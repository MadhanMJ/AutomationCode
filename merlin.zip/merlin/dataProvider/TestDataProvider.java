package com.test.qa.dataProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.EpisodeAdjudication;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;								
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.FrameworkException;

public class TestDataProvider {
	
	public final static String dataPath = CommonUtils.loadFromPropertyFile().getProperty("DATA_PATH");
	static String path = Paths.get("").toAbsolutePath().toString() + File.separator+dataPath+File.separator;
	Fillo fillo=new Fillo();
	Log log = new Log();
	
    @DataProvider(name="TestData")
    public Object[][] readUIData(Method currentMethod) throws InvalidFormatException, IOException {
    	String currentScenario = currentMethod.getDeclaringClass().getSimpleName();
        return readExcel(path+currentScenario+".xlsx", currentScenario);
    }
    
 
    public static Object[][] readExcel(String filePath, String sheetName) throws InvalidFormatException, IOException {
        FileInputStream file= new FileInputStream(filePath);
        XSSFWorkbook wb = new XSSFWorkbook(file);
        XSSFSheet sheet = wb.getSheetAt(0);
        int rowCount = sheet.getLastRowNum();
        int column = sheet.getRow(0).getLastCellNum();
        Object[][] data = new Object[rowCount][column];
        for (int i = 1; i <= rowCount; i++) {
            XSSFRow row = sheet.getRow(i);
            for (int j = 0; j < column; j++) {
                XSSFCell cell = row.getCell(j);
                DataFormatter formatter = new DataFormatter();
                String val = formatter.formatCellValue(cell);
                data[i - 1][j] = val;
            }
        }
        return data;
    }
    
    public Login getLoginData(String userType) {
    	Login login = new Login();
    	 try {
             Connection connection=fillo.getConnection(path+"Login.xlsx");
             String strQuery="Select * from Login where UserType='"+userType+"'";
             Recordset recordset=connection.executeQuery(strQuery);
             while(recordset.next()){
            	 login.setIteration(recordset.getField("Iteration"));
            	 login.setUserName(recordset.getField("UserName"));
            	 login.setPassword(recordset.getField("Password"));
            	 login.setResetPassword(recordset.getField("ResetPassword"));
				login.setTest(recordset.getField("Test"));										
            	 /*
            	  * Author: Mohan Sekar
            	  * Date: 20 Jan 2022
            	  * Purpose: MFA Authentication
            	  * Added MFALogin column in Login.xlsx file to use MFA .
            	  */
            	 login.setMfa(recordset.getField("MFALogin"));
            	
            	 /*
            	  * Author: Vinay Babu
            	  * Date: 07 Dec 2021
            	  * Purpose: For test case ICM_WA_CA600_ReportSetting_ICMEpisodes_01
            	  * Added custname column in Login.xlsx file to use when searching customer in SJM Admin.
            	  */
            	 
            	 login.setCustomer(recordset.getField("CustName"));
             }
             recordset.close();
             connection.close();
         } catch( Exception e ) {
             e.printStackTrace();
         }
    	return login;
    }
    
    public Customer getCustomerData(String testCaseName) throws Exception {
    	Customer customer = new Customer();
    	String flag=null, referenceTestCase=null;
    	String userId = null;
    	 try {
             Connection connection=fillo.getConnection(path+"Customer.xlsx");
             String strQuery="Select * from Customer where TC_Name='"+testCaseName+"'";
             Recordset recordset=connection.executeQuery(strQuery);
             
             while(recordset.next()){
            	 flag = recordset.getField("Flag");          	 
            	 referenceTestCase = recordset.getField("ReferenceTestCase");
             }
             
             if(flag.equalsIgnoreCase("y")) {
            	 customer = setCustomerObjectFromExcel(testCaseName);
             }else if(flag.equalsIgnoreCase("n")) {
            	 String query="Select Userid from Customer where TC_Name='"+referenceTestCase+"'";
            	 Recordset record=connection.executeQuery(query);
            	 
            	//Need to add method to set customer object from refrenced testcase and from current testcase which is planned to implement later
             }else {
            	 throw new FrameworkException("Flag provided is not matching with criteria 'y' or 'n'");
             }
            	 
            connection.close();
            
         } catch( Exception e ) {
        	 log.error(CommonUtils.convertStackTraceToString(e));
             e.printStackTrace();
             throw e;
         }
    	return customer;
    }
    
    public Customer setCustomerObjectFromExcel(String  testCaseName) throws FilloException {
    	Customer customer = new Customer();
    	 Connection connection=fillo.getConnection(path+"Customer.xlsx");
    	 String strQuery="Select * from Customer where TC_Name='"+testCaseName+"'";
         Recordset recordset=connection.executeQuery(strQuery);
         
    	 while(recordset.next()){
    		 
        	 customer.setCustomerName(recordset.getField("CustomerName"));
        	 customer.setCustomerType(recordset.getField("CustomerType"));
        	 customer.setUserid(recordset.getField("Userid"));
        	 customer.setClinicLocation(recordset.getField("ClinicLocation"));
        	 customer.setCountryCode(recordset.getField("CountryCode"));
        	 customer.setAreaCode(recordset.getField("AreaCode"));
        	 customer.setMainPhone(recordset.getField("MainPhone"));
        	 customer.setAddress1(recordset.getField("Address1"));
        	 customer.setAddress2(recordset.getField("Address2"));
        	 customer.setAddress3(recordset.getField("Address3"));
        	 customer.setCountry(recordset.getField("Country"));
        	 customer.setEmail(recordset.getField("Email"));
        	 customer.setClinicTimeZone(recordset.getField("ClinicTimeZone"));
        	 customer.setCity(recordset.getField("City"));
        	 customer.setZipPostalCode(recordset.getField("zipPostalCode")); //Poojitha Added this field in Customer.xlsx and in this method for ZipCode value Date: 29 Dec 2021
        	 customer.setLegalJurisdiction(recordset.getField("LegalJurisdiction"));
        	 customer.setClinicLanguage(recordset.getField("ClinicLanguage"));
        	 customer.setNewPassword(recordset.getField("NewPassword"));
        	 customer.setConfirmNewPassword(recordset.getField("ConfirmNewPassword"));
        	 customer.setFirstName(recordset.getField("FirstName"));
        	 customer.setLastName(recordset.getField("LastName"));
        	 customer.setEmailId(recordset.getField("EmailId"));
        	 customer.setElecExport(recordset.getField("ElecExport"));
        	 customer.setStateProvince(recordset.getField("StateProvince"));
        	 customer.setSecondaryLocation(recordset.getField("SecondaryLocation"));
        	 customer.setMiddleName(recordset.getField("MiddleName"));
        	 customer.setExportTransmissionData(recordset.getField("ExportTransmissionData"));
        	 customer.setOrderTransmitter(recordset.getField("OrderTransmitter"));
        	 customer.setRecordPatientDataCollection(recordset.getField("RecordPatientDataCollection"));
        	 customer.setAllowMobileDirectAlert(recordset.getField("AllowMobileDirectAlert"));
        	 customer.setAllowVoiceMessage(recordset.getField("AllowVoiceMessage"));
        	 customer.setAllowTextMessage(recordset.getField("AllowTextMessage"));
        	 customer.setPatientTransmitterStatus(recordset.getField("PatientTransmitterStatus"));
        	 customer.setPatientDeviceCheck(recordset.getField("PatientDeviceCheck"));
        	 customer.setSearchLocation1(recordset.getField("SearchLocation1"));
        	 customer.setSearchLocation2(recordset.getField("SearchLocation2"));
        	 customer.setSearchLocation3(recordset.getField("SearchLocation3"));
        	 customer.setSearchLocation4(recordset.getField("SearchLocation4"));
        	 customer.setSearchLocation5(recordset.getField("SearchLocation5"));
        	 
        	 customer.setLengthyClinicLocationName(recordset.getField("LengthyClinicLocationName"));
        	 customer.setLengthyAddressField(recordset.getField("LengthyAddressField"));
        	 customer.setLengthyClinicCity(recordset.getField("LengthyClinicCity"));
        	 customer.setLengthyEmailAddress(recordset.getField("LengthyEmailAddress"));
        	 customer.setStateProvinceVerification(recordset.getField("StateProvinceVerification"));
        	 customer.setCountryVerification(recordset.getField("CountryVerification"));
        	 customer.setTimeZoneVerification(recordset.getField("TimeZoneVerification"));
        	 customer.setPatientNames(recordset.getField("PatientNames"));
        	 customer.setPatientID(recordset.getField("PatientID"));
        	 customer.setCustomerApplicationID(recordset.getField("CustomerApplicationID"));
        	 customer.setFollowupDateID(recordset.getField("FollowupDateID"));
        	 
        	 //shafiya added the below code for tc:10.0Rev1_WA_UC013A-B01-01
        	 customer.setTextMessage(recordset.getField("TextMessage"));
        	 customer.setCredentials(recordset.getField("Credentials"));
        	 customer.setSecondaryCountryCode(recordset.getField("SecondaryCountryCode"));
        	 customer.setSecondaryAreaCode(recordset.getField("SecondaryAreaCode"));
        	 customer.setSecondaryMainPhone(recordset.getField("SecondaryMainPhone"));
        	 customer.setFaxCountryCode(recordset.getField("FaxCountryCode"));
        	 customer.setFaxAreaCode(recordset.getField("FaxAreaCode"));
        	 customer.setFaxMainPhone(recordset.getField("FaxMainPhone"));
        	 customer.setStateProvince1(recordset.getField("StateProvince1"));
        	 customer.setStateProvince2(recordset.getField("StateProvince2"));
        	 customer.setStateProvince3(recordset.getField("StateProvince3"));
        	 customer.setStateProvince4(recordset.getField("StateProvince4"));
        	 customer.setStateProvince5(recordset.getField("StateProvince5"));
        	 customer.setStateProvince6(recordset.getField("StateProvince6"));
        	 customer.setStateProvince7(recordset.getField("StateProvince7"));
        	 customer.setStateProvince8(recordset.getField("StateProvince8"));
        	 customer.setCityValue1(recordset.getField("CityValue1"));
        	 customer.setCityValue2(recordset.getField("CityValue2"));
        	 customer.setCityValue3(recordset.getField("CityValue3"));
        	 customer.setCityValue4(recordset.getField("CityValue4"));
        	 customer.setCityValue5(recordset.getField("CityValue5"));
        	 customer.setCityValue6(recordset.getField("CityValue6"));
        	 customer.setClinicNameValue1(recordset.getField("ClinicNameValue1"));
        	 customer.setClinicNameValue2(recordset.getField("ClinicNameValue2"));
        	 customer.setClinicNameValue3(recordset.getField("ClinicNameValue3"));
        	 customer.setClinicNameValue4(recordset.getField("ClinicNameValue4"));
        	 customer.setClinicNameValue5(recordset.getField("ClinicNameValue5"));
        	 customer.setClinicNameValue6(recordset.getField("ClinicNameValue6"));
        	 
         }
         recordset.close();
         
    	return customer;
    }
    
public Patient getPatientData(String testCase) {
    	Patient patient = new Patient();
    	try {
            Connection connection=fillo.getConnection(path+"Patient.xlsx");
            String strQuery="Select * from EnrollPatient where TC_Name='"+testCase+"'";
            Recordset recordset=connection.executeQuery(strQuery);
            while(recordset.next()){
            	patient.setDevice(recordset.getField("Device"));
            	patient.setSerialNumber(recordset.getField("SerialNumber"));
            	patient.setFirstName(recordset.getField("FirstName"));
            	patient.setLastName(recordset.getField("LastName"));
            	patient.setEmail(recordset.getField("Email"));
            	patient.setPhoneNumber(recordset.getField("PhoneNumber"));
            	patient.setDateOfBirth(recordset.getField("DateOfBirth"));
            	patient.setImplantDate(recordset.getField("ImplantDate"));
            	patient.setReleaseReason(recordset.getField("ReleaseReason"));
            	patient.setAddress1(recordset.getField("Address1"));
            	patient.setState(recordset.getField("State"));
            	patient.setZipcode(recordset.getField("Zipcode"));
            	patient.setCity(recordset.getField("City"));
            	patient.setAreaCode(recordset.getField("AreaCode"));
            	patient.setImplantingPhysician(recordset.getField("ImplantingPhysician"));
            	patient.setPatientA(recordset.getField("Patient_A"));
            	patient.setPatientB(recordset.getField("Patient_B"));
            }
            recordset.close();
            connection.close();
        } catch( Exception e ) {
            e.printStackTrace();
        }
    	return patient;
    	
    }
    
  //Poojitha - This method is added to fetch Patient data from excel to search existing patient info in application  
    public Patient getSearchPatientData(String testCase) {
    	Patient searchPatient = new Patient();
    	try {
            Connection connection=fillo.getConnection(path+"Patient.xlsx");
            String strQuery="Select * from SearchPatient where TC_Name='"+testCase+"'";
            Recordset recordset=connection.executeQuery(strQuery);
            while(recordset.next()){
            	searchPatient.setFirstName(recordset.getField("FirstName"));
            	searchPatient.setLastName(recordset.getField("LastName"));
            	searchPatient.setTransmissionFromDate(recordset.getField("TransmissionFromDate"));
            	searchPatient.setTransmissionToDate(recordset.getField("TransmissionToDate"));
            	searchPatient.setPhysicianName_Id(recordset.getField("PhysicianName_Id"));
            	}
            recordset.close();
            connection.close();
        } catch( Exception e ) {
            e.printStackTrace();
        }
    	return searchPatient;
    	
    }													
    
    //Added by Jais
    public List<Login> getClinicUserData(String testCaseID) {
    	List<Login> clinicUsers = new ArrayList<>();
    	
    	 try {
             Connection connection=fillo.getConnection(path+"ClinicUsers.xlsx");
             String strQuery="Select * from "+testCaseID;
             Recordset recordset=connection.executeQuery(strQuery);
             while(recordset.next()){
            	 Login login = new Login();
            	 login.setIteration(recordset.getField("ID"));
            	 login.setUserName(recordset.getField("UserName"));
            	 login.setPassword(recordset.getField("Password"));
            	 login.setUserType(recordset.getField("UserType"));
            	 clinicUsers.add(login);
             }
             recordset.close();
             connection.close();
         } catch( Exception e ) {
             e.printStackTrace();
         }
    	return clinicUsers;
    }
    //emd jais
    
	public static ArrayList<String> readJurisdictionAlerts(String jurisdiction, String sheetName) throws IOException {
		String filename = path+File.separator+"JurisdictionAlerts.xlsx";
		DataFormatter dataFormatter = new DataFormatter();
		ArrayList<String> jurisdictionAlerts = new ArrayList<String>();
		FileInputStream fis = null;
		fis = new FileInputStream(filename);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet(sheetName);
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			XSSFRow row = (XSSFRow) rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) {
				XSSFCell cell = (XSSFCell) cells.next();
				String cellValue = dataFormatter.formatCellValue(cell);
				if(!cellValue.isEmpty())
				jurisdictionAlerts.add(cellValue);
			}
		}
		return jurisdictionAlerts;
	}
	
	
	//Author:Abhishek
	//Reading the alert list from excel for all the alerts
	public static ArrayList<String> readDirectAlertsFromExcel(String sheetName) throws IOException {
		String filename = path+File.separator+"DirectAlert.xlsx";
		DataFormatter dataFormatter = new DataFormatter();
		ArrayList<String> directAlerts = new ArrayList<String>();
		FileInputStream fis = null;
		fis = new FileInputStream(filename);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet(sheetName);
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			XSSFRow row = (XSSFRow) rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) {
				XSSFCell cell = (XSSFCell) cells.next();
				String cellValue = dataFormatter.formatCellValue(cell);
				if(!cellValue.isEmpty())
					directAlerts.add(cellValue);
			}
		}
		return directAlerts;
	}
	
	
	//Author: Snehal
		//Reading the Clinical comments list from excel
		public static ArrayList<String> readClinicalCommentsFromExcel(String sheetName) throws IOException {
			String filename = path+File.separator+"ClinicalComments.xlsx";
			DataFormatter dataFormatter = new DataFormatter();
			ArrayList<String> comments = new ArrayList<String>();
			FileInputStream fis = null;
			fis = new FileInputStream(filename);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			Iterator<Row> rows = sheet.rowIterator();
			while (rows.hasNext()) {
				XSSFRow row = (XSSFRow) rows.next();
				Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					XSSFCell cell = (XSSFCell) cells.next();
					String cellValue = dataFormatter.formatCellValue(cell);
					if(!cellValue.isEmpty())
						comments.add(cellValue);
				}
			}
			return comments;
		}
		
		public static ArrayList<String> readJurisdictionDevices(String sheetName) throws IOException {
			String filename = path+File.separator+"JurisdictionDevices.xlsx";
			DataFormatter dataFormatter = new DataFormatter();
			ArrayList<String> jurisdictionDevice = new ArrayList<String>();
			FileInputStream fis = null;
			fis = new FileInputStream(filename);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			Iterator<Row> rows = sheet.rowIterator();
			while (rows.hasNext()) {
				XSSFRow row = (XSSFRow) rows.next();
				Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					XSSFCell cell = (XSSFCell) cells.next();
					String cellValue = dataFormatter.formatCellValue(cell);
					if(!cellValue.isEmpty())
						jurisdictionDevice.add(cellValue);
				}
			}
			return jurisdictionDevice;
		}
			//Shanmugapriya
		public EpisodeAdjudication getEpisodeAdjudicationData(String path) {
			EpisodeAdjudication searchEpisode = new EpisodeAdjudication();
			try {
			Connection connection=fillo.getConnection(path);
			String strQuery="Select top 1 from Merlin.net™ Episode Adjudication";
			Recordset recordset=connection.executeQuery(strQuery);
			while(recordset.next()){
			searchEpisode.setAssessment(recordset.getField("Assessment"));
			searchEpisode.setLastAccessedBy(recordset.getField("Last assessed by"));
			searchEpisode.setLastAccessedOn(recordset.getField("Last assessed on"));
			searchEpisode.setNotes(recordset.getField("Notes"));
			searchEpisode.setEpisodeDateAndTime(recordset.getField("Episode Date/Time"));
			searchEpisode.setEpisodeType(recordset.getField("Episode Type"));
			searchEpisode.setTransmissionDateAndTime(recordset.getField("Transmission Date/Time"));
			}
			recordset.close();
			connection.close();
			} catch( Exception e ) {
			e.printStackTrace();
			}
			return searchEpisode ;
			}
		//Ends here

}
