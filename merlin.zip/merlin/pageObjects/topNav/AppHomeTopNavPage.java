package com.test.qa.ui.pageObjects.topNav;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static com.test.qa.utilities.CommonUtils.extentTest;

public class AppHomeTopNavPage extends BasePage {

	/*
	 * AUTHOR: Vinay Babu
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public AppHomeTopNavPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By signOut_link_OR = By.xpath("//div[@id=\"shell-wrapper\"]/mat-toolbar/mat-toolbar-row/div[2]/div/div[1]/a/span/span[3]");
	private final String signOut_link_S = "Sign Out Link";
	private final By profile_link_OR=By.xpath("//span[text()='Physician01']"); // Alok
	private final String profile_link_S= "Profile Link"; // Alok
	
	
	public void clickSignOutLink() throws InterruptedException
	{
		presenceOfElementLocated(signOut_link_OR);
		waitForLoading();
		//extentReport.reportScreenShot("Clicking Clinic Administration Link");
		clickElement(signOut_link_OR);
		waitForLoading();
		waitForLoading();
		waitForLoading();
		
	}
	
	// ---------------------- Alok-----------------------------------//
	
	public void profileLink() throws InterruptedException
	{
		System.out.print("---------------------------");
		presenceOfElementLocated(profile_link_OR);
		waitForLoading();
		//highLightElement(profile_link_OR);
		extentReport.reportScreenShot("Clicking User Profile");
		clickElement(profile_link_OR);
		waitForLoading();
		waitForLoading();
		waitForLoading();
		
	}
	
	
	// ------------------------Alok End------------------------//
	// Each page class should have this overridden method of Verify Landing page

	@Override
	public boolean verifyLandingPage() {
		Boolean clinicianHomePageCheck = false;
		
		return clinicianHomePageCheck;
	}
}
