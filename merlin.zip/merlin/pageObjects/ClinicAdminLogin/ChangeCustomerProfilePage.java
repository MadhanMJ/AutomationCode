package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.utilities.CommonUtils;

/**
 * @author RATHIGX
 *
 */
public class ChangeCustomerProfilePage extends BasePage {
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	Assertions assertion = new Assertions(extentTest);
	public final By LoadingIcon_OR = By.xpath("//*[@class='spinnerWrapper show']");
	public final String LoadingIcon_S = "Loading icon";
	public final By customerName = By.xpath("//input[@id='txt_customer-head-quarters_customerName_customerName']");
	private final By customerTypeDropDown = By.xpath("//mat-select[@id='dd_customer-head-quarters_customerTypeCd']/div/div[2]");
	private final By country = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div[2]");
	public final By countryText = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div/span");
	public final By legalJurisdictionText = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_legaJurisdictionCd']/div/div/span");
	public final By legalJurisdictionWarning = By.xpath("//MAT-ERROR");
	private final By countrySearchBox = By.xpath("//ngx-mat-select-search[@formcontrolname='searchCtrl']/div/input");
	private final By areaCode = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_areaCode']/mat-form-field/div/div/div/input");
	private final By firstName = By.xpath(
			"//merlin-textbox[@id='txt_customer-clinic-main-contact_firstName']/mat-form-field/div/div/div/input");
	private final By lastName = By.xpath(
			"//merlin-textbox[@id='txt_customer-clinic-main-contact_lastName']/mat-form-field/div/div/div/input");
	private final By middleName = By.xpath(
			"//merlin-textbox[@id='txt_customer-clinic-main-contact_middleName']/mat-form-field/div/div/div/input");
	private final By clinicContactEmail = By
			.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_email']/mat-form-field/div/div/div/input");
	private final By countryCode = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_countryCode']/mat-form-field/div/div/div/input");
	//XPath Updated on 02/19/2022-ChandraMohan.S
	//private final By zipPostalCode = By.xpath("//input[@placeholder=\"Zip/Postal Code\"]");
	private final By zipPostalCode = By.xpath("//input[@id='txt_customer-clinicinfo_zipCode_zipCode']");
	private final By clinicLocation = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_clinicLocation']/mat-form-field/div/div/div/input");
	private final By address_1 = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address1']/mat-form-field/div/div/div/input");
	private final By address_2 = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address2']/mat-form-field/div/div/div/input");
	private final By address_3 = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address3']/mat-form-field/div/div/div/input");
	//Xpath Updated on 02/19/2022-ChandraMohan.S
	//public final By city = By.xpath("//input[@id=\"merlin_textbox_city\"]");
	public final By city = By.xpath("//input[@id='txt_customer-clinicinfo_city_city']");
	private final By mainPhone = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_mainPhone']/mat-form-field/div/div/div/input");
	public final By clinicEmail = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_emailAddress']/mat-form-field/div/div/div/input");
	private final By clinicTimeZone = By.xpath("//mat-select[@formcontrolname='timeZoneCd']/div/div[2]");
	private final By legalJurisdiction = By.xpath("//mat-select[@formcontrolname='legalJurisdictionCd']");
	private final By legalJurisdictionValues = By.xpath("//span[@class=\"mat-option-text\"]");
	private final By expectedLegalJuridiction = By.xpath("//button[@id=\"btn_pcs-location-popup_Ok\"]");
	private final By clinicLanguageField = By.xpath("//mat-select[@placeholder='Clinic Language ']/div/div[2]");
	private final By clinicLanguageSearchBox = By
			.xpath("//ngx-mat-select-search[@formcontrolname='clinicLangsearchCtrl']/div/input");

	//Updated XPath on 02/16/2022
	//private final By saveButton_OR = By.xpath("//button[@mattooltip='Save']");

	private final By saveButton_OR = By.xpath("//button[@id='btn_customer_save']");
	private final String saveButton_S = "Save Button";
	private final By cancelButton = By.xpath("//button[@id='btn_customer_cancel']");
	private final By popUpCancelButton_OR = By.xpath("//button[@id='btn_pcs-location-popup_Cancel']");
	private final String popUpCancelButton_S = "Popup Cancel Button";
	private final By okButton_OR = By.xpath("//button[@id='btn_pcs-location-popup_Ok']");
	private final String okButton_S = "OK Button";

	public final By mandateFieldWarningToaster_OR = By.xpath("//div[@id='toast-container']/div/div");
	private final String mandateFieldWarningToaster_S = "MandateFieldWarningToaster";

	private final By okButtondeletePopUp_OR = By.xpath("//button[@id='close-btn-customer-delete-popup']");
	private final String okButtondeletePopUp_S = "Ok Button delete popup";
	private final By messageField = By.xpath("//merlin-textbox[@label=\"Text Message\"]");
	public final By okPopUpContent = By.xpath("//mat-dialog-content/div/p");
	public final By jurisdictionPopUpContent_OR = By.xpath("//mat-dialog-content/div/p");
	public final String jurisdictionPopUpContent_S = "Jurisdiction Popup";
	private final By exportToEHRDropDownOption_OR = By.xpath("//mat-option/span[contains(text(),'Manual')]");
	private final String exportToEHRDropDownOption_S = "Export To EHR DropDown Option";
	private final By popUpText = By
			.xpath("//mat-dialog-container[@id='mat-dialog-0']/merlin-popup/mat-dialog-content/div/p");
	private final By popUpDeleteLine1_OR = By.xpath("(//mat-dialog-content[@class='mat-dialog-content']/div)[1]");
	private final String popUpDeleteLine1_S = "Delete customer popup Message Line1";
	private final By popUpDeleteLine2 = By.xpath("(//mat-dialog-content[@class='mat-dialog-content']/div)[2]");
	private final String popUpDeleteLine2_S = "Delete customer popup Message Line2";
	public final By exportTransmissionFlag_OR = By.xpath("//mat-checkbox[@formcontrolname='showExportSessionFlg']");
	public final String exportTransmissionFlag_S = "Export Transmission Check Box";
	public final By exportTransmission_OR = By
			.xpath("//mat-checkbox[@formcontrolname='showExportSessionFlg']/label/div/input");
	public final String exportTransmission_S = "Export Transmission";
	public final By allowedClinicalTrials = By
			.xpath("//merlin-bucket-list[@id=\"bls_customer-feature-control_allowedClinicTrial\"]/div/div/div");
	public final By exportTransmissionCheckBox_OR = By
			.xpath("//mat-checkbox[@formcontrolname='showExportSessionFlg']/label");
	public final String exportTransmissionCheckBox_S = "Export Transmission Check Box";
	public final By exportTransmissionclick = By
			.xpath("//mat-checkbox[@id='chb_customer-feature-control_showExportSessionFlg']/label/div");
	public final By orderTransmitterclick = By
			.xpath("//mat-checkbox[@id='chb_customer-feature-control_orderTransmitterFlg']/label/div");
	public final By exportTransmissionCheckBoxclick = By
			.xpath("//mat-checkbox[@id='chb_customer-feature-control_showExportSessionFlg']/label/div/input");
	public final By orderTransmitterCheckBoxclick = By
			.xpath("//mat-checkbox[@id='chb_customer-feature-control_orderTransmitterFlg']/label/div/input");

	public final By exportToEHRDropDownvalue = By
			.xpath("//mat-select[@id='dd_customer-feature-control_exportEHRTypeCd']//span/span");
	public final By exportToEHRDropDownNoexport = By
			.xpath("//div[@id='dd_customer-feature-control_exportEHRTypeCd-panel']/mat-option[1]");
	public final By exportToEHRDropDownManual = By
			.xpath("//div[@id='dd_customer-feature-control_exportEHRTypeCd-panel']/mat-option[2]");

	public final By exportToEHRDropDown_OR = By.xpath("//mat-select[@formcontrolname='exportEHRTypeCd']/div/div[2]/div");
	public final String exportToEHRDropDown_S = "Export To EHR DropDown";
	private final By exportToEHRDropDownOptions = By
			.xpath("//div[@id='dd_customer-feature-control_exportEHRTypeCd-panel']/mat-option");
	public final By orderTransmitterFlag_OR = By.xpath("//mat-checkbox[@formcontrolname='orderTransmitterFlg']");
	public final String orderTransmitterFlag_S = "Order Transmitter Check Box";
	public final By orderTransmitter_OR = By
			.xpath("//mat-checkbox[@formcontrolname='orderTransmitterFlg']/label/div/input");
	public final String orderTransmitter_S = "Order Transmitter";
	public final By orderTransmitterCheckBox_OR = By.xpath("//mat-checkbox[@formcontrolname='orderTransmitterFlg']/label");
	public final String orderTransmitterCheckBox_S = "Order Transmitter Check Box";
	public final By lockoutLegacyDeviceChckFlg = By
			.xpath("//mat-checkbox[@formcontrolname='lockoutLegacyDeviceChckFlg']");
	public final By lockoutLegacyDevice = By
			.xpath("//mat-checkbox[@formcontrolname='lockoutLegacyDeviceChckFlg']/label/div/input");
	public final By lockoutLegacyDeviceChckBox = By
			.xpath("//mat-checkbox[@formcontrolname='lockoutLegacyDeviceChckFlg']/label/div");
	public final By userIdValue_OR = By.xpath("//input[@placeholder='User ID'][@aria-required='true']");
	private final String userIdValue_S = "User ID";
	private final By stateProvinceDropDown = By
			.xpath("//mat-select[@placeholder='State/Prov.']['aria-required']/div/div[2]");
	public final By stateProvinceTextField_OR = By.xpath("//input[@id='txt_customer-clinicinfo_state_stateProvince']");
	public final String stateProvinceTextField_S = "State Province Text Field";
	public final By mandatoryFieldError = By.xpath("//div[@role='alertdialog'][@aria-label='Some mandatory fields are not filled. Please check for the inline errors!!!']");
	//updated XPath on 02/18-ChandraMohan.S
	//private final By closeMandatoryErrorPopUp = By.xpath("//div[@id='toast-container']");
	private final By closeMandatoryErrorPopUp = By.xpath("//div[@id='toast-container']/div");

	private final By customerHeadquarterText = By.xpath("//merlin-section[@subtitle='Customer Headquarters']");
	public final By allowedApplications_OR = By
			.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedAppCodeIds']/div[3]/div/select");
	public final By allowedApplications = By
			.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedAppCodeIds']/div[3]/div/select");
	public final String allowedApplications_S = "Allowed Applications";
	public final By recordPatientDataCollectionFlag_OR = By
			.xpath("//mat-checkbox[@id='chb_customer-feature-control_showDataMiningConsentFlg']");
	public final String recordPatientDataCollectionFlag_S = "Record Patient Data Collection";
	public final By allowSmartAlertFlg_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowSmartAlertFlg']");
	public final String allowSmartAlertFlg_S="Allow Mobile DirectAlerts";
	public final By allowCommCenterAccess_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowCommCenterAccess']");
	public final String allowCommCenterAccess_S="Allow access to Communication Center";
	public final By allowComplianceReport_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowComplianceReport']");
	public final String allowComplianceReport_S="Allow access to Compliance Report";
	private final By recordPatientDataCollectionChkBox_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_showDataMiningConsentFlg']/label");
	public final String recordPatientDataCollectionChkBox_S = "Record Patient Data Collection ChkBox";
	private final By recordPatientDataCollection_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_showDataMiningConsentFlg']/label/div/input");
	private final String recordPatientDataCollection_S = "Record Patient Data Collection";
	private final By allowSmartAlertChkBox_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowSmartAlertFlg']/label");
	private final String allowSmartAlertChkBox_S = "Allow Smart Alert ChkBox";
	private final By allowSmartAlert_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowSmartAlertFlg']/label/div/input");
	public final By allowDirectCallVoiceFlg_OR=By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowDirectCallVoice']");
	public final String allowDirectCallVoiceFlg_S = "Voice Messages Flag";
	public final By allowDirectCallTextFlg_OR = By
			.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowDirectCallText']");
	public final String allowDirectCallTextFlg_S = "Text Messages Flag";
	private final By allowDirectCallVoiceCB_OR=By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowDirectCallVoice']/label");
	private final String allowDirectCallVoiceCB_S = "Allow Direct Call Voice Check Box";
	private final By allowDirectCallTextCB_OR=By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowDirectCallText']/label");
	private final String allowDirectCallTextCB_S = "Allow Direct Call Tex Checkbox";
	private final By allowDirectCallVoice_OR=By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowDirectCallVoice']/label/div/input");
	private final By allowDirectCallText=By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowDirectCallText']/label/div/input");
	private final By allowedClinicalTrailSection = By.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedClinicTrial']/div[3]/div/select");
	public final By removeEPApplicationButton = By.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedAppCodeIds']/div[2]/button[@id='mmc-customizeHomepage-removeButton']");
	public final By addClinincalTrailButton_OR = By.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedClinicTrial']/div[2]/button[@id='mmc-customizeHomepage-addButton']");
	public final String addClinincalTrailButton_S = "Add Clinical Trial Button";
	private final By generalFeaturesSection = By.xpath("//div[@id='featureControl']/div/div[3]");
	public final By applicationControlSection_OR = By.xpath("//div[@id='featureControl']/div/div[4]");
	public final String applicationControlSection_S = "Application Control Section";
	public final By dropdown = By.xpath("//mat-select[@id='dd_customer-feature-control_exportEHRTypeCd']");
	private final By customerNameInvalidError = By
			.xpath("//merlin-textbox[@placeholder='Customer name']/mat-form-field/div/div[2]/div/mat-error");
	private final By clinicLocationInvalidError = By
			.xpath("//merlin-textbox[@placeholder='Clinic Location']/mat-form-field/div/div[2]/div/mat-error");
	private final By mainPhoneInvalidError = By
			.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_mainPhone']/mat-form-field/div/div[2]/div/mat-error");
	public final By emailInvalidError = By
			.xpath("//merlin-textbox[@label='Email']/mat-form-field/div/div[2]/div/mat-error");
	private final By areaCodeInvalidError = By
			.xpath("//merlin-textbox[@label='Area Code']/mat-form-field/div/div[2]/div/mat-error");
	private final By countryCodeInvalidError = By
			.xpath("//merlin-textbox[@label='Country Code']/mat-form-field/div/div[2]/div/mat-error");
	public final By pageLoading = By.xpath("//*[@class='spinnerWrapper show']");
	/*
	 * Author: Vinay Babu Date: 08 Dec 2021 Below are used for test case
	 * ICM_WA_CA600_ReportSetting_ICMEpisodes_01
	 */
	
	private static By exportToEHRValue_OR(String getElecExport) {
	By exportToEHRValue = By.xpath("//mat-option/span[text()=' " + getElecExport + "']");
	return exportToEHRValue;
	}

	private final By availableDevices_Select_OR = By.xpath(
			"//merlin-bucket-list[@id=\"bls_customer-feature-control_allowedDeviceIds\"]//select[@name=\"sample_2mmc-leftSelectBox\"]");
	private String availableDevices_Select_S = "Available Devices Select";

	private final By allowedDevices_Select_OR = By.xpath(
			"//merlin-bucket-list[@id=\"bls_customer-feature-control_allowedDeviceIds\"]//select[@name=\"sample_2mmc-rightSelectBox\"]");
	private String allowedDevices_Select_S = "Allowed Devices Select";

	private final By devicesadd_Button_OR = By.xpath(
			"//merlin-bucket-list[@id=\"bls_customer-feature-control_allowedDeviceIds\"]//button[@id=\"mmc-customizeHomepage-addButton\"]");
	private String devicesadd_Button_S = "Devices Add Button";

	private final By devicesremove_Button_OR = By.xpath(
			"//merlin-bucket-list[@id=\"bls_customer-feature-control_allowedDeviceIds\"]//button[@id=\"mmc-customizeHomepage-removeButton\"]");
	private String devicesremove_Button_S = "Devices Remove Button";

	private final By deleteCustomer_Button_OR = By.xpath("//button[@id='btn_customer_deleteCustomer']");
	private String deleteCustomer_Button_S = "Delete Customer Button";

	//////////////////////////////////////////////////////////////////////

	// added by Jeetendra
	private final By CustomerIdValue = By.xpath(".//*[@id='txt_customer-head-quarters_customerId']");

	public String userId = "";
	public String zipPostalCodeValue = "";
	public String expectedLegalJuridictionText = "You have changed the clinic's jurisdiction value.\n"
			+ "Please review the following settings to ensure they are appropriate for the new jurisdiction:\n"
			+ "--Available Devices\n" + "--Available DirectAlerts™\n" + "--DirectAlerts™ Notifications\n"
			+ "--Minimum Password Length\n" + "--Password expiration setting\n" + "--Send Voice Messages\n"
			+ "--Send Text Messages\n" + "--Export to EHR\n" + "--Set CDC Schedules\n"
			+ "--Order Transmitter settings\n" + "\n"
			+ "In addition, changing the jurisdiction may require using the \"Software Versioning Tool\"\n"
			+ "to ensure the clinic has the correct Web App and DDT Software versions assigned.";

	// Author: Poojitha - Added few more fields XPath's
	private final By stateProvinenceTextBox_OR = By.xpath("//*[@id='dd_customer-clinicinfo_stateCd']");
	private final String stateProvinenceTextBox_S = "State drop down";
	private final By stateProvinenceSearchBox_OR = By
			.xpath("//ngx-mat-select-search[@formcontrolname='statesearchCtrl']/div/input");
	private final String stateProvinenceSearchBox_S = "State search box after clicking on dropdown";
	private final By directAlertsForPatients_OR = By
			.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedInformPatientAlertIds']");
	private final String directAlertsForPatients_S = "DirectAlerts� Notifications allowed for patients (with non-Bluetooth devices) section";
	private final By removedirectAlertsForPatientsButton_OR = By.xpath(
			"//merlin-bucket-list[@id='bls_customer-feature-control_allowedInformPatientAlertIds']/div[2]/button[@id='mmc-customizeHomepage-removeButton']");
	private final String removedirectAlertsForPatientsButton_S = "Remove button under Direct alerts for Patients section";
	private final By removeAllowedElectroPhysiologyButton_OR = By.xpath(
			"//merlin-bucket-list[@id='bls_customer-feature-control_allowedDeviceIds']/div[2]/button[@id='mmc-customizeHomepage-removeButton']");
	private final String removeAllowedElectroPhysiologyButton_S = "Remove button under Allowed Electrophysiology alerts section";
	// updating existing xpath's as per new standards
	private final By customerName_OR = By.xpath("//input[@id='txt_customer-head-quarters_customerName_customerName']");
	private final String customerName_S = "Customer name text box";
	private final By customerTypeDropDown_OR = By
			.xpath("//mat-select[@id='dd_customer-head-quarters_customerTypeCd']/div/div[2]");
	private final String customerTypeDropDown_S = "Customer Type dropdown";
	private final By country_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div[2]");
	private final String country_S = "Country text box";
	private final By countryText_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div/span");
	private final String countryText_S = "CountryText search box";
	private final By legalJurisdictionText_OR = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_legaJurisdictionCd']/div/div/span");
	private final By legalJurisdictionWarning_OR = By.xpath("//MAT-ERROR[starts-with(@id,'mat-error')]");
	private final By countrySearchBox_OR = By.xpath("//ngx-mat-select-search[@formcontrolname='searchCtrl']/div/input");
	private final String countrySearchBox_S = "Country Search Box";
	private final By areaCode_OR = By.xpath("//input[@id='txt_customer-clinicinfo_areaCode_areaCode']");
	private final String areaCode_S = "area code text box";
	private final By firstName_OR = By.xpath("//input[@id='merlin_textbox_firstName']");
	private final String firstName_S = "first name text box";
	private final By lastName_OR = By.xpath("//input[@id='merlin_textbox_middleName']");
	private final String lastName_S = "last name text box";
	private final By middleName_OR = By.xpath("//input[@id='merlin_textbox_lastName']");
	private final String middleName_S = "middle name text box";
	private final By userId_OR = By.xpath("//input[@id='merlin_textbox_userId']");
	private final String userId_S = "user id text box";
	private final By clinicContactEmail_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_email_mainContactEmail']");
	private final String clinicContactEmail_S = "clinic contact email address";

	private final By countryCode_OR = By.xpath("//input[@id='txt_customer-clinicinfo_countryCode_countryCode']");
	private final String countryCode_S = "country code text box";

	private final By zipPostalCode_OR = By.xpath("//input[@id='merlin_textbox_zipCode']");
	private final String zipPostalCode_S = "Zip postal code text box";
	private final By clinicLocation_OR = By
			.xpath("//input[@id='txt_customer-clinicinfo_clinicLocation_primaryLocation']");
	private final String clinicLocation_S = "clinic location text box";
	private final By address_1_OR = By.xpath("//input[@id='txt_customer-clinicinfo_address1_streetAddress']");
	private final String address_1_S = "Address line1 text box";
	private final By address_2_OR = By.xpath("//input[@id='txt_customer-clinicinfo_address2_streetAddress2']");
	private final String address_2_S = "Address line2 text box";
	private final By address_3_OR = By.xpath("//input[@id='txt_customer-clinicinfo_address3_streetAddress3']");
	private final String address_3_S = "Address line3 text box";
	private final By city_OR = By.xpath("//input[@id='txt_customer-clinicinfo_city_city']");
	private final String city_S = "City text box";
	private final By mainPhone_OR = By.xpath("//input[@id='txt_customer-clinicinfo_mainPhone_phoneNum']");
	private final String mainPhone_S = "main phone number text box";
	private final By clinicEmail_OR = By.xpath("//input[@id='txt_customer-clinicinfo_emailAddress_emailAddress']");
	private final String clinicEmail_S = "Clinic email text box";
	private final By clinicTimeZone_OR = By.xpath("//mat-select[@formcontrolname='timeZoneCd']/div/div[2]");
	private final String clinicTimeZone_S = "Clinic Time Zone dropdown";
	private final By legalJurisdiction_OR = By.xpath("//mat-select[@formcontrolname='legalJurisdictionCd']");
	private final String legalJurisdiction_S = "Legal Jurisdiction";
	private final By legalJurisdictionValues_OR = By.xpath("//span[@class=\"mat-option-text\"]");
	private final By expectedLegalJuridiction_OR = By.xpath("//button[@id=\"btn_pcs-location-popup_Ok\"]");
	private final By clinicLanguageField_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd']/div/div[2]");
	private final String clinicLanguageField_S = "Clinic language text box";
	private final By clinicLanguageSearchBox_OR = By
			.xpath("//ngx-mat-select-search[@formcontrolname='clinicLangsearchCtrl']/div/input");
	private final String clinicLanguageSearchBox_S = "Clinic Language Search Box";
	private final By customerHeadquarterText_OR = By.xpath("//div[@id='section_title_Customer_headquarters']");
	private final String customerHeadquarterText_S = "customer headquarter text";

	private final By availableEPDirectAlerts_Select_OR = By.xpath(
			"//merlin-bucket-list[@id='bls_customer-feature-control_allowedEPAlertIds']//select[@name='sample_2mmc-leftSelectBox']");
	private final String availableEPDirectAlerts_Select_S = "Available EP Direct Alerts™ Notifications (For Non-Bluetooth devices)";
	private final By allowedEPDirectAlerts_Select_OR = By.xpath(
			"//merlin-bucket-list[@id='bls_customer-feature-control_allowedEPAlertIds']//select[@name='sample_2mmc-rightSelectBox']");
	private final String allowedEPDirectAlerts_Select_S = "Allowed EP Direct Alerts™ Notifications (For Non-Bluetooth devices)";
	private final By availableDirectAlertsForPatients_Select_OR = By.xpath(
			"//merlin-bucket-list[@id='bls_customer-feature-control_allowedInformPatientAlertIds']//select[@name='sample_2mmc-leftSelectBox']");
	private final String availableDirectAlertsForPatients_Select_S = "Available direct alerts for patients(Non-Bluetooth devices)";
	private final By allowedDirectAlertsForPatients_Select_OR = By.xpath(
			"//merlin-bucket-list[@id='bls_customer-feature-control_allowedInformPatientAlertIds']//select[@name='sample_2mmc-rightSelectBox']");
	private final String allowedDirectAlertsForPatients_Select_S = "Allowed direct alerts for patients(Non-Bluetooth devices)";

	//Added for Activator clinic test case
	private final By activatorClinicCheckbox_OR = By.xpath("//input[@id='chb_customer-clinicinfo_activator_clinic-input']");
	private final String activatorClinicCheckbox_S = "Activator clinic checkbox";
	//Updated XPath on 02/19/2022-ChandraMohan.S
	//private final By allAbbottCustomers_OR= By.linkText("All Abbott customers");
	private final By allAbbottCustomers_OR= By.xpath("//mat-toolbar/mat-toolbar-row/div/ul/li[2]");
	//mat-toolbar/mat-toolbar-row/div/ul/li[2]
	private final String allAbbottCustomers_S= "All Abbott Customers link";

	// Ends here

	public ChangeCustomerProfilePage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
	}

	/*
	 * Author: Vinay Babu Date: 08 Dec 2021 Below are used for test case
	 * ICM_WA_CA600_ReportSetting_ICMEpisodes_01
	 */

	public void addDevicesToAllowedListAndSave(List<String> deviceNames) throws Exception {

		scrollToView(availableDevices_Select_OR);

		for (String deviceName : deviceNames) {
			clickOnOneElementInSelectList(availableDevices_Select_OR, deviceName, availableDevices_Select_S);
			clickElement(devicesadd_Button_OR, devicesadd_Button_S);
		}

		clickSaveButton();
		clickOKButton();
		waitForLoading();
		waitForLoading();

	}

	// Poojitha
	public void addDevicesToAllowedListAndSave(String[] deviceNames) throws Exception {

		scrollToView(availableDevices_Select_OR);
		List<String> deviceList = new ArrayList<String>();
		deviceList = Arrays.asList(deviceNames);

		for (String deviceName : deviceList) {
			clickOnOneElementInSelectList(availableDevices_Select_OR, deviceName, availableDevices_Select_S);
			clickElement(devicesadd_Button_OR, devicesadd_Button_S);
		}

		clickSaveButton();
		clickOKButton();
		waitForLoading();
		waitForLoading();

	}

	// Vrushali
	public void removeDevicesFromAllowedListAndSave(List<String> deviceNames) throws Exception {

		scrollToViewWithoutReport(allowedDevices_Select_OR, allowedDevices_Select_S);

		for (String deviceName : deviceNames) {
			clickOnOneElementInSelectList(allowedDevices_Select_OR, deviceName, allowedDevices_Select_S);
			clickElement(devicesremove_Button_OR, devicesremove_Button_S);
		}

		clickSaveButton();
		clickOKButton();

	}

	//////////////////////////////////////////////////////////////////////

	/**
	 * This method will be used to get userId from the change customer page
	 */
	public String getUserId() throws InterruptedException {
		invisibilityOfElementLocatedWithoutReport(LoadingIcon_OR, LoadingIcon_S);
		if (visibilityOfElementLocatedWithoutReport(userIdValue_OR, userIdValue_S))
			userId = getAttribute(userIdValue_OR, "value");
		return userId;
	}

	/**
	 * This method will be used to get ZipPostal Code from the change customer page
	 */
	public String getPostalCode() throws InterruptedException {
		if (visibilityOfElementLocated(zipPostalCode))
			clickElement(city);// Just to bring out the mouse focus from zip postal code filed, if any.
		zipPostalCodeValue = getAttribute(zipPostalCode, "value");
		return zipPostalCodeValue;
	}

	/**
	 * This method will be used to get the CustomerId from the URL
	 */
	public String getCustomerId() throws InterruptedException {
		String url = getCurrentURL();
		String customerId = url.substring(url.lastIndexOf("/") + 1);
		return customerId;
	}

	/**
	 * This method to select or unselect based on avalable option. if already
	 * selected it will unselect it
	 */
	public boolean checkboxselect(By locator, boolean option, By clickelement) throws InterruptedException {
		if (option) {

			clickElement(clickelement);

			option = getCheckboxvalue(locator, "aria-checked");
		} else {

			clickElement(clickelement);
			option = getCheckboxvalue(locator, "aria-checked");
		}
		return option;
	}

	/**
	 * method to changing the fields of customer
	 * 
	 * @param customer - Customer object with the values to be changed
	 */
	// Poojitha - updated with new XPath variables Date: 29 Dec, 2021
	public void changeCustomer(Customer customer) throws Exception {
		By customerTypeValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getCustomerType() + "')]");
		By clinicLanguageValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getClinicLanguage() + "')]");
		By countryValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getCountry() + "')]");
		By clinicTimeZoneValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getClinicTimeZone() + "')]");
		By legalJurisdictionValue = By
				.xpath("//mat-option/span[contains(text(),'" + customer.getLegalJurisdiction() + "')]");
		By stateProvinceValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getStateProvince() + "')]");

		try {
				scrollUp();
				if (!customer.getCustomerName().isEmpty()) {
					// if (visibilityOfElementLocated(customerName_OR))
					waitForLoading();
					waitForLoading();
					clickElement(customerName_OR, customerName_S);
					sendKeys(customerName_OR, customerName_S, customer.getCustomerName());
				}
				if (!customer.getCustomerType().isEmpty()) {
					// if (visibilityOfElementLocated(customerTypeDropDown_OR))
					clickElement(customerTypeDropDown_OR, customerTypeDropDown_S);
					clickElement(customerTypeValue);
				}
				if (!customer.getClinicLocation().isEmpty()) {
					// if (visibilityOfElementLocated(clinicLocation_OR))
					sendKeys(clinicLocation_OR, clinicLocation_S, customer.getClinicLocation());
				}
				if (!customer.getCountryCode().isEmpty()) {
					// if (visibilityOfElementLocated(countryCode_OR))
					sendKeys(countryCode_OR, countryCode_S, customer.getCountryCode());
				}
				if (!customer.getAreaCode().isEmpty()) {
					// if (visibilityOfElementLocated(areaCode_OR))
					sendKeys(areaCode_OR, areaCode_S, customer.getAreaCode());
				}
				if (!customer.getMainPhone().isEmpty()) {
					// if (visibilityOfElementLocated(mainPhone_OR))
					sendKeys(mainPhone_OR, mainPhone_S, customer.getMainPhone());
				}
				if (!customer.getAddress1().isEmpty()) {
					// if (visibilityOfElementLocated(address_1_OR))
					sendKeys(address_1_OR, address_1_S, customer.getAddress1());
				}
				if (!customer.getAddress2().isEmpty()) {
					// if (visibilityOfElementLocated(address_2_OR))
					sendKeys(address_2_OR, address_2_S, customer.getAddress2());
				}
				if (!customer.getAddress3().isEmpty()) {
					// if (visibilityOfElementLocated(address_3_OR))
					sendKeys(address_3_OR, address_3_S, customer.getAddress3());
				}
				if (!customer.getCountry().isEmpty()) {
					// if (visibilityOfElementLocated(country_OR))
					clickElement(country_OR, country_S);
					// elementToBeClickable(countrySearchBox_OR);
					sendKeys(countrySearchBox_OR, countrySearchBox_S, customer.getCountry());
					visibilityOfElementLocated(countryValue);
					clickElement(countryValue);
					// invisibilityOfElementLocated(pageLoading);
				}
				if (!customer.getEmail().isEmpty()) {
					// if (visibilityOfElementLocated(clinicEmail_OR))
					sendKeys(clinicEmail_OR, clinicEmail_S, customer.getEmail());
				}
				if (!customer.getClinicTimeZone().isEmpty()) {
					// if (visibilityOfElementLocated(clinicTimeZone_OR))
					clickElement(clinicTimeZone_OR, clinicTimeZone_S);
					clickElement(clinicTimeZoneValue);
				}
				if (!customer.getCity().isEmpty()) {
					// if (visibilityOfElementLocated(city_OR))
					clickElement(city_OR, city_S);
					sendKeys(city_OR, city_S, customer.getCity());
					scrollToViewWithoutReport(city_OR, city_S);
				}
				if (!customer.getLegalJurisdiction().isEmpty()) {
					// if (visibilityOfElementLocated(legalJurisdiction_OR))
					clickElement(legalJurisdiction_OR, legalJurisdiction_S);
					clickOnElementUsingJs(legalJurisdictionValue);
					// invisibilityOfElementLocated(pageLoading);
				}
				if (!customer.getFirstName().isEmpty()) {
					// if (visibilityOfElementLocated(firstName_OR))
					sendKeys(firstName_OR, firstName_S, customer.getFirstName());
				}
				if (!customer.getLastName().isEmpty()) {
					// if (visibilityOfElementLocated(lastName_OR))
					sendKeys(lastName_OR, lastName_S, customer.getLastName());
				}
				if (!customer.getMiddleName().isEmpty()) {
					// if (visibilityOfElementLocated(middleName_OR))
					sendKeys(middleName_OR, middleName_S, customer.getMiddleName());
				}
				if (!customer.getEmailId().isEmpty()) {
					// if (visibilityOfElementLocated(clinicContactEmail_OR))
					sendKeys(clinicContactEmail_OR, clinicContactEmail_S, customer.getEmailId());
				}
				if (!customer.getStateProvince().isEmpty()) { // Poojitha corrected the if condition Date: Dec 29th,
					// 2021
					if (isElementPresentwithoutException(stateProvinenceTextBox_OR, stateProvinenceTextBox_S)) {
						if (visibilityOfElementLocated(stateProvinenceTextBox_OR))
							clickElement(stateProvinenceTextBox_OR, stateProvinenceTextBox_S);
						elementToBeClickable(stateProvinenceSearchBox_OR);
						sendKeys(stateProvinenceSearchBox_OR, stateProvinenceTextBox_S, customer.getStateProvince());
						visibilityOfElementLocated(stateProvinceValue);
						clickElement(stateProvinceValue);
						invisibilityOfElementLocated(pageLoading);
					} else if (isElementPresentwithoutException(stateProvinceTextField_OR, stateProvinceTextField_S)) {
						sendKeys(stateProvinceTextField_OR, stateProvinceTextField_S, customer.getStateProvince());
					}
				}
				if (!customer.getClinicLanguage().isEmpty()) {
					// if (visibilityOfElementLocated(clinicLanguageField_OR))
					clickElement(clinicLanguageField_OR, clinicLanguageField_S);
					sendKeys(clinicLanguageSearchBox_OR, clinicLanguageSearchBox_S, customer.getClinicLanguage());
					visibilityOfElementLocated(clinicLanguageValue);
					clickElement(clinicLanguageValue);
				}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/*
	 * public Customer setNonUSCountryAndJurisdiction(Customer customer) { String
	 * existingCountryValue = getText(countryText_OR, countryText_S); String
	 * existingLegalJurisdictionValue = getText(legalJurisdictionText_OR,
	 * legalJurisdictionText_S);
	 */
	public Customer setNonUSCountryAndJurisdiction(Customer customer) {
		String existingCountryValue = getText(countryText);
		String existingLegalJurisdictionValue = getText(legalJurisdictionText);

		if (existingCountryValue.equalsIgnoreCase("Greece")) {
			customer.setCountry("Japan");
		} else if (existingCountryValue.equalsIgnoreCase("Japan")) {
			customer.setCountry("Greece");
		} else if (!existingCountryValue.equalsIgnoreCase("Japan")
				&& !existingCountryValue.equalsIgnoreCase("Greece")) {
			customer.setCountry("Japan");
		}

		if (existingLegalJurisdictionValue.equalsIgnoreCase("Europe")) {
			customer.setLegalJurisdiction("Japan");
		} else if (existingLegalJurisdictionValue.equalsIgnoreCase("Japan")) {
			customer.setLegalJurisdiction("Europe");
		} else if (!existingLegalJurisdictionValue.equalsIgnoreCase("Japan")
				&& !existingLegalJurisdictionValue.equalsIgnoreCase("Europe")) {
			customer.setLegalJurisdiction("Japan");
		}

		return customer;
	}

	public String changeCustomerPageElementvalidation(By locator, String locatorText, String Message)
			throws InterruptedException {
		String content = "";
		try {
			System.out.println(locatorText);
			if (isElementPresent(locator)) {
				scrollToView(locator);
				if (locatorText.contains("value")) {
					content = getAttribute(locator, "value");
					if (!content.isEmpty()) {
						extentReport.info(Message + " is Displayed as " + content);
					} else {
						extentReport.info(Message + " is Displayed and blank " + content);
					}
				} else if (locatorText.contains("Checkbox")) {
					content = getAttribute(locator, "aria-checked");
					if (content.equals("false")) {
						extentReport.info(Message + " is  not Selected ");
					} else {
						extentReport.info(Message + " is  Selected ");
					}
				}

				else if (locatorText.contains("Dropdown")) {
					content = getText(locator);
					if (content != null) {
						extentReport.info(Message + " is  Displayed as " + content);
					}
				} else if (locatorText.contains("Text")) {
					content = getText(locator);
					extentReport.info(Message + " is Displayed as " + content);
				}
			} else {
				content = null;
				extentReport.info(Message + " is  Displayed as Blank ");
			}
		} catch (Exception e) {
			content = null;
			extentReport.info(Message + " is  Displayed as Blank ");
		}
		return content;

	}

	// public String changeCustomerField(Customer customer,String FieldName) throws
	// Exception {
	public String changeCustomerFieldValidation(String FieldName) throws Exception {
		// By countryValue = By.xpath("//mat-option/span[contains(text(),'" +
		// customer.getCountry() + "')]");
		String value = "";
		Boolean prepop = false;
		try {
			switch (FieldName) {
			case "CustomerName":
				value = changeCustomerPageElementvalidation(customerName, "value", "Customer Name Textbox");
				if (visibilityOfElementLocated(customerName))
					scrollToView(customerName);
				if (!value.isEmpty()) {
					prepop = true;
				}
				break;
			case "CustomerType":
				value = changeCustomerPageElementvalidation(customerTypeDropDown, "value", "Customer Type Dropdown");
				if (visibilityOfElementLocated(customerTypeDropDown))
					scrollToView(customerTypeDropDown);
				if (!value.isEmpty()) {
					prepop = true;
				}
				break;

			case "ClinicLocation":
				value = changeCustomerPageElementvalidation(clinicLocation, "value", "ClinicLocation Textbox");
				if (visibilityOfElementLocated(clinicLocation))
					scrollToView(clinicLocation);
				if (!value.isEmpty()) {
					prepop = true;
				}
				if (visibilityOfElementLocated(clinicLocation))
					// sendKeys(clinicLocation, customer.getClinicLocation());
					break;
			case "MainPhone":
				// value = customerPageElementvalidation(mainPhoneText, "value", "Main Phone
				// Textbox");
				break;
			case "CountryCode":
				// value = customerPageElementvalidation(countryCodeText, "value", "Country Code
				// Textbox");

				/*
				 * if (!customer.getCountry().isEmpty()) { if
				 * (visibilityOfElementLocated(country)) scrollToView(country);
				 * clickElement(country); sendKeys(countrySearchBox,customer.getCountry());
				 * visibilityOfElementLocated(countryValue); clickElement(countryValue); }
				 */
				break;
			case "AreaCode":
				// value = customerPageElementvalidation(areaCodeText, "value", "Area Code
				// Textbox");
				break;
			case "Address1":
				// value = customerPageElementvalidation(address1Text, "value", "address
				// Textbox");
				break;
			case "Address2":
				// value = customerPageElementvalidation(address2Text, "value", "address
				// Textbox");
				break;
			case "Address3":
				// value = customerPageElementvalidation(address3Text, "value", "address
				// Textbox");
				break;
			case "City":
				// value = customerPageElementvalidation(cityText, "value", " city Textbox");
				break;
			case "ClinicLanguage":
				// value = customerPageElementvalidation(clinicLanguageDropdown,
				// "clinicLanguageDropdown"," clinic Language Dropdown");
			case "FaxCountryCode":
				// value = customerPageElementvalidation(faxCountryCodeText, "value", "Country
				// Code Textbox");
				break;
			case "FaxAreaCode":
				// value = customerPageElementvalidation(faxAreaCodeText, "value", "Area Code
				// Textbox");
				break;
			case "State/Prov":
				// value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown",
				// " state/Prov Dropdown");
				break;
			case "Country":
				if (visibilityOfElementLocated(country))
					// scrollUp();
					scrollToView(country);
				clickElement(country);
				// sendKeys(countrySearchBox,customer.getCountry());
				// visibilityOfElementLocated(countryValue);
				// clickElement(countryValue);
				// value = customerPageElementvalidation(countryDropdwon, "countryDropdwon", "
				// country Dropdwon");
				break;
			case "Zip/PostalCode":
				// value = customerPageElementvalidation(zipPostalcodeText, "value", "
				// zipPostalcode Textbox");
				break;
			case "SecondaryPhone":
				// value = customerPageElementvalidation(secondaryPhoneText, "value", "
				// secondary Phone Textbox");
				break;
			case "Fax":
				// value = customerPageElementvalidation(faxText, "value", " fax Textbox");
				break;
			case "ClinicTimeZone":
				// value = customerPageElementvalidation(clinicTimeZoneDropdown,
				// "clinicTimeZoneDropdown", " clinicTimeZone Dropdown");
				break;
			case "TextMessage":
				// value = customerPageElementvalidation(textMessageText, "value", " textMessage
				// Textbox");
				break;
			case "LegalJurisdiction":
				// value = customerPageElementvalidation(legalJurisdictionDropdown,
				// "legalJurisdictionDropdown"," legal Jurisdiction Dropdown");
				break;
			case "Email":
				// value = customerPageElementvalidation(emailText, "value", " email Textbox");
				break;
			case "MiddleName":
				// value = customerPageElementvalidation(middlenameText, "value", "Middle name
				// Textbox");
				break;
			case "LastName":
				// value = customerPageElementvalidation(lastNameText, "value", "Middle name
				// Textbox");
				break;
			case "UserID":
				// value = customerPageElementvalidation(userIDText, "value", "Main user ID");
				break;
			case "FirstName":
				// value = customerPageElementvalidation(firstNameText, "value", "first Name
				// Textbox");
				break;
			case "MainContactEmail":
				// value = customerPageElementvalidation(mainEmailText, "value", "Main Email
				// Textbox");
				break;

			case "Credentials":
				// value = customerPageElementvalidation(credentialsText, "value", "credentials
				// Textbox");
				break;

			case "CustomerOnDemandCheckbox":
				// value = customerPageElementvalidation(merlinOnDemandCheckbox,
				// "merlinOnDemandCheckbox"," merlin OnDemand Checkbox");
				break;
			case "CustomerTestClinic":
				// value = customerPageElementvalidation(testClinicCheckbox,
				// "testClinicCheckbox", " test Clinic Checkbox");
				break;

			case "CustomerUnpaired":
				// value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox",
				// "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				// value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert
				// Checkbox");
				break;
			case "CustomerSendTextMessage":
				// value = customerPageElementvalidation(sendtextmessagesCheckbox,
				// "sendtextmessagesCheckbox","Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				// value = customerPageElementvalidation(sendvoicemessagesCheckbox,
				// "sendvoicemessagesCheckbox","SendvoicemessagesCheckbox");
				break;

			}

			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void changeCustomerFieldValue(String fieldName, String fieldValue, boolean confirmSave) throws Exception {
		this.extentTest = ExtentReport.node;
		By countryValue = By.xpath("//mat-option/span[contains(text(),'" + fieldValue + "')]");
		By legalJurisdictionValue = By.xpath("//mat-option/span[contains(text(),'" + fieldValue + "')]");
		try {
			switch (fieldName) {
			case "ClinicLocation":
				if (fieldName.equalsIgnoreCase("ClinicLocation")) {
					waitForLoading();
					waitForLoading();
					clickElement(clinicLocation_OR);
					if (visibilityOfElementLocated(clinicLocation_OR))
						sendKeys(clinicLocation_OR, fieldValue);
				}
				break;

			case "Country":
				if (fieldName.equalsIgnoreCase("Country")) {
					waitForLoading();
					scrollToView(country);
					waitForLoading();
					waitForLoading();
					clickElement(country);
					waitForLoading();
					waitForLoading();
					sendKeys(countrySearchBox, fieldValue);
					//waitForLoading();
					waitForLoading();
					visibilityOfElementLocated(countryValue);
					clickElement(countryValue);
				}
				break;

			case "ZipPostalcode":
				if (fieldName.equalsIgnoreCase("zipPostalcode")) {
					scrollToView(zipPostalCode);
					waitForLoading();
					sendKeys(zipPostalCode, fieldValue);
				}
				break;

			case "legalJurisdiction":

				if (visibilityOfElementLocated(legalJurisdiction)) {
					scrollToView(legalJurisdiction);
					clickElement(legalJurisdiction);
					sendKeys(legalJurisdiction, fieldValue);
					clickElement(legalJurisdiction);
					clickOnElementUsingJs(legalJurisdictionValue);
				}
				break;
			}
			extentReport.reportScreenShot(fieldName + " updated with " + fieldValue);

			if (confirmSave) {
				waitForLoading();
				clickSaveButton();
				waitForLoading();
				clickOKButton();
				waitForLoading();
				waitForLoading();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public String updateAndgetPostalCode(String fieldValue) throws Exception {
		clearElement("ZipPostalCode");
		changeCustomerFieldValue("ZipPostalcode", fieldValue, false);
		String UpdatedPostCode = getPostalCode();
		extentReport.reportScreenShot("Attempted ZipPostalCode is " + fieldValue
				+ " and Actual Entered /reflected value is   " + UpdatedPostCode);
		return UpdatedPostCode;
	}

	public void changeCustomerClinic(Customer customer) throws Exception {
		By customerTypeValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getCustomerType() + "')]");
		By clinicLanguageValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getClinicLanguage() + "')]");
		By countryValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getCountry() + "')]");
		By clinicTimeZoneValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getClinicTimeZone() + "')]");
		By legalJurisdictionValue = By
				.xpath("//mat-option/span[contains(text(),'" + customer.getLegalJurisdiction() + "')]");
		By stateProvinceValue = By.xpath("//mat-option/span[contains(text(),'" + customer.getStateProvince() + "')]");

		try {
			// if (verifyLandingPage()) {
			scrollUp();
			/*
			 * if (!customer.getCustomerName().isEmpty()) { if
			 * (visibilityOfElementLocated(customerName)) clickElement(customerName);
			 * sendKeys(customerName, customer.getCustomerName()); } if
			 * (!customer.getCustomerType().isEmpty()) { if
			 * (visibilityOfElementLocated(customerTypeDropDown))
			 * clickElement(customerTypeDropDown); clickElement(customerTypeValue); }
			 */
			// if (!customer.getClinicLocation().isEmpty()) {
			if (visibilityOfElementLocated(clinicLocation))
				sendKeys(clinicLocation, customer.getClinicLocation());
			// }
			/*
			 * if (!customer.getCountryCode().isEmpty()) { if
			 * (visibilityOfElementLocated(countryCode)) sendKeys(countryCode,
			 * customer.getCountryCode()); } if (!customer.getAreaCode().isEmpty()) { if
			 * (visibilityOfElementLocated(areaCode)) sendKeys(areaCode,
			 * customer.getAreaCode()); } if (!customer.getMainPhone().isEmpty()) { if
			 * (visibilityOfElementLocated(mainPhone)) sendKeys(mainPhone,
			 * customer.getMainPhone()); } if (!customer.getAddress1().isEmpty()) { if
			 * (visibilityOfElementLocated(address_1)) sendKeys(address_1,
			 * customer.getAddress1()); } if (!customer.getAddress2().isEmpty()) { if
			 * (visibilityOfElementLocated(address_2)) sendKeys(address_2,
			 * customer.getAddress2()); } if (!customer.getAddress3().isEmpty()) { if
			 * (visibilityOfElementLocated(address_3)) sendKeys(address_3,
			 * customer.getAddress3()); } if (!customer.getCountry().isEmpty()) { if
			 * (visibilityOfElementLocated(country)) clickElement(country);
			 * sendKeys(countrySearchBox,customer.getCountry());
			 * visibilityOfElementLocated(countryValue); clickElement(countryValue); } if
			 * (!customer.getEmail().isEmpty()) { if
			 * (visibilityOfElementLocated(clinicEmail)) sendKeys(clinicEmail,
			 * customer.getEmail()); } if (!customer.getClinicTimeZone().isEmpty()) { if
			 * (visibilityOfElementLocated(clinicTimeZone)) clickElement(clinicTimeZone);
			 * clickElement(clinicTimeZoneValue); } if (!customer.getCity().isEmpty()) { if
			 * (visibilityOfElementLocated(city)) clickElement(city); sendKeys(city,
			 * customer.getCity()); } if (!customer.getLegalJurisdiction().isEmpty()) { if
			 * (visibilityOfElementLocated(legalJurisdiction))
			 * clickElement(legalJurisdiction);
			 * clickOnElementUsingJs(legalJurisdictionValue); } if
			 * (!customer.getFirstName().isEmpty()) { if
			 * (visibilityOfElementLocated(firstName)) sendKeys(firstName,
			 * customer.getFirstName()); } if (!customer.getLastName().isEmpty()) { if
			 * (visibilityOfElementLocated(lastName)) sendKeys(lastName,
			 * customer.getLastName()); } if (!customer.getMiddleName().isEmpty()) { if
			 * (visibilityOfElementLocated(middleName)) sendKeys(middleName,
			 * customer.getMiddleName()); } if (!customer.getEmailId().isEmpty()) { if
			 * (visibilityOfElementLocated(clinicContactEmail)) sendKeys(clinicContactEmail,
			 * customer.getEmailId()); } if (!customer.getStateProvince().isEmpty()) { if
			 * (visibilityOfElementLocated(stateProvinceDropDown))
			 * clickElement(stateProvinceDropDown);
			 * clickOnElementUsingJs(stateProvinceValue); } if
			 * (!customer.getClinicLanguage().isEmpty()) { if
			 * (visibilityOfElementLocated(clinicLanguageField))
			 * clickElement(clinicLanguageField);
			 * sendKeys(clinicLanguageSearchBox,customer.getClinicLanguage());
			 * visibilityOfElementLocated(clinicLanguageValue);
			 * clickElement(clinicLanguageValue); }
			 */

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * method to get allowed clinical trals from change customer page
	 * 
	 * @return - Will return the list of allowed clinical trails
	 * 
	 */
	public List<WebElement> getAllowedClinicalTrails() {
		List<WebElement> options = getOptions(allowedClinicalTrailSection);
		return options;
	}

	public void closeErrorPopUp() throws InterruptedException {
		if (visibilityOfElementLocated(closeMandatoryErrorPopUp)) {
			waitForElementToBeClickable(closeMandatoryErrorPopUp);
			clickElement(closeMandatoryErrorPopUp);
			waitForLoading();
			waitForPageLoad();
		}
	}

	/**
	 * Method to click Save button in change customer page
	 * 
	 */
	public void clickSaveButton() throws Exception {
		if (visibilityOfElementLocatedWithoutReport(saveButton_OR, saveButton_S)) {
			// elementToBeClickable(saveButton_OR);
			extentReport.reportScreenShot("User click on Save Button");
			clickElement(saveButton_OR, saveButton_S);
		}
	}

	public void validateAndDeleteCustomer() throws Exception {
		clickElement(deleteCustomer_Button_OR, deleteCustomer_Button_S);
		presenceOfElementLocatedWithReport(deleteCustomer_Button_OR, deleteCustomer_Button_S);

	}

	public void scrollToDelChngBtnCustProfilePg() {
		scrollToViewWithReport(deleteCustomer_Button_OR, deleteCustomer_Button_S);
	}

	public void captureandVerifyDeleteMessagePopUpAD800(String username) {
		// clickElement(deleteCustomer_Button_OR, deleteCustomer_Button_S);
		presenceOfElementLocatedWithReport(popUpDeleteLine1_OR, popUpDeleteLine1_S);
		presenceOfElementLocatedWithReport(popUpDeleteLine2, popUpDeleteLine2_S);
		String line1 = getText(popUpDeleteLine1_OR, popUpDeleteLine1_S);
		String line2 = getText(popUpDeleteLine2, popUpDeleteLine2_S);
		String expectedLine1 = "I'm ready to delete " + username + " for you.";
		String expectedLine2 = "Shall I go ahead?";
		Assert.assertEquals(line1 + line2, expectedLine1 + expectedLine2, "Pop up Message  verified Successfully");

	}

	public void captureandVerifyDeleteMessagePopUpAD802() {
		// clickElement(deleteCustomer_Button_OR, deleteCustomer_Button_S);
		presenceOfElementLocatedWithReport(popUpDeleteLine1_OR, popUpDeleteLine1_S);
		String actualMessage = getText(popUpDeleteLine1_OR, popUpDeleteLine1_S);
		String expectedMessage = "Your customer will be deleted.";
		Assert.assertEquals(actualMessage, expectedMessage, "Pop up Message  verified Successfully");
		extentReport.reportScreenShot("Popup message is validate for delete flow.");

	}

	public void AcceptDeletePopUp() {
		clickElement(okButtondeletePopUp_OR, okButtondeletePopUp_S);
	}

	/**
	 * Method to click OK button in Alert Popup
	 * 
	 */
	public void clickOKButton() throws Exception {
		extentReport.reportScreenShot("User click on Ok Button");
		clickElement(okButton_OR, okButton_S);
	}

	/**
	 * Method to savePositiveChanges in change customer page
	 */
	public void savePositiveChanges() throws Exception {
		try {
			clickSaveButton();
			clickOKButton();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Method to click Cancel button in change customer page
	 * 
	 */
	public void clickCancelButton() throws Exception {
		try {
			if (visibilityOfElementLocated(cancelButton)) {
				extentReport.reportScreenShot("Cancel Button is displayed");
				clickElement(cancelButton);
				extentReport.reportScreenShot("User clicked on Cancel Button");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickPopUpCancelButton() throws Exception {
		if (visibilityOfElementLocatedWithoutReport(popUpCancelButton_OR, popUpCancelButton_S)) {
			clickElement(popUpCancelButton_OR, popUpCancelButton_S);
			extentReport.reportScreenShot("User clicked on Cancel Button");
		}
	}

	/**
	 * method to verify application feature section
	 * 
	 */
	public void applicationFeatureControlVerification(Customer customer) throws InterruptedException {
		
		By exportToEHRValue_OR = exportToEHRValue_OR(customer.getElecExport());
			if (!customer.getExportTransmissionData().isEmpty()) {
				if (visibilityOfElementLocated(exportTransmission_OR))
					if (waitForElementToBeClickable(exportTransmission_OR))
						if (customer.getExportTransmissionData().equalsIgnoreCase("Yes")) {
							if (getAttributeWithReport(exportTransmission_OR, "aria-checked", exportTransmission_S).equalsIgnoreCase("false"))
								clickElement(exportTransmissionCheckBox_OR, exportTransmissionCheckBox_S);
						} else if (customer.getExportTransmissionData().equalsIgnoreCase("No")) {
							if (getAttributeWithReport(exportTransmission_OR, "aria-checked", exportTransmission_S).equalsIgnoreCase("true"))
								clickElement(exportTransmissionCheckBox_OR, exportTransmissionCheckBox_S);
						}
			}
			if (!customer.getOrderTransmitter().isEmpty()) {
				if (visibilityOfElementLocated(orderTransmitter_OR))
					if (waitForElementToBeClickable(orderTransmitter_OR))
						if (customer.getOrderTransmitter().equalsIgnoreCase("Yes")) {
							if (getAttributeWithReport(orderTransmitter_OR, "aria-checked", orderTransmitter_S).equalsIgnoreCase("false"))
								clickElement(orderTransmitterCheckBox_OR, orderTransmitterCheckBox_S);
						} else if (customer.getOrderTransmitter().equalsIgnoreCase("No")) {
							if (getAttributeWithReport(orderTransmitter_OR, "aria-checked", orderTransmitter_S).equalsIgnoreCase("true"))
								clickElement(orderTransmitterCheckBox_OR, orderTransmitterCheckBox_S);
						}
			}
			if (!customer.getElecExport().isEmpty()) {
				if (visibilityOfElementLocated(exportToEHRDropDown_OR))
					if (waitForElementToBeClickable(exportToEHRDropDown_OR)) {
						clickElement(exportToEHRDropDown_OR, exportToEHRDropDown_S);
						clickElement(exportToEHRValue_OR);
					}
			}
			visibilityOfElementLocated(applicationControlSection_OR);
			scrollToView(applicationControlSection_OR);
			extentReport.reportScreenShot("Application Feature Control details are updated");
		}

	/**
	 * method to get Export to EHR drop down values
	 * 
	 */
	public List<String> getExportToEHROptions() throws InterruptedException {
		if (visibilityOfElementLocated(exportToEHRDropDown_OR))
			if (waitForElementToBeClickable(exportToEHRDropDown_OR)) {
				clickElement(exportToEHRDropDown_OR, exportToEHRDropDown_S);
			}

		List<WebElement> optionsElements = findElements(exportToEHRDropDownOptions);
		
		List<String> actualOptions = new ArrayList<String>();
		actualOptions.add(optionsElements.get(0).getText().trim());
		actualOptions.add(optionsElements.get(1).getText().trim());
		actualOptions.add(optionsElements.get(2).getText().trim());
		clickElement(exportToEHRDropDownOption_OR, exportToEHRDropDownOption_S);
		System.out.println("@@@" + actualOptions);
		return actualOptions;
	}

	public void EHRDropdownSelectoption(String option) throws InterruptedException {
		String defaultValue = "No Export";
		// getText(exportToEHRDropDownvalue);
		System.out.println(defaultValue);

		// mat-select[@id="dd_customer-feature-control_exportEHRTypeCd"]
		// List<WebElement> optionsElements = findElements(exportToEHRDropDownOptions);

		// List<String> actualOptions = new ArrayList<String>();

		// actualOptions.add(optionsElements.get(0).getText().trim());

		if (defaultValue.trim().equals(option.trim())) {
			clickElement(dropdown);
			clickElement(exportToEHRDropDownManual);
		} else {
			clickElement(dropdown);
			clickElement(exportToEHRDropDownNoexport);
		}

	}

	/**
	 * method to get allowed applications
	 * 
	 */
	public String getAllowedApplications() {
		String value = "";
		List<WebElement> allowedApplicationsList;
		if (visibilityOfElementLocated(allowedApplications_OR)) {
			presenceOfElementLocated(allowedApplications_OR);
			allowedApplicationsList = getOptions(allowedApplications_OR);
			for (int a = 0; a < allowedApplicationsList.size(); a++) {
				JsonObject jsonObject = new JsonParser().parse(allowedApplicationsList.get(a).getAttribute("value"))
						.getAsJsonObject();
				value = jsonObject.get("codeDesc").getAsString();
			}
		}
		return value;
	}

	/**
	 * method to verify dynamic components
	 *
	 */
	public void dynamicComponentsVerification(Customer customer) throws InterruptedException {
		if (!customer.getRecordPatientDataCollection().isEmpty()) {
			if (visibilityOfElementLocated(recordPatientDataCollection_OR))
				if (waitForElementToBeClickable(recordPatientDataCollection_OR))
					if (customer.getRecordPatientDataCollection().equalsIgnoreCase("Yes")) {
						if (getAttribute(recordPatientDataCollection_OR, "aria-checked").equalsIgnoreCase("false"))							
							clickElement(recordPatientDataCollectionChkBox_OR, recordPatientDataCollectionChkBox_S);
					}else if (customer.getRecordPatientDataCollection().equalsIgnoreCase("No")) {
						if (getAttribute(recordPatientDataCollection_OR, "aria-checked").equalsIgnoreCase("true"))
							clickElement(recordPatientDataCollectionChkBox_OR, recordPatientDataCollectionChkBox_S);
					}
		}
		if (!customer.getAllowMobileDirectAlert().isEmpty()) {
			if (visibilityOfElementLocated(allowSmartAlert_OR))
				if (waitForElementToBeClickable(allowSmartAlertChkBox_OR))
					if (customer.getAllowMobileDirectAlert().equalsIgnoreCase("Yes")) {
						if (getAttribute(allowSmartAlert_OR, "aria-checked").equalsIgnoreCase("false"))							
							clickElement(allowSmartAlertChkBox_OR, allowSmartAlertChkBox_S);
					}else if (customer.getAllowMobileDirectAlert().equalsIgnoreCase("No")) {
						if (getAttribute(allowSmartAlert_OR, "aria-checked").equalsIgnoreCase("true"))
							clickElement(allowSmartAlertChkBox_OR, allowSmartAlertChkBox_S);
					}
		}
		if (!customer.getAllowVoiceMessage().isEmpty()) {
			if (visibilityOfElementLocated(allowDirectCallVoice_OR))
				if (waitForElementToBeClickable(allowDirectCallVoiceCB_OR))
					if (customer.getAllowVoiceMessage().equalsIgnoreCase("Yes")) {
						if (getAttribute(allowDirectCallVoice_OR, "aria-checked").equalsIgnoreCase("false"))							
							clickElement(allowDirectCallVoiceCB_OR, allowDirectCallVoiceCB_S);
					}else if (customer.getAllowVoiceMessage().equalsIgnoreCase("No")) {
						if (getAttribute(allowDirectCallVoice_OR, "aria-checked").equalsIgnoreCase("true"))
							clickElement(allowDirectCallVoiceCB_OR, allowDirectCallVoiceCB_S);
					}
		}
		if (!customer.getAllowTextMessage().isEmpty()) {
			if (visibilityOfElementLocated(allowDirectCallText))
				if (waitForElementToBeClickable(allowDirectCallTextCB_OR))
					if (customer.getAllowTextMessage().equalsIgnoreCase("Yes")) {
						if (getAttribute(allowDirectCallText, "aria-checked").equalsIgnoreCase("false"))							
							clickElement(allowDirectCallTextCB_OR, allowDirectCallTextCB_S);
					}else if (customer.getAllowTextMessage().equalsIgnoreCase("No")) {
						if (getAttribute(allowDirectCallText, "aria-checked").equalsIgnoreCase("true"))
							clickElement(allowDirectCallTextCB_OR, allowDirectCallTextCB_S);
					}
		}
		scrollToView(generalFeaturesSection);
		extentReport.reportScreenShot("General Features and Allow Direct call features are updated");

	}

	/**
	 * method to verify Remove Application Button
	 */
	public void verifyRemoveApplicationButton() {
		if (visibilityOfElementLocated(removeEPApplicationButton)) {
			extentReport.reportPass(
					"Remove link is not displayed restricting the actor from subsequently removing Customer access/authorization to an Application");
		}
	}

	/**
	 * method to get Error Message
	 */
	public String getErrorMessage(String fieldName) {
		String error = null;
		switch (fieldName) {
		case "CustomerName":
			error = getText(customerNameInvalidError);
			break;
		case "ClinicLocation":
			error = getText(clinicLocationInvalidError);
			break;
		case "MainPhone":
			error = getText(mainPhoneInvalidError);
			break;
		case "Email":
			error = getText(emailInvalidError);
			scrollToView(clinicEmail);
			break;
		case "AreaCode":
			error = getText(areaCodeInvalidError);
			break;
		case "CountryCode":
			error = getText(countryCodeInvalidError);
			break;
		}
		return error;
	}

	public void clearElement(String fieldName) {
		switch (fieldName) {
		case "CustomerName":
			deleteContent(customerName);
			break;
		case "ClinicLocation":
			deleteContent(clinicLocation);
			break;
		case "MainPhone":
			deleteContent(mainPhone);
			break;
		case "Email":
			deleteContent(clinicEmail);
			break;
		case "AreaCode":
			deleteContent(areaCode);
			break;
		case "CountryCode":
			deleteContent(countryCode);
			break;
		case "ZipPostalCode":
			deleteContent(zipPostalCode);
			break;
		}
	}

	public void clearElementInChangeCustomer(String fieldName) throws InterruptedException {
		switch (fieldName) {
		case "CustomerName":
			deleteContent(customerName);
			break;
		case "ClinicLocation":
			deleteContent(clinicLocation);
			break;
		case "MainPhone":
			deleteContent(mainPhone);
			break;
		case "Email":
			deleteContent(clinicEmail);
			break;
		case "AreaCode":
			deleteContent(areaCode);
			break;
		case "CountryCode":
			deleteContent(countryCode);
			break;
		case "ZipPostalCode":
			deleteContent(zipPostalCode);
			break;
		}
		waitForLoading();
		extentReport.reportScreenShot("Deleted the data entered in " + fieldName);
	}

	/**
	 * Method to click LegalJuridictionPopUp Ok button in change customer page
	 * 
	 */
	public void LegalJuridictionPopUp() throws Exception {
		try {
			waitForLoading();
			waitForLoading();
			waitForLoading();
			if (isDisplayedFlag(expectedLegalJuridiction)) {
				clickElement(expectedLegalJuridiction);
				savePositiveChanges();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void selectLegalJurisdiction(String legalJurisdictionVal) throws Exception {
		waitForPageLoad();
		waitForPageLoad();
		waitForLoading();
		if (isDisplayedFlag(okButton_OR)) {
			clickElement(okButton_OR);
			waitForLoading();
			waitForPageLoad();
		}
		waitForLoading();
		waitForLoading();
		if (isDisplayedFlag(closeMandatoryErrorPopUp)) {
			waitForElementToBeClickable(closeMandatoryErrorPopUp);
			clickElement(closeMandatoryErrorPopUp);
			waitForLoading();
			waitForPageLoad();
		}
		String MatchedlegalJurisdictionValue = null;
		//if (isDisplayedFlag(legalJurisdictionWarning)) {
		clickElement(legalJurisdiction);
		waitForLoading();
		waitForPageLoad();
		List<WebElement> legalJurisdictionValueList = findElementslist(legalJurisdictionValues);
		for (int i = 0; i < legalJurisdictionValueList.size(); i++) {
			if (legalJurisdictionVal.equalsIgnoreCase(legalJurisdictionValueList.get(i).getText())) {
				MatchedlegalJurisdictionValue = legalJurisdictionValueList.get(i).getText();
				legalJurisdictionValueList.get(i).click();
				System.out.println("MatchedlegalJurisdictionValue is --->" + MatchedlegalJurisdictionValue);
				waitForLoading();
				waitForPageLoad();
				savePositiveChanges();
				LegalJuridictionPopUp();
				extentReport
				.reportScreenShot("LegalJurisdictionValue updated with " + MatchedlegalJurisdictionValue);
				break;
			}
		}
		//}
	}

	/**
	 * method to checkbox value
	 * 
	 * @throws InterruptedException
	 * 
	 */
	public boolean getCheckboxvalue(By locator, String attribute) throws InterruptedException {
		String check = getAttribute(locator, attribute);
		boolean checkb = Boolean.parseBoolean(check);
		return checkb;

	}

	public void changeCountry(String country, String legalJurisdiction) throws Exception {
		if (country.equalsIgnoreCase("USA")) {
			changeCustomerFieldValue("Country", "USA", true);
		} else {
			changeCustomerFieldValue("Country", country, false);
			Thread.sleep(3000);
			selectLegalJurisdiction(legalJurisdiction);
		}
	}



	public String validatePostalCode(String postalCode) throws Exception {
		return CommonUtils.extractIntAndChar(postalCode, 'e');
	}

	// Author: Poojitha - Added few more methods

	// This method is to validate whether the fields are editable or not
	public boolean validateEditableFields(String fieldName) throws Exception {
		boolean enabledFieldValue = false;
		try {
			switch (fieldName) {
			case "CustomerName":
				enabledFieldValue = isEnabledWithoutReport(customerName_OR, customerName_S);
				break;
			case "CustomerType":
				enabledFieldValue = isEnabledWithoutReport(customerTypeDropDown_OR, customerTypeDropDown_S);
				break;
			case "ClinicLocation":
				enabledFieldValue = isEnabledWithoutReport(clinicLocation_OR, clinicLocation_S);
				break;
			case "MainPhone":
				enabledFieldValue = isEnabledWithoutReport(mainPhone_OR, mainPhone_S);
				break;
			case "CountryCode":
				enabledFieldValue = isEnabledWithoutReport(countryCode_OR, countryCode_S);
				break;
			case "AreaCode":
				enabledFieldValue = isEnabledWithoutReport(areaCode_OR, areaCode_S);
				break;
			case "Address1":
				enabledFieldValue = isEnabledWithoutReport(address_1_OR, address_1_S);
				break;
			case "Address2":
				enabledFieldValue = isEnabledWithoutReport(address_2_OR, address_2_S);
				break;
			case "Address3":
				enabledFieldValue = isEnabledWithoutReport(address_3_OR, address_3_S);
				break;
			case "City":
				enabledFieldValue = isEnabledWithoutReport(city_OR, city_S);
				break;
			case "ClinicLanguage":
				enabledFieldValue = isEnabledWithoutReport(clinicLanguageField_OR, clinicLanguageField_S);
				break;
			case "ClinicTimeZone":
				enabledFieldValue = isEnabledWithoutReport(clinicTimeZone_OR, clinicTimeZone_S);
				break;
			case "ClinicEmail":
				enabledFieldValue = isEnabledWithoutReport(clinicEmail_OR, clinicEmail_S);
				break;
			case "Country":
				enabledFieldValue = isEnabledWithoutReport(country_OR, country_S);
				break;
			case "CountryText":
				enabledFieldValue = isEnabledWithoutReport(countryText_OR, countryText_S);
				break;
			case "Zip/PostalCode":
				enabledFieldValue = isEnabledWithoutReport(zipPostalCode_OR, zipPostalCode_S);
				break;
			case "LegalJurisdiction":
				enabledFieldValue = isEnabledWithoutReport(legalJurisdictionText_OR, customerName_S);
				break;
			case "ClinicContactEmail":
				enabledFieldValue = isEnabledWithoutReport(clinicContactEmail_OR, clinicContactEmail_S);
				break;
			case "StateProvinence":
				enabledFieldValue = isEnabledWithoutReport(stateProvinenceTextBox_OR, stateProvinenceTextBox_S);
				break;
			case "UserId":
				enabledFieldValue = isEnabledWithoutReport(userId_OR, userId_S);
				break;
			case "FirstName":
				enabledFieldValue = isEnabledWithoutReport(firstName_OR, firstName_S);
				break;
			case "MiddleName":
				enabledFieldValue = isEnabledWithoutReport(middleName_OR, middleName_S);
				break;
			case "LastName":
				enabledFieldValue = isEnabledWithoutReport(lastName_OR, lastName_S);
				break;
			case "ActivatorClinicCheckBox":
				enabledFieldValue = isEnabledWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
				break;		
			}
			return enabledFieldValue;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	// This method is to validate Remove button is not present in Direct Alerts for
	// Patients section
	public boolean validationOfAccessPreventionPatientsAlerts() {
		return isElementNotPresentWithoutReport(removedirectAlertsForPatientsButton_OR,
				removedirectAlertsForPatientsButton_S);
	}

	// This method is to validate Remove button is present in ElectroPhysiology
	// Alerts section
	public boolean validationOfAllowedAlerts() {
		return isElementPresent(removeAllowedElectroPhysiologyButton_OR, removeAllowedElectroPhysiologyButton_S);

	}

	public ArrayList<String> getJurisdictionAlerts(List<WebElement> options, By locator) {
		extentReport.reportScreenShot("List of Alerts groups displayed");
		String attrVal = "codeDesc";
		if (locator.equals(availableDevices_Select_OR) || locator.equals(allowedDevices_Select_OR)) {
			attrVal = "deviceModelNum";
		}
		ArrayList<String> jurisdictionAlerts = new ArrayList<String>();
		for (int a = 0; a < options.size(); a++) {
			JsonObject jsonObject = new JsonParser().parse(options.get(a).getAttribute("value")).getAsJsonObject();
			String value = jsonObject.get(attrVal).getAsString();
			jurisdictionAlerts.add(value);
		}
		return jurisdictionAlerts;
	}

	public String getLegalJurisdictionValue() {
		scrollToView(legalJurisdiction);
		String JurisdictionVal = getText(legalJurisdiction);
		extentReport.reportScreenShot("Legal Jurisdiction = " + JurisdictionVal);
		return JurisdictionVal;
	}

	public void jurisdictionAlertValidation(String locaterName) throws IOException {
		By locator = null;
		String sheetName = "";
		String jurisdiction = getLegalJurisdictionValue();
		if (jurisdiction.equalsIgnoreCase("United States")) {
			extentReport.pass("Alert validation for United States");
		} else if (jurisdiction.equalsIgnoreCase("Japan")) {
			extentReport.pass("Alert validation for Japan");
		} else if (jurisdiction.equalsIgnoreCase("Canada")) {
			extentReport.pass("Alert validation for Canada");
		} else if (jurisdiction.equalsIgnoreCase("Europe")) {
			extentReport.pass("Alert validation for Europe");
		} else if (jurisdiction.equalsIgnoreCase("Australia/New Zealand")) {
			extentReport.pass("Alert validation for Australia/New Zealand");
		} else {
			extentReport.fail("Jurisdiction not matching");
		}

		if (locaterName.equals("availableEPDirectAlerts_Select_S")) {
			locator = availableEPDirectAlerts_Select_OR;
			sheetName = "US_EP_DirectAlerts_NonBT";
		} else if (locaterName.equals("allowedEPDirectAlerts_Select_S")) {
			locator = allowedEPDirectAlerts_Select_OR;
			sheetName = "US_EP_DirectAlerts_NonBT";
		} else if (locaterName.equals("availableDirectAlertsForPatients_Select_S")) {
			locator = availableDirectAlertsForPatients_Select_OR;
			sheetName = "US_DirectAlert_Non_bT";
		} else if (locaterName.equals("allowedDirectAlertsForPatients_Select_S")) {
			locator = allowedDirectAlertsForPatients_Select_OR;
			sheetName = "US_DirectAlert_Non_bT";
		} else if (locaterName.equals("availableDevices_Select_S")) {
			locator = availableDevices_Select_OR;
			sheetName = "ELECTROPHYSIOLOGY_device";
		} else if (locaterName.equals("allowedDevices_Select_S")) {
			locator = allowedDevices_Select_OR;
			sheetName = "ELECTROPHYSIOLOGY_device";
		} else {
			extentReport.fail("Alerts/Devices not found");
		}

		ArrayList<String> excelData = TestDataProvider.readJurisdictionAlerts(jurisdiction, sheetName);
		System.out.println("Data in excel is:" + excelData);

		ArrayList<String> appData = getJurisdictionAlerts(getOptions(locator), locator);
		System.out.println("Data in app is:" + appData);
		ArrayList<String> missedValue = new ArrayList<>();

		for (String value : appData) {
			if (!excelData.contains(value))
				missedValue.add(value);
		}
		System.out.println("missed values are:" + missedValue);
		if (missedValue.isEmpty()) {
			extentReport.pass("Jurisdiction Alert validation is completed successfully");
		} else {
			extentReport.fail("Jurisdiction Alert validation is not completed successfully");
		}
	}
	public boolean verifyActivatorClinicCheckBox()
	{
		boolean checkBox = false;
		scrollToViewWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
		if(isSelectedWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S))
			checkBox = true;
		return checkBox;
	}

	public void selectActivatorClinicCheckBox()
	{
		clickElement(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
	}

	public void clickOnAllAbbottCustomers()
	{
		clickElement(allAbbottCustomers_OR,allAbbottCustomers_S);
		isAlertPresent();
		acceptAlert();
	}

	// Ends Here
	// Poojitha - Updated Override method as per new standards - Date: 28th Dec 2021

	// ------------------ Jeetendra Added new method to get customer id
	// --------------------

	public String getCustomerId(String UserName) throws InterruptedException {
		userId = getAttribute(CustomerIdValue, "value");
		return userId;
	}
	/*
	 * public String getCustomerId(String UserName) throws InterruptedException {
	 * userId = getAttribute(CustomerIdValue,"value"); return userId; }
	 */
	/**
	 * Method to saveNegativeChanges in change customer page
	 *//*
	 * public void saveChanges() throws Exception { try { clickSaveButton();
	 * getSizeOfElements(okButton_OR,okButton_S); if
	 * (getSizeOfElements(okButton_OR,okButton_S)>0) { clickOKButton(); } else if
	 * (getSizeOfElements(mandateFieldWarningToaster_OR,
	 * mandateFieldWarningToaster_S)>0) { closeMandatoryWarningToaster(); }
	 */

	/**
	 * Method to saveNegativeChanges in change customer page
	 */

	public boolean  validateMandatoryToaster() throws Exception {
		boolean mandTosaterDisp=false;
		try {
			//clickSaveButton();
			if (visibilityOfElementLocatedWithoutReport(mandateFieldWarningToaster_OR, mandateFieldWarningToaster_S)){
				closeMandatoryWarningToaster();
				mandTosaterDisp=true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mandTosaterDisp;
	}


	public void saveChanges() throws Exception {
		try {
			clickSaveButton();
			// getSizeOfElements(okButton_OR,okButton_S);
			if (getSizeOfElements(okButton_OR, okButton_S) > 0) {
				clickOKButton();
			} else if (getSizeOfElements(mandateFieldWarningToaster_OR, mandateFieldWarningToaster_S) > 0) {
				closeMandatoryWarningToaster();
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Method to close Mandatory Field Warning Toaster Message in change customer
	 * page
	 * 
	 */
	public void closeMandatoryWarningToaster() throws Exception {
		if (visibilityOfElementLocatedWithoutReport(mandateFieldWarningToaster_OR, mandateFieldWarningToaster_S)) {
			// elementToBeClickable(saveButton_OR);
			extentReport.reportScreenShot("User closed Mandatory Field Warning Toaster Message");
			clickElement(mandateFieldWarningToaster_OR, mandateFieldWarningToaster_S);
		}
	}

	/**
	 * method to verify landing page
	 * 
	 */
	@Override
	public boolean verifyLandingPage() {
		Boolean changeCustomerProfilePageCheck = false;
		if (isElementPresentwithoutException(customerHeadquarterText_OR, customerHeadquarterText_S)) {
			changeCustomerProfilePageCheck = true;
			extentReport.reportScreenShot("Change Customer page is displayed");
		}
		return changeCustomerProfilePageCheck;

	}

}
