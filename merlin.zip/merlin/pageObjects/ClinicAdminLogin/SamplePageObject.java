
package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import org.openqa.selenium.WebDriver;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;

public class SamplePageObject extends BasePage {
	
	//Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	public static Log logger = new Log();

	public SamplePageObject(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	// The page object class should have the functional methods
	public void login(Login login) throws Exception {
		try {
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	// Each page class should have this overridden method of Verify Landing page 
	@Override
	public boolean verifyLandingPage() {
		return false;

	}

}

