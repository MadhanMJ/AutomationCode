
package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.FrameworkException;

public class LoginPageWithPOJO extends BasePage {
	public WebDriver driver;
	public ExtentReport extentReport;
	private final By loginButton_OR = By.xpath("//*[@id='next']");	
	private final String loginButton_S = "Login Button";
	private final By userNameTextBox = By.xpath("//*[@id='signInName']");
	private final By passwordTextBox = By.xpath("//*[@id='password']");
	private final By emailMFAOption = By.xpath("//input[@id='extension_mfaByPhoneOrEmail_email']");
	private final By sendVerificationCodeButton = By.id("strongAuthenticationEmailAddress_ver_but_send");
	private final By verificationCodeTextBox = By.xpath("//*[@class='verifyInput']");
	private final By verifyCodeButton = By.xpath("//*[@class='verifyButton']");
	private final By continueButton = By.xpath("//*[@id='continue']");
	private final By newpassword = By.xpath("//*[@id=\"newPassword\"]");
	private final By continuebutton = By.xpath("//*[@id=\"continue\"]");
	private final By clinicalHome = By.xpath("//*[@id=\"shell-wrapper\"]/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[1]/a/span");
	
	private final By  Firsttimeregistration = By.xpath("//*[@id='main_title_1']");
	private final By  Lastline = By.xpath("/html/body/div/div[2]/div/div[2]/div[1]/table/tbody/tr/td/div/ol[6]/li[17]/h1/text()");
	private final By  signature = By.xpath("//*[@id=\"signature\"]");
	private final By  Agree = By.xpath("//*[@id=\"agreeBtn\"]");

	private final By confirmnewpassword = By.xpath("//*[@id=\"reenterPassword\"]");
	private final By preferredMFAOption = By.xpath("//label[@id='extension_mfaByPhoneOrEmail_label']");
	private final By codeIncorrectError = By.xpath("//*[@id='strongAuthenticationEmailAddress_fail_retry'][@aria-hidden='false']");
	private final By codeVerifiedMessage = By.xpath("//*[@id='strongAuthenticationEmailAddress_success'][@aria-hidden='false']");
	public final String signOutMessage = "Thank you for visiting Abbott Merlin.net� Patient Care Network. You are now logged out. To prevent possible misuse of the system, you should now close this browser window.";
	public static Log logger = new Log();

	//private final static By allAbbottCustomers_OR= By.xpath("//span[text()='All Abbott customers']");

	// Updated the XPath on 02/14/2022
	//private final static By allAbbottCustomers_OR= By.xpath("//span[text()='All Abbott Customers']");
	private final static By allAbbottCustomers_OR= By.xpath("//mat-toolbar//ul/li[2]/a/span");

	private final static String allAbbottCustomers_S= "All Abbott Customers link";
	private final static By addCustomer_OR= By.xpath("//button[@id=\"btn_pcs-home_add-customer\"]/span");
	private final static String addCustomer_S= "Add Customer Button";

	public LoginPageWithPOJO(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	//public void test(String q,  String... adminlogin ) throws Exception {
	///	
	//	}
	public void login(Login login,  String... adminlogin ) throws Exception {
		
		try {
			if (adminlogin[0].equalsIgnoreCase("externaluser")) {
				getURL(CommonUtils.url);
			} else if (adminlogin[0].equalsIgnoreCase("internaluser")) {

				getURL(CommonUtils.adminUrl);

				loadingWithoutReport();
				Thread.sleep(3000);

				//loadingWithoutReport();

				isElementPresent(allAbbottCustomers_OR);
				Thread.sleep(3000);
				clickElement(allAbbottCustomers_OR, allAbbottCustomers_S);
				Thread.sleep(3000);
				loading();

				if (isDisplayedWithoutReport(addCustomer_OR, addCustomer_S))
				{
					extentReport.reportScreenShot("Landed in Customer list page with Add Customer Button displayed");
				}

			}
			waitForLoading();
			waitForLoading();
			if (isElementPresent(userNameTextBox)) {
				if (visibilityOfElementLocated(userNameTextBox) && visibilityOfElementLocated(passwordTextBox)) {
					extentReport.reportScreenShot("Username and password fields are displayed");
					sendKeys(userNameTextBox, login.getUserName());
					waitForLoading();
					sendKeys(passwordTextBox, login.getPassword());

					extentReport.reportScreenShot("User entered username and password");
					extentReport.reportScreenShot("User clicked Login Button");
					clickElement(loginButton_OR, loginButton_S);
					waitForPageLoad();
					//new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOfElementLocated(clinicalHome));
					//waitForLoading();
					//waitForLoading();
					//waitForPageLoad();
					//PasswordRest page 
					if (isElementPresent(newpassword)) {
						String reset=login.getResetPassword();
						//sendKeys(passwordTextBox, login.getPassword());
						sendKeys(passwordTextBox, login.getPassword());
						sendKeys(confirmnewpassword, reset);
						sendKeys(newpassword, reset);
						clickElement(continuebutton);


					}
					waitForPageLoad();
					waitForPageLoad();
					if (isElementPresent(preferredMFAOption)) {
						if (visibilityOfElementLocated(emailMFAOption))
							extentReport.reportScreenShot("MFA email selection radio button displayed");
						clickOnElementUsingJs(emailMFAOption);
						if (visibilityOfElementLocated(continueButton))
							clickElement(continueButton);
						waitForLoading();
						if (visibilityOfElementLocated(sendVerificationCodeButton))
							extentReport.reportScreenShot("Send Verification code button displayed");
						clickElement(sendVerificationCodeButton);

						String currentHandle = driver.getWindowHandle();

						List<String> otpList = CommonUtils.extractOTP(driver,login.getMfa());
						driver.switchTo().window(currentHandle);
						for (String otp : otpList) {
							if (visibilityOfElementLocated(verificationCodeTextBox)) {
								presenceOfElementLocated(verificationCodeTextBox);
								sendKeys(verificationCodeTextBox, otp);
								extentReport.reportScreenShot("OTP entered");
							} else {
								break;
							}
							if (visibilityOfElementLocated(verifyCodeButton))
								clickElement(verifyCodeButton);
							waitForLoading();
							//							waitForLoading();
							if (isElementPresent(codeVerifiedMessage)) {
								extentReport.reportScreenShot("Code verified messge displayed");
								break;
							}

							waitForLoading();
						}

						if (isElementPresent(codeIncorrectError)) {
							extentReport.reportFail("OTP is invalid and unable to login");
							throw new FrameworkException("OTP is invalid and unable to login");
						}
						waitForLoading();
						waitForPageLoad();
						//code for First time registration
						if (isElementPresent(Firsttimeregistration)) {
							scrollToView(Lastline);
							//sendKeys(passwordTextBox, login.getPassword());
							sendKeys(signature, "Automation");
							clickElement(Agree);
							waitForLoading();
							waitForPageLoad();

						}


					}
				}
			}



		} catch (Exception e) {
			logger.info("Error occured in Login page" + e.getMessage());
			extentReport.reportFail("Error occured in Login page");
			e.printStackTrace();
			throw e;
		}
	}

	//bhupendra
		public void loginWithNewCreatedClinic(Customer customer,Login login) throws Exception {		
			login.setUserName(customer.getUserid());
			login.setPassword(customer.getNewPassword());
			login.setResetPassword(customer.getNewPassword()+"1");
			login(login,"externaluser");
		}

	@Override
	public boolean verifyLandingPage() {
		return false;
		// TODO Auto-generated method stub

	}

}

