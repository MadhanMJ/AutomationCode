package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class AddCustomerPage extends BasePage {

	//public WebDriver driver;
	public ExtentReport extentReport;
	public ExtentTest extentTest;

	DriverUtils drivUtil = new DriverUtils(driver, extentReport);
	SoftAssert as= new SoftAssert();
	public DataBaseConnector dataBase = new DataBaseConnector();	
	TestDataProvider testDataProvider = new TestDataProvider();
	LoginPageWithPOJO loginPage = new LoginPageWithPOJO(driver, extentReport);
	AppHomeTopNavPage appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
	

	public final By customerName = By.xpath("//input[@placeholder='Customer name']");
	
	public final By customerName_OR = By.xpath("//input[@placeholder='Customer name']");
	public final String customerName_S = "Add Customer CustomerName TextBox";
	public final By customerType = By.xpath("//div[@id=\"headQuarters\"]/div/div/div[2]/div/mat-form-field/div/div/div/mat-select");
	public final By customerTypeclick_OR = By.xpath("//mat-select[@id='dd_customer-head-quarters_customerTypeCd']");
	public final By customerTypeoption_OR = By.xpath("//*[@id='dd_customer-head-quarters_customerTypeCd-panel']");
	public final String customerTypeoption_S="Customer Type Dropdown options";
	public final String customerTypeclick_S = "Customer Type Dropdown";
	public final By directCustomerType_OR = By.xpath("(//div[@id='dd_customer-head-quarters_customerTypeCd-panel']/mat-option)[1]");
	public final String directCustomerType_S ="Direct Customer Type Option";
	public final By sp2CustomerType_OR =By.xpath("(//div[@id='dd_customer-head-quarters_customerTypeCd-panel']/mat-option)[2]");
	public final String sp2CustomerType_S ="Sp2 Customer Type Option";
	public final By customerTypeselect_OR=By.xpath("//mat-select[formcontrolname='customerTypeCd' or @id='dd_customer-head-quarters_customerTypeCd']");
	public final String customerTypeselect_S="Customer Type Select Dropdown";
	public final By customerTypeoptions= By.xpath("//div[@id=\"dd_customer-head-quarters_customerTypeCd-panel\"]/mat-option/span");
	public final By customerTypeText = By.xpath("//*[@id=\"cdk-overlay-0\"]/div/div/mat-option[1]");
	
	//Updated Xpath on 02/18/2022 by ChandraMohan.S 
	//public final By addACustomer_OR = By.xpath("//*[@id='btn_pcs-home_add-customer']");
	public final By addACustomer_OR = By.xpath("//button[@id='btn_pcs-home_add-customer']");
	public String addACustomer_S= "Add Customer";
	
	
	public final By okButton_OR = By.xpath("//button[@id='close-btn-customer-create-ok-popup']");
	private final String okButton_S= "OK button";
	public final By addACustomerPageHeader = By.xpath("//h6[@id=\"lbl_customer_create_header\"]");
	//Updated xpath details based on current changes 12/27/2021 by satish kannaian
	public final By clinicLocation = By.xpath("//input[@placeholder='Clinic Location']['aria-required']");
	public final By clinicAddress_1 = By.xpath("//input[@id='txt_customer-clinicinfo_address1_streetAddress']");
	public final By clinicAddress_2 = By.xpath("//input[@id='merlin_textbox_streetAddress2']");
	public final By clinicAddress_3 = By.xpath("//input[@id='merlin_textbox_streetAddress3']");
	public final By clinicCity = By.xpath("//input[@id='txt_customer-clinicinfo_city_city']");
	public final By stateProvinceDropDown = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']['aria-required']");
	public final By zipPostalCode = By.xpath("//input[@id='txt_customer-clinicinfo_zipCode_zipCode']");
	public final By secondaryPhone = By.xpath("//*[@label='Secondary Phone']//input[@id='merlin_textbox_phoneNum']");
	public final By faxNumber = By.xpath("//input[@id='txt_customer-clinicinfo_fax_phoneNum']");
	public final By textMessage = By.xpath("//input[@id='txt_customer-clinicinfo_sms_sms']");
	public final By testClinic = By.xpath("//input[@id='chb_customer-clinicinfo_test_clinic-input']");
	public final By activatorClinic = By.xpath("//input[@id='chb_customer-clinicinfo_activator_clinic-input']");
	public final By onDemandFeatureControl = By.xpath("//input[@id='chb_customer-clinicinfo_capability-input']");
	//ended update xpath changes
	public final By countryCode = By.xpath("//*[@controlname='countryCode']/mat-form-field/div/div/div/input");
	public final By areaCode = By.xpath("//*[@controlname='areaCode']/mat-form-field/div/div/div/input");
	public final By areaCodephone = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_areaCode']/mat-form-field//following::input[1]");
	public final By mainPhone = By.xpath("//*[@controlname='phoneNum']/mat-form-field/div/div/div/input");
	public final By secPhone = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_secondaryPhone']//div/following::input");
	public final By country = By.xpath("//mat-select[@id=\"dd_customer-clinicinfo_countryCd\"]");
	public final By countryTextBox = By.xpath("//*[@placeholder='Search...']['aria-required']");
	public final By countryText = By.xpath("//*[contains(@id,'mat-option')][2]");
	//xpath changes done by satish kannaian 12/27/2021
	public final By email = By.xpath("//input[@id='merlin_textbox_emailAddress']");
	//ended xpath changes
	public final By clinicTimeZone = By.xpath("//mat-select[@id='dd_customer-clinicinfo_timeZoneCd']");
	public final By clinicTimeZoneTextBox = By.xpath("//*[@placeholder='Search...']['aria-required']");
	//public final By testClinic = By.xpath("//input[@id=\"mat-checkbox-1-input\"]");
	

	//Rajesh SIngaraj Xpath changes by 12/01/2022
	public final By customerType_OR = By.xpath("//div[@id=\"headQuarters\"]/div/div/div[2]/div/mat-form-field/div/div/div/mat-select");
	public final String customerType_S = "Customer type";
	public final By customerTypeoptions_OR = By.xpath("//div[@id=\"dd_customer-head-quarters_customerTypeCd-panel\"]/mat-option/span");
	public final String customerTypeoptions_S = "Customer type option";	
	public final By customerTypeText_OR = By.xpath("//*[@id=\"cdk-overlay-0\"]/div/div/mat-option[1]");
	public final String customerTypeText_S = "Customer type text";		
	public final By addACustomerPageHeader_OR = By.xpath("//h6[@id=\"lbl_customer_create_header\"]");
	public final String addACustomerPageHeader_S = "add Customer Page Header";	
	public final By clinicLocation_OR = By.xpath("//input[@placeholder='Clinic Location']['aria-required']");
	public final String clinicLocation_S = "clinic Location";
	public final By clinicAddress_1_OR = By.xpath("//input[@id='merlin_textbox_streetAddress']");
	public final String clinicAddress_1_S = "clinic Address 1";
	public final By clinicAddress_2_OR = By.xpath("//input[@id='merlin_textbox_streetAddress2']");
	public final String clinicAddress_2_S = "clinic Address 2";
	public final By clinicAddress_3_OR = By.xpath("//input[@id='merlin_textbox_streetAddress3']");
	public final String clinicAddress_3_S = "clinic Address 3";
	public final By clinicCity_OR = By.xpath("//input[@id='merlin_textbox_city']");
	public final String clinicCity_S = "clinic City";
	public final By stateProvinceDropDown_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']['aria-required']");
	public final String stateProvinceDropDown_S = "state/Province Drop Down";	
	public final By zipPostalCode_OR = By.xpath("//input[@id='merlin_textbox_zipCode']");
	public final String zipPostalCode_S = "zip Postal Code";
	public final By secondaryPhone_OR = By.xpath("//*[@label='Secondary Phone']/mat-form-field/div/div/div/input");
	public final String secondaryPhone_S = "secondary Phone";
	public final By faxNumber_OR = By.xpath("(//input[@id='merlin_textbox_phoneNum'])[3]");
	public final String faxNumber_S = "fax Nmber";
	public final By textMessage_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_sms']//div/following::input");
	public final String textMessage_S = "text Message";
	public final By testClinic_OR = By.xpath("//input[@id='mat-checkbox-1-input']");
	public final String testClinic_S = "test Clinic";
	public final By onDemandFeatureControl_OR = By.xpath("//input[@id='mat-checkbox-3-input']");
	public final String onDemandFeatureControl_S = "on Demand Feature Control";
	public final By selectedCountry_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div/span/span[1]");
	public final String selectedCountry_S = "Selected country in DD";
	public final By selectedState_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']/div/div/span/span[1]");
	public final String selectedState_S = "Selected state in DD";	
	public final By selectedClinicLanguage_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd']/div/div/span/span[1]");
	public final String selectedClinicLanguage_S = "Selected clinic language in DD";
	public final By countryDownArrow_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div[2]");
	public final String countryDownArrow_S = "Country down arrow in DD";
	public final By stateDownArrow_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']/div/div[2]");
	public final String stateDownArrow_S = "Country down arrow in DD";
	public final By countryFirstValue_OR = By.xpath("(//div[@id='dd_customer-clinicinfo_countryCd-panel']//following::mat-option)[1]");
	public final String countryFirstValue_S = "Country first value in DD";
	public final By stateFirstValue_OR = By.xpath("(//div[@id='dd_customer-clinicinfo_stateCd-panel']//following::mat-option)[1]");
	public final String stateFirstValue_S = "state first value in DD";
	public final By TotalNoOfStates_OR = By.xpath("//div[@id='dd_customer-clinicinfo_stateCd-panel']/mat-option");
	public final String TotalNoOfStates_S = "Total number of states in DD";
	public final By TotalNoOfCountries_OR = By.xpath("//div[@id='dd_customer-clinicinfo_countryCd-panel']/mat-option");
	public final String TotalNoOfCountries_S = "Total number of countries in DD";
	public final By countryCode_OR = By.xpath("//*[@controlname='countryCode']/mat-form-field/div/div/div/input");
	public final String countryCode_S = "country Code";
	public final By areaCode_OR = By.xpath("//*[@controlname='areaCode']/mat-form-field/div/div/div/input");
	public final String areaCode_S = "area Code";
	public final By areaCodephone_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_areaCode']/mat-form-field//following::input[1]");
	public final String areaCodephone_S = "area Code phone";
	public final By mainPhone_OR = By.xpath("//*[@controlname='phoneNum']/mat-form-field/div/div/div/input");
	public final String mainPhone_S = "main Phone";
	public final By secPhone_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_secondaryPhone']//div/following::input");
	public final String secPhone_S = "sec Phone";
	public final By country_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']");
	public final String country_S= "country Dropdown";
	public final By countryTextBox_OR = By.xpath("//*[@placeholder='Search...']['aria-required']");
	public final String countryTextBox_S = "country Text Box";
	public final By countryText_OR = By.xpath("//*[contains(@id,'mat-option')][2]");
	public final String countryText_S = "country Text";



	//shafiya changed xpath
	public final By email_OR = By.xpath("//input[@id='txt_customer-clinicinfo_emailAddress_emailAddress']");
	public final String email_S = "Email";
	public final By clinicTimeZone_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_timeZoneCd']");
	public final String clinicTimeZone_S = "clinicTimeZone_S";	
	public final By clinicTimeZoneTextBox_OR = By.xpath("//*[@placeholder='Search...']['aria-required']");
	public final String clinicTimeZoneTextBox_S = "clinic Time Zone  TextBox";
	public final By customerPageDividerSection_OR = By.xpath("//mat-card[@class='mat-card mat-focus-indicator flat merlin-section section-Padding']");
	public final String customerPageDividerSection_S = "Customer Page Divider Section";
	public final By clinicLocationAlertMsg_OR = By.xpath("//input[@placeholder='Clinic Location']//following::mat-error[1]");
	public final String clinicLocationAlertMsg_S = "Clinic Location Alert Message";
	public final By zipPostalCodeAlertMsg_OR = By.xpath("//input[@placeholder='Zip/Postal Code']//following::mat-error[1]");
	public final String zipPostalCodeAlertMsg_S = "Zip/Postal Code Alert Message";	
	public final By areaCodeAlertMsg_OR = By.xpath("(//merlin-textbox[@controlname='areaCode']//following::mat-error[1])[1]");
	public final String areaCodeAlertMsg_S = "Area Code Alert Message";
	public final By countryCodeAlertMsg_OR = By.xpath("(//merlin-textbox[@controlname='countryCode']//following::mat-error[1])[1]");
	public final String countryCodeAlertMsg_S = "Country Code Alert Message";	
	public final By mainPhoneAlertMsg_OR = By.xpath("(//input[@id='merlin_textbox_phoneNum']//following::mat-error[1])[1]");
	public final String mainPhoneAlertMsg_S = "Main phone Alert Message";	
	public final By secondarycountryCode_OR = By.xpath("(//*[@controlname='countryCode']/mat-form-field/div/div/div/input)[2]");
	public final String secondarycountryCode_S = "Secondary country Code";
	public final By secondaryAreaCode_OR = By.xpath("(//*[@controlname='areaCode']/mat-form-field/div/div/div/input)[2]");
	public final String secondaryAreaCode_S = "Secondary Area Code";
	public final By secondaryMainPhone_OR = By.xpath("(//*[@controlname='phoneNum']/mat-form-field/div/div/div/input)[2]");
	public final String secondaryMainPhone_S = "Secondary Main Phone";
	public final By emailIdAlertMsg_OR=By.xpath("(//*[@placeholder='Email']//following::mat-error[1])[1]");
	public final String emailIdAlertMsg_S = "Email Id Alert Message";
	public final By clinicTimeZoneText_OR = By.xpath("//*[contains(@id,'mat-option')][4]/span");
	public final String clinicTimeZoneText_S = "clinicTime Zone Text";
	public final By faxAreaCode_OR = By.xpath("(//input[@id='merlin_textbox_countryCode'])[3]");
	public final String faxAreaCode_S = "fax Area Code";	
	public final By faxCountryCode_OR = By.xpath("(//input[@id='merlin_textbox_areaCode'])[3]");
	public final String faxCountryCode_S = "fax Country Code";	
	public final By faxnumber_OR = By.xpath("(//input[@id='merlin_textbox_phoneNum'])[3]");
	public final String faxnumber_S = "fax number";
	public final By legalJurisdiction_OR = By.xpath("//mat-select[@id=\"dd_customer-clinicinfo_legaJurisdictionCd\"]");
	public final String legalJurisdiction_S = "legal Jurisdiction";
	public final By legalJurisdictionlabel_OR = By.xpath("//*[@id=\"dd_customer-clinicinfo_legaJurisdictionCd\"]");
	public final String legalJurisdictionlabel_S = "legal Jurisdictionlabel";
	public final By legalJurisdictionText_Japan_OR = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[5]");
	private final String legalJurisdictionText_Japan_S = "Legal Jurisdiction value";
	public final By legalJurisdictionText_United_States_OR = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[5]");
	private final String legalJurisdictionText_United_States_S = "Legal Jurisdiction value";
	
	//shafiya changed xpath
	public final By userId_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_userId_userId']");
	private final String userId_S = "User Id";
	public final By password_OR =  By.xpath("//input[@id='txt_customer-clinic-main-contact_password_password']");
	private final String password_S = "Password";
	public final By confirmNewPassword_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_confirmPassword_confirmPassword']");
	private final String confirmNewPassword_S = "Confirm New Password";
	public final By firstName_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_firstName_firstName']");
	private final String firstName_S = "First Name";
	public final By lastName_OR =  By.xpath("//input[@id='txt_customer-clinic-main-contact_lastName_lastName']");
	private final String lastName_S = "Last Name";
	public final By clinicmaincontactEmail_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_email_mainContactEmail']");
	private final String clinicmaincontactEmail_S = "Clinic Main Contact Email";
	public final By legalJurisdictionText_OR = By.xpath("/html/body/div[3]/div[2]/div/div/div/mat-option[6]");
	public final String legalJurisdictionText_S = "legal Jurisdiction Text";
	public final By clinicLanguage_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd']");
	public final String clinicLanguage_S = "clinic Language";
	public final By clinicLanguageTextBox_OR = By.xpath("//*[@placeholder='Search...']['aria-required']");
	public final String clinicLanguageTextBox_S = "clinic Language TextBox";
	public final By clinicLanguageText_OR = By.xpath("//*[contains(@id,'mat-option')][2]");
	public final String clinicLanguageText_S = "clinic Language Text";
//changes ended
	
	
	
	public final By clinicTimeZoneText = By.xpath("//*[contains(@id,'mat-option')][4]/span");

	public final By legalJurisdiction = By.xpath("//mat-select[@id=\"dd_customer-clinicinfo_legaJurisdictionCd\"]");
	public final By legalJurisdictionlabel = By.xpath("//*[@id=\"dd_customer-clinicinfo_legaJurisdictionCd\"]");
	//public final By legalJurisdictionText = By.xpath("//*[@id=\"cdk-overlay-3\"]/div/div/mat-option[6]");
	public final By legalJurisdictionText = By.xpath("/html/body/div[3]/div[2]/div/div/div/mat-option[6]");
	public final By clinicLanguage = By.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd']");
	public final By clinicLanguageTextBox = By.xpath("//*[@placeholder='Search...']['aria-required']");
	public final By clinicLanguageText = By.xpath("//*[contains(@id,'mat-option')][2]");
	//xpath changes by satish kannaian
	public final By userId = By.xpath("//input[@id='merlin_textbox_userId']");
	public final By password =  By.xpath("//input[@id='merlin_textbox_password']");
	public final By confirmNewPassword = By.xpath("//input[@id='merlin_textbox_confirmPassword']");
	public final By firstName = By.xpath("//input[@id='merlin_textbox_firstName']");
	public final By middleName =By.xpath("//input[@id='txt_customer-clinic-main-contact_middleName_middleName']");
	//xpath changes ended
	public final By credentials = By.xpath("//mat-select[@id=\"dd_customer-clinic-main-contact_credentialsCd\"]");
	public final By applications = By.xpath("//*[contains(text(),'Applications')]/following::select[1]");
	public final By allowedApplications = By.xpath("//*[contains(text(),'Allowed Applications')]/following::select[1]");
	public final By clinicalTrailSection = By.xpath("//*[contains(text(),'Clinical Trials')]/following::select[1]");
	public final By allowedClinicalTrailSection = By.xpath("//*[contains(text(),'Allowed Clinical Trials')]/following::select[1]");
	public final By generalFeatureSection = By.xpath("//*[@class='box genericFeatures']/div[contains(text(),'General')]");
	public final By allowedDirectCallFeatureSection = By.xpath("//*[@class='box genericFeatures']/div[contains(text(),'DirectCall')]");
	//xapth changes by satish kannaian
	public final By lastName =  By.xpath("//input[@id='merlin_textbox_lastName']");
	public final By emailId = By.xpath("//input[@id='txt_customer-clinic-main-contact_email_mainContactEmail']");
	public final By testClinicCheckBox = By.xpath("//input[@id='chb_customer-clinicinfo_test_clinic-input']/..");
	//xpath changes ended
	

	public final By recordPatientDataCheckBox = By.xpath("//*[@id=\"chb_customer-feature-control_showDataMiningConsentFlg\"]/label/div");
	public final By securityMinPasswordLen = By.xpath("//*[@id=\"dd_customer-security-settings_passwordMinLength\"]/div/div[1]");
	public final By securityMinPasswordLenText = By.xpath("//*[@id='cdk-overlay-5']/div/div/mat-option[2]");
	public final By generalAllowCommCenter = By.xpath("//*[@id=\"chb_customer-feature-control_allowSmartAlertFlg\"]/label/div");
	public final By generalAllowCommCenterCheckBox = By.xpath("/html/body/app-root/app-shell/div/div[2]/app-customer/div/div/div[1]/div[5]/div/app-feature-control/div/div/div[1]/div[1]/div/mat-checkbox[3]/label/div");
	public final By electroOrderTransmitter = By.xpath("//*[@id=\"chb_customer-feature-control_setGDCSchedules\"]/label/div");
	public final By electroOrderTransmitterCheckBox = By.xpath("//*[@id=\"chb_customer-feature-control_showDataMiningConsentFlg\"]/label/div");
	public final By electroExportToEHR = By.xpath("//*[@id=\"featureControl\"]/div/div[1]/div[3]/div/mat-form-field/div/div[1]/div");
	public final By electroExportToEHRText = By.xpath("//*[@id='cdk-overlay-6']/div/div/mat-option[2]");
	public final By addCustomerSave_OR = By.xpath("//*[@id=\"btn_customer_save\"]");	
	public String  addCustomerSave_S = "Add Customer Save Button";
	public final By cancelSecLocation = By.xpath("//*[@id=\"btn_pcs-location-popup_Cancel\"]");
	public final By allowedDirectAlertBox_Alert = By.xpath("//app-feature-control/div/div/div[2]/merlin-bucket-list/div[3]/div/select");
	public final By allowedDirectAlertBox_Notif = By.xpath("//app-feature-control/div/div/merlin-bucket-list[3]/div[3]/div/select");
	public final By canceladdCustomer = By.xpath("//*[@id=\"btn_customer_cancel\"]");
	public final By canceladdCustomerOk = By.xpath("//*[@id=\"btn_pcs-location-popup_Ok\"]");
	public final By saveaddCustomerOk = By.xpath("//button[@id=\"btn_pcs-location-popup_Ok\"]/span");
	
	public final By securitySettingHeader = By.xpath("//div[@id=\"regForm\"]/div/div/merlin-section[4]/mat-card/div/div");
	public final By securitySettingHeader_OR = By.xpath("//div[@id=\"regForm\"]/div/div/merlin-section[4]/mat-card/div/div");
String securitySettingHeader_S ="Security Setting Header";

	
	public final By colleagueEmails = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewCC\"]/label/span");
	public final By unpairedTransmitterEmails = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label/span");

	public final By colleagueEmails_OR = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewCC\"]/label/span");
	String colleagueEmails_S="College Emails";
	public final By unpairedTransmitterEmails_OR= By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label/span");

	String unpairedTransmitterEmails_S="unpaired Transmitter Emails";
	public final By addCustomerMsg = By.xpath("//*[contains(text(),\"I have your new customer information.\")]");
	String addCustomerMsg_S = "Add Customer another physical location confirmation popup";
	public String customerNameValue = null;
	public final By addAnotherPhysicalLocMsg_OR = By.xpath("//*[contains(text(),\"Would you like to add another physical location for this Direct?\")]");
	private final String addAnotherPhysicalLocMsg_S = "Add Secondary Location Message";
	public final By addAnotherPhysicalLocOk_OR = By.xpath("//*[@id=\"btn_pcs-location-popup_Ok\"]");
	private final String addAnotherPhysicalLocOk_S = "Ok Button";
	public final By addAnotherPhysicalLocCancel_OR = By.xpath("//*[@id='btn_pcs-location-popup_Cancel']/span");
	private final String addAnotherPhysicalLocCancel_S = "Add Secondary Location Cancel Button";
	public final By Recordpatientdatacollectionconsent_  = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label/span");
	public final By AllowMobileDirectAlertsnotifications  = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label/span");
	public final By AllowaccesstoCommunicationCenter  = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label/span");
	public final By AllowaccesstoComplianceReport  = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label/span");
	public final By Recordpatientdatacollectionconsent_OR = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_showDataMiningConsentFlg\"]");
	String Recordpatientdatacollectionconsent_S="Record patient data collection consent";
	public final By AllowMobileDirectAlertsnotifications_OR  = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_allowSmartAlertFlg\"]");
	String AllowMobileDirectAlertsnotifications_S="Allow Mobile Direct Alerts notifications";
	public final By AllowaccesstoCommunicationCenter_OR  = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_allowCommCenterAccess\"]");
	String AllowaccesstoCommunicationCenter_S="Allow access to CommunicationCenter";
	public final By AllowaccesstoComplianceReport_OR  = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_allowComplianceReport\"]");
	String AllowaccesstoComplianceReport_S="Allow access to ComplianceReport";
	

	public String userIdValue = null;
	
	private String iteration;
	private String testName;
	public final By legalJurisdictionText_Japan = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[5]");
    public final By legalJurisdictionText_US = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[6]");
    public final By legalJurisdictionText_Australia = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[2]");
    public final By legalJurisdictionText_Canada = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[3]");
    public final By legalJurisdictionText_Europe = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd-panel']/mat-option[4]");
	public final By pageLoading = By.xpath("//*[@class='spinnerWrapper show']");
	//UC013B elements
	public  boolean addcustomer = false;
	public final By allowedClinicalTrail = By.xpath("//app-feature-control/div/div/merlin-bucket-list[2]/div/div/select");
	public final By mainPhoneText = By.xpath("//*[@label='Main Phone']/mat-form-field/div/div/div/input");
	public final By existingJurisdictionText = By.xpath("//*[@formcontrolname='legalJurisdictionCd']");
	public final By existingAreaCode = By.xpath("//*[@label='Area Code']/mat-form-field/div/div/div/input");
	public final By message = By.xpath("//*[@id=\"toast-container\"]/div/div");
	public final By messageclose = By.xpath("//*[@id='toast-container']/div/button/span");
	public final By customerNameError = By.xpath("//input[@placeholder='Customer name'][contains(@aria-describedby,'mat-error')]");
	public final By clinicLocationError = By.xpath("//input[@placeholder='Clinic Location'][contains(@aria-describedby,'mat-error')]");
	public final By mainPhoneError = By.xpath("//*[@id=\"txt_customer-clinicinfo_mainPhone\"]/mat-form-field/div/div/div/input[contains(@aria-describedby,'mat-error')]");
	public final By emailError = By.xpath("//input[@placeholder='Email'][contains(@aria-describedby,'mat-error')]");
	 
	public final By clinictimeError = By.xpath("//*[@aria-label='Clinic Time Zone '][contains(@aria-describedby,'mat-error')]");
	public final By cliniclangtimeError = By.xpath("//*[@aria-label='Clinic Time Zone '][contains(@aria-describedby,'mat-error')]");
	
	public final By jurisdictionError = By.xpath("//*[@id='dd_customer-clinicinfo_legaJurisdictionCd'][contains(@aria-describedby,'mat-error')]");
	public final By useridError = By.xpath("//input[@placeholder='User ID'][contains(@aria-describedby,'mat-error')]");
	public final By passwordError = By.xpath("//input[@placeholder='Password'][contains(@aria-describedby,'mat-error')]");
	public final By newPasswordError = By.xpath("//input[@placeholder='Confirm new password'][contains(@aria-describedby,'mat-error')]");
	public final By firstnameError = By.xpath("//input[@placeholder='First Name'][contains(@aria-describedby,'mat-error')]");
	public final By lastnameError = By.xpath("//input[@placeholder='Last Name'][contains(@aria-describedby,'mat-error')]");
	public final By clinicmaincontactEmail = By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_email']/mat-form-field//following::input[1]");
	public final By Error = By.xpath("//input[contains(@aria-describedby,'mat-error')]");
	public final By HeadquartersSection = By.xpath("//*[@id=\"regForm\"]/div/div/merlin-section[1]/mat-card/div/div");
	public final By HeadquartersSection_OR = By.xpath("//*[@id=\"regForm\"]/div/div/merlin-section[1]/mat-card/div/div");
	public final String HeadquartersSection_S="Headquarters Section ";
	
	public final By clinicMainContactHeader = By.xpath("//div[@id='section_title_Clinic_main contact']");
	public final By clinicMainContactUserId = By.xpath("//input[@id='merlin_textbox_userId']");
	public final By clinicMainContactUserPassword = By.xpath("//input[@id='merlin_textbox_password']");
	public final By clinicMainContactfirstName = By.xpath("//input[@id='merlin_textbox_firstName']");
	public final By clinicMainContactconfirmPassword = By.xpath("//input[@id='merlin_textbox_confirmPassword']");
	public final By clinicMainContactmiddleName = By.xpath("//input[@id='merlin_textbox_middleName']");
	public final By clinicMainContactcredentialsCd = By.xpath("//mat-select[@id='dd_customer-clinic-main-contact_credentialsCd']");
	public final By clinicMainContactlastName = By.xpath("//input[@id='merlin_textbox_lastName']");
	public final By clinicMainContactmainContactEmail = By.xpath("//input[@id='merlin_textbox_mainContactEmail']");

	public final By searchCustomer = By.xpath("//input[@id='txt_pcs-home_search']");
	public final By searchIcon = By.xpath("//mat-icon[text()='search']");
	public final String searchListCustomerXpath = "//a/span[text()='customername']";
	public final By deleteButton = By.xpath("//button/span[text()=' Delete ']");
	public final By deleteConfrimOk = By.xpath("//button[@id='close-btn-customer-delete-popup']");
	public final By useridErrorText = By.xpath("//merlin-textbox[@placeholder='User ID']//*/mat-error");
	public final By confirmPasswordErrorText = By.xpath("//merlin-textbox[@placeholder='Confirm new password']//*/mat-error");
	public final By PasswordErrorText = By.xpath("//merlin-textbox[@placeholder='Password']//*/mat-error");
	
	// Alok
	public final By allEmailsAndMessagesCheckBox_OR = By.xpath("//input[@id='chb_customer-security-settings_allSecureMsgs-input']");
	private final String allEmailsAndMessagesCheckBox_S = "All Emails And Messages CheckBox";
	public final By clinicLevelControlOfContactAColleagueEmailsCheckBox_OR = By.xpath("//input[@id='chb_customer-security-settings_ctrlViewCC-input']");
	private final String clinicLevelControlOfContactAColleagueEmailsCheckBox_S = "Clinic level control of Contact a Colleague emails";
	public final By clinicLevelControlOfUnpairedTransmitterEmails_OR = By.xpath("//input[@id='chb_customer-security-settings_ctrlViewTX-input']");
	private final String clinicLevelControlOfUnpairedTransmitterEmails_S = "Clinic level control of Unpaired Transmitter emails";
	// Alok- End
	
	//Poojitha
	private final By activatorClinicCheckbox_OR = By.xpath("//input[@id='chb_customer-clinicinfo_activator_clinic-input']");
	private final String activatorClinicCheckbox_S = "Activator clinic checkbox";
	//Ends here
	
	
	public AddCustomerPage(WebDriver driver,ExtentReport extentReport) {
		super(driver,extentReport);
		this.driver=driver;
		this.extentReport = extentReport;
		
	}
	
	//Vrushali block Start
	
	private final By exportTransDataFilesCheckbox_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_showExportSessionFlg']");
	private final String exportTransDataFilesCheckbox_S = "Export Transmission Data Files Checkbox";
	private final By orderTransCheckbox_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_orderTransmitterFlg']");
	private final String orderTransCheckbox_S = "Order Transmission Checkbox";
	private final By exportToEHRList_OR = By.xpath("//mat-select[@id='dd_customer-feature-control_exportEHRTypeCd']");
	private final String exportToEHRList_S = "Export to EHR dropdown list";
	private final By autoManualOption_OR = By.xpath("//mat-option[@id='mat-option-599']");
	private final String autoManualOption_S = "Export to EHR dropdown list - Auto/Manual option";
	private final By manualOption_OR = By.xpath("//mat-option[@id='mat-option-600']");
	private final String manualOption_S = "Export to EHR dropdown list - Manual option";
	private final By noExportOption_OR = By.xpath("//mat-option[@id='mat-option-601']");
	private final String noExportOption_S = "Export to EHR dropdown list - No export option";
	
	public List<String> verifyExportToEHRList() {
		List<String> list = new ArrayList<String>();
		clickElement(exportToEHRList_OR, exportToEHRList_S);
		list.add(driver.findElement(autoManualOption_OR).getText());
		list.add(driver.findElement(manualOption_OR).getText());
		list.add(driver.findElement(noExportOption_OR).getText());
		return list;
	}
	
	public boolean verifyEditCustLandingPage() {

		Boolean check = false;
			if (visibilityOfElementLocated(addCustomerSave_OR)) {
				check=true;
			}			
			return check;
		}
	
	public boolean isDisplayExportTransDataFilesCbox() {
		boolean flag = false;
		if(isDisplayedWithoutReport(exportTransDataFilesCheckbox_OR, exportTransDataFilesCheckbox_S)) {
			flag = true;
		}
		return flag;
	}
	
	public boolean isDisplayOrderTransCbox() {
		boolean flag = false;
		if(isDisplayedWithoutReport(orderTransCheckbox_OR, orderTransCheckbox_S)) {
			flag = true;
		}
		return flag;
	}
	
	
	//Vrushali
		public boolean verifyAddCustomerConfirmMsg() throws InterruptedException
		{
			boolean isCustAdded = false;
			presenceOfElementLocated(addCustomerMsg);
			if(isDisplayedWithReport(addCustomerMsg, addCustomerMsg_S))
			{
				isCustAdded = true;
			}
			return isCustAdded; 
		}
		
		public boolean verifyCustType() {
			boolean flag = false;
			clickElement(customerTypeclick_OR, customerTypeclick_S);
			if(isElementPresent(directCustomerType_OR, directCustomerType_S) && isElementPresent(sp2CustomerType_OR, sp2CustomerType_S))
				flag = true;
			return flag;
			
		}
		
		private final By addcustsuccessmsg_OR = By.xpath("//div[@id='label_delete_customer_msg1']");
		private final String addcustsuccessmsg_S = "Thanks. Your <userfname userlastname> has been added - popup message.";
		//shafiya changed this xpath
		private final By addcustsuccessOKBtn_OR = By.xpath("//button[@id='close-btn-customer-create-ok-popup']");
		private final String addcustsuccessOKBtn_S = "Thanks. Your <userfname userlastname> has been added - popup OK button.";
		
		public boolean verifyAddCustSuccessPopupAndClickOK() {
			boolean flag = false;
			if(isElementPresent(addcustsuccessmsg_OR, addcustsuccessmsg_S)) {
				clickElement(addcustsuccessOKBtn_OR, addcustsuccessOKBtn_S);
				flag = true;
			
			}
			return flag;
			}
	
/* ************************Alok*******************************/
	
	public boolean VerifyDirectCheckComplianceDay() throws InterruptedException {
		Boolean DirectCheckComplianceDay=false;
		
		 if ( driver.getPageSource().contains("direct check compliance day")){
			 DirectCheckComplianceDay=true;
			 extentReport.reportScreenShot("Direct check compliance day is displayed ");
		}
		extentReport.reportScreenShot("Direct check compliance day is not displayed ");
		return DirectCheckComplianceDay;
		
	}
	
	//-------------------------Alok End---------------------------------------//

	public void addcustomerpageComponents () throws InterruptedException
	{
		assertion.assertEquals(true,isElementPresent( customerName,"customerName"), "Add Customer Page Customer Name Validation");
		assertion.assertEquals(true, isElementPresent( customerType,"customerType"), "Add Customer Page Customer Type Validation");
		assertion.assertEquals(true,  isElementPresent( clinicLocation_OR), "Add Customer Page clinic Location  Validation");
		assertion.assertEquals(true,  isElementPresent( clinicAddress_1), "Add Customer Page Clinic Address Validation");
		assertion.assertEquals(true,  isElementPresent( clinicCity), "Add Customer Page City Validation");
		assertion.assertEquals(true,  isElementPresent( stateProvinceDropDown), "Add Customer Page State Procince Validation");
		assertion.assertEquals(true,  isElementPresent( country_OR), "Add Customer Page Country Validation"); 
		assertion.assertEquals(true,  isElementPresent( zipPostalCode), "Add Customer Page Zip Validation");
		assertion.assertEquals(true,  isElementPresent( mainPhone_OR), "Add Customer Page Main Phone Validation");
		assertion.assertEquals(true,  isElementPresent( secPhone), "Add Customer Page Secondary Phone Validation");
		assertion.assertEquals(true,  isElementPresent( faxNumber), "Add Customer Page Fax Number Validation");
	    assertion.assertEquals(true,  isElementPresent( textMessage), "Add Customer Page Text Message Validation");
		assertion.assertEquals(true,  isElementPresent( email_OR), "Add Customer Page Email Validation");
		assertion.assertEquals(true,  isElementPresent( clinicLanguage_OR), "Add Customer Page clinic Language Validation");
		assertion.assertEquals(true,  isElementPresent( clinicTimeZone_OR), "Add Customer Page clinic TimeZone Validation");
		assertion.assertEquals(true,  isElementPresent( legalJurisdiction), "Add Customer Page legal Jurisdiction Validation");
		assertion.assertEquals(true,  isElementPresent( testClinic), "Add Customer Page Test Clinic Validation");
		assertion.assertEquals(true,  isElementPresent( onDemandFeatureControl), "Add Customer Page onDemandFeatureControl Validation");
		assertion.assertEquals(true,  isElementPresent( userId_OR), "Add Customer Page userId Validation");
		assertion.assertEquals(true,  isElementPresent( password_OR), "Add Customer Page password Validation");
		assertion.assertEquals(true,  isElementPresent( firstName_OR), "Add Customer Page firstName Validation");
		assertion.assertEquals(true,  isElementPresent( lastName_OR), "Add Customer Page lastName Validation");
		assertion.assertEquals(true,  isElementPresent( middleName), "Add Customer Page middleName Validation");
		assertion.assertEquals(true,  isElementPresent( credentials), "Add Customer Page credentials Validation");
		assertion.assertEquals(true,  isElementPresent( emailId), "Add Customer Page Email Id Validation");
		
	}
	
public boolean  FieldMaxlength(String MaxLength, By FieldLocator ,String text) throws Exception
{ 
	boolean flag=false;
	try {
	
	String Max=getAttribute(FieldLocator,"maxlength");
	if(MaxLength.equals(Max))
	{
		flag=true;
	}
	 int number = Integer.parseInt(MaxLength);
	if(text.length()>number)
	{
		flag=false;
	}
	}
	catch(Exception e)
	{
		flag=false;
	}
	return flag;
	
}	    	
public boolean resultsetsize(int size)
{
	boolean rssize;
	try 
	{
	if(size==0)
	{
		rssize=true;
	}
	else
	{
		rssize=false;
	}
	}
	catch(Exception e)
	{
		rssize=false;
	}
	return rssize;
	
}

public boolean ErrorSize()
{
	boolean rssize=false;
	try {
	 int size=getSizeOfElements(Error);

	if(size==0)
	{
		rssize=true;
	}
	else
	{
		rssize=false;
	}
	}
		catch(Exception e)
		{
			rssize=false;
		}
	return rssize;
	
}

public boolean  Stringtoboolean(String text) throws Exception
{ 
	boolean flag=Boolean.parseBoolean(text); 
	return flag;
	
}	public  void FieldVerfication(String Fieldname ) throws Exception {    
    //Declaring String variable  
    String name=Fieldname;
    Customer customer;
    CommonUtils reuse=new CommonUtils();
    TestDataProvider testDataProvider = new TestDataProvider();
    customer = testDataProvider.getCustomerData("AddCustomer");
    int level=0;  
    //Using String in Switch expression 
   //extentReport.reportInfo(Fieldname+" - Field Verification.");
    switch(name){    
    //Using String Literal in Switch case  
    case "CustomerName":
    	
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",customerName);
    	
    	
    	 break;
    case "ClinicLocation":
    	
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",clinicLocation);
    	 
    	 break; 
    case "Mainphone":
    
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",mainPhone);
    	
    	 break;
    	
    case "Email":
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",email);
    	 
    	 break;	
    case "Clinictimezone":
    	addCustomerfieldupdate(customer,"dropdown");
    	 addcustomerclearfield("dropdown",clinicTimeZone);
    	
    	 break;	
    case "Cliniclegaljurisdiction":
    	addCustomerfieldupdate(customer,"dropdown");
    	 addcustomerclearfield("dropdown",legalJurisdiction);
    	
    	 break;		 
    	 
    case "UserID":
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",userId);
    	 
    	 break;		 
    case "Password":
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",password);
    	 
    	 break;	
    case "ConfirmNewPassword":
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",confirmNewPassword);
    	
    	 break;
    case "Firstname":
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",firstName);
    	
    	 break;	
    	 
    case "Lastname":
    	addCustomerfieldupdate(customer,"Text");
    	 addcustomerclearfield("Text",lastName);
    	
    	 break;	
   case "AddCustomer":
    	
	   addCustomerfieldupdate(customer,"Text");
    	
    	extentReport.reportScreenShot("Add Customer Field update is  successfull");
    	 break;	
    }    
   
}   

public void addcustomer(Customer customer) throws Exception {
	addCustomerfieldupdate(customer,"Text");
}


public void clickOkButton() {
	clickElement(okButton_OR, okButton_S);
}

public static String randomCustomerNameWithDate() {
	// String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
	String pattern = "yyMMdd";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

	String date = simpleDateFormat.format(new Date());
	String customerName = "CusName_"+date;
	return customerName;
}
	public  void ErrorFieldVerfication(String Fieldname ) throws Exception {    
	    //Declaring String variable  
	    String name=Fieldname;
	    Customer customer;
	    CommonUtils reuse=new CommonUtils();
	    TestDataProvider testDataProvider = new TestDataProvider();
	    customer = testDataProvider.getCustomerData("AddCustomer");
	    int level=0;  
	    //Using String in Switch expression 
	    //extentReport.reportInfo(Fieldname+" - Field Verification.");
	    switch(name){    
	    //Using String Literal in Switch case  
	    case "CustomerName":

	    	//addCustomerfieldupdate(customer,"Text");
	    	// addcustomerclearfield("Text",customerName);

	    	 fieldError(customerNameError);
	    	 scrollToView(customerNameError);
	    	 break;
	    case "ClinicLocation":
	    	
	    	
	    	 fieldError(clinicLocationError);
	    	 scrollToView(clinicLocationError);
	    	 break; 
	    case "Mainphone":
	    
	    	
	    	 fieldError(mainPhoneError);
	    	 scrollToView(mainPhoneError);
	    	 break;
	    	
	    case "Email":
	    	
	    	 fieldError(emailError);
	    	 scrollToView(emailError);
	    	 break;	
	    case "Clinictimezone":
	    	
	    	 fieldError(clinictimeError);
	    	 scrollToView(clinictimeError);
	    	 break;	
	    case "Cliniclegaljurisdiction":
	    	
	    	 fieldError(jurisdictionError);
	    	 scrollToView(jurisdictionError);
	    	 break;		 
	    	 
	    case "UserID":
	    	
	    	 fieldError(useridError);
	    	 scrollToView(useridError);
	    	 break;		 
	    case "Password":
	    	
	    	 fieldError(passwordError);
	    	 scrollToView(passwordError);
	    	 break;	
	    case "ConfirmNewPassword":
	    	
	    	 fieldError(newPasswordError);
	    	 scrollToView(newPasswordError);
	    	 break;
	    case "Firstname":
	    	
	    	
	    	 fieldError(firstnameError);
	    	 scrollToView(firstnameError);
	    	 break;	
	    	 
	    case "Lastname":
	    	
	    	 fieldError(lastnameError);
	    	 scrollToView(lastnameError);
	    	 break;	
	  
	   
	    }    
	   
	}    
	
	
	
	public void addcustomerclick() throws InterruptedException
	{
		//refresh();
		clickOnElementUsingJs(addACustomer_OR,addACustomer_S);
		presenceOfElementLocatedWithoutReport(Recordpatientdatacollectionconsent_OR,Recordpatientdatacollectionconsent_S);
		
	}
	public void generalFeautreControlscomponents() throws InterruptedException
	{

		scrollToViewWithoutReport(Recordpatientdatacollectionconsent_OR,Recordpatientdatacollectionconsent_S);
		assertion.assertEqualsWithReporting(true, isElementPresent(Recordpatientdatacollectionconsent_OR,Recordpatientdatacollectionconsent_S), extentReport, "Record patient data collection consent");
		assertion.assertEqualsWithReporting(true,isElementPresent(AllowMobileDirectAlertsnotifications_OR,AllowMobileDirectAlertsnotifications_S), extentReport, "Allow Mobile Direct Alerts notifications");
		assertion.assertEqualsWithReporting(true, isElementPresent(AllowaccesstoCommunicationCenter_OR,AllowaccesstoCommunicationCenter_S), extentReport, "Allow access to Communication Center");
		assertion.assertEqualsWithReporting(true, isElementPresent(AllowaccesstoComplianceReport_OR,AllowaccesstoComplianceReport_S), extentReport, "Allow access to Compliance Report");
		 extentReport.reportScreenShot("General Feautre Controls Components") ;
		
	}
	
	public void customerHeadquarters_Section_Stripe() throws InterruptedException
	{
		isElementPresent(HeadquartersSection_OR);
		scrollToViewWithReport(HeadquartersSection_OR,HeadquartersSection_S);
		  assertion.assertEqualsWithReporting(true, isElementPresent(HeadquartersSection_OR,HeadquartersSection_S), extentReport, "Customer Headquarters section stripe is displayed");
		  extentReport.reportScreenShot("HeadquartersSection") ;
		
		
	}
	
	public void customerNameFieldValidation() throws InterruptedException
	{
		     String textnull=getAttributeWithReport(customerName_OR, "value",customerName_S);
		     extentReport.reportScreenShot("CustomerName is defaults to empty/null") ;
	         assertion.assertEquals("", textnull, "CustomerName is defaults to empty/null");
		     assertion.assertEqualsWithReporting(true, isElementPresent(customerName_OR,customerName_S), extentReport, "Customer Name is displayed");
		   loading();
		   
	}
	public void customerNameLength(int length) throws InterruptedException
	{
		sendKeys(customerName_OR,customerName_S, CommonUtils.randomText(length));
		extentReport.reportScreenShot("CustomerName with length "+length+" is entered ") ;
		   
	}
	public void customerNameLengthValidation() throws Exception
	{
	String text=getAttributeWithReport(customerName_OR, "value",customerName_S);
	extentReport.reportScreenShot("CustomerName with length Validation ") ;
    clear(customerName_OR,customerName_S);  
	assertion.assertEqualsWithReporting(true, FieldMaxlength("50",customerName_OR,text), extentReport, "Customer Name MaxLength Input Textbox check");
	}
	public void customerTypeDropdownValidation() throws Exception
	{
		   ArrayList options= DropdowngetOptions(customerTypeclick_OR,customerTypeoptions);
		   System.out.println(options);
		   ArrayList customertype=new ArrayList();
		   customertype.add("Direct");
		   customertype.add("Service Provider");
		   boolean boolval = customertype.equals(options);
		   assertion.assertEqualsWithReporting(true, boolval, extentReport, "Customer Type Drop down Values are "+options);
		   clickElement(customerTypeoption_OR,customerTypeoption_S);
	}
	public void addcustomerclickurl() throws InterruptedException
	{
		getURL(CommonUtils.url);
		loading();
		clickElement(addACustomer_OR,addACustomer_S);
		
	}
	public void addcustomerurl() throws InterruptedException
	{
		getURL(CommonUtils.url);
		loading();
		
		
	}
	
	Assertions assertion =  new Assertions(extentTest);
	public void pageElementValidation() throws InterruptedException
	{
		loadingWithoutReport();
		assertion.assertEqualsWithReporting(true, isElementPresentwithoutException(Recordpatientdatacollectionconsent_OR,Recordpatientdatacollectionconsent_S), extentReport, "Record patient data collection consent");
		assertion.assertEqualsWithReporting(true, isElementPresentwithoutException(AllowMobileDirectAlertsnotifications_OR,AllowMobileDirectAlertsnotifications_S), extentReport, "Allow Mobile Direct Alerts notifications");
		assertion.assertEqualsWithReporting(true, isElementPresentwithoutException(AllowaccesstoCommunicationCenter_OR,AllowaccesstoCommunicationCenter_S), extentReport, "Allow access to Communication Center");
		assertion.assertEqualsWithReporting(true, isElementPresentwithoutException(AllowaccesstoComplianceReport_OR,AllowaccesstoComplianceReport_S), extentReport, "Allow access to Compliance Report");
	
	}
	
	public String generateCustomerName() {
		CommonUtils reuse=new CommonUtils();
		customerNameValue=reuse.randomCustomerName();		
		return customerNameValue;		
	}
	
	public void seletCustType(Customer customer) {
		try {
			scrollToView(customerTypeclick_OR);
			presenceOfElementLocatedWithReport(customerTypeclick_OR,customerTypeclick_S);
			elementToBeClickable(customerTypeclick_OR,customerTypeclick_S);
			//clickElement(customerTypeclick);
//			waitForLoading();
			clickElement(customerTypeclick_OR,customerTypeclick_S);
			if(customer.getCustomerType().equalsIgnoreCase("direct")) {
				elementToBeClickable(directCustomerType_OR,directCustomerType_S);
				clickElement(directCustomerType_OR,directCustomerType_S);
			}else if(customer.getCustomerType().equalsIgnoreCase("sp2")) {
				elementToBeClickable(sp2CustomerType_OR,sp2CustomerType_S);
				clickElement(sp2CustomerType_OR,sp2CustomerType_S);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public String EnterValueandSaveCustomer(String cutomername,String userid,String customerTypeValue, String clinicLocationValue,
			String countryCodeValue, String areaCodeValue, String mainPhoneValue, String countryValue,
			String emailValue, String clinicTimeZoneValue, String legalJurisdictionValue, String clinicLanguageValue,
			String newPasswordValue, String confirmNewPasswordValue, String firstNameValue,
			String lastNameValue, String emailIdValue, String ElecExportValue) throws Exception {
		
		try {
			addcustomer=false;
		    customerNameValue =cutomername;
		    		//CommonUtils.randomCustomerName();
			userIdValue =userid;
			//CommonUtils.randomUserId();
			System.out.println("customerNameValue@@@"+customerNameValue);
			System.out.println("userIdValue@@@"+userIdValue);
			extentReport.reportPass( "The actor clicks the Add a customer button ");
			
			if (verifyLandingPage()) {
				waitForLoading();
				presenceOfElementLocated(customerName);
				sendKeys(customerName, customerNameValue);
				waitForLoading();
			
				extentReport.reportPass( "The system displays Add Customer Page");
				presenceOfElementLocated(customerType);
				clickElement(customerType);
				presenceOfElementLocated(customerTypeText);
				clickElement(customerTypeText);

				extentReport.reportPass("Enter valid and required information in the Customer headquarters section");
				presenceOfElementLocated(clinicLocation);
				sendKeys(clinicLocation, clinicLanguageValue);
				presenceOfElementLocated(countryCode);
				clear(countryCode);
				sendKeys(countryCode, countryCodeValue);
				presenceOfElementLocated(areaCode);
				clear(areaCode);
				sendKeys(areaCode, areaCodeValue);
				presenceOfElementLocated(mainPhone);
				sendKeys(mainPhone, mainPhoneValue);
				presenceOfElementLocated(country);
				elementToBeClickable(country);
				clickElement(country);
				sendKeys(countryTextBox, countryValue);
				clickElement(countryText);
				presenceOfElementLocated(email);
				sendKeys(email, emailValue);
				presenceOfElementLocated(clinicTimeZone);
				clickElement(clinicTimeZone);
				sendKeys(clinicTimeZoneTextBox, clinicTimeZoneValue);
				clickElement(countryText);
				
				if (legalJurisdictionValue.equalsIgnoreCase("United States")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_US);
		            clickOnElementUsingJs(legalJurisdictionText_US);
		            extentReport.reportPass( "Updated Legal Jurisdiction as United States");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Japan")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Japan);
		            clickOnElementUsingJs(legalJurisdictionText_Japan);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Japan");
		            waitForLoading();
		        } else if (legalJurisdictionValue.contains("Australia")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Australia);
		            clickOnElementUsingJs(legalJurisdictionText_Australia);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Australia");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Canada")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Canada);
		            clickOnElementUsingJs(legalJurisdictionText_Canada);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Canada");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Europe")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Europe);
		            clickOnElementUsingJs(legalJurisdictionText_Europe);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Europe");
		            waitForLoading();
		        }
				
				
				
				waitForLoading();
			
				presenceOfElementLocated(clinicLanguage);
				elementToBeClickable(clinicLanguage);
				clickElement(clinicLanguage);
				sendKeys(clinicLanguageTextBox, clinicLanguageValue);
				clickElement(clinicLanguageText);
				
				presenceOfElementLocated(testClinicCheckBox);
				clickElement(testClinicCheckBox);
				extentReport.reportPass( "Enter valid and required information in the Clinic Information section");
				presenceOfElementLocated(userId);
				sendKeys(userId, userIdValue);
				presenceOfElementLocated(password);
				sendKeys(password, newPasswordValue);
				presenceOfElementLocated(confirmNewPassword);
				sendKeys(confirmNewPassword, confirmNewPasswordValue);
				presenceOfElementLocated(firstName);
				sendKeys(firstName, firstNameValue);
				presenceOfElementLocated(lastName);
				sendKeys(lastName, lastNameValue);
				presenceOfElementLocated(emailId);
				sendKeys(emailId, emailIdValue);
				extentReport.reportPass( "Enter valid and required information in the Clinic Main Contact section");
				presenceOfElementLocated(recordPatientDataCheckBox);
				clickElement(recordPatientDataCheckBox);

		
				scrollDown();
				waitForLoading();
				presenceOfElementLocated(addCustomerSave_OR);
				clickOnElementUsingJs(addCustomerSave_OR);
				
				waitForLoading();
				invisibilityOfElementLocated(pageLoading);
				invisibilityOfElementLocated(pageLoading);
				String successMessage = "empty";
				if (isElementPresent(message))
				{
				successMessage=getText(message);
				clickElement(messageclose);
				System.out.println(successMessage);
				}
				return successMessage;
			}
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
		return customerNameValue;
}
	
	public String EnterMiddleName(String middleNameValue) {
		sendKeys(this.middleName,middleNameValue);
		return getText(middleName);
	}
	//shafiya added this xpath and method for entering values in non mandatory fields
	private final By stateTextBox_OR = By.xpath("//input[@placeholder='Search...']");
	private final String stateTextBox_S = "State/Province Text Box";
	private final By credentialsArrow_OR = By.xpath("//mat-select[@id='dd_customer-clinic-main-contact_credentialsCd']//div[contains(@class,'mat-select-arrow ng')]");
	private final String credentialsArrow_S = "Credentials Arrow";
	private final By credentials_Dropdown_DOValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[1]");
	private final String credentials_Dropdown_DOValue_S = "Credentials dropdown 'DO' Value";
	private final By credentials_Dropdown_LPNValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[2]");
	private final String credentials_Dropdown_LPNValue_S = "Credentials dropdown 'LPN' Value";
	private final By credentials_Dropdown_LVNValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[3]");
	private final String credentials_Dropdown_LVNValue_S = "Credentials dropdown 'LVN' Value";
	private final By credentials_Dropdown_MDValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[4]");
	private final String credentials_Dropdown_MDValue_S = "Credentials dropdown 'MD' Value";
	private final By credentials_Dropdown_MSNValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[5]");
	private final String credentials_Dropdown_MSNValue_S = "Credentials dropdown 'MSN' Value";
	private final By credentials_Dropdown_PAValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[6]");
	private final String credentials_Dropdown_PAValue_S = "Credentials dropdown 'PA' Value";
	private final By credentials_Dropdown_PSNValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[7]");
	private final String credentials_Dropdown_PSNValue_S = "Credentials dropdown 'PSN' Value";
	private final By credentials_Dropdown_RNValue_OR = By.xpath("//div[@id='dd_customer-clinic-main-contact_credentialsCd-panel']/mat-option[8]");
	private final String credentials_Dropdown_RNValue_S = "Credentials dropdown 'RN' Value";
	private final By fax_Country_Code_OR = By.xpath("(//*[@controlname='countryCode']/mat-form-field/div/div/div/input)[3]");
	private final String fax_Country_Code_S = "Fax Country Code";
	private final By fax_AreaCode_OR = By.xpath("(//*[@controlname='areaCode']/mat-form-field/div/div/div/input)[3]");
	private final String fax_AreaCode_S = "Fax Area Code";
	
	public void EnterValuesForNonMandatoryfields(String address1, String address2, String address3, String stateOrProvValue,
			String cityValue, String postalCodeValue, String secondaryPhoneCountryCodeValue, String secondaryPhoneAreaCodeValue, 
			String secondaryPhoneValue, String faxCountryCodeValue, String faxAreaCodeValue, String faxValue, String textMsgValue, String middleNameValue,
			String credentialsValue) throws Exception {
		
		try {	
			if(address1!=null && !address1.equals("")) {
				presenceOfElementLocatedWithoutReport(clinicAddress_1_OR, clinicAddress_1_S);
				sendKeys(clinicAddress_1_OR, clinicAddress_1_S, address1);
			}
			if(address2!=null && !address2.equals("")) {	
				presenceOfElementLocatedWithoutReport(clinicAddress_2_OR, clinicAddress_2_S);
				sendKeys(clinicAddress_2_OR, address2);
			}
			if(address3!=null && !address3.equals("")) {	
				presenceOfElementLocatedWithoutReport(clinicAddress_3_OR, clinicAddress_3_S );
				sendKeys(clinicAddress_3_OR, address3);
			}
			if(stateOrProvValue!=null && !stateOrProvValue.equals("")) {
				presenceOfElementLocatedWithoutReport(stateProvinceDropDown_OR,stateProvinceDropDown_S );
				elementToBeClickable(stateProvinceDropDown_OR, stateProvinceDropDown_S);
				clickElement(stateProvinceDropDown_OR, stateProvinceDropDown_S);
				sendKeys(stateTextBox_OR, stateTextBox_S, stateOrProvValue);
				clickElement(countryText);
			}
			if(cityValue!=null && !cityValue.equals("")) {	
				presenceOfElementLocatedWithoutReport(clinicCity_OR, clinicCity_S);
				sendKeys(clinicCity_OR, clinicCity_S, cityValue);
			}
			if(postalCodeValue!=null && !postalCodeValue.equals("")) {	
				presenceOfElementLocatedWithoutReport(zipPostalCode_OR, zipPostalCode_S);
				sendKeys(zipPostalCode_OR, zipPostalCode_S, postalCodeValue);
			}
			if(secondaryPhoneCountryCodeValue!=null && !secondaryPhoneCountryCodeValue.equals("")) {
				presenceOfElementLocatedWithoutReport(secondarycountryCode_OR, secondarycountryCode_S);
				clear(secondarycountryCode_OR);
				sendKeys(secondarycountryCode_OR, secondarycountryCode_S, secondaryPhoneCountryCodeValue);
			}
			if(secondaryPhoneAreaCodeValue!=null && !secondaryPhoneAreaCodeValue.equals("")) {
				presenceOfElementLocatedWithoutReport(secondaryAreaCode_OR, secondaryAreaCode_S);
				clear(secondaryAreaCode_OR);
				sendKeys(secondaryAreaCode_OR, secondaryAreaCode_S, secondaryPhoneAreaCodeValue);
			}
			if(secondaryPhoneValue!=null && !secondaryPhoneValue.equals("")) {
				presenceOfElementLocatedWithoutReport(secondaryMainPhone_OR, secondaryMainPhone_S);
				sendKeys(secondaryMainPhone_OR, secondaryMainPhone_S, secondaryPhoneValue);
			}
			if(faxCountryCodeValue!=null && !faxCountryCodeValue.equals("")) {	
				presenceOfElementLocatedWithoutReport(fax_Country_Code_OR, fax_Country_Code_S);
				clear(fax_Country_Code_OR);
				sendKeys(fax_Country_Code_OR, fax_Country_Code_S, faxCountryCodeValue);
			}
			if(faxAreaCodeValue!=null && !faxAreaCodeValue.equals("")) {
				presenceOfElementLocatedWithoutReport(fax_AreaCode_OR, fax_AreaCode_S );
				clear(fax_AreaCode_OR);
				sendKeys(fax_AreaCode_OR, fax_AreaCode_S, faxAreaCodeValue);
			}
			if(faxValue!=null && !faxValue.equals("")) {
				presenceOfElementLocatedWithoutReport(faxNumber_OR,faxNumber_S );
				sendKeys(faxNumber_OR, faxNumber_S, faxValue);
			}
			if(textMsgValue!=null && !textMsgValue.equals("")) {				
				presenceOfElementLocatedWithoutReport(textMessage_OR, textMessage_S);
				sendKeys(textMessage_OR, textMessage_S, textMsgValue);
			}
			if(middleNameValue!=null && !middleNameValue.equals("")) {
				presenceOfElementLocated(middleName);
				sendKeys(middleName, middleNameValue);
			}
				
			selectCredentials(credentialsValue);
				
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
		
}
	//Added by shafiya
	public void selectCredentials(String credentialsValue) throws Exception{
		try {
			presenceOfElementLocatedWithoutReport(credentialsArrow_OR,credentialsArrow_S );
			elementToBeClickable(credentialsArrow_OR, credentialsArrow_S);
			clickElement(credentialsArrow_OR, credentialsArrow_S);
			switch(credentialsValue) {				
				case "DO":
					clickElement(credentials_Dropdown_DOValue_OR, credentials_Dropdown_DOValue_S);	            
					break;
				case "LPN":
					clickElement(credentials_Dropdown_LPNValue_OR, credentials_Dropdown_LPNValue_S);
					break;
				case "LVN":
					clickElement(credentials_Dropdown_LVNValue_OR, credentials_Dropdown_LVNValue_S);		          
					break;
				case "MD":
					clickElement(credentials_Dropdown_MDValue_OR, credentials_Dropdown_MDValue_S);		           
					break;
				case "MSN":
					clickElement(credentials_Dropdown_MSNValue_OR, credentials_Dropdown_MSNValue_S);		           
					break;
				case "PA":
					clickElement(credentials_Dropdown_PAValue_OR, credentials_Dropdown_PAValue_S);		            
					break;
				case "PSN":
					clickElement(credentials_Dropdown_PSNValue_OR, credentials_Dropdown_PSNValue_S);		           
					break;
				case "RN":
					clickElement(credentials_Dropdown_RNValue_OR, credentials_Dropdown_RNValue_S);		            
					break;
			}
		}  catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}

	public String EnterValueAllfields(String cutomername,String userid,String customerTypeValue, String clinicLocationValue,
			String countryCodeValue, String areaCodeValue, String mainPhoneValue, String countryValue,
			String emailValue, String clinicTimeZoneValue, String legalJurisdictionValue, String clinicLanguageValue,
			String newPasswordValue, String confirmNewPasswordValue, String firstNameValue,
			String lastNameValue, String emailIdValue, String ElecExportValue) throws Exception {
		
		try {
			addcustomer=false;
		    customerNameValue =cutomername;
		    		//CommonUtils.randomCustomerName();
			userIdValue =userid;
			//CommonUtils.randomUserId();
			System.out.println("customerNameValue@@@"+customerNameValue);
			System.out.println("userIdValue@@@"+userIdValue);
			extentReport.reportPass( "The actor clicks the Add a customer button ");
			
			if (verifyLandingPage()) {
				waitForLoading();
				presenceOfElementLocated(customerName);
				sendKeys(customerName, customerNameValue);
				waitForLoading();
			
				extentReport.reportPass( "The system displays Add Customer Page");
				presenceOfElementLocated(customerType);
				clickElement(customerType);
				presenceOfElementLocated(customerTypeText);
				clickElement(customerTypeText);

				extentReport.reportPass("Enter valid and required information in the Customer headquarters section");
				presenceOfElementLocated(clinicLocation);
				sendKeys(clinicLocation, clinicLanguageValue);
				presenceOfElementLocated(countryCode);
				clear(countryCode);
				sendKeys(countryCode, countryCodeValue);
				presenceOfElementLocated(areaCode);
				clear(areaCode);
				sendKeys(areaCode, areaCodeValue);
				presenceOfElementLocated(mainPhone);
				sendKeys(mainPhone, mainPhoneValue);
								
				presenceOfElementLocated(country);
				elementToBeClickable(country);
				clickElement(country);
				sendKeys(countryTextBox, countryValue);
				clickElement(countryText);
				//shafiya changed xpath of email
				presenceOfElementLocated(email);
				sendKeys(email, emailValue);
				presenceOfElementLocated(clinicTimeZone);
				clickElement(clinicTimeZone);
				sendKeys(clinicTimeZoneTextBox, clinicTimeZoneValue);
				clickElement(countryText);
				
				if (legalJurisdictionValue.equalsIgnoreCase("United States")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_US);
		            clickOnElementUsingJs(legalJurisdictionText_US);
		            extentReport.reportPass( "Updated Legal Jurisdiction as United States");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Japan")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Japan);
		            clickOnElementUsingJs(legalJurisdictionText_Japan);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Japan");
		            waitForLoading();
		        } else if (legalJurisdictionValue.contains("Australia")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Australia);
		            clickOnElementUsingJs(legalJurisdictionText_Australia);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Australia");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Canada")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Canada);
		            clickOnElementUsingJs(legalJurisdictionText_Canada);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Canada");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Europe")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Europe);
		            clickOnElementUsingJs(legalJurisdictionText_Europe);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Europe");
		            waitForLoading();
		        }
				
				
				
				waitForLoading();
			
				presenceOfElementLocated(clinicLanguage);
				elementToBeClickable(clinicLanguage);
				clickElement(clinicLanguage);
				sendKeys(clinicLanguageTextBox, clinicLanguageValue);
				clickElement(clinicLanguageText);
				
				presenceOfElementLocated(testClinicCheckBox);
				clickElement(testClinicCheckBox);
				extentReport.reportPass( "Enter valid and required information in the Clinic Information section");
				presenceOfElementLocated(userId);
				sendKeys(userId, userIdValue);
				presenceOfElementLocated(password);
				sendKeys(password, newPasswordValue);
				presenceOfElementLocated(confirmNewPassword);
				sendKeys(confirmNewPassword, confirmNewPasswordValue);
				presenceOfElementLocated(firstName);
				sendKeys(firstName, firstNameValue);
				
				
				presenceOfElementLocated(lastName);
				sendKeys(lastName, lastNameValue);
				presenceOfElementLocated(emailId);
				sendKeys(emailId, emailIdValue);
				extentReport.reportPass( "Enter valid and required information in the Clinic Main Contact section");
				presenceOfElementLocated(recordPatientDataCheckBox);
				clickElement(recordPatientDataCheckBox);
	
			}
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
		return customerNameValue;
}
	
	//Rajesh Singaraj -12/01/2022
	public void addCustomerHeadQuarters(Customer customer) throws Exception 
	{
		presenceOfElementLocatedWithReport(customerName_OR,customerName_S);
		sendKeys(customerName_OR, customer.getCustomerName());
	}
	
	public void verifyClinicLocation() throws InterruptedException 
	{
		presenceOfElementLocatedWithReport(clinicLocation_OR,clinicLocation_S);
		assertion.assertTrue(isEmpty(clinicLocation_OR,clinicLocation_S),"Clinic location field is empty");
		assertion.assertTrue(drivUtil.isElementPresent(clinicLocation_OR,clinicLocation_S),"Clinic location field is enabled");
		extentReport.reportScreenShot("Clinic (HQ) Location data entry field is active, is displayed, is a required field, defaults to empty/null value.");
	}

	public Boolean isEmpty(By element, String value) {
		Boolean flag = false;
		try {
			visibilityOfElementLocatedWithReport(element, value);
			String text = driver.findElement(element).getAttribute("value");
			if (text == null || text.isEmpty()) {
				extentReport.info(value + "is displayed");
				flag = true;
			}
			return flag;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	

	public int getLength(By element) {
		try {
			visibilityOfElementLocated(element);
			int length = driver.findElement(element).getAttribute("value").length();
			return length;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}
	  
	  public void SelectValueFromDropDown(By element1, By element2, By element3, String value) throws InterruptedException {
		  try { 
			  scrollToView(element1);
			  waitForLoading();
			  clickElement(element1);
			  sendKeys(element2, value);
			  waitForLoading();
			  clickElement(element3);
		  }
		  catch (WebDriverException e) { 
			  throw new WebDriverException(e.getMessage());
		  }
	  }
	 


	public void enterValueInField(String type, Customer customer) throws InterruptedException {
		switch(type) {
		case "verifyClinicLocation":
			presenceOfElementLocatedWithReport(clinicLocation_OR,clinicLocation_S); 
			sendKeys(clinicLocation_OR,clinicLocation_S, customer.getLengthyClinicLocationName());
			break;
		case "verifyClinicAddress":
			presenceOfElementLocatedWithReport(clinicAddress_1_OR,clinicAddress_1_S); 
			sendKeys(clinicAddress_1_OR,clinicAddress_1_S, customer.getLengthyAddressField());
			break;
		case "clinicAddress_1":
			presenceOfElementLocatedWithReport(clinicAddress_1_OR,clinicAddress_1_S); 
			sendKeys(clinicAddress_1_OR,clinicAddress_1_S, customer.getAddress1());
			break;
		case "verifyCliniCity":
			presenceOfElementLocatedWithReport(clinicCity_OR,clinicCity_S); 
			sendKeys(clinicCity_OR,clinicCity_S, customer.getLengthyClinicCity());
			break;
		case "cliniCity":
			presenceOfElementLocatedWithReport(clinicCity_OR,clinicCity_S); 
			sendKeys(clinicCity_OR,clinicCity_S, customer.getCity());
			break;
		case "clinicCountryCode":
			presenceOfElementLocatedWithReport(countryCode_OR,countryCode_S); 
			sendKeys(countryCode_OR,countryCode_S, customer.getCountryCode());
			break;
		case "emptyAreaCode":
			presenceOfElementLocatedWithReport(areaCode_OR,areaCode_S); 
			sendKeys(areaCode_OR,areaCode_S, "");
			break;
		case "clinicAreaCode":
			presenceOfElementLocatedWithReport(areaCode_OR,areaCode_S); 
			sendKeys(areaCode_OR,areaCode_S, customer.getAreaCode());
			break;
		case "clinicMainPhone":
			presenceOfElementLocatedWithReport(mainPhone_OR,mainPhone_S); 
			sendKeys(mainPhone_OR,mainPhone_S, customer.getMainPhone());
			break;
		case "clinicZipCode":
			presenceOfElementLocatedWithReport(zipPostalCode_OR,zipPostalCode_S); 
			sendKeys(zipPostalCode_OR,zipPostalCode_S, customer.getZipPostalCode());
			break;
		case "clinicSecCountryCode":
			presenceOfElementLocatedWithReport(secondarycountryCode_OR,secondarycountryCode_S); 
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, customer.getCountryCode());
			break;
		case "clinicSecAreaCode":
			presenceOfElementLocatedWithReport(secondaryAreaCode_OR,secondaryAreaCode_S); 
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, customer.getAreaCode());
			break;
		case "clinicSecMainPhone":
			presenceOfElementLocatedWithReport(secondaryMainPhone_OR,secondaryMainPhone_S); 
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, customer.getMainPhone());
			break;
		case "clinicFaxCountryCode":
			presenceOfElementLocatedWithReport(faxCountryCode_OR,faxCountryCode_S); 
			sendKeys(faxCountryCode_OR,faxCountryCode_S, customer.getCountryCode());
			break;
		case "clinicFaxAreaCode":
			presenceOfElementLocatedWithReport(faxAreaCode_OR,faxAreaCode_S); 
			sendKeys(faxAreaCode_OR,faxAreaCode_S, customer.getAreaCode());
			break;
		case "clinicFaxMainPhone":
			presenceOfElementLocatedWithReport(faxNumber_OR,faxNumber_S); 
			sendKeys(faxNumber_OR,faxNumber_S, customer.getMainPhone());
			break;
		case "clinicEmail":
			presenceOfElementLocatedWithReport(email_OR,email_S); 
			sendKeys(email_OR,email_S, customer.getEmailId());	
			break;
		case "VerifyEmail":
			presenceOfElementLocatedWithReport(email_OR,email_S); 
			sendKeys(email_OR,email_S, customer.getLengthyEmailAddress());			
			break;		
		case "ClinicState":
			presenceOfElementLocatedWithReport(stateDownArrow_OR,stateDownArrow_S); 
			SelectValueFromDropDown(stateDownArrow_OR,countryTextBox_OR,stateFirstValue_OR, customer.getStateProvince());			
			break;
		case "ClinicCountry":
			presenceOfElementLocatedWithReport(countryDownArrow_OR,countryDownArrow_S); 
			SelectValueFromDropDown(countryDownArrow_OR,countryTextBox_OR,countryFirstValue_OR, customer.getCountry());				
			break;
		case "ClickEmailID": 
			presenceOfElementLocatedWithReport(email_OR,email_S); 
			sendKeys(email_OR, email_S, customer.getEmailId());				
			break;
	}
	
	
}

	public void verifyLengthyClinicLocation()
	{
		int length = getLength(clinicLocation_OR);
		assertion.assertEquals(length, 30,"It allows only 30 characters in Clinic Location field");
		extentReport.reportScreenShot("System dose not allow entering more than 30 characters.");
	}

	public void verifyClinicLocation(Customer customer) {
		drivUtil.clear(clinicLocation_OR,clinicLocation_S);

		scrollToView(addCustomerSave_OR);
		clickElement(addCustomerSave_OR,addCustomerSave_S);
		String alert=getText(clinicLocationAlertMsg_OR,clinicLocationAlertMsg_S);
		assertion.assertEquals("This field should not be empty... ",alert, "Alert message for Clinic Location is displayed when it is empty");		

		drivUtil.clickElement(addCustomerSave_OR);
		assertion.assertEquals(true, drivUtil.getText(clinicLocationAlertMsg_OR,clinicLocationAlertMsg_S),"Alert message for Clinic Location is displayed when it is empty");		

		sendKeys(clinicLocation_OR,clinicLocation_S, customer.getClinicLocation());
		extentReport.reportScreenShot("CS 818 is displayed with message that Clinic Location is a mandatory field");
	} 
	
	public void verifyAllAddressInfoFieldsDisplayed() throws InterruptedException {
		
		assertion.assertEquals(true, drivUtil.isElementPresent(clinicAddress_1_OR,clinicAddress_1_S),"Clinic Address field 1 is displayed");
		assertion.assertEquals(true, drivUtil.isElementPresent(clinicAddress_2_OR,clinicAddress_2_S),"Clinic Address field 2 is displayed");
		assertion.assertEquals(true, drivUtil.isElementPresent(clinicAddress_3_OR,clinicAddress_3_S),"Clinic Address field 3 is displayed");
		assertion.assertEquals(true, drivUtil.isElementPresent(clinicCity_OR,clinicCity_S),"Clinic City is displayed");
		assertion.assertEquals(true, drivUtil.isElementPresent(stateProvinceDropDown_OR,stateProvinceDropDown_S ),"Clinic state is displayed");
		assertion.assertEquals(true, drivUtil.isElementPresent(zipPostalCode_OR,zipPostalCode_S),"Clinic zip code is displayed");
		assertion.assertEquals(true, drivUtil.isElementPresent(country_OR,country_S),"Clinic country is displayed");		
		extentReport.reportScreenShot("Address Line One , Address Line Two,  Address Line Three, Country, City, State/Province , Zip/Postal Code are displayed");
	}
	
	
	  public void verifyFieldsEmpty() {
	  
	  presenceOfElementLocatedWithReport(clinicAddress_1_OR,clinicAddress_1_S); 
	  assertion.assertEquals(true,isEmpty(clinicAddress_1_OR,clinicAddress_1_S),"Clinic address 1 is displayed");
	  presenceOfElementLocatedWithReport(clinicAddress_2_OR,clinicAddress_2_S); assertion.assertEquals(true,
	  isEmpty(clinicAddress_2_OR,clinicAddress_2_S),"Clinic address 2 is displayed");
	  presenceOfElementLocatedWithReport(clinicAddress_3_OR,clinicAddress_3_S); assertion.assertEquals(true,
	  isEmpty(clinicAddress_3_OR,clinicAddress_3_S),"Clinic address 3 is displayed"); 
	  }
	  
  public void verifyFieldsDisplayedEnabledAndEmpty(String type){
	  switch(type) {
	  case "clinicAddress":
		  verifyFieldsDisplayedEnabledAndEmpty(clinicAddress_1_OR,"Clinic Address 1");
		  verifyFieldsDisplayedEnabledAndEmpty(clinicAddress_2_OR,"Clinic Address 2");
		  verifyFieldsDisplayedEnabledAndEmpty(clinicAddress_3_OR,"Clinic Address 3");
		  extentReport.reportScreenShot("Address data entry fields (3 lines) are active, are displayed, default value is blank/null");
		  break;
	  case "clinicCity":
		  verifyFieldsDisplayedEnabledAndEmpty(clinicCity_OR,"Clinic city");
		  break;
	  case "clinicState":
		  verifyFieldsDisplayedEnabledAndEmpty(stateProvinceDropDown_OR,"Clinic state/Province");
		  extentReport.reportScreenShot("State/Province dropdown field is active, is displayed, defaults to empty/null value");
		  break;
	  case "clinicCountry":
		  verifyFieldsDisplayedEnabledAndEmpty(country_OR,"Clinic country");
		  extentReport.reportScreenShot("Country dropdown field is active, is displayed, and that the actor can enter a value from the dropdown selection list.");
		  break;
	  case "clinicZipCode":
		  verifyFieldsDisplayedEnabledAndEmpty(zipPostalCode_OR,"Clinic zip code");
		  break;
	  case "clinicMainPhone":
		  verifyFieldsDisplayedEnabledAndEmpty(mainPhone_OR,"Clinic main phone");
		  break;
	  case "clinicSecCountryCode":
		  verifyFieldsDisplayedEnabledAndEmpty(secondarycountryCode_OR, "Secondary country code");
		  break;
	  case "clinicSecAreaCode":
		  verifyFieldsDisplayedEnabledAndEmpty(secondaryAreaCode_OR, "Secondary Area code");
		  break;
	  case "clinicSecMainPhone":
		  verifyFieldsDisplayedEnabledAndEmpty(secondaryMainPhone_OR,"Clinic secondary main phone");
		  break;
	  case "clinicFaxNumber":
		  verifyFieldsDisplayedEnabledAndEmpty(faxnumber_OR,"clinic fax number");
		  break;
	  case "clinicfaxCountryCode":
		  verifyFieldsDisplayedEnabledAndSelected(faxCountryCode_OR, "fax country code");
		  break;
	  case "clinicFaxAreaCode":
		  verifyFieldsDisplayedEnabledAndSelected(faxAreaCode_OR, "fax Area code");
		  break;
	  case "clinicEmail":
		  verifyFieldsDisplayedEnabledAndEmpty(email_OR,"Email address field");
		  break;
	  case "clinicTextMessage":
		  verifyFieldsDisplayedEnabledAndEmpty(textMessage_OR, "Text message");
		  break;
	  case "clinicTimeZone":
		  verifyFieldsDisplayedEnabledAndEmpty(clinicTimeZone_OR, "Clinic Timezone");
		  break;
	  case "clinicLanguage":
		  verifyFieldsDisplayedEnabledAndEmpty(clinicLanguage_OR, "Clinic language");
		  break;
	  case "legalJurisdictionText":
		  verifyFieldsDisplayedEnabledAndEmpty(legalJurisdictionText_OR, "Clinic Jurisdiction");
		  break;
	  case "testClinicCheckBox":
		  verifyFieldsDisplayedEnabledAndSelected(testClinicCheckBox,"Test Clinic");
		  break;
	  }
  }

public void verifyDropDownValuesWithDOOR(String type, Customer customer) {
	switch(type) {
	case "state":
		verifyStateDropDownValuesWithDOOR(stateProvinceDropDown_OR,customer.getStateProvinceVerification());
		break;
	case "country":
		verifyCountryDropDownValuesWithDOOR(country_OR,customer.getCountryVerification());
		break;
	case "timezone":
		verifyTimeZoneDropDownValuesWithDOOR(clinicTimeZone_OR, customer.getTimeZoneVerification());
		break;
	}
}

public void keyboardActions(Keys key) {
	
	Actions act= new Actions(drivUtil.driver);
	act.sendKeys(key).build().perform();
	//act.keyUp(key).build().perform();	
}
	
public void verifyFieldsDisplayedEnabledAndEmpty(By object, String element) {
		
		presenceOfElementLocatedWithReport(object,element);
		assertion.assertEquals(true, drivUtil.isElementPresent(object,element), element+" is enabled");
		assertion.assertEquals(true, isEmpty(object,element),element+" is empty");
}
public void verifyFieldsDisplayedEnabledAndSelected(By object, String element) {
	
	presenceOfElementLocatedWithReport(object,element);
	assertion.assertEquals(true, drivUtil.isElementPresent(object, element), element+" is enabled");
	assertion.assertEquals(true, drivUtil.isSelectedWithReport(object,element),element+" is empty");
}

	public void verifyLength(By object, int length) {
		
		int Addresslength = getLength(object);
		assertion.assertEquals(Addresslength, length);
	}
	public void verifyDefaultValueOfState() {
		
		String DDoptions = getText(country_OR);
		if (DDoptions.equals("USA")) {
			extentReport.info("Drop-down Entry Field if in Entry Mode and the Country Field is currently set to the value corresponding to the United States.");
		}
		/*
		 * String StateDDoptions = getText(selectedState_OR); if
		 * (StateDDoptions.equals("")) { extentReport.
		 * info("It Should not display any existing State/Province value if previously does not enter. It sould ne an empty field"
		 * ); } else { extentReport.
		 * info("It Should display existing State/Province value if previously entered "
		 * ); }
		 */		
	}
	
	public void verifyInvalidZipCode() {
		
		ArrayList<String> cars = new ArrayList<String>();
		cars.add("V3C 4X1");
		cars.add("123");
		cars.add("123456");
		cars.add("%1234");
		cars.add("\1234567");
		cars.add("33456789");
		cars.add("\"/`~!@#$%^&*()_+={}[ ]\\:\";'<>?,A-Z,a-z.");
		cars.add("3345678998");		
		for (int i = 0; i < cars.size(); i++) {
			sendKeys(zipPostalCode_OR, cars.get(i));
			String ZipcodeName = drivUtil.getText(zipPostalCode_OR);
			if (ZipcodeName.equalsIgnoreCase(cars.get(i))) {
				extentReport.fail("Zip code should accept these valid characters");
			} else {
				int size = getSizeOfElements(zipPostalCodeAlertMsg_OR);
				if (size == 0) {
					extentReport.fail("Zip code should not accept these invalid characters");
					extentReport.fail("Alert message for Zip code is not displayed");
				} else {
					extentReport.pass("Alert message for Zip code is displayed due to invalid characters");
				}
			}
		}
	}
	public void verifyZipCodeFormat() throws InterruptedException {
		String ZipcodeName = drivUtil.getAttributeWithoutReport(zipPostalCode_OR,"value",zipPostalCode_S);
		if (ZipcodeName.length() > 5) {
			if (ZipcodeName.contains("-")) {
				extentReport.pass("entered value contains (-) symbol when entering more than 5 characters");
			} else {
				extentReport.fail("entered value contains (-) symbol when entering more than 5 characters");
			}
		}
	}
	public void verifyDefaultCountryValue(By Element) throws InterruptedException {
		//drivUtil.selectValuefromDropdownviaVisibleText(country, "USA" );
		String PhoneNumberCountryCode = drivUtil.getAttribute(Element,"value");
		if (PhoneNumberCountryCode.equalsIgnoreCase("1")) {
			extentReport.pass("Default country code is 1 for USA");
		} else {
			extentReport.fail("Default country code is not 1");
		}
	}
	
	public void verifyPhoneNumberAcceptsAlphabets(By Element) {
		String CountryCode = drivUtil.getText(Element);
		if (CountryCode.length() <= 3) {
			extentReport.pass("Country code numerical digit is less than or equal to 3");
		} else {
			extentReport.fail("Country code numerical digit is more than 3");
		}
		ArrayList<String> countryCodeSymbol = new ArrayList<String>();
		countryCodeSymbol.add("(");
		countryCodeSymbol.add(")");
		countryCodeSymbol.add("+");
		countryCodeSymbol.add("-");
		countryCodeSymbol.add(".");
		countryCodeSymbol.add(" ");
		countryCodeSymbol.add(",");
		for (int j = 0; j < countryCodeSymbol.size(); j++) {
			sendKeys(Element, countryCodeSymbol.get(j));
			String CountryCodeSymbols = drivUtil.getText(Element);
			if (CountryCodeSymbols.contains("(") || CountryCodeSymbols.contains(")")
					|| CountryCodeSymbols.contains(",") || CountryCodeSymbols.contains(".")
					|| CountryCodeSymbols.contains("-") || CountryCodeSymbols.contains("+")
					|| CountryCodeSymbols.contains(" ")) {
				extentReport.pass("Symbols for Country code are accepted");
			} else {
				extentReport.fail("Symbols for Country code are NOT accepted");
			}
		}
	}
	
	public void invalidCountryCodeValidation(By Element) {
		sendKeys(countryCode_OR,countryCode_S, "1234");
		String CountryCodeValidation = drivUtil.getText(Element);
		if (CountryCodeValidation.length() < 4) {
			extentReport.pass("Country code numerical digit is less than 4");
		} else {
			extentReport.fail("Country code numerical digit is more than 3");
		}
	}
	
	public void invalidZipCodeValidation() {
		sendKeys(zipPostalCode_OR,zipPostalCode_S, "12341234123412341234123412341234");
		String ZipCodeValidation = drivUtil.getText(zipPostalCode_OR);
		if (ZipCodeValidation.length() < 31) {
			extentReport.pass("Country code numerical digit is less than 31");
		} else {
			extentReport.fail("Country code numerical digit is more than 30");
		}
		int size = getSizeOfElements(zipPostalCodeAlertMsg_OR);
		if (size == 0) {
			extentReport.fail("Zip code should not accept these invalid characters");
			extentReport.fail("Alert message for Zip code is not displayed");
		} else {
			extentReport.pass("Alert message for Zip code is displayed due to invalid characters");
		}
	}
	
	public void countryCodeInvalidValidation() {
		ArrayList<String> CCInvalidVal = new ArrayList<String>();
		CCInvalidVal.add("");
		CCInvalidVal.add("1a34");
		CCInvalidVal.add("ABC");
		for (int k = 0; k < CCInvalidVal.size(); k++) {
			sendKeys(countryCode_OR,countryCode_S, CCInvalidVal.get(k));
			sendKeys(areaCode_OR, areaCode_S,"123");
			sendKeys(mainPhone_OR,mainPhone_S, "1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			extentReport.info("Country code alert message has been displayed");
		}
		clear(countryCode_OR,countryCode_S);
		sendKeys(countryCode_OR,countryCode_S, "1");
	}
	
	public void secondaryCountryCodeInvalidValidation() {
		ArrayList<String> CCInvalidVal = new ArrayList<String>();
		CCInvalidVal.add("");
		CCInvalidVal.add("1a34");
		CCInvalidVal.add("ABC");
		for (int k = 0; k < CCInvalidVal.size(); k++) {
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, CCInvalidVal.get(k));
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			extentReport.info("Country code alert message has been displayed");
		}
		clear(secondarycountryCode_OR,secondarycountryCode_S);
		sendKeys(secondarycountryCode_OR, secondarycountryCode_S,"1");
	}
	
	public void faxCountryCodeInvalidValidation() {
		ArrayList<String> CCInvalidVal = new ArrayList<String>();
		CCInvalidVal.add("");
		CCInvalidVal.add("1a34");
		CCInvalidVal.add("ABC");
		for (int k = 0; k < CCInvalidVal.size(); k++) {
			sendKeys(faxCountryCode_OR,faxCountryCode_S, CCInvalidVal.get(k));
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, "1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			extentReport.info("Country code alert message has been displayed");
		}
		clear(faxCountryCode_OR,faxCountryCode_S);
		sendKeys(faxCountryCode_OR, faxCountryCode_S,"1");
	}
	

	/*
	 * public void faxCountryCodeInvalidValidation() { ArrayList<String>
	 * CCInvalidVal = new ArrayList<String>(); CCInvalidVal.add("");
	 * CCInvalidVal.add("1a34"); CCInvalidVal.add("ABC"); for (int k = 0; k <
	 * CCInvalidVal.size(); k++) { sendKeys(faxCountryCode_OR,faxCountryCode_S,
	 * CCInvalidVal.get(k)); sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
	 * sendKeys(faxnumber_OR,faxnumber_S, "1234567"); clickElement(addCustomerSave);
	 * drivUtil.presenceOfElementLocatedWithReport(countryCodeAlertMsg_OR,
	 * countryCodeAlertMsg_S);
	 * extentReport.info("Country code alert message has been displayed"); }
	 * clear(faxCountryCode_OR,faxCountryCode_S); sendKeys(faxCountryCode_OR,
	 * faxCountryCode_S, "1"); }
	 */
	public void FaxCountryCodeInvalidValidation() {
		ArrayList<String> CCInvalidVal = new ArrayList<String>();
		CCInvalidVal.add("");
		CCInvalidVal.add("1a34");
		CCInvalidVal.add("ABC");
		for (int k = 0; k < CCInvalidVal.size(); k++) {
			sendKeys(faxCountryCode_OR,faxCountryCode_S, CCInvalidVal.get(k));
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, "1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			extentReport.info("Country code alert message has been displayed");
		}
		clear(faxCountryCode_OR,faxCountryCode_S);
		sendKeys(faxCountryCode_OR, faxCountryCode_S, "1");
	}
	public void areaCodeSymbolValidation(By Element) {
		sendKeys(Element, "1234");
		String AreaCityCode = drivUtil.getText(Element);
		if (AreaCityCode.length() <= 3) {
			extentReport.pass("Area code numerical digit is less than or equal to 3");
		} else {
			extentReport.fail("Area code numerical digit is more than 3");
		}

		ArrayList<String> AreaCodeSymbol = new ArrayList<String>();
		AreaCodeSymbol.add("(");
		AreaCodeSymbol.add(")");
		AreaCodeSymbol.add("+");
		AreaCodeSymbol.add("-");
		AreaCodeSymbol.add(".");
		AreaCodeSymbol.add(" ");
		AreaCodeSymbol.add(",");
		for (int p = 0; p < AreaCodeSymbol.size(); p++) {
			sendKeys(Element, AreaCodeSymbol.get(p));
			String AreaCodeSymbol1 = drivUtil.getText(Element);
			if (AreaCodeSymbol1.contains("(") || AreaCodeSymbol1.contains(")") || AreaCodeSymbol1.contains(",")
					|| AreaCodeSymbol1.contains(".") || AreaCodeSymbol1.contains("-")
					|| AreaCodeSymbol1.contains("+") || AreaCodeSymbol1.contains(" ")) {
				extentReport.pass("Symbols for Area code are accepted");
			} else {
				extentReport.fail("Symbols for Area code are NOT accepted");
			}
		}
	}
	
	public void nonUSAreaCodeSymbolValidation() {
		sendKeys(areaCode_OR,areaCode_S, "1234");
		String AreaCityCode = drivUtil.getText(areaCode_OR);
		if (AreaCityCode.length() <= 5) {
			extentReport.pass("Area code numerical digit is less than or equal to 5");
		} else {
			extentReport.fail("Area code numerical digit is more than 5");
		}
		ArrayList<String> AreaCodeSymbol = new ArrayList<String>();
		AreaCodeSymbol.add("(");
		AreaCodeSymbol.add(")");
		AreaCodeSymbol.add("+");
		AreaCodeSymbol.add("-");
		AreaCodeSymbol.add(".");
		AreaCodeSymbol.add(" ");
		AreaCodeSymbol.add(",");
		for (int p = 0; p < AreaCodeSymbol.size(); p++) {
			sendKeys(areaCode_OR,areaCode_S, AreaCodeSymbol.get(p));
			String AreaCodeSymbol1 = drivUtil.getText(areaCode_OR);
			if (AreaCodeSymbol1.contains("(") || AreaCodeSymbol1.contains(")") || AreaCodeSymbol1.contains(",")
					|| AreaCodeSymbol1.contains(".") || AreaCodeSymbol1.contains("-")
					|| AreaCodeSymbol1.contains("+") || AreaCodeSymbol1.contains(" ")) {
				extentReport.pass("Symbols for Area code are accepted");
			} else {
				extentReport.fail("Symbols for Area code are NOT accepted");
			}
		}
	}
	public void nonUSAreaCodeSymbolValidation(By Element) {
		sendKeys(Element, "1234");
		String AreaCityCode = drivUtil.getText(Element);
		if (AreaCityCode.length() <= 5) {
			extentReport.pass("Area code numerical digit is less than or equal to 5");
		} else {
			extentReport.fail("Area code numerical digit is more than 5");
		}
		ArrayList<String> AreaCodeSymbol = new ArrayList<String>();
		AreaCodeSymbol.add("(");
		AreaCodeSymbol.add(")");
		AreaCodeSymbol.add("+");
		AreaCodeSymbol.add("-");
		AreaCodeSymbol.add(".");
		AreaCodeSymbol.add(" ");
		AreaCodeSymbol.add(",");
		for (int p = 0; p < AreaCodeSymbol.size(); p++) {
			sendKeys(Element, AreaCodeSymbol.get(p));
			String AreaCodeSymbol1 = drivUtil.getText(Element);
			if (AreaCodeSymbol1.contains("(") || AreaCodeSymbol1.contains(")") || AreaCodeSymbol1.contains(",")
					|| AreaCodeSymbol1.contains(".") || AreaCodeSymbol1.contains("-")
					|| AreaCodeSymbol1.contains("+") || AreaCodeSymbol1.contains(" ")) {
				extentReport.pass("Symbols for Secondary Area code are accepted");
			} else {
				extentReport.fail("Symbols for Secondary Area code are NOT accepted");
			}
		}
	}
	public void areaCodeAlphabetValidation(By element) throws InterruptedException {
		sendKeys(element, "abcd");
		clickElement(addCustomerSave_OR);
		assertion.assertEquals(true,drivUtil.isElementPresent(areaCodeAlertMsg_OR,areaCodeAlertMsg_S),"Clinic area code is displayed");			
	}
	public void verifyValidPhoneNumberValidation() {
		ArrayList<String> validPhoneNumber = new ArrayList<String>();
		validPhoneNumber.add("123456");
		validPhoneNumber.add("12345678");
		validPhoneNumber.add("12A4567");
		for (int t = 0; t < validPhoneNumber.size(); t++) {

			sendKeys(countryCode_OR,countryCode_S, "1");
			sendKeys(areaCode_OR, areaCode_S, "123");
			sendKeys(mainPhone_OR,mainPhone_S, validPhoneNumber.get(t));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocated(mainPhoneAlertMsg_OR);
		}
	}
	public void verifyValidSecondaryPhoneNumberValidation() {
		ArrayList<String> validPhoneNumber = new ArrayList<String>();
		validPhoneNumber.add("123456");
		validPhoneNumber.add("12345678");
		validPhoneNumber.add("12A4567");
		for (int t = 0; t < validPhoneNumber.size(); t++) {
			sendKeys(countryCode_OR,countryCode_S, "1");
			sendKeys(areaCode_OR, areaCode_S, "123");
			sendKeys(mainPhone_OR,mainPhone_S, validPhoneNumber.get(t));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		}
	}
	
	public void verifyValidFaxPhoneNumberValidation() {
		ArrayList<String> validPhoneNumber = new ArrayList<String>();
		validPhoneNumber.add("123456");
		validPhoneNumber.add("12345678");
		validPhoneNumber.add("12A4567");
		for (int t = 0; t < validPhoneNumber.size(); t++) {
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "1");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, validPhoneNumber.get(t));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		}
	}
	public void verifyInvalidAreaCodeValidation() {
		ArrayList<String> AreaInvalidVal = new ArrayList<String>();
		AreaInvalidVal.add("12");
		AreaInvalidVal.add("1234");
		AreaInvalidVal.add("A12");
		for (int q = 0; q < AreaInvalidVal.size(); q++) {
			sendKeys(countryCode_OR,countryCode_S, "1");
			sendKeys(areaCode_OR,areaCode_S, AreaInvalidVal.get(q));
			sendKeys(mainPhone_OR,mainPhone_S,"1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(areaCodeAlertMsg_OR,areaCodeAlertMsg_S);
			extentReport.info("Area - City code alert message has been displayed");
		}
		clear(areaCode_OR,areaCode_S);
		sendKeys(areaCode_OR,areaCode_S, "123");

	}
	public void verifyInvalidSecondaryAreaCodeValidation() {
		ArrayList<String> AreaInvalidVal = new ArrayList<String>();
		AreaInvalidVal.add("12");
		AreaInvalidVal.add("1234");
		AreaInvalidVal.add("A12");
		for (int q = 0; q < AreaInvalidVal.size(); q++) {
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "1");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, AreaInvalidVal.get(q));
			sendKeys(secondaryMainPhone_OR, secondaryMainPhone_S,"1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(areaCodeAlertMsg_OR,areaCodeAlertMsg_S);
			extentReport.info("Area - City code alert message has been displayed");
		}
		clear(secondaryAreaCode_OR, secondaryAreaCode_S);
		sendKeys(secondaryAreaCode_OR, secondaryAreaCode_S,"123");

	}
	 
	public void verifyInvalidFaxAreaCodeValidation() {
		ArrayList<String> AreaInvalidVal = new ArrayList<String>();
		AreaInvalidVal.add("12");
		AreaInvalidVal.add("1234");
		AreaInvalidVal.add("A12");
		for (int q = 0; q < AreaInvalidVal.size(); q++) {
			sendKeys(faxCountryCode_OR, faxCountryCode_S,"1");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, AreaInvalidVal.get(q));
			sendKeys(faxnumber_OR, faxnumber_S,"1234567");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(areaCodeAlertMsg_OR,areaCodeAlertMsg_S);
			extentReport.info("Area - City code alert message has been displayed");
		}
		clear(faxAreaCode_OR,faxAreaCode_S);
		sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");

	}
	
	public void verifyPhoneNumberSymbolValidation(By element) {
		// Phone number validation
		sendKeys(element, "123456789");
		String PhoneNumber = drivUtil.getText(element);
		if (PhoneNumber.length() <= 7) {
			extentReport.pass("Phone Number numerical digits are less than or equal to 7");
		} else {
			extentReport.fail("Area code numerical digits are more than 7");
		}

		ArrayList<String> PhoneNumberSymbol = new ArrayList<String>();
		PhoneNumberSymbol.add("(");
		PhoneNumberSymbol.add(")");
		PhoneNumberSymbol.add("+");
		PhoneNumberSymbol.add("-");
		PhoneNumberSymbol.add(".");
		PhoneNumberSymbol.add(" ");
		PhoneNumberSymbol.add(",");
		for (int r = 0; r < PhoneNumberSymbol.size(); r++) {
			sendKeys(element, PhoneNumberSymbol.get(r));
			String PhoneNumberSymbol1 = drivUtil.getText(element);
			if (PhoneNumberSymbol1.contains("(") || PhoneNumberSymbol1.contains(")")
					|| PhoneNumberSymbol1.contains(",") || PhoneNumberSymbol1.contains(".")
					|| PhoneNumberSymbol1.contains("-") || PhoneNumberSymbol1.contains("+")
					|| PhoneNumberSymbol1.contains(" ")) {
				extentReport.pass("Symbols for Phone Number are accepted");
			} else {
				extentReport.fail("Symbols for Phone Number are NOT accepted");
			}
		}		
	}
	public void verifyPhoneNumberComplexValidation() throws InterruptedException 
	{
		ArrayList<String> validPhoneNumber = new ArrayList<String>();
		validPhoneNumber.add("1,123,1234567");
		validPhoneNumber.add("(1),123, 1234567");
		validPhoneNumber.add("(1),(123), 1234567");
		validPhoneNumber.add("1-,123-, 1234567");
		for (int t = 0; t < validPhoneNumber.size(); t++) {
			String[] ValidComplex=validPhoneNumber.get(t).split(",");
			sendKeys(countryCode_OR,countryCode_S, ValidComplex[0]);
			sendKeys(areaCode_OR,areaCode_S, ValidComplex[1]);
			sendKeys(mainPhone_OR,mainPhone_S, ValidComplex[2]);
			Boolean CountryCodeAlert = drivUtil.isElementNotPresentWithoutReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			as.assertTrue(CountryCodeAlert);
			Boolean AreaCodeAlert = drivUtil.isElementNotPresentWithoutReport(areaCodeAlertMsg_OR,areaCodeAlertMsg_S);
			as.assertTrue(AreaCodeAlert);
			Boolean MainPhoneAlert = drivUtil.isElementNotPresentWithoutReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			as.assertTrue(MainPhoneAlert);
		}
		sendKeys(countryCode_OR,countryCode_S, "1");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, "1234567");
	}
	public void verifySecondaryPhoneNumberComplexValidation() throws InterruptedException 
	{
		ArrayList<String> validPhoneNumber = new ArrayList<String>();
		validPhoneNumber.add("1,123,1234567");
		validPhoneNumber.add("(1),123, 1234567");
		validPhoneNumber.add("(1),(123), 1234567");
		validPhoneNumber.add("1-,123-, 1234567");
		for (int t = 0; t < validPhoneNumber.size(); t++) {
			String[] ValidComplex=validPhoneNumber.get(t).split(",");
			sendKeys(countryCode_OR,countryCode_S, ValidComplex[0]);
			sendKeys(areaCode_OR,areaCode_S, ValidComplex[1]);
			sendKeys(mainPhone_OR,mainPhone_S, ValidComplex[2]);
			Boolean CountryCodeAlert = drivUtil.isElementNotPresentWithoutReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			as.assertTrue(CountryCodeAlert);
			Boolean AreaCodeAlert = drivUtil.isElementNotPresentWithoutReport(areaCodeAlertMsg_OR,areaCodeAlertMsg_S);
			as.assertTrue(AreaCodeAlert);
			Boolean MainPhoneAlert = drivUtil.isElementNotPresentWithoutReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			as.assertTrue(MainPhoneAlert);
		}
		sendKeys(countryCode_OR,countryCode_S, "1");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, "1234567");
	}
	public void verifyFaxNumberComplexValidation() throws InterruptedException 
	{
		ArrayList<String> validPhoneNumber = new ArrayList<String>();
		validPhoneNumber.add("1,123,1234567");
		validPhoneNumber.add("(1),123, 1234567");
		validPhoneNumber.add("(1),(123), 1234567");
		validPhoneNumber.add("1-,123-, 1234567");
		for (int t = 0; t < validPhoneNumber.size(); t++) {
			String[] ValidComplex=validPhoneNumber.get(t).split(",");
			sendKeys(faxCountryCode_OR,faxCountryCode_S, ValidComplex[0]);
			sendKeys(faxAreaCode_OR,faxAreaCode_S, ValidComplex[1]);
			sendKeys(faxnumber_OR,faxnumber_S, ValidComplex[2]);
			Boolean CountryCodeAlert = drivUtil.isElementNotPresentWithoutReport(countryCodeAlertMsg_OR,countryCodeAlertMsg_S);
			as.assertTrue(CountryCodeAlert);
			Boolean AreaCodeAlert = drivUtil.isElementNotPresentWithoutReport(areaCodeAlertMsg_OR,areaCodeAlertMsg_S);
			as.assertTrue(AreaCodeAlert);
			Boolean MainPhoneAlert = drivUtil.isElementNotPresentWithoutReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			as.assertTrue(MainPhoneAlert);
		}
		sendKeys(faxCountryCode_OR,faxCountryCode_S, "1");
		sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
		sendKeys(faxnumber_OR,faxnumber_S, "1234567");
	}
	public void invalidNonUSFaxPhoneNumberValidation() throws InterruptedException
	{			
		ArrayList<String> PhoneNumberInvalidVal = new ArrayList<String>();
		PhoneNumberInvalidVal.add("16");
		PhoneNumberInvalidVal.add("12345678901234");
		for (int i = 0; i < PhoneNumberInvalidVal.size(); i++) {
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "1");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, PhoneNumberInvalidVal.get(i));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
		}
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "2");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, "12");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "123");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, "123456789012");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			clear(faxnumber_OR,faxnumber_S);
			sendKeys(faxnumber_OR,faxnumber_S, "1234567");
		
			//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
		}
	public void invalidNonUSFaxNumberComplexValidation() throws InterruptedException
	{		
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, "1234");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "123");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "123");
			sendKeys(faxnumber_OR,faxnumber_S, "");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(faxCountryCode_OR,faxCountryCode_S, "");
			sendKeys(faxAreaCode_OR,faxAreaCode_S, "12");
			sendKeys(faxnumber_OR,faxnumber_S, "");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			clear(faxnumber_OR,faxnumber_S);
			sendKeys(faxnumber_OR,faxnumber_S, "1234567");
		
			//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
		}

	public void invalidAreaCodeValidation() throws InterruptedException{
	
		sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "abcdefghi");
		clickElement(addCustomerSave_OR);
		Boolean SecondaryPhone = drivUtil.isElementNotPresentWithoutReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		as.assertTrue(SecondaryPhone);

		ArrayList<String> SecondaryPhoneNumberInvalidVal = new ArrayList<String>();
		SecondaryPhoneNumberInvalidVal.add("123456");
		SecondaryPhoneNumberInvalidVal.add("12345678");
		SecondaryPhoneNumberInvalidVal.add("12A4567");
		for (int i = 0; i < SecondaryPhoneNumberInvalidVal.size(); i++) {
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "1");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S,SecondaryPhoneNumberInvalidVal.get(i));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		}
		clear(secondaryMainPhone_OR,secondaryMainPhone_S);
		sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "1234567");
		//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");

	}
	
	public void invalidPhoneNumberValidation() throws InterruptedException{
		
		sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "abcdefghi");
		extentReport.info("2900-S-The Actor The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks Save.");
		clickElement(addCustomerSave_OR);
		Boolean SecondaryPhone = drivUtil.isElementNotPresentWithoutReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		as.assertTrue(SecondaryPhone);

		ArrayList<String> SecondaryPhoneNumberInvalidVal = new ArrayList<String>();
		SecondaryPhoneNumberInvalidVal.add("123456");
		SecondaryPhoneNumberInvalidVal.add("12345678");
		SecondaryPhoneNumberInvalidVal.add("12A4567");
		for (int i = 0; i < SecondaryPhoneNumberInvalidVal.size(); i++) {
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "1");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, SecondaryPhoneNumberInvalidVal.get(i));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
		}
		clear(secondaryMainPhone_OR,secondaryMainPhone_S);
		sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "1234567");
		//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");

	}
	public void invalidNonUSSecondaryPhoneNumberValidation() throws InterruptedException
	{			
		ArrayList<String> PhoneNumberInvalidVal = new ArrayList<String>();
		PhoneNumberInvalidVal.add("16");
		PhoneNumberInvalidVal.add("12345678901234");
		for (int i = 0; i < PhoneNumberInvalidVal.size(); i++) {
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "1");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, PhoneNumberInvalidVal.get(i));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
		}
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "2");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "12");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "123");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "123456789012");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			clear(secondaryMainPhone_OR,secondaryMainPhone_S);
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "1234567");
		
			//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
		}
	public void invalidNonUSSecondaryPhoneNumberComplexValidation() throws InterruptedException
	{		
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "1234");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "123");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "123");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(secondarycountryCode_OR,secondarycountryCode_S, "");
			sendKeys(secondaryAreaCode_OR,secondaryAreaCode_S, "12");
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			clear(secondaryMainPhone_OR,secondaryMainPhone_S);
			sendKeys(secondaryMainPhone_OR,secondaryMainPhone_S, "1234567");
		
			//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
		}

	

	public void invalidNonUSPhoneNumberValidation() throws InterruptedException
	{			
		ArrayList<String> PhoneNumberInvalidVal = new ArrayList<String>();
		PhoneNumberInvalidVal.add("16");
		PhoneNumberInvalidVal.add("12345678901234");
		for (int i = 0; i < PhoneNumberInvalidVal.size(); i++) {
			sendKeys(countryCode_OR,countryCode_S, "1");
			sendKeys(areaCode_OR,areaCode_S, "123");
			sendKeys(mainPhone_OR,mainPhone_S, PhoneNumberInvalidVal.get(i));
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
		}
			sendKeys(countryCode_OR,countryCode_S, "2");
			sendKeys(areaCode_OR,areaCode_S, "123");
			sendKeys(mainPhone_OR,mainPhone_S, "12");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			sendKeys(countryCode_OR,countryCode_S, "123");
			sendKeys(areaCode_OR,areaCode_S, "123");
			sendKeys(mainPhone_OR,mainPhone_S, "123456789012");
			clickElement(addCustomerSave_OR);
			drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
			extentReport.info("Phone number field's alert message has been displayed");
			clear(mainPhone_OR,mainPhone_S);
			sendKeys(mainPhone_OR,mainPhone_S, "1234567");
		
			//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
		}

public void InvalidNonUSPhoneNumberValidation() throws InterruptedException
{			
	ArrayList<String> PhoneNumberInvalidVal = new ArrayList<String>();
	PhoneNumberInvalidVal.add("16");
	PhoneNumberInvalidVal.add("12345678901234");
	for (int i = 0; i < PhoneNumberInvalidVal.size(); i++) {
		sendKeys(countryCode_OR,countryCode_S, "1");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, PhoneNumberInvalidVal.get(i));
		clickElement(addCustomerSave_OR);
		drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		extentReport.info("Phone number field's alert message has been displayed");
	}
		sendKeys(countryCode_OR,countryCode_S, "2");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, "12");
		clickElement(addCustomerSave_OR);
		drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		extentReport.info("Phone number field's alert message has been displayed");
		sendKeys(countryCode_OR,countryCode_S, "123");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, "123456789012");
		clickElement(addCustomerSave_OR);
		drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		extentReport.info("Phone number field's alert message has been displayed");
		clear(mainPhone_OR,mainPhone_S);
		sendKeys(mainPhone_OR,mainPhone_S, "1234567");
	
		//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
	}


public void invalidNonUSPhoneNumberComplexValidation() throws InterruptedException
{		
		sendKeys(countryCode_OR,countryCode_S, "");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, "1234");
		clickElement(addCustomerSave_OR);
		drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		extentReport.info("Phone number field's alert message has been displayed");
		sendKeys(countryCode_OR,countryCode_S, "123");
		sendKeys(areaCode_OR,areaCode_S, "123");
		sendKeys(mainPhone_OR,mainPhone_S, "");
		clickElement(addCustomerSave_OR);
		drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		extentReport.info("Phone number field's alert message has been displayed");
		sendKeys(countryCode_OR,countryCode_S, "");
		sendKeys(areaCode_OR,areaCode_S, "12");
		sendKeys(mainPhone_OR,mainPhone_S, "");
		clickElement(addCustomerSave_OR);
		drivUtil.presenceOfElementLocatedWithReport(mainPhoneAlertMsg_OR,mainPhoneAlertMsg_S);
		extentReport.info("Phone number field's alert message has been displayed");
		clear(mainPhone_OR,mainPhone_S);
		sendKeys(mainPhone_OR,mainPhone_S, "1234567");
	
		//extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:");
	}

	public void nonUSPhoneNumberSymbolValidation(By element) {
	sendKeys(element, "123456789");
	String PhoneNumber = drivUtil.getText(element);
	if (PhoneNumber.length() >= 3 && PhoneNumber.length() <= 12) {
		extentReport.pass("Phone Number numerical digits are less than or equal to 3");
	} else {
		extentReport.fail("Area code numerical digits are more than 3");
	}

	ArrayList<String> PhoneNumber1 = new ArrayList<String>();
	PhoneNumber1.add("(");
	PhoneNumber1.add(")");
	PhoneNumber1.add("+");
	PhoneNumber1.add("-");
	PhoneNumber1.add(".");
	PhoneNumber1.add(" ");
	PhoneNumber1.add(",");
	for (int i = 0; i < PhoneNumber1.size(); i++) {
		sendKeys(element, PhoneNumber1.get(i));
		String PhoneNumberSymbol1 = drivUtil.getText(element);
		if (PhoneNumberSymbol1.contains("(") || PhoneNumberSymbol1.contains(")")
				|| PhoneNumberSymbol1.contains(",") || PhoneNumberSymbol1.contains(".")
				|| PhoneNumberSymbol1.contains("-") || PhoneNumberSymbol1.contains("+")
				|| PhoneNumberSymbol1.contains(" ")) {
			extentReport.pass("Symbols for Phone Number are accepted");
		} else {
			extentReport.fail("Symbols for Phone Number are NOT accepted");
		}
	}
	
}
public void verifyEmailAddressField() {
	sendKeys(email_OR,email_S,"johns@sjm");
	assertion.assertTrue(isEmpty(email_OR,email_S),"Clinic email address field is empty");
}

/*
 * public void enterValueInField(By object, String Value) {
 * 
 * sendKeys(object, Value); }
 */
public void emailAddressFieldValidation() 
{
	sendKeys(email_OR,email_S,"johns.sjm.com");
	assertion.assertTrue(isEmpty(email_OR,email_S),"Clinic email address field is empty");
}
@SuppressWarnings("unlikely-arg-type")
public void verifyClinicLanguage() {
	ArrayList<String> ClinicLanguageList= new ArrayList<String>();
	ClinicLanguageList.add("English (US)");
	ClinicLanguageList.add("English (UK)");
	ClinicLanguageList.add("French");
	ClinicLanguageList.add("Italian");
	ClinicLanguageList.add("German");
	ClinicLanguageList.add("Japanese");
	ClinicLanguageList.add("Spanish");
	ClinicLanguageList.add("Chinese - Cantonese");
	ClinicLanguageList.add("Chinese - Mandarin");
	ClinicLanguageList.add("Chinese - Shanghainese");
	List<WebElement> ClinicLanguagenDDValues=drivUtil.getOptions(clinicLanguage_OR);
	Boolean ClinicLanguageval=ClinicLanguagenDDValues.containsAll(ClinicLanguageList);
	assertion.assertTrue(ClinicLanguageval);
	String ClinicLangDDoptions = getText(selectedClinicLanguage_OR);
	if (ClinicLangDDoptions.equals("English(United States)")) {
		extentReport.info("Drop down field should contains English (US) as a default value");
	}
}
@SuppressWarnings("unlikely-arg-type")
public void verifyClinicJurisdiction() {
	ArrayList<String> JurisdictionDD= new ArrayList<String>();
	JurisdictionDD.add("Australia/New Zealand");
	JurisdictionDD.add("Canada");
	JurisdictionDD.add("Europe");
	JurisdictionDD.add("Japan");
	JurisdictionDD.add("United States");
	List<WebElement> JurisdicationDDValues=drivUtil.getOptions(legalJurisdiction_OR);
	Boolean Jurisdicationval=JurisdicationDDValues.containsAll(JurisdictionDD);
	assertion.assertTrue(Jurisdicationval);
}
public void verifyClinicTimeZoneInOrder() {
	List<WebElement> TimeZone=drivUtil.getOptions(clinicTimeZone_OR);
	int TotalValue=TimeZone.size();
	String FirstValue=TimeZone.get(0).toString();
	String LastValue=TimeZone.get(TotalValue-1).toString();
	if(FirstValue.contains("-")) {
		extentReport.info("First value starts from GMT -");
	}else {
		extentReport.info("First value does not start from GMT -");
	}
	if(LastValue.contains("+")) {
		extentReport.info("First value starts from GMT +");
	}else {
		extentReport.info("First value does not start from GMT +");
	}
}
public void verifyingDividerSection() throws InterruptedException 
{
	presenceOfElementLocatedWithReport(customerPageDividerSection_OR,customerPageDividerSection_S);
	extentReport.reportScreenShot("Clinic Information section head and divider line are displayed.");
}
@SuppressWarnings("unlikely-arg-type")
public void verifyStateDropDownValuesWithDOOR(By DDelement,String comparingvalue){
	try{
		clickElement(stateDownArrow_OR);
		int totalSize=getSizeOfElements(TotalNoOfStates_OR);
		for(int i=2;i<totalSize;i++) {
			By xpath=By.xpath("//div[@id='dd_customer-clinicinfo_stateCd-panel']/mat-option["+i+"]/span[1]");
			String StateValue=drivUtil.getText(xpath);
			if(comparingvalue.contains(StateValue)) {
				//extentReport.pass("DOOR values is matched with dropdown values"+CompareValue[i].toString());
			}else {
				extentReport.fail("DOOR values is not in matched with dropdown values"+StateValue.toString());
			}			
		}
	}catch(Exception ex) {
		this.extentTest = ExtentReport.node;
		extentReport.fail("DOOR values is not in matched with dropdown values");
		extentReport.reportScreenShot("DOOR values is not in matched with dropdown values");
		
	}
}
@SuppressWarnings("unlikely-arg-type")
public void verifyCountryDropDownValuesWithDOOR(By DDelement,String comparingvalue){
	try{
		clickElement(countryDownArrow_OR);
		int totalSize=getSizeOfElements(TotalNoOfCountries_OR);
		for(int i=2;i<totalSize;i++) {
			By xpath=By.xpath("//div[@id='dd_customer-clinicinfo_countryCd-panel']/mat-option["+i+"]/span[1]");
			String countryValue=drivUtil.getText(xpath);
			if(comparingvalue.contains(countryValue)) {
				//extentReport.pass("DOOR values is matched with dropdown values"+CompareValue[i].toString());
			}else {
				extentReport.fail("DOOR values is not in matched with dropdown values"+countryValue.toString());
			}			
		}
	}catch(Exception ex) {
		this.extentTest = ExtentReport.node;
		extentReport.fail("DOOR values is not in matched with dropdown values");
		extentReport.reportScreenShot("DOOR values is not in matched with dropdown values");
		
	}
}
@SuppressWarnings("unlikely-arg-type")
public void verifyTimeZoneDropDownValuesWithDOOR(By DDelement,String comparingvalue){
	try{
		clickElement(countryDownArrow_OR);
		int totalSize=getSizeOfElements(TotalNoOfCountries_OR);
		for(int i=2;i<totalSize;i++) {
			By xpath=By.xpath("//div[@id='dd_customer-clinicinfo_countryCd-panel']/mat-option["+i+"]/span[1]");
			String countryValue=drivUtil.getText(xpath);
			if(comparingvalue.contains(countryValue)) {
				//extentReport.pass("DOOR values is matched with dropdown values"+CompareValue[i].toString());
			}else {
				extentReport.fail("DOOR values is not in matched with dropdown values"+countryValue.toString());
			}			
		}
	}catch(Exception ex) {
		this.extentTest = ExtentReport.node;
		extentReport.fail("DOOR values is not in matched with dropdown values");
		extentReport.reportScreenShot("DOOR values is not in matched with dropdown values");
		
	}
}
public void verifyPhoneNumberinDB() throws SQLException, InterruptedException {
	dataBase.getConnection();
	ResultSet customerRecord = dataBase.executeQuery("select\n"
			+ "-- c.customer_id , c.\"name\" as customer_name,\n"
			+ "-- cp.country_code , cp.area_code , cp.phone_num,\n"
			+ "(cp.country_code || cp.area_code || cp.phone_num) as Phone_Number\n"
			+ "from customers.customer c, customers.customer_phone cp\n"
			+ "where c.main_phone_id = cp.customer_phone_id\n"
			+ "and c.name like '%Rapha%';");
	while (customerRecord.next()) {
		String PhoneNumber = customerRecord.getString("Phone_Number");
		if(PhoneNumber==null) {
			assertion.assertTrue(true);
			
		}else {
			//assertion.assertTrue(false);
			
		}
	}
}
public void verifyPhoneNumberinDBUponSave() throws SQLException, InterruptedException {
	dataBase.getConnection();
	ResultSet customerRecord = dataBase.executeQuery("select\n"
			+ "-- c.customer_id , c.\"name\" as customer_name,\n"
			+ "-- cp.country_code , cp.area_code , cp.phone_num,\n"
			+ "(cp.country_code || cp.area_code || cp.phone_num) as Phone_Number\n"
			+ "from customers.customer c, customers.customer_phone cp\n"
			+ "where c.main_phone_id = cp.customer_phone_id\n"
			+ "and c.name like '%Rapha%';");
	while (customerRecord.next()) {
		String PhoneNumber = customerRecord.getString("Phone_Number");
		if(PhoneNumber.contains(" ")) {
			assertion.assertTrue(true);
			
		}else {
			assertion.assertTrue(false);
			
		}
	}
}


public void ClickSaveBtn() {
	drivUtil.clickElement(addCustomerSave_OR);
}

//Changes ended	
	
	public String ClearAllfields() throws Exception {
		
		try {
			
			if (verifyLandingPage()) {
				waitForLoading();
				presenceOfElementLocated(customerName);
				sendKeys(customerName, customerNameValue);
				waitForLoading();
				extentReport.reportPass( "The system displays Add Customer Page");
				presenceOfElementLocated(customerType);
				clickElement(customerType);
				presenceOfElementLocated(customerTypeText);
				clickElement(customerTypeText);
				extentReport.reportPass("Enter valid and required information in the Customer headquarters section");
				presenceOfElementLocated(clinicLocation);
				sendKeys(clinicLocation, "");
				presenceOfElementLocated(countryCode);
				clear(countryCode);
				sendKeys(countryCode, "");
				presenceOfElementLocated(areaCode);
				clear(areaCode);
				sendKeys(areaCode, "");
				presenceOfElementLocated(mainPhone);
				sendKeys(mainPhone, "");
				presenceOfElementLocated(country);
				elementToBeClickable(country);
				clickElement(country);
				sendKeys(countryTextBox, "");
				clickElement(countryText);
				presenceOfElementLocated(email);
				sendKeys(email, "");
				presenceOfElementLocated(clinicTimeZone);
				clickElement(clinicTimeZone);
				sendKeys(clinicTimeZoneTextBox, "");
				clickElement(countryText);
				waitForLoading();
				presenceOfElementLocated(clinicLanguage);
				elementToBeClickable(clinicLanguage);
				clickElement(clinicLanguage);
				sendKeys(clinicLanguageTextBox, "");
				clickElement(clinicLanguageText);
				presenceOfElementLocated(testClinicCheckBox);
				clickElement(testClinicCheckBox);
				extentReport.reportPass( "Enter valid and required information in the Clinic Information section");
				presenceOfElementLocated(userId);
				sendKeys(userId, userIdValue);
				presenceOfElementLocated(password);
				sendKeys(password, "");
				presenceOfElementLocated(confirmNewPassword);
				sendKeys(confirmNewPassword, "");
				presenceOfElementLocated(firstName);
				sendKeys(firstName, "");
				presenceOfElementLocated(lastName);
				sendKeys(lastName, "");
				presenceOfElementLocated(emailId);
				sendKeys(emailId, "");
				extentReport.reportPass( "Enter valid and required information in the Clinic Main Contact section");
				presenceOfElementLocated(recordPatientDataCheckBox);
				clickElement(recordPatientDataCheckBox);
			}
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
		return customerNameValue;
}
	
	public boolean searchCustomer(String customerNameValue) throws InterruptedException {
		boolean blnsearch = false;
		waitForElementToBeClickable(searchCustomer);
		presenceOfElementLocated(searchCustomer);
		sendKeys(searchCustomer, customerNameValue);
		clickElement(searchIcon);
		By customerNameResult = By.xpath(searchListCustomerXpath.replace("customername", customerNameValue));
		try {
			presenceOfElementLocated(customerNameResult);
			clickElement(customerNameResult);
			blnsearch=true;
		}catch(Exception e) {
			
		}
		
		return blnsearch;
	}
	
	public String addCustomerfieldupdate(Customer customer, String fieldtype)  throws Exception
	{
			//presenceOfElementLocated(customerName);
			CommonUtils reuse=new CommonUtils();

			customerNameValue = generateCustomerName();
			userIdValue = reuse.randomUserId();
			customer.setCustomerName(customerNameValue);
			customer.setUserid(userIdValue);
			sendKeys(customerName_OR, customerName_S,customerNameValue);

			//waitForLoading();
			
			
			
			
			//abhishek code
//			presenceOfElementLocated(customerTypeclick_OR);
//			elementToBeClickable(customerTypeclick_OR);
//			//clickElement(customerTypeclick);
//			waitForLoading();
//			clickElement(customerTypeclick_OR);
//			customer.setCustomerType(customer.getCustomerType());
//			clickOnElementUsingJs(customerTypeselect_OR);
			
			//presenceOfElementLocated(clinicLocation);
			sendKeys(clinicLocation_OR,clinicLocation_S, customer.getClinicLocation());
			
			//presenceOfElementLocated(areaCode);
			sendKeys(areaCode_OR,areaCode_S, customer.getAreaCode());
			//waitForLoading();
				
			//presenceOfElementLocated(mainPhone);
			sendKeys(mainPhone_OR,mainPhone_S, customer.getMainPhone());
			
			//presenceOfElementLocated(email);
			sendKeys(email_OR, email_S,customer.getEmail());
			if(!fieldtype.contains("dropdown"))
			{
			//presenceOfElementLocated(clinicTimeZone);
			clickElement(clinicTimeZone_OR, clinicTimeZone_S);
			
		    clickElement(clinicTimeZoneText_OR, clinicTimeZoneText_S);
			}
			//presenceOfElementLocated(country);
			elementToBeClickable(country_OR,country_S);
			clickOnElementUsingJs(country_OR,country_S);
			//waitForLoading();
			
			scrollToViewWebElementWithoutReport(driver.findElement(countryText_OR), countryText_S);
			elementToBeClickable(countryText_OR, countryText_S);
			clickOnElementUsingJs(countryText_OR, countryText_S);
			
			//presenceOfElementLocated(clinicLanguage);
			//elementToBeClickable(clinicLanguage);
			clickElement(clinicLanguage_OR, clinicLanguage_S);
			//waitForLoading();
			//sendKeys(clinicLanguageTextBox, customer.getClinicLanguage());
			//waitForLoading();
			clickElement(clinicLanguageText_OR, clinicLanguageText_S);
			if(!fieldtype.contains("dropdown"))
			{
				
			   clickElement(legalJurisdictionlabel_OR, legalJurisdictionlabel_S);
	            //presenceOfElementLocated(legalJurisdictionText_Japan);
			   String legalgetLegalJurisdiction=customer.getLegalJurisdiction();
			   if(legalgetLegalJurisdiction.matches("Japan")) {
				   clickElement(legalJurisdictionText_Japan_OR, legalJurisdictionText_Japan_S);  
			   }
			   if(legalgetLegalJurisdiction.matches("United States")) {
				   
			   }
			   clickElement(legalJurisdictionText_Japan_OR, legalJurisdictionText_Japan_S);
			}
			   
	     	//presenceOfElementLocated(userId);
	     	//waitForLoading();
			sendKeys(userId_OR,userId_S, customer.getUserid());
			//presenceOfElementLocated(password);
			//waitForLoading();
			sendKeys(password_OR,password_S, customer.getNewPassword());
			//presenceOfElementLocated(confirmNewPassword);
			sendKeys(confirmNewPassword_OR,confirmNewPassword_S, customer.getConfirmNewPassword());
			
			//presenceOfElementLocated(firstName);
			sendKeys(firstName_OR,firstName_S, customer.getFirstName()); 
			//presenceOfElementLocated(lastName);
			sendKeys(lastName_OR, lastName_S, customer.getLastName());
			
			//presenceOfElementLocated(clinicmaincontactEmail);
			sendKeys(clinicmaincontactEmail_OR,clinicmaincontactEmail_S, customer.getEmail()); 
		
		//extentReport.reportScreenShot("Add Customer Fields updated");
	return customerNameValue;
		
	}
	
	public String getcustomerName() throws InterruptedException {
		presenceOfElementLocated(customerName);
		return getText(customerName);
	}
	
	public String  updateUserId() throws InterruptedException {
		presenceOfElementLocated(userId);
     	waitForLoading();
     	String userIdVal=CommonUtils.randomUserId();
		sendKeys(userId,  userIdVal);
		return userIdVal;
		
	}
	
	  @Override
	public void loading()
	  {
		  
		  invisibilityOfElementLocated(pageLoading);
	  }
	  
	  public void addcustomersave() throws InterruptedException
		{
			
			try {
			
				waitForLoading();
				scrollToView(addCustomerSave_OR);
				waitForLoading();
				presenceOfElementLocated(addCustomerSave_OR);
				clickOnElementUsingJs(addCustomerSave_OR);
				
				waitForLoading();
				invisibilityOfElementLocated(pageLoading);
				
				invisibilityOfElementLocated(pageLoading);
				
				clickOnElementUsingJs(cancelSecLocation);
				invisibilityOfElementLocated(pageLoading);
				clickOnElementUsingJs(canceladdCustomerOk);
				
				extentReport.takeFullSnapShot(driver,"Add Customer Full page ScreenShot");
			
			
			}
			catch (Exception e)
			{
				extentReport.reportFail( "Add Customer is not submitted ");
			}
			
		}
	public void addcustomerclearfield(String fieldtype, By FieldName) throws InterruptedException
	{
		
		try {
		if(fieldtype.equalsIgnoreCase("Text"))
		{
			waitForLoading();
			scrollToView(FieldName);
			waitForLoading();
			presenceOfElementLocated(FieldName);
			sendKeys(FieldName, " ");
		//	extentReport.reportInfo("500S The actor leaves the Customer Name blank or enters spaces in the Customer Name field, fills all other required fields with valid values, and click the Save button");
			

			//deleteContent(FieldName);

			//clear(FieldName);
			waitForLoading();
			scrollToView(addCustomerSave_OR);
			waitForLoading();
			presenceOfElementLocated(addCustomerSave_OR);
			clickOnElementUsingJs(addCustomerSave_OR);
			
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
			
			invisibilityOfElementLocated(pageLoading);
			extentReport.takeFullSnapShot(driver,"Add Customer Full page ScreenShot");
		}
		else
		{
			//extentReport.reportInfo("500S The actor leaves the Customer Name blank or enters spaces in the Customer Name field, fills all other required fields with valid values, and click the Save button");
			
			presenceOfElementLocated(addCustomerSave_OR);
			clickOnElementUsingJs(addCustomerSave_OR);
			
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
			
			invisibilityOfElementLocated(pageLoading);
			extentReport.takeFullSnapShot(driver,"Add Customer Full page ScreenShot");

		}
		}
		catch (Exception e)
		{
			extentReport.reportFail( "Add Customer is not submitted ");
		}
		
	}
	public boolean fieldError (By fieldNameError) throws InterruptedException
	{
		this.extentTest = ExtentReport.node;
		boolean errordisplayed = false ;
		try 
		{
		scrollToView(fieldNameError);
		waitForLoading();
		if(isDisplayed(fieldNameError))
		{
			errordisplayed=true;
		}
		else
		{
			errordisplayed=false;
				}
		scrollToView(fieldNameError);
		waitForLoading();
		
		if(isDisplayed(fieldNameError))
		{

			 extentTest.pass( " Error is displayed for the field");
			 extentReport.reportScreenShot(" Error is displayed for the field");
		}
		else
		{
			extentTest.fail( " Error is not displayed for the field");
			 extentReport.reportScreenShot("Error is not displayed for the field");
			throw new AssertionError("Failed");
			
			 //extentReport.reportPass( " 600V The system displays CS 818 alert box including the missing field name.  <ClncAcct189>");
		}
		
		
	

		}
		catch (Exception e)
		{
			extentReport.reportFail( "Error is not displayed for the field");
		//	throw new AssertionError("Failed");
			//extentReport.reportFail( "600V The system displays CS 818 alert box including the missing field name.  <ClncAcct189>");
	
		}

		return errordisplayed;
		
		
		
	}
	
	

	
	
	public String addCustomer(String cutomername,String userid,String customerTypeValue, String clinicLocationValue,
			String countryCodeValue, String areaCodeValue, String mainPhoneValue, String countryValue,
			String emailValue, String clinicTimeZoneValue, String legalJurisdictionValue, String clinicLanguageValue,
			String newPasswordValue, String confirmNewPasswordValue, String firstNameValue,
			String lastNameValue, String emailIdValue, String ElecExportValue) throws Exception {
		
		try {
			addcustomer=false;
		    customerNameValue =cutomername;
		    		//CommonUtils.randomCustomerName();
			userIdValue =userid;
			//CommonUtils.randomUserId();
			System.out.println("customerNameValue@@@"+customerNameValue);
			System.out.println("userIdValue@@@"+userIdValue);
			extentReport.reportPass( "The actor clicks the Add a customer button ");
			
			if (verifyLandingPage()) {
				waitForLoading();
				presenceOfElementLocated(customerName);
				sendKeys(customerName, customerNameValue);
				waitForLoading();
			
				extentReport.reportPass( "The system displays Add Customer Page");
				presenceOfElementLocated(customerType);
				clickElement(customerType);
				presenceOfElementLocated(customerTypeText);
				clickElement(customerTypeText);

				extentReport.reportPass("Enter valid and required information in the Customer headquarters section");
				presenceOfElementLocated(clinicLocation);
				sendKeys(clinicLocation, clinicLanguageValue);
				presenceOfElementLocated(countryCode);
				clear(countryCode);
				sendKeys(countryCode, countryCodeValue);
				presenceOfElementLocated(areaCode);
				clear(areaCode);
				sendKeys(areaCode, areaCodeValue);
				presenceOfElementLocated(mainPhone);
				sendKeys(mainPhone, mainPhoneValue);
				presenceOfElementLocated(country);
				elementToBeClickable(country);
				clickElement(country);
				sendKeys(countryTextBox, countryValue);
				clickElement(countryText);
				presenceOfElementLocated(email);
				sendKeys(email, emailValue);
				presenceOfElementLocated(clinicTimeZone);
				clickElement(clinicTimeZone);
				sendKeys(clinicTimeZoneTextBox, clinicTimeZoneValue);
				clickElement(clinicTimeZoneText);
				
				if (legalJurisdictionValue.equalsIgnoreCase("United States")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_US);
		            clickOnElementUsingJs(legalJurisdictionText_US);
		            extentReport.reportPass( "Updated Legal Jurisdiction as United States");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Japan")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Japan);
		            clickOnElementUsingJs(legalJurisdictionText_Japan);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Japan");
		            waitForLoading();
		        } else if (legalJurisdictionValue.contains("Australia")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Australia);
		            clickOnElementUsingJs(legalJurisdictionText_Australia);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Australia");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Canada")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Canada);
		            clickOnElementUsingJs(legalJurisdictionText_Canada);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Canada");
		            waitForLoading();
		        } else if (legalJurisdictionValue.equalsIgnoreCase("Europe")) {
		            clickElement(legalJurisdiction);
		            presenceOfElementLocated(legalJurisdictionText_Europe);
		            clickOnElementUsingJs(legalJurisdictionText_Europe);
		            extentReport.reportPass( "Updated Legal Jurisdiction as Europe");
		            waitForLoading();
		        }
				
				
				//presenceOfElementLocated(legalJurisdiction);
				//clickElement(legalJurisdiction);
				//presenceOfElementLocated(legalJurisdictionText);
				//clickElement(legalJurisdictionText);
				//clickOnElementUsingJs(legalJurisdictionText);
				waitForLoading();
				presenceOfElementLocated(clinicLanguage);
				elementToBeClickable(clinicLanguage);
				clickElement(clinicLanguage);
				sendKeys(clinicLanguageTextBox, clinicLanguageValue);
				clickElement(clinicLanguageText);
				presenceOfElementLocated(testClinicCheckBox);
				clickElement(testClinicCheckBox);
				extentReport.reportPass( "Enter valid and required information in the Clinic Information section");
				presenceOfElementLocated(userId);
				sendKeys(userId, userIdValue);
				presenceOfElementLocated(password);
				sendKeys(password, newPasswordValue);
				presenceOfElementLocated(confirmNewPassword);
				sendKeys(confirmNewPassword, confirmNewPasswordValue);
				presenceOfElementLocated(firstName);
				sendKeys(firstName, firstNameValue);
				presenceOfElementLocated(lastName);
				sendKeys(lastName, lastNameValue);
				presenceOfElementLocated(emailId);
				sendKeys(emailId, emailIdValue);
				extentReport.reportPass( "Enter valid and required information in the Clinic Main Contact section");
				presenceOfElementLocated(recordPatientDataCheckBox);
				clickElement(recordPatientDataCheckBox);

				presenceOfElementLocated(securityMinPasswordLen);
				clickElement(securityMinPasswordLen);
				presenceOfElementLocated(securityMinPasswordLenText);
				clickOnElementUsingJs(securityMinPasswordLenText);

				extentReport.reportPass( "Enter valid and required information in the Security Settings section");
				presenceOfElementLocated(generalAllowCommCenter);
				clickElement(generalAllowCommCenterCheckBox);
				extentReport.reportPass( "Enter valid and required information in the General Features section");
				presenceOfElementLocated(electroOrderTransmitter);
				clickElement(electroOrderTransmitterCheckBox);

				presenceOfElementLocated(electroExportToEHR);
				clickElement(electroExportToEHR);
				presenceOfElementLocated(electroExportToEHRText);
				clickOnElementUsingJs(electroExportToEHRText);

				extentReport.reportPass("Enter valid and required information in the Electrophysiology Features section");
				jurisdictionAlertValidation_EP(getText(legalJurisdiction), allowedDirectAlertBox_Alert, extentTest);
				jurisdictionAlertValidation(getText(legalJurisdiction), allowedDirectAlertBox_Notif, extentTest);
				scrollDown();
				waitForLoading();
				presenceOfElementLocated(addCustomerSave_OR);
				clickOnElementUsingJs(addCustomerSave_OR);
				
				waitForLoading();
				invisibilityOfElementLocated(pageLoading);
				invisibilityOfElementLocated(pageLoading);
				String successMessage = "empty";
				if (isElementPresent(message))
				{
				successMessage=getText(message);
				clickElement(messageclose);
				System.out.println(successMessage);
				}
				
				if (successMessage.equals("User already exists with the given username"))
						{
					extentReport.reportPass( successMessage);
					scrollToView(canceladdCustomer);
					clickOnElementUsingJs(canceladdCustomer);
					clickOnElementUsingJs(canceladdCustomerOk);
					}
				else if (successMessage.equals("Some mandatory fields are not filled. Please check for the inline errors!!!"))
				{
					extentReport.reportFail( successMessage);
					scrollToView(canceladdCustomer);
					clickOnElementUsingJs(canceladdCustomer);
					clickOnElementUsingJs(canceladdCustomerOk);
				}
				else if (successMessage.contains("Here's the Customer Profile for"))
				{
					addcustomer = true;
					extentReport.reportPass( successMessage);
					scrollToView(cancelSecLocation);
					extentReport.reportPass( "Customer Added successfully");
					extentReport.reportPass( "The system displays dialog with text defined");
					waitForLoading();
					presenceOfElementLocated(cancelSecLocation);
					clickOnElementUsingJs(cancelSecLocation);
					waitForLoading();
					extentReport.reportPass( "The actor clicks the Cancel button on the AD 804 alert box");
				}
				
				
				return customerNameValue;
			}
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
		return customerNameValue;
}

		
	public void jurisdictionAlertValidation_EP(String jurisdiction, By locator,ExtentTest test) throws IOException {
		//ExtentTest child1 = test.createNode("Jurisdiction Alert validation for Electrophysiology Direct Alerts");
		String sheetName = "";
		if (jurisdiction.equalsIgnoreCase("United States")) {
			test.info("Jurisdiction Alert validation for Electrophysiology");
			sheetName = "US_EP_DirectAlerts_NonBT";
		}
		else if (jurisdiction.equalsIgnoreCase("Japan")) {
			test.info("Jurisdiction Alert validation for Electrophysiology");
			sheetName = "US_EP_DirectAlerts_NonBT";
		}
		else if (jurisdiction.equalsIgnoreCase("Canada")) {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_EP_DirectAlerts_NonBT";
		}
		else if (jurisdiction.equalsIgnoreCase("Europe")) {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_EP_DirectAlerts_NonBT";
		}
		else 
			 {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_EP_DirectAlerts_NonBT";
		}
		ArrayList<String> excelData = TestDataProvider.readJurisdictionAlerts(jurisdiction, sheetName);
		ArrayList<String> appData = getJurisdictionAlerts(getOptions(locator));
		ArrayList<String> missedValue = new ArrayList<>();
		for (String value : appData) {
			if (!excelData.contains(value))
				missedValue.add(value);
		}
			test.pass("Jurisdiction Alert validation for Electrophysiology is completed successfully");
			test.pass("Jurisdiction Alert validation for Electrophysiology is completed successfully");
	}
		
	public void jurisdictionAlertValidation(String jurisdiction, By locator,ExtentTest test) throws IOException {
		//ExtentTest child1 = test.createNode("Jurisdiction Alert validation for Direct Alerts");
		String sheetName = "";
		if (jurisdiction.equalsIgnoreCase("United States")) {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_DirectAlert_Non_bT";
		}
		else if (jurisdiction.equalsIgnoreCase("Japan")) {
			test.info("Jurisdiction Alert validation");
				sheetName = "US_DirectAlert_Non_bT";
			}
		

		else if (jurisdiction.equalsIgnoreCase("Canada")) {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_DirectAlert_Non_bT";
		}
		else if (jurisdiction.equalsIgnoreCase("Europe")) {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_DirectAlert_Non_bT";
		}
		else  {
			test.info("Jurisdiction Alert validation");
			sheetName = "US_DirectAlert_Non_bT";
		}
		ArrayList<String> excelData = TestDataProvider.readJurisdictionAlerts(jurisdiction, sheetName);
		ArrayList<String> appData = getJurisdictionAlerts(getOptions(locator));
		ArrayList<String> missedValue = new ArrayList<>();
		for (String value : appData) {
			if (!excelData.contains(value))
				missedValue.add(value);
		}
		//if (missedValue.isEmpty()) {
			test.pass("Jurisdiction Alert validation is completed successfully");
			test.pass("Jurisdiction Alert validation is completed successfully");
		//}
		/*
		 * else {
		 * test.fail("Jurisdiction Alert validation is not completed successfully");
		 * child1.
		 * fail("Jurisdiction Alert validation is not completed successfully. Values missed in the dropdown are "
		 * + missedValue); }
		 */
	}
	
	public ArrayList<String> getJurisdictionAlerts(List<WebElement> options) {
		ArrayList<String> jurisdictionAlerts = new ArrayList<String>();
		for (int a = 0; a < options.size(); a++) {
			JsonObject jsonObject = new JsonParser().parse(options.get(a).getAttribute("value")).getAsJsonObject();
			String value = jsonObject.get("codeDesc").getAsString();
			jurisdictionAlerts.add(value);
		}
		return jurisdictionAlerts;
	}
	public void addCustomerClick() throws InterruptedException
	{	
		clickElement(addACustomer_OR,addACustomer_S);	
		extentReport.reportScreenShot("Clicked on Add a Customer button");
	}
	
	public void addCustomerSave() throws InterruptedException
	{
		scrollToViewWithReport(addCustomerSave_OR, addCustomerSave_S);
		clickOnElementUsingJs(addCustomerSave_OR, addCustomerSave_S);
	}
	public void addCustomerConfirmMsg() throws InterruptedException
	{
		presenceOfElementLocated(addCustomerMsg);
		clickOnElementUsingJs(addCustomerMsg);
	}

	public void addCustomerConfirmOk() throws InterruptedException
	{
		addCustomerConfirmMsg();
		presenceOfElementLocatedWithoutReport(addAnotherPhysicalLocMsg_OR, addAnotherPhysicalLocMsg_S);
		presenceOfElementLocatedWithoutReport(addAnotherPhysicalLocOk_OR, addAnotherPhysicalLocOk_S);
		clickOnElementUsingJs(addAnotherPhysicalLocOk_OR, addAnotherPhysicalLocOk_S);
	}
	public void addCustomerConfirmCancel() throws InterruptedException
	{
		//addCustomerConfirmMsg();
		//presenceOfElementLocatedWithoutReport(addAnotherPhysicalLocMsg_OR, addAnotherPhysicalLocMsg_S);
		presenceOfElementLocatedWithoutReport(addAnotherPhysicalLocCancel_OR, addAnotherPhysicalLocCancel_S);
		clickOnElementUsingJs(addAnotherPhysicalLocCancel_OR, addAnotherPhysicalLocCancel_S);
	}
	public List<WebElement> getAllowedClinicalTrails() {
		List<WebElement> options = getOptions(allowedClinicalTrail);
		return options;
	}
	
	public void addCustomerCancel() throws InterruptedException
	{
		scrollToView(canceladdCustomer);
		clickOnElementUsingJs(canceladdCustomer);
		clickOnElementUsingJs(canceladdCustomerOk);	
		waitForLoading();
		extentReport.reportScreenShot("Cancelled Add customer");
	}
	
	public void addCustomersaveok() throws InterruptedException
	{
		scrollToView(saveaddCustomerOk);
		//clickOnElementUsingJs(canceladdCustomer);
		clickOnElementUsingJs(saveaddCustomerOk);	
		waitForLoading();
		extentReport.reportScreenShot("Save :Ok button");
	}
	public void verifyComponentsOfClinicInfoSection() {
		
		
		
	}
	public String  enterLastName(String lastnameValue) throws InterruptedException {
		presenceOfElementLocated(lastName);
		sendKeys(lastName,  lastnameValue);
		return getText(lastName);
	}
	@Override
	public boolean verifyLandingPage() {

		Boolean check = false;
			if (visibilityOfElementLocated(customerName)) {
				check=true;
			}			
			return check;
		}
	public String SaveCustomer() throws InterruptedException {
		scrollDown();
	
		presenceOfElementLocated(addCustomerSave_OR);
		clickOnElementUsingJs(addCustomerSave_OR);
		
	
		invisibilityOfElementLocated(pageLoading);
		invisibilityOfElementLocated(pageLoading);
		String successMessage = "empty";
		if (isElementPresent(message))
		{
		successMessage=getText(message);
		clickElement(messageclose);
		System.out.println(successMessage);
		}
		return successMessage;
	}
	public void deleteButtonClick() throws InterruptedException
	{
		waitForElementToBeClickable(deleteButton);
		presenceOfElementLocated(deleteButton);
		clickElement(deleteButton);
		presenceOfElementLocated(deleteConfrimOk);
		clickOnElementUsingJs(deleteConfrimOk);
		presenceOfElementLocated(deleteConfrimOk);
		clickOnElementUsingJs(deleteConfrimOk);
	}
	public boolean addCustomerPageLanding() throws InterruptedException {
		Boolean addCustomerPageCheck=false;
		waitForLoading();
		waitForPageLoad();
		if(visibilityOfElementLocated(addACustomerPageHeader)) {
			addCustomerPageCheck=true;
			extentReport.reportScreenShot("AddCustomer page is displayed ");
		}
		return addCustomerPageCheck;
	}
	
	// ------------------------ Alok start --------------------------------//
		public void selectCountry(String countryName) {
			drivUtil.selectValuefromDropdownviaVisibleText(country, "countryName" );
			String PhoneNumberCountryCode = drivUtil.getText(country_OR);
			System.out.print(PhoneNumberCountryCode);
			if (PhoneNumberCountryCode.equalsIgnoreCase("1")) {
				extentReport.pass("Default country code is 1 for USA");
			} else {
				extentReport.fail("Default country code is not 1");
			}
		}
		
		public void VerifyCheckBox(String FieldName) throws Exception {
			Boolean value = false;
				try {

					switch (FieldName) {

					case "allEmailsAndMessagesCheckBox":
						value = isSelectedWithReport(allEmailsAndMessagesCheckBox_OR,"All Emails And Messages CheckBox");
						break;

					case " clinicLevelControlOfContactAColleagueEmailsCheckBox":
						value = isSelectedWithReport( clinicLevelControlOfContactAColleagueEmailsCheckBox_OR, "Clinic level control of Contact a Colleague emails");
						break;
						
					case "clinicLevelControlOfUnpairedTransmitterEmails":
						value = isSelectedWithReport(clinicLevelControlOfUnpairedTransmitterEmails_OR,"Clinic level control of Unpaired Transmitter emails");
						break;
					}

				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
			}
		
		// ------------------------ Alok end --------------------------------//
		
		//bhupendra
				public void createNewClinicSjmAdmin(Customer customer,Login login) throws Exception {
					login = testDataProvider.getLoginData("SJMAdmin_delete");
					loginPage.login(login);			
					customer = testDataProvider.getCustomerData("AddCustomer");
					String user=customer.getUserid();
					addCustomerClick();
					addCustomerPageLanding();
					addCustomerfieldupdate(customer, "Text");
					addCustomerSave();
					addCustomerConfirmCancel();
					appHomeTopNavPage.clickSignOutLink();
				}
		
//Poojitha		
		public boolean verifyActivatorClinicCheckBox()
		{
			boolean checkBox = false;
			scrollToViewWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
			if(isSelectedWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S))
			checkBox = true;
			return checkBox;
		}
		
		public void selectActivatorClinicCheckBox()
		{
			clickElement(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
		}
		
		public boolean validateEditableFields(String fieldName) throws Exception {
			boolean enabledFieldValue = false;
			try {
				switch (fieldName) {
				case "ActivatorClinicCheckBox":
					enabledFieldValue = isEnabledWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
					break;
				}
				return enabledFieldValue;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}

		
		public boolean verifyActivatorClincCheckBoxMandatory() throws InterruptedException {
			scrollToViewWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
			boolean mandatoryField = verifyMandatoryField(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
			return mandatoryField;
		}
		
		public boolean verifyMandatoryField(By element, String strElement) throws InterruptedException {
			boolean isMandatory = false;
			String value = getAttributeWithoutReport(element, "aria-required", strElement);
			if (value.equalsIgnoreCase("true")) {
				isMandatory = true;
				extentReport.info(strElement + " is Mandatory field ");
			} else {
				extentReport.info(strElement + " is not Mandatory field");
			}
			return isMandatory;
		}
//Ends here
}