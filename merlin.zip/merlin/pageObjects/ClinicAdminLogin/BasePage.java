package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import org.openqa.selenium.WebDriver;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.utilities.DriverUtils;

public abstract class BasePage extends DriverUtils{
	
//	private WebDriver driver;

	public BasePage(WebDriver driver,ExtentReport extentReport) {
		super(driver,extentReport);			
	}
	
	public abstract boolean verifyLandingPage() throws InterruptedException;
	

}
