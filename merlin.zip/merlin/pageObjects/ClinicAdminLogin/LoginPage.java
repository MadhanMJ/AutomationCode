
package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.FrameworkException;

public class LoginPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	
	private final By loginButton = By.xpath("//*[@id='next']");	
	private final By userNameTextBox = By.xpath("//*[@id='signInName']");
	private final By passwordTextBox = By.xpath("//*[@id='password']");
	private final By sendVerificationCodeButton = By.xpath("//*[text()='Get verification code']");
	private final By verificationCodeTextBox = By.xpath("//*[@class='verifyInput']");
	private final By verifyCodeButton = By.xpath("//*[@class='verifyButton']");
	private final By continueButton = By.xpath("//*[@id='continue']");
	private final By preferredMFAOption = By.xpath("//label[@id='extension_mfaByPhoneOrEmail_label']");
	private final By codeIncorrectError = By.xpath("//*[@id='strongAuthenticationEmailAddress_fail_retry'][@aria-hidden='false']");
	public final String signOutMessage = "Thank you for visiting Abbott Merlin.net� Patient Care Network. You are now logged out. To prevent possible misuse of the system, you should now close this browser window.";
	public static Log logger = new Log();

	public LoginPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}


	public void login(String username, String password) throws Exception {
		try {
			getURL(CommonUtils.url);
			extentReport.reportPass(
					"Actor successfully opened the web browser and typed the application URL ");
			waitForLoading();
			waitForLoading();
			if (isElementPresent(userNameTextBox)) {
				if (visibilityOfElementLocated(userNameTextBox) && visibilityOfElementLocated(passwordTextBox)) {
					extentReport.reportPass( "User is successfully viewed the Login Page ");
					sendKeys(userNameTextBox, username);
					sendKeys(passwordTextBox, password);
					extentReport.reportPass( "Actor entered Username and Password");
					clickElement(loginButton);
					waitForLoading();
					waitForLoading();
					if (isElementPresent(preferredMFAOption)) {
						if (visibilityOfElementLocated(continueButton))
						clickElement(continueButton);
						extentReport.reportPass( "Clicked continue button in the Preferred MFA Selection page");
						waitForLoading();
						if (visibilityOfElementLocated(sendVerificationCodeButton))
							clickElement(sendVerificationCodeButton);
						waitForLoading();
						String currentHandle = driver.getWindowHandle();
						//create object and pass otp value 
						List<String> otpList = CommonUtils.extractOTP(driver,"otp");
						driver.switchTo().window(currentHandle);
						for (String otp : otpList) {
							if (visibilityOfElementLocated(verificationCodeTextBox)) {
								sendKeys(verificationCodeTextBox, otp);
							} else {
								break;
							}
							extentReport.reportPass( "Entered OTP Value in  VerificationCode Text Box");
							if (visibilityOfElementLocated(verifyCodeButton))
							clickElement(verifyCodeButton);
							waitForLoading();
							waitForLoading();
						}
						
						if (isElementPresent(codeIncorrectError)) {
								extentReport.reportFail( "OTP is invalid and unable to login");
								throw new FrameworkException("OTP is invalid and unable to login");
						}
					}
				}
			}
			else {
				logger.info("Unable to find username field in login page" );
				extentReport.reportFail( "Unable to find username field in login page");
				throw new Exception();

			}
		} catch (Exception e) {
			System.out.println("*******Throwing Exception due to Username field****************");
			logger.info("Error occured in Login page" + e.getMessage());
			extentReport.reportFail( "Error occured in Login page");
			e.printStackTrace();
			throw e;
		}
	}



	@Override
	public boolean verifyLandingPage() {
		return false;
		// TODO Auto-generated method stub

	}



}

