package com.test.qa.ui.pageObjects.ClinicAdminLogin;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.utilities.CommonUtils;

public class ViewCustomerPage extends BasePage {
	public WebDriver driver;
	public ExtentReport extentReport;
	private ExtentTest extentTest;
	public DataBaseConnector dataBase = new DataBaseConnector();
	private final By customerNameInList = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[1]/a");

	public final By addSecLocCalcel = By.xpath("//button[@id='btn_pcs-home_Cancel']");
	public final By addSecLocsave = By.xpath("//button[@id='btn_pcs-home_Save']");
	public final By addSecLocCalcelok = By.xpath("//button[@id='btn_pcs-location-popup_Ok']");
	public final By addSecLocsaveok = By.xpath("//button[@id=\"btn_pcs-location-popup_Ok\"]");
	public final By addSecLocsavecancel = By.xpath("//button[@id='btn_pcs-location-popup_Cancel']");
	public String customerNameValue = CommonUtils.randomCustomerName();
	public String seclocation = CommonUtils.randomSecLoc();
	public String userIdValue = CommonUtils.randomUserId();
	public final By pageLoading = By.xpath("//*[@class='spinnerWrapper show']");
	public final By customerlistName = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[1]/a");
	private final By searchByCustomerName = By.xpath("//*[@id=\"txt_pcs-home_search\"]");
	private final By customerNameText = By.xpath("//input[@id=\"merlin_textbox_customerName\"]");
	private final By customerNameText_OR = By.xpath("//input[@id=\"txt_customer-head-quarters_customerName_customerName\"]");
	private String customerNameText_S= "Customer Name ";
	public final By addloctioncancel=By.xpath("//*[@id=\"btn_pcs-home_Cancel\"]");
	private final By customerLocationText = By.xpath("//input[@id='merlin_textbox_primaryLocation']");
	private final By customerLocationText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_clinicLocation_primaryLocation']");
	private String customerLocationText_S = "customerLocationText";
	private final By customerTypeDropdown = By
			.xpath("//div[@id=\"headQuarters\"]/div/div/div[2]/div/mat-form-field/div/div/div/mat-select");
	private final By customerTypeDropdown_OR= By
			.xpath("//div[@id=\"headQuarters\"]/div/div/div[2]/div/mat-form-field/div/div/div/mat-select");
	private String customerTypeDropdown_S= "customer TypeDropdown";
	private final By mainPhoneText = By.xpath("//input[@id='merlin_textbox_phoneNum']");
	private final By mainPhoneText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_mainPhone_phoneNum']");
	private String mainPhoneText_S = "Main Phone";
	private final By address1Text = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address1']//div/following::input");
	private final By address1Text_OR = By.xpath("//input[@id='txt_customer-clinicinfo_address1_streetAddress']");
	private String address1Text_S = "Address 1";

	private final By address2Text = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address2']//div/following::input");
	private final By address2Text_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address2']//div/following::input");
	private String address2Text_S = "Address 2";
	private final By address3Text = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address3']//div/following::input");
	private final By address3Text_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address3']//div/following::input");
	private String address3Text_S = "Address 3";
	private final By cityText = By.xpath("//input[@id='merlin_textbox_city']");
	private final By cityText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_city_city']");
	private String cityText_S ="City Text";
	private final By stateProvDropdown = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']/div/div/span/span");
	private final By stateProvDropdown_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']/div/div/span/span");
	private String  stateProvDropdown_S = "state Prov Dropdown";
	
	private final By countryDropdwon = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div/span/span");
	private final By countryDropdwon_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_countryCd']/div/div/span/span");
	private String countryDropdwon_S = "County DropDown";
	private final By zipPostalcodeText = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_zipCode']//div/following::input");
	private final By zipPostalcodeText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_zipCode']//div/following::input");
	private String zipPostalcodeText_S = "zip Postalcode Text";
	private final By secondaryPhoneText = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_secondaryPhone']//div/following::input");
	private final By secondaryPhoneText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_secondaryPhone']//div/following::input");
	private String secondaryPhoneText_S ="Secondary Phone Text";
	
	private final By emailText = By.xpath("//input[@id='merlin_textbox_emailAddress']");
	private final By emailText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_emailAddress_emailAddress']");
	
	private String emailText_S = "Email Text";
	
	private final By clinicTimeZoneDropdown = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_timeZoneCd']/div/div/span/span");
	private final By clinicTimeZoneDropdown_OR = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_timeZoneCd']/div/div/span/span");
	
	private String clinicTimeZoneDropdown_S = "clinic TimeZone Dropdown Text";
	
	private final By textMessageText = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_sms']//div/following::input");
	
	private final By textMessageText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_sms']//div/following::input");

	private String textMessageText_S = "Text Message";
public final By addSecondaryLocation = By.xpath("//button[@id='btn_customer_addSecondaryLocation']");
	private final By clinicLanguageDropdown = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd']/div/div/span/span");
	private final By clinicLanguageDropdown_OR = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd']/div/div/span/span");
	private String clinicLanguageDropdown_S ="clinicLanguageDropdown_S";
	private final By legalJurisdiction = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_legaJurisdictionCd']/div/div/span/span");
	private final By legalJurisdiction_OR = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_legaJurisdictionCd']/div/div/span/span");
	
	private String legalJurisdiction_S = "legalJurisdiction";
	private final By faxText = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_fax']//div/following::input");
	private final By faxText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_fax']//div/following::input");
	private String faxText_S= "Fax Time";
	private final By addSeclocationbutton = By.xpath("//*[@id=\"registration\"]/div[3]/button[1]/span");
	public final By addSeclocationtextbox = By.xpath("//input[@id=\"txt_pcs-home_clinic-secondaryLocation\"]");
	public final By addButton = By.xpath("//button[@id='btn_pcs-home_add-customer']");
	public final By addcustomercancelbutton = By.xpath("//*[@id=\"btn_customer_cancel\"]/span");
	private final By cancelbuttonOk = By.xpath(" //*[@id=\"btn_pcs-location-popup_Ok\"]/span");
	private final By merlinOnDemandCheckbox = By
			.xpath("//input[@id='mat-checkbox-3-input']");
	private final By merlinOnDemandCheckbox_OR = By
			.xpath("//input[@id='chb_customer-clinicinfo_capability-input']");
	private String merlinOnDemandCheckbox_S= "merlin OnDemand Checkbox";
	private final By testClinicCheckbox = By.xpath("//input[@id='mat-checkbox-1-input']");
	private final By testClinicCheckbox_OR = By.xpath("//input[@id='chb_customer-clinicinfo_test_clinic-input']");
	
	private String testClinicCheckbox_S = "testClinicCheckbox";
	
	private final By userIDText = By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_userId']//div/following::input");
	private final By userIDText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_userId']//div/following::input");
	private String userIDText_S = "User Id Text";
	
	private final By firstNameText = By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_firstName']//div/following::input");
	private final By firstNameText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_firstName']//div/following::input");
	private String firstNameText_S= "firstNameText";
	private final By mainEmailText = By.xpath(
			"//merlin-textbox[@id='txt_customer-clinic-main-contact_email']//div/following::input");
	private final By mainEmailText_OR = By.xpath(
			"//merlin-textbox[@id='txt_customer-clinic-main-contact_email']//div/following::input");
	
	private String mainEmailText_S = "mainEmailText_S";
	
	private final By middlenameText_OR = By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_middleName']//div/following::input");
	private String middlenameText_S ="Middle Name";
	

	private final By credentialsText = By
			.xpath("//mat-select[@id='dd_customer-clinic-main-contact_credentialsCd']/following::span/label/mat-label");
	private final By credentialsText_OR = By
			.xpath("//mat-select[@id='dd_customer-clinic-main-contact_credentialsCd']/div/div/span/span");
	private String credentialsText_S= "credentialsText_S";
	
	private final By colleagueEmailCheckbox = By.xpath(
			"//*[text()='Require recipient authentication to view Contact a Colleague emails']/preceding::input[1]");
	private final By unparredCheckbox = By.xpath(
			"//input[@id='chb_customer-security-settings_ctrlViewTX-input']");
	private final By unparredCheckbox_OR = By.xpath(
			"//input[@id='chb_customer-security-settings_ctrlViewTX-input']");

	private String unparredCheckbox_S ="unparredCheckbox";


	private final By alertCheckbox = By
			.xpath("//input[@id='chb_customer-feature-control_allowSmartAlertFlg-input']");
	private final By alertCheckbox_OR= By
			.xpath("//input[@id='chb_customer-feature-control_allowSmartAlertFlg-input']");
	private String alertCheckbox_S= "alertCheckbox";
	
	
	private final By sendvoicemessagesCheckbox = By.xpath("//input[@id='chb_customer-feature-control_allowDirectCallVoice-input']");
	private final By sendvoicemessagesCheckbox_OR= By.xpath("//input[@id='chb_customer-feature-control_allowDirectCallVoice-input']");

	private String sendvoicemessagesCheckbox_S = "sendvoicemessagesCheckbox_S";
	private final By activatorClinic_OR= By.xpath("//*[@id=\"chb_customer-clinicinfo_activator_clinic-input\"]");

	private String SctivatorClinic_S = "Activator Clinic";
	
	private final By sendtextmessagesCheckbox = By.xpath("//input[@id='chb_customer-feature-control_allowDirectCallText-input']");
	private final By sendtextmessagesCheckbox_OR = By.xpath("//input[@id='chb_customer-feature-control_allowDirectCallText-input']");
	private String sendtextmessagesCheckbox_S = "sendtextmessagesCheckbox_S";
	private final By HcustomerNameGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[1]/div/button");
	private final By HprimaryLocationGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[2]/div/button");
	private final By HcustomerTypeGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[3]/div/button");
	private final By HphoneNumGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[4]/div/button");

	/****Security settings Section: *****/
	private final By colleagueEmailsCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewCC\"]/label");
	private final By colleagueEmailsCheckbox_OR = By.xpath("//*[@id=\"chb_customer-security-settings_ctrlViewTX-input\"]");
	
	private String colleagueEmailsCheckbox_S = "colleagueEmailsCheckbox_S";
	
	private final By unpairedTransmitterEmailCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label");
	public final By receiveDirectAlertsCheckbox =By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_allSecureMsgs\"]/label/div");
	/****Application Control Section:***/
	private final By allowedApplication= By.xpath("//app-feature-control//div[1]/div/merlin-bucket-list//select/option[1]");

	/*****General Feature Control Section:*****/
	private final By recordPatientDataCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_showDataMiningConsentFlg\"]/label");
	private final By mobileDirectAlertCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_allowSmartAlertFlg\"]/label");
	private final By accessToCommunicationCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_allowCommCenterAccess\"]/label");
	private final By accessToComplianceCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_allowComplianceReport\"]/label");

	/*************Patient Messaging Feature Controls*******/
	private final By voiceMessagesFlag = By.xpath("//MAT-CHECKBOX[@id=\"chb_customer-feature-control_allowDirectCallVoice\"]");
	private final By textMessagesFlag = By.xpath("//MAT-CHECKBOX[@id=\"chb_customer-feature-control_allowDirectCallText\"]");

	/*************EP Application Feature Controls*******/
	private final By exportTransmissionCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_showExportSessionFlg\"]");
	private final By exportToEMREHRCheckbox = By.xpath("//*[@id=\"featureControl\"]/div/div[4]/div[1]/div/mat-form-field");
	private final By orderTransmitterCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-feature-control_orderTransmitterFlg\"]/label");

	final By customerNameShorting = By.xpath("//*[contains(@class,'customerName ')]");
	final By primaryLocationShorting = By.xpath("//*[contains(@class,'primaryLocation')]");
	final By customerTypeShorting = By.xpath("//*[contains(@class,'customerTypeDesc')]");
	final By phoneNumShorting = By.xpath("//*[contains(@class,'phoneNum')]");
	final By changeButton = By.xpath("//*[@id=\"btn_customer_changeCustomer\"]");
	
	//snehal
	private final By allowed_ep_directAlert_4NBLE_OR= By.xpath("//div[@id='lbl_customer-feature-control_allowed_electrophysiology_directAlert']//following-sibling::div//select");
	private final String allowed_ep_directAlert_4NBLE_S = "ALLOWED ELECTROPHYSIOLOGY DIRECTALERTS™ NOTIFICATIONS (FOR NON-BLUETOOTH DEVICES)";
	private final By dirAlert_Notif_Allow4Patient_NBLE_OR= By.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedInformPatientAlertIds']//div/select");
	private final String dirAlert_Notif_Allow4Patient_NBLE_S = "DIRECTALERTS™ NOTIFICATIONS ALLOWED FOR PATIENTS (WITH NON-BLUETOOTH DEVICES)";
	private final By allowed_ep_Devices_OR = By.xpath("//div[@id='lbl_customer-feature-control_Allowed_electrophysiology_devices']//following-sibling::div//select");    
	private final String allowed_ep_Devices_S = "ALLOWED ELECTROPHYSIOLOGY DEVICES";
	private final By allAbbottCustomersTab_OR = By.xpath("//a[@href='/dist/merlin-cloud/pcs-admin']");
	private final String allAbbottCustomersTab_S = "All Abbott Customers tab";
	private final By customerName_OR = By.xpath("//input[@id='merlin_textbox_customerName']");
	private final String customerName_S = "Customer Name";


	public ViewCustomerPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.driver = driver;
		this.extentReport = extentReport;
	}

	public void launchUrl() throws InterruptedException {
		getURL(CommonUtils.url);
		waitForLoading();
	}
	public  void cancel() throws Exception
	{ 
		try 
		{
			scrollToView(addcustomercancelbutton);
			presenceOfElementLocated(addcustomercancelbutton);

			extentReport.reportScreenShot( "User clicked on cancel button in Add Customer Page");
			clickElement(addcustomercancelbutton);
			invisibilityOfElementLocated(pageLoading);

			invisibilityOfElementLocated(pageLoading);
			extentReport.reportScreenShot( "User clicked on ok button in Add Customer Page cancel pop up");
			clickElement(cancelbuttonOk);
			invisibilityOfElementLocated(pageLoading);
		}
		catch(Exception e)
		{
			extentReport.fail( "User not able to cancel  ");
		}
	}
	
	
	// *************************** Alok - Start ***********************
	public void change() throws Exception
	{
	try
	{
	scrollToView(changeButton);
	presenceOfElementLocated(changeButton);

	extentReport.reportScreenShot( "User clicked on change utton in view Customer Page");
	clickElement(changeButton);
	invisibilityOfElementLocated(pageLoading);

	}
	catch(Exception e)
	{
	extentReport.fail( "User not able to change ");
	}

	}

	public boolean VerifyDirectCheckComplianceDay() throws InterruptedException {
	Boolean DirectCheckComplianceDay=false;

	if ( driver.getPageSource().contains("direct check compliance day")){
	DirectCheckComplianceDay=true;
	extentReport.reportScreenShot("Direct check compliance day is displayed ");
	}
	extentReport.reportScreenShot("Direct check compliance day is not displayed ");
	return DirectCheckComplianceDay;

	}

	// *************************** Alok - End ***********************
	public  void addseclocationcancel() throws Exception
	{ 
		try 
		{
			scrollToView(addSecLocCalcel);
			presenceOfElementLocated(addSecLocCalcel);
			clickElement(addSecLocCalcel);
			//extentReport.takeScreenShot("User clicked on cancel button in Add Customer Page");
			invisibilityOfElementLocated(pageLoading);
			//extentReport.takeScreenShot( "User clicked on ok button in Add Customer Page cancel pop up");
			clickElement(addSecLocCalcelok);
			invisibilityOfElementLocated(pageLoading);

			invisibilityOfElementLocated(pageLoading);
		}
		catch(Exception e)
		{
			extentReport.reportFail( "User not able to cancel  ");
		}
	}


	public void checkshoring(By locator, By Button, String Message) throws InterruptedException {
		waitForLoading();
		String content = "";
		clickElement(locator);
		waitForLoading();
		content = getAttribute(Button, "aria-sort");
		extentReport.reportInfo( Message + " is in  " + content);
		clickElement(locator);
		waitForLoading();
		content = getAttribute(Button, "aria-sort");
		extentReport.reportInfo( Message + " is in  " + content);
	}

	public String customerPageElementvalidation(By locator, String _Sobjname,String locatorText, String Message)
			throws InterruptedException {
		String content = "";
		this.extentTest = ExtentReport.node;
		try {
			System.out.println(locatorText);
			// System.out.println("GetText1");
			if (isElementPresent(locator,_Sobjname)) {
				visibilityOfElementLocatedWithoutReport(locator,_Sobjname);
				scrollToViewWithoutReport(locator,_Sobjname);

				// System.out.println("GetText2");
				if (locatorText.contains("value")) {
					content = getAttributeWithoutReport(locator,"value",_Sobjname);
					if (!content.isEmpty()) {
						extentTest.info( Message + " is Displayed as " + content);
					} else {
						extentTest.info( Message + " is Displayed and blank " + content);
					}
				} else if (locatorText.contains("Checkbox")) {
					content = getAttributeWithoutReport(locator, "aria-checked",_Sobjname);
					if (content.equals("false")) {
						extentTest.info( Message + " is  not Selected ");
					} else {
						extentTest.info( Message + " is  Selected ");
					}
				}

				else if (locatorText.contains("Dropdown")) {
					content = getText(locator,_Sobjname);
					if (content != null) {
						extentTest.info( Message + " is  Displayed as " + content);
					}
				} else if (locatorText.contains("Text")) {
					// System.out.println("Text");
					content = getText(locator,_Sobjname);
					extentTest.info( Message + " is Displayed as " + content);
				}
			} else {
				content = null;
				extentTest.info( Message + " is  Displayed as Blank ");
			}
			// return content;
		} catch (Exception e) {
			content = null;
			System.out.println(e);
			extentTest.fail( Message + " is not Displayed  ");
		}
		return content;
	}


	public boolean customerPageElementExistencesdd(String FieldName)throws InterruptedException {
		loading();
		boolean present = false;
		this.extentTest = ExtentReport.node;
		try {
			switch (FieldName) {
			case "ColleagueEmailsCheckbox":
				if (isElementPresent(colleagueEmailsCheckbox)) {
					visibilityOfElementLocated(colleagueEmailsCheckbox);
					scrollToView(colleagueEmailsCheckbox);
					extentTest.info( FieldName + " is Displayed /Available ");
					present = true;
				}
				break;
			}

		} catch (Exception e) {
			extentTest.info( FieldName + " is NOT Displayed /Available ");
		}
		return present;

	}


	public boolean customerPageElementExistence(String FieldName) throws Exception {
		boolean value = false;
		By element = null;
		try {
			switch (FieldName) {
			case "ColleagueEmailsCheckbox":
				element = colleagueEmailsCheckbox;
				break;
			case "UnpairedTransmitterEmailCheckbox":
				element = unpairedTransmitterEmailCheckbox;
				break;
			case "RecordPatientDataCheckbox":
				element = recordPatientDataCheckbox;
				break;
			case "MobileDirectAlertCheckbox":
				element = mobileDirectAlertCheckbox;
				break;
			case "AccessToCommunicationCheckbox":
				element = accessToCommunicationCheckbox;
				break;
			case "AccessToComplianceCheckbox":
				element = accessToComplianceCheckbox;
				break;
			case "VoiceMessagesFlag":
				element = voiceMessagesFlag;
				break;
			case "TextMessagesFlag":
				element = textMessagesFlag;
				break;
			case "ExportTransmissionCheckbox":
				element = exportTransmissionCheckbox;
				break;
			case "ExportToEMREHRCheckbox":
				element = exportToEMREHRCheckbox;
				break;
			case "OrderTransmitterCheckbox":
				element = orderTransmitterCheckbox;
				break;
			case "ReceiveDirectAlertsCheckbox":
				element = receiveDirectAlertsCheckbox;
				break;

			}



			if (isElementPresent(element)) {
				visibilityOfElementLocated(element);
				scrollToView(element);
				value = true;
			}
			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	public String getAllowedAppications(String appName) throws Exception {
		By element =allowedApplication	;
		//String appName="";
		if (isElementPresent(element)) {
			visibilityOfElementLocated(element);
			scrollToView(element);

		}
		appName = getText(element);

		List<WebElement> apps =findElementslist(element);
		System.out.println("Numper of Apps ---->  "+apps.size());	
		/*	for (int i = 1; i < apps.size(); i++) {

			appName = getText(apps);
		}
		 */
		return appName.trim();
	}

	public String VerifyCustomerDataInViewMode(String FieldName) throws Exception {

		String value = "";
		try {

			switch (FieldName) {
			case "CustomerName":
				value = customerPageElementvalidation(customerNameText_OR, customerNameText_S,"value", "Customer Name Textbox");
				break;
			case "CustomerType":
			
				value = customerPageElementvalidation(customerTypeDropdown_OR,customerTypeDropdown_S, "countryDropdown", "Customer Name Textbox");
				break;
			case "CustomerLocation":
				value = customerPageElementvalidation(customerLocationText_OR,customerLocationText_S, "value", "customer Location Textbox");
				break;
			case "CustomerMainPhone":
				value = customerPageElementvalidation(mainPhoneText_OR,mainPhoneText_S, "value", "Main Phone Textbox");
				break;
			case "CustomerAddressText":
				value = customerPageElementvalidation(address1Text_OR,address1Text_S, "value", "address Textbox");
				break;
			case "CustomerCityText":
				value = customerPageElementvalidation(cityText_OR,cityText_S, "value", " city Textbox");
				break;
			case "CustomerStateProv":
				value = customerPageElementvalidation(stateProvDropdown_OR,stateProvDropdown_S,"stateProvDropdown", " state/Prov Dropdown");
				break;
			case "CustomerCountry":
				value = customerPageElementvalidation(countryDropdwon_OR,countryDropdwon_S, "countryDropdown", " country Dropdwon");
				break;
			case "CustomerPostalCode":
				value = customerPageElementvalidation(zipPostalcodeText_OR,zipPostalcodeText_S, "value", " zipPostalcode Textbox");
				break;
			case "CustomerSecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText_OR,secondaryPhoneText_S, "value", " secondary Phone Textbox");
				break;
				
			case "CustomerMiddleName":
				value = customerPageElementvalidation(middlenameText_OR, middlenameText_S,"value", "Middle name Textbox");
				break;
			case "CustomerEmail":
				value = customerPageElementvalidation(emailText_OR,emailText_S, "value", " email Textbox");
				break;
			case "CustomerFax":
				value = customerPageElementvalidation(faxText_OR,faxText_S, "value", " fax Textbox");
				break;
			case "CustomerTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown_OR, clinicTimeZoneDropdown_S,"clinicTimeZoneDropdown",
						" clinicTimeZone Dropdown");
				break;
			case "CustomerTextMessage":
				value = customerPageElementvalidation(textMessageText_OR,textMessageText_S, "value", " textMessage Textbox");
				break;
			case "CustomerJurisdiction":
				value = customerPageElementvalidation(legalJurisdiction_OR,legalJurisdiction_S, "legalJurisdictionDropdown",
						" legal Jurisdiction");
				break;

			case "CustomerOnDemandCheckbox":
				value = customerPageElementvalidation(merlinOnDemandCheckbox_OR,merlinOnDemandCheckbox_S, "merlinOnDemandCheckbox",
						" merlin OnDemand Checkbox");
				
				break;
			case "CustomerTestClinic":
				customerPageElementvalidation(testClinicCheckbox_OR,testClinicCheckbox_S, "testClinicCheckbox", " test Clinic Checkbox");
				break;
			case "CustomerUserID":
				value = customerPageElementvalidation(userIDText_OR,userIDText_S, "value", "Main user ID");
				break;
			case "CustomerFirstName":
				value = customerPageElementvalidation(firstNameText_OR,firstNameText_S, "value", "first Name Textbox");
				break;
			case "CustomerMainEmail":
				value = customerPageElementvalidation(mainEmailText_OR,mainEmailText_S, "value", "Main Email Textbox");
				break;
			case "CustomerMName":
				value = customerPageElementvalidation(middlenameText_OR,middlenameText_S, "value", "Middle name Textbox");
				break;

			case "CustomerCredentials":
				value = customerPageElementvalidation(credentialsText_OR,credentialsText_S, "credentialsTextdropdown", "credentials Textbox");
				break;

			case "ColleagueEmailsCheckbox":	
				scrollToView(colleagueEmailsCheckbox_OR);
				value = customerPageElementvalidation(colleagueEmailsCheckbox_OR,colleagueEmailsCheckbox_S, "unparredCheckbox", "colleagueEmailsCheckbox");
				break;
			case "CustomerUnpaired":
				value = customerPageElementvalidation(unparredCheckbox_OR,unparredCheckbox_S, "unparredCheckbox", "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				value = customerPageElementvalidation(alertCheckbox_OR,alertCheckbox_S, "alertCheckbox", " Alert Checkbox");
				break;
			case "CustomerSendTextMessage":
				value = customerPageElementvalidation(sendtextmessagesCheckbox_OR, sendtextmessagesCheckbox_S,"sendtextmessagesCheckbox",
						"Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox_OR,sendvoicemessagesCheckbox_S, "sendvoicemessagesCheckbox",
						"SendvoicemessagesCheckbox");
				break;
			case "ActivatorClinic":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox_OR,sendvoicemessagesCheckbox_S, "ActivatorClinicCheckbox",
						"ActivatorClinicCheckbox");
				break;
			case "CustomerLanguage":
				value= customerPageElementvalidation(clinicLanguageDropdown_OR,clinicLanguageDropdown_S, "clinicLanguageDropdown"," clinic Language Dropdown");

			}

			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	@Override
	public void loading()
	{

		invisibilityOfElementLocated(pageLoading);
	}
	public void customerpageshortingValidation() throws InterruptedException {
		waitForLoading();
		customerPageElementvalidation(HcustomerNameGetText,"HcustomerNameGetText", "Text", "customer Name Header");
		extentReport.reportInfo( "User clicks on Cutomer Name to check sorting ");
		checkshoring(HcustomerNameGetText, customerNameShorting, "Customer Name");
		customerPageElementvalidation(HprimaryLocationGetText,"HprimaryLocationGetText", "Text", "Location Header");
		extentReport.reportInfo( "User clicks on Location to check sorting");
		checkshoring(HprimaryLocationGetText, primaryLocationShorting, "Location ");
		customerPageElementvalidation(HcustomerTypeGetText, "HcustomerTypeGetText","Text", "customer Type Header");
		extentReport.reportInfo( "User clicks on Customer Type to check sorting");
		checkshoring(HcustomerTypeGetText, customerTypeShorting, "Customer Type");
		customerPageElementvalidation(HphoneNumGetText,"HphoneNumGetText", "Text", "Telephone No");
		extentReport.reportInfo( "User clicks on Telephone No to check sorting");
		checkshoring(HphoneNumGetText, phoneNumShorting, "Telephone No");

	}

	public void customerPageValidation() throws InterruptedException {
		waitForLoading();
		customerPageElementvalidation(customerNameText,"customerNameText", "value", "customer Name Textbox");
		customerPageElementvalidation(customerTypeDropdown,"customerTypeDropdown", "customerTypeDropdown", "customer Type Dropdown");
		customerPageElementvalidation(customerLocationText,"customerLocationText", "value", "customer Location Textbox");
		customerPageElementvalidation(mainPhoneText, "mainPhoneText","value", "Main Phone Textbox");
		customerPageElementvalidation(address1Text,"address1Text", "value", "address Textbox");
		customerPageElementvalidation(cityText,"cityText", "value", " city Textbox");
		customerPageElementvalidation(stateProvDropdown,"stateProvDropdown", "stateProvDropdown", " state/Prov Dropdown");
		customerPageElementvalidation(countryDropdwon,"countryDropdwon", "countryDropdwon", " country Dropdwon");
		customerPageElementvalidation(zipPostalcodeText,"zipPostalcodeText", "value", " zipPostalcode Textbox");
		customerPageElementvalidation(secondaryPhoneText,"secondaryPhoneText", "value", " secondary Phone Textbox");
		customerPageElementvalidation(middlenameText_OR,"middlenameText_OR", "value", "Middle name Textbox");
		customerPageElementvalidation(emailText,"emailText", "value", " email Textbox");
		customerPageElementvalidation(faxText,"faxText", "value", " fax Textbox");
		customerPageElementvalidation(clinicTimeZoneDropdown,"clinicTimeZoneDropdown", "clinicTimeZoneDropdown", " clinicTimeZone Dropdown");
		customerPageElementvalidation(textMessageText,"textMessageText", "value", " textMessage Textbox");
		customerPageElementvalidation(legalJurisdiction,"legalJurisdiction", "legalJurisdiction",
				" legal Jurisdiction");
		customerPageElementvalidation(merlinOnDemandCheckbox,"merlinOnDemandCheckbox", "merlinOnDemandCheckbox", " merlin OnDemand Checkbox");
		customerPageElementvalidation(testClinicCheckbox,"testClinicCheckbox", "testClinicCheckbox", " test Clinic Checkbox");
		customerPageElementvalidation(userIDText,"userIDText", "value", "Main user ID");
		customerPageElementvalidation(firstNameText, "firstNameText","value", "first Name Textbox");
		customerPageElementvalidation(mainEmailText,"mainEmailText", "value", "Main Email Textbox");
		customerPageElementvalidation(middlenameText_OR,"middlenameText_OR", "value", "Middle name Textbox");

		customerPageElementvalidation(credentialsText,"credentialsText", "value", "credentials Textbox");
		customerPageElementvalidation(colleagueEmailCheckbox,"colleagueEmailCheckbox", "colleagueEmailCheckbox", "colleague Email Checkbox");
		customerPageElementvalidation(unparredCheckbox,"unparredCheckbox", "unparredCheckbox", "unparred Checkbox");

		customerPageElementvalidation(alertCheckbox,"alertCheckbox", "alertCheckbox", " Alert Checkbox");
		customerPageElementvalidation(sendtextmessagesCheckbox,"sendtextmessagesCheckbox", "sendtextmessagesCheckbox",
				"Send Text Message Chechbox");
		customerPageElementvalidation(sendvoicemessagesCheckbox,"sendvoicemessagesCheckbox", "sendvoicemessagesCheckbox",
				"SendvoicemessagesCheckbox");
		customerPageElementvalidation(clinicLanguageDropdown,"clinicLanguageDropdown", "clinicLanguageDropdown", " clinic Language Dropdown");

		scrollToView(changeButton);
		presenceOfElementLocated(changeButton);
		extentReport.reportPass( "User clicked on Change button  ");
		clickElement(changeButton);
		waitForLoading();
		scrollToView(addcustomercancelbutton);
		presenceOfElementLocated(addcustomercancelbutton);

		clickElement(addcustomercancelbutton);
		extentReport.reportPass( "User clicked on cancel button ");

		waitForLoading();
		clickElement(cancelbuttonOk);
		extentReport.reportPass( "User clicked on ok button ");
		extentReport.reportPass( "User  is in Customer List page  ");
		invisibilityOfElementLocated(pageLoading);
	}

	public void customerPageValidation1() throws InterruptedException {
		waitForLoading();
		customerPageElementvalidation(customerNameText,"customerNameText", "value", "customer Name Textbox");
	}


	/****Security settings Section: 
	 * @throws Exception *****/
	public void verifySecuritySettings_colleagueEmail() throws Exception {
		/*
		 * waitForLoading(); scrollToView(colleagueEmailsCheckbox);
		 */
		customerPageElementExistence("colleagueEmailsCheckbox");	
	}
	
	public void ViewCustomerProfile_PageComponents() throws Exception {
		 extentReport.reportInfo(" Customer headquarters section: ");
		 CommonUtils.extentTest = extentTest;
		VerifyCustomerDataInViewMode("CustomerName");
		VerifyCustomerDataInViewMode("CustomerType");
		extentReport.reportInfo(" Clinic information section: ");
		CommonUtils.extentTest = extentTest;
		VerifyCustomerDataInViewMode("CustomerLocation");
		VerifyCustomerDataInViewMode("CustomerMainPhone");
		VerifyCustomerDataInViewMode("CustomerAddressText");
		VerifyCustomerDataInViewMode("CustomerCityText");
		VerifyCustomerDataInViewMode("CustomerStateProv");
		VerifyCustomerDataInViewMode("CustomerCountry");
		VerifyCustomerDataInViewMode("CustomerPostalCode");
		
		VerifyCustomerDataInViewMode("CustomerSecondaryPhone");
		VerifyCustomerDataInViewMode("CustomerMiddleName");
		VerifyCustomerDataInViewMode("CustomerEmail");
		
		VerifyCustomerDataInViewMode("CustomerFax");
		VerifyCustomerDataInViewMode("CustomerTimeZone");
		VerifyCustomerDataInViewMode("CustomerTextMessage");
		VerifyCustomerDataInViewMode("CustomerJurisdiction");
		
		VerifyCustomerDataInViewMode("CustomerOnDemandCheckbox");
		VerifyCustomerDataInViewMode("CustomerTestClinic");
		extentReport.reportInfo("Clinic main contact section:");
		CommonUtils.extentTest = extentTest;
		VerifyCustomerDataInViewMode("CustomerUserID");
		VerifyCustomerDataInViewMode("firstNameText");
		VerifyCustomerDataInViewMode("mainEmailText");
		VerifyCustomerDataInViewMode("middlenameText");
		VerifyCustomerDataInViewMode("CustomerCredentials");
		VerifyCustomerDataInViewMode("CustomerUnpaired");
		VerifyCustomerDataInViewMode("CustomerAlertCheckbox");
		VerifyCustomerDataInViewMode("CustomerSendTextMessage");
		VerifyCustomerDataInViewMode("ActivatorClinic");
		                                                                                                                                                  
		VerifyCustomerDataInViewMode("CustomerSendVoiceMessage");
		VerifyCustomerDataInViewMode("CustomerLanguage");
		extentReport.takeFullSnapShot(driver,"View Page full Screen Shot");
		extentReport.info("Test Case Ends");	
	}

	public void verifySecuritySettingsunpairedTransmitterEmail() throws InterruptedException {
		waitForLoading();
		scrollToView(unpairedTransmitterEmailCheckbox);
		customerPageElementvalidation(unpairedTransmitterEmailCheckbox,"unpairedTransmitterEmailCheckbox", "unpairedTransmitterEmailCheckbox", "unpairedTransmitterEmailCheckbox");	
	}


	//private final By colleagueEmailsCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewCC\"]/label");
	//private final By unpairedTransmitterEmailCheckbox = By.xpath("//mat-checkbox[@id=\"chb_customer-security-settings_ctrlViewTX\"]/label");
	public void pageload()
	{
		invisibilityOfElementLocated(pageLoading);
	}
	public void customerPageNavigationValidation() throws Exception {
		// invisibilityOfElementLocated(pageLoading);
		waitForLoading();
		scrollToView(addButton);
		waitForLoading();
		invisibilityOfElementLocated(pageLoading);
		clickElement(addButton);
		waitForLoading();
		invisibilityOfElementLocated(pageLoading);
		scrollToView(addcustomercancelbutton);
		presenceOfElementLocated(addcustomercancelbutton);
		extentReport.reportPass( "Add Customer Page is Displayed ");
		clickElement(addcustomercancelbutton);
		extentReport.reportPass( "User clicked on cancel button in Add Customer Page");

		waitForLoading();
		clickElement(cancelbuttonOk);
		extentReport.reportPass( "User clicked on ok button in Add Customer Page");

		invisibilityOfElementLocated(pageLoading);
		Thread.sleep(3000);
		clickElement(customerlistName);
		extentReport.reportPass( "Customer List is displayed and user clicked on Existing customer Name ");
		Thread.sleep(3000);
		invisibilityOfElementLocated(pageLoading);
		scrollToView(changeButton);
		presenceOfElementLocated(changeButton);
		extentReport.reportPass( "User clicked on Change button ");
		clickElement(changeButton);
		waitForLoading();
		scrollToView(addcustomercancelbutton);
		presenceOfElementLocated(addcustomercancelbutton);
		clickElement(addcustomercancelbutton);
		extentReport.reportPass( "User clicked on cancel button ");
		waitForLoading();
		scrollToView(cancelbuttonOk);
		waitForLoading();
		clickElement(cancelbuttonOk);
		extentReport.reportPass( "User clicked on ok button ");

		extentReport.reportPass( "User  is in Customer List page  ");

	}

	public void customerList() throws Exception {
		try {
			invisibilityOfElementLocated(pageLoading);
			waitForLoading();
			presenceOfElementLocated(customerlistName);
			extentReport.reportPass( "Customer list is displayed ");
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail( "Customer list is not displayed ");
			throw e;
		}
	}
	public void customerListclick() throws Exception {
		try {
			invisibilityOfElementLocated(pageLoading);
			waitForLoading();
			presenceOfElementLocated(customerlistName);
			clickElement(customerlistName);
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
		} catch (Exception e) {
			e.printStackTrace();

			throw e;
		}
	}
	public void customerSearch(String searchtext) throws Exception {

		scrollToView(searchByCustomerName);
		sendKeys(searchByCustomerName, searchtext);
		Thread.sleep(6000);

		final By customernameListSize = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td/a");

		List<WebElement> customerNamelist = findElementslist(customernameListSize);
		// driver.findElements(By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td/a"));
		// List<WebElement> list3 =
		// driver.findElements(By.xpath("//*[@id='tblHeader']/thead/tr[1]/th/img[@class='collapse']"));

		try {
			extentReport.reportInfo( "User is Searching with Text " + searchtext);

			for (int i = 1; i < customerNamelist.size(); i++) {
				int j = i;
				Thread.sleep(500);
				invisibilityOfElementLocated(pageLoading);
				final By locationlocator = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr[" + j + "]/td[2]");
				final By customerNamelocator = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr[" + j + "]/td[1]/a");
				final By customerType = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr[" + j + "]/td[3]");
				final By phoneNumber = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr[" + j + "]/td[4]");
				System.out.println(j);

				scrollToViewlist(customerNamelist.get(j));
				// System.out.println("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[1]/a");
				String customerName = getAttribute(customerNamelocator, "innerText");
				// driver.findElement(By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[1]/a")).getAttribute("innerText");
				String location = getAttribute(locationlocator, "innerText");
				String customertype = getAttribute(customerType, "innerText");
				String phonenumber = getAttribute(phoneNumber, "innerText");
				// driver.findElement(By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[2]")).getAttribute("innerText");
				customertype = customertype.toUpperCase();
				customerName = customerName.toUpperCase();
				phonenumber = phonenumber.toUpperCase();
				location = location.toUpperCase();
				searchtext = searchtext.toUpperCase();
				System.out.println(customerName);
				System.out.println(location);
				boolean check = false;
				System.out.println(customerName.equalsIgnoreCase(searchtext));
				if (customerName.contains(searchtext)) {
					extentReport.reportPass( "Customer name is displayed with search text " + customerName);
					check = true;
				}
				if (location.contains(searchtext)) {
					extentReport.reportPass( "Location is displayed with search text " + location);
					check = true;
				}

				if (phonenumber.contains(searchtext)) {
					extentReport.reportPass( "Phone number is displayed with search text " + phonenumber);
					check = true;
				}
				if (customertype.contains(searchtext)) {
					extentReport.reportPass( "Customer Type is displayed with search text " + customertype);
					check = true;
				}
				if (!check) {
					extentReport.reportFail( "Result is not displayed in Row " + i);
				}

			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void customerProfileselect(String customerName) throws Exception {
		try {

			invisibilityOfElementLocated(pageLoading);
			waitForLoading();
			presenceOfElementLocated(customerlistName);
			sendKeys(searchByCustomerName, customerName);

			extentReport.reportInfo( "User enter " + customerName + " in the Seach Field");
			waitForLoading();
			waitForLoading();
			clickElement(customerlistName);
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
			Thread.sleep(5000);
			invisibilityOfElementLocated(pageLoading);

			extentReport.reportInfo(
					"Customer Profile page is displayed with customer's details pre-populated");

		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail( "Customer name is not displayed ");
			throw e;
		}
	}

	public String AddSecondarylocation() throws Exception {
		try {
			invisibilityOfElementLocated(pageLoading);
			scrollToView(addSeclocationbutton);
			waitForLoading();
			clickElement(addSeclocationbutton);
			waitForLoading();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return customerNameValue;
	}
	public void clickOnAddCustomerButton() throws InterruptedException {


		scrollToView(addButton);
		extentReport.reportScreenShot( "The actor clicks the Add a customer button ");
		clickElement(addButton);
		invisibilityOfElementLocated(pageLoading);
	}


	public String searchCustomer() throws Exception {
		try {
			waitForLoading();
			extentReport.reportPass( "Search Customer from the list of customers");
			// sendKeys(searchCustomerbox, customerNameValue.toLowerCase());
			waitForLoading();
			presenceOfElementLocated(customerNameInList);
			String customerName = getText(customerNameInList);
			extentReport.reportPass( "The system displays Customer List Page with newly added customer");
			return customerName;

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	//Snehal
		public String getLegalJurisdictionValue() {
			scrollToView(legalJurisdiction);
			String JurisdictionVal = getText(legalJurisdiction);
			extentReport.reportScreenShot("Legal Jurisdiction = "+JurisdictionVal);
			return JurisdictionVal;
		}
		
		//Snehal
		public void jurisdictionAlertValidation(String locaterName) throws IOException {
			By locator = null;
			String sheetName = "";
			String jurisdiction = getLegalJurisdictionValue();
			if (jurisdiction.equalsIgnoreCase("United States")) {
				extentReport.pass("Alerts validation for United States" );
				if(locaterName.equals("dirAlert_Notif_Allow4Patient_NBLE_S")) {
					locator = dirAlert_Notif_Allow4Patient_NBLE_OR;
					sheetName = "DirectAlerts_Patient_NonBT(US)";
				}
				else if(locaterName.equals("allowed_ep_directAlert_4NBLE_S")) {
					locator = allowed_ep_directAlert_4NBLE_OR;
					sheetName = "EP_DirectAlerts_NonBT(US)";
				}
				else  {
					extentReport.fail("Alerts not found" );		
				}
			}
			else {
				extentReport.pass("Alerts validation for " + jurisdiction);	
				if(locaterName.equals("dirAlert_Notif_Allow4Patient_NBLE_S")) {
					locator = dirAlert_Notif_Allow4Patient_NBLE_OR;
					sheetName = "DirectAlerts_Patient_NonBT(OUS)";
				}
				else if(locaterName.equals("allowed_ep_directAlert_4NBLE_S")) {
					locator = allowed_ep_directAlert_4NBLE_OR;
					sheetName = "EP_DirectAlerts_NonBT(OUS)";
				}
				else  {
					extentReport.fail("Alerts not found" );		
				}
			}		
						
			ArrayList<String> excelData = TestDataProvider.readJurisdictionAlerts(jurisdiction, sheetName);
			ArrayList<String> appData = getJurisdictionAlerts(getOptions(locator));
			ArrayList<String> missedValue = new ArrayList<>();
			for (String value : appData) {
				if (!excelData.contains(value))
					missedValue.add(value);
			}
			
			if (missedValue.isEmpty()) {
				extentReport.pass("Jurisdiction Alert validation is completed successfully");			
			}
			else {
				for(int i=0; i<missedValue.size(); i++) {
					String missingVal = missedValue.get(i);
					System.out.println(missingVal + " is not present");
				}
				extentReport.fail("Jurisdiction Alert validation is not completed successfully");
			}
			
		}
		
		//Snehal
		public ArrayList<String> getJurisdictionAlerts(List<WebElement> options) {
			extentReport.reportScreenShot("List of Alerts displayed");
			String attrVal = "codeDesc";

			ArrayList<String> jurisdictionAlerts = new ArrayList<String>();
			for (int a = 0; a < options.size(); a++) {
				JsonObject jsonObject = new JsonParser().parse(options.get(a).getAttribute("value")).getAsJsonObject();
				String value = jsonObject.get(attrVal).getAsString();
				jurisdictionAlerts.add(value);
			}
			return jurisdictionAlerts;
		}
	
	public void jurisdictionAllowedDeviceValidation() throws IOException {
		By locator = allowed_ep_Devices_OR;
		String jurisdiction = getLegalJurisdictionValue();
		String sheetName = "";
		if (jurisdiction.equalsIgnoreCase("United States")) {
			extentReport.pass("Device validation for United States" );
			sheetName = "US_devices";
		}
		else if (jurisdiction.equalsIgnoreCase("Japan")) {
			extentReport.pass("Device validation for Japan" );
				sheetName = "JA_devices";
			}
		else if (jurisdiction.equalsIgnoreCase("Canada")) {
			extentReport.pass("Device validation for Canada" );
			sheetName = "CA_device";
		}
		else if (jurisdiction.equalsIgnoreCase("Europe")) {
			extentReport.pass("Device validation for Europe" );
			sheetName = "EU_device";
		}
		else  {
			extentReport.pass("Device validation for Australia/New Zealand" );
			sheetName = "AU_device";
		}
		
		ArrayList<String> excelData = TestDataProvider.readJurisdictionDevices(sheetName);
		ArrayList<String> appData = getJurisdictionDevice(getOptions(locator));
		ArrayList<String> missedValue = new ArrayList<>();
		for (String value : appData) {
			if (!excelData.contains(value))
				missedValue.add(value);
		}
		
		if (missedValue.isEmpty()) {
			extentReport.pass("Jurisdiction Device validation is completed successfully");		
		}
		else {
			for(int i=0; i<missedValue.size(); i++) {
				String missingVal = missedValue.get(i);
				System.out.println(missingVal + " is not present");
			}
			 extentReport.fail("Jurisdiction Device validation is not completed successfully");
		}
	}
	
	public ArrayList<String> getJurisdictionDevice(List<WebElement> options) {
		extentReport.reportScreenShot("List of devices displayed");
		ArrayList<String> jurisdictionDevice = new ArrayList<String>();
		for (int a = 0; a < options.size(); a++) {
			JsonObject jsonObject = new JsonParser().parse(options.get(a).getAttribute("value")).getAsJsonObject();
			String value = jsonObject.get("deviceModelNum").getAsString();
			jurisdictionDevice.add(value);
		}
		return jurisdictionDevice;
	}
	
	//Snehal
	public void clicktoAllAbbottCustTab() {
		scrollToView(allAbbottCustomersTab_OR);
		clickElement(allAbbottCustomersTab_OR, allAbbottCustomersTab_S);
	}

	//Snehal
		public boolean verifySearchedCustomerProfilePage(String CustmerName) throws InterruptedException {
			Boolean flag = false;
			loading();
			presenceOfElementLocatedWithReport(customerName_OR, customerName_S);
			 String custName = getAttribute(customerName_OR, "value");
			 if(custName.equals(CustmerName)) {
				 flag = true;
			 }
			 return flag;
		}
		

	@Override
	public boolean verifyLandingPage() {
		Boolean Check = false;

		if (verifyElement(addSeclocationtextbox)) {
			Check=true;
		}
		if (verifyElement(addSecLocsave)) {
			Check=true;
		}



		return Check;

	}

	
}
