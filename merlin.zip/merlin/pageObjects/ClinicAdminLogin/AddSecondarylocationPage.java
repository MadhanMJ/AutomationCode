
package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import java.util.Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.utilities.CommonUtils;

public class AddSecondarylocationPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	// XPath Updated on 02/19/2022- ChandraMohan.S
	//public final By AllAbbottCustomerMenu_OR = By.xpath("//*[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[1]");
	public final By AllAbbottCustomerMenu_OR = By.xpath("//mat-toolbar/mat-toolbar-row/div/ul/li[2]");
	private final String AllAbbottCustomerMenu_S ="AllAbbottCustomer Top Left Menu";

	private final By customerNameText_OR = By.xpath("//input[@id=\"txt_pcs-home_customer-name\"]");
	private final String customerNameText_S ="Customer Name";

	private final By customerTypeText_OR = By.xpath("//input[@id=\"txt_pcs-home_customer-type\"]");
	private final String customerTypeText_S ="Customer Type Value ";

	private final By address1Text_OR = By.xpath("//input[@id=\"txt_pcs-home_Address1\"]");
	private final String address1Text_S ="address1 Value ";

	private final By address2Text_OR = By.xpath("//input[@id=\"txt_pcs-home_Address2\"]");
	private final String address2Text_S ="address2Value ";

	private final By address3Text_OR = By.xpath("//input[@id=\"txt_pcs-home_Address3\"]");
	private final String address3Text_S ="address3 Value ";

	private final By emailText_OR = By.xpath("//input[@id=\"txt_pcs-home_Email\"]");
	private final String emailText_S ="EmailId Value ";

	private final By clinicTimeZoneText_OR = By.xpath("//input[@id=\"txt_pcs-home_clinic-time-zone\"]");
	private final String clinicTimeZoneText_S ="Clinic TimeZone Value ";

	private final By legalJurisdictionText_OR = By.xpath("//input[@id=\"txt_pcs-home_legalJurisdiction\"]");
	private final String legalJurisdictionText_S ="LegalJurisdiction country ";

	private final By clinicLanguageText_OR = By.xpath("//input[@id=\"txt_pcs-home_clinic-language\"]");
	private final String clinicLanguageText_S ="Clinic Language ";

	private final By countryText_OR = By.xpath("//input[@id=\"txt_pcs-home_country\"]");
	private final String countryText_S ="Country Name ";

	private final By zipPostalcodeText_OR = By.xpath("//input[@id=\"txt_pcs-home_zipCode\"]");
	private final String zipPostalcodeText_S ="ZipPostalcode Number ";

	private final By mainPhoneText_OR = By.xpath("//input[@id=\"txt_pcs-home_main-phone\"]");
	private final String mainPhoneText_S ="MainPhone Number ";

	private final By secondaryPhoneText_OR= By.xpath("//input[@id=\"txt_pcs-home_secondary-phone\"]");
	private final String secondaryPhoneText_S ="SecondaryPhone Number ";

	private final By faxText_OR = By.xpath("//input[@id=\"txt_pcs-home_Fax\"]");
	private final String faxText_S ="Fax Number ";
	private final By cityText_OR = By.xpath("//input[@id=\"txt_pcs-home_city\"]");
	private final String cityText_S ="City Name ";

	private final By customerLocationText_OR = By.xpath("//input[@id=\"txt_pcs-home_clinic-secondaryLocation\"]");
	private final String customerLocationText_S ="customerLocation";

	private final By addasecondarylocationPageTitle_OR = By.xpath("//*[contains(text(),\"Add a secondary location\")]");
	private final String addasecondarylocationPageTitle_S = "Add a Secondarylocation Page Title";

	private final By clinicSecondaryLocationTextBox_OR = By.xpath("//input[@id=\"txt_pcs-home_clinic-secondaryLocation\"]");	
	private final String clinicSecondaryLocationTextBox_S = "Clinic Secondary Location TextBox";
	private final By addasecondarylocationLable = By.xpath("//div[@id=\"secondary-location\"]/div[2]/div/merlin-section/mat-card/div/div");

	private final By clinicSecLocaEmptyMsg_OR =By.xpath("//MAT-ERROR[starts-with(@id,'mat-error-')]");
	private final String clinicSecLocaEmptyMsg_S ="This field should not be empty...Message ";

	private final By saveButton_OR = By.xpath("//BUTTON[@id=\"btn_pcs-home_Save\"]");
	private final String saveButton_S = "SAVE button";

	private final By cancelButton_OR = By.xpath("//BUTTON[@id=\"btn_pcs-home_Cancel\"]");
	private final String cancelButton_S ="CANCEL button";

	private final By warningMsg_OR = By.xpath("//MAT-ERROR[@class=\"mat-error ng-star-inserted\"]");
	private final String warningMsg_S ="Warning Message";

	private final By existingLocWarning_OR = By.xpath("//DIV[@id=\"toast-container\"]/div");
	private final String existingLocWarning_S ="ExistingLocation Warning Message";

	private final By popUpCancelButton_OR = By.xpath("//BUTTON[@id=\"btn_pcs-location-popup_Cancel\"]/span");
	private final String popUpCancelButton_S="CancelButton in popUp";

	private final By popUpOkButton_OR = By.xpath("//BUTTON[@id=\"btn_pcs-location-popup_Ok\"]");
	private final String popUpOkButton_S="OK Button in popUp";

	private final By toasterMsg_OR = By.xpath("//div[@id=\"toast-container\"]");
	private final String toasterMsg_S="Confirmation Message ";

	private final By aD811Dialog_OR = By.xpath("//div[@id=\"toast-container\"]");
	private final String aD811Dialog_S="AD 811 dialog";

	public final String signOutMessage = "Thank you for visiting Abbott Merlin.net� Patient Care Network. You are now logged out. To prevent possible misuse of the system, you should now close this browser window.";
	public final String existingLocWarningMessage = "This Location name is already in use. Please specify a different Location name";
	public String addSecondaryLocationValue = null;
	public boolean clinicSecLocEmptyMsg = false;
	public static Log logger = new Log();

	public AddSecondarylocationPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
	}

	public void addSecondaryLocationValue(String clinicSecondaryLocationValue, boolean save) throws Exception {
		try {
			if (verifyLandingPage()) {
				presenceOfElementLocated(clinicSecondaryLocationTextBox_OR);
				scrollToView(clinicSecondaryLocationTextBox_OR);
				extentReport.reportScreenShot("User enters secondary location value is  ' "+clinicSecondaryLocationValue+" '");

				sendKeys(clinicSecondaryLocationTextBox_OR, clinicSecondaryLocationValue);

				if(save) {
					clickSaveButton();
					clickPopUpOkButton();
					clicktoasterMsg();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public String enterRandomSecondaryLocationValue() throws Exception {
		String randomSecondaryLocationValue=CommonUtils.randomSecLocation();
		try {
			presenceOfElementLocated(clinicSecondaryLocationTextBox_OR);
			System.out.println("clinicSecondaryLocationTextBox is located");
			sendKeys(clinicSecondaryLocationTextBox_OR, randomSecondaryLocationValue);
			//extentReport.info(reportMsg);
			extentReport.reportScreenShot("The actor enters Clinic location data");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return randomSecondaryLocationValue;
	}


	public String enterRandomSecondaryLocationValue(boolean confirmSave) throws Exception {
		String randomSecondaryLocationValue="";
		try {
			randomSecondaryLocationValue=enterRandomSecondaryLocationValue();
			if(confirmSave) {
				clickSaveButton();
				clickPopUpOkButton();
				clicktoasterMsg();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return randomSecondaryLocationValue;
	}

	public String readEnteredSecondaryLocationValue() throws Exception {
		try {
			presenceOfElementLocated(clinicSecondaryLocationTextBox_OR);
			clickElement(addasecondarylocationLable);
			addSecondaryLocationValue=getAttribute(clinicSecondaryLocationTextBox_OR,"value");
			//extentReport.reportScreenShot("Accepted addSecondaryLocationValue after entered is "+addSecondaryLocationValue);
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return addSecondaryLocationValue;		
	}
	public void clickSaveButton() throws Exception {
		try {
			clickOnElementUsingJs(saveButton_OR); 
			//clickElement(saveButton_OR,saveButton_S);
			extentReport.reportScreenShot("User clicked Save button in  Add Secondary Location Page");
			waitForLoading(); 
			//waitForLoading(); //waitForLoading();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clicktoasterMsg() throws Exception {
		try {
			clickElement(toasterMsg_OR,toasterMsg_S);
			//waitForLoading();			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean verifyWarningMsg() throws Exception {
		boolean msgExists =false;
		try {
			waitForLoading();
			if(getSizeOfElements(warningMsg_OR,warningMsg_S)>0) {
				presenceOfElementLocated(warningMsg_OR);
				if(isDisplayed(warningMsg_OR)) {
					scrollToView(warningMsg_OR);
					if(getText(warningMsg_OR,warningMsg_S).contains(existingLocWarningMessage)) {
						msgExists =true;	
					}
				}	
			}
			else
			{
				//extentReport.reportScreenShot("System NOT displays Secondary location alert Missing message");	
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return msgExists;
	}


	public void clickPopUpOkButton() throws Exception {
		try {
			clickElement(popUpOkButton_OR,popUpOkButton_S);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void closeConfirmMsg() throws Exception {
		try {
			clickElement(toasterMsg_OR,toasterMsg_S);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	public void clickCancelButton() throws Exception {
		try {
			clickElement(cancelButton_OR,cancelButton_S);
			//waitForLoading();
			waitForPageLoad();						
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickpopUpOkButtonn() throws Exception {
		try {
			clickElement(popUpOkButton_OR,popUpOkButton_S);
			//waitForLoading();			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickPopUpCancelButton() throws Exception {
		try {			
			clickElement(popUpCancelButton_OR,popUpCancelButton_S);
			clickElement(toasterMsg_OR,toasterMsg_S);
			//waitForLoading();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean aD811DialogExists() throws Exception {
		try {	
			boolean dailogDisplayed =verifyElementWithReport(aD811Dialog_OR, aD811Dialog_S);
			return dailogDisplayed;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}


	public void goToCustomerListPage() throws Exception {
		try {
			clickElement(AllAbbottCustomerMenu_OR,AllAbbottCustomerMenu_S);
			//waitForLoading();			

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyAddSecLocPage() throws Exception {
		String verify ="";
		try {			
			if (verifyLandingPage()) {
				presenceOfElementLocatedWithoutReport(clinicSecondaryLocationTextBox_OR, "clinicSecondaryLocationTextBox_S");
				verify = "AddSecLocPageDisplayed";	
			}
			else {
				verify = "AddSecLocPage NOT Displayed";	
			}			
			extentReport.reportScreenShot(verify);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean secLocValueEmptyErrorMsg() throws Exception {
		try {
			if (verifyLandingPage()) {
				presenceOfElementLocated(saveButton_OR);
				clickElement(saveButton_OR,saveButton_S);
				extentReport.reportPass( "User clicked Save button in  Add Secondary Location Page");
				//waitForLoading();
				clinicSecLocEmptyMsg =visibilityOfElementLocated(clinicSecLocaEmptyMsg_OR);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return clinicSecLocEmptyMsg;
	}

	public boolean  existingsecLocErrorMsg() throws Exception {
		boolean existingLocWarningMsg= false;
		try {
			presenceOfElementLocated(existingLocWarning_OR);
			if(getText(existingLocWarning_OR,existingLocWarning_S).contains(existingLocWarningMessage)) {
				existingLocWarningMsg= true;	
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return existingLocWarningMsg;
	}

	public String  existingSecLocErrorMsgContent() throws Exception {
		try {
			presenceOfElementLocated(existingLocWarning_OR);
			if(getText(existingLocWarning_OR,existingLocWarning_S).contains(existingLocWarningMessage)) ;
			return existingLocWarningMessage;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	public void  closeExistingsecLocErrorMsg() throws Exception {
		presenceOfElementLocated(existingLocWarning_OR);
		if(getText(existingLocWarning_OR,existingLocWarning_S).contains(existingLocWarningMessage)) {
			clickElement(existingLocWarning_OR,existingLocWarning_S);
			extentReport.reportPass( "User clicked on existingLocWarning Message in  Add Secondary Location Page");
		}
	}
	public String addCustomerLocationPageElementvalidation(By locator, String locatorText, String Message)throws InterruptedException {
		String content = "";
		try {
			if (isElementPresent(locator)) {
				scrollToView(locator);
				if (locatorText.contains("value")) {
					content = getAttribute(locator, "value");
					if (!content.isEmpty()) {
						extentReport.reportInfo( Message + " is Displayed as " + content);
					} else {
						extentReport.reportInfo( Message + " is Displayed and blank " + content);
					}
				} else if (locatorText.contains("Checkbox")) {
					content = getAttribute(locator, "aria-checked");
					if (content.equals("false")) {
						extentReport.reportInfo( Message + " is  not Selected ");
					} else {
						extentReport.reportInfo( Message + " is  Selected ");
					}
				}

				else if (locatorText.contains("Dropdown")) {
					content = getText(locator);
					if (content != null) {
						extentReport.reportInfo( Message + " is  Displayed as " + content);
					}
				} else if (locatorText.contains("Text")) {
					content = getText(locator);
					extentReport.reportInfo( Message + " is Displayed as " + content);
				}
			} else {
				content = null;
				extentReport.reportInfo( Message + " is  Displayed as Blank ");
			}
		} catch (Exception e) {
			content = null;
			extentReport.reportInfo( Message + " is  Displayed as Blank ");
		}
		return content;

	}

	public String getDataFromAddCustomerlocationpage(String FieldName) throws Exception {
		String value = "";
		try {
			switch (FieldName) {
			case "CustomerName":
				value = addCustomerLocationPageElementvalidation(customerNameText_OR, "value", "Customer Name Textbox");
				break;
			case "CustomerType":
				value = addCustomerLocationPageElementvalidation(customerTypeText_OR, "value", "Customer Type Textbox");
				break;
			case "ClinicLocation":
				//value = addCustomerPageElementvalidation(customerLocationText, "value", "customer Location Textbox");
				break;
			case "MainPhone":
				value = addCustomerLocationPageElementvalidation(mainPhoneText_OR, "value", "Main Phone Textbox");
				break;
			case "CountryCode":
				//value = addCustomerPageElementvalidation(countryCodeText, "value", "Country Code Textbox");
				break;
			case "AreaCode":
				//value = addCustomerPageElementvalidation(areaCodeText, "value", "Area Code Textbox");
				break;
			case "Address1":
				value = addCustomerLocationPageElementvalidation(address1Text_OR, "value", "address1 Textbox");
				if(value.isEmpty()) {
					value="";
				}
				break;
			case "Address2":
				value = addCustomerLocationPageElementvalidation(address2Text_OR, "value", "address2 Textbox");
				if(value.isEmpty()) {
					value="";
				}
				break;
			case "Address3":
				value = addCustomerLocationPageElementvalidation(address3Text_OR, "value", "address3 Textbox");
				if(value.isEmpty()) {
					value="";
				}
				break;
			case "City":
				//value = addCustomerPageElementvalidation(cityText, "value", " city Textbox");
				break;
			case "ClinicLanguage":
				value = addCustomerLocationPageElementvalidation(clinicLanguageText_OR, "clinicLanguageDropdown"," clinic Language Text");

			case "Country":
				//value = addCustomerPageElementvalidation(countryText, "countryDropdwon", " country Text");
				break;
			case "Zip/PostalCode":
				//value = addCustomerPageElementvalidation(zipPostalcodeText, "value", " zipPostalcode Textbox");
				break;
			case "SecondaryPhone":
				value = addCustomerLocationPageElementvalidation(secondaryPhoneText_OR, "value", " secondary Phone Textbox");
				break;
			case "Fax":
				value = addCustomerLocationPageElementvalidation(faxText_OR, "value", " fax Textbox");
				break;
			case "ClinicTimeZone":
				value = addCustomerLocationPageElementvalidation(clinicTimeZoneText_OR, "clinicTimeZoneDropdown"," clinicTimeZone Text");
				break;
			case "TextMessage":
				//value = addCustomerPageElementvalidation(textMessageText, "value", " textMessage Textbox");
				break;
			case "LegalJurisdiction":
				value = addCustomerLocationPageElementvalidation(legalJurisdictionText_OR, "legalJurisdictionDropdown"," legal Jurisdiction Text");
				break;
			case "Email":
				value = addCustomerLocationPageElementvalidation(emailText_OR, "value", " email Textbox");
				break;

			}
			if(value.equalsIgnoreCase("null")) {
				value="";	
				
			}
			Objects.toString(value, "");
			System.out.println("Objects.toString is   "+Objects.toString(value, ""));
			String.valueOf(value);
			System.out.println("String.valueOf(value) is   "+String.valueOf(value));
			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public Boolean verifyDataInAddCustomerlocationpage(String FieldName) throws Exception {
		Boolean prepop = false;
		String value = "";
		try {
			switch (FieldName) {
			case "CustomerName"://Mandate
				value = addCustomerLocationPageElementvalidation(customerNameText_OR,"value", "Customer Name Textbox");
				if(!value.isEmpty()) {
					prepop = true;
				}
				break;
			case "CustomerType"://Mandate
				value = addCustomerLocationPageElementvalidation(customerTypeText_OR, "value", "Customer Type Textbox");
				if(!value.isEmpty()) {
					prepop = true;
				}
				break;
			case "Country"://Mandate
				value = addCustomerLocationPageElementvalidation(countryText_OR, "countryDropdown", " country Text");
				if(!value.isEmpty()) {
					prepop = true;
				}
			case "MainPhone"://Mandate
				value = addCustomerLocationPageElementvalidation(mainPhoneText_OR, "value", "Main Phone Textbox");
				if(!value.isEmpty()) {
					prepop = true;
				}
				break;
			case "SecondaryPhone"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(secondaryPhoneText_OR, "value", " secondary Phone Textbox");
				break;
			case "Address1"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(address1Text_OR, "value", "address Textbox");

				break;
			case "Address2"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(address2Text_OR, "value", "address Textbox");
				break;
			case "Address3"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(address3Text_OR, "value", "address Textbox");
				break;

			case "City"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(cityText_OR, "value", " city Textbox");
				break;

			case "Zip/PostalCode"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(zipPostalcodeText_OR, "value", " zipPostalcode Textbox");
				break;

			case "Fax"://NON-Mandate
				value = addCustomerLocationPageElementvalidation(faxText_OR, "value", " fax Textbox");
				break;

			case "Email"://Mandate
				value = addCustomerLocationPageElementvalidation(emailText_OR, "value", " email Textbox");
				if(!value.isEmpty())
				{ 
					prepop = true;
				}
				break;
			case "ClinicTimeZone"://Mandate
				value = addCustomerLocationPageElementvalidation(clinicTimeZoneText_OR, "value"," clinicTimeZone Text");
				if(!value.isEmpty())
				{ 
					prepop = true;
				}
				break;	
			case "TextMessage"://NON-Mandate
				//value = addCustomerPageElementvalidation(textMessageText, "value", " textMessage Textbox");
				break;
			case "ClinicLanguage"://Mandate
				value = addCustomerLocationPageElementvalidation(clinicLanguageText_OR, "clinicLanguageDropdown"," clinic Language Text");
				if(!value.isEmpty())
				{ 
					prepop = true;
				}
				break;
			case "LegalJurisdiction"://Mandate
				value = addCustomerLocationPageElementvalidation(legalJurisdictionText_OR, "value"," legal Jurisdiction Text");
				if(!value.isEmpty())
				{ 
					prepop = true;
				}
				break;
			}
			return prepop;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public boolean verifyLandingPage() throws InterruptedException {
		Boolean pageLoaded = null;
		if(visibilityOfElementLocated(addasecondarylocationPageTitle_OR)) {
			//extentReport.reportPass( "Add a Secondary Location page is displayed ");
			waitForLoading();
			pageLoaded=true;
			waitForLoading();
		}else {
			//extentReport.reportFail( "Add a Secondary Location is NOT displayed ");
			pageLoaded=false;
		}		
		return pageLoaded;
	}
}
