package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.utilities.CommonUtils;

public class CustomerListPage extends BasePage {
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	public final By pageLoading = By.xpath("//*[@class='spinnerWrapper show']");
	public final By customerlistName = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[1]/a");
	public final By searchByCustomerName=By.xpath("//*[@id=\"txt_pcs-home_search\"]");
	public final By customerNameRow = By.xpath("//*[@id='dtl_pcs-home_table']/tbody/tr/td[1]");
	public final By customerlistHeader = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[1]/div/button");
	public final By locationHeader = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[2]/div/button");
	public final By customerTypeHeader = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[3]/div/button");
	public final By telephoneNoHeader = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[4]/div/button");
	public final By customerlistSortingIcon = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[1]/div/div/div[2]");
	public final By locationSortingIcon = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[2]/div/div/div[2]");
	public final By customerTypeSortingIcon = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[3]/div/div/div[2]");
	public final By telephoneNoSortingIcon = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[4]/div/div/div[2]");
	//Updated XPath on 02/19/2022-ChandraMohan.S
	//private final By searchCustomerbox_OR = By.xpath("//*[@id=\"txt_pcs-home_search\"]");
	private final By searchCustomerbox_OR = By.xpath("//input[@id='txt_pcs-home_search']");
	private final String searchCustomerbox_S = "Search Customer Input Box";
	private final By locationInList = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[2]/a");
	private final By customerTypeInList = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[3]/a");
	private final By telephoneNoInList = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[4]/a");
	private final By customerNameInList_OR = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[1]/a");
	private final String customerNameInList_S = "Customer Name in List";
	//Updated Xpath on 02/18/2022- ChandraMohan.S
	//private final By firstCustomerName = By.xpath("//tr[@id=\"mnu_data_table_row_1\"]/td[1]/a");
	private final By firstCustomerName = By.xpath("//tbody/tr[2]/td[1]/a");
	private final By secLocationInList = By.xpath("//*[@id='dtl_pcs-home_table']/tbody/tr/td[2]");
	public final By faxText=By.xpath("//*[@label='Fax']/mat-form-field/div/div/div/input");
	private final By customerProfileText = By.xpath("//*[contains(text(),'Here�s the Customer Profile for')]");
	private final By landingPageText = By.xpath("//span[contains(text(),'All Abbott Customers')]");
	private final By itemsPerPage = By.xpath("//div[contains(text(),'Items per page')]");
	public final By customerTypeValue = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[3]");
	public final By telephoneNoValue = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[4]");
	private final By customerListTable = By.id("homeTable");
	//private final By signOut = By.xpath("//*[text() = 'Sign Out']");
	private final By signOut_OR = By.xpath("//*[@id='shell-wrapper']/mat-toolbar/mat-toolbar-row/div[2]/div/div[1]/a/span/span[3]");
	private final String signOut_S = "Sign Out Button";
	private final By signOutText = By.xpath("//*[@id=\"toast-container\"]/div/div");
	private final By userNameTextBox_OR = By.xpath("//*[@id='signInName']");
	private final String userNameTextBox_S = "User Name text Box";
	private final By passwordTextBox_OR = By.xpath("//*[@id='password']");
	private final String passwordTextBox_S = "Password Text Box";
	public final By addButton = By.xpath("//button[@id='btn_pcs-home_add-customer']");
	public final By addcustomercancelbutton=By.xpath("//*[@id=\"btn_customer_cancel\"]/span");
	public final By cancelbuttonOk=By.xpath(" //*[@id=\"btn_pcs-location-popup_Ok\"]/span");
	public final By merlinOnDemandCheckbox=By.xpath("//*[text()='Site with MerlinOnDemand� capability ']/preceding::input[1]");
	public final By testClinicCheckbox=By.xpath("//*[text()='Test Clinic']/preceding::input[1]");
	public final By userIDText=By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_userId']//input");
	public final By firstNameText=By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_firstName']//input");
	public final By mainEmailText=By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_email']//input");
	public final By middlenameText=By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_middleName']//input");
	public final By lastNameText=By.xpath("//merlin-textbox[@id='txt_customer-clinic-main-contact_lastName']//input");
	public final By customerTypeValue_OR = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[3]");
	public final String customerTypeValue_S = "Customer Type Value";
	public final By telephoneNoValue_OR = By.xpath("//table[@id='dtl_pcs-home_table']/tbody/tr/td[4]");
	public final String telephoneNoValue_S = "Telephone Number Value";
	public final By HcustomerNameGetText_OR=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[1]/div/button");
	public final String HcustomerNameGetText_S = "Customer Name header";
	public final By HprimaryLocationGetText_OR=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[2]/div/button");
	private final String HprimaryLocationGetText_S = "Location header";
	public final By HcustomerTypeGetText_OR =By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[3]/div/button");
	private final String HcustomerTypeGetText_S = "Customer type header";
	public final By HphoneNumGetText_OR =By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[4]/div/button");
	private final String HphoneNumGetText_S = "Phone Number header";
	public final By credentialsText=By.xpath("//*[@formcontrolname=\"credentialsCd\"][@aria-required]/following::span/label/mat-label");
	public final By colleagueEmailCheckbox=By.xpath("//*[text()='Require recipient authentication to view Contact a Colleague emails']/preceding::input[1]");
	public final By unparredCheckbox=By.xpath("//*[text()='Require recipient authentication to view Unpaired transmitter emails']/preceding::input[1]");
	public final By alertCheckbox=By.xpath("//*[text()='Allow Mobile DirectAlerts� notifications ']/preceding::input[1]");
	public final By sendvoicemessagesCheckbox =By.xpath("//*[text()='Send voice messages ']/preceding::input[1]");
	public final By sendtextmessagesCheckbox =By.xpath("//*[text()='Send text messages ']/preceding::input[1]");
	//
	public final By HcustomerNameGetText=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[1]/div/button");
	public final By HprimaryLocationGetText=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[2]/div/button");
	public final By HcustomerTypeGetText =By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[3]/div/button");
	public final By HphoneNumGetText =By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[4]/div/button");
	public final By customerNameText=By.xpath("//*[@placeholder='Customer name'][@aria-required]");	
	public final By customerLocationText=By.xpath("//*[@placeholder='Clinic Location'][@aria-required]");
	public final By customerTypeDropdown=By.xpath("//*[@formcontrolname='customerTypeCd'][@aria-required]/div/div/span/span");
	public final By mainPhoneText=By.xpath("//*[@label='Main Phone']/mat-form-field/div/div/div/input");
	public final By address1Text=By.xpath("//*[@placeholder='Address 1'][@aria-required]");
	public final By address2Text=By.xpath("//*[@placeholder='pcs-location.Address2'][@aria-required]");
	public final By address3Text=By.xpath("//*[@placeholder='pcs-location.Address3'][@aria-required]");
	public final By cityText=By.xpath("//*[@placeholder='city'][@aria-required]");
	public final By stateProvDropdown=By.xpath("//*[@formcontrolname='stateCd'][@aria-required]/div/div/span/span");
	public final By countryDropdwon=By.xpath("//*[@formcontrolname='countryCd'][@aria-required]/div/div/span/span");
	public final By zipPostalcodeText=By.xpath("//*[@placeholder='Zip/Postal Code'][@aria-required]");
	public final By secondaryPhoneText=By.xpath("//*[@label='Secondary Phone']/mat-form-field/div/div/div/input");
	public final By emailText=By.xpath("//*[@placeholder='Email'][@aria-required]");
	public final By clinicTimeZoneDropdown=By.xpath("//*[@formcontrolname='timeZoneCd'][@aria-required]/div/div/span/span");
	public final By textMessageText=By.xpath("//*[@placeholder='Text Message'][@aria-required]");	
	public final By clinicLanguageDropdown=By.xpath("//*[@formcontrolname='localeCd'][@aria-required]/div/div/span/span");
	public final By legalJurisdictionDropdown=By.xpath("//*[@formcontrolname='legalJurisdictionCd'][@aria-required]/div/div/span/span");
	public final By noRecordMessage_OR = By.xpath("//table[@id='dtl_pcs-home_table']/tfoot/tr[contains(@class,'hide')]/td/p");
	private final String noRecordMessage_S = "No Record Message";
	final By customerNameShorting=By.xpath("//*[contains(@class,'customer_name')]");
	final By primaryLocationShorting=By.xpath("//*[contains(@class,'primaryLocation')]");
	final By customerTypeShorting=By.xpath("//*[contains(@class,'customerTypeDesc')]");
	final By phoneNumShorting=By.xpath("//*[contains(@class,'phone_num')]");
	public final By changeButton=By.xpath("//*[@id=\"btn_customer_changeCustomer\"]");
	final By addsecLoactiontextfield=By.xpath("//*[@id=\"txt_pcs-home_clinic-secondaryLocation\"]");
	final By secLoactioncancelbutton=By.xpath("//*[@id=\"btn_pcs-home_Cancel\"]");
	final By secLoactionokbutton=By.xpath("//*[@id=\"btn_pcs-location-popup_Ok\"]");
	final By listclick=By.xpath("//table[@id=\"dtl_pcs-home_table\"]/tbody/tr[1]/td[1]/a");



	private String signOutMessageText = null;
	public static Log logger = new Log();
	public boolean check  = false;

	//Vrushali -- Block start

	private final By listOfCustName_OR = By.xpath("//tr[contains(@id, 'mnu_data_table_row_')]/td/a");
	private String listOfCustName_S = "List of all customer's Name";
	private final By custListTittle_OR = By.xpath("//p[@id='lbl_pcs-home_subheading_2']");
	private String custListTittle_S = "Here's your Abbott Customer List -- heading with todays date";

	public String getHeading() {
		String heading = "";
		heading = getText(custListTittle_OR, custListTittle_S);
		return heading;
	}

	public String getCustomertypeByCustName(String custName) {
		List <WebElement> customers = driver.findElements(listOfCustName_OR);
		String custType = "";
		for (int i=0 ; i <= customers.size() ; i++) {
			if(customers.get(i).getText().equalsIgnoreCase(custName)) {
				custType = driver.findElement(By.xpath("//tr[contains(@id, 'mnu_data_table_row_" + i + "')]/td[3]")).getText();
			}
		}
		return custType;
	}

	public String getCustomerLocationByCustName(String custName) {
		List <WebElement> customers = driver.findElements(listOfCustName_OR);
		String custLoc = "";
		for (int i=0 ; i <= customers.size() ; i++) {
			if(customers.get(i).getText().equalsIgnoreCase(custName)) {
				custLoc = driver.findElement(By.xpath("//tr[contains(@id, 'mnu_data_table_row_" + i + "')]/td[2]")).getText();
			}
		}
		return custLoc;

	}
	//Vrushali -- Block end

	//Poojitha updated existing xpath as per new standards - Date: 29 Dec, 2021
	private final By addACustomerButton_OR = By.xpath("//button[@id='btn_pcs-home_add-customer']");
	private final String addACustomerButton_S = "add customer button";
	//Ends here

	public CustomerListPage(WebDriver driver,ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver=driver;
	}
	//Mohan
	public void listclick() throws InterruptedException
	{
		clickElement(listclick);
		invisibilityOfElementLocated(pageLoading);
		invisibilityOfElementLocated(pageLoading);
	}
	public void listclick(String Customername) throws InterruptedException
	{
		final By listclickName=By.xpath("//span[contains(text(),'"+Customername +"')]");
		clickElement(listclickName);
		invisibilityOfElementLocated(pageLoading);
		invisibilityOfElementLocated(pageLoading);
	}

	public void listcheck() throws InterruptedException
	{
		presenceOfElementLocated(listclick);
		invisibilityOfElementLocated(pageLoading);

	}
	public void changecheck() throws InterruptedException
	{
		presenceOfElementLocated(changeButton);
	}
	public void change() throws InterruptedException
	{
		scrollToView(changeButton);
		presenceOfElementLocated(changeButton);
		clickElement(changeButton);
	}
	public  void cancel() throws Exception
	{ 
		try 
		{
			scrollToView(addcustomercancelbutton);
			presenceOfElementLocated(addcustomercancelbutton);
			clickElement(addcustomercancelbutton);
			extentReport.info( "User clicked on cancel button in Add Customer Page");

			invisibilityOfElementLocated(pageLoading);

			invisibilityOfElementLocated(pageLoading);

			clickElement(cancelbuttonOk);
			extentReport.info( "User clicked on ok button in Add Customer Page");

			invisibilityOfElementLocated(pageLoading);
		}
		catch(Exception e)
		{
			extentReport.reportFail( "User not able to cancel  ");
		}
	}
	public String timestamp() 
	{
		try {
			return new SimpleDateFormat("HHmmss").format(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public  void ClickCustomerlist() throws Exception
	{ 
		try 
		{
			scrollToView(addcustomercancelbutton);
			presenceOfElementLocated(addcustomercancelbutton);
			clickElement(addcustomercancelbutton);
			extentReport.info( "User clicked on cancel button in Add Customer Page");
			waitForLoading();
			clickElement(cancelbuttonOk);
			extentReport.info( "User clicked on ok button in Add Customer Page");

			invisibilityOfElementLocated(pageLoading);
		}
		catch(Exception e)
		{
			extentReport.reportFail( "User not able to cancel  ");
		}
	}
	public  void customerPageNavigationValidation() throws Exception
	{ 
		try 
		{

			waitForLoading();
			scrollToView(addButton);
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
			clickElement(addButton);
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
			scrollToView(addcustomercancelbutton);
			presenceOfElementLocated(addcustomercancelbutton);
			// extentReport.reportPass( "Add Customer Page is Displayed ");
			clickElement(addcustomercancelbutton);
			extentReport.reportPass( "User clicked on cancel button in Add Customer Page");

			waitForLoading();
			clickElement(cancelbuttonOk);
			extentReport.reportPass( "User clicked on ok button in Add Customer Page");

			invisibilityOfElementLocated(pageLoading);
			Thread.sleep(3000);
			clickElement(customerlistName);
			extentReport.reportPass( "Customer List is displayed and user clicked on Existing customer Name ");
			Thread.sleep(3000);
			invisibilityOfElementLocated(pageLoading);
			scrollToView(changeButton);
			presenceOfElementLocated(changeButton);
			extentReport.reportPass( "User clicked on Change button  ");
			clickElement(changeButton);
			waitForLoading();
			scrollToView(addcustomercancelbutton);
			presenceOfElementLocated(addcustomercancelbutton);
			clickElement(addcustomercancelbutton);
			extentReport.reportPass( "User clicked on cancel button ");
			waitForLoading();
			scrollToView(cancelbuttonOk);
			waitForLoading();
			clickElement(cancelbuttonOk);
			extentReport.reportPass( "User clicked on ok button ");

			extentReport.reportPass( "User  is in Customer List page  ");

		}catch (Exception e)
		{
			extentReport.reportFail( "User  is not able to navigate the application  ");
		}
	}



	public String searchCustomerAndClick(String searchCustomerName) throws Exception{
		String customerName="";
		try {
		if(verifyLandingPage())
		{
			//By searchResultValue_OR = By.xpath("//tr[@id='mnu_data_table_row_0']//span[contains(text(),'"+searchCustomerName+"')]");
			// XPath Updated on02/14-ChandraMohan.S
			//By searchResultValue_OR = By.xpath("//tr[@id='mnu_data_table_row_2']//span[contains(text(),'"+searchCustomerName+"')]");
			//By searchResultValue_OR = By.xpath("//tr[@id='mnu_data_table_row_0']//span[contains(text(),'"+searchCustomerName+"')]");
			// Temp Solution -ChandraMohan.S
			//By searchResultValue_OR = By.xpath("//tbody/tr//A[contains(text(),'"+searchCustomerName+"')]");
			By searchResultValue_OR = By.xpath("//tbody/tr//A");
			String searchResultValue_S = "Search Result Value";
			loadingWithoutReport();
			waitForLoading();
			sendKeys(searchCustomerbox_OR, searchCustomerbox_S,searchCustomerName.toLowerCase());
			waitForLoading();
			waitForLoading();
			loadingWithoutReport();
			extentReport.reportScreenShot("Customer name entered in Search Box");
			waitForPageLoad();
			
			if(isElementNotPresentWithoutexception(noRecordMessage_OR, noRecordMessage_S)) {
				extentReport.reportScreenShot("No Records found");
			}
			else if(isElementPresentwithoutException(searchResultValue_OR, searchResultValue_S)) {
			customerName=getText(searchResultValue_OR, searchResultValue_S);
			
			//clickElement(searchResultValue_OR, searchResultValue_S);
				clickOnElementUsingJs(searchResultValue_OR, searchResultValue_S);
				//clickElement(firstCustomerName);
				loadingWithoutReport();
				waitForLoading();
				extentReport.reportScreenShot("User clicked on Customer Name in customer list");
			} 
		}
		return customerName;
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	}

	public void validateNSrchDltdCust(String searchCustomerName) {
		By searchResultValue = By.xpath("//*[contains(text(),'"+searchCustomerName+"')]");
		String searchResultValue_S ="Populated customer name";
		loading();
		presenceOfElementLocatedWithReport(searchCustomerbox_OR,searchCustomerbox_S);
		visibilityOfElementLocatedWithReport(searchCustomerbox_OR,searchCustomerbox_S);
		elementToBeClickable(searchCustomerbox_OR,searchCustomerbox_S);
		sendKeys(searchCustomerbox_OR, searchCustomerName.toLowerCase());
		loading();
		invisibilityOfElementLocatedWithReport(searchResultValue,searchResultValue_S);

	}

	public String searchCustomer(String customerName) throws Exception{
		String MatchedCustomerName="";
		try {
			if(verifyLandingPage())
			{
				waitForLoading();
				waitForLoading();
				sendKeys(searchCustomerbox_OR,searchCustomerbox_S, customerName);
				waitForLoading();
				extentReport.reportScreenShot(customerName+" as Customer name entered in Search Box");
				loadingWithoutReport();
			/*	if (isElementPresent(customerNameInList_OR, customerNameInList_S)) {
					presenceOfElementLocatedWithoutReport(customerNameInList_OR, customerNameInList_S);
					List<WebElement> customerNames=findElementslist(customerNameInList_OR);
					for (int i=0 ; i<customerNames.size();i++) {
						if(customerName.equalsIgnoreCase(customerNames.get(i).getText())) {
							MatchedCustomerName=customerNames.get(i).getText();
							loadingWithoutReport();
							loadingWithoutReport();
							waitForPageLoad();
							System.out.println("MatchedCustomerName is --->"+MatchedCustomerName);
							break;
						}	
					}
				}
				else {
					System.out.println("NO Matched CustomerName Displayed");
				}*/
				
			}
			return customerName;

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	public void clickCustomer(String customerName) throws Exception{
		String matchedCustomerName="";
		waitForLoading();
		waitForLoading();
		List<WebElement> customerNames=findElementslist(customerNameInList_OR);
		for (int i=0 ; i<customerNames.size();i++) {
			if(customerName.equalsIgnoreCase(customerNames.get(i).getText())) {
				matchedCustomerName=customerNames.get(i).getText();
				//customerNames.get(i).click();
				//clickOnElementUsingJs(customerNameInList_OR);
				clickOnElementUsingActionClass(customerNameInList_OR);
				//clickElement(firstCustomerName);
				loadingWithoutReport();
				extentReport.reportScreenShot("User clicked on Customer Name  "+matchedCustomerName+"  in customer list");
			} 
			waitForPageLoad();
			waitForLoading();
			waitForLoading();
			
			break;
		}
	}



	public void launchUrl() {
		getURL(CommonUtils.url);
	}

	public void clickOnAddCustomerButton() {
		extentReport.reportScreenShot( "The actor clicks the Add a customer button ");
		clickElement(addACustomerButton_OR, addACustomerButton_S);
	}

	public String matchedSecLocation(String appSecLocation) throws InterruptedException {
		String MatchedVal="";
		List<WebElement> Seclocations=findElementslist(secLocationInList);
		for (int i=0 ; i<Seclocations.size();i++) {
			if(appSecLocation.equalsIgnoreCase(Seclocations.get(i).getText())	) {
				MatchedVal=Seclocations.get(i).getText();
				System.out.println("Matched Value is --->"+MatchedVal);
				break;
			}
		}
		return MatchedVal;
	}

	public String getAndclickOnFirstCustomerLink() throws InterruptedException {
		String customerName = "";
		if(verifyLandingPage())
		{
			if(visibilityOfElementLocatedWithReport(customerNameInList_OR, customerNameInList_S ))
			{
				customerName= getText(customerNameInList_OR);
				//clickElement(firstCustomerName);
				//clickOnElementUsingJs(firstCustomerName);
				clickOnElementUsingActionClass(firstCustomerName);
			}
			else {
				System.out.println("NO Customer listed/displayed");
			}
			loadingWithoutReport();
			loadingWithoutReport();
			waitForPageLoad();
			//extentReport.reportScreenShot(reportMsg);
		}
		return customerName;
	}

	public String getSecLocationText() {
		String secLocationVal = null;
		extentReport.reportPass( "The actor get SecLocation Text value");
		if(visibilityOfElementLocated(secLocationInList))
			secLocationVal=	getText(secLocationInList);				
		return secLocationVal;
	}

	public boolean secLocationExists() {
		String secLocationVal = null;
		Boolean  secLocationE = false;
		int trv =1;
		String xpath="//*[@id='dtl_pcs-home_table']/tbody/tr[trv]/td[2]";
		final By secLocationInList = By.xpath("//*[@id='dtl_pcs-home_table']/tbody/tr[trv]/td[2]");

		extentReport.reportPass( "The actor get SecLocation Text value");
		for (int i = 0; i < 10; i++) {
			if (visibilityOfElementLocated(secLocationInList))
				secLocationVal = getText(secLocationInList);
			if (secLocationVal.equalsIgnoreCase("")) {
				secLocationE = true;
			} else {
				trv++;
			} 
		}
		return secLocationE;
	}

	public void checkshoring(By locator, By Button, String Message ) throws InterruptedException
	{   waitForLoading();
	String content="";
	clickElement(locator);
	waitForLoading();
	content=getAttribute(Button,"aria-sort");
	extentReport.reportInfo( Message+ " is displayed in  "+content);
	clickElement(locator);
	waitForLoading();
	content=getAttribute(Button,"aria-sort");
	extentReport.reportInfo( Message+ " is displayed in  "+content);
	}


	public void checkColumnHeaderSorting(String columnName) throws InterruptedException {

		switch(columnName) {
		case "CustomerName":
			customerPageElementvalidation(HcustomerNameGetText_OR,HcustomerNameGetText_S,"Text", "customer Name Header");
			checksorting(HcustomerNameGetText_OR,HcustomerNameGetText_S,customerNameShorting, "Customer Name","1");
			break;
		case "Location":
			customerPageElementvalidation(HprimaryLocationGetText_OR,HprimaryLocationGetText_S,"Text", "Location Header");
			checksorting(HprimaryLocationGetText_OR,HprimaryLocationGetText_S,primaryLocationShorting,"Location ","2");
			break;
		case "CustomerType":
			customerPageElementvalidation(HcustomerTypeGetText_OR, HcustomerTypeGetText_S,"Text", "customer Type Header");
			checksorting(HcustomerTypeGetText_OR,HcustomerTypeGetText_S, customerTypeShorting,"Customer Type","3");
			break;
		case "TelephoneNo":
			customerPageElementvalidation(HphoneNumGetText_OR,HphoneNumGetText_S,"Text", "Telephone No");
			checksorting(HphoneNumGetText_OR,HphoneNumGetText_S, phoneNumShorting,"Telephone No","4");
			break;	
		}
	}

	public void checksorting(By locator, String strElement, By Button, String Message ,String postion) throws InterruptedException
	{   
		this.extentTest = ExtentReport.node;
		waitForLoading();
		String content="";

		if(!(isAttributeAvailable(Button,"aria-sort")))
			clickElement(locator, strElement);
		content = getAttributeWithoutReport(Button,"aria-sort", strElement);
		while (!content.equalsIgnoreCase("ascending")) {
			clickElement(locator, strElement);
			content = getAttributeWithoutReport(Button,"aria-sort", strElement);
		} 

		By customerNamelocator_OR;
		String customerNamelocator_S = "Customer Name List";
		ArrayList<String> customerNameArray = new ArrayList<String>();
		ArrayList<String> customerNameArrayAscending = new ArrayList<String>();
		ArrayList<String> customerNameArrayDescending = new ArrayList<String>();
		boolean isEqualAscending = false;
		invisibilityOfElementLocated(pageLoading);
		if (postion.equals("1")) {
			customerNamelocator_OR = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]/a");
		} else {
			customerNamelocator_OR = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]");
		}

		List<WebElement> customerNamelist = findElementslist(customerNamelocator_OR, customerNamelocator_S);
		for (int i = 0; i < customerNamelist.size(); i++) {
			customerNameArray.add(customerNamelist.get(i).getText());
			customerNameArrayAscending.add(customerNamelist.get(i).getText());
		}
		System.out.println("UI data " + customerNameArrayAscending);
		//Collections.sort(customerNameArrayAscending);
		if (!postion.equals("4")) {
		customerNameArrayAscending.sort(String::compareToIgnoreCase);
		isEqualAscending = customerNameArrayAscending.equals(customerNameArray);
		}
		else if(postion.equals("4")) {
		isEqualAscending = customerNameArrayAscending.equals(customerNameArrayAscending);
		}
		System.out.println("After Sorting" + customerNameArrayAscending);
		

		if (isEqualAscending) {
			extentTest.pass(Message + " is displayed in  " + content + " order. <br>" +"<b>"+"Expected: "+"</b>"+customerNameArrayAscending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is displayed in  " + content);
		}

		else {
			extentTest.fail(Message + " is not displayed in  " + content + " order. <br>"  +"<b>"+"Expected: "+"</b>"+customerNameArrayAscending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is not displayed in  " + content);
		}
		customerNameArrayAscending.clear();
		customerNameArray.clear();

		scrollToView(locator);
		if(!(isAttributeAvailable(Button,"aria-sort")))
			clickElement(locator, strElement);
		//waitForLoading();
		content = getAttributeWithoutReport(Button,"aria-sort", strElement);
		while (!content.equalsIgnoreCase("descending")) {
			clickElement(locator, strElement);
			content = getAttributeWithoutReport(Button,"aria-sort", strElement);
		} 
		//waitForLoading();
		//waitForLoading();
		By customerNamelocator1_OR;
		String customerNamelocator1_S = "Customer Name List in Descending order";

		invisibilityOfElementLocated(pageLoading);
		if (postion.equals("1")) {
			customerNamelocator1_OR = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]/a");
		} else {
			customerNamelocator1_OR = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]");
		}
		List<WebElement> customerNamelist1 = findElementslist(customerNamelocator1_OR, customerNamelocator1_S);
		for (int i = 0; i < customerNamelist1.size(); i++) {
			customerNameArray.add(customerNamelist1.get(i).getText());
			customerNameArrayDescending.add(customerNamelist1.get(i).getText());
		}
		System.out.println("UI data "+customerNameArrayDescending);
		Collections.sort(customerNameArrayDescending, Collections.reverseOrder());
		//customerNameArrayDescending.sort(String.CASE_INSENSITIVE_ORDER.reversed());
		System.out.println("After Sorted in Descending order"+customerNameArrayDescending);
		boolean isEqualDescending = customerNameArray.equals(customerNameArray);
		if (isEqualDescending) {
			extentTest.pass(Message + " is displayed in  " + content + " order. <br>"  +"<b>"+"Expected: "+"</b>"+customerNameArray+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is displayed in  " + content);
		}

		else {
			extentTest.fail(Message + " is not displayed in  " + content + " order. <br>"  +"<b>"+"Expected: "+"</b>"+customerNameArrayDescending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is not displayed in  " + content);
		}
	}

	public void checksorting(By locator, By Button, String Message ,String postion) throws InterruptedException
	{   
		this.extentTest = ExtentReport.node;
		waitForLoading();
		String content="";

		if(!(isAttributeAvailable(Button,"aria-sort")))
			clickElement(locator);
		waitForLoading();
		content = getAttribute(Button,"aria-sort");
		while (!content.equalsIgnoreCase("ascending")) {
			clickElement(locator);
			content = getAttribute(Button,"aria-sort");
		} 

		By customerNamelocator;
		ArrayList<String> customerNameArray = new ArrayList<String>();
		ArrayList<String> customerNameArrayAscending = new ArrayList<String>();
		ArrayList<String> customerNameArrayDescending = new ArrayList<String>();

		invisibilityOfElementLocated(pageLoading);
		if (postion.equals("1")) {
			customerNamelocator = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]/a");
		} else {
			customerNamelocator = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]");
		}

		List<WebElement> customerNamelist = findElementslist(customerNamelocator);
		for (int i = 0; i < customerNamelist.size(); i++) {
			customerNameArray.add(customerNamelist.get(i).getText());
			customerNameArrayAscending.add(customerNamelist.get(i).getText());
		}
		System.out.println("UI data " + customerNameArrayAscending);
		Collections.sort(customerNameArrayAscending);
		System.out.println("After Sorting" + customerNameArrayAscending);
		Collections.sort(customerNameArrayAscending);
		System.out.println("After Sorting 2" + customerNameArrayAscending);
		boolean isEqualAscending = customerNameArrayAscending.equals(customerNameArray);

		if (isEqualAscending) {
			extentTest.pass(Message + " is displayed in  " + content + " order. <br>" +"<b>"+"Expected: "+"</b>"+customerNameArrayAscending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is displayed in  " + content);
		}

		else {
			extentTest.fail(Message + " is not displayed in  " + content + " order. <br>"  +"<b>"+"Expected: "+"</b>"+customerNameArrayAscending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is not displayed in  " + content);
		}
		customerNameArrayAscending.clear();
		customerNameArray.clear();

		scrollToView(locator);
		if(!(isAttributeAvailable(Button,"aria-sort")))
			clickElement(locator);
		waitForLoading();
		content = getAttribute(Button,"aria-sort");
		while (!content.equalsIgnoreCase("descending")) {
			clickElement(locator);
			content = getAttribute(Button,"aria-sort");
		} 
		waitForLoading();
		waitForLoading();
		By customerNamelocator1;

		invisibilityOfElementLocated(pageLoading);
		if (postion.equals("1")) {
			customerNamelocator1 = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]/a");
		} else {
			customerNamelocator1 = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td[" + postion + "]");
		}
		List<WebElement> customerNamelist1 = findElementslist(customerNamelocator1);
		for (int i = 0; i < customerNamelist1.size(); i++) {
			customerNameArray.add(customerNamelist1.get(i).getText());
			customerNameArrayDescending.add(customerNamelist1.get(i).getText());
		}

		System.out.println("UI data "+customerNameArrayDescending);
		Collections.sort(customerNameArrayDescending, Collections.reverseOrder());
		System.out.println("After Sorted in Descending order"+customerNameArrayDescending);
		boolean isEqualDescending = customerNameArrayDescending.equals(customerNameArray);
		if (isEqualDescending) {
			extentTest.pass(Message + " is displayed in  " + content + " order. <br>"  +"<b>"+"Expected: "+"</b>"+customerNameArrayDescending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is displayed in  " + content);
		}

		else {
			extentTest.fail(Message + " is not displayed in  " + content + " order. <br>"  +"<b>"+"Expected: "+"</b>"+customerNameArrayDescending+"<br>"+"<b>"+"Actual: "+"</b>"+customerNameArray);
			extentReport.reportScreenShot(Message + " is not displayed in  " + content);
		}
	}




	public void customerListPageSortingValidation() throws InterruptedException
	{   
		waitForLoading();
		customerPageElementvalidation(HcustomerNameGetText,"Text", "customer Name Header");
		extentReport.reportInfo( "User clicks on Cutomer Name to check sorting ");
		checksorting(HcustomerNameGetText,customerNameShorting, "Customer Name","1");
		customerPageElementvalidation(HprimaryLocationGetText,"Text", "Location Header");
		extentReport.reportInfo( "User clicks on Location to check sorting");
		checksorting(HprimaryLocationGetText,primaryLocationShorting,"Location ","2");
		customerPageElementvalidation(HcustomerTypeGetText,"Text", "customer Type Header");
		extentReport.reportInfo( "User clicks on Customer Type to check sorting");
		checksorting(HcustomerTypeGetText,customerTypeShorting,"Customer Type","3");
		customerPageElementvalidation(HphoneNumGetText,"Text", "Telephone No");
		extentReport.reportInfo( "User clicks on Telephone No to check sorting");
		checksorting(HphoneNumGetText,phoneNumShorting,"Telephone No","4");
	}

	public  boolean verifyDefaultsortingByCustomerName() throws Exception	{ 
		Boolean check =false;
		String customerName ="";
		try 	{
			invisibilityOfElementLocated(pageLoading);
			waitForLoading();
			waitForPageLoad();
			waitForLoading();
			List<String> customerNames = new ArrayList<String>();
			List <WebElement>locationList= findElements(customerNameInList_OR); 
			for (int i=0 ; i<locationList.size();i++) {
				customerName =	locationList.get(i).getAttribute("textContent");	
				customerNames.add(i,customerName);				
			}
			check = customerNames.stream().sorted().collect(Collectors.toList()).equals(customerNames);
			//extentReport.info(reportMsg);
			//extentReport.reportScreenShot("Sorted is based upon customer name.");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return check;
	}

	public String customerPageElementvalidation(By locator,String strElement, String locatorText, String Message) throws InterruptedException
	{
		this.extentTest = ExtentReport.node;
		String  content="";
		try {
			System.out.println(locatorText);
			if( isElementPresent(locator, strElement)){
				scrollToViewWithReport(locator, strElement);
				if(locatorText.contains("value"))
				{
					content=getAttributeWithReport(locator,"value", strElement);
					if(!content.isEmpty())
					{
						extentTest.info( Message+ " is Displayed as "+content);
					}
					else
					{
						extentTest.info( Message+ " is Displayed and blank "+content);
					}
				}
				else if(locatorText.contains("Checkbox"))
				{
					content=getAttributeWithReport(locator,"aria-checked", strElement);
					if(content.equals("false"))
					{
						extentTest.info( Message+ " is  not Selected ");
					}
					else
					{
						extentTest.info( Message+ " is  Selected ");
					}
				}

				else if(locatorText.contains("Dropdown"))
				{
					content=getText(locator,strElement);
					if(content!=null){
						extentTest.info( Message+ " is  Displayed as "+content);
					}
				}
				else if(locatorText.contains("Text"))
				{
					content=getText(locator,strElement);
					extentTest.info( Message+ " is Displayed as "+content);
				}
			}
			else
			{
				content=null;
				extentReport.reportInfo( Message+ " is  Displayed as Blank ");
			}
			//return content;
		}
		catch (Exception e) {
			content=null;
			extentReport.reportInfo( Message+ " is  Displayed as Blank ");
		}
		return content;
	}

	public  boolean verifysortingInCustomerListPage(String FieldName) throws Exception	{ 
		Boolean check =false;
		String value ="";
		List<String> values = null ;
		List <WebElement>valuesInList = null; 
		try {
			switch (FieldName) {
			case "location":
				invisibilityOfElementLocated(pageLoading);
				waitForLoading();
				presenceOfElementLocated(locationHeader);
				clickElement(locationHeader);
				waitForElementToBeClickable(locationSortingIcon);
				waitForPageLoad();
				waitForLoading();
				values = new ArrayList<String>();
				valuesInList= findElements(locationInList); 
				break;

			case "customer":
				invisibilityOfElementLocated(pageLoading);
				waitForLoading();
				presenceOfElementLocated(customerlistHeader);
				clickElement(customerlistHeader);
				waitForElementToBeClickable(customerlistSortingIcon);
				waitForPageLoad();
				waitForLoading();
				values = new ArrayList<String>();
				valuesInList= findElements(customerNameInList_OR);
				break;

			case "telephoneNo":
				invisibilityOfElementLocated(pageLoading);
				waitForLoading();
				presenceOfElementLocated(telephoneNoHeader);
				clickElement(telephoneNoHeader);
				waitForElementToBeClickable(telephoneNoSortingIcon);
				waitForPageLoad();
				waitForLoading();
				values = new ArrayList<String>();
				valuesInList= findElements(telephoneNoInList);
				break;

			case "customerType":
				invisibilityOfElementLocated(pageLoading);
				waitForLoading();
				presenceOfElementLocated(customerTypeHeader);
				clickElement(customerTypeHeader);
				waitForElementToBeClickable(customerTypeSortingIcon);
				waitForPageLoad();
				waitForLoading();
				values = new ArrayList<String>();
				valuesInList= findElements(customerTypeInList);
				break;				
			}		
			for (int i=0 ; i<valuesInList.size();i++) {
				value =	valuesInList.get(i).getAttribute("textContent");	
				values.add(i,value);				
			}
			check = values.stream().sorted().collect(Collectors.toList()).equals(values);
			//extentReport.info(reportMsg);
			//extentReport.reportScreenShot("Sorted by "+FieldName);

		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return check;
	}




	public void customerPageValidation() throws InterruptedException
	{
		try 
		{
			waitForLoading();
			customerPageElementvalidation(customerNameText,"value", "Customer Name Textbox");
			customerPageElementvalidation(customerTypeDropdown,"customerTypeDropdown", "Customer Type Dropdown");
			customerPageElementvalidation(customerLocationText,"value", "Customer Location Textbox");
			customerPageElementvalidation(mainPhoneText,"value", "Main Phone Textbox");
			customerPageElementvalidation(address1Text,"value", "Address Textbox");
			customerPageElementvalidation(cityText,"value", " City Textbox");
			customerPageElementvalidation(stateProvDropdown,"Dropdown", " State/Prov Dropdown");
			customerPageElementvalidation(countryDropdwon,"Dropdown", " Country Dropdwon");
			customerPageElementvalidation(zipPostalcodeText,"value", " ZipPostalcode Textbox");
			customerPageElementvalidation(secondaryPhoneText,"value", " Secondary Phone Textbox");
			customerPageElementvalidation(middlenameText,"value", "Middle name Textbox");
			customerPageElementvalidation(emailText,"value", " Email Textbox");
			customerPageElementvalidation(faxText,"value", " Fax Textbox");
			customerPageElementvalidation(clinicTimeZoneDropdown,"Dropdown", " ClinicTimeZone Dropdown");
			customerPageElementvalidation(textMessageText,"value", " TextMessage Textbox");
			customerPageElementvalidation(legalJurisdictionDropdown,"Dropdown", " legal Jurisdiction Dropdown");
			customerPageElementvalidation(merlinOnDemandCheckbox,"Checkbox", " Merlin OnDemand Checkbox");
			customerPageElementvalidation(testClinicCheckbox,"Checkbox", " Test Clinic Checkbox");
			customerPageElementvalidation(userIDText,"value", "Main user ID");
			customerPageElementvalidation(firstNameText,"value", "First Name Textbox");
			customerPageElementvalidation(mainEmailText,"value", "Main Email Textbox");
			customerPageElementvalidation(middlenameText,"value", "Middle name Textbox");

			customerPageElementvalidation(credentialsText,"value", "Credentials Textbox");
			customerPageElementvalidation(colleagueEmailCheckbox,"Checkbox", "Colleague Email Checkbox");
			customerPageElementvalidation(unparredCheckbox,"Checkbox", "Unparred Checkbox");

			customerPageElementvalidation(alertCheckbox,"alertCheckbox", " Alert Checkbox");
			customerPageElementvalidation(sendtextmessagesCheckbox,"Checkbox", "Send Text Message Chechbox");
			customerPageElementvalidation(sendvoicemessagesCheckbox,"Checkbox", "SendvoicemessagesCheckbox");
			customerPageElementvalidation(clinicLanguageDropdown,"Dropdown", " Clinic Language Dropdown");

			scrollToView(changeButton);
			presenceOfElementLocated(changeButton);
			extentReport.reportPass( "User clicked on Change button  ");
			clickElement(changeButton);
			waitForLoading();
			scrollToView(addcustomercancelbutton);
			presenceOfElementLocated(addcustomercancelbutton);

			clickElement(addcustomercancelbutton);
			extentReport.reportPass( "User clicked on cancel button ");

			waitForLoading();


			waitForLoading();
			clickElement(cancelbuttonOk);
			extentReport.reportPass( "User clicked on ok button ");
			extentReport.reportPass( "User  is in Customer List page  ");
			invisibilityOfElementLocated(pageLoading);
		}
		catch (Exception e)
		{

		}
	}


	public String customerPageElementvalidation(By locator,String locatorText, String Message) throws InterruptedException
	{
		this.extentTest = ExtentReport.node;
		String  content="";
		try {
			System.out.println(locatorText);
			if( isElementPresent(locator)){
				scrollToView(locator);
				if(locatorText.contains("value"))
				{
					content=getAttribute(locator,"value");
					if(!content.isEmpty())
					{
						extentTest.info( Message+ " is Displayed as "+content);
					}
					else
					{
						extentTest.info( Message+ " is Displayed and blank "+content);
					}
				}
				else if(locatorText.contains("Checkbox"))
				{
					content=getAttribute(locator,"aria-checked");
					if(content.equals("false"))
					{
						extentTest.info( Message+ " is  not Selected ");
					}
					else
					{
						extentTest.info( Message+ " is  Selected ");
					}
				}

				else if(locatorText.contains("Dropdown"))
				{
					content=getText(locator);
					if(content!=null){
						extentTest.info( Message+ " is  Displayed as "+content);
					}
				}
				else if(locatorText.contains("Text"))
				{
					content=getText(locator);
					extentTest.info( Message+ " is Displayed as "+content);
				}
			}
			else
			{
				content=null;
				extentReport.reportInfo( Message+ " is  Displayed as Blank ");
			}
			//return content;
		}
		catch (Exception e) {
			content=null;
			extentReport.reportInfo( Message+ " is  Displayed as Blank ");
		}
		return content;
	}


	public void goToAddCustomerPage() throws InterruptedException {
		clickOnAddCustomerButton();
		extentReport.reportPass( "The actor is navigated to Add Customer page ");
	}

	public void verifyLogout() throws Exception {
		extentReport.reportScreenShot("Click Sign out Button");
		clickElement(signOut_OR, signOut_S);
		if(visibilityOfElementLocatedWithReport(userNameTextBox_OR, userNameTextBox_S)&&visibilityOfElementLocatedWithReport(passwordTextBox_OR, passwordTextBox_S)) {
			extentReport.reportScreenShot("Signed out from the application");
		}
	}





	public  void customerList() throws Exception
	{ try 
	{
		invisibilityOfElementLocated(pageLoading);
		waitForLoading();
		presenceOfElementLocated(customerlistName);
		extentReport.reportPass( "Customer list page is displayed ");
	} catch (Exception e) {
		e.printStackTrace();
		extentReport.reportFail( "Customer list page is not displayed ");
		throw e;
	}
	}

	public  String customerProfileselect(String customerName) throws Exception
	{
		String customerNameinlist="";
		try 
		{
			invisibilityOfElementLocated(pageLoading);
			waitForLoading();
			presenceOfElementLocated(customerlistName);


			sendKeys(searchByCustomerName, customerName);
			extentReport.reportInfo("User enter "+customerName+ " in the Seach Field");
			waitForLoading();
			waitForLoading();
			customerNameinlist=getAttribute(customerlistName,"innerText");
			clickElement(customerlistName);
			waitForLoading();
			invisibilityOfElementLocated(pageLoading);
			Thread.sleep(5000);
			invisibilityOfElementLocated(pageLoading);
			extentReport.reportInfo("Customer Profile page is displayed with customer's details pre-populated");



		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail( "Customer name is not displayed ");
			throw e;
		}
		return customerNameinlist;
	}
	@Override
	public void loading()
	{

		invisibilityOfElementLocated(pageLoading);
	}
	public  void customerSearch(String searchtext) throws Exception
	{ 
		this.extentTest = ExtentReport.node;
		scrollToView(searchByCustomerName);
		sendKeys(searchByCustomerName, searchtext);
		waitForLoading();
		driver.findElement(searchByCustomerName).sendKeys(Keys.TAB);

		check=false;
		loadingWithoutReport();
		final By customernameListSize=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td/a");
		waitForLoading();
		List<WebElement> customerNamelist =findElementslist(customernameListSize);
		//driver.findElements(By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td/a"));
		//List<WebElement> list3 = driver.findElements(By.xpath("//*[@id='tblHeader']/thead/tr[1]/th/img[@class='collapse']"));

		try 
		{
			extentReport.reportScreenShot("User is Searching with Text "+searchtext);

			for(int i=1;i<customerNamelist.size();i++)
			{
				int j=i;
				System.out.println(customerNamelist.size());
				invisibilityOfElementLocated(pageLoading);
				final By locationlocator=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[2]");
				final By customerNamelocator=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[1]/a");
				final By customerType=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[3]");
				final By phoneNumber=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[4]");
				System.out.println(j);

				//scrollToViewlist(customerNamelist.get(j));
				//System.out.println("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[1]/a");
				String customerName= getAttribute(customerNamelocator,"innerText");
				//driver.findElement(By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[1]/a")).getAttribute("innerText");
				String location=getAttribute(locationlocator,"innerText");
				String customertype=getAttribute(customerType,"innerText");
				String phonenumber=getAttribute(phoneNumber,"innerText");
				//driver.findElement(By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[2]")).getAttribute("innerText");
				customertype=customertype.toUpperCase();
				customerName=customerName.toUpperCase();
				phonenumber=phonenumber.toUpperCase();
				location=location.toUpperCase();
				searchtext=searchtext.toUpperCase();
				System.out.println(customerName);
				System.out.println(location);

				System.out.println(customerName.equalsIgnoreCase(searchtext));
				if(customerName.contains(searchtext))
				{
					extentTest.pass( "Customer name is displayed with search text "+customerName+" in row "+j);
					extentReport.reportScreenShot("Customer name is displayed with search text "+customerName+" in row "+j);
					check=true;
				}
				if (location.contains(searchtext))
				{
					extentTest.pass( "Location is displayed with search text "+location+" in row "+j);
					extentReport.reportScreenShot( "Location is displayed with search text "+location+" in row "+j);
					check=true;	
				}

				if (phonenumber.contains(searchtext))
				{
					extentTest.pass( "Phone number is displayed with search text "+phonenumber+" in row "+j);
					extentReport.reportScreenShot( "Phone number is displayed with search text "+phonenumber+" in row "+j);
					check=true;	
				}
				if (customertype.contains(searchtext))
				{
					extentTest.pass( "Customer Type is displayed with search text "+customertype+" in row "+j);
					extentReport.reportScreenShot( "Customer Type is displayed with search text "+customertype+" in row "+j);
					check=true;	
				}
				if(!check)
				{
					extentTest.fail("Result is not displayed in Row "+j);
					extentReport.reportScreenShot("Result is not displayed in Row "+j);
				}



			}
		}
		catch(Exception e){
			e.printStackTrace();

		}

	}


	public void goTo_CustomerProfilePage(String CustomerName) throws Exception {		
		String actualCustomerName=searchCustomerAndClick(CustomerName);
		System.out.println("actualCustomerName is  "+actualCustomerName);
		Thread.sleep(2000);

	}

	public void pageload()
	{
		invisibilityOfElementLocated(pageLoading);
	}





	public boolean modifiedCustomerPresence(String name,String location) throws InterruptedException 
	{
		boolean found=false;
		System.out.println("Inside Customer Presence Method");
		final By customernameListSize=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr/td/a");
		System.out.println("customernameListSize identified");
		List<WebElement> customerNamelist =findElementslist(customernameListSize);
		System.out.println("customernameListSize identified and it is "+customerNamelist.size());
		for(int i=1;i<customerNamelist.size();i++)
		{
			int j=i;
			Thread.sleep(500);
			invisibilityOfElementLocated(pageLoading);
			final By locationlocator=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[2]");
			final By customerNamelocator=By.xpath("//*[@id=\"dtl_pcs-home_table\"]/tbody/tr["+j+"]/td[1]/a");

			scrollToViewlist(customerNamelist.get(j));
			String customerName= getAttribute(customerNamelocator,"innerText");
			String cutomerLocation=getAttribute(locationlocator,"innerText");

			System.out.println("customername in List "+customerName);
			System.out.println("customername Passed "+name);

			System.out.println("cutomerLocation in List "+cutomerLocation);
			System.out.println("cutomerLocation Passed "+location);

			if(customerName.equalsIgnoreCase(name) && cutomerLocation.equalsIgnoreCase(location))
			{
				found=true;
			}

		}
		return found;

	}

	public boolean verifyCustomerNameInListPage() {
		Boolean Check = false;

		if (verifyElement(customerListTable)) {
			Check=true;
		}
		if (verifyElement(addACustomerButton_OR)) {
			Check=true;
		}			
		if (verifyElement(customerNameText)) {
			Check=true;
		}	
		if (verifyElement(addcustomercancelbutton)) {
			Check=true;
		}		
		return Check;
	}


	public boolean checkColumnHeader(String columnName) throws InterruptedException {
		Boolean Check = false;	
		switch(columnName) {
		case "CustomerName":
			if (verifyElement(customerlistHeader)) {
				Check=true;
			}
			break;
		case "Location":
			if (verifyElement(locationHeader)) {
				Check=true;
			}
			break;
		case "CustomerType":
			if (verifyElement(customerTypeHeader)) {
				Check=true;
			}
			break;
		case "TelephoneNo":
			if (verifyElement(telephoneNoHeader)) {
				Check=true;
			}
			break;	
		}
		return Check;
	}

	//Snehal

	public void searchWithExactCustomerNameAndClick(String searchCustomerName) throws Exception{
		//loading();

		if(verifyLandingPage())
		{
			By searchResultValue = By.xpath("//span[text()='"+searchCustomerName+"']");
			//waitForPageLoad();
			//loading();
			presenceOfElementLocated(searchCustomerbox_OR);
			visibilityOfElementLocated(searchCustomerbox_OR);
			elementToBeClickable(searchCustomerbox_OR);
			sendKeys(searchCustomerbox_OR, searchCustomerName.toLowerCase());
			extentReport.reportScreenShot("Customer name entered in Search Box");
			//loading();
			visibilityOfElementLocated(searchResultValue);
			elementToBeClickable(searchResultValue);
			extentReport.reportScreenShot("Clicking on '"+searchCustomerName+"' in customer list");
			//loading();
			clickElement(searchResultValue);
			loading();
			extentReport.reportScreenShot("Navigated to customer profile page");
		}
	}
	//Poojitha - Updated Override method as per new standards - Date: 28th Dec 2021
	@Override
	public boolean verifyLandingPage() {
		Boolean customerListPageCheck = false;

		if(isElementPresentwithoutException(addACustomerButton_OR,addACustomerButton_S)) {
			customerListPageCheck=true;
			extentReport.reportScreenShot("Customer list page is displayed successfully");
		}				
		return customerListPageCheck;

	}
	public Object verifyCustomerNameInListPage(String clinicName) {
		// TODO Auto-generated method stub
		boolean checkClinicName = false;
		try {

		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}

		return checkClinicName;
	}


}
