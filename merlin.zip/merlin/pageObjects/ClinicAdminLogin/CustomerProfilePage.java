package com.test.qa.ui.pageObjects.ClinicAdminLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;

public class CustomerProfilePage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	private ExtentTest extentTest;
	private final By pageLoading = By.xpath("//*[@class='spinnerWrapper show']");
	private final By customerlistName = By.xpath("//*[@id='dtl_pcs-home_table']/tbody/tr/td[1]/a");
	private final By searchByCustomerName = By.xpath("//*[@id=\"txt_pcs-home_search\"]");

	//Updated XPath as on 02/15-ChandraMohan
	//public final By customerLocationText = By.xpath("//*[@placeholder='Clinic Location'][@aria-required]");
	public final By clinicLocationText = By.xpath("//app-clinicinfo/div/div/div/div[1]//merlin-textbox[1]//div[1]//input");
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone,logon_user_name,clinicName,customerEmailAddress,addressLine1,addressLine2,stateCode,zipCode;
	public final By customerTypeDropdown = By.xpath("//*[@formcontrolname='customerTypeCd'][@aria-required]/div/div/span/span");
	public final By customerTypeText = By.xpath("//MAT-SELECT[@id='dd_customer-head-quarters_customerTypeCd']");
	public final By clinicLocationValue = By.xpath("//input[@id='txt_customer-clinicinfo_clinicLocation_primaryLocation']");

	//Updated XPath as on 02/15-ChandraMohan
	//public final By mainPhoneText = By.xpath("//*[@label='Main Phone']/mat-form-field/div/div/div/input");
	public final By mainPhoneText = By.xpath("//input[@id='txt_customer-clinicinfo_mainPhone_phoneNum']");

	public final By address1Text = By.xpath("//input[@placeholder='Address 1'][@aria-required]");
	//XPath Updated as on 02/19/2022-ChandraMohan.S
	//public final By address2Text = By.id("mat-input-6");
	public final By address2Text = By.xpath("//input[@id='txt_customer-clinicinfo_address2_streetAddress2']");
	
	//XPath Updated as on 02/19/2022-ChandraMohan.S
	//public final By address3Text = By.xpath("//merlin-textbox[@id='txt_customer-clinicinfo_address3']");
	public final By address3Text = By.xpath("//input[@id='txt_customer-clinicinfo_address3_streetAddress3']");
	
	public final By cityText = By.xpath("//*[@placeholder='city'][@aria-required]");
	public final By stateProvDropdown = By.xpath("//*[@formcontrolname='stateCd'][@aria-required]/div/div/span/span");
	public final By stateProvDropdownField = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']");

	public final By countryText = By.xpath("//*[@formcontrolname='countryCd'][@aria-required]//span/span");
	public final By zipPostalcodeText = By.xpath("//*[@placeholder='Zip/Postal Code'][@aria-required]");
	
	//Updated Xpath on 02/19/2022 -ChandraMohan.S
	//public final By secondaryPhoneText = By.xpath("//*[@label='Secondary Phone']/mat-form-field/div/div/div/input");
	public final By secondaryPhoneText = By.xpath("//input[@id='txt_customer-clinicinfo_secondaryPhone_phoneNum']");
	
	public final By emailText = By.xpath("//*[@placeholder='Email'][@aria-required]");

	//Updated Xpath -ChandraMohan.S
	//public final By clinicTimeZoneDropdown = By.xpath("//*[@formcontrolname='timeZoneCd'][@aria-required]/div/div/span/span");
	public final By clinicTimeZoneDropdown = By.xpath("//MAT-SELECT[@id='dd_customer-clinicinfo_timeZoneCd']");

	public final By textMessageText = By.xpath("//*[@placeholder='Text Message'][@aria-required]");
	public final By clinicLanguageDropdown = By.xpath("//*[@formcontrolname='localeCd'][@aria-required]/div/div/span/span");
	public final By clinicLanguageText = By.xpath("//*[@id=\"dd_customer-clinicinfo_localCd\"]/div/div[1]/span/span");
	public final By legalJurisdictionDropdown = By
			.xpath("//*[@formcontrolname='legalJurisdictionCd'][@aria-required]/div/div/span/span");
	
	//Updated Xpath on 08/19/2022-ChandraMohan.S
	//public final By faxText = By.xpath("//*[@label='Fax']/mat-form-field/div/div/div/input");
	public final By faxText = By.xpath("//input[@id='txt_customer-clinicinfo_fax_phoneNum']");
	
	public final By addSeclocationbutton = By.xpath("//*[@id=\"registration\"]/div[3]/button[1]/span");
	public final By addButton = By.xpath("//*[@id=\"btn_pcs-home_add-customer\"]/span");
	public final By addcustomercancelbutton = By.xpath("//*[@id=\"btn_customer_cancel\"]/span");
	public final By cancelbuttonOk = By.xpath(" //*[@id=\"btn_pcs-location-popup_Ok\"]/span");
	public final By merlinOnDemandCheckbox_OR = By
			.xpath("//mat-checkbox[@id='chb_customer-clinicinfo_capability']");
	public final String merlinOnDemandCheckbox_S = "Merlin On Demand Check Box";
	public final By testClinicCheckbox_OR = By.xpath("//mat-checkbox[@id='chb_customer-clinicinfo_test_clinic']");
	public final String testClinicCheckbox_S = "Test Clinic Check Box";
	public final By userIDText = By.xpath("//*[@placeholder='User ID'][@aria-required]");

	//Updated XPATH 02/15/2022-ChandraMohan.S
	//public final By firstNameText = By.xpath("//*[@placeholder='First Name'][@aria-required]");
	public final By firstNameText = By.xpath("//input[@id='txt_customer-clinic-main-contact_firstName_firstName']");

	//Updated XPATH 02/15/2022-ChandraMohan.S
	//public final By mainEmailText = By.xpath("//*[@placeholder='Email'][@controlname='mainContactEmail']/mat-form-field//following::input[@placeholder='Email']");
	public final By mainEmailText = By.xpath("//input[@id='txt_customer-clinic-main-contact_email_mainContactEmail']");

	public final By middlenameText = By.xpath("//*[@placeholder='Middle Name'][@aria-required]");
	public final By credentialsText_OR = By.xpath("//mat-select[@formcontrolname='credentialsCd'][@aria-required]/following::span/label/mat-label");
	public final String credentialsText_S = "Credential Text";
	public final By authenticationToViewCollegueEmail_OR = By.xpath("//mat-checkbox[@id='chb_customer-security-settings_ctrlViewCC']");
	public final String authenticationToViewCollegueEmail_S = "Authentication to view Collegue Email";
	public final By authenticationToViewUnPairedTransmitterEmail_OR = By.xpath("//mat-checkbox[@id='chb_customer-security-settings_ctrlViewTX']");
	public final String authenticationToViewUnPairedTransmitterEmail_S = "Authentication To View UnPaired Transmitter Email";
	public final By secureCommForAllTheEmailsAndMessages_OR = By.xpath("//mat-checkbox[@id='chb_customer-security-settings_allSecureMsgs']");
	public final String secureCommForAllTheEmailsAndMessages_S = "Secure Communication For All The EmailsAndMessages";
	public final By colleagueEmailCheckbox = By.xpath("//*[text()='Require recipient authentication to view Contact a Colleague emails']/preceding::input[1]");
	public final By unparredCheckbox = By.xpath("//*[text()='Require recipient authentication to view Unpaired transmitter emails']/preceding::input[1]");
	private final By alertCheckbox = By.xpath("//*[text()='Allow Mobile DirectAlerts� notifications ']/preceding::input[1]");
	private final By sendvoicemessagesCheckbox = By.xpath("//*[text()='Send voice messages ']/preceding::input[1]");
	private final By sendtextmessagesCheckbox = By.xpath("//*[text()='Send text messages ']/preceding::input[1]");

	private final By HcustomerNameGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[1]/div/button");
	private final By HprimaryLocationGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[2]/div/button");
	private final By HcustomerTypeGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[3]/div/button");
	private final By HphoneNumGetText = By.xpath("//*[@id=\"dtl_pcs-home_table\"]/thead/tr/th[4]/div/button");
	public final By userIdValue=By.xpath("//input[@placeholder='User ID'][@aria-required='true']");
	final By customerNameShorting = By.xpath("//*[contains(@class,'customerName ')]");
	final By primaryLocationShorting = By.xpath("//*[contains(@class,'primaryLocation')]");
	final By customerTypeShorting = By.xpath("//*[contains(@class,'customerTypeDesc')]");
	final By phoneNumShorting = By.xpath("//*[contains(@class,'phoneNum')]");
	//mohan
	public final By changeButton_OR = By.xpath("//button[@id='btn_customer_changeCustomer']");
	private final String changeButton_S = "Change Button";

	public final By deleteButton_OR = By.xpath("//button[@id='btn_customer_deleteCustomer']");
	private final String deleteButton_S = "Delete Button";

	public final By deleteConfirmButton_OR = By.xpath("//button[@id='close-btn-customer-delete-popup']");
	private final String deleteConfirmButton_S = "Delete Confirmation Button";

	public final By deleteConfirmPopUPButton_OR = By.xpath("//button[@id='close-btn-customer-delete-popup']");
	private final String deleteConfirmPopUPButton_S = "Delete Confirmation PopUP Button";

	public final By okButton_OR = By.xpath("//button[@id='close-btn-customer-delete-popup']");
	private final String okButton_S = "Ok button in Delete Popup";
	public final By deletePopUpContent = By.xpath("//mat-dialog-content");
	private final By customerHeadquarterText = By.xpath("//*[contains(text(),'Customer Headquarters')]");
	private final By customerProfilePageTitle = By.xpath("//*[@id=\"add-customer-wrapper\"]");
	private final By addSecondaryLocationButton = By.xpath("//*[@id=\"btn_customer_addSecondaryLocation\"]");
	public final By allowedClinicalTrailSectionTitle_OR = By.xpath("//merlin-bucket-list[@id=\"bls_customer-feature-control_allowedClinicTrial\"]/div/div/div");
	public final String allowedClinicalTrailSectionTitle_S = "Allowed Clinical Trail Title";
	private final By allowedClinicalTrailSection = By.xpath("//*[contains(text(),'Allowed Clinical Trials')]/following::select[1]");
	//public final By countryCodeText = By.id("mat-input-10");

	String userId = "";
	public final By countryCodeText = By.xpath("//*[@id=\"mat-input-10\"]");
	public final By lastNameText = By.id("mat-input-24");
	public final By areaCodeText = By.id("mat-input-11");
	public final By faxCountryCodeText = By.id("mat-input-16");
	public final By faxAreaCodeText_OR = By.id("txt_customer-clinicinfo_areaCode_areaCode");
	public final String faxAreaCodeText_S = "Fax Area Code";
	private final By signOut = By.xpath("//span[@class=\"mat-button-wrapper\"]");
	private String signOutMessageText = null;
	public static Log logger = new Log();
	Assertions softAssert;
	//Poojitha
	private final By clinicFeatureControlHeader_OR = By.xpath("//*[@id='lbl_customer-feature-control_directalert_notification_allowed']//ancestor::mat-card/div/div");
	private final String clinicFeatureControlHeader_S = " Corelating DirectAlerts� Notifications allowed for patients and Clinic Feature control section";
	//Updated Xpath as on 02/14-ChandraMohan.S
	//public final By areaCodeText_OR = By.xpath("//input[@id='merlin_textbox_areaCode']"); 
	public final By areaCodeText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_areaCode_areaCode']");
	public final String areaCodeText_S = "Area code text box"; 

	//Updated Xpath as on 02/14-ChandraMohan.S
	public final By countryCodeText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_countryCode_countryCode']");
	public final String countryCodeText_S = "Country code text box";

	public final By lastNameText_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_lastName_lastName']");
	public final String lastNameText_S = "Last name text box";
	public final By address2Text_OR = By.xpath("//input[@id='txt_customer-clinicinfo_address2_streetAddress2']");
	public final String address2Text_S = "Address Line2 text box";
	public final By faxCountryCodeText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_countryCode_countryCode']");
	public final String faxCountryCodeText_S = "fax country code text box";

	//Updated Xpath as on 02/14-ChandraMohan.S
	//public final By customerNameText_OR = By.xpath("//input[@placeholder='Customer name'][@aria-required]");
	public final By customerNameText_OR = By.xpath("//input[@id='txt_customer-head-quarters_customerName_customerName']");
	public final String customerNameText_S = "customer Name text box";

	public final By customerLocationText_OR = By.xpath("//input[@placeholder='Clinic Location'][@aria-required]");
	public final String customerLocationText_S = "customer location text box";
	public final By customerTypeDropdown_OR = By
			.xpath("//mat-select[@formcontrolname='customerTypeCd'][@aria-required]/div/div/span/span");
	public final String customerTypeDropdown_S = "customer type dropdown";
	public final By mainPhoneText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_mainPhone_phoneNum']");
	public final String mainPhoneText_S = "Main phone text box";
	public final By address1Text_OR = By.xpath("//input[@placeholder='Address 1'][@aria-required]");
	public final String address1Text_S = "addressline1 text box";
	public final By address3Text_OR = By.xpath("//input[@placeholder='Address 3'][@aria-required]");
	public final String address3Text_S = "addressline3 text box";
	public final By cityText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_city_city']");
	public final String cityText_S = "city text box";
	public final By stateProvDropdown_OR = By.xpath("//*[@formcontrolname='stateCd'][@aria-required]/div/div/span/span");
	public final String stateProvDropdown_S = "state code dropdown";
	public final By stateProvDropdownField_OR = By.xpath("//mat-select[@id='dd_customer-clinicinfo_stateCd']");
	public final String stateProvDropdownField_S = "state provinence dropdown";
	public final By countryText_OR = By.xpath("//mat-select[@formcontrolname='countryCd'][@aria-required]/div/div/span/span");
	public final String countryText_S = "country text";
	public final By zipPostalcodeText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_zipCode_zipCode']");
	public final String zipPostalcodeText_S = "postal code text box";
	public final By secondaryPhoneText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_secondaryPhone_phoneNum']");
	public final String secondaryPhoneText_S = "secondary phone text box";
	public final By emailText_OR = By.xpath("//input[@placeholder='Email'][@aria-required]");
	public final String emailText_S = "email address text box";
	public final By clinicTimeZoneDropdown_OR = By
			.xpath("//mat-select[@formcontrolname='timeZoneCd'][@aria-required]/div/div/span/span");
	public final String clinicTimeZoneDropdown_S = "clinic time zone dropdown";
	public final By clinicLanguageDropdown_OR = By
			.xpath("//mat-select[@id='dd_customer-clinicinfo_localCd'][@aria-required]/div/div/span");
	public final String clinicLanguageDropdown_S = "clinic language zone dropdown";
	public final By legalJurisdictionDropdown_OR = By
			.xpath("//mat-select[@formcontrolname='legalJurisdictionCd'][@aria-required]/div/div/span/span");
	public final String legalJurisdictionDropdown_S = "legaljurisdiction zone dropdown";
	public final By faxText_OR = By.xpath("//input[@id='txt_customer-clinicinfo_fax_phoneNum']");
	public final String faxText_S = "fax text box";
	public final By userIDText_OR = By.xpath("//input[@placeholder='User ID'][@aria-required]");
	public final String userIDText_S = "UserId text box";
	public final By firstNameText_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_firstName_firstName']");
	public final String firstNameText_S = "first name text box";
	public final By mainEmailText_OR = By.xpath(
			"//input[@id='txt_customer-clinic-main-contact_email_mainContactEmail']");
	public final String mainEmailText_S = "main emailId text box";
	public final By middlenameText_OR = By.xpath("//input[@id='txt_customer-clinic-main-contact_middleName_middleName']");
	public final String middlenameText_S = "middle name text box";
	private final By addSecondaryLocationButton_OR = By.xpath("//*[@id=\"btn_customer_addSecondaryLocation\"]");
	private final String addSecondaryLocationButton_S = "Add Secondary location button";
	private final By customerHeadquarterText_OR = By.xpath("//div[@id='section_title_Customer_headquarters']");
	private final String customerHeadquarterText_S = "customer headquarter text";

	//Poojitha - Added new XPath's
	private final By sendvoicemessages_OR = By.xpath("//mat-checkbox[@formcontrolname='allowDirectCallVoice']");
	private final String sendvoicemessages_S = "Send Voice Messages label and checkbox";
	private final By sendtextmessages_OR = By.xpath("//mat-checkbox[@formcontrolname='allowDirectCallText']");
	private final String sendtextmessages_S = "Send text Messages label and checkbox";
	private final By patientDataCollectionConsent_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_showDataMiningConsentFlg']");
	private final String patientDataCollectionConsent_S = "patientDataCollectionConsent label and checkbox";
	private final By mobileDirectAlerts_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowSmartAlertFlg']");
	private final String mobileDirectAlerts_S = "mobile direct alerts label and checkbox";
	private final By communicationCenter_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowCommCenterAccess']");
	private final String communicationCenter_S = "communicationCenter label and checkbox";
	private final By complianceReport_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_allowComplianceReport']");
	private final String complianceReport_S = "compliance report label and checkbox";
	private final By exportTransmission_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_showExportSessionFlg']");
	private final String exportTransmission_S = "Export transmission label and checkbox";
	private final By orderTransmitter_OR = By.xpath("//mat-checkbox[@id='chb_customer-feature-control_orderTransmitterFlg']");
	private final String orderTransmitter_S = "order transmitter label and checkbox";

	//Added for Activator clinic test case
		private final By activatorClinicCheckbox_OR = By.xpath("//input[@id='chb_customer-clinicinfo_activator_clinic-input']");
		private final String activatorClinicCheckbox_S = "Activator clinic checkbox";

	//Ends here

	public CustomerProfilePage(WebDriver driver,ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		softAssert = new Assertions(extentTest);
	}

	public void clickChangeButton() throws Exception {
		loadingWithoutReport();
		clickElement(changeButton_OR, changeButton_S);
		loadingWithoutReport();
		//waitForLoading();
		extentReport.reportScreenShot("User clicked on Change button");
	}

	public void clickDeleteButton() throws Exception {
		clickElement(deleteButton_OR, deleteButton_S);
		extentReport.reportScreenShot("User clicked on Delete button");
	}

	public void clickOKButton() throws Exception {
		clickElement(okButton_OR, okButton_S);
		extentReport.reportScreenShot("User clicked on OK button");
	}

	public String getUserId() throws InterruptedException {

		if(visibilityOfElementLocated(userIdValue))
			userId = getAttribute(userIdValue,"value");
		return userId;
	}

	@Override
	public void loading()
	{

		invisibilityOfElementLocated(pageLoading);
	}
	public void goToChangeCustomerProfilePage() throws Exception {
		waitForLoading();
		if (getSizeOfElements(changeButton_OR, changeButton_S)>0) {
			clickChangeButton();	
			waitForLoading();
		}

	}

	public void deleteCustomer() throws Exception {
		try {
			waitForPageLoad();
			if(visibilityOfElementLocated(deleteButton_OR)) {
				waitForElementToBeClickable(deleteButton_OR);
				/*
				 * waitForLoading(); waitForLoading();
				 */
				clickElement(deleteButton_OR);
				extentReport.reportScreenShot( "Delete Button is clicked in Customer Profile page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void ConfirmDeleteCustomer() throws Exception {
		try {
			waitForPageLoad();
			if(visibilityOfElementLocated(deleteConfirmButton_OR)) {
				waitForElementToBeClickable(deleteConfirmButton_OR);
				clickElement(deleteConfirmButton_OR);
				extentReport.reportScreenShot("Delete confirmation OK Button is clicked in Customer Profile page");

				waitForElementToBeClickable(deleteConfirmPopUPButton_OR);
				clickElement(deleteConfirmPopUPButton_OR);
				extentReport.reportScreenShot( "Delete confirmation OK Button in PopUp is clicked in Customer Profile page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	public void goToAddSecondaryLocationPage() throws Exception {
		try {
			waitForLoading();
			if(visibilityOfElementLocated(addSecondaryLocationButton)) {
				waitForElementToBeClickable(addSecondaryLocationButton);
				scrollToView(addSecondaryLocationButton);
				clickElement(addSecondaryLocationButton);
				extentReport.reportScreenShot( "Add a Secondary Location Button is clicked in Customer Profile page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}



	public String VerifyCustomerDataInViewMode(String FieldName) throws Exception {
		/*	String value = "";
		try {
			switch (FieldName) {
			case "CustomerName":
				//value = customerPageElementvalidation(customerNameText, "value", "Customer Name Textbox");
				break;
			case "CustomerType":
				value = customerPageElementvalidation(customerTypeDropdown, "customerTypeDropdown", "Customer Type Dropdown");
				break;
			case "ClinicLocation":
				value = customerPageElementvalidation(customerLocationText, "value", "customer Location Textbox");
				break;
			case "MainPhone":
				value = customerPageElementvalidation(mainPhoneText, "value", "Main Phone Textbox");
				break;
			case "CountryCode":
				value = customerPageElementvalidation(countryCodeText_OR, "value", "Country Code Textbox");
				break;
			case "AreaCode":
				value = customerPageElementvalidation(areaCodeText_OR, "value", "Area Code Textbox");
				break;
			case "Address1":
				value = customerPageElementvalidation(address1Text_OR, "value", "addressline1 Textbox");
				break;
			case "Address2":
				value = customerPageElementvalidation(address2Text_OR, "value", "addressline2 Textbox");
				break;
			case "Address3":
				value = customerPageElementvalidation(address3Text_OR, "value", "addressline3 Textbox");
				break;
			case "City":
				value = customerPageElementvalidation(cityText_OR, "value", " city Textbox");
				break;
			case "ClinicLanguage":
				value = customerPageElementvalidation(clinicLanguageDropdown, "clinicLanguageDropdown",
						" clinic Language Dropdown");
				break;
			case "FaxCountryCode":
				value = customerPageElementvalidation(faxCountryCodeText, "value", "Country Code Textbox");
				break;
			case "FaxAreaCode":
				value = customerPageElementvalidation(faxAreaCodeText, "value", "Area Code Textbox");
				break;
			case "State/Prov":
				value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown", " state/Prov Dropdown");
				break;
			case "Country":
				value = customerPageElementvalidation(countryText_OR, "countryDropdown", " country Dropdwon");
				break;
			case "Zip/PostalCode":
				value = customerPageElementvalidation(zipPostalcodeText, "value", " zipPostalcode Textbox");
				break;
			case "SecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText, "value", " secondary Phone Textbox");
				break;
			case "Fax":
				value = customerPageElementvalidation(faxText, "value", " fax Textbox");
				break;
			case "ClinicTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown, "clinicTimeZoneDropdown",
						" clinicTimeZone Dropdown");
				break;
			case "TextMessage":
				value = customerPageElementvalidation(textMessageText, "value", " textMessage Textbox");
				break;
			case "LegalJurisdiction":
				value = customerPageElementvalidation(legalJurisdictionDropdown, "legalJurisdictionDropdown",
						" legal Jurisdiction Dropdown");
				break;
			case "Email":
				value = customerPageElementvalidation(emailText, "value", " email Textbox");
				break;
			case "MiddleName":
				value = customerPageElementvalidation(middlenameText, "value", "Middle name Textbox");
				break;
			case "LastName":
				value = customerPageElementvalidation(lastNameText, "value", "Middle name Textbox");
				break;
			case "UserID":
				value = customerPageElementvalidation(userIDText, "value", "Main user ID");
				break;
			case "FirstName":
				value = customerPageElementvalidation(firstNameText, "value", "first Name Textbox");
				break;
			case "MainContactEmail":
				value = customerPageElementvalidation(mainEmailText, "value", "Main Email Textbox");
				break; 
				case "Credentials":
					value = customerPageElementvalidation(credentialsText, "value", "credentials Textbox");
					break; 
					case "CustomerOnDemandCheckbox":
						value = customerPageElementvalidation(merlinOnDemandCheckbox, "merlinOnDemandCheckbox",
								" merlin OnDemand Checkbox");
						break;
					case "CustomerTestClinic":
						customerPageElementvalidation(testClinicCheckbox, "testClinicCheckbox", " test Clinic Checkbox");
						break; 
						case "CustomerUnpaired":
							value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox", "unparred Checkbox");
							break;
						case "CustomerAlertCheckbox":
							value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert Checkbox");
							break;
						case "CustomerSendTextMessage":
							value = customerPageElementvalidation(sendtextmessagesCheckbox, "sendtextmessagesCheckbox",
									"Send Text Message Chechbox");
							break;
						case "CustomerSendVoiceMessage":
							value = customerPageElementvalidation(sendvoicemessagesCheckbox, "sendvoicemessagesCheckbox",
									"SendvoicemessagesCheckbox");
							break; } return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
=======*/
		String value = "";
		try {
			switch (FieldName) {
			case "CustomerName":
				value = customerPageElementvalidation(customerNameText_OR, "value", "Customer Name Textbox");
				break;
			case "CustomerType":
				value = customerPageElementvalidation(customerTypeDropdown, "customerTypeDropdown", "Customer Type Dropdown");
				break;
			case "ClinicLocation":
				value = customerPageElementvalidation(clinicLocationText, "value", "customer Location Textbox");
				break;
			case "MainPhone":
				value = customerPageElementvalidation(mainPhoneText, "value", "Main Phone Textbox");
				break;
			case "CountryCode":
				value = customerPageElementvalidation(countryCodeText_OR, "value", "Country Code Textbox");
				break;
			case "AreaCode":
				value = customerPageElementvalidation(areaCodeText_OR, "value", "Area Code Textbox");
				break;
			case "Address1":
				value = customerPageElementvalidation(address1Text_OR, "value", "addressline1 Textbox");
				break;
			case "Address2":
				value = customerPageElementvalidation(address2Text_OR, "value", "addressline2 Textbox");
				break;
			case "Address3":
				value = customerPageElementvalidation(address3Text_OR, "value", "addressline3 Textbox");
				break;
			case "City":
				value = customerPageElementvalidation(cityText_OR, "value", " city Textbox");
				break;
			case "ClinicLanguage":
				value = customerPageElementvalidation(clinicLanguageDropdown, "clinicLanguageDropdown",
						" clinic Language Dropdown");
				break;
			case "FaxCountryCode":
				value = customerPageElementvalidation(faxCountryCodeText, "value", "Country Code Textbox");
				break;
			case "FaxAreaCode":
				value = customerPageElementvalidation(faxAreaCodeText_OR, "value", "Area Code Textbox");
				break;
			case "State/Prov":
				value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown", " state/Prov Dropdown");
				break;
			case "Country":
				value = customerPageElementvalidation(countryText_OR, "countryDropdown", " country Dropdwon");
				break;
			case "Zip/PostalCode":
				value = customerPageElementvalidation(zipPostalcodeText, "value", " zipPostalcode Textbox");
				break;
			case "SecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText, "value", " secondary Phone Textbox");
				break;
			case "Fax":
				value = customerPageElementvalidation(faxText, "value", " fax Textbox");
				break;
			case "ClinicTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown, "clinicTimeZoneDropdown",
						" clinicTimeZone Dropdown");
				break;
			case "TextMessage":
				value = customerPageElementvalidation(textMessageText, "value", " textMessage Textbox");
				break;
			case "LegalJurisdiction":
				value = customerPageElementvalidation(legalJurisdictionDropdown, "legalJurisdictionDropdown",
						" legal Jurisdiction Dropdown");
				break;
			case "Email":
				value = customerPageElementvalidation(emailText, "value", " email Textbox");
				break;
			case "MiddleName":
				value = customerPageElementvalidation(middlenameText, "value", "Middle name Textbox");
				break;
			case "LastName":
				value = customerPageElementvalidation(lastNameText, "value", "Middle name Textbox");
				break;
			case "UserID":
				value = customerPageElementvalidation(userIDText, "value", "Main user ID");
				break;
			case "FirstName":
				value = customerPageElementvalidation(firstNameText, "value", "first Name Textbox");
				break;
			case "MainContactEmail":
				value = customerPageElementvalidation(mainEmailText, "value", "Main Email Textbox");
				break; 
			case "Credentials":
				value = customerPageElementvalidation(credentialsText_OR, "value", "credentials Textbox");
				break; 
			case "CustomerOnDemandCheckbox":
				value = customerPageElementvalidation(merlinOnDemandCheckbox_OR, "merlinOnDemandCheckbox"," merlin OnDemand Checkbox");
				break;
			case "CustomerTestClinic":
				customerPageElementvalidation(testClinicCheckbox_OR, "testClinicCheckbox", " test Clinic Checkbox");
				break; 
			case "CustomerUnpaired":
				value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox", "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert Checkbox");
				break;
			case "CustomerSendTextMessage":
				value = customerPageElementvalidation(sendtextmessagesCheckbox, "sendtextmessagesCheckbox",
						"Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox, "sendvoicemessagesCheckbox",
						"SendvoicemessagesCheckbox");
				break; 
			} 
			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}


	public boolean verifyMandateCustomerDataInViewMode(String FieldName) throws Exception {
		String value = "";
		boolean fieldValueExists =false;
		try {
			switch (FieldName) {
			case "CustomerName":
				value = customerPageElementvalidation(customerNameText_OR, "Value", "Customer Name");
				/*fieldValueExists =false;
				if(!value.contains("blank")) {
					fieldValueExists =true;
				}*/
				break;
			case "CustomerType":
				value = customerPageElementvalidation(customerTypeText, "Text", "Customer Type");
				break;
			case "ClinicLocation":
				value = customerPageElementvalidation(clinicLocationText, "Value", "ClinicLocation");
				break;
			case "MainPhone":
				value = customerPageElementvalidation(mainPhoneText, "Value", "Main Phone");
				break;
			case "CountryCode":
				value = customerPageElementvalidation(countryCodeText_OR, "Value", "Country Code");
				break;
			case "AreaCode":
				value = customerPageElementvalidation(areaCodeText_OR, "Value", "Area Code");
				break;
			case "Address1":
				value = customerPageElementvalidation(address1Text, "Value", "address");
				break;
			case "Address2":
				value = customerPageElementvalidation(address2Text, "Value", "address");
				break;
			case "Address3":
				value = customerPageElementvalidation(address3Text, "Value", "address");
				break;
			case "City":
				value = customerPageElementvalidation(cityText, "Value", " city");
				break;
				
			case "FaxCountryCode":
				value = customerPageElementvalidation(faxCountryCodeText, "Value", "Country Code");
				break;
			case "FaxAreaCode":
				value = customerPageElementvalidation(faxAreaCodeText_OR, "Value", "Area Code");
				break;
			case "State/Prov":
				value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown", " state/Prov Dropdown");
				break;
			case "Country":
				value = customerPageElementvalidation(countryText, "countryText", " country Text");
				break;
			case "Zip/PostalCode":
				value = customerPageElementvalidation(zipPostalcodeText, "Value", " zipPostalcode");
				break;
			case "SecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText, "Value", " secondary Phone");
				break;
			case "Fax":
				value = customerPageElementvalidation(faxText, "Value", " fax");
				break;
			case "ClinicTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown, "clinicTimeZoneDropdown"," clinicTimeZone Dropdown");
				break;
			case "TextMessage":
				value = customerPageElementvalidation(textMessageText, "Value", " textMessage");
				break;
			case "LegalJurisdiction":
				value = customerPageElementvalidation(legalJurisdictionDropdown, "legalJurisdictionDropdown"," legal Jurisdiction");
				break;
			case "Email":
				value = customerPageElementvalidation(emailText, "Value", " email");
				break;
			case "MiddleName":
				value = customerPageElementvalidation(middlenameText, "Value", "Middle name");
				break;
			case "LastName":
				value = customerPageElementvalidation(lastNameText_OR, "Text", "Last name");
				break;
			case "UserID":
				value = customerPageElementvalidation(userIDText, "Value", "User ID");
				break;
			case "FirstName":
				value = customerPageElementvalidation(firstNameText, "Value", "first Name");
				break;
			case "MainContactEmail":
				value = customerPageElementvalidation(mainEmailText, "Value", "Main Email");
				break;

			case "Credentials":
				value = customerPageElementvalidation(credentialsText_OR, "Value", "credentials");
				break;

			case "CustomerOnDemandCheckbox":
				value = customerPageElementvalidation(merlinOnDemandCheckbox_OR, "merlinOnDemandCheckbox"," merlin OnDemand");
				break;

			case "CustomerTestClinic":
				customerPageElementvalidation(testClinicCheckbox_OR, "testClinicCheckbox", " test Clinic Checkbox");
				if(!value.contains("blank")) {
					fieldValueExists =true;
				}
				break;

			case "CustomerUnpaired":
				value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox", "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert Checkbox");
				break;
			case "CustomerSendTextMessage":
				value = customerPageElementvalidation(sendtextmessagesCheckbox, "sendtextmessagesCheckbox","Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox, "sendvoicemessagesCheckbox","SendvoicemessagesCheckbox");
				break;
			}
			if(!value.contains("blank")) 
			{ 
				fieldValueExists =true; 
			}
			return fieldValueExists;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}



	/*
	 * public String customerPageElementvalidation(By locator, String locatorText,
	 * String Message) throws InterruptedException { this.extentTest =
	 * ExtentReport.node; String content = ""; try {
	 * System.out.println(locatorText); if (isElementPresent(locator)) {
	 * scrollToView(locator); if (locatorText.contains("value")) { content =
	 * getAttribute(locator, "value"); if (!content.isEmpty()) {
	 * extentTest.info(Message + " is Displayed as " + content); } else {
	 * extentTest.info(Message + " is Displayed and blank " + content); } } else if
	 * (locatorText.contains("Checkbox")) { content = getAttribute(locator,
	 * "aria-checked"); if (content.equals("false")) { extentTest.info(Message +
	 * " is  not Selected "); } else { extentTest.info(Message + " is  Selected ");
	 * } }
	 * 
	 * else if (locatorText.contains("Dropdown")) { content = getText(locator); if
	 * (content != null) { extentTest.info(Message + " is  Displayed as " +
	 * content); } } else if (locatorText.contains("Text")) { content =
	 * getText(locator); extentTest.info(Message + " is Displayed as " + content); }
	 * } else { content = null; extentTest.info(Message +
	 * " is  Displayed as Blank "); } } catch (Exception e) { content = null;
	 * extentTest.info(Message + " is  Displayed as Blank "); } return content;
	 * 
	 * }
	 */

	public String customerPageElementvalidation(By locator, String locatorText, String Message)throws InterruptedException {
		this.extentTest = ExtentReport.node;
		String content = "";
		try {
			System.out.println(locatorText);
			if (isElementPresent(locator)) {
				scrollToView(locator);
				if (locatorText.contains("Value")||locatorText.contains("value")) {
					content = getAttribute(locator, "value");
					if (!content.isEmpty()) {
						extentTest.info(Message + " is Displayed as " + content);
					} else {
						extentTest.info(Message + " is Displayed and blank " + content);
					}
				} else if (locatorText.contains("Checkbox")) {
					content = getAttribute(locator, "aria-checked");
					if (content.equals("false")) {
						extentTest.info(Message + " is  not Selected ");
					} else {
						extentTest.info(Message + " is  Selected ");
					}
				}

				else if (locatorText.contains("Dropdown")) {
					content = getText(locator);
					if (content != null) {
						extentTest.info(Message + " is  Displayed as " + content);
					}
				} else if (locatorText.contains("Text")) {
					content = getText(locator);
					extentTest.info(Message + " is Displayed as " + content);
				}
			} else {
				content = null;
				extentTest.info(Message + " is  Displayed as Blank ");
			}
		} catch (Exception e) {
			content = null;
			extentTest.info(Message + " is  Displayed as Blank ");
		}
		return content;

	}

	public String customerPageElementvalidation(By locator, String locatorText, String Message,String extReportMsg)throws InterruptedException {
		this.extentTest = ExtentReport.node;
		String content = "";
		try {
			if (isElementPresent(locator)) {
				scrollToView(locator);
				if (locatorText.contains("value")) {
					content = getAttribute(locator, "value");
					if (!content.isEmpty()) {
						extentReport.reportScreenShot(extReportMsg+" "+Message + " is Displayed as " + content);
					} else {
						extentReport.reportScreenShot(extReportMsg+" "+Message + " is Displayed and blank " + content);
					}
				} else if (locatorText.contains("Checkbox")) {
					content = getAttribute(locator, "aria-checked");
					if (content.equals("false")) {
						extentReport.reportScreenShot( Message + " is  not Selected ");
					} else {
						extentReport.reportScreenShot( Message + " is  Selected ");
					}
				}
				else if (locatorText.contains("Dropdown")) {
					content = getText(locator);
					if (content != null) {
						extentReport.reportScreenShot( Message + " is  Displayed as " + content);
					}
				} else if (locatorText.contains("Text")) {
					content = getText(locator);
					if(content.isEmpty()) {
						content = getText(locator);	
					}
					extentReport.reportScreenShot( extReportMsg+"  "+Message + " is Displayed as " + content);
				}
			} else {
				content = null;
				extentReport.reportScreenShot( Message + " is  Displayed as Blank ");
			}
		} catch (Exception e) {
			content = null;
			extentReport.reportScreenShot( Message + " is  Displayed as Blank ");
		}
		return content;
	}

	public String customerPageElementGetValue(By locator, String locatorText, String Message,String extReportMsg)throws InterruptedException {
		String content = "";
		try {
			if (isElementPresent(locator)) {
				scrollToView(locator);
				if (locatorText.contains("value")) {
					content = getAttribute(locator, "value");
					if (!content.isEmpty()) {
						extentReport.reportInfo(extReportMsg+" "+Message + " is Displayed as " + content);
					} else {
						extentReport.reportInfo(extReportMsg+" "+Message + " is Displayed and blank " + content);
					}
				} else if (locatorText.contains("Checkbox")) {
					content = getAttribute(locator, "aria-checked");
					if (content.equals("false")) {
						extentReport.reportInfo( Message + " is  not Selected ");
					} else {
						extentReport.reportInfo( Message + " is  Selected ");
					}
				}
				else if (locatorText.contains("Dropdown")) {
					content = getText(locator);
					if (content != null) {
						extentReport.reportInfo( Message + " is  Displayed as " + content);
					}
				} else if (locatorText.contains("Text")) {
					content = getText(locator);
					extentReport.reportInfo( extReportMsg+"  "+Message + " is Displayed as " + content);
				}
			} else {
				content = null;
				extentReport.reportInfo( Message + " is  Displayed as Blank ");
			}
		} catch (Exception e) {
			content = null;
			extentReport.reportInfo( Message + " is  Displayed as Blank ");
		}
		return content;
	}

	public String VerifyCustomerDataInViewModee(String FieldName, String extReportMsg) throws Exception {

		String value = "";
		try {
			switch (FieldName) {
			case "CustomerName":
				value = customerPageElementvalidation(customerNameText_OR, "value", "Customer Name");
				break;
			case "CustomerType":
				value = customerPageElementvalidation(customerTypeText, "value", "Customer Name Textbox",extReportMsg);
				break;
			case "ClinicLocation":
				value = customerPageElementvalidation(clinicLocationText, "value", "customer Location");
				break;
			case "MainPhone":
				value = customerPageElementvalidation(mainPhoneText, "value", "Main Phone");
				break;
			case "CountryCode":
				value = customerPageElementvalidation(countryCodeText, "value", "Country Code");
				//customerPageElementvalidation(By locator, String locatorText, String Message,String extReportMsg)
				break;
			case "AreaCode":
				value = customerPageElementvalidation(areaCodeText, "value", "Area Code");
				break;
			case "Address1":
				value = customerPageElementvalidation(address1Text, "value", "address");
				break;
			case "Address2":
				value = customerPageElementvalidation(address2Text, "value", "address");
				break;
			case "Address3":
				value = customerPageElementvalidation(address3Text, "value", "address");
				break;
			case "City":
				value = customerPageElementvalidation(cityText, "value", " city");
				break;
			case "ClinicLanguage":
				value = customerPageElementvalidation(clinicLanguageDropdown, "clinicLanguageDropdown"," clinic Language Dropdown");

			case "FaxCountryCode":
				value = customerPageElementvalidation(faxCountryCodeText, "value", "Country Code");
				break;
			case "FaxAreaCode":
				value = customerPageElementvalidation(faxAreaCodeText_OR, "value", "Area Code");
				break;
			case "State/Prov":
				value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown", " state/Prov");
				break;
			case "Country":
				//value = customerPageElementvalidation(countryDropdown, "countryDropdwon", " country Dropdwon");
				break;
			case "Zip/PostalCode":
				value = customerPageElementvalidation(zipPostalcodeText, "value", " zipPostalcode");
				break;
			case "SecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText, "value", " secondary Phone");
				break;
			case "Fax":
				value = customerPageElementvalidation(faxText, "value", " fax");
				break;
			case "ClinicTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown, "clinicTimeZoneDropdown",
						" clinicTimeZone Dropdown");
				break;
			case "TextMessage":
				value = customerPageElementvalidation(textMessageText, "value", " textMessage");
				break;
			case "LegalJurisdiction":
				value = customerPageElementvalidation(legalJurisdictionDropdown, "legalJurisdictionDropdown",
						" legal Jurisdiction Dropdown");
				break;
			case "Email":
				value = customerPageElementvalidation(emailText, "value", " email");
				break;
			case "MiddleName":
				value = customerPageElementvalidation(middlenameText, "value", "Middle name");
				break;
			case "LastName":
				value = customerPageElementvalidation(lastNameText_OR, "value", "Middle name");
				break;
			case "UserID":
				value = customerPageElementvalidation(userIDText, "value", "Main user ID");
				break;
			case "FirstName":
				value = customerPageElementvalidation(firstNameText, "value", "first Name");
				break;
			case "MainContactEmail":
				value = customerPageElementvalidation(mainEmailText, "value", "Main Email Textbox");
				break;

			case "Credentials":
				value = customerPageElementvalidation(credentialsText_OR, "value", "credentials");
				break;

			case "CustomerOnDemandCheckbox":
				value = customerPageElementvalidation(merlinOnDemandCheckbox_OR, "merlinOnDemandCheckbox",
						" merlin OnDemand Checkbox");
				break;
			case "CustomerTestClinic":
				customerPageElementvalidation(testClinicCheckbox_OR, "testClinicCheckbox", " test Clinic Checkbox");
				break;

			case "CustomerUnpaired":
				value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox", "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert Checkbox");
				break;
			case "CustomerSendTextMessage":
				value = customerPageElementvalidation(sendtextmessagesCheckbox, "sendtextmessagesCheckbox",
						"Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox, "sendvoicemessagesCheckbox",
						"SendvoicemessagesCheckbox");
				break;

			}

			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	public String getCustomerDataInViewMode(String FieldName) throws Exception {
		String value = "";
		try {
			switch (FieldName) {
			case "CustomerName":
				value = customerPageElementvalidation(customerNameText_OR, "value", "Customer Name");
				break;
			case "CustomerType":
				value = customerPageElementvalidation(customerTypeDropdown, "value", "Customer Name");
				break;
			case "ClinicLocation":
				value = customerPageElementvalidation(clinicLocationText, "value", "customer Location");
				break;
			case "MainPhone":
				value = customerPageElementvalidation(mainPhoneText, "value", "Main Phone");
				break;
			case "CountryCode":
				value = customerPageElementvalidation(countryCodeText, "value", "Country Code");
				break;
			case "AreaCode":
				value = customerPageElementvalidation(areaCodeText, "value", "Area Code");
				break;
			case "Address1":
				value = customerPageElementvalidation(address1Text, "value", "address1");
				break;
			case "Address2":
				value = customerPageElementvalidation(address2Text, "value", "address2");
				break;
			case "Address3":
				value = customerPageElementvalidation(address3Text, "value", "address3 Textbox");
				break;
			case "City":
				value = customerPageElementvalidation(cityText, "value", " city Textbox");
				break;
			case "ClinicLanguage":
				value = customerPageElementvalidation(clinicLanguageDropdown, "clinicLanguageDropdown",
						" clinic Language Dropdown");
			case "FaxCountryCode":
				value = customerPageElementvalidation(faxCountryCodeText, "value", "Country Code");
				break;
			case "FaxAreaCode":
				value = customerPageElementvalidation(faxAreaCodeText_OR, "value", "Area Code");
				break;
			case "State/Prov":
				value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown", " state/Prov ");
				break;
			case "Country":
				//value = customerPageElementvalidation(countryDropdown, "countryDropdwon", " country Dropdwon");
				break;
			case "Zip/PostalCode":
				value = customerPageElementvalidation(zipPostalcodeText, "value", " zipPostalcode");
				break;
			case "SecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText, "value", " secondary Phone");
				break;
			case "Fax":
				value = customerPageElementvalidation(faxText, "value", " fax");
				break;
			case "ClinicTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown, "clinicTimeZoneDropdown"," clinicTimeZone ");
				break;
			case "TextMessage":
				value = customerPageElementvalidation(textMessageText, "value", " textMessage");
				break;
			case "LegalJurisdiction":
				value = customerPageElementvalidation(legalJurisdictionDropdown, "legalJurisdictionDropdown",
						" legal Jurisdiction Dropdown");
				break;
			case "Email":
				value = customerPageElementvalidation(emailText, "value", " email");
				break;
			case "MiddleName":
				value = customerPageElementvalidation(middlenameText, "value", "Middle name");
				break;
			case "LastName":
				value = customerPageElementvalidation(lastNameText, "value", "Last name");
				break;
			case "UserID":
				value = customerPageElementvalidation(userIDText, "value", "User ID");
				break;
			case "FirstName":
				value = customerPageElementvalidation(firstNameText, "value", "first Name");
				break;
			case "MainContactEmail":
				value = customerPageElementvalidation(mainEmailText, "value", "Main Email");
				break;

			case "Credentials":
				value = customerPageElementvalidation(credentialsText_OR, "value", "credentials");
				break;

			case "CustomerOnDemandCheckbox":
				value = customerPageElementvalidation(merlinOnDemandCheckbox_OR, "merlinOnDemandCheckbox",
						" merlin OnDemand Checkbox");
				break;
			case "CustomerTestClinic":
				customerPageElementvalidation(testClinicCheckbox_OR, "testClinicCheckbox", " test Clinic Checkbox");
				break;

			case "CustomerUnpaired":
				value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox", "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert Checkbox");
				break;
			case "CustomerSendTextMessage":
				value = customerPageElementvalidation(sendtextmessagesCheckbox, "sendtextmessagesCheckbox",
						"Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox, "sendvoicemessagesCheckbox",
						"SendvoicemessagesCheckbox");
				break;

			}

			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyCustomerProfileMandateData() throws Exception {
		loading();
		waitForPageLoad();
		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("CustomerName"), true, " CustomerName detail is Prepopulated");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("CustomerType"), true, "CustomerType detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("ClinicLocation"), true, "ClinicLocation detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("CountryCode"), true,"CountryCode detail is pre-populated. ");
		extentReport.reportScreenShot("Customer Profile Page prepopulated with data:Upper half Page");
		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("AreaCode"), true, "AreaCode detail is pre-populated. ");
		
		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("MainPhone"), true, "MainPhone detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("Country"), true, "Country detail is pre-populated. ");
		
		softAssert.assertEquals( verifyMandateCustomerDataInViewMode("Email"), true, "Email detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("ClinicTimeZone"), true, "Email detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("LegalJurisdiction"), true, "LegalJurisdiction detail is pre-populated. ");

		softAssert.assertEquals( verifyMandateCustomerDataInViewMode("UserID"), true, "UserID detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("FirstName"), true, "FirstName detail is pre-populated. ");

		softAssert.assertEquals(verifyMandateCustomerDataInViewMode("LastName"), true, "LastName detail is pre-populated. ");

		softAssert.assertEquals( verifyMandateCustomerDataInViewMode("MainContactEmail"), true, "MainContactEmail detail is pre-populated. ");

	}
	
	public String readCustomerDataInViewMode(String FieldName) throws Exception {
		String value = "";
		try {
			switch (FieldName) {
			case "CustomerName":
				value = customerPageElementvalidation(customerNameText_OR, "value", "Customer Name");
				break;
			case "CustomerType":
				value = customerPageElementvalidation(customerTypeText, "value", "Customer Type");
				break;
			case "ClinicLocation":
				value = customerPageElementvalidation(clinicLocationValue, "value", "Clinic Location");
				break;
			case "MainPhone":
				value = customerPageElementvalidation(mainPhoneText, "value", "Main Phone");
				break;
			case "CountryCode":
				value = customerPageElementvalidation(countryCodeText, "value", "Country Code");
				//customerPageElementvalidation(By locator, String locatorText, String Message,String extReportMsg)
				break;
			case "AreaCode":
				value = customerPageElementvalidation(areaCodeText, "value", "Area Code");
				break;
			case "Address1":
				value = customerPageElementvalidation(address1Text, "value", "address");
				break;
			case "Address2":
				value = customerPageElementvalidation(address2Text, "value", "address");
				break;
			case "Address3":
				value = customerPageElementvalidation(address3Text, "value", "address");
				break;
			case "City":
				value = customerPageElementvalidation(cityText, "value", " city");
				break;
			case "ClinicLanguage":
				value = customerPageElementvalidation(clinicLanguageDropdown, "clinicLanguageDropdown"," clinic Language Dropdown");
			case "FaxCountryCode":
				value = customerPageElementvalidation(faxCountryCodeText, "value", "Country Code");
				break;
			case "FaxAreaCode":
				value = customerPageElementvalidation(faxAreaCodeText_OR, "value", "Area Code");
				break;
			case "State/Prov":
				value = customerPageElementvalidation(stateProvDropdown, "stateProvDropdown", " state/Prov ");
				break;
			case "Country":
				//value = customerPageElementvalidation(countryDropdown, "countryDropdwon", " country Dropdwon");;
				break;
			case "Zip/PostalCode":
				value = customerPageElementvalidation(zipPostalcodeText, "value", " zipPostalcode");
				break;
			case "SecondaryPhone":
				value = customerPageElementvalidation(secondaryPhoneText, "value", " secondary Phone");
				break;
			case "Fax":
				value = customerPageElementvalidation(faxText, "value", " fax");
				break;
			case "ClinicTimeZone":
				value = customerPageElementvalidation(clinicTimeZoneDropdown, "value", "clinicTimeZone");

				break;
			case "TextMessage":
				value = customerPageElementvalidation(textMessageText, "value", " textMessage");
				break;
			case "LegalJurisdiction":
				value = customerPageElementvalidation(legalJurisdictionDropdown, "legalJurisdiction",
						" legal Jurisdiction Dropdown");
				break;
			case "Email":
				value = customerPageElementvalidation(emailText, "value", " email");
				break;
			case "MiddleName":
				value = customerPageElementvalidation(middlenameText, "value", "Middle name");
				break;
			case "LastName":
				value = customerPageElementvalidation(lastNameText, "value", "Middle name");
				break;
			case "UserID":
				value = customerPageElementvalidation(userIDText, "value", "User ID");
				break;
			case "FirstName":
				value = customerPageElementvalidation(firstNameText, "value", "first Name");
				break;
			case "MainContactEmail":
				value = customerPageElementvalidation(mainEmailText, "value", "Main Email");
				break;

			case "Credentials":
				value = customerPageElementvalidation(credentialsText_OR, "value", "credentials");
				break;

			case "CustomerOnDemandCheckbox":
				value = customerPageElementvalidation(merlinOnDemandCheckbox_OR, "merlinOnDemandCheckbox"," merlin OnDemand");

				break;
			case "CustomerTestClinic":
				customerPageElementvalidation(testClinicCheckbox_OR, "testClinicCheckbox", " test Clinic Checkbox");
				break;

			case "CustomerUnpaired":
				value = customerPageElementvalidation(unparredCheckbox, "unparredCheckbox", "unparred Checkbox");
				break;
			case "CustomerAlertCheckbox":
				value = customerPageElementvalidation(alertCheckbox, "alertCheckbox", " Alert Checkbox");
				break;
			case "CustomerSendTextMessage":
				value = customerPageElementvalidation(sendtextmessagesCheckbox, "sendtextmessagesCheckbox",
						"Send Text Message Chechbox");
				break;
			case "CustomerSendVoiceMessage":
				value = customerPageElementvalidation(sendvoicemessagesCheckbox, "sendvoicemessagesCheckbox",
						"SendvoicemessagesCheckbox");
				break;

			}

			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	public String verifyLogout() throws Exception {
		try {
			waitForLoading();
			presenceOfElementLocated(signOut);
			extentReport.reportScreenShot("Click Sign out Button");
			clickElement(signOut);
			return signOutMessageText;
		} catch (Exception e) {
			logger.info("Error occured in Logout page"+e.getMessage());
			extentReport.reportFail( "Error occured in Logout page");
			e.printStackTrace();
			throw e;
		}
	}

	//Poojitha
	//This method is to check whether AddSecondaryLocation button is clickable during view operation
	public void validateAddSecondaryLocationButtonClickable() throws Exception {

		if(visibilityOfElementLocatedWithReport(addSecondaryLocationButton_OR,addSecondaryLocationButton_S)) {
			waitForElementToBeClickable(addSecondaryLocationButton_OR,addSecondaryLocationButton_S);
		}
	}


	// This method is to check DirectAlertsTM Notification allowed for patients section is present under Clinic Feature control section
	public boolean validationDirectAlertsForPatientsAvailability() {
		boolean patientAlertsCheck = false;
		scrollToViewWithoutReport(clinicFeatureControlHeader_OR,clinicFeatureControlHeader_S);
		String fieldValue = getText(clinicFeatureControlHeader_OR,clinicFeatureControlHeader_S);
		scrollDown();
		if(fieldValue.equalsIgnoreCase("Clinic Feature Control"))
		{
			patientAlertsCheck = true;
		}
		return patientAlertsCheck;
	}


	//This method is to validate whether the fields are present or not
	public boolean validatePresenceOfField(String fieldName) throws Exception {
		boolean value = false;
		try {
			switch (fieldName) {
			case "CustomerName":
				value = isElementPresent(customerNameText_OR,customerNameText_S);
				break;
			case "CustomerType":
				value = isElementPresent(customerTypeDropdown_OR,customerTypeDropdown_S);
				break;
			case "ClinicLocation":
				value = isElementPresent(customerLocationText_OR,customerLocationText_S);
				break;
			case "MainPhone":
				value = isElementPresent(mainPhoneText_OR,mainPhoneText_S);
				break;
			case "CountryCode":
				value = isElementPresent(countryCodeText_OR,countryCodeText_S);
				break;
			case "AreaCode":
				value = isElementPresent(areaCodeText_OR,areaCodeText_S);
				break;
			case "Address1":
				value = isElementPresent(address1Text_OR,address1Text_S);
				break;
			case "Address2":
				value = isElementPresent(address2Text_OR,address2Text_S);
				break;
			case "Address3":
				value = isElementPresent(address3Text_OR,address3Text_S);
				break;
			case "City":
				value = isElementPresent(cityText_OR,cityText_S);
				break;
			case "ClinicLanguage":
				value = isElementPresent(clinicLanguageDropdown_OR,clinicLanguageDropdown_S);
				break;
			case "ClinicTimeZone":
				value = isElementPresent(clinicTimeZoneDropdown_OR,clinicTimeZoneDropdown_S);
				break;
			case "ClinicEmail":
				value = isElementPresent(emailText_OR,emailText_S);
				break;
			case "Country":
				value = isElementPresent(countryText_OR,countryText_S);
				break;
			case "Zip/PostalCode":
				value = isElementPresent(zipPostalcodeText_OR,zipPostalcodeText_S);
				break;
			case "LegalJurisdiction":
				value = isElementPresent(legalJurisdictionDropdown_OR,legalJurisdictionDropdown_S);
				break;
			case "ClinicMainContactEmail":
				value = isElementPresent(mainEmailText_OR,mainEmailText_S);
				break;
			case "StateProvinence":
				value = isElementPresent(stateProvDropdownField_OR,stateProvDropdownField_S);
				break;
			case "FaxCountryCode":
				value = isElementPresent(faxCountryCodeText_OR,faxCountryCodeText_S);
				break;
			case "SecondaryPhone":
				value = isElementPresent(secondaryPhoneText_OR,secondaryPhoneText_S);
				break;
			case "FaxText":
				value = isElementPresent(faxText_OR,faxText_S);
				break;
			case "UserId":
				value = isElementPresent(userIDText_OR,userIDText_S);
				break;
			case "FirstName":
				value = isElementPresent(firstNameText_OR,firstNameText_S);
				break;
			case "MiddleName":
				value = isElementPresent(middlenameText_OR,middlenameText_S);
				break;
			case "LastName":
				value = isElementPresent(lastNameText_OR,lastNameText_S);
				break;
			case "SendVoiceMessages":
				value = isElementPresent(sendvoicemessages_OR,sendvoicemessages_S);
				break;
			case "SendTextMessages":
				value = isElementPresent(sendtextmessages_OR,sendtextmessages_S);
				break;
			case "PatientDataCollectionConsent":
				value = isElementPresent(patientDataCollectionConsent_OR,patientDataCollectionConsent_S);
				break;
			case "MobileDirectAlerts":
				value = isElementPresent(mobileDirectAlerts_OR,mobileDirectAlerts_S);
				break;
			case "CommunicationCenter":
				value = isElementPresent(communicationCenter_OR,communicationCenter_S);
				break;
			case "ComplianceReport":
				value = isElementPresent(complianceReport_OR,complianceReport_S);
				break;
			case "ExportTransmission":
				value = isElementPresent(exportTransmission_OR,exportTransmission_S);
				break;
			case "OrderTransmitter":
				value = isElementPresent(orderTransmitter_OR,orderTransmitter_S);
				break;



			}



			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean verifyActivatorClinicCheckBox()
	{
		boolean checkBox = false;
		scrollToViewWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
		if(isSelectedWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S))
		checkBox = true;
		return checkBox;
	}
	
	// This method is to validate whether the fields are editable or not
		public boolean validateEditableFields(String fieldName) throws Exception {
			boolean enabledFieldValue = false;
			try {
				switch (fieldName) {
				case "ActivatorClinicCheckBox":
					enabledFieldValue = isEnabledWithoutReport(activatorClinicCheckbox_OR,activatorClinicCheckbox_S);
					break;
				}
				return enabledFieldValue;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}

	//ends here
	//Poojitha - Updated Override method as per new standards - Date: 28th Dec 2021
	@Override
	public boolean verifyLandingPage() {
		Boolean customerProfilePageCheck=false;
		if(isElementPresentwithoutException(customerHeadquarterText_OR,customerHeadquarterText_S)) {
			customerProfilePageCheck=true;
			extentReport.reportScreenShot("Customer Profile page is displayed");
		}
		return customerProfilePageCheck;
	}
	//Shafiya added the below xpaths and validateFields() code
	private final By customerNameLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Customer_name']");
	private final String customerNameLabel_S = "Customer Name Label";
	private final By customerTypeLabel_OR = By.xpath("//mat-label[@id='lbl_customer-head-quarters_customerTypeCd']");
	private final String customerTypeLabel_S = "Customer Type Label";

	private final By clinicLocationLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Clinic_Location']");
	private final String clinicLocationLabel_S = "Clinic Location Label";
	private final By address1Label_OR = By.xpath("//mat-label[@id='merlin_textbox_Address_1']");
	private final String address1Label_S = "Adress1 Label";
	private final By address2Label_OR = By.xpath("//mat-label[@id='merlin_textbox_Address_2']");
	private final String address2Label_S = "Adress2 Label";
	private final By address3Label_OR = By.xpath("//mat-label[@id='merlin_textbox_Address_3']");
	private final String address3Label_S = "Adress3 Label";
	private final By cityLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_City']");
	private final String cityLabel_S = "City Label";
	private final By stateOrProvinceLabel_OR = By.xpath("//mat-label[@id='lbl_customer-clinicinfo_stateCd']");
	private final String stateOrProvinceLabel_S = "State/Province Label";
	private final By countryLabel_OR = By.xpath("//mat-label[@id='lbl_customer-clinicinfo_countryCd']");
	private final String countryLabel_S = "Country Label";
	private final By zipOrpostalCodeLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Zip/Postal_Code']");
	private final String zipOrpostalCodeLabel_S = "Zip/Postal Code Label";
	private final By countryCodeLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Country_Code'])[1]");
	private final String countryCodeLabel_S = "Country Code Label";
	private final By areaCodeLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Area_Code'])[1]");
	private final String areaCodeLabel_S = "Area Code Label";
	private final By mainPhoneLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Main_Phone']");
	private final String mainPhoneLabel_S = "Main Phone Label";
	private final By secondaryCountryCodeLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Country_Code'])[2]");
	private final String secondaryCountryCodeLabel_S = "Secondary Country Code Label";
	private final By secondaryAreaCodeLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Area_Code'])[2]");
	private final String secondaryAreaCodeLabel_S = "Secondary Area Code Label";
	private final By secondaryPhoneLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Secondary_Phone']");
	private final String secondaryPhoneLabel_S = "Secondary Phone Label";	
	private final By faxCountryCodeLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Country_Code'])[3]");
	private final String faxCountryCodeLabel_S = "Fax Country Code Label";
	private final By faxAreaCodeLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Area_Code'])[3]");
	private final String faxAreaCodeLabel_S = "Fax Area Code Label";
	private final By faxLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Fax']");
	private final String faxLabel_S = "Fax Label";
	private final By textMessageLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Text_Message']");
	private final String textMessageLabel_S = "Text Message Label";
	private final By email_OR = By.xpath("(//mat-label[@id='merlin_textbox_Email'])[1]");
	private final String email_S = "Email Label";
	private final By clinicTimeZoneLabel_OR = By.xpath("//mat-label[@id='lbl_customer-clinicinfo_timeZoneCd']");
	private final String clinicTimeZoneLabel_S = "Clinic TimeZone Label";
	private final By legalJurisdictionLabel_OR = By.xpath("//mat-label[@id='lbl_customer-clinicinfo_legaJurisdictionCd']");
	private final String legalJurisdictionLabel_S = "LegalJurisdiction Label";
	private final By clinicLanguageLabel_OR = By.xpath("//mat-label[@id='lbl_customer-clinicinfo_localeCd']");
	private final String clinicLanguageLabel_S = "Clinic Language Label";

	private final By userIDLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_User_ID']");
	private final String userIDLabel_S = "UserID Label";
	private final By firstNameLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_First_Name']");
	private final String firstNameLabel_S = "First Name Label";
	private final By middleNameLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Middle_Name']");
	private final String middleNameLabel_S = "Middle Name Label";
	private final By lastNameLabel_OR = By.xpath("//mat-label[@id='merlin_textbox_Last_Name']");
	private final String lastNameLabel_S = "Last Name Label";
	private final By credentialsLabel_OR = By.xpath("//mat-label[@id='lbl_customer-clinic-main-contact_credentialsCd']");
	private final String credentialsLabel_S = "Credentials Label";
	private final By clinicMainEmailLabel_OR = By.xpath("(//mat-label[@id='merlin_textbox_Email'])[2]");
	private final String clinicMainEmailLabel_S = "Clinic Main Contact Email Label";
	private final By AllowedApplications_OR = By.xpath("//merlin-bucket-list[@id='bls_customer-feature-control_allowedAppCodeIds']/div");
	private final String AllowedApplications_S = "Allowed Applications in Clinic Feature Control";		

	//This method is to validate whether the field labels are present or not
	public boolean validateFields(String fieldName) throws Exception {
		boolean value = false;
		try {
			switch (fieldName) {
			//Customer HeadQuarters Section
			case "CustomerName":
				value = isElementPresent(customerNameLabel_OR,customerNameLabel_S);
				break;
			case "CustomerType":
				value = isElementPresent(customerTypeLabel_OR,customerTypeLabel_S);
				break;
				//Clinic Information Section
			case "ClinicLocation":
				value = isElementPresent(clinicLocationLabel_OR,clinicLocationLabel_S);
				break;
			case "Address1":
				value = isElementPresent(address1Label_OR,address1Label_S);
				break;
			case "Address2":
				value = isElementPresent(address2Label_OR,address2Label_S);
				break;
			case "Address3":
				value = isElementPresent(address3Label_OR,address3Label_S);
				break;
			case "City":
				value = isElementPresent(cityLabel_OR,cityLabel_S);
				break;
			case "StateProvinence":
				value = isElementPresent(stateOrProvinceLabel_OR,stateOrProvinceLabel_S);
				break;
			case "Country":
				value = isElementPresent(countryLabel_OR,countryLabel_S);
				break;
			case "Zip/PostalCode":
				value = isElementPresent(zipOrpostalCodeLabel_OR,zipOrpostalCodeLabel_S);
				break;
			case "MainPhone":
				value = isElementPresent(mainPhoneLabel_OR,mainPhoneLabel_S);
				break;
			case "CountryCode":
				value = isElementPresent(countryCodeLabel_OR,countryCodeLabel_S);
				break;
			case "AreaCode":
				value = isElementPresent(areaCodeLabel_OR,areaCodeLabel_S);
				break;
			case "SecondaryCountryCode":
				value = isElementPresent(secondaryCountryCodeLabel_OR,secondaryCountryCodeLabel_S);
				break;
			case "SecondaryAreaCode":
				value = isElementPresent(secondaryAreaCodeLabel_OR,secondaryAreaCodeLabel_S);
				break;
			case "SecondaryPhone":
				value = isElementPresent(secondaryPhoneLabel_OR,secondaryPhoneLabel_S);
				break;
			case "FaxCountryCode":
				value = isElementPresent(faxCountryCodeLabel_OR,faxCountryCodeLabel_S);
				break;
			case "FaxAreaCode":
				value = isElementPresent(faxAreaCodeLabel_OR,faxAreaCodeLabel_S);
				break;
			case "Fax":
				value = isElementPresent(faxLabel_OR,faxLabel_S);
				break;					
			case "TextMesssage":
				value = isElementPresent(textMessageLabel_OR,textMessageLabel_S);
				break;
			case "Email":
				value = isElementPresent(email_OR,email_S);
				break;
			case "ClinicTimeZone":
				value = isElementPresent(clinicTimeZoneLabel_OR,clinicTimeZoneLabel_S);
				break;
			case "LegalJurisdiction":
				value = isElementPresent(legalJurisdictionLabel_OR,legalJurisdictionLabel_S);
				break;
			case "ClinicLanguage":
				value = isElementPresent(clinicLanguageLabel_OR,clinicLanguageLabel_S);
				break;
				//Clinic Main Contact Section
			case "UserId":
				value = isElementPresent(userIDLabel_OR,userIDLabel_S);
				break;
			case "FirstName":
				value = isElementPresent(firstNameLabel_OR,firstNameLabel_S);
				break;
			case "MiddleName":
				value = isElementPresent(middleNameLabel_OR,middleNameLabel_S);
				break;
			case "LastName":
				value = isElementPresent(lastNameLabel_OR,lastNameLabel_S);
				break;
			case "Credentials":
				value = isElementPresent(credentialsLabel_OR,credentialsLabel_S);
				break;
			case "ClinicMainContactEmail":
				value = isElementPresent(clinicMainEmailLabel_OR,clinicMainEmailLabel_S);
				break;				
				//Clinic Feature Control section
			case "AllowedApplications":
				value = isElementPresent(AllowedApplications_OR,AllowedApplications_S);
				break;
				//General Features
			case "PatientDataCollectionConsent":
				value = isElementPresent(patientDataCollectionConsent_OR,patientDataCollectionConsent_S);
				break;
			case "MobileDirectAlerts":
				value = isElementPresent(mobileDirectAlerts_OR,mobileDirectAlerts_S);
				break;
				//Allow Direct Call Features section
			case "SendVoiceMessages":
				value = isElementPresent(sendvoicemessages_OR,sendvoicemessages_S);
				break;
			case "SendTextMessages":
				value = isElementPresent(sendtextmessages_OR,sendtextmessages_S);
				break;				
				//ElectroPhysiology Features
			case "ExportTransmission":
				value = isElementPresent(exportTransmission_OR,exportTransmission_S);
				break;
			case "OrderTransmitter":
				value = isElementPresent(orderTransmitter_OR,orderTransmitter_S);
				break;

			case "CommunicationCenter":
				value = isElementPresent(communicationCenter_OR,communicationCenter_S);
				break;
			case "ComplianceReport":
				value = isElementPresent(complianceReport_OR,complianceReport_S);
				break;
			}
			return value;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	//*******shafiya ******


}



