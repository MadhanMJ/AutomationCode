package com.test.qa.ui.pageObjects.ViewProfile;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static com.test.qa.utilities.CommonUtils.extentTest;

public class ViewProfile extends BasePage {

	/*
	 * AUTHOR: Alok Kumar
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public ViewProfile(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	private final By UserProfile_OR = By.xpath("//div[@id='my-account']/div[1]/div[1]/div[1]");
	private final String UserProfile_S = "User Profile";
	private final By Edit_Button_OR = By.xpath("//button[@id='myAccountEdit']");
	private final String Edit_Button_S = "Edit Button";
	private final By Save_Button_OR = By.xpath("//button[@id='myAccountSave']");
	private final String Save_Button_S = "Save Button";
	private final By Cancel_Button_OR = By.xpath("//button[@id='myAccountCancel']");
	private final String Cancel_Button_S = "Cancel Button";
	private final By FirstName_TextField_OR = By.xpath("//input[@id='firstName_firstName']");
	private final String FirstName_TextField_S = "FirstName_TextField" ;
	private final By MiddleName_TextField_OR = By.xpath("//input[@id='middleName_middleName']");
	private final String MiddleName_TextField_S = "MiddleName_TextField" ;
	private final By LastName_TextField_OR = By.xpath("//input[@id='lastName_lastName']");
	private final String LastName_TextField_S = "LastName_TextField" ;
	private final By Credential_TextField_OR = By.xpath("//input[@id='credentials_credentialsCd']");
	private final String Credential_TextField_S = "Credential_TextField";
	private final By UserType_TextField_OR = By.xpath("//input[@id='individualType_individualTypeCd']");
	private final String UserType_TextField_S = "UserType_TextField";
	private final By Department_TextField_OR = By.xpath("//input[@id='department_departmentCd']");
	private final String Department_TextField_S = "Department_TextField";
	private final By Administrator_checkbox_OR = By.xpath("//input[@id='administratorFlg-input']");
	private final String Administrator_checkbox_S = "Administrator_checkbox";
	private final By Communication_checkbox_OR = By.xpath("//input[@id='commCenterFlg-input']");
	private final String Communication_checkbox_S = "Communication_checkbox";
	private final By Address1_Textbox_OR = By.xpath("//input[@id='address1_address']");
	private final String Address1_Text_S = "Address1_Textbox";
	private final By Address2_Textbox_OR = By.xpath("//input[@id='address2_address2']");
	private final String Address2_Text_S = "Address2_Textbox";
	private final By Address3_Textbox_OR = By.xpath("//input[@id='address3_address3']");
	private final String Address3_Text_S = "Address3_Textbox";
	private final By PhoneNumber_Textbox_OR = By.xpath("//input[@id='mainPhoneNum_phoneNum']");
	private final String PhoneNumber_Text_S = "PhoneNumberTextbox";
	private final By PhoneNumberAreaCode_Textbox_OR = By.xpath("//input[@id='mainAreaCode_areaCode']");
	private final String PhoneNumberAreaCode_Textbox_S = "Phone Number Textbox";
	private final By PhoneNumberCountryCode_Textbox_OR = By.xpath("//input[@id='maincountryCode_countryCode']");
	private final String PhoneNumberCountryCode_Textbox_S = "Phone Number Textbox";
	private final By SecondryPhoneNumber_Textbox_OR = By.xpath("//input[@id='secPhoneNum_phoneNum']");
	private final String SecondryPhoneNumber_Text_S = "Secondry Phone Number Textbox";
	private final By SecondryPhoneNumberAreaCode_Textbox_OR = By.xpath("//input[@id='secAreaCode_areaCode']");
	private final String SecondryPhoneNumberAreaCode_Textbox_S = "Phone Number Textbox";
	private final By SecondryPhoneNumberCountryCode_Textbox_OR = By.xpath("//input[@id='secCountryCode_countryCode']");
	private final String SecondryPhoneNumberCountryCode_Textbox_S = "Phone Number Textbox";
	private final By FaxNumber_Textbox_OR = By.xpath("//input[@id='faxPhoneNum_phoneNum']");
	private final String FaxNumber_Textbox_S = "Secondry Phone Number Textbox";
	private final By FaxNumberAreaCode_Textbox_OR = By.xpath("//input[@id='faxAreaCode_areaCode']");
	private final String FaxNumberAreaCode_Textbox_S = "Secondry Phone Number Textbox";
	private final By FaxNumberCountryCode_Textbox_OR = By.xpath("//input[@id='faxCountryCode_countryCode']");
	private final String FaxNumberCountryCode_Textbox_S = "SecondryPhoneNumber Textbox";
	private final By SecurityStamp_Textbox_OR = By.xpath("//input[@id='securityStamp_securityStamp']");
	private final String SecurityStamp_Textbox_S = "Security stamp";
	private final By Email_Textbox_OR = By.xpath("//input[@id='textMessage_textMessageId']");
	private final String Email_Textbox_S = "SecondryPhoneNumber Textbox";
	private final By Message_Textbox_OR = By.xpath("//input[@id='textMessage_textMessageId']");
	private final String Message_Textbox_S = "Message Textbox";
	private final By State_Textbox_OR = By.xpath("//mat-select[@id='stateCd']");
	private final String State_Textbox_S = "State Textbox";
	private final By City_Textbox_OR = By.xpath("//input[@id='city_city']");
	private final String City_Textbox_S = "City Textbox";
	private final By ZipCode_Textbox_OR = By.xpath("//input[@id='postalCode_zipCode']");
	private final String ZipCode_Textbox_S = "Zip Code Textbox";
	private final By Country_List_OR = By.xpath("//mat-select[@id='countryCd']");
	private final String Country_List_S = "Country_List";
	private final By StateProv_List_OR = By.xpath("//mat-select[@id='stateCd']");
	private final String StateProv_S = "State/Prov";
	private final By Hour_List_OR = By.xpath("//mat-select[@id='afterHoursContact']");
	private final String Hour_S = "Hours";
	private final By Alert_RadioButton_OR = By.xpath("//mat-radio-button[@id='AL']/label/div[1]");
	private final String Alert_RadioButton_S = "Alert_RadioButton";
	private final By Clinic_RadioButton_OR = By.xpath("//mat-radio-button[@id='CL']/label/div[1]");
	private final String Clinic_RadioButton_S = "Clinic_RadioButton";
	private final By PatientName_RadioButton_OR = By.xpath("//mat-radio-button[@id='PN']/label/div[1]");
	private final String PatientName_RadioButton_S = "Patient Name_RadioButton";
	private final By Transmissiontimeanddate_RadioButton_OR = By.xpath("//mat-radio-button[@id='TD']/label/div[1]");
	private final String Transmissiontimeanddate_RadioButton_S = "Transmission time and date_RadioButton";
	private final By Dynamicprescription_RadioButton_OR = By.xpath("//mat-radio-button[@id='RX']/label/div[1]");
	private final String Dynamicprescription_RadioButton_S = "Dynamic prescription_RadioButton";
	private final By Electrophysiology_RadioButton_OR = By.xpath("//mat-radio-button[@id='EP']/label/div[1]");
	private final String  Electrophysiology_RadioButton_S = " Electro physiology_RadioButton";
	private final By HeartFailure_RadioButton_OR = By.xpath("//mat-radio-button[@id='HF']/label/div[1]");
	private final String   HeartFailure_RadioButton_S = "  Heart Failure_RadioButton";
	private final By Error_Message_OR = By.xpath("//div[contains(text(),' Main phone number' )]");
	private final String   Error_Message_S = "Main phone number provided is invalid format, please enter in correct format and proceed";
	private final By Success_Message_OR = By.xpath("//div[contains(text(),' Main phone number' )]");
	private final String   Success_Message_S = "Updated My Account!!";
	private final By changePassword_link_OR=By.xpath("//button[@id='btn_my-account_change-password']");
	private final String   changePassword_link_S = "Change-password";
	private final By changePassword_Header_OR=By.xpath("//div[@id='page-title2']");
	private final String   changePassword_Header_S = "Change-Password header";
	private final By changePassword_CurrentPassword_OR=By.xpath("//div[@id='page-title2']");
	private final String   changePassword_CurrentPassword_S = "Change-Password header";
	private final By changePassword_Password_OR=By.xpath("//div[@id='page-title2']");
	private final String   changePassword_Password_S = "Change-Password header";
	private final By changePassword_ReConfirmPassword_OR=By.xpath("//div[@id='page-title2']");
	private final String   changePassword_ReConfirmPassword_S = "Change-Password header";
	
	
	// Each page class should have this overridden method of Verify Landing page

	@Override
	public boolean verifyLandingPage() {
		
	Boolean viewProfile = false;
	if(isElementPresentwithoutException(UserProfile_OR, UserProfile_S))
	{
		viewProfile = true;
	
	}return viewProfile;
	
	}
	
	public boolean verifyChangePasswordPage() {
		
		Boolean changePassword = false;
		if(isElementPresentwithoutException(changePassword_Header_OR, changePassword_Header_S))
		{
			changePassword = true;
		
		}return changePassword;
		
		}
	
	public void checkPageInViewMode()  {
		
		String pageViewMode = "";
       try {
			if (isDisplayed(FirstName_TextField_OR) && isDisplayed(MiddleName_TextField_OR)
				&& isDisplayed(LastName_TextField_OR) && isDisplayed(Credential_TextField_OR)
				&& isDisplayed(UserType_TextField_OR) && isDisplayed(Department_TextField_OR)
				&& isDisplayed(Administrator_checkbox_OR) && isDisplayed(Communication_checkbox_OR)
				&& isDisplayed(Address1_Textbox_OR) && isDisplayed(Address2_Textbox_OR)
				&& isDisplayed(Address3_Textbox_OR) && isDisplayed(PhoneNumber_Textbox_OR)
				&& isDisplayed(SecondryPhoneNumber_Textbox_OR) && isDisplayed(Email_Textbox_OR)
				&& isDisplayed(Message_Textbox_OR) 
				&& isDisplayed(City_Textbox_OR) && isDisplayed(ZipCode_Textbox_OR)
				&& isDisplayed(Country_List_OR) && isDisplayed(StateProv_List_OR)
				&& isDisplayed(Hour_List_OR) && isDisplayed(Alert_RadioButton_OR)
				&& isDisplayed(Clinic_RadioButton_OR) && isDisplayed(PatientName_RadioButton_OR)
				&& isDisplayed(Transmissiontimeanddate_RadioButton_OR) && isDisplayed(Dynamicprescription_RadioButton_OR)
				&& isDisplayed(Electrophysiology_RadioButton_OR) && isDisplayed(HeartFailure_RadioButton_OR)
				&& (!isEnabled(FirstName_TextField_OR)) && (!isEnabled(MiddleName_TextField_OR))
				&& (!isEnabled(LastName_TextField_OR)) && (!isEnabled(Credential_TextField_OR))
				&& (!isEnabled(UserType_TextField_OR)) && (!isEnabled(Department_TextField_OR))
				&& (!isEnabled(Administrator_checkbox_OR)) && (!isEnabled(Communication_checkbox_OR))
				&& (!isEnabled(Address1_Textbox_OR)) && (!isEnabled(Address2_Textbox_OR))
				&& (!isEnabled(Address3_Textbox_OR)) && (!isEnabled(PhoneNumber_Textbox_OR))
				&& (!isEnabled(SecondryPhoneNumber_Textbox_OR)) && (!isEnabled(Email_Textbox_OR))
				&& (!isEnabled(Message_Textbox_OR)) 
				&& (!isEnabled(City_Textbox_OR)) && (!isEnabled(ZipCode_Textbox_OR))
				&& (!isEnabled(Country_List_OR)) && (!isEnabled(StateProv_List_OR))
				&& (!isEnabled(Hour_List_OR)) && (!isEnabled(Alert_RadioButton_OR))
				&& (!isEnabled(Clinic_RadioButton_OR)) && (!isEnabled(PatientName_RadioButton_OR))
				&& (!isEnabled(Transmissiontimeanddate_RadioButton_OR)) && (!isEnabled(Dynamicprescription_RadioButton_OR))
				&& (!isEnabled(Electrophysiology_RadioButton_OR)) && (!isEnabled(HeartFailure_RadioButton_OR))) {
			pageViewMode = "Page is in view mode";
			extentReport.reportScreenShot("Page is in view mode");
		} else {
			pageViewMode = "Page is NOT in view mode";
			extentReport.reportScreenShot("Page is NOT in view mode");
		}

		return;
       }catch(NullPointerException e)  
		{ 
            System.out.print("Caught NullPointerException"); 
        } 
	}
	
	public  void clickOnEdit() throws Exception
	{ 
		try 
		{
			scrollToView(Edit_Button_OR);
			presenceOfElementLocated(Edit_Button_OR);
			clickElement(Edit_Button_OR);
			extentReport.reportScreenShot( "User clicked on change utton in view Customer Page");
			
			
		}
		catch(Exception e)
		{
			extentReport.fail( "User not able to click on edit button ");
		}
		
	}
	
	public  void clickOnChangePassword() throws Exception
	{ 
		try 
		{
			scrollToView(changePassword_link_OR);
			presenceOfElementLocated(changePassword_link_OR);
			clickElement(changePassword_link_OR);
			extentReport.reportScreenShot( "User clicked on change password in customer profile Page");
			
			
		}
		catch(Exception e)
		{
			extentReport.fail( "User not able to click on change password in customer profile Page ");
		}
		
	}
	
	public  void changePassword(String currPassword,String password, String confirmPassword) throws Exception
	{ 
		try 
		{                                                                                                      
			scrollToView(changePassword_CurrentPassword_OR);
			deleteContent(changePassword_CurrentPassword_OR);
			sendKeys(changePassword_CurrentPassword_OR,currPassword);
			sendKeys(changePassword_Password_OR,password);
			sendKeys(changePassword_ReConfirmPassword_OR,confirmPassword);
			driver.findElement(changePassword_ReConfirmPassword_OR).sendKeys(Keys.ENTER);
			extentReport.pass( " User able to change password ");
			extentReport.pass( " User able to change password ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to change password ");
		}
		return ;
	}
	
	public void VerifyingField(String FieldName) throws Exception {
		String pageViewMode ;
		Boolean value = false;
		try {
			
			switch (FieldName) {
			
			case "FirstName_TextField":
				if(!isEnabled(FirstName_TextField_OR))
				  {
				  
				   extentReport.pass(" User Profile - FirstName  is Not Enabled ");
				  }
				  else
				  {
				   
				   extentReport.reportFail(" User Profile - FirstName  is Enabled");
				  }
				break;
			
			case "MiddleName_TextField":
				if(!isEnabled(MiddleName_TextField_OR))
				  {
				   pageViewMode = "Page is NOT in view mode";
				   extentReport.pass(" User Profile - MiddleName is Not Enabled");
				  }
				  else
				  {
				   extentReport.reportFail(" User Profile - MiddleName  is Enabled");
				  }break;
				
			case "LastName_TextField": 
				if(!isEnabled(LastName_TextField_OR))
				  {
				   pageViewMode = "Page is NOT in view mode";
				   extentReport.pass(" User Profile - LastName is Not Enabled");
				  }
				  else
				  {
				   extentReport.reportFail(" User Profile - LastName  is Enabled");
				  }break;
				
			case "Credential_TextField": 
				if(!isEnabled(Credential_TextField_OR))
				  {
				   pageViewMode = "Page is NOT in view mode";
				   extentReport.pass(" User Profile - Credential  is Not Enabled");
				  }
				  else
				  {
				   extentReport.reportFail(" User Profile - Credential is Enabled");
				  }
				break; 
				
			case "UserType_TextField":
				if(!isEnabled(UserType_TextField_OR))
				  {
				   pageViewMode = "Page is NOT in view mode";
				   extentReport.pass(" User Profile - UserType is Not Enabled");
				  }
				  else
				  {
				   extentReport.reportFail(" User Profile - UserType  is Enabled");
				  }
			   break; 
			 	
			case  "Department_TextField":
				if(!isEnabled(Department_TextField_OR))
				  {
				   pageViewMode = "Page is NOT in view mode";
				   extentReport.pass(" User Profile - Department is Not Enabled");
				  }
				  else
				  {
				   extentReport.reportFail(" User Profile - Department  is Enabled");
				  }
			   break;
			  	
			case "Administrator_checkbox_OR": 
				if(!isEnabled(Department_TextField_OR))
				  {
				   pageViewMode = "Page is NOT in view mode";
				   extentReport.pass(" User Profile - Administrator is Not Enabled");
				  }
				  else
				  {
				   extentReport.reportFail(" User Profile - Administrator is Enabled");
				  }
			    break;
				
			}
			extentReport.reportScreenShot("User Profile is Not Enabled");
		
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public  void clearPrimaryPhoneNumber() throws Exception
	{ 
		try 
		{
			scrollToView(PhoneNumber_Textbox_OR);
			deleteContent(PhoneNumber_Textbox_OR);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to clear Primary Phone number");
			
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear Primary Phone number ");
		}
	}
	
	public  void clearEmailAddress() throws Exception
	{ 
		try 
		{
			scrollToView(Email_Textbox_OR);
			deleteContent(Email_Textbox_OR);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to clear Email address");
			
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear Email address ");
		}
	}
	
	public  void clearStamp() throws Exception
	{ 
		try 
		{
			scrollToView(SecurityStamp_Textbox_OR);
			deleteContent(SecurityStamp_Textbox_OR);
			clickOnElementUsingActions(Address1_Textbox_OR);
			extentReport.pass( "User able to clear Security stamp");
			
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear  Security stamp ");
		}
	}
	
	public  void clearCity() throws Exception
	{ 
		try 
		{
			scrollToView(City_Textbox_OR);
			deleteContent(City_Textbox_OR);
			clickOnElementUsingActions(Address1_Textbox_OR);
			extentReport.pass( "User able to clear Security stamp");
			
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear  Security stamp ");
		}
	}
	
	public  String updatingAddress1(String address) throws Exception
	{ 
		try 
		{                                                                                                      
			scrollToView(Address1_Textbox_OR);
			deleteContent(Address1_Textbox_OR);
			sendKeys(Address1_Textbox_OR,address);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to clear address1");
			extentReport.pass( "User able to enter address1 ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear address ");
		}
		return address;
	}
	
	public  String updatingAddress2(String address) throws Exception
	{ 
		try 
		{
			scrollToView(Address2_Textbox_OR);
			deleteContent(Address2_Textbox_OR);
			sendKeys(Address1_Textbox_OR,address);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to clear address2");
			extentReport.pass( "User able to enter address2 ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear address ");
		}
		return address;
	}
	
	public  String updatingAddress3(String address) throws Exception
	{ 
		try 
		{
			scrollToView(Address3_Textbox_OR);
			deleteContent(Address3_Textbox_OR);
			sendKeys(Address1_Textbox_OR,address);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to clear address3");
			extentReport.pass( "User able to enter address3 ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear address ");
		}
		return address;
	}
	
	public  String updatingCity(String city) throws Exception
	{ 
		try 
		{
			scrollToView(City_Textbox_OR);
			deleteContent(City_Textbox_OR);
			sendKeys(City_Textbox_OR,city);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to clear address3");
			extentReport.pass( "User able to enter address3 ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to clear address ");
		}
		return city;
	}
	
	public  String updatingEmail(String email) throws Exception
	{ 
		try 
		{
			scrollToView(Email_Textbox_OR);
			deleteContent(Email_Textbox_OR);
			sendKeys(Email_Textbox_OR,email);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter Email address  ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter Email address ");
		}
		return email;
	}
	
	public  String updatingTextMessage(String message) throws Exception
	{ 
		try 
		{
			scrollToView(Message_Textbox_OR);
			deleteContent(Message_Textbox_OR);
			sendKeys(Message_Textbox_OR,message);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter text messages ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter text messages ");
		}
		return message;
	}
	
	public  String updatingSecurityStamp(String securityStamp) throws Exception
	{ 
		try 
		{
			scrollToView(SecurityStamp_Textbox_OR);
			deleteContent(SecurityStamp_Textbox_OR);
			sendKeys(SecurityStamp_Textbox_OR,securityStamp);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter Security Message ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter Security Message ");
		}
		return securityStamp;
	}
	
	
	public  void updatingFaxNumber(String faxNumber,String areaCode,String countryCode) throws Exception
	{ 
		try 
		{
			scrollToView(FaxNumber_Textbox_OR);
			deleteContent(FaxNumber_Textbox_OR);
			sendKeys(FaxNumber_Textbox_OR,faxNumber);
			deleteContent(FaxNumberAreaCode_Textbox_OR);
			sendKeys(FaxNumberAreaCode_Textbox_OR,areaCode);
			deleteContent(FaxNumberCountryCode_Textbox_OR);
			sendKeys(FaxNumberCountryCode_Textbox_OR,countryCode);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter Fax Number  ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter Fax Number ");
		}
		return ;
	}
	
	public  void updatingPhoneNumber(String phoneNumber,String areaCode,String countryCode) throws Exception
	{ 
		try 
		{
			scrollToView(PhoneNumber_Textbox_OR);
			deleteContent(PhoneNumber_Textbox_OR);
			sendKeys(PhoneNumber_Textbox_OR,phoneNumber);
			deleteContent(PhoneNumberAreaCode_Textbox_OR);
			sendKeys(PhoneNumberAreaCode_Textbox_OR,areaCode);
			deleteContent(PhoneNumberCountryCode_Textbox_OR);
			sendKeys(PhoneNumberCountryCode_Textbox_OR,countryCode);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter Email address  ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter Email address ");
		}
		return ;
	}
	
	public  void updatingSecPhoneNumber(String phoneNumber,String areaCode,String countryCode) throws Exception
	{ 
		try 
		{
			scrollToView(SecondryPhoneNumber_Textbox_OR);
			deleteContent(SecondryPhoneNumber_Textbox_OR);
			sendKeys(SecondryPhoneNumber_Textbox_OR,phoneNumber);
			deleteContent(SecondryPhoneNumberAreaCode_Textbox_OR);
			sendKeys(SecondryPhoneNumberAreaCode_Textbox_OR,areaCode);
			deleteContent(SecondryPhoneNumberCountryCode_Textbox_OR);
			sendKeys(SecondryPhoneNumberCountryCode_Textbox_OR,countryCode);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter  sec phone number with area code and country code  ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter sec phone number with area code and country code ");
		}
		return ;
	}
	
	public  void checkingCharacterLengthOfAddress() throws Exception
	{ 
		try 
		{
			scrollToView(Address1_Textbox_OR);
			String text;
			text = getText(Address1_Textbox_OR);
			int length = text.length();
			if(length == 100)
			{
			extentReport.reportScreenShot( " system does not allow to enter more than 100 characters ");
			extentReport.pass( " System does not allow to enter more than 100 characters in address ");
			}else
			{
				extentReport.fail( " system allow to enter more than 100 characters ");
			}
		}	
		catch(Exception e)
		{
			extentReport.fail( " system allow to enter more than 100 characters ");
		}
		
	}
	
	public  void verifyingAddressUpdated(String address) throws Exception
	{ 
		try 
		{
			scrollToView(Address1_Textbox_OR);
			String text;
			text = getText(Address1_Textbox_OR);
			
			if(address.equals(text))
			{
			extentReport.reportScreenShot("Address updated");
			extentReport.pass("Address updated");
			}else
			{
				extentReport.fail( " Address not updated ");
			}
		}	
		catch(Exception e)
		{
			extentReport.fail(" system not able to update address ");
		}
		
	}
	
	public  void verifyingCityUpdated(String city) throws Exception
	{ 
		try 
		{
			scrollToView(City_Textbox_OR);
			String text;
			text = getText(City_Textbox_OR);
			
			if(city.equals(text))
			{
			extentReport.reportScreenShot( "City detail updated");
			extentReport.pass( "City detail updated");
			}else
			{
				extentReport.fail( " City detail not updated ");
			}
		}	
		catch(Exception e)
		{
			extentReport.fail( " system not able to update address  ");
		}
		
	}
	
	public  void checkingCharacterlengthOfCity() throws Exception
	{ 
		try 
		{
			scrollToView(City_Textbox_OR);
			String text;
			text = getText(City_Textbox_OR);
			int length = text.length();
			if(length == 30)
			{
			extentReport.reportScreenShot( "system does not allow to enter more than 30 characters");
			extentReport.pass( "User able to enter address ");
			}else
			{
				extentReport.fail( " system able to enter more than 30 characters ");
			}
		}	
		catch(Exception e)
		{
			extentReport.fail( " system does not allow to enter more than 30 characters ");
		}
		
	}
	
	public  void clickOnSave() throws Exception
	{ 
		try 
		{
			scrollToView(Save_Button_OR);
			clickOnElementUsingActions(Save_Button_OR);
			extentReport.pass( "User able to Save the changes");
			
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to Save the changes ");
		}
	}
	
	public  void VerifyMessage() 
	{ 
		try 
		{
		
		String actual;
		actual = getText(Error_Message_OR);
		System.out.print(actual);
		if(actual.equals(Error_Message_S))
		{
			extentReport.pass("Expected error displayed");
			extentReport.reportScreenShot("Expected error displayed");
		}
		else {
			extentReport.fail("Expected error not displayed");
			extentReport.reportScreenShot( " Expected error not displayed ");
		}
		}
		catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}clickOnElementUsingActions(Error_Message_OR);
	}
	
	public  void VerifySuccessMsg() 
	{ 
		try 
		{
		
		String actual;
		actual = getText(Success_Message_OR);
		System.out.print(actual);
		if(actual.equals(Success_Message_S))
		{
			extentReport.pass(" Successful message displayed");
			extentReport.reportScreenShot("Successful message displayed");
		}
		else {
			extentReport.fail(" Successful message displayed ");
			extentReport.reportScreenShot( " Successful message not displayed ");
		}
		}
		catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}clickOnElementUsingActions(Error_Message_OR);
	}
	
	public  void updateZipOrPostalCode(String zipcode) throws Exception
	{ 
		try 
		{
			scrollToView(ZipCode_Textbox_OR);
			sendKeys(ZipCode_Textbox_OR,zipcode);
			clickOnElementUsingActions(SecurityStamp_Textbox_OR);
			extentReport.pass( "User able to enter zip/postal code ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to enter zip/postal code ");
		}
		
	}	

	public  void updateCountry(String nonUSCountry) throws Exception
	{ 
		try 
		{
			scrollToView(Country_List_OR);
			selectValuefromDropdownviaVisibleText(Country_List_OR,nonUSCountry);
			extentReport.pass( "User able select non US country ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to select non US country  ");
		}
		
	}	
	
}