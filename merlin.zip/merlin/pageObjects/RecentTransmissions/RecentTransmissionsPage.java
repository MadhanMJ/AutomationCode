
package com.test.qa.ui.pageObjects.RecentTransmissions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

/**
 * RecentTransmissionsPage for non-admin clinician user.
 * This is the default page displayed on clinician login.
 */
public class RecentTransmissionsPage extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	
	private final By quickLinksVerticalSplit = By.xpath("//div[@class='quicklink mt-15']/button[@class='mat-focus-indicator merlin-button mat-button mat-button-base mat-primary ng-star-inserted']/span[@class='mat-button-wrapper']/span[@class='material-icons ml-30']");
	private final By clinicAdministrationNavigation = By.xpath("//li[@class='list-item ng-star-inserted'][4]/a[@class='mat-focus-indicator mat-ripple mat-button mat-button-base ng-star-inserted']");
	
	private final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");
	
	public static Log logger = new Log();

	public RecentTransmissionsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	/*
	 * ----------------
	 * Helper functions
	 * ----------------
	 */
	
	private boolean elementVisibleOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			if (!verifyLandingPage()) {
				extentReport.reportFail(reportFailMsg);
				return false;
			}
			
			invisibilityOfElementLocated(pageLoading);
			waitForPageLoad();
			
			if (visibilityOfElementLocated(element)) {
				extentReport.reportPass(reportPassMsg);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		extentReport.reportFail(reportFailMsg);
		return false;
	}
	
	private void clickElementOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			if (!elementVisibleOnPage(element, "Element found on page", "Element not found on page")) {
				extentReport.reportFail(reportFailMsg);
				return;
			}
			
			waitForElementToBeClickable(element);
			//invisibilityOfElementLocated(pageLoading);
			clickElement(element);
			extentReport.reportPass(reportPassMsg);
			waitForLoading();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/*
	 * ----------------
	 * Public functions
	 * ----------------
	 */
	
	public void goToClinicAdministrationProfilePage() throws Exception {
		clickElementOnPage(clinicAdministrationNavigation, "Clinic Administration Button is clicked from Recent Transmissions Page", "Clinic Administration Button could not be found");
	}
	
	// Each page class should have this overridden method of Verify Landing page 
	@Override
	public boolean verifyLandingPage() {
		Boolean verifyRecentTransmissionsPage = false;
		
		if(visibilityOfElementLocated(quickLinksVerticalSplit)) {
			verifyRecentTransmissionsPage = true;
			extentReport.reportPass("Recent Transmissions Page is displayed");
		} else {
			extentReport.reportFail("Recent Transmissions Page is not displayed");
		}
		return verifyRecentTransmissionsPage;

	}
	
	/*
	 * Author Salin Gambhir
	 * Test case name quicklinks_02
	 */
	
	public final By disconnectedTransmitterLink_OR = By.xpath("//app-transmission//div[2]/div[2]/div/app-quick-links/div/mat-action-list/button[5]/div/div[3]/div");
	public final String disconnectedTransmitterLink_S = "Disconnected Transmitter Links";
	public final By disconnectedTransmitterLinkCount_OR = By.xpath("//app-transmission/div[2]/div[2]/div/app-quick-links/div/mat-action-list/button[5]/div/div[3]/span");
 	public final String disconnectedTransmitterLinkCount_S = "Disconnect Transmitter Link Count";  
	
	
	public boolean verifyDisconnectedTransmitterLink() {
		
		return visibilityOfElementLocatedWithReport(disconnectedTransmitterLink_OR, disconnectedTransmitterLink_S);
				
	}
	
	public boolean verifyDisconnectedTransmitterLinkCount(int expectedValue) {
		boolean countCheck= false;
		try {
			int countValue = Integer.parseInt(getText(disconnectedTransmitterLinkCount_OR));
			if (countValue == expectedValue)
			{
				extentReport.reportPass("Disconnected Transmitter link has same value as Patient List");
				countCheck = true;
			}
			else
				extentReport.reportFail("Disconnected Transmitter link has same value as Patient List");
				
		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		return countCheck;
		
	}
	
	public void goToDisconnectedTransmitterLink()
	{
		clickElement(disconnectedTransmitterLink_OR, disconnectedTransmitterLink_S);
	}

}

