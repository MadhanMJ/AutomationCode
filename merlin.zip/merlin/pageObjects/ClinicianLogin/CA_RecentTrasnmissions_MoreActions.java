package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_RecentTrasnmissions_MoreActions extends BasePage
{
	
	/*
	 * AUTHOR: Kundan Kumar
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public CA_RecentTrasnmissions_MoreActions(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	
	private final By recent_transmission_more_action_OR = By.xpath("//button[@id=\"btn_transmission-list_selectMoreAction\"]");
	private final String recent_transmission_more_action_S = "Recent Transmission more action button";
	
	private final By  more_Action_Dowloadspreasheet_OR=By.xpath("//button[@id=\"btn_transmission-list_downloadSpreadsheet\"]/span");
	private final String more_action_Dowloadspreasheet_S="Recent Transmission more action button download spreadsheet option";
	
	private final By  more_Action_AddorRemovecolumn_OR=By.xpath("//button[@id=\"btn_transmission-list_addOrRemoveColumns\"]/span");
	private final String  more_action_addorRemovecolumn_S="Recent Transmission more action button Add or Remove column option";
	
	private final By  more_Action_Print_OR=By.xpath("//button[@id=\"btn_transmission-list_print\" and @role='menuitem']");
	private final String more_Action_Print_S="Recent Transmission more action button Print option";
	
	private final By  AddorRemovecolumn_Scehdule_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_0\"]/label/span");
	private final String AddorRemovecolumn_Scehdule_Checkbox_S="more action button AddorRemovecolumn Scehdule Checkbox";
	
	private final By  AddorRemovecolumn_Location_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_1\"]/label/span");
	private final String AddorRemovecolumn_Location_Checkbox_S="more action button AddorRemovecolumn Location Checkbox";
	
	private final By  AddorRemovecolumn_Device_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_2\"]/label/span");
	private final String AddorRemovecolumn_Device_Checkbox_S="more action button AddorRemovecolumn Device Checkbox";
	
	private final By  AddorRemovecolumn_Advsiory_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_3\"]/label/span");
	private final String AddorRemovecolumn_Advsiory_Checkbox_S="more action button AddorRemovecolumn Advsiory Checkbox";
    
	private final By  AddorRemovecolumn_Alertslist_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_4\"]/label/span");
	private final String AddorRemovecolumn_Alertslist_Checkbox_S="more action button AddorRemovecolumn Alertslist Checkbox";
	
	private final By  AddorRemovecolumn_Latestcomments_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_5\"]/label/span");
	private final String AddorRemovecolumn_Latestcomments_Checkbox_S="more action button AddorRemovecolumn Latest comments Checkbox";
	
	private final By  AddorRemovecolumn_Window_Done_OR=By.xpath("//button[@id=\"btn_column_name_done\"]/span");
	private final String AddorRemovecolumn_Window_Done_S="more action button AddorRemovecolumn window done";
	
	
	@Override
	public boolean verifyLandingPage() {
	Boolean clinicLocationsPageCheck = false;

	if(isElementPresentwithoutException(recent_transmission_more_action_OR, recent_transmission_more_action_S)) {
	clinicLocationsPageCheck = true;

	}

	return clinicLocationsPageCheck;
	}
}
