package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_EpisodesAndEGMPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	
	/*
	 * Author: Gowshalya
	 */
	
	public CA_EpisodesAndEGMPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	//Gowshalya
	private final By episodesAndEGMHdr_OR = By.xpath("//h6[@id='title_episode-egm-icm_episodeEgm']");
	private final String episodesAndEGMHdr_S = "Episodes & EGM Page header";
	
	private final By episodesAndEGMNonICMHdr_OR = By.xpath("//*[@id=\"title_egm-non-icm-device-data_episode_egm_non_icm\"]");
	private final String episodesAndEGMNonICMHdr_S = "Episodes & EGM Page header";
	
	public Boolean verifyLandingPageForNonICM() {
		Boolean flag = false;

		if(isElementPresentwithoutException(episodesAndEGMNonICMHdr_OR, episodesAndEGMNonICMHdr_S)) {
			flag = true;
			extentReport.reportScreenShot("Episodes & EGM Page is displayed");
		} else {
			extentReport.reportScreenShot("Episodes & EGM Page is not displayed");
		}
		return flag;

	}
	
	
	@Override
	public boolean verifyLandingPage() {
		Boolean flag = false;

		if(isElementPresentwithoutException(episodesAndEGMHdr_OR, episodesAndEGMHdr_S)) {
			flag = true;
			extentReport.reportScreenShot("Episodes & EGM Page is displayed");
		} else {
			extentReport.reportScreenShot("Episodes & EGM Page is not displayed");
		}
		return flag;

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Kundan
		private final By selectpt_Checkbox_EpisodeEGM_Page_OR = By.xpath("//*[@id=\"mat-checkbox-521\"]/label/div");
		private final String selectpt_Checkbox_Transmission_Page_S = "Episode EGM page select patient check box";
		
		private final By moreAction_OR = By.xpath("//button[@id='btn_episode-egm-icm_selectMoreAction']");
		private final String moreAction_S = "More Action Button";
		
		private final By moreAction_ViewEpisode_OR = By.xpath("//button[@id=\"btn_episode-egm-icm-more_action-list-item_View Episodes\"]");
		private final String moreAction_ViewEpisode_S = "More Action view episode option";
		
		private final By episodeand_EGM_Window_OR = By.xpath("//h5[@id=\"title_popup-pdf_main_title\"]");
		private final String episodeand_EGM_Window_S = "Episode and EGM window";
		
		private final By episodeandegm_Selfassesment_DropDown_OR = By.xpath("//mat-select[@id=\"dd_popup-pdf-other_assesmentTypes\"]/div/div[2]");
		private final String episodeandegm_Selfassesment_DropDown_S = "Episode and EGM window self assesment drop down";
		
		private final By selfassesment_DropDown_Inappropiate_Option_OR = By.xpath("//mat-option[@id=\"mat-option-40\"]");
		private final String selfassesment_DropDown_Inappropiate_Option_S = "Episode and EGM window self assesment drop down Inappropiate_Option";
		
		private final By selfassesment_DropDown_Appropiate_Option_OR = By.xpath("//mat-option[@id=\"mat-option-41\"]");
		private final String selfassesment_DropDown_Appropiate_Option_S = "Episode and EGM window self assesment drop down Appropiate_Option";
		
		private final By selfassesment_DropDown_Notsure_Option_OR = By.xpath("//mat-option[@id=\"mat-option-42\"]");
		private final String selfassesment_DropDown_Notsure_Option_S = "Episode and EGM window self assesment drop down Notsure_Option";
		
		private final By selfassesment_DropDown_Notassessed_Option_OR = By.xpath("//mat-option[@id=\"mat-option-155\"]");
		private final String selfassesment_DropDown_Notassessed_Option_S = "Episode and EGM window self assesment drop down Notassessed_Option";
		//here xpath changing dynamically.Rework effort is here
		
		private final By episodeandegm_Window_Save_Button_OR = By.xpath("//button[@id=\"btn_popup-pdf_save\"]");
		private final String episodeandegm_Window_Save_Button_S = "Episode and EGM window save button";
		
		private final By episodeandegm_Window_Cancel_Button_OR = By.xpath("//button[@id=\"btn_popup-pdf_close2\"]");
		private final String episodeandegm_Window_Cancel_Button_S = "Episode and EGM window save button";
		
		private final By episode_DateandTime_Link_OR = By.xpath("//tr[@id=\"mnu_episode-egm-icm__0\"]/td[5]/div");
		private final String episode_DateandTime_Link_S = "Episode date and time link";
		
		private final By episodeandegm_Window_Note_Textbox_OR = By.xpath("//textarea[@id=\"txt_popup-pdf_notes\"]");
		private final String episodeandegm_Window_Note_Textbox_S = "Episode and EGM window note text box";
		
		private final By episodeandegm_Window_Print_checkbox_OR = By.xpath("//mat-checkbox[@id=\"ICMEGMPopupOtherContentPrintCheck\"]/label/div");
		private final String episodeandegm_Window_Print_Checkbox_S = "Episode and EGM window print check box";
		
		private final By rectransmission_DateandTime_Column_OR = By.xpath("//td[@id=\"lbl_transmission-list_td-transmission0\"]/div");
		private final String rectransmission_DateandTime_Column_S = "Recent transmission transmission cloumn link";
		
		private final By egmGainViewerButton_OR = By.xpath("//button[@id='label_egm_gain_viewer']");
		private final String egmGainViewerButton_S = "EGM Gain Viewer button";
		
		private final By egmGainViewerWindow_OR = By.xpath("//mat-dialog-container[contains(@class,'mat-dialog-container')]");
		private final String egmGainViewerWindow_S = "EGM Gain Viewer Modal Window";
		
		private final By episodeAndEgmCloseButton_OR = By.xpath("  //*[@id=\"mat-dialog-2\"]/app-egm-viewer-popup/div/header/div/button[2]/span/mat-icon");
		private final String episodeAndEgmCloseButton_S ="Episode and EGM Pdf close button";
		
		public void selectEpisodeCbxEpisodeEGMPage()
		{
			clickElement(selectpt_Checkbox_EpisodeEGM_Page_OR, selectpt_Checkbox_Transmission_Page_S);
		}
		
		public void clickOnMoreActions() {
			
			clickElement(moreAction_OR, moreAction_S);
			waitForPageLoad();
		}
		
		public void navigateToViewEpisodeOption()
		{
			clickElement(moreAction_ViewEpisode_OR, moreAction_ViewEpisode_S);
		}
        
		public void verifyEpisodeandEgmWindow()
		{
		Boolean episodeegmwindow=isElementPresent(episodeand_EGM_Window_OR, episodeand_EGM_Window_S);
		extentReport.pass("Episode and EGM window displayed "+episodeegmwindow);
			
		}
		
		public void selectInappropiateOption()
		{
			clickElement(episodeandegm_Selfassesment_DropDown_OR, episodeandegm_Selfassesment_DropDown_S);
			clickElement(selfassesment_DropDown_Inappropiate_Option_OR, selfassesment_DropDown_Inappropiate_Option_S);
		}
		
		public void selectAppropiateOption()
		{
			clickElement(episodeandegm_Selfassesment_DropDown_OR, episodeandegm_Selfassesment_DropDown_S);
			clickElement(selfassesment_DropDown_Appropiate_Option_OR, selfassesment_DropDown_Appropiate_Option_S);
		}
		
		public void selectNotsureOption()
		{
			clickElement(episodeandegm_Selfassesment_DropDown_OR, episodeandegm_Selfassesment_DropDown_S);
			clickElement(selfassesment_DropDown_Notsure_Option_OR, selfassesment_DropDown_Notsure_Option_S);
		}
		
		public void selectNotassessedOption()
		{
			clickElement(episodeandegm_Selfassesment_DropDown_OR, episodeandegm_Selfassesment_DropDown_S);
			clickElement(selfassesment_DropDown_Notassessed_Option_OR, selfassesment_DropDown_Notassessed_Option_S);
		}
		
		public void verifySaveButtonisDisabled()
		{
			clickElement(episodeand_EGM_Window_OR, episodeand_EGM_Window_S);
	        Boolean savebuttondisabled=isEnabledWithReport(episodeandegm_Window_Save_Button_OR, episodeandegm_Window_Save_Button_S);
		    extentReport.pass("Save is enabled "+savebuttondisabled);
		}
		
		public void clickCancelButton()
		{
			clickElement(episodeandegm_Window_Cancel_Button_OR, episodeandegm_Window_Cancel_Button_S);
		}
		
		public void clickEpisodeDateandTimeLink()
		{
			waitForPageLoad();
			clickElement(episode_DateandTime_Link_OR, episode_DateandTime_Link_S);
		}
		
		public void verifyNoteTextboxisDisabled()
		{
		Boolean notedisabled=isEnabledWithReport(episodeandegm_Window_Note_Textbox_OR, episodeandegm_Window_Note_Textbox_S);
		extentReport.pass("Note text box is enabled "+notedisabled);
		}
		
		public void selectPrintCheckbox()
		{
			clickElement(episodeandegm_Window_Print_checkbox_OR, episodeandegm_Window_Print_Checkbox_S);
		}
		
		public void navigateToTransmissionLinkColumn()
		{
			clickElement(rectransmission_DateandTime_Column_OR, rectransmission_DateandTime_Column_S);
			waitForPageLoad();
		}
		 public void selectEgmViewerButton()
		 {
			 
			 clickElement(egmGainViewerButton_OR, egmGainViewerButton_S);
		 }
		 
		 public void verifyEgmViewerWindow()
		 {
			 isElementPresent(egmGainViewerWindow_OR, egmGainViewerWindow_S);
		 }
	
		
		
		
	
}
