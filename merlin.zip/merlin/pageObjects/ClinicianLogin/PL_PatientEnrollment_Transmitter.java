package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

//Author: Poojitha

public class PL_PatientEnrollment_Transmitter extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientEnrollment_Transmitter(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
//Poojitha
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By transSectionLabelsHeader_OR = By.xpath("//h3[@class='merlin-header']");
	private final String transSectionLabelsHeader_S = "Labels present in Transmitter Page";
	private final By mistValue_OR = By.xpath("");
	private final String mistValue_S = "Patient level MIST value";
	private final By nodcValue_OR = By.xpath("");
	private final String nodcValue_S = "Patient level NODC value";
	private final By continueButton_OR = By.xpath("//*[@id=\"cdk-step-content-0-1\"]/app-enroll-patient-transmitter/form/div[3]/button[4]");
	private final String continueButton_S = "Continue button";
//Ends here	
	
//Poojitha
	public void validateDefaultThresholdValues(String mistValue, String nodcValue)
	{
		if(getText(mistValue_OR, mistValue_S).equalsIgnoreCase(mistValue) && getText(nodcValue_OR, nodcValue_S).equalsIgnoreCase(nodcValue))
			extentReport.reportPass("Patient level MIST & NODC Values are matching with the clinic level parameters");
		else
			extentReport.reportFail("Patient level MIST/NODC Values are not matching with the clinic level parameters");		
	}
	
	public void clickContinueButton()
	{
		clickOnElementUsingJs(continueButton_OR,continueButton_S);
	}
	//Ends here
	
	@Override
	public boolean verifyLandingPage() {
		Boolean transmitterPageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(transSectionLabelsHeader_OR, transSectionLabelsHeader_S)) {
			transmitterPageCheck = true;
		}
		return transmitterPageCheck;
	}
	

}
