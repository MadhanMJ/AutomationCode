package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class PL_TopNavPage extends BasePage {

	public PL_TopNavPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;

	}

	// Poojitha
	private final By allTransmissions_OR = By.partialLinkText("All Transmissions");
	private final String allTransmissions_S = "All Transmissions";

	private final By patientSummary_OR = By.linkText("Patient Summary");
	private final String patientSummary_S = "Patient Summary";
	// ends here
	
	//shafiya 24/02/2022 added xpath
	private final By transmission_OR = By.linkText("Transmission");
	private final String transmission_S = "Transmission";
	// ends here

	// Poojitha
	// This method is used to navigate to Patient Summary page
	public void navigateToPatientSummary() throws Exception {
		loadingWithoutReport();
		clickElement(patientSummary_OR, patientSummary_S);
	}

	// This method is used to navigate to All Transmissions page
	public void navigateToAllTransmissionPage() throws Exception {
		clickElement(allTransmissions_OR, allTransmissions_S);
	}

	// This method is used to navigate to Transmissions page
	public void navigateToTransmissionPage() throws Exception {
		clickElement(transmission_OR, transmission_S);
	}
//ends here	

	public boolean verifyPatientSummaryTab() {
		boolean isPatientSummaryDisplayed = false;
		if (isElementPresentwithoutException(patientSummary_OR, patientSummary_S)) {
			isPatientSummaryDisplayed = true;
			extentReport.reportScreenShot("Patient Summary Tab  is available");
		} else {
			extentReport.reportScreenShot("Patient Summary Page  is not available");
		}
		return isPatientSummaryDisplayed;
	}

	// Each page class should have this overridden method of Verify Landing page
	@Override
	public boolean verifyLandingPage() {
		Boolean patientListTopNavPageCheck = false;
		if (visibilityOfElementLocatedWithoutReport(allTransmissions_OR, allTransmissions_S)) {
			patientListTopNavPageCheck = true;
			extentReport.reportScreenShot("Patient List Transmission Page is displayed");
		}
		return patientListTopNavPageCheck;
	}

}
