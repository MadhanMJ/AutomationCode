package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class ToolsPage extends BasePage{
	public ToolsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By weeklyGlance_OR = By.xpath("//*[@id=\"app-container\"]/app-tools-sidebar-cmp/div/div[3]/ul/li[1]/a");
	private final String weeklyGlance_S = "Weekly Glance Link";
	
	
	@Override
	public boolean verifyLandingPage() {
		Boolean toolsPageCheck = false;
		if(isElementPresentwithoutException(weeklyGlance_OR,weeklyGlance_S)) {
			toolsPageCheck =true;
			extentReport.reportScreenShot("Tools page is displayed");
		}
		return toolsPageCheck;
	}
	
	/*
	 * Salin Gambhir
	 * for TC name: WA_96_QuickLinks_02
	 */
	
	private final By messageLink_OR = By.xpath("//div[@id='TEST_IDENTIFICATION']/app-tools-sidebar-cmp/div/div[3]/ul/li[@class='nav-item ng-star-inserted active']/a/p");
	private final String messageLink_S = "Message link on Tools page";
	private final By allMessages_OR = By.xpath("//div[@id='TEST_IDENTIFICATION']/div/div/div/div/app-tools-messages/div[1]/div[1]");
	private final String allMessages_S = "All Messages Link";
	private final By allRelatedMessages_OR = By.xpath("//div[@class='cdk-overlay-container']//button[1]");
	private final String allRelatedMessages_S = "All Related Messages Link";
	private final By clinicRelatedMessages_OR = By.xpath("//div[@class='cdk-overlay-container']//button[2]");
	private final String clinicRelatedMessages_S = "Clinic Related Messages Link";
	private final By patientRelatedMessages_OR = By.xpath("//div[@class='cdk-overlay-container']//button[5]");
	private final String patientRelatedMessages_S = "Patient Related Messages";
	
	public boolean verifyMessageLink()
	{
		boolean isMessageLinkActive = false;
		try {
			if(visibilityOfElementLocatedWithReport(messageLink_OR, messageLink_S))
				if(getText(messageLink_OR, messageLink_S).equals("Messages"))
					{
						extentReport.reportPass("Message link is active.");
						isMessageLinkActive= true;
					}
				else
					extentReport.reportFail("Message link is not active.");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		return isMessageLinkActive;
	}
	
	public void clickOnVariousMessages(String menuOption)
	{
		clickOnMessageFilterLink();
		
		switch (menuOption.toLowerCase())
		{
		case "All Messages":
			elementToBeClickable(allRelatedMessages_OR, allRelatedMessages_S);
			clickElement(allRelatedMessages_OR, allRelatedMessages_S);
			break;
		case "clinic-related messages":
			elementToBeClickable(clinicRelatedMessages_OR, clinicRelatedMessages_S);
			clickElement(clinicRelatedMessages_OR, clinicRelatedMessages_S);
			break;
		case "patient-related messages":
			elementToBeClickable(patientRelatedMessages_OR, patientRelatedMessages_S);
			clickElement(patientRelatedMessages_OR, patientRelatedMessages_S);
			break;
		}
		
	}
	
	public void clickOnMessageFilterLink() {
		elementToBeClickable(allMessages_OR, allMessages_S);
		clickElement(allMessages_OR, allMessages_S);
	}

	public boolean verifyMessages(String specificMessage) {
		// TODO Auto-generated method stub
		boolean checkMessages = false;
		
		try {
			switch (specificMessage.toLowerCase())
			{
				case "clinic-related messages":
					
					checkMessages= true;
					break;
				case "patient-related messages":
					checkMessages=true;
					break;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		return checkMessages;
	}

}
