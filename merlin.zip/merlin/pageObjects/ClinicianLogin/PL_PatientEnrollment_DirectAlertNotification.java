package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

//Author: Salin Gambhir

public class PL_PatientEnrollment_DirectAlertNotification extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientEnrollment_DirectAlertNotification(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By directAlertNotificationHeader_OR = By.xpath("//div[starts-with(@id,'cdk-step-content')]/app-enroll-direct-alert-settings/div[1]/div");
	private final String directAlertNotificationHeader_S = "Direct Alert Notification Header";
	
	//Poojitha
	private final By continueButton_OR = By.xpath("//div[starts-with(@id,'cdk-step-content')]/app-enroll-direct-alert-settings/div[2]/div[3]/button[4]");
	private final String continueButton_S = "continue button";
	//Ends here
	
	//Poojitha
	public void clickContinueButton()
	{
		clickElement(continueButton_OR,continueButton_S);
	}
	//Ends here
	
	@Override
	public boolean verifyLandingPage() {
		Boolean directAlertNotificationPageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(directAlertNotificationHeader_OR, directAlertNotificationHeader_S)) {
			directAlertNotificationPageCheck = true;
		}
		return directAlertNotificationPageCheck;
	}
	

}
