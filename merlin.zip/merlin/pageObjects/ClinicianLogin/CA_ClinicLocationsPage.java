package com.test.qa.ui.pageObjects.ClinicianLogin;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.CommonLibraries;

import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.test.qa.utilities.CommonUtils.extentTest;

public class CA_ClinicLocationsPage extends BasePage {

	/*
	 * AUTHOR: Carmel Vimala
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	CommonUtils commonUtils = new CommonUtils();
	CommonLibraries commonLibraries;

	public CA_ClinicLocationsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		commonLibraries = new CommonLibraries(driver, extentReport);
	}

	private final By clinicLocations_HomePage_header_OR = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-clinic-locations//header/div");
	private final String clinicLocations_HomePage_header_S = "Clinic Locations Header in Clinic Locations page";

	private final By ClinicLocations_SearchLocationsTextBox_OR = By.xpath("//input[@placeholder='Search']");
	private final String ClinicLocations_SearchLocationsTextBox_S = "Clinic Locations Search textbox in Clinic Locations page";

	private final By ClinicLocations_AddLocationButton_OR = By.xpath("//button[@id='add']");
	private final String ClinicLocations_AddLocationButton_S = "Add Locations button in Clinic Locations page";

	private final By ClinicLocations_CustomerLocationsTextBox_OR = By
			.xpath("//input[@id='location_clinicLocation']");
	private final String ClinicLocations_CustomerLocationsTextBox_S = "Customer Locations textbox in Clinic Locations page";

	private final By ClinicLocations_SaveButton_OR = By.xpath("//button[@id='save']");
	private final String ClinicLocations_SaveButton_S = "Save button in Clinic Locations page";

	private final By ClinicLocations_toastSuccessMessage_OR = By.xpath("//div[text()=' Success ']");
	private final String ClinicLocations_toastSuccessMessage_S = "Clinic locations toast add success message in Clinic Locations page";

	private final By ClinicLocations_toastCloseButton_OR = By.xpath("//button[contains(@class,'toast-close-button')]");
	private final String ClinicLocations_toastCloseButton_S = "Close button in toast message in Clinic Locations page";

	private final By ClinicLocations_VerifyLocationListInGrid_OR = By.xpath("//mat-radio-button[contains(@id,'mat-radio')]");
	private final String ClinicLocations_VerifyLocationListInGrid_S = "Locations list in the grid in Clinic Locations page";

	private final By ClinicLocations_LocationListInGrid_OR = By
			.xpath("//mat-radio-button[contains(@id,'mat-radio')]/label/div");
	private final String ClinicLocations_LocationListInGrid_S = "Locations list in the grid in Clinic Locations page";

	private final By ClinicLocations_LocationradioButtonInGrid_OR = By
			.xpath("//mat-radio-button[contains(@id,'mat-radio')]");
	private final String ClinicLocations_LocationradioButtonInGrid_S = "location radio button in grid";

	private static String ClinicLocations_LocationradioButtonInGrid_S(String strlocationName) {
		String location = "Radio button for  \"" + strlocationName + "\" in locations grid";
		return location;
	}

	private final By ClinicLocations_DeleteLocationButtn_OR = By.xpath("//button[@id='delete']");
	private final String ClinicLocations_DeleteLocationButtn_S = "Delete Location Button";

	private final By ClinicLocations_NoDataMatchingTextInGrid_OR = By
			.xpath("//div[contains(text(),'No data matching')]");
	private final String ClinicLocations_NoDataMatchingTextInGrid_S = "\"No matching data\" text in locations grid";

	private final By ClinicLocations_EditButton_OR = By.xpath("//button[@id='edit']");
	private final String ClinicLocations_EditButton_S = "Edit button in Clinic Locations page";

	private final By ClinicLocations_CancelButton_OR = By.xpath("//button[@id='cancel']");
	private final String ClinicLocations_CancelButton_S = "cancel button in Clinic Locations page";

	private final By ClinicLocations_Address1TexBox_OR = By.xpath("//input[@placeholder='Address 1']");
	private final String ClinicLocations_Address1TexBox_S = "Address1 Textbox in Clinic Locations page";
	private final By ClinicLocations_Address2TexBox_OR = By.xpath("//input[@placeholder='Address 2']");
	private final String ClinicLocations_Address2TexBox_S = "Address2 Textbox in Clinic Locations page";

	private final By ClinicLocations_Address3TexBox_OR = By.xpath("//input[@placeholder='Address 3']");
	private final String ClinicLocations_Address3TexBox_S = "Address3 Textbox in Clinic Locations page";

	private final By ClinicLocations_CountryTexBox_OR = By.xpath("//input[@placeholder='Country']");
	private final String ClinicLocations_CountryTexBox_S = "Country Textbox in Clinic Locations page";

	private final By ClinicLocations_CityTexBox_OR = By.xpath("//input[@placeholder='City']");
	private final String ClinicLocations_CityTexBox_S = "City Textbox in Clinic Locations page";

	private final By ClinicLocations_StateTexBox_OR = By.xpath("//input[@placeholder='State/Prov']");
	private final String ClinicLocations_StateTexBox_S = "State Textbox in Clinic Locations page";

	private final By ClinicLocations_ZipCodeTexBox_OR = By.xpath("//input[@placeholder='Zip/Postal code']");
	private final String ClinicLocations_ZipCodeTexBox_S = "Zipcode Textbox in Clinic Locations page";

	private final By ClinicLocations_MainPhonenumber_OR = By.xpath("(//input[@id='merlin_textbox_number'])[1]");
	private final String ClinicLocations_MainPhonenumber_S = "Main phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_SecPhoneNumberTexBox_OR = By.xpath("(//input[@id='merlin_textbox_number'])[2]");
	private final String ClinicLocations_SecPhoneNumberTexBox_S = "Secondary phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_FaxTexBox_OR = By.xpath("(//input[@id='merlin_textbox_number'])[3]");
	private final String ClinicLocations_FaxTexBox_S = "Fax Textbox in Clinic Locations page";

	private final By ClinicLocations_EmailTexBox_OR = By.xpath("//input[@placeholder='EMail']");
	private final String ClinicLocations_EmailTexBox_S = "Email Textbox in Clinic Locations page";

	private final By ClinicLocations_TimeZoneTexBox_OR = By.xpath("//input[@placeholder='Clinic time zone']");
	private final String ClinicLocations_TimeZoneTexBox_S = "Fax Textbox in Clinic Locations page";

	private final By ClinicLocations_CustomerNameTextBox_OR = By.xpath("//input[@id='merlin_textbox_customerName']");
	private final String ClinicLocations_CustomerNameTextBox_S = "Customer Name Textbox in Clinic Locations page";

	private final By ClinicLocations_CustomerTypeTextBox_OR = By.xpath("//input[@id='merlin_textbox_customerType']");
	private final String ClinicLocations_CustomerTypeTextBox_S = "Fax Textbox in Clinic Locations page";

	private final By ClinicLocations_CountryCodeMainPhone_OR = By
			.xpath("(//input[@id='merlin_textbox_countryCode'])[1]");
	private final String ClinicLocations_CountryCodeMainPhone_S = "Country code of Main phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_CountryCodeSecPhone_OR = By
			.xpath("(//input[@id='merlin_textbox_countryCode'])[2]");
	private final String ClinicLocations_CountryCodeSecPhone_S = "Country code of Secondary phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_CountryCodeFax_OR = By.xpath("(//input[@id='merlin_textbox_countryCode'])[3]");
	private final String ClinicLocations_CountryCodeFax_S = "Country code of Fax phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_AreaCodeMainPhone_OR = By.xpath("(//input[@id='merlin_textbox_areaCityCode'])[1]");
	private final String ClinicLocations_AreaCodeMainPhone_S = "Area code of Main phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_AreaCodeSecPhone_OR = By.xpath("(//input[@id='merlin_textbox_areaCityCode'])[2]");
	private final String ClinicLocations_AreaCodeSecPhone_S = "Area code of Secondary phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_AreaCodeFax_OR = By.xpath("//input[@id='merlin_textbox_areaCityCode'])[3]");
	private final String ClinicLocations_AreaCodeFax_S = "Area code of Fax phone number Textbox in Clinic Locations page";

	private final By ClinicLocations_TextMessage_OR = By.xpath("//input[@id='merlin_textbox_textMessageId']");
	private final String ClinicLocations_TextMessage_S = "Text Message Textbox in Clinic Locations page";


	Map<String, String> customerExistingData = new HashMap<String, String>();

	// carmel
	public void AddAndSearchLocations(String strClinicLocation) throws Exception {
		String[] arrClinicLocations = strClinicLocation.split(", ");
		for (String clinicLoc : arrClinicLocations) {
			// Add

			clickElement(ClinicLocations_AddLocationButton_OR, ClinicLocations_AddLocationButton_S);
			scrollToViewWithoutReport(ClinicLocations_CustomerLocationsTextBox_OR,
					ClinicLocations_CustomerLocationsTextBox_S);
			sendKeys(ClinicLocations_CustomerLocationsTextBox_OR, ClinicLocations_CustomerLocationsTextBox_S,
					clinicLoc);
			scrollToViewWithoutReport(ClinicLocations_SaveButton_OR, ClinicLocations_SaveButton_S);
			clickElement(ClinicLocations_SaveButton_OR, ClinicLocations_SaveButton_S);
			presenceOfElementLocatedWithReport(ClinicLocations_toastSuccessMessage_OR,
					ClinicLocations_toastSuccessMessage_S);
			clickElement(ClinicLocations_toastSuccessMessage_OR, ClinicLocations_toastSuccessMessage_S);
			invisibilityOfElementLocatedWithoutReport(ClinicLocations_toastSuccessMessage_OR,
					ClinicLocations_toastSuccessMessage_S);
			SearchLocations(clinicLoc);
			VerifySearchLocationsfuction(clinicLoc);

		}
	}

//carmel
	public void SearchLocations(String strClinicLocation) throws Exception {
		sendKeys(ClinicLocations_SearchLocationsTextBox_OR, ClinicLocations_SearchLocationsTextBox_S,
				strClinicLocation);
	}

	// carmel
	public void VerifySearchLocationsfuction(String strClinicLocation) throws Exception {
		commonLibraries.VerifyTextinWebElementList(ClinicLocations_VerifyLocationListInGrid_OR,
				ClinicLocations_VerifyLocationListInGrid_S, strClinicLocation);

	}

	// carmel
	public void DeleteLocations(String strClinicLocation) throws Exception {
		String[] arrClinicLocations = strClinicLocation.split(", ");
		for (String clinicLoc : arrClinicLocations) {
			clear(ClinicLocations_SearchLocationsTextBox_OR, ClinicLocations_SearchLocationsTextBox_S);
			SearchLocations(clinicLoc);
			boolean searchlocation = isElementPresentwithoutException(ClinicLocations_LocationradioButtonInGrid_OR,
					ClinicLocations_LocationradioButtonInGrid_S);
			if (searchlocation == true) {
				clickElement(ClinicLocations_LocationradioButtonInGrid_OR,
						ClinicLocations_LocationradioButtonInGrid_S(clinicLoc));
				clickElement(ClinicLocations_DeleteLocationButtn_OR, ClinicLocations_DeleteLocationButtn_S);
				presenceOfElementLocatedWithReport(ClinicLocations_toastSuccessMessage_OR,
						ClinicLocations_toastSuccessMessage_S);
				clickElement(ClinicLocations_toastSuccessMessage_OR, ClinicLocations_toastSuccessMessage_S);
				clear(ClinicLocations_SearchLocationsTextBox_OR, ClinicLocations_SearchLocationsTextBox_S);

				SearchLocations(clinicLoc);
				presenceOfElementLocatedWithReport(ClinicLocations_NoDataMatchingTextInGrid_OR,
						ClinicLocations_NoDataMatchingTextInGrid_S);
			}
		}
	}

	// Shanmugapriya
	public boolean verifyLocationIsAlphabeticOrder(By element, String strElement) throws Exception {
		ArrayList<String> list = new ArrayList<String>();
		boolean isLocationAlphabeticOrder = false;
		List<WebElement> elementList = new ArrayList<WebElement>();

		try {
			scrollToViewWithoutReport(element, strElement);
			elementList = findElementslist(element, strElement);
			int elementSize = elementList.size();
			if (elementSize > 0) {
				for (WebElement we : elementList) {
					list.add(we.getText());
				}
				// storing in another list to sort
				ArrayList<String> sortedList = new ArrayList<String>();
				for (String s : list) {
					sortedList.add(s);
				}
				Collections.sort(sortedList, String.CASE_INSENSITIVE_ORDER);
				System.out.println(sortedList);
				if (sortedList.equals(list)) {
					isLocationAlphabeticOrder = true;
					extentReport.pass("Success - \"" + strElement + "\" are in the Alphabetical order ");
				} else {
					throw new AssertionError();
				}
			} else {
				extentReport.reportFail("Element size is :" + elementSize);
			}
		} catch (AssertionError e) {

			extentReport.reportFail("\"" + strElement + "\" are not in Alphabetical order ",
					CommonUtils.convertStackTraceToString(e));

			throw e;
		} catch (Exception e) {
			extentReport.reportFail("Failure - \"" + strElement + "\" are not  in Alphabetical order",
					CommonUtils.convertStackTraceToString(e));
			throw new Exception(e.getMessage());
		}
		return isLocationAlphabeticOrder;
	}

	public boolean verifyLocationOrder() throws Exception {
		boolean verifyLocationIsAlphabeticOrder = verifyLocationIsAlphabeticOrder(
				ClinicLocations_VerifyLocationListInGrid_OR, ClinicLocations_VerifyLocationListInGrid_S);
		return verifyLocationIsAlphabeticOrder;

	}

//	public void selectAnyLocationInclinicLocation() {
//		scrollToViewWithoutReport(ClinicLocations_LocationradioButtonInGrid_OR,
//				ClinicLocations_LocationradioButtonInGrid_S);
//		clickOnElementUsingJs(ClinicLocations_LocationradioButtonInGrid_OR,
//				ClinicLocations_LocationradioButtonInGrid_S);
//		loadingWithoutReport();
//	}
	
	
	public void selectRandomElementInList(By element, String strElement) {
		List<WebElement> elementInList = driver.findElements(element);
		Random r = new Random();
		// Getting a random value that is between 0 and (list's size)-1
		int randomValue = r.nextInt(elementInList.size());
		loadingWithoutReport();
		js.executeScript("arguments[0].click()", elementInList.get(randomValue));
	}
	public void selectAnyLocationInclinicLocation() {
		try{
			scrollToViewWithoutReport(ClinicLocations_LocationListInGrid_OR,
					ClinicLocations_LocationListInGrid_S);
			selectRandomElementInList(ClinicLocations_LocationListInGrid_OR, ClinicLocations_LocationListInGrid_S);
			loading();
		}catch(StaleElementReferenceException e) {
			scrollToViewWithoutReport(ClinicLocations_LocationListInGrid_OR,
					ClinicLocations_LocationradioButtonInGrid_S);
			selectRandomElementInList(ClinicLocations_LocationListInGrid_OR, ClinicLocations_LocationradioButtonInGrid_S);
			loading();
		}
	}
	
//	public void selectAnyLocation() {
//		scrollToViewWithoutReport(ClinicLocations_LocationListInGrid_OR,
//				ClinicLocations_LocationListInGrid_S);
//		selectRandomElementInList(ClinicLocations_LocationListInGrid_OR, ClinicLocations_LocationListInGrid_S);
//		loading();
//
//	}
//	
//	public void selectAnyLocationInclinicLocation() {
//		scrollToViewWithoutReport(ClinicLocations_LocationListInGrid_OR,
//				ClinicLocations_LocationListInGrid_S);
//		selectRandomElementInList(ClinicLocations_LocationListInGrid_OR, ClinicLocations_LocationListInGrid_S);
//	}
//	

	public void EditLocation() {
		scrollToViewWithoutReport(ClinicLocations_EditButton_OR, ClinicLocations_EditButton_S);
		clickOnElementUsingJs(ClinicLocations_EditButton_OR, ClinicLocations_EditButton_S);

	}

	public boolean verifyMandatoryField(By element, String strElement) throws InterruptedException {
		boolean isCustomerLocationMandatory = false;
		WebElement customerLocation = driver.findElement(element);

		String value = getAttributeWithoutReport(element, "aria-required", strElement);
		if (value.equalsIgnoreCase("true")) {
			isCustomerLocationMandatory = true;
			extentReport.pass("Success - \"" + strElement + " is Mandatory field ");
		} else {
			extentReport.fail("Failure - \"" + strElement + " is not Mandatory field ");
		}
		return isCustomerLocationMandatory;
	}

	public boolean verifyCustomerLocationMandatory() throws InterruptedException {
		scrollToViewWithoutReport(ClinicLocations_CustomerLocationsTextBox_OR,
				ClinicLocations_CustomerLocationsTextBox_S);
		boolean customerLocationMandatory = verifyMandatoryField(ClinicLocations_CustomerLocationsTextBox_OR,
				ClinicLocations_CustomerLocationsTextBox_S);
		return customerLocationMandatory;
	}

	public void cancelLocation() {
		scrollToViewWithoutReport(ClinicLocations_CancelButton_OR, ClinicLocations_CancelButton_S);
		clickOnElementUsingJs(ClinicLocations_CancelButton_OR, ClinicLocations_CancelButton_S);
		acceptAlert();

	}

	public boolean verifyElementInViewMode(By element, String strElement) {
		loading();
		boolean isElementInViewMode=false;
		try {
			if (isElementPresent(element, strElement)) {
				visibilityOfElementLocatedWithoutReport(element, strElement);
				isElementInViewMode=true;
				extentReport.pass("Success - \"" + strElement + "\" is displayed  in view mode");
			} else {
				extentReport.fail("Failure - \"" + strElement + "\" is not displayed  in view mode");
			}

		} catch (Exception e) {
			extentReport.fail("Failure - \"" + strElement + "\" is not displayed in view mode");
			throw new WebDriverException(e.getMessage());
		}
		return isElementInViewMode;
	}

	public boolean VerifyClinicLocDataInViewMode(String FieldName) throws Exception {
		boolean verifyElementInViewMode = false;
		try {
			switch (FieldName) {
			case "Customer Name":
				verifyElementInViewMode(ClinicLocations_CustomerNameTextBox_OR, 
						ClinicLocations_CustomerNameTextBox_S);
				verifyElementInViewMode=true;
				break;
			case "Customer Type":
				verifyElementInViewMode(ClinicLocations_CustomerTypeTextBox_OR, 
						ClinicLocations_CustomerTypeTextBox_S);
				verifyElementInViewMode=true;
				break;
			case "Address1":
				verifyElementInViewMode(ClinicLocations_Address1TexBox_OR, 
						ClinicLocations_Address1TexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Address2":
				verifyElementInViewMode(ClinicLocations_Address2TexBox_OR, 
						ClinicLocations_Address2TexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Address3":
				verifyElementInViewMode(ClinicLocations_Address3TexBox_OR, 
						ClinicLocations_Address3TexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Country":
				verifyElementInViewMode(ClinicLocations_CountryTexBox_OR,
						ClinicLocations_CountryTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "City":
				verifyElementInViewMode(ClinicLocations_CityTexBox_OR, 
						ClinicLocations_CityTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "State":
				verifyElementInViewMode(ClinicLocations_StateTexBox_OR, 
						ClinicLocations_StateTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Zipcode":
				verifyElementInViewMode(ClinicLocations_ZipCodeTexBox_OR,
						ClinicLocations_ZipCodeTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Country Code of Main Phone":
				verifyElementInViewMode(ClinicLocations_CountryCodeMainPhone_OR,
						ClinicLocations_CountryCodeMainPhone_S);
				verifyElementInViewMode=true;
				break;
			case "Area Code of Main Phone":
				verifyElementInViewMode(ClinicLocations_AreaCodeMainPhone_OR,
						ClinicLocations_AreaCodeMainPhone_S);
				verifyElementInViewMode=true;
				break;
			case "MainPhoneNumber":
				verifyElementInViewMode(ClinicLocations_MainPhonenumber_OR,
						ClinicLocations_MainPhonenumber_S);
				verifyElementInViewMode=true;
				break;
			case "Country Code of Sec Phone":
				verifyElementInViewMode(ClinicLocations_CountryCodeSecPhone_OR,
						ClinicLocations_CountryCodeSecPhone_S);
				verifyElementInViewMode=true;
				break;
			case "Area Code of Sec Phone":
				verifyElementInViewMode(ClinicLocations_AreaCodeSecPhone_OR,
						ClinicLocations_AreaCodeSecPhone_S);
				verifyElementInViewMode=true;
				break;
			case "SecPhoneNumber":
				verifyElementInViewMode(ClinicLocations_SecPhoneNumberTexBox_OR,
						ClinicLocations_SecPhoneNumberTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Country Code of Fax":
				verifyElementInViewMode(ClinicLocations_CountryCodeFax_OR,
						ClinicLocations_CountryCodeFax_S);
				verifyElementInViewMode=true;
				break;
			case "Area Code of Fax":
				verifyElementInViewMode(ClinicLocations_AreaCodeFax_OR,
						ClinicLocations_AreaCodeFax_S);
				verifyElementInViewMode=true;
				break;
			case "Fax":
				verifyElementInViewMode(ClinicLocations_FaxTexBox_OR, ClinicLocations_FaxTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Text Message":
				verifyElementInViewMode(ClinicLocations_TextMessage_OR, ClinicLocations_TextMessage_S);
				verifyElementInViewMode=true;
				break;
			case "Email":
				verifyElementInViewMode(ClinicLocations_EmailTexBox_OR, ClinicLocations_EmailTexBox_S);
				verifyElementInViewMode=true;
				break;
			case "Timezone":
				verifyElementInViewMode(ClinicLocations_TimeZoneTexBox_OR, ClinicLocations_TimeZoneTexBox_S);
				verifyElementInViewMode=true;
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return verifyElementInViewMode;
	}


	// Each page class should have this overridden method of Verify Landing page
	private final By pageLoading_OR = By.xpath("//div[@class='spinnerWrapper show']");
	private final String pageLoading_S = "Page loading symbol";
	@Override
	public boolean verifyLandingPage() {
		Boolean clinicLocationsPageCheck = false;

		if (isElementPresentwithoutException(clinicLocations_HomePage_header_OR, clinicLocations_HomePage_header_S)) {
			invisibilityOfElementLocated(pageLoading_OR);
			clinicLocationsPageCheck = true;
			extentReport.reportScreenShot("Clinic Locations page is displayed");
		}

		return clinicLocationsPageCheck;
	}
	//shafiya added method on 21/02/2021
	//This method clicks on Add Location button
	public void clickAddLocationBtn() throws Exception{
		elementToBeClickable(ClinicLocations_AddLocationButton_OR, ClinicLocations_AddLocationButton_S);
		clickElement(ClinicLocations_AddLocationButton_OR, ClinicLocations_AddLocationButton_S);
	}
	//shafiya added method on 21/02/2021
	//This method is used to enter value in mandatory seconday location 
	public void enterSecondayLocation(String location) throws Exception{
		if(isElementPresentwithoutException(ClinicLocations_CustomerLocationsTextBox_OR, ClinicLocations_CustomerLocationsTextBox_S))		
			sendKeys(ClinicLocations_CustomerLocationsTextBox_OR, ClinicLocations_CustomerLocationsTextBox_S,location);			
	}
	//shafiya added method on 21/02/2021
	//This method clicks on save location
	public void clickSaveBtn() throws Exception {
		try {
			if (visibilityOfElementLocatedWithoutReport(ClinicLocations_SaveButton_OR,ClinicLocations_SaveButton_S )) {
				elementToBeClickable(ClinicLocations_SaveButton_OR,ClinicLocations_SaveButton_S);				
				clickElement(ClinicLocations_SaveButton_OR, ClinicLocations_SaveButton_S);
				presenceOfElementLocatedWithReport(ClinicLocations_toastSuccessMessage_OR, ClinicLocations_toastSuccessMessage_S);
				clickElement(ClinicLocations_toastSuccessMessage_OR, ClinicLocations_toastSuccessMessage_S);
				//invisibilityOfElementLocatedWithoutReport(ClinicLocations_toastSuccessMessage_OR,ClinicLocations_toastSuccessMessage_S);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}

