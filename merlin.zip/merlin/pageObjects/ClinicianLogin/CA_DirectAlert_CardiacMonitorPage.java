package com.test.qa.ui.pageObjects.ClinicianLogin;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.activemq.store.kahadb.disk.util.DiskBenchmark.Report;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

/**
 * Clinic Administration page for regular user.
 * Navigate to Cardiac Monitor in sidebar.
 */
public class CA_DirectAlert_CardiacMonitorPage extends BasePage {

	//Below three references needs to be there and webelements as per pages
	private final By pageLoading = By.xpath("//*[@class='spinnerWrapper']");
	public WebDriver driver;
	public ExtentReport extentReport;
	public static Log logger = new Log();
	private final By cardiacMonitorHeader_OR =By.xpath("//div[@id=\"cardiac-monitor-wrapper\"]/div[1]/div[1]/h5");
	private final String cardiacMonitorHeader_S ="Cardiac Monitor header";

	public CA_DirectAlert_CardiacMonitorPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}


	private final By editButton_OR = By.xpath("//button[@id='edit']");
	private final String editButton_S = "Cardiac Page edit button";
	private final By cancelButton_OR = By.xpath("//button[@id='cancel']");
	private final String cancelButton_S ="Cardiac Monitor Page cancel button";
	private final By saveButton_OR = By.xpath("//button[@id='save']");
	private final String saveButton_S ="Cardiac Monitor Page save button";
	private final By showDevicesCloseBtn_OR = By.xpath("//button[@class='mat-focus-indicator mat-button mat-button-base']"); 
	private final String showDevicesCloseBtn_S = "Cardiac Page Show Devices popup Close button";
	private final By showDevices_OR = By.xpath("//div[@class='main-panel main-content']/div/div//following::a");
	private final String showDevices_S = "Cardiac Page Show Devices";
	private final By deviceList_OR = By.xpath("//tr[contains(@class, cdk-column-deviceName)]/td");
	private final String deviceList_S = "Cardiac Page Show Devices -> Device List ";
	private final By deviceListH2_OR = By.xpath("//h2[@id='mat-dialog-title-7']");
	private final String deviceListH2_S = "Cardiac Page Show Devices -> Device List heading ";
	//dummy data
	private final By ICM3500_OR = By.xpath("//span[contains(text(),'ICM3500')]");
	private final String ICM3500_S = "Cardiac device in list";

	private final By ICM4500_OR = By.xpath("//span[contains(text(),'ICM4500')]");
	private final String ICM4500_S = "Cardiac device in list";

	private final By radioYellowForICM3500_OR = By.xpath("//span[contains(text(),'Tachy Episode')]/parent::td//[@id='alertss']");
	private final String radioYellowForICM3500_S = "Yellow button of ICM device";

	private final By radioYellowForICM4500_OR = By.xpath("//span[contains(text(),'Tachy Episode')]/parent::td//[@id='alertss']");
	private final String radioYellowForICM4500_S = "Yellow button of ICM device";

	private final By radioRedForICM3500_OR = By.xpath("//span[contains(text(),'Tachy Episode')]/parent::td//[@id='alertss']");
	private final String radioRedForICM3500_S = "Yellow button of ICM device";

	private final By radioRedForICM4500_OR = By.xpath("//span[contains(text(),'Tachy Episode')]/parent::td//[@id='alertss']");
	private final String radioRedForICM4500_S = "Yellow button of ICM device";


	//Poojitha
	private final By symptomFlagYellowAlert_OR = By.xpath("");
	private final String symptomFlagYellowAlert_S = "symptom episode yellow Alert radio button";
	private final By symptomFlagRedAlert_OR = By.xpath("");
	private final String symptomFlagRedAlert_S = "symptom episode yellow Alert radio button";
	private final By symptomFlagAlertOff_OR = By.xpath("");
	private final String symptomFlagAlertOff_S = "symptom episode yellow Alert radio button";
	private final By cardiacAlertType_OR=By.xpath("//div[@class='alert-cont']//p");
	private final String cardiacAlertType_S = "Alerts label";
	//Ends here



	// The page object class should have the functional methods
	public void login(Login login) throws Exception {
		try {

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	//victor
	public void clickShowDevicesLink() throws InterruptedException {
		presenceOfElementLocatedWithoutReport(showDevices_OR, showDevices_S);
		clickElementWithoutReport(showDevices_OR, showDevices_S);
		loading();
	}

	public void verifyShowDevicesLink() {
		presenceOfElementLocatedWithReport(showDevices_OR, showDevices_S);
	}
	//victor
	public boolean verifyDeviceListPopup() throws InterruptedException
	{
		boolean isDeviceListPopup = false;
		scrollToViewWithoutReport(showDeviceCloseBtn_OR, showDeviceCloseBtn_S);
		//if(isElementPresent(showDevicesCloseBtn_OR, showDevicesCloseBtn_S)) { 
		if(getText(deviceListH2_OR, deviceListH2_S).contains("Cardiac Monitor devices")) {
			isDeviceListPopup =true;
			clickElement(deviceListH2_OR, deviceListH2_S);
		}
		return isDeviceListPopup;
	}
	
	//Vrushali
	public boolean validateDeviceInShowDeviceDialogBoxCM(String deviceName) {
  		Boolean flag = false;
  		
  		if(visibilityOfElementLocatedWithReport(showDeviceDialogBox_OR, showDeviceDialogBox_S)) {
  			extentReport.reportScreenShot("Show Devices DialogBox is displayed");
  			if(visibilityOfElementLocatedWithReport(By.xpath(deviceNameInShowDeviceDialogBox_OR.replace("$deviceName", deviceName)), deviceNameInShowDeviceDialogBox_S)) {
  				flag = true;
  				extentReport.reportScreenShot(deviceName+" is present");
  				
  			}
  		}
  		clickElement(showDeviceCloseBtn_OR, showDeviceCloseBtn_S);
  		return flag;
  	}

	//vrushali -- Do not use this 
	public List<WebElement> getDeviceList() {
		List<WebElement> deviceList = new ArrayList<WebElement>();
		deviceList = driver.findElements((deviceList_OR));
		return deviceList;
	}

	//victor -- Do not use this

	public void clickDeviceListPopupCloseBtn() throws InterruptedException {
		presenceOfElementLocatedWithoutReport(showDevicesCloseBtn_OR, showDevicesCloseBtn_S);
		clickElementWithoutReport(showDevicesCloseBtn_OR, showDevicesCloseBtn_S);
	}

	//Victor
	public boolean verifyEditButton() {
		Boolean isEditbuttonpresent=false;
		if(visibilityOfElementLocated(editButton_OR)) {
			isEditbuttonpresent=true;
			extentReport.reportScreenShot("Edit Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Edit Button is not displayed");
		}
		return isEditbuttonpresent;
	}

	public void clickClinicEditButton() throws InterruptedException
	{
		presenceOfElementLocated(editButton_OR);
		waitForLoading();
		extentReport.reportScreenShot("Edit button  is displayed");
		clickElement(editButton_OR);

	}

	public boolean verifyCancelButton() {
		Boolean isCancelButtonPresent=false;
		if(visibilityOfElementLocated(cancelButton_OR)) {
			isCancelButtonPresent=true;
			extentReport.reportScreenShot("Cancel Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Cancel Button is not displayed");
		}
		return isCancelButtonPresent;
	}

	public boolean verifySaveButton() {
		Boolean isSaveButtonPresent=false;
		if(visibilityOfElementLocated(saveButton_OR)) {
			isSaveButtonPresent=true;
			extentReport.reportScreenShot("Save Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Save Button is not displayed");
		}
		return isSaveButtonPresent;
	}

	public String verifydevices_ICM() {
		String success = "";
		if ((isDisplayedWithReportScreenshot(ICM3500_OR, ICM3500_S))&&(isDisplayedWithReportScreenshot(ICM4500_OR, ICM4500_S))){
			success = "Cardiac Monitor devices are available in Alert Types"; 
		} else {
			success = "Cardiac Monitor devices are NOT Available in Alert Types";
		}
		return success;

	}
	//need to change the xpath
	public boolean selectICMDeviceClassification() {
		Boolean isclassificationEditable = false;
		scrollToViewWithoutReport(radioYellowForICM3500_OR,
				radioYellowForICM3500_S);
		clickElement(radioYellowForICM3500_OR, radioYellowForICM3500_S);
		clickElement(radioYellowForICM4500_OR, radioYellowForICM4500_S);
		isclassificationEditable=true;
		return isclassificationEditable;
	}
	//need to change xpath
	public boolean selectICMDeviceAlertClassification() {
		Boolean isclassificationEditable = false;
		scrollToViewWithoutReport(radioRedForICM3500_OR,
				radioRedForICM3500_S);
		clickElement(radioRedForICM3500_OR, radioRedForICM3500_S);
		clickElement(radioRedForICM4500_OR, radioRedForICM3500_S);
		isclassificationEditable=true;
		return isclassificationEditable;
	}

	public boolean verifyICMDeviceClassification() {
		Boolean isICMDeviceNotChanged = false;
		if ((isSelectedWithoutReport(radioYellowForICM3500_OR, radioYellowForICM3500_S))&&(isSelectedWithoutReport(radioYellowForICM4500_OR, radioYellowForICM4500_S))){
			isICMDeviceNotChanged= true; 
		}
		return isICMDeviceNotChanged; 

	}

	public void clickSaveButton() {
		scrollToViewWithoutReport(saveButton_OR,saveButton_S);
		clickElement(saveButton_OR, saveButton_S);		  

	}

	public void clickEditButton() {
		scrollToViewWithoutReport(editButton_OR,editButton_S);
		clickElement(editButton_OR, editButton_S);	  

	}

	public void clickCancelButton() throws Exception {
		scrollToViewWithoutReport(cancelButton_OR,cancelButton_S);
		clickElement(cancelButton_OR, cancelButton_S);
		acceptAlert();
	}

	//vrushali

	//Poojitha
	public boolean validateSymptomEpisodeFlag()
	{
		boolean flagSelected = false;
		scrollToViewWithoutReport(symptomFlagYellowAlert_OR,symptomFlagYellowAlert_S);
		if(isSelectedWithoutReport(symptomFlagYellowAlert_OR,symptomFlagYellowAlert_S) || isSelectedWithoutReport(symptomFlagRedAlert_OR,symptomFlagRedAlert_S))
			flagSelected = true;
		else if(isSelectedWithoutReport(symptomFlagYellowAlert_OR,symptomFlagYellowAlert_S))
			flagSelected = false;
		return flagSelected;
	}

	public void selectAlert(String AlertType) {
		String xpath1="";
		String xpath2="";
		String xpath3 = "";
		String xpath_yellow="//mat-radio-group//*[@id='yellowButton']"; //dummy xpath
		String xpath_Red="//mat-radio-group//*[@id='redButton']"; //dummy xpath
		String xpath_Off="//mat-radio-group//*[@id='redButton']";//dummy xpath
		List<WebElement> li=driver.findElements(cardiacAlertType_OR);
		for(int i=1;i<=li.size();i++) {
			if(li.get(i).getText().contains(AlertType)) {
				int alertindex=i;
				System.out.println(alertindex);
				xpath1="("+xpath_yellow+")"+"["+alertindex+"]";
				xpath2="("+xpath_Red+")"+"["+alertindex+"]";
				xpath3="("+xpath_Off+")"+"["+alertindex+"]";
				WebElement redAlertRadio=driver.findElement(By.xpath(xpath2));
				WebElement yellowAlertRadio=driver.findElement(By.xpath(xpath1));
				WebElement alertOffRadio = driver.findElement(By.xpath(xpath3));
				if(redAlertRadio.isEnabled() || yellowAlertRadio.isSelected()) {
					scrollToViewWebElementWithoutReport(alertOffRadio, "Scroll down to validate all types of alerts");
					System.out.println(xpath3);
					alertOffRadio.click();
					extentReport.reportScreenShot("Alert has been turned off"+ AlertType);
				}
				else {
					redAlertRadio.click();
					extentReport.reportScreenShot("Alert Category changed to Urgent for the alert type: "+ AlertType);
				}
			}
		}	
	}
	//Ends here


	@Override
	public boolean verifyLandingPage() {
		Boolean verifyClinicProfilePage = false;
		if (isElementPresentwithoutException(cardiacMonitorHeader_OR, cardiacMonitorHeader_S)) {
			verifyClinicProfilePage = true;
			extentReport.reportScreenShot("Cardiac Monitor page is displayed successfully");
		}
		return verifyClinicProfilePage;
	}

	//-------------------- jeetendra ----------------------------------
	public boolean checkPatient_notification(String val1, String val2) {
		return false;

	}






	//Kundan
	//*[@id="cardiacAlertType"]/div/div[1]/div[1]
	private final By cardiac_BatteryLow_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[1]/div[1]/div/mat-label");
	private final String cardiac_BatteryLow_Alert_S = "Cardiac monitor tab Battery Low alerts";

	private final By cardiac_MonitorAtEndOfService_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[2]/div[1]/div/mat-label");
	private final String cardiac_MonitorAtEndOfService_S = "Cardiac monitor tab Monitor at End Of Service alerts";

	private final By cardiac_AFEpisode_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[3]/div[1]/div/mat-label");
	private final String cardiac_AFEpisode_Alert_S = "Cardiac monitor tab AF Episode alerts";

	private final By cardiac_ParameterErrors_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[2]/div[1]/div/mat-label");
	private final String cardiac_ParameterErrors_Alert_S = "Cardiac monitor tab Parameter Errors alerts";

	private final By cardiac_DeviceReset_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[4]/div[1]/div/mat-label");
	private final String cardiac_DeviceReset_Alert_S = "Cardiac monitor tab Device Reset alerts";

	private final By cardiac_MonitoringDisabled_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[5]/div[1]/div/mat-label");
	private final String cardiac_MonitoringDisabled_Alert_S = "Cardiac monitor tab Monitoring Disabled alerts";

	private final By cardiac_ContinuousAF_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[7]/div[1]/div/mat-label");
	private final String cardiac_ContinuousAF_Alert_S = "Cardiac monitor tab Continuous AF alerts";

	private final By cardiac_AFBurden_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[8]/div[1]/div/mat-label");
	private final String cardiac_AFBurden_Alert_S = "Cardiac monitor tab AF Burden alerts";

	private final By cardiac_VRateduringAF_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[9]/div[1]/div/mat-label");
	private final String cardiac_VRateduringAF_Alert_S = "Cardiac monitor tab VRateduringAF alerts";

	private final By cardiac_TachyEpisode_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[10]/div[1]/div/mat-label");
	private final String cardiac_TachyEpisode_Alert_S = "Cardiac monitor tabTachy Episode alerts";


	private final By cardiac_BradyEpisode_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[11]/div[1]/div/mat-label");
	private final String cardiac_BradyEpisode_Alert_S = "Cardiac monitor tab Brady Episode alerts";

	private final By cardiac_PauseEpisode_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[12]/div[1]/div/mat-label");
	private final String cardiac_PauseEpisode_Alert_S = "Cardiac monitor tab Pause Episode alerts";

	private final By cardiac_SymptomAlert_Alert_OR = By.xpath("//div[@id=\"cardiacAlertType\"]/div/div[2]/div[13]/div[1]/div/mat-label");
	private final String cardiac_SymptomAlert_Alert_S = "Cardiac monitor tab Symptom Alert alerts";

	private final By directAlert_redAlertsduringOffice_OR=By.xpath("//mat-select[@id=\"mat-select-18\"]/div/div[2]/div");
	private final String directAlert_redAlertsduringOffice_S="Direct Alert Red Alert during office hours";

	private final By directAlert_redAlertsAfterOffice_OR=By.xpath("//mat-select[@id=\"redAlertsAfterOffice\"]/div/div[2]/div");
	private final String directAlert_redAlertsAfterOffice_S="Direct Alert Red Alert after office hours";

	private final By directAlert_YellowAlertsduringOffice_OR=By.xpath("//mat-select[@id=\"yellowAlertsDuringOffice\"]/div/div[2]/div");
	private final String directAlert_YellowAlertsduringOffice_S="Direct Alert Yellow Alert during office hours";

	private final By directAlert_YellowAlertsAfterOffice_OR=By.xpath("//mat-select[@id=\"yellowAlertsDuringOffice\"]/div/div[2]/div");
	private final String directAlert_YellowAlertsAfterOffice_S="Direct Alert Yellow Alert after office hours";

	private final By directAlert_medicalTeamAlerts_OR=By.xpath("//mat-select[@id=\"medicalTeamAlerts\"]/div/div[2]/div");
	private final String directAlert_medicalTeamAlerts_S="Direct Alert medical Team Alerts";

	private final By directAlert_onCallPhysician_OR=By.xpath("//mat-select[@id=\"onCallPhysician\"]/div/div[2]/div");
	private final String directAlert_onCallPhysician_S="Direct Alert on Call Physician";

	private final By directAlert_DropDown_Email_Option_OR=By.xpath("//mat-option[@id=\"Email\"]");
	private final String directAlert_DropDown_Email_Option_S="Direct alert drop down email option";


	private final By directAlert_DropDown_Fax_Option_OR=By.xpath("//mat-option[@id=\"Fax\"]");
	private final String directAlert_DropDown_Fax_Option_S="Direct alert drop down fax option";


	private final By directAlert_DropDown_TextMessage_Option_OR=By.xpath("//mat-option[@id=\"Text Message\"]");
	private final String directAlert_DropDown_TextMessage_Option_S="Direct alert drop down TextMessage option";


	private final By directAlert_DropDown_Phone_Option_OR=By.xpath("//mat-option[@id=\"Phone\"]");
	private final String directAlert_DropDown_Phone_Option_S="Direct alert drop down Phone option";

	private final By directAlert_DropDown_None_Option_OR=By.xpath("//mat-option[@id=\"None\"]");
	private final String directAlert_DropDown_None_Option_S="Direct alert drop down Phone option";

	private final By ClinicContactInformation_SmsTextbox_OR=By.xpath("//input[@id=\"merlin_textbox_sms\"]");
	private final String ClinicContactInformation_SmsTextbox_S="Direct alert clinic contact information sms text box";

	private final By ClinicContactInformation_EmailTextbox_OR=By.xpath("//input[@id=\"merlin_textbox_emailAddress\"]");
	private final String ClinicContactInformation_EmailTextbox_S="Direct alert clinic contact information email text box";

	private final By ClinicContactInformation_CountryCodeTextbox_OR=By.xpath("//input[@id=\"merlin_textbox_countryCode\"]");
	private final String ClinicContactInformation_CountryCodeTextbox_S="Direct alert clinic contact information country code text box";

	private final By ClinicContactInformation_AreacodeTextbox_OR=By.xpath("//input[@id=\"merlin_textbox_areaCode\"]");
	private final String ClinicContactInformation_AreacodeTextbox_S="Direct alert clinic contact information area text box";

	private final By ClinicContactInformation_PhnTextbox_OR=By.xpath("//input[@id=\"merlin_textbox_phoneNum\"]");
	private final String ClinicContactInformation_PhnTextbox_S="Direct alert clinic contact information Phone text box";

	private final By redAlert_DuringOfficeHours_Email_OR=By.xpath("//div[@class='mat-select-value ng-tns-c149-76'][contains(.,'Email')]");
	private final String redAlert_DuringOfficeHours_Email_S="Red alert during office hours email seletion verification";

	private final By redAlert_AfterOfficeHours_Fax_OR=By.xpath("//div[@class='mat-select-value ng-tns-c149-78'][contains(.,'Fax')]");
	private final String redAlert_AfterOfficeHours_Fax_S="Red alert after office hours fax seletion verification";

	private final By yellowAlert_DuringOfficeHours_Textmessage_OR=By.xpath("//div[@class='mat-form-field-infix ng-tns-c31-79'][contains(.,'Text Message')]");
	private final String yellowAlert_DuringOfficeHours_Textmessage_S="yellow alert during office hours fax seletion verification";

	private final By yellowAlert_AfterOfficeHours_Textmessage_OR=By.xpath("//div[@class='mat-select-value ng-tns-c149-82'][contains(.,'Phone')]");
	private final String yellowAlert_AfterOfficeHours_Textmessage_S="yellow alert after office hours phone seletion verification";

	private final By oncall_Physciancontact_Email_OR=By.xpath("//div[@class='mat-select-value ng-tns-c149-87'][contains(.,'Email')]");
	private final String oncall_Physciancontact_Email_S="yellow alert after office hours phone seletion verification";

	private final By alertclassification_Battrylow_Redbutton_OR=By.xpath("//mat-radio-button[@id=\"redButton0\"]/label/div[1]/div[2]");
	private final String alertclassification_Battrylow_Redbutton_S="Alert classification Battery low Red button ";

	private final By alertclassification_Battrylow_Yellowbutton_OR=By.xpath("//mat-radio-button[@id=\"yellowButton0\"]/label/div[1]/div[2]");
	private final String alertclassification_Battrylow_Yellowbutton_S="Alert classification Battery low Yellow button ";








	public boolean verifyCardiacAlertIsnotPresent() {
		Boolean isCardiacAlertpresent=false;
		if(visibilityOfElementLocated(cardiac_BatteryLow_Alert_OR)) {
			isCardiacAlertpresent=true;
			extentReport.reportScreenShot("Battery Low Alert is displayed");
		}

		else {
			extentReport.reportScreenShot("Battery Low Alert is not displayed");
		}


		return isCardiacAlertpresent;

	}

	public void verifyFewCardiacAlertIspresent()
	{
		presenceOfElementLocatedWithReport(cardiac_AFEpisode_Alert_OR, cardiac_AFEpisode_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_BatteryLow_Alert_OR, cardiac_BatteryLow_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_MonitorAtEndOfService_Alert_OR, cardiac_MonitorAtEndOfService_S);
	}

	public void verifyAlertDisplayedwithClassification()
	{
		//Need to discuss how to write code for this
	}

	public void verifyAllCardiacAlertIsPresent()
	{
		presenceOfElementLocatedWithReport(cardiac_AFBurden_Alert_OR, cardiac_AFBurden_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_AFEpisode_Alert_OR, cardiac_AFEpisode_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_BatteryLow_Alert_OR, cardiac_BatteryLow_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_BradyEpisode_Alert_OR, cardiac_BradyEpisode_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_ContinuousAF_Alert_OR, cardiac_ContinuousAF_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_DeviceReset_Alert_OR, cardiac_DeviceReset_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_MonitorAtEndOfService_Alert_OR, cardiac_MonitorAtEndOfService_S);
		presenceOfElementLocatedWithReport(cardiac_MonitoringDisabled_Alert_OR, cardiac_MonitoringDisabled_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_ParameterErrors_Alert_OR, cardiac_ParameterErrors_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_PauseEpisode_Alert_OR, cardiac_PauseEpisode_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_SymptomAlert_Alert_OR, cardiac_SymptomAlert_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_TachyEpisode_Alert_OR, cardiac_TachyEpisode_Alert_S);
		presenceOfElementLocatedWithReport(cardiac_VRateduringAF_Alert_OR, cardiac_VRateduringAF_Alert_S);
	}

	public void verifyPatientAlertDropDown()
	{
		//Need to discuss how to validate drop down values 1200
	}

	public void verifySymptomEpisodeAlertMessage()
	{
		//Need to discuss how to verify symptom episode meesage 1250
	}

	public void verifySymptomEpisodeChange()
	{
		//Need to discuss how to verify 1260
	}

	public void selectUrgentAndStandardValueforAlerts()
	{
		clickElement(directAlert_redAlertsduringOffice_OR, directAlert_redAlertsduringOffice_S);
		clickElement(directAlert_DropDown_Fax_Option_OR, directAlert_DropDown_Fax_Option_S);
		clickElement(directAlert_redAlertsAfterOffice_OR, directAlert_redAlertsAfterOffice_S);
		clickElement(directAlert_DropDown_TextMessage_Option_OR, directAlert_DropDown_TextMessage_Option_S);
		clickElement(directAlert_YellowAlertsduringOffice_OR, directAlert_YellowAlertsduringOffice_S);
		clickElement(directAlert_DropDown_Fax_Option_OR, directAlert_DropDown_Fax_Option_S);
		clickElement(directAlert_YellowAlertsAfterOffice_OR, directAlert_YellowAlertsAfterOffice_S);
		clickElement(directAlert_DropDown_TextMessage_Option_OR, directAlert_DropDown_TextMessage_Option_S);
		clickElement(directAlert_onCallPhysician_OR, directAlert_onCallPhysician_S);
		clickElement(directAlert_DropDown_Fax_Option_OR, directAlert_DropDown_Fax_Option_S);

	}

	public void verifySelectedFieldAsMandatatory()
	{
		//Need to discuss how to verify it is mandatatory 1400
	}

	public void verifyClinicContactInformation()
	{
		Boolean email=isElementPresent(ClinicContactInformation_EmailTextbox_OR, ClinicContactInformation_EmailTextbox_S);		
		extentReport.reportScreenShot("Email text box is present "+ email);

		Boolean areacode=isElementPresent(ClinicContactInformation_AreacodeTextbox_OR, ClinicContactInformation_AreacodeTextbox_S);
		extentReport.reportScreenShot("Area code text box is present "+areacode);

		Boolean countrycode= isElementPresent(ClinicContactInformation_CountryCodeTextbox_OR, ClinicContactInformation_CountryCodeTextbox_S);
		extentReport.reportScreenShot("Country code text box is present "+ countrycode);

		Boolean phone= isElementPresent(ClinicContactInformation_PhnTextbox_OR, ClinicContactInformation_PhnTextbox_S);
		extentReport.reportScreenShot("Phone text box is present "+ phone);
	}

	public void editUrgentAndStandardValueforAlerts()
	{
		clickElement(directAlert_redAlertsduringOffice_OR, directAlert_redAlertsduringOffice_S);
		clickElement(directAlert_DropDown_Email_Option_OR, directAlert_DropDown_Email_Option_S);
		clickElement(directAlert_redAlertsAfterOffice_OR, directAlert_redAlertsAfterOffice_S);
		clickElement(directAlert_DropDown_Fax_Option_OR, directAlert_DropDown_Fax_Option_S);
		clickElement(directAlert_YellowAlertsduringOffice_OR, directAlert_YellowAlertsduringOffice_S);
		clickElement(directAlert_DropDown_TextMessage_Option_OR, directAlert_DropDown_TextMessage_Option_S);
		clickElement(directAlert_YellowAlertsAfterOffice_OR, directAlert_YellowAlertsAfterOffice_S);
		clickElement(directAlert_DropDown_Phone_Option_OR, directAlert_DropDown_Phone_Option_S);
		clickElement(directAlert_onCallPhysician_OR, directAlert_onCallPhysician_S);
		clickElement(directAlert_DropDown_Email_Option_OR, directAlert_DropDown_Email_Option_S);
		clickElement(ClinicContactInformation_SmsTextbox_OR, ClinicContactInformation_SmsTextbox_S);
		clear(ClinicContactInformation_SmsTextbox_OR, ClinicContactInformation_SmsTextbox_S);
		sendKeys(ClinicContactInformation_SmsTextbox_OR, "Cardiac Monitor");

	}

	public void verifyEditedUrgentAndStandardValueforAlerts()
	{
		presenceOfElementLocatedWithReport(redAlert_AfterOfficeHours_Fax_OR, redAlert_AfterOfficeHours_Fax_S);
		presenceOfElementLocatedWithReport(redAlert_DuringOfficeHours_Email_OR, redAlert_DuringOfficeHours_Email_S);
		presenceOfElementLocatedWithReport(yellowAlert_AfterOfficeHours_Textmessage_OR, yellowAlert_DuringOfficeHours_Textmessage_S);
		presenceOfElementLocatedWithReport(yellowAlert_DuringOfficeHours_Textmessage_OR, yellowAlert_DuringOfficeHours_Textmessage_S);
		presenceOfElementLocatedWithReport(oncall_Physciancontact_Email_OR, oncall_Physciancontact_Email_S);
	}

	public void editAlertClassification()
	{
		clickElement(alertclassification_Battrylow_Yellowbutton_OR, alertclassification_Battrylow_Yellowbutton_S);

	}

	public void verifyEditedAlertClassification()
	{
		//Need to discuss how to verify  2300 and 2500
	}

	public void verifyDataIsNotSavedPopup()
	{
		String alerttest= driver.switchTo().alert().getText();
		System.out.println("Popup alert  tetx is "+alerttest);
		driver.switchTo().alert().accept();
	}





	//End
























	//snehal

	private final By showDeviceDialogBox_OR = By.xpath("//div[@class='cdk-overlay-pane']//app-show-devices-dialog/h2");
	private final String showDeviceDialogBox_S = "Show Devices Dialogue Box";

	private final String deviceNameInShowDeviceDialogBox_OR = "//td[@class='mat-cell cdk-cell cdk-column-deviceName mat-column-deviceName ng-star-inserted'][contains(text(),'$deviceName')]";
	private final String deviceNameInShowDeviceDialogBox_S = "Device Name under Show Devices Dialogue Box";

	private final By showDeviceCloseBtn_OR = By.xpath("//mat-dialog-actions/button/span");
	private final String showDeviceCloseBtn_S = "Show Devices Close Button";

	public boolean validateDeviceInShowDeviceDialogBox(String deviceName) {
		Boolean flag = false;

		if(visibilityOfElementLocatedWithReport(showDeviceDialogBox_OR, showDeviceDialogBox_S)) {
			extentReport.reportScreenShot("Show Devices DialogBox is displayed");
			if(visibilityOfElementLocatedWithReport(By.xpath(deviceNameInShowDeviceDialogBox_OR.replace("$deviceName", deviceName)), deviceNameInShowDeviceDialogBox_S)) {
				flag = true;
				extentReport.reportScreenShot(deviceName+" is present");

			}
		}
		clickElement(showDeviceCloseBtn_OR, showDeviceCloseBtn_S);
		return flag;
	}


	private final By allCradiacMonitor_OR=By.xpath("(//div[@formarrayname='alertTypes']//mat-label)");

	public boolean validateCardiacMonitorAlertValueInTable(String ReadDataBasedOnJuridiction) throws InterruptedException, IOException{
		boolean flag = true;
		int i;



		List<WebElement> allAlertsCardiacMonitor=findElements(allCradiacMonitor_OR);
		if(ReadDataBasedOnJuridiction.equalsIgnoreCase("US")) {
			ArrayList<String> directAlerts_US=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_US");
			for (String string : directAlerts_US) {
				System.out.println(string);
			}
			//Collections.sort(directAlerts);
			//&& statement will be removed once hidden value "Excessive charge time" will come in UI
			for (i=1;i<allAlertsCardiacMonitor.size();i++)
			{

				String AlertCardiacMonitor=(driver.findElement(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)["+i+"]"))).getText().trim();
				String alert1=directAlerts_US.get(i-1);
				System.out.println(alert1);
				System.out.println(AlertCardiacMonitor);
				if(!directAlerts_US.get(i-1).equalsIgnoreCase(AlertCardiacMonitor)) {
					flag=false;
					break;

				}
			}
		}
		else {
			ArrayList<String> directAlerts_OUS=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_OUS");
			for (String string : directAlerts_OUS) {
				System.out.println(string);
			}
			//Collections.sort(directAlerts);
			//&& statement will be removed once hidden value "Excessive charge time" will come in UI
			for (i=1;i<allAlertsCardiacMonitor.size();i++)
			{

				String AlertCardiacMonitor=(driver.findElement(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)["+i+"]"))).getText().trim();
				String alert1=directAlerts_OUS.get(i-1);
				System.out.println(alert1);
				System.out.println(AlertCardiacMonitor);
				if(!directAlerts_OUS.get(i-1).equalsIgnoreCase(AlertCardiacMonitor)) {
					flag=false;
					break;

				}

			}


		}
		return flag;
	}



	public void validateSaveButton() {
		elementToBeClickable(saveButton_OR, saveButton_S);
		clickElement(saveButton_OR, saveButton_S);
	}









	private final By redRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'redButton')]");
	private final String redRadioButton_S = "RedRadioButton";

	private final By yellowRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'yellowButton')]");
	private final String yellowRadioButton_S = "YellowRadioButton";

	private final By offRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'offButton')]");
	private final String offRadioButton_S = "OFFRadioButton";

	//author :bhupendra
	public String verifyAlertClassificationStatus(String alertTypeName) throws InterruptedException {
		String statusFlg="";
		List<WebElement> alerttTypes = findElementslist(allCradiacMonitor_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if (Red.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);", Red.get(i));
					statusFlg= "red";
				}					
				else if (Yellow.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);", Yellow.get(i));
					statusFlg= "yellow";			
				}
				else if (Off.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);", Off.get(i));
					statusFlg= "off";			
				}else {
					statusFlg="0";
				}
				break;
			}
		}
		return statusFlg;
	}


	//Author:Bhupendra
	public String changeAlertClassification(String alertTypeName) throws InterruptedException {
		String radioButtonEnabled = "";
		JavascriptExecutor js = (JavascriptExecutor) driver;

		List<WebElement> alerttTypes = findElementslist(allCradiacMonitor_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if (Red.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);",Yellow.get(i));
					js.executeScript("arguments[0].click();", Yellow.get(i));
					radioButtonEnabled="yellow";
					break;
				}					
				else if (Yellow.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);",Off.get(i));
					js.executeScript("arguments[0].click();", Off.get(i));
					radioButtonEnabled="off";	
					break;
				}
				else if (Off.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);",Red.get(i));
					js.executeScript("arguments[0].click();", Red.get(i));
					radioButtonEnabled="red";	
					break;
				}

				break;
			}
		}
		return radioButtonEnabled;
	}


	public void validateCancelButton() {
		elementToBeClickable(saveButton_OR, saveButton_S);
		clickElement(saveButton_OR, saveButton_S);
	}



	public void editAndVerifyAlertCategory(String ReadDataBasedOnJuridiction) throws Exception {
		List<String>  alertSTatusUpdated= new ArrayList<String>() ,
				alertSTatusAfterUpdated= new ArrayList<String>(),
				alertSTatusAfterSave= new ArrayList<String>();
		if(ReadDataBasedOnJuridiction.equalsIgnoreCase("US")) {

			ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_US");



			for(int j=0;j<3;j++) {
				int i =0;
				for (String alertName : directAlerts) {	
					alertSTatusUpdated.add( changeAlertClassification(alertName));
					alertSTatusAfterUpdated.add(verifyAlertClassificationStatus(alertName));
					assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterUpdated.get(i)));	
					extentReport.reportScreenShot("Changed  Alert Categories  to "+alertSTatusUpdated.get(i)+" for "+alertName);				
					i++;					
				}
				validateSaveButton();
				i=0;
				for (String alertName : directAlerts) {						
					alertSTatusAfterSave.add(verifyAlertClassificationStatus(alertName));
					assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterSave.get(i)));
					extentReport.reportScreenShot("Changed  Alert Categories to "+alertSTatusAfterSave.get(i)+" for "+alertName);				
					i++;
				}
				alertSTatusUpdated.clear();
				alertSTatusAfterUpdated.clear();
				alertSTatusAfterSave.clear();
				if(j!=2) {
					//	clickClinicEditButton();
				}

			}
		}
		else {

			ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_OUS");



			for(int j=0;j<3;j++) {
				int i =0;
				for (String alertName : directAlerts) {	
					alertSTatusUpdated.add( changeAlertClassification(alertName));
					alertSTatusAfterUpdated.add(verifyAlertClassificationStatus(alertName));
					assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterUpdated.get(i)));	
					extentReport.reportScreenShot("Changed  Alert Categories  to "+alertSTatusUpdated.get(i)+" for "+alertName);				
					i++;					
				}
				validateSaveButton();
				i=0;
				for (String alertName : directAlerts) {						
					alertSTatusAfterSave.add(verifyAlertClassificationStatus(alertName));
					assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterSave.get(i)));
					extentReport.reportScreenShot("Changed  Alert Categories to "+alertSTatusAfterSave.get(i)+" for "+alertName);				
					i++;
				}
				alertSTatusUpdated.clear();
				alertSTatusAfterUpdated.clear();
				alertSTatusAfterSave.clear();
				if(j!=2) {
					//	clickClinicEditButton();
				}

			}
		}

	}

	public void editAndVerifyAlertCategoryAfterCancellation(String ReadDataBasedOnJuridiction) throws Exception {
		List<String>  alertSTatusUpdated= new ArrayList<String>() ,
				alertSTatusAfterUpdated= new ArrayList<String>(),
				alertSTatusAfterCancel= new ArrayList<String>(),
				alertStatusExisting=new ArrayList<String>();
		ArrayList<String> directAlerts=null;
		if(ReadDataBasedOnJuridiction.equalsIgnoreCase("US")) {				
			directAlerts=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_US");
		}else {
			directAlerts=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_OUS");
		}

		int i=0;

		for (String alertName : directAlerts) {
			alertStatusExisting.add(verifyAlertClassificationStatus(alertName));
			alertSTatusUpdated.add( changeAlertClassification(alertName));
			alertSTatusAfterUpdated.add(verifyAlertClassificationStatus(alertName));
			assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterUpdated.get(i)));	
			extentReport.reportScreenShot("Changed  Alert Categories  to "+alertSTatusUpdated.get(i)+" for "+alertName);				
			i++;					
		}
		verifyCancelButton();
		clickCancelButton();
		i=0;
		for (String alertName : directAlerts) {						
			alertSTatusAfterCancel.add(verifyAlertClassificationStatus(alertName));
			assertEquals(true,alertSTatusAfterCancel.get(i).equalsIgnoreCase(alertSTatusAfterCancel.get(i)));
			extentReport.reportScreenShot("Changed  Alert Categories to "+alertSTatusAfterCancel.get(i)+" for "+alertName);				
			i++;
		}


	}



	public String verifyDisableOREnableStatus(String ReadDataBasedOnJuridiction) throws Exception {
		String radioButtonstatus = "0";
		List<String>  alertSTatusUpdated= new ArrayList<String>() ,
				alertSTatusAfterUpdated= new ArrayList<String>(),
				alertSTatusAfterCancel= new ArrayList<String>(),
				alertStatusExisting=new ArrayList<String>();
		String radioButtonEnabled = "";
		int i=0;
		JavascriptExecutor js = (JavascriptExecutor) driver;

		List<WebElement> alerttTypes = findElementslist(allCradiacMonitor_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		ArrayList<String> directAlerts=null;
		if(ReadDataBasedOnJuridiction.equalsIgnoreCase("US")) {				
			directAlerts=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_US");
		}else {
			directAlerts=TestDataProvider.readDirectAlertsFromExcel("Cardiac_Monitor_OUS");
		}


		for(i=1;i<=directAlerts.size(); i++) {


			if(alerttTypes.get(i).getText().equalsIgnoreCase(directAlerts.get(i))){
				if (!(Red.get(i).isEnabled()==true )) {
					scrollToViewlist(alerttTypes.get(i));
					extentReport.reportScreenShot("Alert \""+directAlerts.get(i)+"\" red status id disabled.");				
					radioButtonstatus="1";					   
				}else {
					radioButtonstatus=directAlerts.get(i)+" red";	
					return radioButtonstatus;
				}
				if (!(Yellow.get(i).isEnabled()==true )) {
					scrollToViewlist(alerttTypes.get(i));
					extentReport.reportScreenShot("Alert \""+directAlerts.get(i)+"\" yellow status id disabled.");				
					radioButtonstatus="1";					   
				}else {
					radioButtonstatus=directAlerts.get(i)+" yellow";	
					return radioButtonstatus;
				}
				if (!(Off.get(i).isEnabled()==true )) {
					scrollToViewlist(alerttTypes.get(i));
					extentReport.reportScreenShot("Alert \""+directAlerts.get(i)+"\" Off status id disabled.");				
					radioButtonstatus="1";					   
				}else {
					radioButtonstatus=directAlerts.get(i)+" Off";	
					return radioButtonstatus;
				}
			}

		}
		return radioButtonstatus;


	}
}