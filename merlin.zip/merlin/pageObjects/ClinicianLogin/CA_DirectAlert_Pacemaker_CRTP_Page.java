
package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

/**
 * Clinic Administration page for regular user.
 * Navigate to Pacemaker / CRT-P in sidebar.
 */
public class CA_DirectAlert_Pacemaker_CRTP_Page extends BasePage {

	//Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	private final By pacemakerCRTP_NavigationActive = By.xpath("//li[@class='nav-item ng-star-inserted active']/a[@class='nav-link']/span[@class='sidebar-normal']");
	
	//ChandraMohan updated the XPath as NOT Working.
	private final By pacemakerCRTP_PageHeader_OR = By.xpath("//div[@id='pacemaker-wrapper']//h5");
	private final String pacemakerCRTP_PageHeader_S = "Pacemaker CRTP header";

	private final By pacemakerCRTP_link_OR = By.xpath("//*[@id=\"direct-alert-settings\"]/ul/li[2]/a/span");
	private final String pacemakerCRTP_link_S = "Pacemaker CRTP link";
	private final By clinicProfileNavigation = By.xpath("//div[@class='sidebar-wrapper']/ul[@class='nav']/li[@class='nav-item ng-star-inserted'][1]");

	//ChandraMohan updated the XPath as NOT Working.
	private final By editButton_OR = By.xpath("//button[@id='edit']");
	private final String editButton_S = "Edit Button Pacemaker Page";

	private final By cancelButton_OR = By.xpath("//button[@class='mat-focus-indicator btn-styl mat-raised-button mat-button-base mat-accent ng-star-inserted']");
	private final String  cancelButton_S = "Cancel Button Pacemaker Page";

	private final By saveButton_OR = By.xpath("//button[@class='mat-focus-indicator btn-styl mat-raised-button mat-button-base mat-primary ng-star-inserted']");
	private final String  saveButton_S = "Save Button Pacemaker Page";
	private final By showDevicesButton = By.xpath("//div[@class='row']/div[3]/a");
	private final By showDevicesCloseButton = By.xpath("//button[contains(@class,'mat-focus-indicator mat-button mat-button-base')]");

	private final By textMessageField_OR = By.xpath("//input[@id=\"merlin_textbox_textMessageId\"]");
	private final String  textMessageField_S = "TextMessage Field in Pacemaker Page";

	private final By emailField_OR = By.xpath("//input[@id=\"merlin_textbox_email\"]");
	private final String  emailField_S = "Email Field in Pacemaker Page";


	//private final By phoneCountryCodeField = By.xpath("//div[@class='col-xs-5 row'][2]/div[@class='col-xs-2'][1]/merlin-textbox/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/input[contains(@id,'')]");
	private final By phoneCountryCodeField1 = By.xpath("//div[2]/div[4]//input[@id=\"merlin_textbox_countryCode\"]");
	//private final By phoneAreaCodeField = By.xpath("//div[@class='col-xs-5 row'][2]/div[@class='col-xs-2'][2]/merlin-textbox/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/input[contains(@id,'')]");
	private final By phoneAreaCodeField1 = By.xpath("//app-contact-information-distribustion/div[2]/div[2]/div[3]/merlin-textbox/mat-form-field/div/div[1]");
	//private final By phoneNumberField = By.xpath("//div[@class='col-xs-5 row'][2]/div[@class='col-xs-4']/merlin-textbox/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/input[contains(@id,'')]");
	private final By phoneNumberField1 = By.xpath("//div[2]/div[4]//input[@id=\"merlin_textbox_phoneNum\"]");
	private final By faxCountryCodeField = By.xpath("//div[@class='col-xs-6 row']/span[@class='col-xs-2'][1]/merlin-textbox/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/input[contains(@id,'')]");
	private final By faxAreaCodeField = By.xpath("//div[@class='col-xs-6 row']/span[@class='col-xs-2'][2]/merlin-textbox/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/input[contains(@id,'')]");
	private final By faxNumberField = By.xpath("//div[@class='col-xs-6 row']/span[@class='col-xs-4']/merlin-textbox/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/input[contains(@id,'')]");
	private final By instructionalTextOfAlertTransmissions= By.xpath("//app-pacemaker-alert-settings/p");
	private final By physicianInfoIcon = By.xpath("//app-alert-settings-distribution//p[2]/img");
	private final By physicianInfoMessage = By.xpath("//div[@class='cdk-overlay-container']/div[@class='cdk-overlay-connected-position-bounding-box']");

	private final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");

	private final By showDevicesLink_OR = By.xpath("//div[@id='pacemaker-wrapper']//div/a");
	private final String showDevicesLink_S = "Show Devices Link on Pacemaker page";
	private final By allPacemakerAppAlert_OR=By.xpath("//div[@id='pacemakerAlertType']//mat-label");
	private final String allPacemakerAppAlert_S="Mobile App Alerts";

	//author: bhupendra
	private final By alertType_OR =By.xpath("//div[@formarrayname='alertTypes']//mat-label");
	private final String alertTyp_S = "AlertType";

	private final By redRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'redButton')]");
	private final String redRadioButton_S = "RedRadioButton";

	private final By yellowRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'yellowButton')]");
	private final String yellowRadioButton_S = "YellowRadioButton";

	private final By offRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'offButton')]");
	private final String offRadioButton_S = "OFFRadioButton";


	private final By informPatientCheckbox_OR =By.xpath("//mat-checkbox[@id='checkboxes']/label/div");
	private final String informPatientCheckbox_S = "OFFRadioButton";
	//end of region author:bhupendra

	public static Log logger = new Log();

	public CA_DirectAlert_Pacemaker_CRTP_Page(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	/*
	 * ----------------
	 * Helper functions
	 * ----------------
	 */

	private boolean elementVisibleOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {

			if (!verifyLandingPage()) {
				extentReport.reportFail(reportFailMsg);
				return false;
			}

			invisibilityOfElementLocated(pageLoading);
			waitForPageLoad();

			if (visibilityOfElementLocated(element)) {
				extentReport.reportPass(reportPassMsg);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		extentReport.reportFail(reportFailMsg);
		return false;
	}
	//mohan
	private final By directAlertSettings_CRTP_OR =By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/icd-crt-d/mobile-app-transmitter']/ancestor::ul/li[4]/div/span");
	private final String directAlertSettings_CRTP_S="Direct Alert settings Link in Left Nav";
	public boolean verifyDirectAlertTab() {
		Boolean isDirectAlertTabpresent=false;
		loading();
		if(visibilityOfElementLocated(directAlertSettings_CRTP_OR)) {
			isDirectAlertTabpresent=true;
			extentReport.reportScreenShot("Direct Alert is displayed");
		}
		else {
			extentReport.reportScreenShot("Direct Alert is not displayed");
		}
		return isDirectAlertTabpresent;
	}
	private final By red_Alert_OR = By.xpath(
			"//*[@id=\"pacemakerProfileForm\"]/div[1]/div/app-alert-distribution/form/div/div[1]/h4");
	private final String red_Alert_S = "Red Alert ";
	
	private final By yellow_alert_OR = By.xpath(
			"//*[@id=\"pacemakerProfileForm\"]/div[1]/div/app-alert-distribution/form/div/div[1]/h4");
	private final String yellow_alert_S = "Red Alert ";
	public boolean verifyRedAlert() {
		Boolean alert=false;
		if(visibilityOfElementLocatedWithReport(red_Alert_OR,red_Alert_S)) {
			alert=true;
			
		}
		
		return alert;
	}
	
	public boolean verifyYellowAlert() {
		Boolean alert=false;
		if(visibilityOfElementLocatedWithReport(yellow_alert_OR,yellow_alert_S)) {
			alert=true;
			
		}
		
		return alert;
	}
	
	
	 private final By yelloAlertsDuringOffice_OR =By.xpath("//*[@id=\"yellowAlertsDuringOffice\"]/div/div[1]/span/span");
	    private final String yelloAlertsDuringOffice_S = "RedRadioButton";
		
		private final By yelloAlertsAfterOffice_OR =By.xpath("//*[@id=\"yellowAlertsAfterOffice\"]/div/div[1]/span/span");
	    private final String yelloAlertsAfterOffice_S = "RedRadioButton";


	  public String yellowalertduringofficehours() {
			String alert =getText(yelloAlertsDuringOffice_OR,yelloAlertsDuringOffice_S);
			return alert;
		}
	  
	  public String yellowalertafterofficehours() {
			String alert =getText(yelloAlertsAfterOffice_OR,yelloAlertsAfterOffice_S);
			return alert;
		}
	  
		private final By Send_RedAlertsduringOfficeHoursvalue_OR = By.xpath("//*[@id=\"mat-select-18\"]/div/div[1]/span/span");
		private final String Send_RedAlertsduringOfficeHoursvalue_S = "Send RedAlerts during OfficeHours value  ";
		
		private final By SendRedAlertsafterOfficeHoursto_OR = By.xpath("//*[@id=\"redAlertsAfterOffice\"]/div/div[1]/span/span");
		private final String SendRedAlertsafterOfficeHoursto_S = "Send RedAlerts After OfficeHours value  ";
	  public String UrgentAlertsduringofficehours() {
			String alert =getText(Send_RedAlertsduringOfficeHoursvalue_OR,Send_RedAlertsduringOfficeHoursvalue_S);
			return alert;
		}
	  public String UrgentAlertsAfterofficehours() {
			String alert =getText(SendRedAlertsafterOfficeHoursto_OR,SendRedAlertsafterOfficeHoursto_S);
			return alert;
		}
	  private final By medicalteamnotificationsettingafterhours_OR =By.xpath("//*[@id=\"medicalTeamAlerts\"]/div/div[1]/span/span");
	  private final String medicalteamnotificationsettingafterhours_S = "medical team notification setting afterhours";
		
		private final By OnCallPhysiciancontactinformation_OR =By.xpath("//*[@id=\"onCallPhysician\"]/div/div[1]/span/span");
	  private final String OnCallPhysiciancontactinformation_S = "OnCall Physician contact information";
	  private final By allMerlinHomeAlert_OR=By.xpath("(//div[@formarrayname='alertTypes']//mat-label)");
		private final String allMerlinHomeAlert_S="Merlin@Home Alert Name";
		
		public boolean validatepacemakerAlertValueInTable() throws InterruptedException, IOException{
			boolean flag = true;
			int i;

			//clickElement(expandAlert_OR, expandAlert_S);
			By alertname=By.xpath("//mat-label[text()='Alert Type'])");
			scrollToView(alertname);

			List<WebElement> allAlertsMerlinHome=findElements(allMerlinHomeAlert_OR);
			ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("Pacemaker");
			for (String string : directAlerts) {
				System.out.println(string);
			}
			//Collections.sort(directAlerts);
			//&& statement will be removed once hidden value "Excessive charge time" will come in UI
			for (i=1;i<=allAlertsMerlinHome.size();i++)
			{

				String AlertMerlinHome=(driver.findElement(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)["+i+"]"))).getText().trim();
				String alert1=directAlerts.get(i-1);
				System.out.println(alert1);
				System.out.println(AlertMerlinHome);
				if(!directAlerts.get(i-1).equalsIgnoreCase(AlertMerlinHome)) {
					flag=false;
					break;

				}

			}
			return flag;

			}
		
		
		public String changeAlertClassification(String alertTypeName, String classification) throws Exception {
	  		String radioButtonEnabled = "";
	  		JavascriptExecutor js = (JavascriptExecutor) driver;
	  		
	  		List<WebElement> alerttTypes = findElementslist(alertType_OR);
	  		List<WebElement> Red = findElementslist(redRadioButton_OR);
	  		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
	  		List<WebElement> Off = findElementslist(offRadioButton_OR);
	  		for (int i = 0; i < alerttTypes.size(); i++) {
	  			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
	  				switch (classification){
	  				case "Red":
	  					if (!Red.get(i).isSelected()) {
	  						
							js.executeScript("arguments[0].click();", Red.get(i));
							radioButtonEnabled="Red button is clicked";
							scrollToViewlist(Red.get(i));
	  					}
	  					else
	  						radioButtonEnabled="Red button is not clicked";
	  					break;
	  				case "Yellow":
	  					if (!Yellow.get(i).isSelected()) {
	  						
							js.executeScript("arguments[0].click();", Yellow.get(i));
							radioButtonEnabled="Yellow button is clicked";
							scrollToViewlist(Yellow.get(i));
	  					}
	  					else
	  						radioButtonEnabled="Yellow button is not clicked";
	  					break;
	  				case "OFF":
	  					if (!Off.get(i).isSelected()) {
	  						
							js.executeScript("arguments[0].click();", Off.get(i));
							radioButtonEnabled="OFF button is clicked";
							scrollToViewlist(Off.get(i));
	  					}
	  					else
	  						radioButtonEnabled="OFF button is not clicked";		
	  					break;
	  				}
	  				
	  			
	  				break;
	  			}
	  			
	  		}
	  				
	  		//Shafiya added to know which alert type radio button is clicked

	  		extentReport.reportScreenShot(radioButtonEnabled+ " for "+alertTypeName+ " Alert Type ");
	  		return radioButtonEnabled;
	  	} 
	public Boolean medicalteamnotificationsettingafterhours() {
			//String alert =getText(medicalteamnotificationsettingafterhours_OR,medicalteamnotificationsettingafterhours_S);
			Boolean alert=false;
			if(visibilityOfElementLocatedWithReport(medicalteamnotificationsettingafterhours_OR,medicalteamnotificationsettingafterhours_S)) {
				alert=true;
				
			}
			
			return alert;
		}

	public Boolean OnCallPhysiciancontactinformation() {
			//String alert =getText(OnCallPhysiciancontactinformation_OR,OnCallPhysiciancontactinformation_S);
		Boolean alert=false;
		if(visibilityOfElementLocatedWithReport(OnCallPhysiciancontactinformation_OR,OnCallPhysiciancontactinformation_S)) {
			alert=true;
			
		}
		
		return alert;
		}
	
	
	private final By ALERTTYPE_OR = By.xpath("//*[@id=\"pacemakerAlertType\"]/div/div[2]/div[1]");
	private final String ALERTTYPE_S = "Alert Type";
	private final By ALERTCLASSIFICATION_OR = By.xpath("//*[@id=\\\"pacemakerAlertType\\\"]/div/div[2]/div[1]");
	private final String ALERTCLASSIFICATION_S = "Alert Classfication";
	private final By INFORMPATIENT_OR = By.xpath("(//*[@id=\"merlinAlertType\"]/div/div[2]/div/div[3]//mat-checkbox");
	private final String INFORMPATIENT_S = "Inform Pattient";
	
	public boolean verifyAlertTypelist() throws Exception {
		Boolean isdisplayed = false;
		scrollToView(ALERTTYPE_OR);
		//clickElement(additionalAlertNotif_sendNotif_1st_select_Arrow_OR, additionalAlertNotif_sendNotif_1st_select_Arrow_S);
		if (isDisplayedWithoutReport(ALERTTYPE_OR, ALERTTYPE_S) && isDisplayedWithoutReport(ALERTCLASSIFICATION_OR, ALERTCLASSIFICATION_S) ) 
			isdisplayed = true;
				
		else
			isdisplayed = false;
			
	
		
		return isdisplayed;
	}
	private boolean elementEditableOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			invisibilityOfElementLocated(pageLoading);
			waitForPageLoad();
			if (isEnabled(element)) {
				extentReport.reportScreenShot(reportPassMsg);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		extentReport.reportFail(reportFailMsg);
		return false;
	}
	
	private final By INFORMPATIENTcheckbox_OR = By.xpath("//*[@id=\"checkboxes0-input\"]");
	private final String INFORMPATIENTcheckbox_S  ="INFORM PATIENT";

	public boolean checkboxvalue() throws Exception{	
		Boolean isExpanded = false;
  		try {
  			
  			isExpanded= Boolean.parseBoolean(getAttributeWithReport(INFORMPATIENTcheckbox_OR,"aria-checked",INFORMPATIENTcheckbox_S));
  			
  		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return isExpanded;
  		
  	}
	private void clickElementOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			if (!elementVisibleOnPage(element, "Element found on page", "Element not found on page")) {
				extentReport.reportFail(reportFailMsg);
				return;
			}

			waitForElementToBeClickable(element);
			//invisibilityOfElementLocated(pageLoading);
			clickElement(element);
			extentReport.reportPass(reportPassMsg);
			waitForLoading();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	private void fillFieldWithValue(By field, String value, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			clickElementOnPage(field, "Field element clicked", "Could not click field element");
			sendKeys(field, value);
			extentReport.reportPass(reportPassMsg);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/*
	 * ----------------
	 * Public functions
	 * ----------------
	 */

	/*
	 * Click functions
	 */
	
	public void clickEditButton() throws Exception {
		clickElementOnPage(editButton_OR, "Clicked on Edit Button", "Could not click on Edit Button");
	}
	public void pacemakerCRTP_linkclick() throws Exception {
		//clickElementOnPage(pacemakerCRTP_link_OR, "Clicked on Edit Button", "Could not click on Edit Button");
		clickElement(pacemakerCRTP_link_OR, pacemakerCRTP_link_S);
	}
	public void clickCancelButton() throws Exception {
		clickElementOnPage(cancelButton_OR, "Clicked on Cancel Button", "Could not click on Cancel Button");
	}
	//edited by bhupendra (replace click with new carmel function)
	public void clickSaveButton() throws Exception {
		elementToBeClickable(saveButton_OR, saveButton_S);
		clickElement(saveButton_OR, saveButton_S);
	}

	public void clickShowDevicesButton() throws Exception {
		clickElementOnPage(showDevicesButton, "Clicked on Show Devices link", "Could not click on Show Devices link");
	}

	public void clickShowDevicesCloseButton() throws Exception {
		clickElementOnPage(showDevicesCloseButton, "Clicked on Show Devices Close Button", "Could not click on Show Devices Close Button");
	}

	/*
	 * Element locator functions
	 */

	public boolean findEditButton() throws Exception {
		return elementVisibleOnPage(editButton_OR, "Found Edit Button", "Did not find Edit Button");
	}

	public boolean findCancelButton() throws Exception {
		return elementVisibleOnPage(cancelButton_OR, "Found Cancel Button", "Did not find Cancel Button");
	}

	public boolean findSaveButton() throws Exception {
		return elementVisibleOnPage(saveButton_OR, "Found Save Button", "Did not find Save Button");
	}

	public boolean findTextMessageField() throws Exception {
		return elementVisibleOnPage(textMessageField_OR, "Found Text Message field", "Did not find Text Message field");
	}

	public boolean findPhoneNumberField() throws Exception {
		System.out.println("Phone Number Field Verification");
		return elementVisibleOnPage(phoneNumberField1, "Found Phone Number field", "Did not find Phone Number field");
	}

	public boolean findEmailField() throws Exception {
		return elementVisibleOnPage(emailField_OR, "Found Email field", "Did not find Email field");
	}

	public boolean findFaxField() throws Exception {
		return elementVisibleOnPage(faxNumberField, "Found Fax field", "Did not find Fax field");
	}

	public boolean findPhysicianInfoMessage() throws Exception {
		if (!elementVisibleOnPage(physicianInfoIcon, "Found Physician info icon", "Did not find Physician info icon")) {
			return false;
		}

		mouseHover(physicianInfoIcon);
		return elementVisibleOnPage(physicianInfoMessage, "Found Physician info message", "Did not find Physician info message");
	}

	/*
	 * Field fill functions
	 */

	public void fillPhoneNumberWithCodes(String countryCode, String areaCode, String number) throws Exception {
		fillFieldWithValue(phoneCountryCodeField1, countryCode, "Filled Phone Country Code field", "Could not fill Phone Country Code field");
		fillFieldWithValue(phoneAreaCodeField1, areaCode, "Filled Phone Area Code field", "Could not fill Phone Area Code field");
		fillFieldWithValue(phoneNumberField1, number, "Filled Phone Number field", "Could not fill Phone Number field");
		extentReport.reportPass("Filled phone number with codes");
	}

	public void fillFaxNumberWithCodes(String countryCode, String areaCode, String number) throws Exception {
		fillFieldWithValue(faxCountryCodeField, countryCode, "Filled Fax Country Code field", "Could not fill Fax Country Code field");
		fillFieldWithValue(faxAreaCodeField, areaCode, "Filled Fax Area Code field", "Could not fill Fax Area Code field");
		fillFieldWithValue(faxNumberField, number, "Filled Fax Number field", "Could not fill Fax Number field");
		extentReport.reportPass("Filled fax number with codes");
	}

	public void fillTextMessage(String address) throws Exception {
		fillFieldWithValue(textMessageField_OR, address, "Filled Text Message field", "Could not fill text message field");
		extentReport.reportPass("Filled text message");
	}

	public void fillEmail(String email) throws Exception {
		fillFieldWithValue(emailField_OR, email, "Filled Email field", "Could not fill Email field");
		extentReport.reportPass("Filled email");
	}

	/*
	 * Field value getter functions
	 */

	public String getEmailFieldValue() throws Exception{
		return getAttribute(emailField_OR, "value");
	}

	public String getPhoneNumberFieldValue() throws Exception{
		return getAttribute(phoneNumberField1, "value");
	}


	public String instructionalTextOfAlertTransmissions() throws Exception {
		String text ="";
		if(elementVisibleOnPage(instructionalTextOfAlertTransmissions, "Found instructionalTextOfAlertTransmissions", "Did not find instructionalTextOfAlertTransmissions")) {
			text=getText(instructionalTextOfAlertTransmissions);
		}
		return  text;
	}

	/*
	 * Page navigation functions
	 */

	public void goToClinicProfilePage() throws Exception {
		clickElementOnPage(clinicProfileNavigation, "Clinic Profile Sidebar is clicked from Direct Alert - Pacemaker / CRT-P Page", "Clinic Profile sidebar could not be clicked");
	}

	/*****CLinic Information****/
	public boolean isEditable_TextMessageField() throws Exception {
		return elementEditableOnPage(textMessageField_OR, "Text Message field is Editable", "Text Message field Did is NOT Editable ");
	}

	public boolean isEditable_findPhoneNumberField() throws Exception {
		return elementEditableOnPage(phoneNumberField1, "Phone Number field is Editable", "Phone Number field is NOT Editable ");
	}

	public boolean isEditable_findEmailField() throws Exception {
		return elementEditableOnPage(emailField_OR, "Email field is Editable", "Email field is NOT Editable ");
	}

	public boolean isEditable_findFaxField() throws Exception {
		return elementVisibleOnPage(faxNumberField, "Found Fax field", "Did not find Fax field");
	}

	public boolean verifyEditButton() {
		Boolean isEditbuttonpresent=false;
		if(visibilityOfElementLocated(editButton_OR)) {
			isEditbuttonpresent=true;
			extentReport.reportScreenShot("Edit Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Edit Button is not displayed");
		}
		return isEditbuttonpresent;
	}

	//created bybhupi 
	public void verifyEditButton_new() {
		presenceOfElementLocatedWithReport(editButton_OR,editButton_S);
	}

	public boolean verifyCancelButton() {
		Boolean isCancelButtonPresent=false;
		if(visibilityOfElementLocated(cancelButton_OR)) {
			isCancelButtonPresent=true;
			extentReport.reportScreenShot("Cancel Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Cancel Button is not displayed");
		}
		return isCancelButtonPresent;
	}

	public void verifyCancelButton_new() {
		presenceOfElementLocatedWithReport(cancelButton_OR,cancelButton_S);
	}
	public void fillPhoneData(String FieldName, String Value) throws Exception {
		By element = null;
		try {
			switch (FieldName) {
			case "PhoneCountryCode":
				element = phoneCountryCodeField1;
				break;
			case "PhoneAreaCode":
				element = phoneAreaCodeField1;
				break;
			case "PhoneNumber":
				element = phoneNumberField1;
				break;
			case "Email":
				element = emailField_OR;
				break;
				/*		}

			case "Email":
				//element = eMailField_OR;
				break;
				 */	}
			if (isElementPresent(element)) {
				visibilityOfElementLocated(element);
				scrollToView(element);
				sendKeys(element, Value);

			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean verifySaveButton() {
		Boolean isSaveButtonPresent=false;
		if(visibilityOfElementLocated(saveButton_OR)) {
			isSaveButtonPresent=true;
			extentReport.reportScreenShot("Save Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Save Button is not displayed");
		}
		return isSaveButtonPresent;
	}


	public void verifySaveButton_new() {
		presenceOfElementLocatedWithReport(saveButton_OR,saveButton_S);
	}


	public void ValidatePacemakerEditButton() throws InterruptedException
	{
		clickElement(editButton_OR, editButton_S);				
	}

	public void validateEditModePacemaker() throws InterruptedException {
		verifyEditButton_new();
		extentReport.reportScreenShot("Edit Buttonis dispalyed on pacemaker page");	
		ValidatePacemakerEditButton();
		verifySaveButton_new();
		verifyCancelButton_new();
		extentReport.reportScreenShot("Save and cancel button dispalyed after clicking on edit button in pacemaker page.");	
	}


	// Each page class should have this overridden method of Verify Landing page 
	@Override
	public boolean verifyLandingPage() {

		Boolean verifyPacemakerCRTPPage = false;

		if(isElementPresentwithoutException(pacemakerCRTP_PageHeader_OR, pacemakerCRTP_PageHeader_S)) {
			verifyPacemakerCRTPPage = true;
			extentReport.reportScreenShot("Direct Alerts Pacemaker / CRT-P Page is displayed");
		} else {
			extentReport.reportScreenShot("Direct Alerts Pacemaker / CRT-P Page is not displayed");
		}

		return verifyPacemakerCRTPPage;
	}

	//--------------------------------- Jeetendra --------------------------------
	String DirectAlertsSettings_S=null;
	By PatientNotificationCheckbox= By.xpath("");
	//	  String DirectAlertsSettings_S=null;
	public boolean verifyPatientNotificationcheckboxState(String PageName , String state) {
		boolean flag=false;
		if(PageName.matches(pacemakerCRTP_PageHeader_S)&&state.matches("OFF")) {
			if(!(getSizeOfElements(PatientNotificationCheckbox)>0)) {
				flag=true;	
			}	
		}

		if(PageName.matches(DirectAlertsSettings_S)&&state.matches("Editable")) {
			System.out.println("Blocker - due to defect");
		}
		return flag;

	}

	public boolean SelectPatientNotificationcheckbox(String PageName ,String state) {
		boolean flag=false;
		if(PageName.matches(pacemakerCRTP_PageHeader_S)&&state.matches("OFF")) {
			if(!(getSizeOfElements(PatientNotificationCheckbox)>0)) {
				flag=true;	
			}	
		}
		return flag;
	}
		  
	
			public boolean verifyandclickAlert() {
				return false;
				// TODO Auto-generated method stub
				
			}
	
			public boolean VerifySavepopupandclick() {
				return false;
				// TODO Auto-generated method stub
				
			}
	
			public boolean verifychangesonPage() {
				return false;
				// TODO Auto-generated method stub
				
			}
			
			public boolean pacemaker_default_Alert_Config() {
				return false;
				
			}
			
			public boolean checkPatientcheckbox_with_alertsetting(String val1,String val2,String val3) {
				return false;
				
			}
	//-------------------------------- Jeetendra End------------------------------



	//created by Bhupendra
	public void verifyLandingPage_new() {
		presenceOfElementLocatedWithReport(pacemakerCRTP_PageHeader_OR, pacemakerCRTP_PageHeader_S);
	}

	//Author:Bhupendra
	public String changeAlertClassification(String alertTypeName) throws InterruptedException {
		String radioButtonEnabled = "";
		JavascriptExecutor js = (JavascriptExecutor) driver;

		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if (Red.get(i).isSelected()) {
					js.executeScript("arguments[0].click();", Yellow.get(i));
					radioButtonEnabled="yellow";
				}					
				else if (Yellow.get(i).isSelected()) {
					js.executeScript("arguments[0].click();", Off.get(i));
					radioButtonEnabled="off";			
				}
				else if (Off.get(i).isSelected()) {
					js.executeScript("arguments[0].click();", Red.get(i));
					radioButtonEnabled="red";				
				}
				break;
			}
		}
		return radioButtonEnabled;
	}

	//author :bhupendra
	public String VerifyTextSaveALertPOpup() {
		String alertText="";
		isAlertPresent();
		alertText = getAlertText();	
		return alertText;
	}

	public void acceptSaveAlertPOpup() {
		isAlertPresent();
		acceptAlert();
	}


	//author :bhupendra
	public String verifyAlertClassificationStatus(String alertTypeName) throws InterruptedException {
		String statusFlg="";
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i < alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName) && i!=10) {
				if (Red.get(i).isSelected()) {
					statusFlg= "red";
				}					
				else if (Yellow.get(i).isSelected()) {
					statusFlg= "yellow";			
				}
				else if (Off.get(i).isSelected()) {
					statusFlg= "off";			
				}else {
					statusFlg="0";
				}
				break;
			}
		}
		return statusFlg;
	}



	//author :bhupendra
	public void selectAlertClassification(String alertTypeName,String Classification) throws InterruptedException {

		try {
			Classification=Classification.toLowerCase();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			List<WebElement> alerttTypes = findElementslist(alertType_OR);
			List<WebElement> Red = findElementslist(redRadioButton_OR);
			List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
			List<WebElement> Off = findElementslist(offRadioButton_OR);
			for (int i = 0; i <= alerttTypes.size(); i++) {
				if (alerttTypes.get(i).getText().contains(alertTypeName)) {
					if (Classification.toLowerCase().contains("red")) {
						//Added the below method to bring focus on webElement-ChandraMohan.S
						scrollToViewWebElementWithoutReport(Red.get(i),alertTypeName+" "+Classification);
						js.executeScript("arguments[0].click();",Red.get(i) );
					}					
					else if (Classification.toLowerCase().contains("yellow")) {
						scrollToViewWebElementWithoutReport(Yellow.get(i),alertTypeName+" "+Classification);
						js.executeScript("arguments[0].click();",Yellow.get(i) );
					}
					else if (Classification.toLowerCase().contains("off")) {
						scrollToViewWebElementWithoutReport(Off.get(i),alertTypeName+" "+Classification);
						js.executeScript("arguments[0].click();", Off.get(i));
					}
					break;
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			extentReport.reportFail("Error occured while clicking on alert classification radio button");
		}
	}


	//author :bhupendra
	public boolean verifyAlertClassification(String alertTypeName, String classification) throws InterruptedException {
		Boolean isAlertSaved= false;	
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if(classification.contains("Red")){
					WebElement element = driver.findElements((redRadioButton_OR)).get(i);
					if(element.isSelected() ) {
						isAlertSaved=true;
						break;
					}
				}else if(classification.contains("Yellow")){
					WebElement element = driver.findElements((yellowRadioButton_OR)).get(i);
					if(element.isSelected()) {
						isAlertSaved=true;
						break;
					}				
				}else if(classification.contains("OFF")){
					WebElement element = driver.findElements((offRadioButton_OR)).get(i);
					if(element.isSelected()) {
						isAlertSaved=true;
						break;
					}
				}else if(classification.contains("InformCheckBox")){
					WebElement element = driver.findElements((informPatientCheckbox_OR)).get(i);
					if(element.isSelected()) {
						isAlertSaved=true;
						break;
					}
				}
				break;
			}
		}
		extentReport.reportScreenShot(alertTypeName+ " is saved with  "+classification+ " Alert Classification ");
		return isAlertSaved;
	}
	//end of region author:bhupendra


	/**author :ChandraMohan.S
	 * 
	 * @param alertTypeName
	 * @param classification
	 * @return
	 * @throws InterruptedException
	 */
	public boolean verifyEditModeOfAlertClassification(String alertTypeName, String classification) throws InterruptedException {
		Boolean isObjectEnabled= false;	
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if(classification.contains("Red")){
					WebElement element = driver.findElements((redRadioButton_OR)).get(i);
					if(element.isEnabled()){
						isObjectEnabled=true;
						break;
					}
				}else if(classification.contains("Yellow")){
					WebElement element = driver.findElements((yellowRadioButton_OR)).get(i);
					if(element.isEnabled()) {
						isObjectEnabled=true;
						break;
					}				
				}else if(classification.contains("OFF")){
					WebElement element = driver.findElements((offRadioButton_OR)).get(i);
					if(element.isEnabled()) {
						isObjectEnabled=true;
						break;
					}
				}else if(classification.contains("InformCheckBox")){
					WebElement element = driver.findElements((informPatientCheckbox_OR)).get(i);
					if(element.isEnabled()) {
						isObjectEnabled=true;
						break;
					}
				}
				break;
			}
		}
		extentReport.reportScreenShot(alertTypeName+ " is enabled  for  "+classification+ " Alert Classification ");
		return isObjectEnabled;
	}


	public void verifyShowDevicesLink() {
		presenceOfElementLocatedWithReport(showDevicesLink_OR, showDevicesLink_S);
	}

	public void clickShowDevicesLink() {
		clickElement(showDevicesLink_OR, showDevicesLink_S);
	}



	//

	public boolean validatePacemakerAlertValueInTable() throws InterruptedException, IOException {
		boolean flag = true;
		int i;
		By alertname=By.xpath("//mat-label[text()='Alert Type'])");
		scrollToView(alertname);
		List<WebElement> allAlertspacemaker=findElements(allPacemakerAppAlert_OR);
		ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("Pacemaker");
		for (String string : directAlerts) {
			System.out.println(string);
		}
		//Collections.sort(directAlerts);
		//&& statement will be removed once hidden value "RV Pacing Lead Impedance Out of Range" will come in UI
		for (i=1;i<=allAlertspacemaker.size();i++)
		{			//String AlertsMerlinMobile = getText(By.xpath(allMobileAppAlertValues_OR+"["+"i"+"]"));
			//String AlertMerlinMobile=(driver.findElements(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)"))).get(i).getText().trim();
			String AlertMerlinMobile=(driver.findElement(By.xpath("(//div[@id='pacemakerAlertType']//mat-label)["+i+"]"))).getText().trim();
			String alert1=directAlerts.get(i-1);
			System.out.println(alert1);
			System.out.println(AlertMerlinMobile);
			if(!directAlerts.get(i-1).equalsIgnoreCase(AlertMerlinMobile) && i!=10) {
				flag=false;
				break;

			}

		}
		return flag;





	}





	//snehal

	private final By showDeviceDialogBox_OR = By.xpath("//div[@class='cdk-overlay-pane']//app-show-devices-dialog/h2");
	private final String showDeviceDialogBox_S = "Show Devices Dialogue Box";

	private final String deviceNameInShowDeviceDialogBox_OR = "//td[@class='mat-cell cdk-cell cdk-column-deviceName mat-column-deviceName ng-star-inserted'][contains(text(),'$deviceName')]";
	private final String deviceNameInShowDeviceDialogBox_S = "Device Name under Show Devices Dialogue Box";

	private final By showDeviceCloseBtn_OR = By.xpath("//mat-dialog-actions/button/span");
	private final String showDeviceCloseBtn_S = "Show Devices Close Button";

	public boolean validateDeviceInShowDeviceDialogBox(String deviceName) {
		Boolean flag = false;
		loading();
		if(visibilityOfElementLocatedWithReport(showDeviceDialogBox_OR, showDeviceDialogBox_S)) {
			extentReport.reportScreenShot("Show Devices DialogBox is displayed");
			if(visibilityOfElementLocatedWithReport(By.xpath(deviceNameInShowDeviceDialogBox_OR.replace("$deviceName", deviceName)), deviceNameInShowDeviceDialogBox_S)) {
				flag = true;
				extentReport.reportScreenShot(deviceName+" is present");

			}
		}
		clickElementWithoutReport(showDeviceCloseBtn_OR, showDeviceCloseBtn_S);
		return flag;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String verifyDefaultStatusOfAlert(String ReadDataforPacemaker) throws Exception {
		String radioButtonstatus = "0";
		List<String>  alertSTatusUpdated= new ArrayList<String>() ,
				alertSTatusAfterUpdated= new ArrayList<String>(),
				alertSTatusAfterCancel= new ArrayList<String>(),
				alertStatusExisting=new ArrayList<String>();
		String radioButtonEnabled = "";
		int i=0;
		JavascriptExecutor js = (JavascriptExecutor) driver;

		List<WebElement> alerttTypes = findElementslist(allPacemakerAppAlert_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		ArrayList<String> directAlerts=null;
		if(ReadDataforPacemaker.equalsIgnoreCase("US")) {				
			directAlerts=TestDataProvider.readDirectAlertsFromExcel("Pacemaker");
		}


		for(i=1;i<=directAlerts.size(); i++) {


			if(alerttTypes.get(i).getText().equalsIgnoreCase(directAlerts.get(i))){
				if ((Red.get(i).isSelected()==true && Yellow.get(i).isSelected()==false && Off.get(i).isSelected()==false)) {
					scrollToViewlist(alerttTypes.get(i));
					extentReport.reportScreenShot("Alert \""+directAlerts.get(i)+"\" red status id enabled by default.");				
					radioButtonstatus="1";					   
				}
				else {
					radioButtonstatus="0";
					extentReport.reportScreenShot("Alert \""+directAlerts.get(i)+"\" is enabled");
				}
				
				
			}

		}
		return radioButtonstatus;


	}
	
	
	public boolean verifyDefaultSTatusOfAlert(String status) throws Exception {
		
	boolean flag=true;
		
		ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("Pacemaker");
		
		for(String alertName : directAlerts) {
		if( verifyAlertClassification(alertName,status)) {
		extentReport.reportScreenShot("For :"+alertName+" classification status is "+status);
		}else {
			flag=false;
			extentReport.reportScreenShot("For :"+alertName+" classification status is "+status);
		}
			
			
		}
		return flag;

		}
	
	
	public String changeAlertCategoryToOtherAlert(String alertTypeName,String AlertClassification) throws InterruptedException {
		String radioButtonEnabled = "";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i < alerttTypes.size(); i++) {
			System.out.println(alerttTypes.get(i).getText());
			if (alerttTypes.get(i).getText().contains(alertTypeName) && i!=10) {
				scrollToViewlist(alerttTypes.get(i));
				if (AlertClassification.toLowerCase().equalsIgnoreCase("yellow") ) {

					js.executeScript("arguments[0].click();", Yellow.get(i));
					radioButtonEnabled="Yellow";
					
				}	
				else if(AlertClassification.toLowerCase().equalsIgnoreCase("red")) {
					js.executeScript("arguments[0].click();", Red.get(i));
					radioButtonEnabled="Red";
					
	}	
				else if(AlertClassification.toLowerCase().equalsIgnoreCase("off")) {
					js.executeScript("arguments[0].click();", Off.get(i));
					radioButtonEnabled="Off";
					
				}
			}
		}
		return radioButtonEnabled;
	}
				
				public String changeAlertCategoryToOff(String alertTypeName) throws InterruptedException {
					String radioButtonEnabled = "";
					JavascriptExecutor js = (JavascriptExecutor) driver;
					
					List<WebElement> alerttTypes = findElementslist(alertType_OR);
					List<WebElement> Red = findElementslist(redRadioButton_OR);
					List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
					List<WebElement> Off = findElementslist(offRadioButton_OR);
					for (int i = 0; i <= alerttTypes.size(); i++) {
						System.out.println(alerttTypes.get(i).getText());
						if (alerttTypes.get(i).getText().contains(alertTypeName)) {
							scrollToViewlist(alerttTypes.get(i));
							if (Red.get(i).isSelected()) {

								js.executeScript("arguments[0].click();", Off.get(i));
								radioButtonEnabled="Off";
								extentReport.reportScreenShot("For :"+alertTypeName+" classification status is changed to "+radioButtonEnabled);
							}	
				           else{
				               extentReport.reportScreenShot("For :"+alertTypeName+" Red or yellow is selected by default");
				}		   				
}
		}
		return radioButtonEnabled;
	}
}