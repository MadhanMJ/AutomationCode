package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.dataBase.DataBaseConnector;

public class PL_TransmissionPage extends BasePage {
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	DataBaseConnector dbConnector;

	public PL_TransmissionPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		// TODO Auto-generated constructor stub
		this.extentReport = extentReport;
		this.driver = driver;
	}

	// Poojitha
	private final By pageText_OR = By.xpath("//a[@id='btn_patient-list-breadcrumb_breadcumb3']");
	private final String pageText_S = "FastPath summary Validation";
	private final By pageLoading_OR = By.xpath("//div[@class='spinnerWrapper']");
	private final String pageLoading_S = "Page loading symbol";
	private final By patientListLink_OR = By.xpath("//a[@id='btn_patient-list-breadcrumb_breadcumb0']");
	private final String patientListLink_S = "PatientList Hyperlink";
	private final By episodesAndEGMLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']");
	private final String episodesAndEGMLink_S = "Episodes and EGM Hyperlink";
	// Dhaval
	private final By trnsDtLbl_OR = By.xpath("//div[@id='lbl_transmission_summary_transmission_date']");
	private final String trnsDtLbl_S = "Tranmission Dt Time";
	private final By patientNameOnTransmissionTab_OR = By.xpath("//div[@id='title_banner_name']");
	private final String patientNameOnTransmissionTab_S = "Tranmission Dt Time";
	private final By episodesAndEGMTitle_OR = By.xpath("//h6[@id='title_episode-egm-icm_episodeEgm']");
	private final String episodesAndEGMTitle_S = "Episodes And EGM Title";
	private final By scheduleButton_OR = By.xpath("//a[@id='btn_transmission-list_schedule']");
	private final String scheduleButton_S = "Schedule button on transmission action panel";
	private final By fastPathSummaryLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_0_0']");
	private final String fastPathSummaryLink_S = "Fast Path Summary Hyperlink";
	

	// snehal
	private final By transmissionHdr_OR = By.xpath("//a[@id='btn_patient-list-breadcrumb_breadcumb1']");
	private final String transmissionHdr_S = "Transmission header";

	private final By transmissionTab_OR = By.xpath("//a[@href='/dist/merlin-cloud/patient-list/transmission']/span");
	private final String transmissionTab_S = "Transmission tab";

	// dummy xpath
	private final By archiveBtn_OR = By.xpath("//button[@id='btn_transmission-list_archive']/span");
	private final String archiveBtn_S = "Archive Button";

	private final By archiveMsg_OR = By.xpath("//div[@id='toast-container']/div/div");
	private final String archiveMsg_S = "Archive message";

	private final By printTranmissionButton_OR = By
			.xpath("//button[@id='btn_print-transmission_availableReportsPrint']");
	private final String printTranmissionButton_S = "Print Button";

	private final By printTransmission_OR = By.xpath("//h6[@id='title_print-transmission_pt']");
	private final String printTransmission_S = "Print Transmission";

	private final By printButton_OR = By.xpath("//button[@id='btn_transmission-list_print']");
	private final String printButton_S = "Print Button";

	private final By patientRecordsPrintBtn_OR = By.xpath("//button[@id='btn_popup-pdf_print']");
	private final String patientRecordsPrintBtn_S = "Print Button";

	private final String patientNameInPrintReport_OR = "//div[@class='pdfViewer']//div/span[contains(text(),'$patientName')]";
	private final String patientNameInPrintReport_S = "Patient Name in Print Report";

	// Poojitha
	// This method is used to validate the navigation to FastPath Summary page
	public void verifyNavigationTofastPathSummary() throws Exception {
		if (getText(pageText_OR).trim().equalsIgnoreCase("Fast Path Summary")) {
			extentReport.reportPass("Navigated to FastPath™ Summary page");
		} else {
			extentReport.reportFail("Navigated to other than FastPath™ Summary page");
		}
	}

	// This method is used to validate the navigation to Episodes & EGM's page
	public void verifyNavigationToEpisodes() throws Exception {
		if (getText(pageText_OR).trim().equalsIgnoreCase("Episodes & EGMs") && getText(episodesAndEGMTitle_OR).trim().equalsIgnoreCase("Episodes and EGMs")) {
			extentReport.reportPass("Navigated to Episodes & EGMs page");
		} else {
			extentReport.reportFail("Navigated to other than Episodes & EGMs page");
		}
	}

	// This method is used to navigate to Episodes and EGM Page
	public void navigateToEpisodesAndEGMs() {
		clickElement(episodesAndEGMLink_OR, episodesAndEGMLink_S);
	}
//Ends here
	
	//Dhaval
	public boolean verifyScheduleButton() {
		boolean checkScheduleButtonTransmissionPage = false;
		if (visibilityOfElementLocatedWithReport(scheduleButton_OR, scheduleButton_S)) {
			checkScheduleButtonTransmissionPage = true;
		}
		return checkScheduleButtonTransmissionPage;
	}
	
	// This method is used to navigate to Fast Path Summary Page
		public void navigateToFastPathSummary() {
			clickElement(fastPathSummaryLink_OR, fastPathSummaryLink_S);
		}
		
// This method is used to navigate to Schedule Tab Page
		public void navigateToSchdeuleTab() {
			clickElement(scheduleButton_OR, scheduleButton_S);
		}

	// Author :Dhaval
	public String verifyPLTranmissionTabIsSelected() {

		visibilityOfElementLocatedWithReport(patientListLink_OR, patientListLink_S);
		return driver.findElement(By.xpath("//mat-toolbar-row[@id='sub-header']//a[2]")).getAttribute("class");

	}

	// Author :Dhaval
	public String verifyTransmissionDtTime() {
		visibilityOfElementLocatedWithReport(trnsDtLbl_OR, trnsDtLbl_S);
		return getText(trnsDtLbl_OR, trnsDtLbl_S);
	}

	// Author :Dhaval
	public String verifyPatientName() {
		visibilityOfElementLocatedWithReport(patientNameOnTransmissionTab_OR, patientNameOnTransmissionTab_S);
		return getText(patientNameOnTransmissionTab_OR, patientNameOnTransmissionTab_S);
	}

	// Snehal
	public void navigateToTransmissionTab() {
		clickElement(transmissionTab_OR, transmissionTab_S);
	}

	public void clickOnArchiveBtn() {
		clickElement(archiveBtn_OR, archiveBtn_S);
	}

	public String verifyArchiveMsg() {
		String archiveMsg = "";
		visibilityOfElementLocatedWithReport(archiveMsg_OR, archiveMsg_S);
		archiveMsg = driver.findElement(archiveMsg_OR).getText();
		return archiveMsg;
	}

	public void clickPrintBtnOnPrintTrans() {

		clickElement(printTranmissionButton_OR, printTranmissionButton_S);

	}

	public boolean verifyPrintTransmission() {
		boolean checkPrintTransmissionPage = false;
		if (visibilityOfElementLocatedWithReport(printTransmission_OR, printTransmission_S)) {
			checkPrintTransmissionPage = true;
		}
		return checkPrintTransmissionPage;
	}

	public void clickPrintButton() {

		clickElement(printButton_OR, printButton_S);

	}

	public void clickPrintBtnOnPatientRecords() {

		clickElement(patientRecordsPrintBtn_OR, patientRecordsPrintBtn_S);

	}

	public boolean verifyPatientNameInPrintReport(String patientName) {
		Boolean flag = false;
		switchToFrameViaNameOrId("ng2-pdfjs-viewer");
		if (visibilityOfElementLocatedWithReport(
				By.xpath(patientNameInPrintReport_OR.replace("$patientName", patientName)),
				patientNameInPrintReport_S)) {
			extentReport.reportScreenShot("Patient Name in print pdf report is verified");
		}

		return flag;
	}

	/*
	 * Author Salin Gambhir for TC Name:
	 */
	private final By episodeEGMLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']");
	private final String episodeEGMLink_S = "Episode and EGMs Link";
	private final By moreAction_OR = By.xpath("//button[@id='btn_episode-egm-icm_selectMoreAction']");
	private final String moreAction_S = "More Action Button";

	public void clickOnEpisodeEGMsLink() {

		clickElement(episodeEGMLink_OR, episodeEGMLink_S);
		// TODO Auto-generated method stub

	}

	public void downloadSpreadsheet() {
		// TODO Auto-generated method stub

	}

	public void clickOnMoreActions() {
		// TODO Auto-generated method stub
		clickElement(moreAction_OR, moreAction_S);
	}

	// Each page class should have this overridden method of Verify Landing page
	@Override
	public boolean verifyLandingPage() {
		Boolean patientTransmissionPageCheck = false;
		if (visibilityOfElementLocatedWithoutReport(transmissionHdr_OR, transmissionHdr_S)) {
			invisibilityOfElementLocated(pageLoading_OR);
			patientTransmissionPageCheck = true;
			extentReport.reportScreenShot("Patient List Transmission Page is displayed");
		}
		return patientTransmissionPageCheck;
	}
	

	/*
	 * Salin Gambhir
	 */
	
	private final By tableHeader_OR = By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/thead/tr/th");
	private final String tableHeader_S = "Table header for Transmission";
	private final String rowCount = "";

	@SuppressWarnings("null")
	public ArrayList<String> getAllTransmissionColumnName() {
		// TODO Auto-generated method stub
		ArrayList<String> columnName = null;
		int firstRowElementSize=getSizeOfElements(tableHeader_OR, tableHeader_S);
		for(int i=1;i<=firstRowElementSize;i++) {
		String value="//table[@id='dtl_episode-egm-icm_icm-device']/thead/tr/th["+i+"]/div/button";
		String columnValue=getText(By.xpath(value));
		System.out.println(columnValue);
		columnName.add(columnValue);
		}
		
		return columnName;
	}
	
	
	
	public boolean checkFileNameAndExt(String downloadPath, String ext) throws FileNotFoundException {
		boolean fileCheck = false;
		
		File directoryPath = new File(downloadPath);
		String[] listOfFiles = directoryPath.list();
		
		for(int i = 0; i<=listOfFiles.length; i++)
		{
			String[] fileNameWithExt = listOfFiles[i].split(".");
			if (fileNameWithExt[0].equals("MerlinNet") && fileNameWithExt[1].equals("csv"))
				fileCheck = true;
				
		}
		
		return fileCheck;
	}

	public int getRowCount() {
		// TODO Auto-generated method stub
		int rowCount = 0;
		
		
		return rowCount;
	}
		
	
	
	//Kundan
	private final By selectpt_Checkbox_EpisodeEGM_Page_OR = By.xpath("//*[@id=\"mat-checkbox-521\"]/label/div");
	private final String selectpt_Checkbox_Transmission_Page_S = "Episode EGM page select patient check box";
	
	
	public void selectEpisodeCbxEpisodeEGMPage()
	{
		clickElement(selectpt_Checkbox_EpisodeEGM_Page_OR, selectpt_Checkbox_Transmission_Page_S);

	}
	


}
