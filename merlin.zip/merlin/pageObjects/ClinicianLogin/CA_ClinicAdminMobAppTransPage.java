package com.test.qa.ui.pageObjects.ClinicianLogin;



import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;

import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import static com.test.qa.utilities.CommonUtils.extentTest;
import static org.testng.Assert.assertEquals;





public class CA_ClinicAdminMobAppTransPage extends BasePage {
	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	public final static String dataPath = CommonUtils.loadFromPropertyFile().getProperty("DATA_PATH");
	static String path = Paths.get("").toAbsolutePath().toString() + File.separator+dataPath+File.separator;
	TestDataProvider testDataProvider; 




	public CA_ClinicAdminMobAppTransPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}






	private final By editButton_OR = By.xpath("//button[@id='edit']");
	private final String editButton_S = "Mobile App Transmitter Page edit button";
	private final By cancelButton_OR = By.xpath("//button[@id='cancel']");
	private final String cancelButton_S ="Mobile App Transmitter Page cancel button";
	private final By saveButton_OR = By.xpath("//button[@id='save']");
	private final String saveButton_S ="Mobile App Transmitter Page save button";
	private final By mobAppTransHeader_OR =By.xpath("//*[@id=\"cardiac-monitor-wrapper\"]/div[1]/div[1]/h5");
	private final String mobAppTransHeader_S ="Mobile App transmitter header";
	private final By allMobileAppAlert_OR=By.xpath("(//div[@formarrayname='alertTypes']//mat-label)");
	private final String allMobileAppAlert_S="Mobile App Alerts";
	private final String allMobileAppAlertValues_OR="(//div[@formarrayname='alertTypes']//mat-label)";
	private final String allMobileAppAlertValues_S="Mobile App Alert value";

	//author: bhupendra
	private final By alertType_OR =By.xpath("//div[@formarrayname='alertTypes']//mat-label");
	private final String alertTyp_S = "AlertType";

	private final By redRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'redButton')]");
	private final String redRadioButton_S = "RedRadioButton";

	private final By yellowRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'yellowButton')]");
	private final String yellowRadioButton_S = "YellowRadioButton";

	private final By offRadioButton_OR =By.xpath("//input[@type='radio' and contains(@id,'offButton')]");
	private final String offRadioButton_S = "OFFRadioButton";

	//clickElement(pacemaker_CRTP_OR);
	//visibilityOfElementLocated(MerlinHome_OR)





	public boolean verifyLandingPage() {
		Boolean verifyMobAppTrnsPgPage = false;

		try {
			if(isElementPresentwithoutException(mobAppTransHeader_OR, mobAppTransHeader_S)) {
				verifyMobAppTrnsPgPage = true;
				extentReport.reportScreenShot("Mobile App Transmitter Page is displayed");
			} else {
				extentReport.reportScreenShot("Mobile App Transmitter Page is not displayed");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return verifyMobAppTrnsPgPage;
	}



	public boolean verifyEditButton() {
		Boolean isEditbuttonpresent=false;
		if(visibilityOfElementLocated(editButton_OR)) {
			isEditbuttonpresent=true;
			extentReport.reportScreenShot("Edit Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Edit Button is not displayed");
		}
		return isEditbuttonpresent;
	}

	public void clickClinicEditButton() throws InterruptedException
	{
		presenceOfElementLocated(editButton_OR);
		waitForLoading();
		extentReport.reportScreenShot("Edit button  is displayed");
		clickElement(editButton_OR);

	}

	public boolean verifyCancelButton() {
		Boolean isCancelButtonPresent=false;
		if(visibilityOfElementLocated(cancelButton_OR)) {
			isCancelButtonPresent=true;
			extentReport.reportScreenShot("Cancel Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Cancel Button is not displayed");
		}
		return isCancelButtonPresent;
	}

	public boolean verifySaveButton() {
		Boolean isSaveButtonPresent=false;
		if(visibilityOfElementLocated(saveButton_OR)) {
			isSaveButtonPresent=true;
			extentReport.reportScreenShot("Save Button is displayed");
		}
		else {
			extentReport.reportScreenShot("Save Button is not displayed");
		}
		return isSaveButtonPresent;
	}

	public void validateSaveButton() {
		elementToBeClickable(saveButton_OR, saveButton_S);
		clickElement(saveButton_OR, saveButton_S);
	}

	//------------------------ jeetendra ----------------------------------
	public boolean checkPatient_notification(String PageName, String off) {
		return false;

	}
	//----------------------------- jeetendra End ------------------------

	//Author:Abhishek kumar

	public boolean validateMobileAppAlertValueInTable() throws InterruptedException, IOException{
		boolean flag = true;
		int i;
		By alertname=By.xpath("//mat-label[text()='Alert Type'])");
		scrollToView(alertname);
		List<WebElement> allAlertsMerlinMobile=findElements(allMobileAppAlert_OR);
		ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("MobileApp");
		for (String string : directAlerts) {
			System.out.println(string);
		}
		//Collections.sort(directAlerts);
		//&& statement will be removed once hidden value "Excessive charge time" will come in UI
		for (i=3;i<=allAlertsMerlinMobile.size();i++)
		{
			//String AlertsMerlinMobile = getText(By.xpath(allMobileAppAlertValues_OR+"["+"i"+"]"));
			//String AlertMerlinMobile=(driver.findElements(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)"))).get(i).getText().trim();
			String AlertMerlinMobile=(driver.findElement(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)["+i+"]"))).getText().trim();
			String alert1=directAlerts.get(i-1);
			System.out.println(alert1);
			System.out.println(AlertMerlinMobile);
			if(!directAlerts.get(i-1).equalsIgnoreCase(AlertMerlinMobile)) {
				flag=false;
				break;
			}
		}
		return flag;
	}

	
	//Author:Bhupendra
	public String changeAlertClassification(String alertTypeName) throws InterruptedException {
		String radioButtonEnabled = "";
		JavascriptExecutor js = (JavascriptExecutor) driver;

		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if (Red.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);",Yellow.get(i));
					js.executeScript("arguments[0].click();", Yellow.get(i));
					radioButtonEnabled="yellow";
					break;
				}					
				else if (Yellow.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);",Off.get(i));
					js.executeScript("arguments[0].click();", Off.get(i));
					radioButtonEnabled="off";	
					break;
				}
				else if (Off.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);",Red.get(i));
					js.executeScript("arguments[0].click();", Red.get(i));
					radioButtonEnabled="red";	
					break;
				}
				
				break;
			}
		}
		return radioButtonEnabled;
	}




	//author :bhupendra
	public String verifyAlertClassificationStatus(String alertTypeName) throws InterruptedException {
		String statusFlg="";
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if (Red.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);", Red.get(i));
					statusFlg= "red";
				}					
				else if (Yellow.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);", Yellow.get(i));
					statusFlg= "yellow";			
				}
				else if (Off.get(i).isSelected()) {
					js.executeScript("arguments[0].scrollIntoView(true);", Off.get(i));
					statusFlg= "off";			
				}else {
					statusFlg="0";
				}
				break;
			}
		}
		return statusFlg;
	}



	//author :bhupendra
	public void vidateAlertClassification(String alertTypeName,String Classification) throws InterruptedException {
		try {
			Classification=Classification.toLowerCase();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			List<WebElement> alerttTypes = findElementslist(alertType_OR);
			List<WebElement> Red = findElementslist(redRadioButton_OR);
			List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
			List<WebElement> Off = findElementslist(offRadioButton_OR);
			for (int i = 0; i <= alerttTypes.size(); i++) {
				if (alerttTypes.get(i).getText().contains(alertTypeName)) {
					if (Classification.toLowerCase().contains("red")) {
						js.executeScript("arguments[0].click();",Red.get(i) );
					}					
					else if (Classification.toLowerCase().contains("yellow")) {
						js.executeScript("arguments[0].click();",Yellow.get(i) );
					}
					else if (Classification.toLowerCase().contains("off")) {
						js.executeScript("arguments[0].click();", Off.get(i));
					}
					break;
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			extentReport.reportFail("Error occured while clicking on alert classification radio button");
		}
	}


	//author :bhupendra
	public boolean verifyAlertClassification(String alertTypeName, String classification) throws InterruptedException {
		Boolean isAlertSaved= false;	
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if(classification.contains("Red")){
					WebElement element = driver.findElements((redRadioButton_OR)).get(i);
					if(element.isEnabled() && element.isSelected() ) {
						isAlertSaved=true;
						break;
					}
				}else if(classification.contains("Yellow")){
					WebElement element = driver.findElements((yellowRadioButton_OR)).get(i);
					if(element.isEnabled() && element.isSelected()) {
						isAlertSaved=true;
						break;
					}				
				}else if(classification.contains("OFF")){
					WebElement element = driver.findElements((offRadioButton_OR)).get(i);
					if(element.isEnabled() && element.isSelected()) {
						isAlertSaved=true;
						break;
					}
				}

			}
		}
		extentReport.reportScreenShot(alertTypeName+ " is saved with  "+classification+ " Alert Classification ");
		return isAlertSaved;
	}

	public void editAndVerifyAlertCategory() throws Exception {
		List<String>  alertSTatusUpdated= new ArrayList<String>() ,alertSTatusAfterUpdated= new ArrayList<String>(), alertSTatusAfterSave= new ArrayList<String>();
		ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("MobileApp");
		

		for(int j=0;j<3;j++) {
			int i =0;
			for (String alertName : directAlerts) {	
				alertSTatusUpdated.add( changeAlertClassification(alertName));
				alertSTatusAfterUpdated.add(verifyAlertClassificationStatus(alertName));
				assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterUpdated.get(i)));	
				extentReport.reportScreenShot("Changed  Alert Categories  to "+alertSTatusUpdated.get(i)+" for "+alertName);				
				i++;					
			}
			validateSaveButton();
			i=0;
			for (String alertName : directAlerts) {						
				alertSTatusAfterSave.add(verifyAlertClassificationStatus(alertName));
				assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterSave.get(i)));
				extentReport.reportScreenShot("Changed  Alert Categories to "+alertSTatusAfterSave.get(i)+" for "+alertName);				
				i++;
			}
			alertSTatusUpdated.clear();
			alertSTatusAfterUpdated.clear();
			alertSTatusAfterSave.clear();
			if(j!=2) {
			//	clickClinicEditButton();
			}
			
		}
	}

	public void clickOkButton() {
		acceptAlert();
	}

	public boolean VerifySavepopupandclick(){
		return false;

	}
	
	//snehal
	
	public void verifyEditMode() {
		scrollToViewWithoutReport(editButton_OR,editButton_S);
		clickElement(editButton_OR,editButton_S);

	}
	
	public void verifyEditButton_new() {
		presenceOfElementLocatedWithReport(editButton_OR,editButton_S);
	}
  	
  	public void verifySaveButton_new() {
		presenceOfElementLocatedWithReport(saveButton_OR,saveButton_S);
	}
  	
  	public void verifyCancelButton_new() {
		presenceOfElementLocatedWithReport(cancelButton_OR,cancelButton_S);
	}
  	
	public void validateEditMode() throws InterruptedException {
		verifyEditButton_new();
		extentReport.reportScreenShot("Edit Button is dispalyed on Merlin@Home page");	
		verifyEditMode();
		verifySaveButton_new();
		verifyCancelButton_new();
		extentReport.reportScreenShot("Save and cancel button displayed after clicking on edit button on Merlin@Home page.");	
	}

}
