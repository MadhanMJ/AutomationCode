package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;

public class PL_AllTransmissionsPage extends BasePage {

	public PL_AllTransmissionsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	// Poojitha
	private final By archiveButton_OR = By.xpath("//button[@id='btn_all-transmissions_archive']");
	private final String archiveButton_S = "Archive button";
	private final By tierOneFilter_OR = By.xpath("//mat-select[@id='dd_all-transmissions_RT_T1_Filter']");
	private final String tierOneFilter_S = "All Transmissions Tier1 filter";
	private final String tierOneFilterDropdownOptions_OR = "(//div[@id='dd_all-transmissions_RT_T1_Filter-panel']/mat-option)[{0}]";
	private final String tierOneFilterDropdownOptions_S = "All Transmissions Tier1 filter";
	private final By fromDate_OR = By.xpath("//input[@id='txt_all-transmissions_startdate']");
	private final String fromDate_S = "Transmission from date";
	private final By toDate_OR = By.xpath("//input[@id='txt_all-transmissions_todate']");
	private final String toDate_S = "Transmission to date";
	private final By transmissionTable_OR = By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr");
	private final String transmissionTable_S = "Transmissions info";
	private final By alertsLink_OR = By
			.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[1]/td[3]/div/span[1]/span");// dummy xpath
	private final String alertsLink_S = "Alerts Link";
	private final By episodesLinkICM_OR = By
			.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[1]/td[3]/div/span[1]/span"); // dummy xpath
	private final String episodesLinkICM_S = "Episodes link for ICM devices Transmissions";
	private final By episodesLinkNonICM_OR = By
			.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[1]/td[3]/div/span/span[2]"); // dummy xpath
	private final String episodesLinkNonICM_S = "Episodes link for Non-ICM devices Transmissions";
	private final By searchTextBox_OR = By.xpath("//input[@id='txt_all-transmission_search']");
	private final String searchTextBox_S = "Textbox search";
	// Ends here

	// Dhaval
	private final By patientNameOnTransmissionTab_OR = By.xpath("//div[@id='title_banner_name']");
	private final String patientNameOnTransmissionTab_S = "Tranmission Dt Time";
	private final By allTransmissionTableDateTime_OR = By.xpath("//table[@id='dtl_all-transmission_at']/tbody//tr");
	private final String allTransmissionTableDateTime_S = "All Tranmission Dt Time";

	// snehal
	private final By allTransmissionHdr_OR = By.xpath("//a[@id='btn_patient-list-breadcrumb_breadcumb1']");
	private final String allTransmissionHdr_S = "All Transmissions header";

	private final By pageLoading_OR = By.xpath("//div[@class='spinnerWrapper']");
	private final String pageLoading_S = "Page loading symbol";

	private final By transmissionDateTimeTblHdr_OR = By
			.xpath("//button[@class='mat-sort-header-button mat-focus-indicator ng-tns-c163-399']");
	private final String transmissionDateTimeTblHdr_S = "Transmission Date/Time header";

	private final By archivedStatusForUnviwdTrans_OR = By.xpath(
			"//tr[1]/td/mat-icon[@class='mat-icon notranslate abbott-blue unviewed material-icons mat-icon-no-color ng-star-inserted']/following-sibling::small//span[text()='Archived']");
	private final String archivedStatusForUnviwdTrans_S = "Archived Status of Unviewed Transmission";

	private final By archivedStatusOfTrans_OR = By.xpath(
			"//tr[1]/td/mat-icon[@class='mat-icon notranslate abbott-blue unviewed material-icons mat-icon-no-color ng-star-inserted']/following-sibling::small//span[text()='Archived']");
	private final String archivedStatusOfTrans_S = "Archived Status of Transmission";

	private final By select1stTransChkbox_OR = By.xpath("//tr[1]/td/mat-checkbox//input");
	private final String select1stTransChkbox_S = "Select Transmission check box";

	private final By archiveBtn_OR = By.xpath("//button[@id='btn_transmission-list_archive']/span");
	private final String archiveBtn_S = "Archive Button";

	private final By archiveMsg_OR = By.xpath("//div[@id='toast-container']/div/div");
	private final String archiveMsg_S = "Archive message";

	private final By archiveMsgClosBtn_OR = By.xpath("//div[@id='toast-container']/div/div");
	private final String archiveMsgClosBtn_S = "Archive message close button";

	// Poojitha
	// This method is used to select one of the available options from the Tier1 filter
	public void selectTierOneFilterOption(String option) {
		clickElement(tierOneFilter_OR, tierOneFilter_S);
		switch (option) {
		case "AllTransmissions":
			clickElement(By.xpath(tierOneFilterDropdownOptions_OR.replace("{0}", "1")), tierOneFilterDropdownOptions_S);
			break;
		case "DateRange":
			clickElement(By.xpath(tierOneFilterDropdownOptions_OR.replace("{0}", "2")), tierOneFilterDropdownOptions_S);
			break;
		case "TransWithAlerts":
			clickElement(By.xpath(tierOneFilterDropdownOptions_OR.replace("{0}", "3")), tierOneFilterDropdownOptions_S);
			break;
		case "UnArchivedTrans":
			clickElement(By.xpath(tierOneFilterDropdownOptions_OR.replace("{0}", "4")), tierOneFilterDropdownOptions_S);
			break;
		}
	}
	
	//Vrushali - block start
	//this method click on Nth transmission on All transmission page and returns timestamp of thetransmission	
	public String clickOnNthTransRecordAndGetTimestamp(String recordNumber) throws Exception {
		String transTimestamp = "";
		clickElement(By.xpath("//table[@id='dtl_all-transmission_at']//tr[{0}]/td[2]/a".replace("{0}", recordNumber)), recordNumber+"th transmission on All transmission page");
		transTimestamp = getText(By.xpath("//table[@id='dtl_all-transmission_at']//tr[{0}]/td[2]/a".replace("{0}", recordNumber)), recordNumber+"th transmission timestamp");
		return transTimestamp;
	}
	
	//Vrushali - block end

	// This method is used to click on Alerts hyperlink
	public void clickOnAlerts() throws Exception {
		clickElement(alertsLink_OR, alertsLink_S);
	}

	// This method is used to click on Episodes hyperlink
	public void clickOnEpisodes(String device) throws Exception {
		if (device.equalsIgnoreCase("ICM"))
			clickElement(episodesLinkICM_OR, episodesLinkICM_S);
		else if (device.equalsIgnoreCase("Other"))
			clickElement(episodesLinkNonICM_OR, episodesLinkNonICM_S);
	}

	// This method is used to validate the presence of alerts
	public void alertsValidation(String text) throws Exception {
		// sendKeys(searchTextBox_OR, text);
		List<WebElement> rows = findElements(transmissionTable_OR);
		String alerts;
		for (int i = 1; i <= rows.size(); i++) {
			alerts = getText(
					By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[" + i + "]/td[3]/div/span[1]/span"));
			if (alerts.contains("Alert")) {
				extentReport.reportPass("Alerts are present");
			} else {
				extentReport.reportFail("Alerts are not present"); 
			}
		}
	}

	// This method is used to validate the presence of episodes
	public void episodesValidation(String device) throws Exception {
		List<WebElement> rows = findElements(transmissionTable_OR);
		String alerts;
		for (int i = 1; i <= rows.size(); i++) {
			if (device.equalsIgnoreCase("ICM")) {
				alerts = getText(
						By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[" + i + "]/td[3]/div/span[1]/span"));
				if (alerts.contains("Episodes"))
					extentReport.reportFail("Episodes are present");
				else
					extentReport.reportPass("Episodes are not present");
			} else if (device.equalsIgnoreCase("Other")) {
				alerts = getText(
						By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[" + i + "]/td[3]/div/span/span[2]"));
				if (alerts.contains("Episodes"))
					extentReport.reportPass("Episodes are present");
				else
					extentReport.reportFail("Episodes are not present");
			}
		}
	}

	// This method is used to capture the available Transmission dates
	public ArrayList<Date> captureTransDate(String format,boolean isWithTimestamp) throws InterruptedException, ParseException {
		List<WebElement> rows = findElements(transmissionTable_OR);
		ArrayList<Date> transDateValue = new ArrayList<Date>();
		SimpleDateFormat transDate = new SimpleDateFormat(format);
		for (int i = 1; i <= rows.size(); i++) {
			String actualDateValue = getText(
			By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[" + i + "]/td[2]/a"));
			if(!isWithTimestamp)
			actualDateValue = actualDateValue.trim().substring(0, 10);
			java.util.Date actualDate = transDate.parse(actualDateValue);
			transDateValue.add(actualDate);
		}
		System.out.println("Captured Transmission date:" + transDateValue);
		return transDateValue;
	}

	// This method is used to enter From and To dates after selecting "Date Range" from Tier1 filter 
	public void enterDateValues(String fromDateValue, String toDateValue) throws ParseException, InterruptedException {
		sendKeys(fromDate_OR, fromDateValue);
		sendKeys(toDate_OR, toDateValue);
	}

	// This method is used to validate the available transmission dates lies in the provided date range or not
	public Integer populatedTransValidations(ArrayList<Date> transDateValue, String fromDateValue, String toDateValue)
			throws InterruptedException, ParseException {
		ArrayList<Date> capturedDate = new ArrayList<Date>();
		ArrayList<Date> comparedDate = new ArrayList<Date>();
		ArrayList<Date> missedValue = new ArrayList<Date>();
		SimpleDateFormat dateValue = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat actualValue = new SimpleDateFormat("MM-dd-yyyy");
		java.util.Date fromDate = dateValue.parse(fromDateValue);
		java.util.Date toDate = dateValue.parse(toDateValue);
		List<WebElement> rows = findElements(transmissionTable_OR);
		for (Date value : transDateValue) {
			if (value.compareTo(fromDate) >= 0 && value.compareTo(toDate) <= 0) {
				comparedDate.add(value);
			}

		}
		int transmissionCount = comparedDate.size();
		System.out.println("Compared dates are:" + comparedDate);
		if (comparedDate.isEmpty()) {
			extentReport.pass("Transmissions are not available with in the given date range");
		} else {
			for (int i = 1; i <= rows.size(); i++) {
				String actualDateValue = getText(
						By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[" + i + "]/td[2]/a"));
				actualDateValue = actualDateValue.trim().substring(0, 10);
				java.util.Date actualDate = actualValue.parse(actualDateValue);
				capturedDate.add(actualDate);
				System.out.println("actual date value:" + actualDate);
				System.out.println("From date value:" + fromDate);
				System.out.println("To date value:" + toDate);
				for (Date value : capturedDate) {
					if (!comparedDate.contains(value))
						missedValue.add(value);
				}
				System.out.println("missed values are:" + missedValue);
				if (missedValue.isEmpty()) {
					extentReport.pass("Transmissions within the date range are fetched successfully");
				} else {
					extentReport.fail("Transmissions within the date range are not fetched");
				}

			}
		}
		return transmissionCount;
	}
	// ends here

	// Author :Dhaval

	public String verifyPatientName() {
		visibilityOfElementLocatedWithReport(patientNameOnTransmissionTab_OR, patientNameOnTransmissionTab_S);
		return getText(patientNameOnTransmissionTab_OR, patientNameOnTransmissionTab_S);
	}

	// Author :Dhaval
	public int allTransmissionCount() {
		return getSizeOfElements(allTransmissionTableDateTime_OR, allTransmissionTableDateTime_S);
	}

	public void populatedTransDateTimeValidations(ArrayList<String> transDateTimeValueDB) throws InterruptedException {
		String actualDateTimeValueDB;
		boolean valueCheck = true;
		List<WebElement> allTransDateTime = findElements(allTransmissionTableDateTime_OR);
		for (int i = 1; i <= allTransDateTime.size(); i++) {

			String actualDateTimeValue = getText(
					By.xpath("//table[@id='dtl_all-transmission_at']/tbody//tr[" + i + "]//td[2]"));
			actualDateTimeValue = actualDateTimeValue.trim();
			actualDateTimeValueDB = transDateTimeValueDB.get(i - 1).trim();

			if (!actualDateTimeValue.equals(actualDateTimeValueDB)) {
				valueCheck = false;
			}

		}

		if (valueCheck) {
			extentReport.pass("Transmissions Date and Time is same in UI & DB");
		} else {
			extentReport.fail("Transmissions Date and Time is not same in UI & DB");
		}

	}

	// Snehal
	public void verifyAtchivedStatusForUnviwdTrans() {
		if (visibilityOfElementLocatedWithReport(archivedStatusForUnviwdTrans_OR, archivedStatusForUnviwdTrans_S)) {
			extentReport.reportScreenShot("Archived Status verified");
			extentReport.pass("Unviewed Transmission is archived");
		} else {
			clickElement(transmissionDateTimeTblHdr_OR, transmissionDateTimeTblHdr_S);
			if (visibilityOfElementLocatedWithReport(archivedStatusForUnviwdTrans_OR, archivedStatusForUnviwdTrans_S)) {
				extentReport.reportScreenShot("Archived Status verified");
				extentReport.pass("Unviewed Transmission is archived");
			} else {
				extentReport.fail("Unviewed Transmission is not archived");
			}
		}
	}

	public void verifyAtchivedStatusOfTrans() {
		if (visibilityOfElementLocatedWithReport(archivedStatusOfTrans_OR, archivedStatusOfTrans_S)) {
			extentReport.reportScreenShot("Archived Status verified");
			extentReport.pass("Transmission is archived");
		} else {
			clickElement(transmissionDateTimeTblHdr_OR, transmissionDateTimeTblHdr_S);
			if (visibilityOfElementLocatedWithReport(archivedStatusOfTrans_OR, archivedStatusOfTrans_S)) {
				extentReport.reportScreenShot("Archived Status verified");
				extentReport.pass("Transmission is archived");
			} else {
				extentReport.fail("Transmission is not archived");
			}
		}
	}

	public void archiveTransmission() {
		clickElement(select1stTransChkbox_OR, select1stTransChkbox_S);
		extentReport.reportScreenShot("Transmission is selected");
		clickElement(archiveBtn_OR, archiveBtn_S);
		extentReport.pass("'" + verifyArchiveMsg() + "' message is displayed");
		clickOnArchiveMsgClosBtn();
	}

	public String verifyArchiveMsg() {
		String archiveMsg = "";
		visibilityOfElementLocatedWithReport(archiveMsg_OR, archiveMsg_S);
		archiveMsg = driver.findElement(archiveMsg_OR).getText();
		return archiveMsg;
	}

	public void clickOnArchiveMsgClosBtn() {
		clickElement(archiveMsgClosBtn_OR, archiveMsgClosBtn_S);
	}

	@Override

	public boolean verifyLandingPage() {
		Boolean patientTransmissionPageCheck = false;
		if (visibilityOfElementLocatedWithoutReport(allTransmissionHdr_OR, allTransmissionHdr_S)) {
			invisibilityOfElementLocated(pageLoading_OR);
			patientTransmissionPageCheck = true;
			extentReport.reportScreenShot("Patient List Transmission Page is displayed");
		}
		return patientTransmissionPageCheck;
	}
	private final By status_Sort_Symbol_OR = By.xpath("//th[contains(@class,'transmissionStatusDescription')]//div[contains(@class,'mat-sort-header-indicator')]");
	private final String status_Sort_Symbol_S = "Status Sort Symbol";
	public boolean isSortSymbolDisplayed() throws Exception{
		Boolean isDisplayed = false;
		if(isElementPresent(status_Sort_Symbol_OR, status_Sort_Symbol_S)) {
			String text = getText(status_Sort_Symbol_OR, status_Sort_Symbol_S);
			if(text.contains("::before")) {
				isDisplayed = true;
				extentReport.pass("Primary sort order is on column 'Status'");
			}				
			else
				extentReport.fail("Primary sort order is not there on column 'Status'");
				
		}
		return isDisplayed;
	}
	//shafiya added below method on 18/02/2022
	//This method is used to check the default sorting of transmission Date/Time is in descending order
	public boolean isTransmissionDateSorted() throws Exception{
		Boolean isSortedDesc = false;
		List<WebElement> rows = findElements(transmissionTable_OR);
		List<String> actualDateList = new ArrayList<String>();
		List<String> sortedDateList = new ArrayList<String>();
		for (int i = 1; i <= rows.size(); i++) {
			String actualDateValue = getText(
					By.xpath("//table[@id='dtl_all-transmission_at']/tbody/tr[" + i + "]/td[2]/a"));
			actualDateList.add(actualDateValue);
		}
		//Store transmission dates initially in below arraylists
		sortedDateList = actualDateList;
		//sort the transmissions in descending order using below code
		Collections.sort(sortedDateList, Collections.reverseOrder());
		//Compare if both actual list and reverse sorted list are same
		if(actualDateList.equals(sortedDateList)) {
			isSortedDesc = true;
			extentReport.pass("Transmission Date/Time is in descending order");
		}
		else
			extentReport.fail("Transmission Date/Time is not  in descending order");
		
		return isSortedDesc;
	}
	

	//--------------------- Jeetendra Code Start ----------------------------------------------
	
	public boolean clickOnmoreActionButton() {
		System.out.println("Under Development");
		return false;
	}
	
	public boolean ClickonSend_a_DirectCall_link() {
		System.out.println("Under Development");
		return false;
	}
	
	public boolean verifyDirectCallWindow() {
		System.out.println("Under Development");
		return false;
	}
	
	
	public boolean verifyradioButton_enabled() {
		System.out.println("Under Development");
		return false;
	}
	
	public boolean clickSendButton() {
		System.out.println("Under Development");
		return false;
	}
	
	
	public boolean ClickOnContact_a_Colleague() {
		System.out.println("Under Development");
		return false;
	}
	
	public boolean verifyContact_a_ColleagueWindow() {
		System.out.println("Under Development");
		return false;
	}

	public boolean clickOnmarkasUnviewed() {
		System.out.println("Under Development");
		return false;
	}
	
	//--------------------- Jeetendra Code End ----------------------------------------------

	private final By transDateAndTime_OR = By.xpath("//button[@aria-label='Change sorting for sessionDateAndTime']");
	private final String transDateAndTime_S = "Transmission Date and Time";
	
	public void clickTransDateAndTime() {
		loading();
		clickElement(transDateAndTime_OR, transDateAndTime_S);
	}
	
	
	public boolean verifyListIsSorted(By element, String strElement) throws Exception {
		ArrayList<String> list = new ArrayList<String>();
		boolean isListSorted = false;
		List<WebElement> elementList = new ArrayList<WebElement>();

		try {
			scrollToViewWithoutReport(element, strElement);
			elementList = findElementslist(element, strElement);
			int elementSize = elementList.size();
			if (elementSize > 0) {
				for (WebElement we : elementList) {
					list.add(we.getText());
				}
				// storing in another list to sort
				ArrayList<String> sortedList = new ArrayList<String>();
				for (String s : list) {
					sortedList.add(s);
				}
				Collections.sort(sortedList, String.CASE_INSENSITIVE_ORDER);
				System.out.println(sortedList);
				if (sortedList.equals(list)) {
					isListSorted = true;
					extentReport.pass("Success - \"" + strElement + "\" are in the Alphabetical order ");
				} else {
					throw new AssertionError();
				}
			} else {
				extentReport.reportFail("Element size is :" + elementSize);
			}
		} catch (AssertionError e) {
			
			extentReport.reportFail("\"" + strElement + "\" are not in Alphabetical order ",
					CommonUtils.convertStackTraceToString(e));

			throw e;
		} catch (Exception e) {
			extentReport.reportFail("Failure - \"" + strElement + "\" are not  in Alphabetical order",
					CommonUtils.convertStackTraceToString(e));
			throw new Exception(e.getMessage());
		}
		return isListSorted;
	}
	
	private final By DateAndTimeInList_OR = By.xpath("//td[contains(@class,'sessionDateAndTime ')]");
	private final String DateAndTimeInList_S = "Transmission Date and Time";
	
	
	public boolean verifyTransDateAndTimeSorted() throws Exception {
		boolean isDateAndTimeSorted = verifyListIsSorted(
				DateAndTimeInList_OR, DateAndTimeInList_S);
		return isDateAndTimeSorted;

	}
	
	private final By statusUnviewedTrans_OR = By.xpath("//mat-icon[contains(@class,'unview')]");
	private final String statusUnviewedTrans_S = "Unviewed Transmission";
	
	private final By getUnviewedId_OR = By.xpath("//mat-icon[contains(@class,'unview')]//preceding-sibling::input");
	private final String getUnviewedId_S = "Unviewed Transmission";
	
	private final By checkBoxUnviewedTrans_OR = By.xpath("//mat-icon[contains(@class,'unview')]/parent::td/following-sibling::td[contains(@class,'column-select')]/mat-checkbox");
	private final String checkBoxUnviewedTrans_S = "Unviewed Checkbox";
	
	private final By buttonPrint_OR = By.xpath("//button[@id='btn_all-transmissions_print']");
	private final String buttonPrint_S = "Print button";
	
	private final By checkBoxPrintAll_OR = By.xpath("//mat-checkbox[@id='chb_print-transmission_printSelect']");
	private final String checkBoxPrintAll_S = "Print All checkbox";
	
	private final By printInPrintTransmission_OR = By.xpath("//button[@id='btn_print-transmission_availableReportsPrint']");
	private final String printInPrintTransmission_S = "Print in Print Transmission";
	
	private final By reportPDF_OR = By.xpath("//mat-dialog-container//div[@id='popup-wrapper']");
	private final String reportPDF_S = "PDF Report";
	
	private final By closePDF_OR = By.xpath("//button[@id='btn_popup-pdf_close']");
	private final String closePDF_S = "PDF Close button";
	
	private final String statusRow_OR = "//input[@id={0}]/following-sibling::mat-icon";
	private final String statusRow_S = "PDF Close button";
	
	private final String viewedCheckbox_OR = "//input[@id={0}]/following-sibling::mat-icon/parent::td/following-sibling::td[contains(@class,'column-select')]/mat-checkbox";
	private final String viewedCheckbox_S = "Viewed checkbox";
	
	private final By btnMoreActions_OR = By.xpath("//button[@id='btn_all-transmission_menu-trigger']");
	private final String btnMoreActions_S = "More Actions";
	
	private final By btnMarkAsUnviewed_OR = By.xpath("//button[@id='dd_all-transmission_menuItem0']");
	private final String btnMarkAsUnviewed_S = "Mark as unviewed";
	
	
	public String selectUnviewedCheckbox() throws InterruptedException {
		isElementPresent(statusUnviewedTrans_OR,statusUnviewedTrans_S);
		String value=driver.findElement(getUnviewedId_OR).getAttribute("id");
//		String value = getAttributeWithoutReport(getUnviewedId_OR, "id", getUnviewedId_S);
		System.out.println("Value is :" +value);
		clickElement(checkBoxUnviewedTrans_OR, checkBoxUnviewedTrans_S);
		return value;
		
	}
	
	public boolean verifyTransmissionStatus(String value) {
		Boolean isStatusVerified=false;
		String status = getText(By.xpath(statusRow_OR.replace("{0}", value)));
		if(status.equals("drafts")){
			isStatusVerified=true;
		}
		return isStatusVerified;
		}
	
	public void changeToUnviewedTransmission(String value) {
		clickElement(By.xpath(viewedCheckbox_OR.replace("{0}", value)));
		clickElement(btnMoreActions_OR);
		clickElement(btnMarkAsUnviewed_OR);
	}
	
	public void clickPrintButton() {
		clickElement(buttonPrint_OR, buttonPrint_S);

	}
	
	public void selectPrintAllAndPrint() {

		clickElement(printInPrintTransmission_OR, printInPrintTransmission_S);
	}
	
	public boolean verifyPDFReport() {
		Boolean isPDFDisplayed=false;
		if(isDisplayedWithoutReport(reportPDF_OR, reportPDF_S)) {
			isPDFDisplayed=true;
			
		}
		return isPDFDisplayed;
		
	}
	
	public void closePDF() {
		clickElement(closePDF_OR, closePDF_S);
	}
}

