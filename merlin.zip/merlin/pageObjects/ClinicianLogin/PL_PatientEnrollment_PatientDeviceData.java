package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;

//Author: Salin Gambhir

public class PL_PatientEnrollment_PatientDeviceData extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientEnrollment_PatientDeviceData(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By transSectionLabelsHeader_OR = By.xpath("//h3[@class='merlin-header']");
	private final String transSectionLabelsHeader_S = "Labels present in Transmitter Page";
	//salin gambhir updated the mandatory fields for entering patient data
		private final By serialNumber_OR = By.xpath("//input[@id='merlin_textbox_serialNum']");
		private final String serialNumber_S = "Serial text box";
		private final By deviceName_OR = By.xpath("//div[@class='mat-select-value ng-tns-c149-57']");
		private final String deviceName_S = "Device name dropdown";
		private final By implantDate_OR = By.xpath("//input[@id='mat-input-6']");
		private final String implantDate_S = "Implant date text box";
		private final By implantPhysician_OR = By.xpath("//mat-select[@id='mat-select-20']/div/div[1]/span");
		private final String implantPhysician_S = "Implant Physician dropdown";
		private final By implantPhysicianName_OR = By.xpath("//mat-option[starts-with(@id,'mat-option')]/span");
		private final String implantPhysicianName_S = "Implant Physician Name";
		private final By orderTransmitterRadioButton_OR = By.xpath("//input[@id='mat-radio-2-input']");
		private final String orderTransmitterRadioButton_S = "Order transmitter radio button";
		private final By patientTransmitterRadioButton_OR = By.xpath("//input[@id='mat-radio-3-input']");
		private final String patientTransmitterRadioButton_S = "Patient transmitter radio button";
		private final By firstName_OR = By.xpath("//input[@id='merlin_textbox_firstName']");
		private final String firstName_S = "First name text box";
		private final By middleName_OR = By.xpath("//input[@id='mat-input-12']");
		private final String middleName_S = "Middle name text box";
		private final By lastName_OR = By.xpath("//input[@id='merlin_textbox_lastName']");
		private final String lastName_S = "Last name text box";
		private final By patientId_OR = By.xpath("//input[@id='mat-input-11']");
		private final String patientId_S = "Patient Id text box";
		private final By race_OR = By.xpath("//input[@id='mat-select-10-panel']");
		private final String race_S = "Race drop down";
		private final By gender_OR = By.xpath("//mat-select[@id='mat-select-11']");
		private final String gender_S = "Gender drop down";
		private final By language_OR = By.xpath("//mat-select[@id='mat-select-13']");
		private final String language_S = "Language drop down";
		private final By dateOfBirth_OR = By.xpath("//input[@id='mat-input-8']");
		private final String dateOfBirth_S = "DateOfBirth";
		private final By addressLineOne_OR = By.xpath("//input[@id='merlin_textbox_address']");
		private final String addressLineOne_S = "Address Line1 text box";
		private final By addressLineTwo_OR = By.xpath("//input[@id='merlin_textbox_address2']");
		private final String addressLineTwo_S = "Address Line2 text box";
		private final By addressLineThree_OR = By.xpath("//input[@id='merlin_textbox_address3']");
		private final String addressLineThree_S = "Address Line3 text box";
		private final By city_OR = By.xpath("//input[@id='merlin_textbox_city']");
		private final String city_S = "Address Line3 text box";
		private final By state_OR = By.xpath("//mat-select[@id='mat-select-15']");
		private final By stateOptions_OR = By.xpath("//div[@id='mat-select-15-panel']//mat-option[6]/span");
		private final String stateOptions_S = "Selecting the State from Dropdown";
		private final String state_S = "Address Line3 text box";
		private final By zipCode_OR = By.xpath("//input[@id='merlin_textbox_zipCode']");
		private final String zipCode_S = "Address Line3 text box";
		private final By countryCode_OR = By.xpath("//mat-select[@id='mat-select-15']");
		private final String countryCode_S = "Address Line3 text box";
		private final By email_OR = By.xpath("//input[@id='merlin_textbox_email']");
		private final String email_S = "Email text box";
		private final By phoneAreaCode_OR = By.xpath("//input[@id='mat-input-14']");
		private final String phoneAreaCode_S = "Phone area code text box";
		private final By mainPhoneNumber_OR = By.xpath("//input[@id='mat-input-15']");
		private final String mainPhoneNumber_S = "Main Phone number text box";
		private final By continueButton_OR = By.xpath("//button[@mattooltip='Continue']");
		private final String continueButton_S = "Continue button";
		private final By saveAndCloseButton_OR = By.xpath("//div[@id='cdk-step-content-0-0']/app-manual-patient-device-data/div[2]/button[2]");
		private final String saveAndCloseButton_S = "Save and Close button";
		private final By errorMessage_OR = By.xpath("");
		private final String errorMessage_S = "Error message displayed"; 
		private final By merlinNetNumber_OR = By.xpath("//div[@id='app-container']/app-view-edit-patient-profile/div[2]/div[2]/app-manual-patient-device-data/app-patient-details/mat-card/div[2]/div/div[2]/div[4]");
		private final String merlinNetNumber_S = "Merlin Net Number";
		
	
	@Override
	public boolean verifyLandingPage() {
		Boolean transmitterPageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(serialNumber_OR, serialNumber_S)) {
			transmitterPageCheck = true;
		}
		return transmitterPageCheck;
	}
	
	
	/*
	 * Salin Gambhir
	 * for TC: 
	 */
	//private final By deviceDropDown_OR = By.xpath("//mat-select[@id='mat-select-38']/div/div[1]/span");
	private final By deviceDropDown_OR = By.xpath("//mat-select[@formControlName='productId']/div/div[2]/div"); //Poojitha - updated
	private final String deviceDropDown_S = "Device Data dropdown"; 
//	private final By searchDeviceDropDown_OR = By.xpath("//div[@id='mat-select-22-panel']//input");
	private final By searchDeviceDropDown_OR = By.xpath("//div[@id='mat-select-10-panel']//input");
	private final String searchDeviceDropDown_S = "Device Searched in Device Dropdown";
	//private final By searchedDeviceValue_OR = By.xpath("//div[@id='mat-select-22-panel']//mat-option/span");
	private final By searchedDeviceValue_OR = By.xpath("//div[@id='mat-select-10-panel']//mat-option/span");
	private final String searchedDeviceValue_S = "Searched Device Value";
	private final By enrollPatientManuallyHeader_OR = By.xpath("//div[@id='app-container']//app-manual-patient-enroll/header[1]/div");
	private final String enrollPatientManuallyHeader_S = "Enroll a Patient Manually";
 	
	public void searchDeviceInEnrollDeviceDropDown(List<String> deviceNames) {
		// TODO Auto-generated method stub
		
		clickElement(deviceDropDown_OR, deviceDropDown_S);
		clickOnElementUsingJs(deviceDropDown_OR, deviceDropDown_S);
		for (String deviceName: deviceNames)
			sendKeys(searchDeviceDropDown_OR, searchDeviceDropDown_S, deviceName);
	}
	
	public boolean verifyDeviceInDropDown(List<String> deviceNames, String status)
	{
		boolean checkDeviceName = false;
		String searchedDeviceName = null;
		if(visibilityOfElementLocatedWithReport(searchedDeviceValue_OR, searchedDeviceValue_S))
			searchedDeviceName = getText(searchedDeviceValue_OR, searchedDeviceValue_S);

		switch(status.toLowerCase())
		{
		case "not available":
			if (searchedDeviceName.equals(null) || searchedDeviceName.equals("")) {
				extentReport.reportInfo(searchedDeviceName + "is not present in Dropdown");
			checkDeviceName = true;
		}
		case "available":
			for (String deviceName: deviceNames)
			{
				if (searchedDeviceName.equals(deviceName))
				{
					extentReport.reportInfo(searchedDeviceName + "is not present in Dropdown");
					checkDeviceName = true;
				}
				else 
					extentReport.reportFail("Searched device is not in list");		
			}

		}
		
		
		return checkDeviceName;
	}
	
	public void enterSerialNumber(String serialNumber) {
		sendKeys(serialNumber_OR, serialNumber_S, serialNumber);
		
	}
	public void selectDeviceInEnrollDeviceDropDown(List<String> deviceNames) {
		searchDeviceInEnrollDeviceDropDown(deviceNames);
		clickElement(searchedDeviceValue_OR, searchedDeviceValue_S);
			
	}
	
	public void enterFirstName(String firstName)
	{
		sendKeys(firstName_OR, firstName_S, firstName);
	}
	
	public void enterLastName(String firstName)
	{
		sendKeys(lastName_OR, lastName_S, firstName);
	}
	
	public void enterEmailID(String emailID)
	{
		sendKeys(email_OR, email_S, emailID);
	}
	
	public void enterDOB(String DOB)
	{
		sendKeys(dateOfBirth_OR, dateOfBirth_S, DOB);
	}
	
	public void enterPhoneNumber(String phoneNumber)
	{
		String[] phone = phoneNumber.split("-");
		//sendKeys(countryCode_OR, countryCode_S, phone[0]);
		sendKeys(phoneAreaCode_OR, phoneAreaCode_S, phone[0]);
		sendKeys(mainPhoneNumber_OR, mainPhoneNumber_S, phone[1]);
	}
	
	public void enterImplantDate(String implantDate)
	{
		sendKeys(implantDate_OR, implantDate_S, implantDate);
	}
	
	public void enterImplantPhysician(Patient patient)
	{
		By implantPhysicianName_OR = By.xpath("//mat-option/span[contains(text(),'"+patient.getImplantingPhysician()+"')]");
		clickElement(implantPhysician_OR, implantPhysician_S);
		clickElement(implantPhysicianName_OR, implantPhysicianName_S);
	}
	
	public void enterAddress(Patient patient)
	{
		// code to get from Excel file
		String address1 = "some address";
		String state = "California";
		String zipCode = "95001";
		String city = "Sunnyvale";
		
		sendKeys(addressLineOne_OR, addressLineOne_S, patient.getAddress1());
		sendKeys(zipCode_OR, zipCode_S, patient.getZipcode());
		clickElement(state_OR, state_S);
		List<WebElement> elements = null;
		try {
			elements = findElements(stateOptions_OR, stateOptions_S);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (WebElement element: elements)
		{
			if(element.getText().equalsIgnoreCase(patient.getState()))
				element.click();
			break;
		}
		
		sendKeys(city_OR, city_S, patient.getCity());
		
	}
	
	
	public void clickOnSaveAndCloseButton() {
		if(!visibilityOfElementLocatedWithReport(errorMessage_OR, errorMessage_S))
		{
			elementToBeClickable(saveAndCloseButton_OR, saveAndCloseButton_S);
			clickElement(saveAndCloseButton_OR, saveAndCloseButton_S);
		}
		else
			extentReport.reportFail("Some Mandatory fields are not filled correctly");
			
		
	}

	public void enrollNewPatientManually(String deviceType, List<String> deviceNames, Patient patient) {
		// login to enter all mandatory fields for creating data
		//String serialNumber = "223322", firstName = "Salin", lastName = "Gambhir", email = "salin.gambhir@abbott.com",phoneNumber = "1-234-2233223", dateOfBirth = "12-01-2001";
		//String implantDate = "02-12-2022";
		
		enterSerialNumber(patient.getSerialNumber());
		
		switch(deviceType.toUpperCase())
		{
		case "NGQ":
			selectDeviceInEnrollDeviceDropDown(deviceNames);
			break;
		case "ICM":
			selectDeviceInEnrollDeviceDropDown(deviceNames);
			enterImplantDate(patient.getImplantDate());
			enterImplantPhysician(patient);
			enterAddress(patient);
			break;
		default:
			break;
		}
		enterFirstName(patient.getFirstName());
		enterLastName(patient.getLastName());
		enterEmailID(patient.getEmail());
		enterDOB(patient.getDateOfBirth());
		enterPhoneNumber(patient.getPhoneNumber());
	}
	
	
	
	public String getMerlinNetNumber() {
		
		String number = getText(merlinNetNumber_OR, merlinNetNumber_S);
		return number;
	}
	
	 public boolean verifyPatientCreatedSuccessully() {
		 boolean checkPatientCreated= false;
		 
		 try {
			 if (visibilityOfElementLocatedWithReport(enrollPatientManuallyHeader_OR, enrollPatientManuallyHeader_S))
				 extentReport.reportFail("Patient still on Enrollment Page, some issue with Data, please check");
			 else
			 {
				 checkPatientCreated= true;
				 extentReport.reportPass("Patient Created successfully");
			 }
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 throw e;
		 }
		 
		 return checkPatientCreated; 
	 }
	// ending test case data
	 
	//Poojitha
	 public void enrollNewPatientManually_DynamicData(String deviceType, List<String> deviceNames) {
			enterSerialNumber(CommonUtils.deviceSerialNumber());		
			switch(deviceType.toUpperCase())
			{
			case "NGQ":
				selectDeviceInEnrollDeviceDropDown(deviceNames);
				break;
			case "ICM":
				selectDeviceInEnrollDeviceDropDown(deviceNames);
				enterImplantDate(CommonUtils.currentDate());
				enterImplantPhysician();
				enterAddress();
				break;
			default:
				break;
			}
			enterFirstName(CommonUtils.randomUserId());
			enterLastName(CommonUtils.randomUserId());
			enterEmailID(CommonUtils.randomUserId()+"@abbott.com");
			enterDOB(CommonUtils.randomDateOfBirthGenerator());
			enterPhoneNumber(CommonUtils.randomPhoneNumber());
		}
	 
	 public void enterImplantPhysician()
		{
			clickElement(implantPhysician_OR, implantPhysician_S);
			clickElement(implantPhysicianName_OR, implantPhysicianName_S);
		}
	 
	 public void enterAddress()
		{
			// code to get from Excel file
			String address1 = "some address";
			String state = "California";
			String zipCode = "95001";
			String city = "Sunnyvale";
			
			sendKeys(addressLineOne_OR, addressLineOne_S, address1);
			sendKeys(zipCode_OR, zipCode_S, zipCode);
			clickElement(state_OR, state_S);
			List<WebElement> elements = null;
			try {
				elements = findElements(stateOptions_OR, stateOptions_S);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (WebElement element: elements)
			{
				if(element.getText().equalsIgnoreCase(state))
					element.click();
				break;
			}
			
			sendKeys(city_OR, city_S, city);
			
		}
		
	 public void clickContinueButton()
	 {
		 scrollToViewWithoutReport(continueButton_OR,continueButton_S);
		 clickElement(continueButton_OR,continueButton_S);
	 }
//Ends here
}
