package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class PL_PatientProfile_DirectAlertsPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientProfile_DirectAlertsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By alertPanel_OR = By.xpath("//div[@class='alert-cont']");
	private final String alertPanel_S = "Alert Panel";
	private final By editButton_OR = By.xpath("//button[@id='profileEditButton']"); 
	private final String editButton_S = "Edit button";
	private final By saveButton_OR = By.xpath("//button[@id='profileSaveButton']"); 
	private final String saveButton_S = "Save button";
	private final By symptomFlagYellowAlert_OR = By.xpath("");
	private final String symptomFlagYellowAlert_S = "symptom episode yellow Alert radio button";
	private final By symptomFlagRedAlert_OR = By.xpath("");
	private final String symptomFlagRedAlert_S = "symptom episode yellow Alert radio button";
	private final By symptomFlagAlertOff_OR = By.xpath("");
	private final String symptomFlagAlertOff_S = "symptom episode yellow Alert radio button";
	private final By cardiacAlertType_OR=By.xpath("//div[@class='alert-cont']//p");
	private final String cardiacAlertType_S = "Alerts label";
	
	
	public void clickEditButton()
	{
	clickElement(editButton_OR,editButton_S);	
	}
	
	public void clickSaveButton()
	{
	clickElement(saveButton_OR,saveButton_S);	
	}
	
	public boolean validateSymptomEpisodeFlag()
	{
		boolean flagSelected = false;
		scrollToViewWithoutReport(symptomFlagYellowAlert_OR,symptomFlagYellowAlert_S);
		if(isSelectedWithoutReport(symptomFlagYellowAlert_OR,symptomFlagYellowAlert_S) || isSelectedWithoutReport(symptomFlagRedAlert_OR,symptomFlagRedAlert_S))
			flagSelected = true;
		else if(isSelectedWithoutReport(symptomFlagYellowAlert_OR,symptomFlagYellowAlert_S))
			flagSelected = false;
		return flagSelected;
	}
	
	public void selectAlert(String AlertType) {
		String xpath1="";
		String xpath2="";
		String xpath3 = "";
		String xpath_yellow="//mat-radio-group//*[@id='yellowButton']"; //dummy xpath
		String xpath_Red="//mat-radio-group//*[@id='redButton']"; //dummy xpath
		String xpath_Off="//mat-radio-group//*[@id='redButton']";//dummy xpath
		List<WebElement> li=driver.findElements(cardiacAlertType_OR);
		for(int i=1;i<=li.size();i++) {
		if(li.get(i).getText().contains(AlertType)) {
		int alertindex=i;
		System.out.println(alertindex);
		xpath1="("+xpath_yellow+")"+"["+alertindex+"]";
		xpath2="("+xpath_Red+")"+"["+alertindex+"]";
		xpath3="("+xpath_Off+")"+"["+alertindex+"]";
		WebElement redAlertRadio=driver.findElement(By.xpath(xpath2));
		WebElement yellowAlertRadio=driver.findElement(By.xpath(xpath1));
		WebElement alertOffRadio = driver.findElement(By.xpath(xpath3));
		if(redAlertRadio.isEnabled() || yellowAlertRadio.isSelected()) {
		scrollToViewWebElementWithoutReport(alertOffRadio, "Scroll down to validate all types of alerts");
		System.out.println(xpath3);
		alertOffRadio.click();
		extentReport.reportScreenShot("Alert has been turned off"+ AlertType);
		}
		else {
		redAlertRadio.click();
		extentReport.reportScreenShot("Alert Category changed to Urgent for the alert type: "+ AlertType);
		}
		}
		}	
	}

	
	@Override
	public boolean verifyLandingPage() {
		Boolean directAlertsPageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(alertPanel_OR, alertPanel_S)) {
			directAlertsPageCheck = true;
		}
		return directAlertsPageCheck;
	}

}
