package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.text.DateFormat;
import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.grpc.Context.Key;
public class PL_PatientSummaryPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	
	/*
	 * Author: Gowshalya
	 */
	
	public PL_PatientSummaryPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		ca_ClinicLocationsPage= new CA_ClinicLocationsPage(driver,extentReport);
		
	}
	//Gowshalya
	private final By patientSummaryHdr_OR = By.xpath("//h5[@id='title_view-snapshot_patientSummary']");
	private final String patientSummaryHdr_S = "Patient Summary Page header";
	
	//Poojitha
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By transMessage_OR = By.xpath("//div[@id='no_transmission_have_received']");
	private final String transMessage_S = "Transmissions message";
	private final By scheduledTransCount_OR = By.xpath("//div[@id='lbl_view-snapshot_scheduledCount']");
	private final String scheduleTransCount_S = "Scheduled Transmissions count";
	private final By patientInitiatedTransCount_OR = By.xpath("//div[@id='lbl_view-snapshot_patientInitCount']");
	private final String patientInitiatedTransCount_S = "Patient initiated Transmissions count";
	private final By AlertinitiatedTransCount_OR = By.xpath("//div[@id='lbl_view-snapshot_alertInitCount']");
	private final String AlertinitiatedTransCount_S = "Alert initiated Transmissions count";
	private final By episodeCount_OR = By.xpath("//div[contains(@id,'lbl_view-snapshot_episodeCount')]");
	private final String episodeCount_S = "Episodes count";
	private final By fromDate_OR = By.xpath("//input[@id='mnu_view-snapshot_fromDate']");
	private final String fromDate_S = "From date";
	private final By toDate_OR = By.xpath("//input[@id='mnu_view-snapshot_toDate']");
	private final String toDate_S = "To date";
	private final By applyButton_OR = By.xpath("//button[@id='btn_view-snapshot_apply']");
	private final String applyButton_S = "Apply button";
	
	private final By imgCalendarFromDate_OR = By.xpath("(//button[@aria-label='Open calendar'])[1]");
	private final String imgCalendarFromDate_S = "From Calendar";
	
	private final By selectedDateInCalendar_OR = By.xpath("//td[@aria-selected='true']");
	private final String selectedDateInCalendar_S = "Selected Date";
	
	private final By calendarDates_OR = By.xpath("//td[@class='mat-calendar-body-cell mat-focus-indicator ng-star-inserted']");
	private final String calendarDates_S = "Selected Date";
	
	private final By btnPrint_OR = By.xpath("//button[@id='btn_view-snapshot_print']");
	private final String btnPrint_S = "Print Button";
	
	private final By coverPage_OR = By.xpath("//div[@data-page-number='1']/div/canvas");
	private final String coverPage_S = "Cover Page";
	
	private final By episodesCount_OR = By.xpath("//span[text()='Episodes count']");
	private final String episodesCount_S = "Patient Summary Report in PDF";
	
	private final By remoteTransmission_OR = By.xpath("//span[text()='Remote Transmissions']");
	private final String remoteTransmission_S = "Remote Transmission in PDF";
	
	private final By listOfEpisodes_OR = By.xpath("//span[text()='List of Episodes']");
	private final String listOfEpisodes_S = "List of Episodes in PDF";
	
	private final By closeButtonInPDF_OR = By.xpath("//button[@id='btn_popup-pdf_close']");
	private final String closeButtonInPDF_S = "Close button in PDF";
	
	private final By transmissionSummary_OR = By.xpath("//div/h6[@id='title_view-snapshot_transmissionSummary']");
	private final String transmissionSummary_S = "Transmission Summary in work area";
	
	private final By episodesCountInTransSummary_OR = By.xpath("//div/h6[@id='title_view-snapshot_episodeCount']");
	private final String episodesCountInTransSummary_S = "Episodes Count in work area";
	
	private final By remoteTransmissionInTransSummary_OR = By.xpath("//div/h6[@id='title_view-snapshot_remoteTransmissions']");
	private final String remoteTransmissionInTransSummary_S = "Remote Transmission in work area";
	
	private final By episodesCountSubSection_OR = By.xpath("//div[contains(@id,'lbl_view-snapshot_name')]");
	private final String episodesCountSubSection_S = "Episodes Count Sub Section";
	
	private final By thisReportPeriod_OR = By.xpath("//div[contains(@id,'lbl_view-snapshot_name')]/following-sibling::div[contains(@id,'lbl_view-snapshot_episodeCount')]");
	private final String thisReportPeriod_S = "Episodes Count Sub Section";
	
	private final By sinceEnrolledInMerlinnet_OR = By.xpath("//div[contains(@id,'lbl_view-snapshot_name')]/following-sibling::div[contains(@id,'lbl_view-snapshot_episodeLTCount_')]");
	private final String sinceEnrolledInMerlinnet_S = "Episodes Count Sub Section";
	
	private final By scheduled_OR = By.xpath("//div[@id='lbl_view-snapshot_scheduledCount']");
	private final String scheduled_S = "Scheduled in Remote Transmissions";
	
	private final By patientInitiated_OR = By.xpath("//div[@id='lbl_view-snapshot_patientInitCount']");
	private final String patientInitiated_S = "Patient Initiated in Remote Transmissions";
	
	private final By alertInitiated_OR = By.xpath("//div[@id='lbl_view-snapshot_alertInitCount']");
	private final String alertInitiated_S = "Alert Initiated in Remote Transmissions";
	
	private final By afBurden_OR = By.xpath("//div/h6[@id='title_view-snapshot_afBurden']");
	private final String afBurden_S = "AF Burden Section";
	
	private final By fromDateAF_OR = By.xpath("//div[@id='view-snapshot_dates']");
	private final String fromDateAF_S = "AF From Date";
	
	//need to check
	private final By xAxis_OR = By.xpath("//*[@class='highcharts-axis-labels highcharts-xaxis-labels']//*");
	private final String xAxis_S = "X Axis";
	
	//need to check
	private final By yAxis_OR = By.xpath("//*[@class='highcharts-axis-labels highcharts-yaxis-labels']//*");
	private final String yAxis_S = "Y Axis";
	
	private final By footNote_OR = By.xpath("//div[@id='lbl_view-snapshot_afBurdenNote']");
	private final String footNote_S = "Foot Note";
	
	private final By todayDate_OR = By.xpath("//div[contains(@class,'today')]");
	private final String todayDate_S = "Today's Date";
	
	private final By errorMessageInScheduleLink_OR = By.xpath("//mat-card[@class='mat-card mat-focus-indicator flat ng-star-inserted']/p");
	private final String errorMessageInScheduleLink_S = "Error Message in Schdule link";
	
	private final By parmanentScheduleStartingOn_OR = By.xpath("(//input[@id='permDatePicker'])[1]");
	private final String parmanentScheduleStartingOn_S = "Parmanent Schedule Starting On";
	
	private final  Map<String,String> rowMap = new LinkedHashMap<>();
	
	
	
	
	public boolean verifyDataUnavailabilityMessage()
	{
		boolean dataAvailabilityCheck = false;
		if(visibilityOfElementLocatedWithReport(transMessage_OR,transMessage_S))
		{
			scrollToViewWithoutReport(transMessage_OR,transMessage_S);
			dataAvailabilityCheck = true;
		}
		return dataAvailabilityCheck;
	}

	public void enterDateValues(String fromDateValue, String toDateValue) throws ParseException, InterruptedException {
		sendKeys(fromDate_OR, fromDateValue);
		sendKeys(toDate_OR, toDateValue);
		clickElement(applyButton_OR,applyButton_S);
			}
	
	public Integer getTotalTransmissionsCount()
	{
		int totalTransCount = 0;
		String value = "";
		System.out.println(getText(scheduledTransCount_OR).trim());
		System.out.println(getText(patientInitiatedTransCount_OR).trim());
		System.out.println(getText(AlertinitiatedTransCount_OR).trim());
		value = (getText(scheduledTransCount_OR).trim().substring(11));
		totalTransCount = Integer.parseInt(value);
		value = (getText(patientInitiatedTransCount_OR).trim().substring(19));
		totalTransCount = totalTransCount + Integer.parseInt(value);
		value = (getText(AlertinitiatedTransCount_OR).trim().substring(17));
		totalTransCount = totalTransCount + Integer.parseInt(value);
		System.out.println("Total transmissions present in Patient summary Page:"+ totalTransCount);
		return totalTransCount;
	}
	
	public Integer getTotalEpisodesCount()
	{
		int totalEpisodesCount = 0;
		List<WebElement> list = new ArrayList<WebElement>();
		list = driver.findElements(episodeCount_OR);
		for (int i=1; i<=list.size();i++)
		{
			totalEpisodesCount = totalEpisodesCount + Integer.parseInt(list.get(i).getText().trim());
		}
		return totalEpisodesCount;
	}
	
	public boolean verifyPatientSummaryTitle() {
		boolean isPatientSummaryReportDisplayed=false;
		if(isElementPresentwithoutException(patientSummaryHdr_OR, patientSummaryHdr_S)) {
			isPatientSummaryReportDisplayed=true;
			extentReport.reportScreenShot("Patient Summary Page Title is displayed");
		} else {
			extentReport.reportScreenShot("Patient Summary Page Title is not displayed");
		}
		return isPatientSummaryReportDisplayed;

	}
	
	public boolean verifyApplyButton() {
		boolean enabledStatus = false;
		if(visibilityOfElementLocatedWithoutReport(applyButton_OR, applyButton_S)) {
			if(driver.findElement(applyButton_OR).isEnabled()) {
				enabledStatus=true;
				extentReport.reportScreenShot("Apply button is Enabled");
			}else {
				extentReport.reportScreenShot("Apply button is Disabled");
			}
		}
		return enabledStatus;
	}
	
	public void clickApplyButton() {
		clickElement(applyButton_OR,applyButton_S);
	}
	
	@Override
	public boolean verifyLandingPage() {
		Boolean flag = false;

		if(isElementPresentwithoutException(patientSummaryHdr_OR, patientSummaryHdr_S)) {
			flag = true;
			extentReport.reportScreenShot("Patient Summary Page is displayed");
		} else {
			extentReport.reportScreenShot("Patient Summary Page is not displayed");
		}
		return flag;

	}


//Meenakshi

private final By patientSummaryBilling_OR = By.xpath("//*[@id=\"title_view-snapshot_billing\"]");
private final String patientSummaryBillingS = "Patient Summary Billing header";

private final By BillingLastBilledDate_OR = By.xpath("//*[@id=\"lbl_view-snapshot_lastBilled\"]/text()");
private final String BillingLastBilledDate_S = "Billing Last Billed Date";

private final By BillingNextBilledDate_OR = By.xpath("//*[@id=\"lbl_view-snapshot_nextBillable\"]/text()");
private final String BillingNextBilledDate_S = "Billing Next Billed Date";

private final By BillingNextTransmissionDate_OR = By.xpath("//*[@id=\"lbl_view-snapshot_nextTransmission\"]/text()");
private final String BillingNextTransmissionDate_S = "Billing Next Transmission Date";

private final By BillingLastBilledDateInfo_OR = By.xpath("//*[@id=\"lbl_view-snapshot_lastBilled\"]/span");
private final String Billing_LastBilledDateInfo_S = "Billing Last Billed Date Info";

private final By BillingNextBilledDateInfo_OR = By.xpath("//*[@id=\"lbl_view-snapshot_nextBillable\"]/span");
private final String BillingNextBilledDateInfo_S = "Billing Next Billed Date Info";

private final By BillingNextTransmissionDateInfo_OR = By.xpath("//*[@id=\"lbl_view-snapshot_nextTransmission\"]/span");
private final String BillingNextTransmissionDateInfo_S = "Billing Next Transmission Date Info";

private final By BillingCheckbox_OR = By.xpath("//*[@id=\"chb_view-snapshot_markAsUnbilled\"]/label/div");
private final String Billing_Checkbox_S = "Billing Checkbox";

private final By BillingSaveButton_OR = By.xpath("//*[@id=\"btn_customer_saveBilling\"]/span");
private final String BillingSaveButton_S = "Billing Save Button";

private final By BillingSystemDate_OR = By.xpath("//*[@id=\"mnu_view-snapshot_billing\"]");
private final String BillingSystemDate_S = "Billing System Date";

private final By BillingSchedule_OR = By.xpath("//*[@id=\"lbl_view-snapshot_schedule\"]/a");
private final String BillingSchedule_S = "Billing Schedule link";

private final By ScheduleType_OR= By.xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/app-followuppatient-schedule/div/mat-dialog-content/mat-card/div[2]/div[2]/mat-form-field/div/div[1]/div[3]/mat-select");
private final String ScheduleType_S = "Billing Schedule Type";

private final By ScheduleTypeSmart_OR= By.xpath("/html/body/div[2]/div[4]/div/div/div/mat-option[1]/span");
private final String ScheduleTypeSmart_S = "Smart Schedule calendar";

private final By ScheduleTypeManual_OR= By.xpath("/html/body/div[2]/div[4]/div/div/div/mat-option[2]/span");
private final String ScheduleTypeManual_S = "Manual entry calendar";

private final By ScheduleTypeNone_OR= By.xpath("/html/body/div[2]/div[4]/div/div/div/mat-option[3]/span");
private final String ScheduleTypeNone_S = "None";

private final By PermanentSchedule_OR = By.xpath("//*[@id=\"permDatePickerRadioButton\"]");
private final String PermanentSchedule_S = "Smart Permanent Schedule";

private final By PermanentScheduleSpecificDay_OR =By.xpath("//*[@id=\"permDropDownRadioButton\"]");
private final String PermanentScheduleSpecificDay_S = "Smart Permanent Schedule Specific day";

private final By PermanentTransmitEvery_OR = By.xpath("//*[@id=\"permFrequencyDropdown\"]");
private final String PermanentTransmitEvery_S = "Permanent Schedule Transmit Every";

private final By PermanentTransmitFor_OR = By.xpath("//*[@id=\"permDurationDropdown\"]/div/div[1]/span/span");
private final String PermanentTransmitFor_S = "Permanent Schedule Transmit For";

private final By PermanentWeek_OR = By.xpath("//*[@id=\"permOnWeekDropdown\"]");
private final String PermanentWeek_S = "Permanent Schedule Week";

private final By PermanentDay_OR = By.xpath("//*[@id=\"permOnDayDropdown\"]");
private final String PermanentDay_S = "Permanent Schedule Day";

private final By PermanentMonth_OR = By.xpath("//*[@id=\"permOnMonthDropdown\"]");
private final String PermanentMonth_S = "Permanent Schedule Month";

private final By TemporaryScheduleCheckbox_OR = By.xpath("//*[@id=\"tempEnabledCheckbox\"]");
private final String TemporaryScheduleCheckbox_S = "Temporary Schedule checkbox";

private final By TemporarySchedule_OR = By.xpath("//*[@id=\"permFrequencyDropdown\"]/div/div[1]/span/span");
private final String TemporarySchedule_S = "Smart Temporary Schedule";

private final By TemporaryTransmitEvery_OR = By.xpath("//*[@id=\"tempFrequencyDropdown\"]/div/div[1]/span/span");
private final String TemporaryTransmitEvery_S = "Temporary Schedule Transmit Every";

private final By TemporaryTransmitFor_OR = By.xpath("//*[@id=\"tempDurationDropdown\"]/div/div[1]/span/span");
private final String TemporaryTransmitFor_S = "Temporary Schedule Transmit For";

//Datepicker for  Schedules-Permanent or temporary
private final By ScheduleTransmitDate_OR = By.xpath("//*[@id=\"permDatePicker\"]");
private final String ScheduleTransmitDate_S = "Schedule Transmit Date";

private final By ScheduleCalendar_OR = By.xpath("//*[@id=\"permDatePicker\"]/mat-form-field/div/div[1]/div[4]");
private final String ScheduleCalendar_S = "Schedule Calendar Date";

private final By ScheduleCalendarCurrent_OR = By.xpath("//*[@id=\"permDatePicker\"]/mat-form-field/div/div[1]/div[4]/mat-datepicker-toggle/button/span/svg/path");
private final String ScheduleCalendarCurrent_S = "Schedule Calendar Current Date";

private final By ScheduleCalendarNext_OR = By.xpath("//*[@id=\"permDatePicker\"]/mat-form-field/div/div[1]/div[4]/mat-datepicker-toggle/button/span/svg/path");
private final String ScheduleCalendarNext_S = "Schedule Calendar Next Date";

private final By ScheduleCalendarNextbutton_OR = By.xpath("//*[@id=\"mat-datepicker-5\"]/div/mat-month-view/table/tbody/tr[4]/td[1]/div");
private final String ScheduleCalendarNextbutton_S = "Schedule Calendar Next Date";
 //None
private final By ScheduleNone_OR = By.xpath("//*[@id=\"printable\"]/mat-dialog-content/mat-card/div[3]/div/div[2]");
private final String ScheduleNone_S = "Schedule Type None";

	//Save

//
private final By RecentTranslink_OR = By.xpath("//*[@id=\"lbl_transmission-list_td-transmission0\"]/div/span[1]");
private final String RecentTranslink_S = "Recent Transmission link";

private final By PatientSummarylink_OR = By.xpath("//*[@id=\"sub-header\"]/div/a[4]");
private final String PatientSummarylink_S = "Patient Summary  link";


private final By ScheduleSaveButton_OR = By.xpath("//*[@id=\"printable\"]/mat-dialog-actions/div/button[2]");
private final String ScheduleSaveButton_S = "Schedule Save Button";

private final By calenderFromDate_OR = By.xpath("(//button[@aria-label='Open calendar'])[1]");
private final String calenderFromDate_S = "Patient Summary From Date";

private final By calenderTodaysDate_OR = By.xpath("//td[@aria-selected='true']");
private final String calenderTodaysDate_S = "Patient Summary Today Date";

private final By FromDate_OR = By.xpath("//input[@Id='mnu_view-snapshot_fromDate']");
private final String FromDate_S = "Patient Summary From Date";

private final By drpDownDateRange_OR = By.xpath("//mat-select[@id='dd_view-snapshot_dateRange']");
private final String drpDownDateRange_S = "Date Range Drop down";

private final String dateRangeDrpdownOptions_OR= "(//div[@id='dd_view-snapshot_dateRange-panel']/mat-option)[{0}]";
private final String dateRangeDrpdownOptions_S ="Date Range Options";

private final By textBoxMarkedAsBilled_OR= By.xpath("//input[@id='mnu_view-snapshot_billing']");
private final String textBoxMarkedAsBilled_S ="Marked As Billed Text Box";

private final By btnCancelInBillingSection_OR= By.xpath("//button[@id='btn_view-snapshot_cancelBilling']");
private final String btnCancelInBillingSection_S ="Cancel button in Billing Section";

private final By btnSaveInBillingSection_OR= By.xpath("//button[@id='btn_customer_saveBilling']");
private final String btnSaveInBillingSection_S ="Save buttong in Billing Section";


private final By MarkedAsBilledHighlighted_OR= By.xpath("//input[@id='mnu_view-snapshot_billing'][@aria-describedby='mat-error-4']");
private final String MarkedAsBilledHighlighted_S ="Marked as billed highlighted in Red";

private final By MarkedAsBilledValidDate_OR= By.xpath("//td[@aria-selected='true']//preceding::td[@class='mat-calendar-body-cell mat-focus-indicator ng-star-inserted']");
private final String MarkedAsBilledValidDate_S ="Marked as billed valid date";

private final By imgCalendarMarkedAsBilled_OR= By.xpath("//input[@Id='mnu_view-snapshot_billing']/parent::div/following-sibling::div//button");
private final String imgCalendarMarkedAsBilled_S ="Marked as billed Calendar image";

//dummy xpath
private final By nextTransmissionHighlighted_OR= By.xpath("//div[@id='snapshotReportNextTransDt'][contains(@style,'red')]");
private final String nextTransmissionHighlighted_S ="Next Transmission Highlighted in Red";


private final By txtNoteInBillingSection_OR= By.xpath("//div[@id='lbl_view-snapshot_billingTransmissionNote']");
private final String txtNoteInBillingSection_S ="Note Text in billing section";

private final By lnkSchedule_OR= By.xpath("//div[@id='lbl_view-snapshot_schedule']/a[@class='btn btn-link']");
private final String lnkSchedule_S ="Schedule Link";

private final By errorMessage_OR= By.xpath("//div[@role='alertdialog']");
private final String errorMessage_S ="Error Message";

private final By parmanentScheduleCalendar_OR= By.xpath("(//button[@aria-label='Open calendar'])[4]");
private final String parmanentScheduleCalendar_S ="Error Message";
//dummy
private final By scheduleNote1_OR= By.xpath("//span[@id='scheduleNote1']");
private final String scheduleNote1_S ="Schedule Not";


Map<String,String> savedDatas = new LinkedHashMap<>();



//Method to verify billing section is displayed

public void clickOnPatientSummaryLink() {
	clickElement(PatientSummarylink_OR, PatientSummarylink_S);
	loadingWithoutReport();
	extentReport.reportScreenShot("Clicked on Patient Summary link");
}

public boolean verifyBillingsection() {
	Actions a=new Actions(driver);
	Boolean flag = false;
	//To scroll to the Billing section
	WebElement billing= driver.findElement(BillingNextTransmissionDateInfo_OR);
	a.moveToElement(billing);
	a.perform();
	if(visibilityOfElementLocatedWithReport(patientSummaryBilling_OR, patientSummaryBillingS)) {
		flag = true;
		String patientSummaryBilling= driver.findElement(patientSummaryBilling_OR).getText();
		extentReport.reportPass("Billing section heading is displayed as "  +patientSummaryBilling);
	} else {
		extentReport.reportFail("Billing section heading is not displayed");
	}
	return flag;

}
//Method to verify billing information is displayed

public boolean verifyBillingInfo() {
	Boolean flag = false;
	
	if(visibilityOfElementLocatedWithReport(BillingLastBilledDate_OR, BillingLastBilledDate_S)) {
		flag = true;
		
		String LastBilledHeading=driver.findElement(BillingLastBilledDate_OR).getText();
		
		extentReport.reportPass("Last Billed Date heading under Billing section is displayed as "+LastBilledHeading);
		
	} else {
		extentReport.reportFail("Last Billed Date under Billing section is not displayed");
	}
	if(visibilityOfElementLocatedWithReport(BillingNextBilledDate_OR, BillingNextBilledDate_S)) {
		flag = true;
		String NextBilledHeading=driver.findElement(BillingNextBilledDate_OR).getText();

		extentReport.reportPass("Next Billed Date under Billing section is displayed as  "+NextBilledHeading);
	} else {
		extentReport.reportFail("Next Billed Date under Billing section is not displayed");
	}
	if(visibilityOfElementLocatedWithReport(BillingNextTransmissionDate_OR, BillingNextTransmissionDate_S)) {
		flag = true;
		String NextTransmissionHeading=driver.findElement(BillingNextTransmissionDate_OR).getText();

		extentReport.reportPass("Next Transmission Date under Billing section is displayed as  "+NextTransmissionHeading);
	} else {
		extentReport.reportFail("Next Transmission Date under Billing section is not displayed");
	}
	return flag;
}
//Method to verify billing section  values are displayed
public boolean verifyBillingValues() {
	Boolean flag = false;
	
	if(visibilityOfElementLocatedWithReport(BillingLastBilledDateInfo_OR, Billing_LastBilledDateInfo_S)) {
		flag = true;
		
		String BillingLastDate=driver.findElement(BillingLastBilledDateInfo_OR).getText();
		
		extentReport.reportPass("Last Billed Date under Billing section is displayed as   "+BillingLastDate);
		
	} else {
		extentReport.reportFail("Last Billed Date under Billing section is not displayed");
	}
	if(visibilityOfElementLocatedWithReport(BillingNextBilledDateInfo_OR, BillingNextBilledDateInfo_S)) {
		flag = true;
		String BillingNextDate=driver.findElement(BillingNextBilledDateInfo_OR).getText();

		extentReport.reportPass("Next Billed Date under Billing section is displayed as   "+BillingNextDate);
	} else {
		extentReport.reportFail("Next Billed Date under Billing section is not displayed");
	}
	if(visibilityOfElementLocatedWithReport(BillingNextTransmissionDateInfo_OR, BillingNextTransmissionDateInfo_S)) {
		flag = true;
		String NextTransmissionDate=driver.findElement(BillingNextTransmissionDateInfo_OR).getText();

		extentReport.reportPass("Next Transmission Date under Billing section is displayed as   "+NextTransmissionDate);
	} else {
		extentReport.reportFail("Next Transmission Date under Billing section is not displayed");
	}
	return flag;
}

//Method to verify default system  section is displayed
public boolean defaultSystemDate() {
	String success = "";
	Boolean flag = false;
	
	try {
		if(!(isEnabled(BillingSystemDate_OR))) {
			
			success = "Billing System Date is  not populated";
		}		
			else
				flag = true;
			
		elementToBeClickable(BillingSystemDate_OR, BillingSystemDate_S);
			success = "Billing System Date is  populated";
		
				
	}
	catch (Exception e) {

		throw new AssertionError(e.getMessage());
		
	}

	return flag;
}
public void enterSystemDate(String text) {
	elementToBeClickable(BillingSystemDate_OR, BillingSystemDate_S);
	WebElement clear=driver.findElement(BillingSystemDate_OR);
	clear.sendKeys(Keys.CONTROL + "a");
	clear.sendKeys(Keys.DELETE);
	sendKeys(BillingSystemDate_OR, text);
}
public String selectBilling_checkbox() {
	String success = "";
	
	try {
		clickElement(BillingCheckbox_OR, Billing_Checkbox_S);
		if(!(isEnabled(BillingCheckbox_OR))) {
		success = " Billing Checkbox is not selected";
		}

		else 
		{
			success = " Billing Checkbox is selected ";
			System.out.println(success);

		}
	
	} catch (Exception e) {
		success = "Billing checkbox is NOT selected";
		throw new AssertionError(e.getMessage());
	}

	return success;
}
public void patientSummarySave() throws InterruptedException
{
	scrollToView(BillingSaveButton_OR);
	presenceOfElementLocatedWithoutReport(BillingSaveButton_OR, BillingSaveButton_S);
	clickElement(BillingSaveButton_OR, BillingSaveButton_S);
	
}
public boolean manualSchedule() throws InterruptedException {	
	boolean flag= false;
	scrollToView(BillingSchedule_OR);
	String success = "";
	presenceOfElementLocatedWithoutReport(BillingSchedule_OR, BillingSchedule_S);
	clickElement(BillingSchedule_OR, BillingSchedule_S); 
	driver.findElement(ScheduleType_OR).click();
	new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ScheduleTypeManual_OR));
	driver.findElement(ScheduleTypeManual_OR).click();
	String scheduletype= driver.findElement(ScheduleType_OR).getText();
	try {
	
		if (scheduletype.equals("Manual entry calendar")){
			flag = true;
		List<WebElement> transmitDate= driver.findElements(ScheduleTransmitDate_OR);
		List<WebElement> calendars= driver.findElements(ScheduleCalendar_OR);
		transmitDate.get(1).sendKeys(Keys.CONTROL+"a",  Keys.DELETE);
		transmitDate.get(1).sendKeys(Keys.TAB, Keys.ENTER);		
		//driver.findElement(ScheduleCalendar_OR).click();
		new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("mat-calendar-table")));
		
		selectDate("10","MAR", "2022");
		transmitDate.get(1).sendKeys(Keys.TAB, Keys.TAB, Keys.BACK_SPACE);	

		calendars.get(1).click();	
		new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("mat-calendar-table")));


		selectDate("26","APR", "2022");


		clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S); 
		success = "Manual schedule is created successfully";

					}
		else {
			success = "Manual schedule cannot be created";}
	}
		catch (Exception e) {
		
		throw new AssertionError(e.getMessage());
	}
	return flag;

	}

public  void selectDate(String day, String month,  String year) throws InterruptedException {
	String monthYearValue=driver.findElement(By.className("mat-calendar-header")).getText();
	while(!(monthYear(monthYearValue)[0].equals(month) && monthYear(monthYearValue)[1].equals(year))) {
	driver.findElement(By.xpath("/html/body/div[2]/div[4]/div/mat-datepicker-content/mat-calendar/mat-calendar-header/div/div/button[3]")).click();
	 monthYearValue=driver.findElement(By.className("mat-calendar-header")).getText();
	 System.out.println(monthYearValue);
		System.out.println("Mee");

	System.out.println( monthYear(monthYearValue)[1]);

	 }
	 List<WebElement> datesAll=	driver.findElements(By.className("mat-calendar-body-cell-content"));
	 int nodes=datesAll.size();

	 for (int i=0;i<nodes;i++)
	 {
	 	String date=datesAll.get(i).getText();
	 	if (date.equals(day)) {
	 		datesAll.get(i).click();

	 		Thread.sleep(1000);
	 		break;
	 	
	 }			
}	
	 
}
//Date

	public static String[] monthYear(String monthYearValue) {
		return monthYearValue.split(" ");
		
	}
public boolean automaticSchedule() throws InterruptedException {	
	Boolean flag = false;
	scrollToView(BillingSchedule_OR);
	String success = "";
	presenceOfElementLocatedWithoutReport(BillingSchedule_OR, BillingSchedule_S);
	clickElement(BillingSchedule_OR, BillingSchedule_S); 
	driver.findElement(ScheduleType_OR).click();
	Thread.sleep(3000);
	//new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfElementLocated(ScheduleTypeSmart_OR));
	driver.findElement(ScheduleTypeSmart_OR).click();
	System.out.println(driver.findElement(ScheduleType_OR).getText());
	 String scheduletype=driver.findElement(ScheduleType_OR).getText();
	//String schedule=driver.findElement(ScheduleType_OR).getText();

try {

		if (scheduletype.contains("SmartSchedule™ calendar")){
			flag = true;
			if (driver.findElement(PermanentSchedule_OR).isEnabled()){
		//perform Permanent schedule mode 1
		List<WebElement> transmitDate= driver.findElements(ScheduleTransmitDate_OR);
		transmitDate.get(1).sendKeys(Keys.CONTROL+"a",  Keys.DELETE);
		transmitDate.get(1).sendKeys(Keys.TAB, Keys.ENTER);		
		String nextTransmissionScheduled=(transmitDate.get(1).getText());
		new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("mat-calendar-table")));

		selectDate("11","JUN", "2022");
					
		//driver.findElement(ScheduleCalendar_OR).click();
		driver.findElement(PermanentTransmitEvery_OR).sendKeys("9M");
		clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S); 
		success = "Automatic schedule is created successfully";
		}
		else {
				
		}

		new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(BillingSchedule_OR));

			clickElement(BillingSchedule_OR, BillingSchedule_S);
		if (scheduletype.contains("SmartSchedule™ calendar")){
		driver.findElement(PermanentScheduleSpecificDay_OR).click();	
			if (driver.findElement(PermanentScheduleSpecificDay_OR).isEnabled()){
			
		//perform Permanent schedule mode 2
					
				//driver.findElement(ScheduleCalendar_OR).click();

				//
				driver.findElement(PermanentWeek_OR).sendKeys("4");
				driver.findElement(PermanentDay_OR).sendKeys("TUE");
				Thread.sleep(3000);
				driver.findElement(PermanentMonth_OR).sendKeys("MAR");
				PermanentTransmitEvery_OR.findElement(driver).sendKeys("9M");
//				List<WebElement> transmitDate= driver.findElements(ScheduleTransmitDate_OR);
//				transmitDate.get(1).sendKeys(Keys.CONTROL+"a",  Keys.DELETE);
//				transmitDate.get(1).sendKeys(Keys.TAB, Keys.ENTER);		
//				//driver.findElement(ScheduleCalendar_OR).click();
//				new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("mat-calendar-table")));
//
//				selectDate("11","JUN", "2022");
				clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S); 
				Thread.sleep(5000);
				Actions a=new Actions(driver);
				//To scroll to the Billing section
				//a.sendKeys(Keys.HOME).build().perform();
				driver.switchTo().alert().accept();
				success = "Automatic schedule is created successfully";
		}	
			else {}
					
		}
		else {}}
		else {
			success = "Automatic schedule cannot be created";}
	}
		catch (Exception e) {
		
		throw new AssertionError(e.getMessage());
		}
	 
	return flag;
}

//method for Schedule type None
public boolean noneSchedule() throws InterruptedException {	
	Boolean flag = false;
	scrollToView(BillingSchedule_OR);
	String success = "";
	presenceOfElementLocatedWithoutReport(BillingSchedule_OR, BillingSchedule_S);
	clickElement(BillingSchedule_OR, BillingSchedule_S); 
	System.out.println(driver.findElement(ScheduleType_OR).getText());
	WebElement scheduleDropdown= driver.findElement(ScheduleType_OR);
	scheduleDropdown.click();
	new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfElementLocated(ScheduleTypeNone_OR));
	driver.findElement(ScheduleTypeNone_OR).click();		
	System.out.println(driver.findElement(ScheduleType_OR).getText());
	String scheduletype=driver.findElement(ScheduleType_OR).getText();
	//String schedule=driver.findElement(ScheduleType_OR).getText();

try {

		if (scheduletype.equals("None")){
			flag = true;		
		System.out.println(driver.findElement(ScheduleNone_OR).getText());
		String message=driver.findElement(ScheduleNone_OR).getText();
		success = "None schedule is seleced successfully with the messsage"+message;
		
		

		}	
			else {
		success = "None schedule cannot be created";}
	}
		catch (Exception e) {
		
		throw new AssertionError(e.getMessage());
		}
	 
	return flag;
}

public boolean nextTransmission() throws AWTException {
	boolean flag = false;
	try {
		
		scrollToView(BillingSchedule_OR);
		String success = "";
		presenceOfElementLocatedWithoutReport(BillingSchedule_OR, BillingSchedule_S);
		clickElement(BillingSchedule_OR, BillingSchedule_S); 
		driver.findElement(ScheduleType_OR).click();
		//new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfElementLocated(ScheduleTypeSmart_OR));
		driver.findElement(ScheduleTypeSmart_OR).click();
		System.out.println(driver.findElement(ScheduleType_OR).getText());
		 String scheduletype=driver.findElement(ScheduleType_OR).getText();
		//String schedule=driver.findElement(ScheduleType_OR).getText();

			if (scheduletype.contains("SmartSchedule™ calendar")){
				driver.findElement(By.xpath("//*[@id=\"permDatePickerRadioButton\"]/label/div[1]")).click();
				if (driver.findElement(PermanentSchedule_OR).isEnabled()){
			//perform Permanent schedule mode 1
			List<WebElement> transmitDate= driver.findElements(ScheduleTransmitDate_OR);
			transmitDate.get(1).sendKeys(Keys.CONTROL+"a",  Keys.DELETE);
			transmitDate.get(1).sendKeys(Keys.TAB, Keys.ENTER);		
			new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("mat-calendar-table")));
			selectDate("31","OCT", "2022");
			transmitDate.get(1).sendKeys(Keys.CONTROL + "a");
			transmitDate.get(1).sendKeys(Keys.CONTROL + "c");
			String nextTransmissionScheduled=(String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);

			System.out.println(nextTransmissionScheduled);


			driver.findElement(PermanentTransmitEvery_OR).sendKeys("9M");
			transmitDate.get(1).click();

			clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S);
			//To scroll to the Billing section
			//a.sendKeys(Keys.HOME).build().perform();
			//driver.switchTo().alert().accept();
			success = "Automatic schedule is created successfully";
			driver.navigate().refresh();
			new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.visibilityOfElementLocated(RecentTranslink_OR));

			driver.findElement(RecentTranslink_OR).click();
			System.out.println("meenu");
			loading();
			driver.findElement(PatientSummarylink_OR).click();
			System.out.println("bheem");


			System.out.println(nextTransmissionScheduled);

			String billingNextTransmission=driver.findElement(BillingNextTransmissionDateInfo_OR).getText();
			//if( billingNextTransmission.startsWith("0")) {
				String billingNextTransmissionDate=billingNextTransmission.replace("-", "/").replaceFirst("^0+(?!$)", "");
			//	String billingNextTransmissionDate=billingNextTransmission.replace("-", "/").replaceFirst("0","");
			if((billingNextTransmissionDate).equals(nextTransmissionScheduled)){
				flag=true;

				extentReport.reportPass("Next Transmission Date under Billing section is same as Scheduled next transmission as   "+billingNextTransmissionDate);
			} 	else {
				extentReport.reportFail("Next Transmission Date under Billing and schedule section is not same");
			}
			}

			else {
	success = "Automatic schedule not created ";
}
			}
			

			}
catch (Exception e) {

	throw new AssertionError(e.getMessage());
	
}
return flag;
	}

public String selectingDateFromCalendar() {
	elementToBeClickable(imgCalendarFromDate_OR, imgCalendarFromDate_S);
	clickElement(imgCalendarFromDate_OR, imgCalendarFromDate_S);
	ca_ClinicLocationsPage.selectRandomElementInList(calendarDates_OR, calendarDates_S);
	String fromSelectedDate = driver.findElement(FromDate_OR).getText();
	return fromSelectedDate;

}
	public String enteringToDate(String toDate) {
		sendKeys(toDate_OR, toDate_S);
		return toDate;

	}
	
	public boolean verifySelectedFromDate() {
		Boolean isSelectedDateDisplayed=false;
		
		if(driver.findElement(FromDate_OR).getText().equals(selectingDateFromCalendar()))
		{
			isSelectedDateDisplayed=true;
		}else {
			extentReport.reportFail("Selected Date is mismatch");
		}
		return isSelectedDateDisplayed;
	}

	public boolean verifySelectedToDate(String toDate) {
		Boolean isSelectedDateDisplayed=false;
		
		if(driver.findElement(toDate_OR).getText().equals(enteringToDate(toDate)))
		{
			isSelectedDateDisplayed=true;
		}else {
			extentReport.reportFail("Selected Date is mismatch");
		}
		return isSelectedDateDisplayed;
		
	}
	
	public String selectDateRangeOptions(String option) {
		elementToBeClickable(drpDownDateRange_OR, drpDownDateRange_S);
		loadingWithoutReport();
		clickElement(drpDownDateRange_OR, drpDownDateRange_S);
		String Week1="";
		String Week2="";
		String days31="";
		String days91="";
		String days120="";
				
		switch (option) {
		case "1 week":
			elementToBeClickable(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "2")), dateRangeDrpdownOptions_S);
			clickElement(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "2")), dateRangeDrpdownOptions_S);	
			Week1= "7 days difference for From and To dates";
			break;
		case "2 week":
			elementToBeClickable(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "3")), dateRangeDrpdownOptions_S);
			clickElement(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "3")), dateRangeDrpdownOptions_S);	
			Week2= "14 days difference for From and To dates";
			break;
		case "31 days":
			elementToBeClickable(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "4")), dateRangeDrpdownOptions_S);
			clickElement(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "4")), dateRangeDrpdownOptions_S);
			days31= "31 days difference for From and To dates";
			break;
		case "91 days":
			elementToBeClickable(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "5")), dateRangeDrpdownOptions_S);
			clickElement(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "5")), dateRangeDrpdownOptions_S);
			days91= "91 days difference for From and To dates";
			break;
		case "120 days":
			elementToBeClickable(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "6")), dateRangeDrpdownOptions_S);
			clickElement(By.xpath(dateRangeDrpdownOptions_OR.replace("{0}", "6")), dateRangeDrpdownOptions_S);
			days120= "120 days difference for From and To dates";
			break;
		default:
			System.out.println("Not able to find the optionin dropdown");
		}
		return option;

	}
	
	public boolean selectDateRange(String option) {
		Boolean isOptionsSelectable=false;
		if(isDisplayedWithoutReport(drpDownDateRange_OR, drpDownDateRange_S)) {
			selectDateRangeOptions(option);
			isOptionsSelectable=true;
		} else {
			extentReport.reportFail("Date Range is not Displayed");
			
		}
		return isOptionsSelectable;
	}
	
	
	public String addDays(String toDate, String duration){
	    try {
	        String[] arrFromDate = toDate.split("/");
	        int fromMonth = Integer.parseInt(arrFromDate[0])-1;
	        int fromDay = Integer.parseInt(arrFromDate[1]);
	        int fromYear = Integer.parseInt(arrFromDate[2]);
	        int intDuration = Integer.parseInt(duration);
	        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	        Calendar cal = Calendar.getInstance();
	        cal.set(Calendar.DAY_OF_MONTH, fromDay);
	        cal.set(Calendar.MONTH, fromMonth);
	        cal.set(Calendar.YEAR, fromYear);   
	        cal.add(Calendar.DAY_OF_MONTH, intDuration);
	        String fromDate = sdf.format(cal.getTime());
	        return fromDate;
	    } catch (NumberFormatException e) {
	        e.printStackTrace();
	        return null;
	    }
	    }
	public boolean verifyDateRange(String duration) {
		String currentDate = driver.findElement(toDate_OR).getText();
		rowMap.put("SystemDate", currentDate);		
		String selectedDate = driver.findElement(fromDate_OR).getText();
		String fromDate = addDays(currentDate, duration);
		boolean isToDateCorrect = false;
		if(selectedDate.equals(fromDate)) {
			isToDateCorrect=true;			
		}
		return isToDateCorrect;
		
	}
	
	public boolean verifyPrintButton() {
		Boolean isPrintButtonDisplayed=false;
		
		if(isDisplayedWithoutReport(btnPrint_OR, btnPrint_S)) {
			clickElement(btnPrint_OR, btnPrint_S);
			isPrintButtonDisplayed=true;
			
		} else {
			extentReport.reportFail("Print button is not Displayed");
			
		}
		return isPrintButtonDisplayed;
		
	}
	
	public boolean verifyPDFReport() {
		Boolean isReportDisplayed=false;
		if(isDisplayedWithoutReport(coverPage_OR,coverPage_S)) {
			extentReport.reportPass("Cover page is Displayed");
			scrollToViewWithoutReport(episodesCount_OR, episodesCount_S);
			extentReport.reportScreenShot("Cover page is displayed in PDF report");
			if(isDisplayedWithoutReport(episodesCount_OR,episodesCount_S)) {
				extentReport.reportPass("Episodes count is Displayed");
				extentReport.reportScreenShot("Episodes count is displayed in PDF report");
				scrollToViewWithoutReport(remoteTransmission_OR, remoteTransmission_S);
				if(isDisplayedWithoutReport(remoteTransmission_OR,remoteTransmission_S)) {
					extentReport.reportPass("Remote Transmission count is Displayed");
					extentReport.reportScreenShot("Remote Transmission count is displayed in PDF report");
					scrollToViewWithoutReport(listOfEpisodes_OR, listOfEpisodes_S);
					if(isDisplayedWithoutReport(listOfEpisodes_OR,listOfEpisodes_S)) {
						extentReport.reportPass("List of Episodes are Displayed");
						extentReport.reportScreenShot("List of Episodes are displayed in PDF report");
						isReportDisplayed=true;
						clickElement(closeButtonInPDF_OR, closeButtonInPDF_S);
					} else {
						extentReport.reportFail("List of Episodes are not Displayed");
					}
					
				} else {
					extentReport.reportFail("Remote Transmission count is not Displayed");
				}
				
			} else {
				extentReport.reportFail("Episodes count is not Displayed");
			}
			
		} else {
			extentReport.reportFail("Cover page is not Displayed");
		}
		return isReportDisplayed;

	}

	
	public boolean verifyTransmissionSummary() {
	 Boolean isTransmissionSummaryDisplayed=false;
	 if(isDisplayedWithoutReport(transmissionSummary_OR,transmissionSummary_S)) {
		 isTransmissionSummaryDisplayed=true;
	} else {
		extentReport.reportFail("Transmission Summary Section is not displayed ");
		
	}
	return isTransmissionSummaryDisplayed;
	}
	
	public boolean verifyEpisodesCount() {
		Boolean isEpisodesCountDisplayed=false;
		 if(isDisplayedWithoutReport(episodesCountInTransSummary_OR,episodesCountInTransSummary_S)) {
			 isEpisodesCountDisplayed=true;
		} else {
			extentReport.reportFail("Episodes count Section is not displayed ");
		}
		return isEpisodesCountDisplayed;
	}
	
	public boolean verifyRemoteTransmissions() {
		Boolean isRemoteTransmissionDisplayed=false;
		 if(isDisplayedWithoutReport(remoteTransmissionInTransSummary_OR,remoteTransmissionInTransSummary_S)) {
			 isRemoteTransmissionDisplayed=true;
		} else {
			extentReport.reportFail("Episodes count Section is not displayed ");
		}
		return isRemoteTransmissionDisplayed;
	}
	
	public boolean verifySubSectionEpisodesCount() throws InterruptedException {
		Boolean isEpisodeCountDisplayed=false;
		if (isDisplayedWithoutReport(episodesCountSubSection_OR, episodesCountSubSection_S)) {
			int size = findElementslist(episodesCountSubSection_OR).size();
			if (size == 6) {
				if (isDisplayedWithoutReport(thisReportPeriod_OR, thisReportPeriod_S)) {
					int thisReportSize = findElementslist(thisReportPeriod_OR).size();
					if (thisReportSize == 6) {
						isEpisodeCountDisplayed = true;
					} else {
						extentReport.reportFail("Count of This report period is mismatched");
					}
				}
				if (isDisplayedWithoutReport(sinceEnrolledInMerlinnet_OR, sinceEnrolledInMerlinnet_S)) {
					int sinceEnrollmentSize = findElementslist(sinceEnrolledInMerlinnet_OR).size();
					if (sinceEnrollmentSize == 6) {
						isEpisodeCountDisplayed = true;
					}
				} else {
					extentReport.reportFail("Count of This report period is mismatched");
				}
			} else {
				extentReport.reportFail("Count of Episode count are mismatched");
			}
		} else {
			extentReport.reportFail("Episodes count are not displayed");
		}
		return isEpisodeCountDisplayed;
	}
	
	public boolean verifyRemoteTransmissionsSection() {
		Boolean isRemoteTransmissionsSectionDisplayed=false;
		if(isDisplayedWithoutReport(scheduled_OR, scheduled_S)&&
		isDisplayedWithoutReport(patientInitiated_OR, patientInitiated_S)&
		isDisplayedWithoutReport(alertInitiated_OR, alertInitiated_S)) {
			isRemoteTransmissionsSectionDisplayed=true;			
		} else {
			extentReport.reportFail("Remote Transmission Section does not contains all sub sections");
		}
		
		return isRemoteTransmissionsSectionDisplayed;
	}
	
	public boolean verifyAFBurden() {
		Boolean isAFBurdenDisplayed=false;
		if(isDisplayedWithoutReport(afBurden_OR, afBurden_S)){
			isAFBurdenDisplayed=true;
		}
		return isAFBurdenDisplayed;
	}
	
	public boolean verifyAFFromAndToDate() {
		Boolean isAfFromAndToDateDisplayed=false;
		if(!getText(fromDateAF_OR).equals("")){
			isAfFromAndToDateDisplayed=true;
		}
		return isAfFromAndToDateDisplayed;
	}
	
	public boolean verifyXAxis() throws InterruptedException {
		Boolean isXAxisDisplayed12Months = false;
		if (isDisplayedWithoutReport(xAxis_OR, xAxis_S)) {
			int size = findElementslist(xAxis_OR).size();
			if (size == 12) {
				isXAxisDisplayed12Months = true;
			} else {
				extentReport.reportFail("AF burden plot x-axis is not divided into 12 months");
			}

		}
		return isXAxisDisplayed12Months;
	}  
	
	public boolean verifyYAxis() throws InterruptedException {
		Boolean isYAxisDisplayed5QuarterlyPercentiles = false;
		if (isDisplayedWithoutReport(yAxis_OR, yAxis_S)) {
			int size = findElementslist(yAxis_OR).size();
			if (size == 5) {
				isYAxisDisplayed5QuarterlyPercentiles = true;
			} else {
				extentReport.reportFail("AF burden plot y-axis is not divided into 5 Quarterly Percentiles");
			}

		}
		return isYAxisDisplayed5QuarterlyPercentiles;
	}
	
	public boolean verifyFootNote(String value) throws InterruptedException {
		Boolean isFootNoteDisplayed = false;
		if (isDisplayedWithoutReport(footNote_OR, footNote_S)) {
			if(getText(footNote_OR).contains(value)) {
				isFootNoteDisplayed = true;
			} else {
				extentReport.reportFail("Foot Note is mismatched");
			}
			

		}
		return isFootNoteDisplayed;
	}

	public boolean verifyMarkedAsBilledCheckbox() {
		Boolean isFootNoteDisplayed = false;
		if (isDisplayedWithoutReport(BillingCheckbox_OR, Billing_Checkbox_S)) {
				isFootNoteDisplayed = true;
		}
		return isFootNoteDisplayed;
	}
	
	public boolean verifyMarkedAsBilledDate() {
		Boolean isCurrentDateDisplayed=false;
		clickElement(BillingCheckbox_OR, Billing_Checkbox_S);
		if(getText(textBoxMarkedAsBilled_OR).equals(rowMap.get("SystemDate"))) {
			isCurrentDateDisplayed=true;
		}else {
			extentReport.reportFail("Marked As Billed Text Box is not displayed Current Date");
			
		}
		return isCurrentDateDisplayed;
	}
	
	public boolean verifySaveAndCancelButton() {
		Boolean isSaveCancelDisplayed = false;
		if (isDisplayedWithoutReport(btnSaveInBillingSection_OR, btnSaveInBillingSection_S)&&
				isDisplayedWithoutReport(btnCancelInBillingSection_OR, btnCancelInBillingSection_S)) {
			isSaveCancelDisplayed = true;
		}
		return isSaveCancelDisplayed;
	}
	
	public boolean verifyBilledDateAfterClickingCancel() {
		Boolean isCurrentDateNotDisplayed=false;
		clickElement(btnCancelInBillingSection_OR, btnCancelInBillingSection_S);
		if(getText(textBoxMarkedAsBilled_OR).isEmpty()) {
			isCurrentDateNotDisplayed=true;
		}
		return isCurrentDateNotDisplayed;
		
	}
	
	public void enterInvalidDateInMarkedAsBilled(String value) {
		clickElement(BillingCheckbox_OR, Billing_Checkbox_S);
		sendKeys(textBoxMarkedAsBilled_OR, value);
		clickElement(btnSaveInBillingSection_OR, btnSaveInBillingSection_S);
	}
	
	public boolean verifyMarkedAsBilledHighlighted() {
		Boolean isMarkedAsBilledHighlighted=false;
		if (isDisplayedWithoutReport(MarkedAsBilledHighlighted_OR, MarkedAsBilledHighlighted_S)) {
			isMarkedAsBilledHighlighted=true;
		}
		return isMarkedAsBilledHighlighted;
	}
	
	public void selectValidDateInBilledDate() {
		
		clickElement(imgCalendarMarkedAsBilled_OR, imgCalendarMarkedAsBilled_S);
		ca_ClinicLocationsPage.selectRandomElementInList(MarkedAsBilledValidDate_OR, MarkedAsBilledValidDate_S);
		String billedDate = driver.findElement(textBoxMarkedAsBilled_OR).getText();
		rowMap.put("BilledDate", billedDate);		
		clickElement(btnSaveInBillingSection_OR, btnSaveInBillingSection_S);
		
	}
	
	public boolean verifyDateInLastBilledDate() {
		Boolean isBilledDateDisplayedinLastBilled=false;
		//need to change once defect is fixed
		if(getText(textBoxMarkedAsBilled_OR).equals(rowMap.get("BilledDate"))) {
			isBilledDateDisplayedinLastBilled=true;
		}else {
			extentReport.reportFail("Last Billed date is not displayed Billed Date");
			
		}
		return isBilledDateDisplayedinLastBilled;

	}
	
	public boolean verifyNextTranmissionHighlighted(String value) {
		Boolean isnextTransmissionHighlighted_OR=false;
		if (isDisplayedWithoutReport(nextTransmissionHighlighted_OR, nextTransmissionHighlighted_S)&&
				getText(txtNoteInBillingSection_OR).contains(value)) {
			isnextTransmissionHighlighted_OR=true;
		}
		return isnextTransmissionHighlighted_OR;
	}
	
	public boolean verifyScheduleLink() {
		Boolean isScheduledLinkDisplayed=false;
		if (isDisplayedWithoutReport(lnkSchedule_OR, lnkSchedule_S)) {
			isScheduledLinkDisplayed=true;
		}
		return isScheduledLinkDisplayed;

	}
	
	
	public boolean verifyErrorMessage() {
		Boolean isErrorMessageDisplayed=false;
		if (isDisplayedWithoutReport(errorMessage_OR, errorMessage_S)) {
			isErrorMessageDisplayed=true;
		}
		return isErrorMessageDisplayed;
	}
	
	
	public boolean verifyDefaultFromDate(String patientAppDate) {
		Boolean isFromDateHavingDefaultValue=false;
		if(getText(FromDate_OR).equals(getText(BillingLastBilledDateInfo_OR))||
				equals(patientAppDate)) {
			isFromDateHavingDefaultValue=true;
		}
		return isFromDateHavingDefaultValue;
	}
	
	//31 or 91 days
	public boolean verifyNextBillableDate(String duration) {
		Boolean lastBilledDateValue=false;
		String lastBilledDate = getText(BillingLastBilledDateInfo_OR);
		String addedDays = addDays(lastBilledDate, duration);
		String nextBilledDate = getText(BillingNextBilledDateInfo_OR);
		rowMap.put("NextBilledDate", nextBilledDate);
		if(nextBilledDate.equals(addedDays)) {
			lastBilledDateValue=true;
		}
		return lastBilledDateValue;
	}
	
	public void clickScheduleLinkAndInvalidDate() {
		clickElement(lnkSchedule_OR, lnkSchedule_S);
		clickElement(parmanentScheduleCalendar_OR, parmanentScheduleCalendar_S);
		clickElement(todayDate_OR, todayDate_S);
		clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S);

		
	}
	
	public boolean verifyDataNotSaved() {
		Boolean isDataNotSaved=false;
		if(isDisplayedWithoutReport(errorMessageInScheduleLink_OR, errorMessageInScheduleLink_S)) {
			isDataNotSaved=true;
		}
		return isDataNotSaved;
	}
	
	public String selectDayBeforeNextBilledDate() {
		String dayBeforeNextBilledDate = addDays(rowMap.get("NextBilledDate"), "-1");
		sendKeys(parmanentScheduleStartingOn_OR, parmanentScheduleStartingOn_S, dayBeforeNextBilledDate);
		clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S);
		return dayBeforeNextBilledDate;
	}
	
	public boolean verifyNextTransmission() {
		Boolean isnextTransmissionHighlighted_OR=false;
		if (isDisplayedWithoutReport(nextTransmissionHighlighted_OR, nextTransmissionHighlighted_S)&&
				getText(nextTransmissionHighlighted_OR).equals(selectDayBeforeNextBilledDate())) {
			isnextTransmissionHighlighted_OR=true;
		}
		return isnextTransmissionHighlighted_OR;

	}
	
 public boolean verifyScheduleNote() {
	 Boolean isScheduleNoteDisplayed=false;
	 if(isDisplayedWithoutReport(scheduleNote1_OR, scheduleNote1_S)) {
		 isScheduleNoteDisplayed=true;
		}
		return isScheduleNoteDisplayed;

}
 
 public String selectDayAfterNextBilledDate() {
	 clickElement(lnkSchedule_OR, lnkSchedule_S);
	 clickElement(parmanentScheduleCalendar_OR, parmanentScheduleCalendar_S);
	 String dayBeforeNextBilledDate = addDays(rowMap.get("NextBilledDate"), "1");
	 clickElement(ScheduleSaveButton_OR, ScheduleSaveButton_S);
	 return dayBeforeNextBilledDate;
}
 
 public boolean verifyNextTransmissionAfterNextBilledDate() {
		Boolean isnextTransmissionHighlighted_OR=false;
		if (getText(nextTransmissionHighlighted_OR).equals(selectDayAfterNextBilledDate())) {
			isnextTransmissionHighlighted_OR=true;
		}
		return isnextTransmissionHighlighted_OR;

	}

 
	
}
