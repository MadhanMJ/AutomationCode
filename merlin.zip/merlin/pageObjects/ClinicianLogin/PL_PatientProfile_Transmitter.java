package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

// Author - Shafiya Sunkesala

public class PL_PatientProfile_Transmitter extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientProfile_Transmitter(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		
	}
	
	private final By editButton_OR = By.xpath("//button[@id='profileEditButton']/span");
	private final String editButton_S = "Edit button";
	private final By PP_Transmitter_Header_OR= By.xpath("//app-enroll-patient-transmitter[@functionmode='profile']/form/div[1]/div[1]");
	private final String PP_Transmitter_Header_S ="Transmitter Header in Patient Profile Transmitter Page";
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	
	//This section is not displayed added code, need to check
	private final By PP_Transmitter_DailyMIST_Text_OR= By.xpath("//mat-select[@id='mistThreshold']/div/div[1]/span/span");
	private final String PP_Transmitter_DailyMIST_Text_S= "Daily MIST Value";
	
	private final By PP_PatientTransmitter_OR= By.xpath("//mat-checkbox[@formcontrolname='mistFlg']");
	private final String PP_PatientTransmitter_S= "Patient Profile Patient Transmitter Status";
	
	//Poojitha
	private final By mistOverrideSymbol_OR = By.xpath("");
	private final String mistOverrideSymbol_S = "MIST Override Symbol";
	private final By nodcOverrideSymbol_OR = By.xpath("");
	private final String nodcOverrideSymbol_S = "NODC Override Symbol";
	private final By overrideSymbol_OR = By.xpath("");
	private final String overrideSymbol_S = "Transmitter page Override Symbol";
	private final By saveButton_OR = By.xpath("//button[@id='profileSaveButton']");
	private final String saveButton_S = "Save button";
	private final By mistDropdownPanel_OR = By.xpath("//div[@id='mat-select-11-panel']");
	private final String mistDropdownPanel_S = "MIST values dropdown";
	private final String mistDropdownValues_OR = "//div[@id='mat-select-11-panel']//mat-option[{0}]";
	private final String mistDropdownValues_S = "MIST Values in the dropdown";
	private final By nodcDropdownPanel_OR = By.xpath("");
	private final String nodcDropdownPanel_S = "NODC values dropdown";
	//Ends here
	
	private final By patientAppRegistrationDate_OR = By.xpath("(//span[@class='ng-star-inserted']/parent::div)[3]");
	private final String patientAppRegistrationDate_S = "Patient App Registration Date";
	
	
	//Poojitha
	public void clickEditButton()
	{
		clickElement(editButton_OR,editButton_S);
	}
	
	public void editMISTAndNODCValues(String mist, String nodc)
	{
		clickElement(mistDropdownPanel_OR,mistDropdownPanel_S);
		switch(mist)
		{
		case "3 days":
			clickElement(By.xpath(mistDropdownValues_OR.replace("{0}", "1")), mistDropdownValues_S);	
			break;
		case "4 days":
			clickElement(By.xpath(mistDropdownValues_OR.replace("{0}", "2")), mistDropdownValues_S);	
			break;
		case "5 days":
			clickElement(By.xpath(mistDropdownValues_OR.replace("{0}", "3")), mistDropdownValues_S);	
			break;
		case "6 days":
			clickElement(By.xpath(mistDropdownValues_OR.replace("{0}", "4")), mistDropdownValues_S);	
			break;
		case "7 days":
			clickElement(By.xpath(mistDropdownValues_OR.replace("{0}", "5")), mistDropdownValues_S);	
			break;
		}
		clickElement(nodcDropdownPanel_OR,nodcDropdownPanel_S);
		//Need to write code for selecting NODC values from the dropdown 
	}
    
	public void validateOverrideFeature()
	{
		scrollToViewWithoutReport(overrideSymbol_OR,overrideSymbol_S);
		if(isDisplayedWithoutReport(overrideSymbol_OR,overrideSymbol_S))
			extentReport.reportPass("Override symbol is displayed beside MIST and NODC labels");
		else
			extentReport.reportFail("Override symbol is displayed beside MIST and NODC labels");
	}
	public void validateMIST_NODCOverrideFeature()
	{
		scrollToViewWithoutReport(nodcOverrideSymbol_OR,nodcOverrideSymbol_S);
		if(isDisplayedWithoutReport(mistOverrideSymbol_OR,mistOverrideSymbol_S) || isDisplayedWithoutReport(nodcOverrideSymbol_OR,nodcOverrideSymbol_S))
			extentReport.reportPass("Override symbol is displayed beside MIST and NODC labels");
		else
			extentReport.reportFail("Override symbol is displayed beside MIST and NODC labels");
	}
	public void clickSaveButton()
	{
		clickElement(saveButton_OR,saveButton_S);
	}
	
	@Override
	public boolean verifyLandingPage() {
		Boolean transmitterPageCheck = false;
		if(isElementPresentwithoutException(PP_Transmitter_Header_OR,PP_Transmitter_Header_S)) {
			if(getText(PP_Transmitter_Header_OR, PP_Transmitter_Header_S).equals("Transmitter"))
			{
				transmitterPageCheck =true;				
				//invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
				extentReport.reportScreenShot("Patient Profile->Transmitter page is displayed");
			}
		}
		return transmitterPageCheck;
	}
	//Author :Shafiya Sunkesala
	public String getDailyMISTValue() {			
		String dailyMISTvalue = null;
		scrollToViewWithoutReport(PP_PatientTransmitter_OR, PP_PatientTransmitter_S);
		if(isElementPresentwithoutException(PP_Transmitter_DailyMIST_Text_OR,PP_Transmitter_DailyMIST_Text_S))
			dailyMISTvalue = getText(PP_Transmitter_DailyMIST_Text_OR,PP_Transmitter_DailyMIST_Text_S);
		//extentReport.reportScreenShot("Patient List Transmitter Page - Daily MIST actual value is: "+dailyMISTvalue);					
		return dailyMISTvalue;
	}
	//Author: Shafiya Sunkesala
    public boolean verifyDailyMISTValue(String value) throws Exception{
        Boolean dailyMIST = false;
        if(value.equals(getDailyMISTValue())) 
        	dailyMIST = true;
        	extentReport.reportScreenShot("Patient Profile Transmitter Page - Daily MIST actual value is: "+getDailyMISTValue()+ ", Expected value: "+value);      	
        return dailyMIST;
    }
    
    public String patientAppRegistrationDate() {
    	String RegistrationDate = getText(patientAppRegistrationDate_OR);
    	return RegistrationDate;
	}

}
