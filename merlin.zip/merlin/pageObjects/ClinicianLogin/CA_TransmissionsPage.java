package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_TransmissionsPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	
	/*
	 * Author: Gowshalya
	 */
	
	public CA_TransmissionsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	//snehal
	private final By transmissionHdr_OR = By.xpath("//div[@id='lbl_transmission_summary_transmission_date']");
	private final String transmissionHdr_S = "Transmission Page header";
	
	private final By icm_EpisodesAndEGMLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']");
	private final String icm_EpisodesAndEGMLink_S = "Episodes & EGM link";
	
	private final By nonICM_EpisodesAndEGMLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_1']");
	private final String nonICM_EpisodesAndEGMLink_S = "Episodes & EGM link";
	
	private final By patientSummaryLink_OR = By.xpath("//mat-toolbar-row[@id=\"sub-header\"]/div/a[4]");
	private final String patientSummaryLink_S = "Patient Summary link";
	
	public void clickOnICMEpisodesAndEGMLink() {
		clickElement(icm_EpisodesAndEGMLink_OR, icm_EpisodesAndEGMLink_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on Episodes & EGM link");
	}
	
	public void clickOnNonICMEpisodesAndEGMLink() {
		clickElement(nonICM_EpisodesAndEGMLink_OR, nonICM_EpisodesAndEGMLink_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on Episodes & EGM link");
	}

	public void clickOnPatientSummaryLink() {
		clickElement(patientSummaryLink_OR, patientSummaryLink_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on Patient Summary link");
	}
	
	@Override
	public boolean verifyLandingPage() {
		Boolean flag = false;

		if(isElementPresentwithoutException(transmissionHdr_OR, transmissionHdr_S)) {
			flag = true;
			extentReport.reportScreenShot("Transmission Page is displayed");
		} else {
			extentReport.reportScreenShot("Transmission Page is not displayed");
		}
		return flag;

	}
}
