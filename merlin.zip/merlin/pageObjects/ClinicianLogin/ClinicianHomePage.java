package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class ClinicianHomePage extends BasePage {

	/*
	 * AUTHOR: Vinay Babu
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public ClinicianHomePage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By quickLinks_button_OR = By.xpath("//*[@id=\"btn_transmission-list_archive\"]/span");

	private final String quickLinks_button_S = "Quick Links Button";

	// Each page class should have this overridden method of Verify Landing page

	//Poojitha - updated XPath names to reflect the correct field 
		private final By archive_button_OR = By.xpath("//*[@id=\"btn_transmission-list_archive\"]/span");
		private final String archive_button_S = "Quick Links Button";
		
		//Poojitha - Added XPath - Date: 28th Dec 2021
		private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper show']");
		private final String pageLoading_S = "Page loading symbol";
		//Ends here
		//Poojitha - Updated Override method as per new standards - Date: 28th Dec 2021
			@Override
			public boolean verifyLandingPage() throws InterruptedException {
				waitForLoading();
				Boolean clinicianHomePageCheck = false;
					if(visibilityOfElementLocatedWithoutReport(archive_button_OR,archive_button_S)) {
						invisibilityOfElementLocatedWithoutReport(pageLoading_OR,pageLoading_S);
						clinicianHomePageCheck=true;
					}
				return clinicianHomePageCheck;
			}
		}
