package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_CommunicationCenter extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	
	/*
	 * Author: Salin Gambhir
	 * for TC : NV-PA001-PatLst-01
	 */
	
	public CA_CommunicationCenter(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	
	private final By communicationCenterHdr_OR = By.xpath("dummyxpath");
	private final String communicationCenterHdr_S = "Communication Cneter Header page";
	
	
	@Override
	public boolean verifyLandingPage() {
		Boolean communicationCenterflag = false;

		if(isElementPresentwithoutException(communicationCenterHdr_OR, communicationCenterHdr_S)) {
			communicationCenterflag = true;
			extentReport.reportScreenShot("Communication Center Page is displayed");
		} else {
			extentReport.reportScreenShot("Communication Center Page is not displayed");
		}
		return communicationCenterflag;

	}
}