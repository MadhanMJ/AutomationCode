package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

//Author: Salin Gambhir

public class PL_PatientEnrollment_FollowUpSchedule extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientEnrollment_FollowUpSchedule(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By followUpScheduleHeader_OR = By.xpath("//div[@id='cdk-step-content-1-2']/app-followup-schedule/div[1]/div");
	private final String followUpScheduleHeader_S = "Labels present in Transmitter Page";
	
	
	//Poojitha
		private final By scheduleTypeHeader_OR = By.xpath("//mat-radio-group[@id='scheduleModeGroup']");
		private final String scheduleTypeHeader_S = "Schedule Type header";
		private final By cardiacMonitorDiagnostics_checkbox_OR = By.xpath("//mat-checkbox[@id='clearEpisodeEgmDiag']"); //dummy xpath
		private final String cardiacMonitorDiagnostics_checkbox_S = "Cardiac Monitor - Diagnostics, Episodes and EGMs checkbox";
		private final By smartScheduleStartDate_OR = By.xpath("//input[@id='permDatePicker']");
		private final String smartScheduleStartDate_S = "Smart schedule Calendra start date";
		private final By continueButton_OR = By.xpath("//button[@id='enrollContinueButton']");
		private final String continueButton_S = "Continue button";
	//Ends here		
	
		//Poojitha
		public boolean verifyCardiacMonitorCheckbox() {
			Boolean checkBox = false;
			scrollToViewWithoutReport(cardiacMonitorDiagnostics_checkbox_OR,cardiacMonitorDiagnostics_checkbox_S);
			if (isSelectedWithReport(cardiacMonitorDiagnostics_checkbox_OR,cardiacMonitorDiagnostics_checkbox_S).equals(true)) {
				checkBox = true;
				}
			return checkBox;
		}
		
		public static String generateSmartScheduleStartDate()
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-yyyy");
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DAY_OF_MONTH, 7);
			String smartScheduleStartDate = simpleDateFormat.format(c.getTime());
			return smartScheduleStartDate;
		}
		
		public void enterSmartScheduleStartDate()
		{
			sendKeys(smartScheduleStartDate_OR,smartScheduleStartDate_S,generateSmartScheduleStartDate());
		}
		
	public void clickContinueButton() {
		clickElement(continueButton_OR,continueButton_S);
	}
//Ends here
	
	@Override
	public boolean verifyLandingPage() {
		Boolean followUpSchedulePageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(scheduleTypeHeader_OR, scheduleTypeHeader_S)) {
			followUpSchedulePageCheck = true;
		}
		return followUpSchedulePageCheck;
	}
}