package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

//Author: Salin Gambhir

public class PL_PatientEnrollment_Complete extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientEnrollment_Complete(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By enrollCompleteHeader_OR = By.xpath("//div[starts-with(@id,'cdk-step-content')]/app-enroll-complete/div/div/merlin-section/mat-card/mat-card-content/header/div");
	private final String enrollCompleteHeader_S = "Patient Enroll Complete Page";
	
	//Poojitha
	private final By finishButton_OR = By.xpath("//div[starts-with(@id,'cdk-step-content')]/app-enroll-complete/div/div/merlin-section/mat-card/mat-card-content/div[3]/button");
	private final String finishButton_S = "Finish button";
	//Ends here
	
	//Poojitha
	public void clickFinishButton()
	{
		clickElement(finishButton_OR,finishButton_S);
	}
	
	@Override
	public boolean verifyLandingPage() {
		Boolean enrollCompletePageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(enrollCompleteHeader_OR, enrollCompleteHeader_S)) {
			enrollCompletePageCheck = true;
		}
		return enrollCompletePageCheck;
	}
	

}
