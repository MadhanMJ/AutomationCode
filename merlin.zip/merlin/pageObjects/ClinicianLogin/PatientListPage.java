package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentTest;
import com.opencsv.CSVReader;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class PatientListPage extends BasePage {

	public WebDriver driver;
	 public ExtentReport extentReport; ExtentTest extentTest;
	 
	TestDataProvider testDataProvider;
	private DataBaseConnector dataBase = new DataBaseConnector();
	DriverUtils drivUtil = new DriverUtils(driver, extentReport);
	Login login = new Login();
	CA_RecentTransmissionsPage recentTrnsPg = new CA_RecentTransmissionsPage(driver, extentReport);
	// PatientListPage patientListPage=new PatientListPage(driver, extentReport);
	LoginPageWithPOJO loginPage = new LoginPageWithPOJO(driver, extentReport);
	ClinicianHomeTopNavPage clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
	Assertions assertions = new Assertions(extentTest);

	public PatientListPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		testDataProvider = new TestDataProvider();
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By enrollNewPatientButton_OR = By.xpath("//button[@id='btn_patient-list_navigateToNew']/span");
	private final String enrollNewPatientButton_S = "Enroll a New Patient button";
	
	// Rajesh Singaraj -02/01/2022
	private final By noOfPatientInPatientsTable_OR = By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr");
	private final String noOfPatientInPatientsTable_S = "No of patient in patients table";
	private final By selectFirstPatient_OR = By
			.xpath("//table[@id='dtl_patient-list_table']/tbody/tr[1]/td[13]/mat-checkbox[1]");
	private final String selectFirstPatient_S = "First Patient selection";
	private final By moreActionsLnk_OR = By.xpath("//button[@id='btn_patient-list_menu-trigger']");
	private final String moreActionsLnk_S = "More Actions button";
	private final By clearOverdue_OR = By.xpath("//button[@id='btn_patient-list_clearOverdueStatus']");
	private final String clearOverdue_S = "Clear Overdue button";
	private final By patientListSearch_OR = By.xpath("//input[@id='txt_patient-list_search']");
	private final String patientListSearch_S = "Patient list search button";
	private final By clearedOverduePatient_OR = By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr");
	private final String clearedOverduePatient_S = "Cleared overdue patient";
	private final By pageNavigationLabel_OR = By.xpath("//*[@class='mat-paginator-range-label']");
	private final String pageNavigationLabel_S = "Cleared overdue patient";
	//02/16/2022
	private final By transmissionLink_OR = By.xpath("//table[@id='dtl_transmission-list_table']/tbody/tr[1]/td[3]/div");
	private final String transmissionLink_S = "Transmission Link";
	private final By transmissionDetailsLink_OR = By.xpath("//div[@id='lbl_transmission_summary_transmission_date']/text()");
	private final String transmissionDetailsLink_S = "Transmission Link";
	private final By fastSummaryPath_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_0_0']/div/div[2]");
	private final String fastSummaryPath_S = "Fast Summary Link";
	private final By episodeSummaryLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_0_1']/div/div[2]");
	private final String episodeSummaryLink_S = "Episode Summary Link";
	private final By diagnosticsSummaryLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_0_2']/div/div[2]");
	private final String diagnosticsSummaryLink_S = "Diagnostics Summary Link";
	private final By alertSummaryPath_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']/div/div[2]");
	private final String alertSummaryPath_S = "Alert Summary Link";
	private final By episodeEGMsLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_1']/div/div[2]");
	private final String episodeEGMsLink_S = "Episode and EGMs Summary Link";
	private final By extendedEpisodes_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_2']/div/div[2]");
	private final String extendedEpisodes_S = "Extended episodes Link";
	private final By extendedDiagnostics_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_2_0']/div/div[2]");
	private final String extendedDiagnostics_S = "extended Diagnostics Link";
	private final By corvueReport_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_2_2']/div/div[2]");
	private final String corvueReport_S = "corvue Report Link";
	private final By directTrendReport_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_2_3']/div/div[2]");
	private final String directTrendReport_S = "direct Trend Report Link";
	private final By TestResults_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_3_0']/div/div[2]");
	private final String TestResults_S = "Test Results Link";
	private final By parameters_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_4_0']/div/div[2]");
	private final String parameters_S = "direct Trend Report Link";
	private final By textSummary_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_6_0']/div/div[2]");
	private final String textSummary_S = "Text Summary Link";
	private final By viewMergedReport_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_6_1']/div/div[2]");
	private final String viewMergedReport_S = "direct Trend Report Link";
	private final By wrapUpOverview_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_6_1']/div/div[2]");
	private final String wrapUpOverview_S = "Wrap up overview Link";
	private final By stMonotoring_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_6_1']/div/div[2]");
	private final String stMonotoring_S = "ST Monitoring";
	private final By viewMergedReportCanBtn_OR = By.xpath("//button[@id='btn_popup-pdf_close2']");
	private final String viewMergedReportCanBtn_S = "view Merged Report Cancel Button";
	private final By textSummaryTitle_OR = By.xpath("//h3[@id='text_summary_report_title']");
	private final String textSummaryTitle_S = "text Sumamry Report title";
	private final By viewMergedReportTitle_OR = By.xpath("//h5[@id='title_popup-pdf_main_title']");
	private final String viewMergedReportTitle_S = "View Merged Report title";
	private final By dateTimeInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[1]");
	private final By zoneTypeInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[2]");
	private final By clMSInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[3]");
	private final By threapyInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[4]");
	private final By durationInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[5]");
	private final By EGMInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[6]");
	private final By alertInEpisodeAndEGM_OR = By.xpath("//table[@id='episode-egm-non-icm-grid']/thead/tr[1]/th[7]");
	private final By firstEpisodeDateAndTimeValue_OR = By.xpath("//tr[@id='mnu_episode-egm-non-icm__0']/td/a");
	private final String firstEpisodeDateAndTimeValue_S = "First row value of Episodes and EGMs";
	private final By scheduleCancelBtn_OR = By.xpath("//button[@mattooltip='cancel']");
	private final String scheduleCancelBtn_S = "Schedule Link Cancel Button";
	private final By scheduleLink_OR = By.xpath("//a[@id='btn_transmission-list_schedule']");
	private final String scheduleLink_S = "Schedule Link";
	private final By scheduleDialogBox_OR = By.xpath("//div[@class='header-title']");
	private final String scheduleDialogBox_S = "Schedule dialog box";
	private final By printCancelBtn_OR = By.xpath("//button[@id='btn_print-transmission_availableReportsCancel']");
	private final String printCancelBtn_S = "Print Transmission Cancel Button";
	private final By printLink_OR = By.xpath("//button[@id='btn_transmission-list_print']");
	private final String printLink_S = "Print Link";
	private final By printDialogBox_OR = By.xpath("//h6[@id='title_print-transmission_pt']");
	private final String printDialogBox_S = "Print dialog box";	
	
	// 02/04/2022
	private final By addOrRemoveCloumn_OR = By.xpath("//button[@id='btn_patient-list_addOrRemoveColumns']");
	private final String addOrRemoveCloumn_S = "Add or Remove column";
	private final By addOrRemoveModelWindow_OR = By.xpath("//h6[@id='btn_column_name_add_remove_column']");
	private final String addOrRemoveModelWindow_S = "Add or Remove column";
	private final By totalNoOfColumnsInModelWindow_OR = By.xpath("//div[@id='btn_column_name_visible_column']//following::div[1]/div/div");
	private final String totalNoOfColumnsInModelWindow_S = "total No Of Columns In Model Window";
	private final By nextTransmissionInModelWindow_OR = By.xpath("//div[@id='btn_column_name_visible_column']//following::div[1]/div/div[8]/mat-checkbox/label/div/input[1]");
	private final String nextTransmissionInModelWindow_S = "Next transmission In Model Window";
	private final By saveButtonInModelWindow_OR = By.xpath("//button[@id='btn_column_name_done']");
	private final String saveButtonInModelWindow_S = "Save button In Model Window_S";
	private final By cancelButtonInModelWindow_OR = By.xpath("//button[@id='btn_column_name_done']");
	private final String cancelButtonInModelWindow_S = "Cancel button In Model Window_S";
	private final By nextTransmissionColumnInPA001_OR = By
			.xpath("//th[@id='lbl_patient-list_th-nextTransmission']/div/button");
	private final String nextTransmissionColumnInPA001_S = "Next Transmission column in PA001";
	private final By patientStatusColumnInPA001_OR = By
			.xpath("//th[@id='lbl_patient-list_th-patientStatus']/div/button");
	private final String patientStatusColumnInPA001_S = "Patient status column in PA001";
	private final By pastTransmissionColumnInPA001_OR = By
			.xpath("//th[@id='lbl_patient-list_th-latestTransmission']/div/button");
	private final String pastTransmissionColumnInPA001_S = "past Transmission column in PA001";
	private final By lastTransmissionColumnInPA001_OR = By
			.xpath("//th[@id='lbl_patient-list_th-lastTransmitterCommunication']/div/button");
	private final String lastTransmissionColumnInPA001_S = "last Transmission column in PA001";
	private final By deviceImplantColumnInPA001_OR = By.xpath("//th[@id='lbl_patient-list_th-implantDate']/div/button");
	private final String deviceImplantColumnInPA001_S = "Device implant column in PA001";
	private final By signOutBtn_OR = By.xpath("//span[text()='Sign Out']");
	private final String signOutBtn_S = "Signout button";
	private final By patientStatusInModelWindow_OR = By.xpath(
			"//div[@id='btn_column_name_visible_column']//following::div[1]/div/div[1]/mat-checkbox/label/div/input[1]");
	private final String patientStatusInModelWindow_S = "Patient status In Model Window";
	private final By lastTransmissionInModelWindow_OR = By.xpath(
			"//div[@id='btn_column_name_visible_column']//following::div[1]/div/div[10]/mat-checkbox/label/div/input[1]");
	private final String lastTransmissionInModelWindow_S = "Last transmission In Model Window";
	private final By pastTransmissionInModelWindow_OR = By.xpath(
			"//div[@id='btn_column_name_visible_column']//following::div[1]/div/div[7]/mat-checkbox/label/div/input[1]");
	private final String pastTransmissionInModelWindow_S = "Past transmission In Model Window";
	private final By deviceImplantInModelWindow_OR = By.xpath(
			"//div[@id='btn_column_name_visible_column']//following::div[1]/div/div[4]/mat-checkbox/label/div/input[1]");
	private final String deviceImplantInModelWindow_S = "Device Implant In Model Window";
	private final By totalNumberOfColumns_OR = By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr[1]/td");
	private final String totalNumberOfColumns_S = "Total number of columns";
	private final By totalCoulmnsInPatientList_OR = By.xpath("//table[@id='dtl_patient-list_table']/thead/tr/th");
	private final String totalCoulmnsInPatientList_S = "Total number of columns In patient list";
	private final By downloadSpreadsheet_OR = By.xpath("//button[@id='btn_patient-list_downloadSpreadsheet']");
	private final String downloadSpreadsheet_S = "download spreadsheet";
	private final By printButton_OR = By.xpath("//button[@id='btn_patient-list_print']");
	private final String printButton_S = "Print button";
	private final By printPreviewButton_OR = By.xpath("//button[@id='btn_print-table_print']");
	private final String printPreviewButton_S = "Print button";
	private final By sortOption_OR = By.xpath("//th[@id='lbl_patient-list_th-patientName']/div/div/div[2]");
	private final String sortOption_S = "Sort option";
	private final By cancelButtonInPreview_OR = By.xpath("(//div[@id='more-settings-container']//following::button[7])[2]");
	private final String cancelButtonInPreview_S = "Print in Print preview";
	private final By searchBox_OR = By.xpath("//input[@id='txt_patient-list_search']");
	private final String searchbox_S = "Patient List Search Box";
	private final By patientName_OR = By.xpath("//*[@id='btn_patient-list_cell-row0']/span");
	private final String patientName_S = "Patient Name";
	private final By moreActionsBtn_OR = By.xpath("//button[@id='btn_patient-list_menu-trigger']");
	private final String moreActionsBtn_S="More Actions Button";
	private final By releasePatientLink_OR=By.xpath("//button[@id='btn_patient-list_releasePatient']");
	private final String releasePatientLink_S = "Release Patient Link";
	private final By patientListSize_OR=By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr/td/a");
	private final By reasonForReleaseDropDwn_OR = By.xpath("//mat-select[@id='mat-select-9']/div/div[2]");
	private final String reasonForReleaseDropDwn_S="Reason for Release Dropdown";
	private final By clinicListSize_OR = By.xpath("//table[@id='dtl_patient-list_clinicDataSource']/tbody/tr/td[1]");
	private final By releaseBtn_OR = By.xpath("//button[@id='btn_patient-list-release-patient_releasea']");
	private final String releaseBtn_S = "Release Button";
	private final By patientList_OR=By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr/td[1]");
	private final String patientList_S = "Patient List count";
	private final By addOrRemoveColumns_OR = By.xpath("//button[@id='btn_patient-list_addOrRemoveColumns']");
	private final String addOrRemoveColumns_S = "Add Or Remove Columns";
	
	//bhupendra
	private final By moreActionOptions_OR = By.xpath("//input[contains(@id,'chb_column_name_preference')]");
	private final String moreActionOptions_S = "More Action Options";
	
	private final By allTransmissions_OR = By.xpath("//input[contains(@id,'chb_column_name_preference')]");
	private final String allTransmissions_S = "All Transmission Column";


	private final By clinicCommentsHeader_OR = By.xpath("//th[@id='lbl_patient-list_th-latestComments']");
	private final String clinicCommentsHeader_S = "Latest Comments Column";
	
	private final By clinicAdministration_link_OR = By.xpath("//div[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[4]/a");
	private final String clinicAdministration_link_S = "ClinicAdministration Link";
	
	private final By patientList_link_OR = By.xpath("//div[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[2]/a");
	private final String patientList_link_S = "Patient List Link";

	

	//Gowshalya - Needs to be updated once the data is available
	private final By patientsTrsnfrdToClinicSize_OR = By.xpath("//*[@id='app-container']/app-patient-finder/div[1]/app-pending-enrollment-by-clinic/div[1]/table/tbody/tr/td");

	//Alok - 
		private final By patients_OR = By.xpath("//td[@id='lbl_patient-list_td-patientName1']/a");
		private final String patients_S= "Patient";
		private final By EpisodesandEGM_OR = By.xpath("//div[contains(text(), ' Episodes and EGMs ')]");
		private final String EpisodesandEGM_S= "Episodes and EGM";
		private final By patientsInAllTransmission_OR = By.xpath("//div[contains(text(), ' Episodes and EGMs ')]");
		private final String patientsInAllTransmission_S= " patients In AllTransmission ";
		private final By ShowTier1DrpDwn_OR = By.xpath("//mat-select[@id='dd_episode-egm-icm_RT_T1_Filter']");
		private final String ShowTier1DrpDwn_S= " Tier 1 Filter ";
		// Alok - End
	//shafiya 25/02/2022
	private final By reactivatePatientLink_OR=By.xpath("//button[@id='btn_patient-list_releasePatient']");
	private final String reactivatePatientLink_S = "Re-activate Patient Link ";
	//Ends here
	
	@Override
	public boolean verifyLandingPage() {
		Boolean patientListPageCheck = false;
		if (visibilityOfElementLocatedWithoutReport(enrollNewPatientButton_OR, enrollNewPatientButton_S)) {
			patientListPageCheck = true;
			invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
			extentReport.reportScreenShot("Patient List page is displayed");
		}
		return patientListPageCheck;
	}


//bhupendra
	public void validateDwnldSpreadSheetMoreActionOption() throws Exception {
		selectTierTwoFilterOption("All");
		clickMoreActionsButton();
		elementToBeClickable(downloadSpreadsheet_OR, downloadSpreadsheet_S);
		extentReport.reportScreenShot("Clicked on download sreadsheet option");	
		clickElement("DownloadSpreadsheet");		
	}

	//bhupendra
	public void validatePatientListFilterWithDifferentValues(String patientName) throws Exception {
		String [] tierOneFiletValus = {"My Active Patients","Active Clinic Patients","Inactive Patients"};
		clickOnElementUsingJs(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		List<WebElement> tier2list = driver.findElements(By.xpath(tier2FilterDrpdownOptions_OR.replace("[{0}]", "")));
		List<String> values = new ArrayList<String>();
		for(WebElement tire2FilterValue : tier2list) {
			if (tire2FilterValue.isDisplayed()) {
				values.add(tire2FilterValue.getText());
			}
		}
		elementToBeClickable(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		clickOnElementUsingJs(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		for(int i=0;i<tierOneFiletValus.length;i++) {	
			selectTierOneFilterOption(tierOneFiletValus[i]);
			for (int k = 0; k < values.size(); k++) {
				selectTierTwoFilterOption(values.get(k));
				for (int j = 0; j < 2; j++) {
					if (j == 0) {
						//driver.findElement(tier3FilterDrpdown_OR).clear();
						enterTier3FilterInputBx("");
					} else {
						enterTier3FilterInputBx(patientName);
					}
											navigateToClinicAdministrationPage();
											navigateToPatientListPage();
											
											assertions.assertEqualsWithReporting(true,verifyTier1FilterValue(tierOneFiletValus[i]), extentReport, "Tier one filter value "+tierOneFiletValus[i]+" is retained");
											assertions.assertEqualsWithReporting(true,verifyTier2FilterValue(values.get(k)), extentReport, "Tier two filter value "+tierOneFiletValus[i]+" is retained");
											if (j == 0) {
												assertions.assertEqualsWithReporting(true,verifyTier3Filter(""), extentReport, "Tier three filter value is retained");
											}else {
												assertions.assertEqualsWithReporting(true,verifyTier3Filter(patientName), extentReport, "Tier three filter value "+patientName+" is retained");
											}
				} 

			} 
		}
	}

	
	public boolean verifyTier3Filter(String searchText) {
		boolean flg= false;
		if(getText(tier3FilterDrpdown_OR, tier3FilterDrpdown_S).equals(searchText)) {
			flg= true;
		}
		return flg;
	}
	//bhupendra
	public  void navigateToClinicAdministrationPage() throws Exception
	{ 
		
		clickOnElementUsingJs(clinicAdministration_link_OR, clinicAdministration_link_S);
		loadingWithoutReport();
		//presenceOfElementLocatedWithReport(clinicAdministration_HomePage_OR,clinicAdministration_HomePage_S);
	}
	
	//bhupendra
	public void navigateToPatientListPage() {
		clickOnElementUsingJs(patientList_link_OR, patientList_link_S);

	}
	
	
	//bhupendra
	public void verifyLatestCommentsHeader() throws Exception {
		clickPatientListLink();
		//extentReport.reportScreenShot("Navigated to Patient List.");
		if(visibilityOfElementLocatedWithReport(clinicCommentsHeader_OR, clinicCommentsHeader_S)) {
			scrollToViewWebElementWithoutReport(driver.findElement(clinicCommentsHeader_OR), clinicCommentsHeader_S);
			extentReport.reportScreenShot("Latest Comment column header is disaplyed on pateint list page.");
		}
	}

	public void clickPatientListLink() throws InterruptedException
	{
		elementToBeClickable(patientList_link_OR, patientList_link_S);
		clickElement(patientList_link_OR, patientList_link_S);
		loadingWithoutReport();
	}



	//bhupendra
	public void removeColumn(String columnName) throws Exception {
		clickMoreActionsButton();
		clickElement("AddOrRemoveColumns");
		List<WebElement> options = driver.findElements(moreActionOptions_OR);
		columnName = columnName.toLowerCase();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch (columnName) {	
		case "patient status":
			scrollToViewlist(options.get(0));
			if(options.get(0).isSelected())
				js.executeScript("arguments[0].click();",options.get(0));
			break;
		case "Device":
			scrollToViewlist(options.get(1));
			if(options.get(1).isSelected())
				js.executeScript("arguments[0].click();",options.get(1));
			break;
		case "premature battery depletion":
			scrollToViewlist(options.get(2));
			if(options.get(2).isSelected())
				js.executeScript("arguments[0].click();",options.get(2));
			break;
		case "implant date":
			scrollToViewlist(options.get(3));
			if(options.get(3).isSelected())
				js.executeScript("arguments[0].click();",options.get(3));
			break;
		case "transmitter software version":
			scrollToViewlist(options.get(4));
			if(options.get(4).isSelected())
				js.executeScript("arguments[0].click();",options.get(4));
			break;
		case "all transmissions":
			scrollToViewlist(options.get(5));
			if(options.get(5).isSelected())
				js.executeScript("arguments[0].click();",options.get(5));
			break;
		case "latest transmission":
			scrollToViewlist(options.get(6));
			if(options.get(6).isSelected())
				js.executeScript("arguments[0].click();",options.get(6));
			break;
		case "":
			scrollToViewlist(options.get(7));
			if(options.get(7).isSelected())
				js.executeScript("arguments[0].click();",options.get(7));
			break;
		}
		extentReport.reportScreenShot(columnName+"Column is unselected.");
		scrollToViewWebElementWithoutReport(driver.findElement(customizeColumnDoneBtn_OR), customizeColumnDoneBtn_S);
		clickElement(customizeColumnDoneBtn_OR, customizeColumnDoneBtn_S);

	}
	
	//bhupendra
	public void addColumn(String columnName) throws Exception {
		clickMoreActionsButton();
		clickElement("AddOrRemoveColumns");
		List<WebElement> options = driver.findElements(moreActionOptions_OR);
		columnName = columnName.toLowerCase();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		switch (columnName) {	
		case "patient status":
			scrollToViewlist(options.get(0));
			if(!options.get(0).isSelected())
				js.executeScript("arguments[0].click();",options.get(0));
			break;
		case "Device":
			scrollToViewlist(options.get(1));
			if(!options.get(1).isSelected())
				js.executeScript("arguments[0].click();",options.get(1));
			break;
		case "premature battery depletion":
			scrollToViewlist(options.get(2));
			if(!options.get(2).isSelected())
				js.executeScript("arguments[0].click();",options.get(2));
			break;
		case "implant date":
			scrollToViewlist(options.get(3));
			if(!options.get(3).isSelected())
				js.executeScript("arguments[0].click();",options.get(3));
			break;
		case "transmitter software version":
			scrollToViewlist(options.get(4));
			if(!options.get(4).isSelected())
				js.executeScript("arguments[0].click();",options.get(4));
			break;
		case "all transmissions":
			scrollToViewlist(options.get(5));
			if(!options.get(5).isSelected())
				js.executeScript("arguments[0].click();",options.get(5));
			break;
		case "latest transmission":
			scrollToViewlist(options.get(6));
			if(!options.get(6).isSelected())
				js.executeScript("arguments[0].click();",options.get(6));
			break;
		case "":
			scrollToViewlist(options.get(7));
			if(!options.get(7).isSelected())
				js.executeScript("arguments[0].click();",options.get(7));
			break;
		}
		extentReport.reportScreenShot(columnName+"Column is unselected.");
		scrollToViewWebElementWithoutReport(driver.findElement(customizeColumnDoneBtn_OR), customizeColumnDoneBtn_S);
		clickElement(customizeColumnDoneBtn_OR, customizeColumnDoneBtn_S);
	}
	
	//bhupendra
	public String getLatestDownloadedFile(String path) {
		String directory = path;
		File ErrorFile = new File(directory);
		String Er_FileName = "";

		long LastModifiedFile = Long.MIN_VALUE;
		File choice = null;

		File[] files= ErrorFile.listFiles();

		for(File file : files) //this for loop returns NPE
		{
			if(file.lastModified() > LastModifiedFile)
			{
				choice = file;
				LastModifiedFile = file.lastModified();
				Er_FileName = file.getName();
			}
		}
		return Er_FileName;
	}
	
	//bhupendra
	public void verifyAllTransmissionColumnHyperlink() {
		List<WebElement> transmissionCol = driver.findElements(allTransmissions_OR);
	}
	
	//Vrushali -- Block start
		private final By patList_teleNum_ColHeading_OR=By.xpath("//table[@id='dtl_patient-list_table']//th[contains(text(), 'telephone')]");
		private final String patList_teleNum_ColHeading_S = "Patient List Column heading - Telephone Number";
		private final By columnCheckboxList_OR=By.xpath("//mat-checkbox[contains(@id, 'chb_column_name_preference')]");
		private final String columnCheckboxList_S = "List of checkboxes from Column preference popup";
		private final By customizeColumnDoneBtn_OR=By.xpath("//button[@id='btn_column_name_done']");
		private final String customizeColumnDoneBtn_S = "Add/Remove column popup Done button";
		private final By patListTableHeadings_OR=By.xpath("//th[contains(@id,  'lbl_patient-list_th')]");
		private final String patListTableHeadings_S = "Patient list table all headings";
		private final String patListTableHeadingsSort="//th[contains(@id,  'lbl_patient-list_th-{0}')]";
		private final String patListTableHeadingsSort_S = "Patient list table heading for sorting";
		private final By colSortOrderIcon_OR=By.xpath("//div[@class='mat-sort-header-indicator ng-tns-c163-112 ng-trigger ng-trigger-indicator']");
		private final String colSortOrderIcon_S = "Sort column icon";

		private final By fromDate_OR = By.xpath("//input[@id='patientListStartDate_DP']");
		private final String fromDate_S = "Tier three filter from date input";
		private final By toDate_OR = By.xpath("//input[@id='patientListToDate_DP']");
		private final String toDate_S = "Tier three filter to date input";

		public void enterTier3DateValues(String fromDateValue, String toDateValue) throws ParseException, InterruptedException {
			sendKeys(fromDate_OR, fromDateValue);
			sendKeys(toDate_OR, toDateValue);
		}
		
		//Verify Telephone number column is not displayed
		public boolean verifyTeleNumColumn() {
			boolean isTeleNumColumn = true;
			if(visibilityOfElementLocatedWithReport(patList_teleNum_ColHeading_OR, patList_teleNum_ColHeading_S)) {
				isTeleNumColumn = false;
			}
			return isTeleNumColumn;
		}
		
		public void sort(String colName) {
			clickElement(By.xpath(patListTableHeadingsSort.replace("{0}", colName)), patListTableHeadingsSort_S);
		}
		
		public String getSortOrder() {
			String order = "Descending";
			if(findElement(colSortOrderIcon_OR, colSortOrderIcon_S).getAttribute("style").contains("(0px)"));
			order = "Ascending";
			return order;
		}
		
		public void addAllColumns() throws Exception {
			clickMoreActionsButton();
			clickElement(addOrRemoveColumns_OR);
			List<WebElement> cbList = driver.findElements(columnCheckboxList_OR);
			for (int i = 0; i <= cbList.size(); i++) {
				cbList.get(i).click();
			}
			clickElement(customizeColumnDoneBtn_OR, customizeColumnDoneBtn_S);
		}
		
		public boolean verifyPatientListColumnsHeading(String text) throws Exception {
			boolean isColHeadingMatching = false;
			List<WebElement> rows = findElements(patListTableHeadings_OR);
			String alerts;
			for (int i = 1; i <= rows.size(); i++) {
				if (rows.get(i).getText().contains(text)) {
					isColHeadingMatching = true;
					extentReport.reportPass("Column heading is matching with the UI - " + text);
				} else {
					extentReport.reportFail("Column heading is not matching with the UI - " + text);
				}
			}
			return isColHeadingMatching;
		}
	//Vrushali -- block end
	
		//Poojitha
		private final By patientSummaryLinkFrmList_OR= By.xpath("//td[contains(@id,'lbl_patient-list_td-patientSummaryReport0')]/a");
		private final String patientSummaryLinkFrmList_S = "Patient Summary Hyperlink";
		//Ends here
		

	/*
	 * Author Salin Gambhir for test case WA_96_QuickLinks _02
	 */

	private final By dropdownT1FilterForActivePatient_OR = By.xpath(
			"//app-patient-list/div/div[1]/div[1]/mat-form-field[1]/div/div[1]/div[3]/mat-select/div/div[1]/span/span");
	private final String dropdownT1FilterForActivePatient_S = "Filter for Active Patient Search";
	private final By dropdownT2FilterForSearch_OR = By.xpath(
			"//app-patient-list/div/div[1]/div[1]/mat-form-field[2]/div/div[1]/div[3]/mat-select/div/div[1]/span/span");
	private final String dropdownT2FilterForSearch_S = "Filter for All kind of Patient Transmitters";
	private final By totalCountPatientFilter_OR = By
			.xpath("//div[@id='patientTable']/mat-paginator/div/div/div[2]/div");
	private final String totalCountPatientFilter_S = "Total count of patient based on filter";
	private final By searchIcon_OR = By
			.xpath("//div[@id=\"patient-list\"]/div[1]/div[1]/mat-form-field[3]/div/div[1]/div[4]/mat-icon");
	private final String searchIcon_S = "Search Icon button";

	private final By tier1FilterDrpdown_OR = By.xpath("//mat-select[@id='dd_patient-list_t1filterList']");
	private final String tier1FilterDrpdown_S = "Filter for patient list";

	private final By tier1FilterMyActivePatients_OR = By
			.xpath("(//div[@id='dd_patient-list_t1filterList-panel']/mat-option)[1]");
	private final String tier1FilterMyActivePatients_S = "My Active Patients";

	private final By tier1FilterActiveClinicPatients_OR = By
			.xpath("(//div[@id='dd_patient-list_t1filterList-panel']/mat-option)[2]");
	private final String tier1FilterActiveClinicPatients_S = "Active Clinic Patients";

	private final By tier1FilterInActivePatients_OR = By
			.xpath("(//div[@id='dd_patient-list_t1filterList-panel']/mat-option)[3]");
	private final String tier1FilterInActivePatients_S = "Inactive Patients";

	private final By tier2FilterDrpdown_OR = By.xpath("//mat-select[@id='dd_patient-list_t2filterList']");
	private final String tier2FilterDrpdown_S = "Type Of Patient Filter DropDown";

	private final String tier2FilterDrpdownOptions_OR = "(//div[@Id='dd_patient-list_t2filterList-panel']/mat-optgroup/mat-option)[{0}]";
	private final String tier2FilterDrpdownOptions_S = "Type Of Patient Filter Options";

	private final String tier2FilterOptions_OR = "//mat-option/span[contains(text(),'{value}')]";
	private final String tier2FilterOptions_S = "Options present in tier2 filter";

	private final By FilterTier2Options_OR = By.xpath("//div[@id='dd_patient-list_t2filterList-panel']/mat-optgroup/mat-option");
	private final String FilterTier2Options_S = "Options in tier2 filter";
	
	private final By patientStatus_OR = By.xpath("//table[@id='dtl_patient-list_table']//tr/td[2]");
	private final String patientStatus_S = "Patient Status";
	
	private final By allTransmission_OR = By.xpath("//td[contains(@id,'lbl_patient-list_td-allTransmission')]/a/span");
	private final String allTransmission_S = "All Transmission";
	
	private final By allTransmissionTab_OR = By.xpath("//mat-toolbar-row[@id='sub-header']/div/a[3]");
	private final String allTransmissionTab_S = "All Transmission";
	
	private final By mistCondition_OR = By.xpath("//span[@class='connectivityText']");
	private final String mistCondition_S = "MIST Conditions";
	
	private final By icmCondition_OR = By.xpath("//span[@class='connectivityText']");
	private final String icmCondition_S = "ICM Conditions";
	
	private final By implantDate_OR = By.xpath("(//a[@id='btn_patient-list_cell-row0'])[3]");
	private final String implantDate_S = "Implant Date";
	
	private final By deviceAndSerial_OR = By.xpath("//td[@id='lbl_patient-list_td-device0']");
	private final String deviceAndSerial_S = "Device and Serial Number";
	
	private final By deviceConnectivityColumnInPA001_OR = By.xpath("//button[@aria-label='Change sorting for compliance']");
	private final String deviceConnectivityColumnInPA001_S = "Connectivity";
	
	private final By deviceUnderAdvisoryColumnInPA001_OR = By.xpath("//button[@aria-label='Change sorting for advisoryIndicationCd']");
	private final String deviceUnderAdvisoryColumnInPA001_S = "Device Under Advisory";
	
	private final By LastTrasnmitterCommunicationColumnInPA001_OR = By.xpath("//button[@class='mat-sort-header-button mat-focus-indicator ng-tns-c163-69']");
	private final String LastTrasnmitterCommunicationColumnInPA001_S = "Last Transmitter Communication";
	
	private final By LastTrasnmitterCommunicationDatePA001_OR = By.xpath("//td[@id='lbl_patient-list_td-lastTransmitterCommunication0']/a");
	private final String LastTrasnmitterCommunicationDatePA001_S = "Last Transmitter Communication Date";
	
	private final By connectionChkBox_OR = By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_3\"]/label/span");
	private final String connectionChkBox_S = "Connection Check Box";
	
	private final By doneButton_OR = By.xpath("//button[@id='btn_column_name_done']");
	private final String doneButton_S = "Connection Check Box";
	
	private final By communicationType_OR = By.xpath("//td[@id='lbl_patient-list_td-connection0']");
	private final String communicationType_S = "Communication Type";
	
	private final By connectivityNote_OR = By.xpath("//button[@aria-label='Change sorting for connectivityNote']");
	private final String connectivityNote_S = "Connectivity Note";
	
	private final By connectivityNoteAdd_OR = By.xpath("//td[@id='lbl_patient-list_td-connectivity_Note0']/span");
	private final String connectivityNoteAdd_S = "Connectivity Note Add";
	
	private final By connection_OR = By.xpath("//button[@aria-label='Change sorting for communicationType']");
	private final String connection_S = "Connection"; 
	
	private final By connectivityNoteTxtArea_OR = By.xpath("//div[@class='mat-form-field-infix ng-tns-c31-96']/textarea");
	private final String connectivityNoteTxtArea_S = "Connectivity Note Text Area";
	
	private final By saveButton_OR = By.xpath("//button[@id='btn_connectivity-note_send']");
	private final String saveButton_S = "Save Button";
	
	private final By checkBox1_OR = By.xpath("//td[@id='lbl_patient-list_td-isSelected0']");
	private final String checkBox1_S = "Check Box 1";
	
	private final By checkBox2_OR = By.xpath("//td[@id='lbl_patient-list_td-isSelected1']");
	private final String checkBox2_S = "Check Box 2";
	
	private final By snoozeNotifications_OR = By.xpath("//button[@id='btn_patient-list_snoozeNotifications']");
	private final String snoozeNotifications_S = "Snooze Notifications";
	
	private final By snoozeOKButton_OR = By.xpath("//button[@id='btn_snooze-notifcations-popup_ok']");
	private final String snoozeOKButton_S = "Snooze pop-up Ok Button";
	
	public boolean verifyDropdownFilter(String expectedValue) {
		boolean checkDropdownFilter = false;
		String dropdownValue = "";
		switch (expectedValue) {

		case "Patients with Disconnected Transmitters":

			dropdownValue = getText(dropdownT2FilterForSearch_OR);
			if (dropdownValue.equalsIgnoreCase(expectedValue)) {
				checkDropdownFilter = true;
				extentReport.reportScreenShot("Patient with Disconnected Transmitters exist in dropdown");
			} else
				extentReport.reportFail("Patient with Disconnected Transmitters exist in dropdown");
			break;

		case "My Active Patients":

			dropdownValue = getText(dropdownT1FilterForActivePatient_OR);
			dropdownValue.trim();
			System.out.println(dropdownValue);
			if (dropdownValue.equalsIgnoreCase(expectedValue)) {
				checkDropdownFilter = true;
				extentReport.reportScreenShot("My Active patients exist in dropdown and is selected");
			} else
				extentReport.reportFail("My Active patients doesn't exist in dropdown and is not selected ");
			break;

		case "Active Clinic Patients":

			dropdownValue = getText(dropdownT1FilterForActivePatient_OR);
			if (dropdownValue.equalsIgnoreCase(expectedValue)) {
				checkDropdownFilter = true;
				extentReport.reportScreenShot("Active Clinic Patients exist in dropdown and is selected");
			} else
				extentReport.reportFail("Active Clinic Patients doesn't exist in dropdown and is not ");
			break;

			
		case "Release Requests from another clinic":
			
			dropdownValue = getText(dropdownT2FilterForSearch_OR);
			if (dropdownValue.equalsIgnoreCase(expectedValue)) {
					checkDropdownFilter = true;
					extentReport.reportScreenShot("Release Requests from another clinic  exist in dropdown and is selected");
				}
			else
				extentReport.reportFail("Release Requests from another clinic doesn't exist in dropdown and is not selected");
			break;
			
		}

		return checkDropdownFilter;

	}


	public void selectTierOneFilterOption(String option) {

		elementToBeClickable(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
		clickOnElementUsingJs(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
		if (option.equalsIgnoreCase("My Active Patients")) {
			elementToBeClickable(tier1FilterMyActivePatients_OR, tier1FilterMyActivePatients_S);
			clickOnElementUsingJs(tier1FilterMyActivePatients_OR, tier1FilterMyActivePatients_S);
		} else if (option.equalsIgnoreCase("Active Clinic Patients")) {
			elementToBeClickable(tier1FilterActiveClinicPatients_OR, tier1FilterActiveClinicPatients_S);
			clickElement(tier1FilterActiveClinicPatients_OR, tier1FilterActiveClinicPatients_S);
		} else if (option.equalsIgnoreCase("Inactive Patients")) {
			elementToBeClickable(tier1FilterInActivePatients_OR, tier1FilterInActivePatients_S);
			clickElement(tier1FilterInActivePatients_OR, tier1FilterInActivePatients_S);
		}
	}


	public void selectTierTwoFilterOption(String option) {

		elementToBeClickable(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		clickOnElementUsingJs(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		switch (option) {
		case "All":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "1")),
					tier2FilterDrpdownOptions_S);
			clickOnElementUsingJs(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "1")), tier2FilterDrpdownOptions_S);
			break;
		case "Cardiac Monitor":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "2")),
					tier2FilterDrpdownOptions_S);
			clickOnElementUsingJs(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "2")), tier2FilterDrpdownOptions_S);
			break;
		case "ICD/Pacemaker":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "3")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "3")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients with no future schedule":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "4")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "4")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients with overdue follow-up":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "5")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "5")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients with pending transmissions due today":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "6")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "6")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients released for transfer":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "7")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "7")), tier2FilterDrpdownOptions_S);
			break;
		case "Release Requests from another clinic":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "8")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "8")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients with disconnected transmitters":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "9")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "9")), tier2FilterDrpdownOptions_S);
			break;
			//Author: Madhan/Sai
		case "Cardiac Monitor under disconnected transmitters":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "10")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "10")), tier2FilterDrpdownOptions_S);
			break;
		case "ICD/Pacemaker under disconnected transmitters":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "11")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "11")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients with snoozed disconnected transmitter reporting":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "12")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "12")), tier2FilterDrpdownOptions_S);
			break;
		case "Patients ready for billing (Cardiac Monitors)":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "13")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "13")), tier2FilterDrpdownOptions_S);
			break;
		case "Patient Name":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "14")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "14")), tier2FilterDrpdownOptions_S);
			break;
		case "Patient ID":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "15")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "15")), tier2FilterDrpdownOptions_S);
			break;
		case "Patient Merlin.net™ Number":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "16")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "16")), tier2FilterDrpdownOptions_S);
			break;
		case "Physician Name/ID":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "17")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "17")), tier2FilterDrpdownOptions_S);
			break;
		case "Device Model Number":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "18")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "18")), tier2FilterDrpdownOptions_S);
			break;
		case "Device Serial Number":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "19")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "19")), tier2FilterDrpdownOptions_S);
			break;
		case "Device Type":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "20")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "20")), tier2FilterDrpdownOptions_S);
			break;
		case "Lead Model":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "21")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "21")), tier2FilterDrpdownOptions_S);
			break;
		case "Clinic Location":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "22")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "22")), tier2FilterDrpdownOptions_S);
			break;
		case "Latest Transmission Date Range":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "23")),
					tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "23")), tier2FilterDrpdownOptions_S);
			break;

		default:
			System.out.println("Not able to find the optionin dropdown");
		}

	}

	public void selectTier2FilterInDropdown() {
		visibilityOfElementLocatedWithoutReport(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		elementToBeClickable(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		clickOnElementUsingJs(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
	}

	public Boolean validateTier2FilterOptions(String option) {
		Boolean verifyElement = verifyElementWithReport(By.xpath(tier2FilterOptions_OR.replace("{value}", option)),
				tier2FilterOptions_S);
		return verifyElement;
	}
	
	public Boolean validateTier2Options(By element, String strElement,String option) {
		Boolean isPresent=false;
		List<WebElement> elementslist = findElementslist(element, strElement);
		for(int i=0;i<elementslist.size();i++) {
			
			if(elementslist.get(i).getText().contains(option)){
				isPresent=true;	
				System.out.println(elementslist.get(i).getText());
				break;
			}
		}
		if(isPresent==true) {
			extentReport.pass("Success - \"" + option + "\" is found  in " + strElement);
			
		} else {
			extentReport.reportInfo(option + "Is not found in " + strElement);
			
		}
		return isPresent;
		
	}
	

	public Boolean validateDrpdwnContainDevice(String deviceName) throws Exception {
		Boolean validateDrpdownNotParticularText = validateTier2Options(FilterTier2Options_OR, FilterTier2Options_S, deviceName);
		return validateDrpdownNotParticularText;
	}
	
		
	
	public int countPatientWithFilter() {
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		// count number of patients based on first and second dropdown filter. 

		int countPatient = 0;
		if (visibilityOfElementLocatedWithoutReport(totalCountPatientFilter_OR, totalCountPatientFilter_S)) {
			scrollToViewWithoutReport(totalCountPatientFilter_OR, totalCountPatientFilter_S);
			String totalCount = getText(totalCountPatientFilter_OR);
			String[] countTotal = totalCount.split("of");
			countPatient = Integer.valueOf(countTotal[1]);
		}
		return countPatient;

	}

	// Rajesh Singaraj -02/16/2022
		public void verifyTransDateAndTime() {
			String value=getText(transmissionLink_OR,transmissionLink_S);
			String[] transDateAndTime=value.split("\n");
			clickElement(transmissionLink_OR,transmissionLink_S);
			String transDetailsDateAndTime=getText(transmissionDetailsLink_OR,transmissionDetailsLink_S);
			if(transDetailsDateAndTime.contains(transDateAndTime[1])) {
				extentReport.pass("Transmission date and time in recent transmission and transmission details page are matched");
			}else {
				extentReport.fail("Transmission date and time in recent transmission and transmission details page are matched");
			}
		}
		public void invisibleOfSpinner() {
			invisibilityOfElementLocated(pageLoading_OR);
		}
		public void verifyLeftPanelReports(String leftPanel) {
						
			if(leftPanel.equals("Summary")) {
				String fastSummary=getText(fastSummaryPath_OR,fastSummaryPath_S);
				if(fastSummary.trim().contains("FastPath™ Summary")) {
					extentReport.pass("Fast summary details is available in transmission details page");
				}else {
					extentReport.fail("Fast summary details is NOT available in transmission details page");
				}
				String diagnosticsSummary=getText(diagnosticsSummaryLink_OR,diagnosticsSummaryLink_S);
				if(diagnosticsSummary.trim().contains("Diagnostics Summary")) {
					extentReport.pass("Diagnostics summary details is available in transmission details page");
				}else {
					extentReport.fail("Diagnostics summary details is NOT available in transmission details page");
				}
				String episodeSummary=getText(episodeSummaryLink_OR,episodeSummaryLink_S);
				if(episodeSummary.trim().contains("Episodes Summary")) {
					extentReport.pass("Episodes summary details is available in transmission details page");
				}else {
					extentReport.fail("Episodes summary details is NOT available in transmission details page");
				}

			}if(leftPanel.equals("AlertEpisodes")) {
				String alertSummary=getText(alertSummaryPath_OR,alertSummaryPath_S);
				if(alertSummary.trim().contains("Alert Summary")) {
					extentReport.pass("Alert summary details is available in transmission details page");
				}else {
					extentReport.fail("Alert summary details is NOT available in transmission details page");
				}
				String episodeSummary=getText(episodeEGMsLink_OR,episodeEGMsLink_S);
				if(episodeSummary.trim().contains("Episodes and EGMs")) {
					extentReport.pass("Episodes summary details is available in transmission details page");
				}else {
					extentReport.fail("Episodes summary details is NOT available in transmission details page");
				}
				String extendedEpisodes=getText(extendedEpisodes_OR,extendedEpisodes_S);
				if(extendedEpisodes.trim().contains("Extended Episodes")) {
					extentReport.pass("Extended Episodes details is available in transmission details page");
				}else {
					extentReport.fail("Extended Episodes details is NOT available in transmission details page");
				}
			}if(leftPanel.equals("Diagnostics")) {
				String extendedDiagnostics=getText(extendedDiagnostics_OR,extendedDiagnostics_S);
				if(extendedDiagnostics.trim().contains("Extended Diagnostics")) {
					extentReport.pass("Extended Diagnostics details is available in transmission details page");
				}else {
					extentReport.fail("Extended Diagnostics details is NOT available in transmission details page");
				}
				String wrapup=getText(stMonotoring_OR,stMonotoring_S);
				if(wrapup.trim().contains("ST Monitoring")) {
					extentReport.pass("STMonitoring details is available in transmission details page");
				}else {
					extentReport.fail("STMonitoring details is NOT available in transmission details page");
				}	
				String corvueReport=getText(corvueReport_OR,corvueReport_S);
				if(corvueReport.trim().contains(" Corvue™ Report ")) {
					extentReport.pass(" Corvue™ Report details is available in transmission details page");
				}else {
					extentReport.fail(" Corvue™ Report details is NOT available in transmission details page");
				}
				String directTrendReport=getText(directTrendReport_OR,directTrendReport_S);
				if(directTrendReport.trim().contains("DirectTrend™ Report")) {
					extentReport.pass("DirectTrend™ Report details is available in transmission details page");
				}else {
					extentReport.fail("DirectTrend™ Report details is NOT available in transmission details page");
				}
			}if(leftPanel.equals("TestResults")) {
				String testResults=getText(TestResults_OR,TestResults_S);
				if(testResults.trim().contains("Test Results")) {
					extentReport.pass("Test Results details is available in transmission details page");
				}else {
					extentReport.fail("Test Results details is NOT available in transmission details page");
				}
			}if(leftPanel.equals("Parameters")) {
				String testResults=getText(parameters_OR,parameters_S);
				if(testResults.trim().contains("Parameters")) {
					extentReport.pass("parameters details is available in transmission details page");
				}else {
					extentReport.fail("parameters details is NOT available in transmission details page");
				}
			}if(leftPanel.equals("OtherReports")) {
				String textSummary=getText(textSummary_OR,textSummary_S);
				if(textSummary.trim().contains("Text Summary")) {
					extentReport.pass("Text Summary details is available in transmission details page");
				}else {
					extentReport.fail("Text Summary details is NOT available in transmission details page");
				}
				String viewMergedReport=getText(viewMergedReport_OR,viewMergedReport_S);
				if(viewMergedReport.trim().contains("View Merged Report")) {
					extentReport.pass("View Merged Report details is available in transmission details page");
				}else {
					extentReport.fail("View Merged Report details is NOT available in transmission details page");
				}
			}if(leftPanel.equals("Wrapup")) {
				String wrapup=getText(wrapUpOverview_OR,wrapUpOverview_S);
				if(wrapup.trim().contains("Wrap-Up™ OverView")) {
					extentReport.pass("Wrap-Up™ OverView details is available in transmission details page");
				}else {
					extentReport.fail("Wrap-Up™ OverView details is NOT available in transmission details page");
				}				
			}else {
				//Do Nothing
			}
			
		}
		
	//02/01/2022
	public void RemoveEachColumnAndVerifyInPatientList(String ColumnInModelWindow, String ColumnInPatientList)
			throws Exception {

		clickElement("MoreAction");
		clickElement("AddOrRemoveColumns");
		clickElement("AddOrRemoveModelWindow");

		SelectCheckBoxForAllColumns();
		clickElement(ColumnInModelWindow);
		clickElement("ModelWindowSaveButton");
		clickElement(ColumnInPatientList);

		clickElement("SignOut");
		minimizeBrowser();		
		extentReport.info("repeats the steps 200 to 600");

	}

	public void copyingValueToClipboard(String copyingValue) {
		String myString = copyingValue;
		StringSelection stringSelection = new StringSelection(myString);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
	}

	public void keyboardActions(String type) {
		Actions act = new Actions(driver);
		switch (type) {
		case "Paste":
			act.sendKeys(Keys.CONTROL).sendKeys("v").build().perform();
			break;
		case "SelectAll":
			act.sendKeys(Keys.CONTROL).sendKeys("a").build().perform();
			break;
		case "Copy":
			act.sendKeys(Keys.CONTROL).sendKeys("c").build().perform();
			break;
		case "Move":
			act.sendKeys(Keys.CONTROL).sendKeys("x").build().perform();
			break;
		case "Escape":
			act.sendKeys(Keys.ESCAPE).build().perform();
			break;
		case "Enter":
			act.sendKeys(Keys.ENTER).build().perform();
			break;
		}

	}
	
	public ArrayList<ArrayList<String>> storeElementsFromUI(String type) {
		ArrayList<ArrayList<String>> arList = new ArrayList<ArrayList<String>>();	
		
		if(type.equalsIgnoreCase("PatientTable")) {
			//for header
			for(int i=1;i <= 1; i++) {
				int headerElementSize = getSizeOfElements(By.xpath("//table[@id='dtl_patient-list_table']/thead/tr[1]/th"));
				arList.add(new ArrayList<String>());
				
				for (int j = 1; j < headerElementSize; j++) {
					if(i==1) {
						if(j==3 || j==4) 
						{										
						String ColumnValue = getText(By.xpath("//table[@id='dtl_patient-list_table']/thead/tr[1]/th["+j+"]/div/button"));
						String val=ColumnValue.replace("help_outline", "");
						String val1=val.replace("cancel", "");	
						String val2=val1.replace("create", "");	
						String val3=val2.replace(" ", "");	
						arList.get(i-1).add(j-1, val3.trim());
						}else {
							String ColumnValue = getText(By.xpath("//table[@id='dtl_patient-list_table']/thead/tr[1]/th["+j+"]/div/button"));
							String val=ColumnValue.replace("help_outline", "");
							String val1=val.replace("cancel", "");	
							String val2=val1.replace("create", "");	
							String val3=val2.replace(" ", "");
							arList.get(i-1).add(j-1, val3.trim());
					}
				}
					
				}
			}
			//for row values
			for(int i=2;i <= 2; i++) {
				int headerElementSize = getSizeOfElements(By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr[1]/td"));
				arList.add(new ArrayList<String>());
				
				for (int j = 1; j < headerElementSize; j++) {
					
					String ColumnValue = getText(By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr[1]/td["+j+"]"));
					String val=ColumnValue.replace(" ", "");
					String val1=val.replace("--", "");
					String val2=val1.replace("\n", "");
					String val3=val2.replace("\n", "");
					String val4=val3.replace("cancel", "");	
					String val5=val4.replace("create", "");	
					arList.get(i-1).add(j-1, val5.trim());				
				}
			}
			

		}if(type.equalsIgnoreCase("PrintPreview")) {
			//for header
			for(int i=1;i <= 1; i++) {
				int headerElementSize = getSizeOfElements(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/thead/tr[1]/th"));
				arList.add(new ArrayList<String>());
				
				for (int j = 1; j <= headerElementSize; j++) {
					if(i==1) {
						if(j==3 || j==4) 
						{										
						String ColumnValue = getText(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/thead/tr[1]/th["+j+"]/div/button"));
						String val=ColumnValue.replace("help_outline", "");
						String val1=val.replace("cancel", "");	
						String val2=val1.replace("create", "");	
						String val3=val2.replace(" ", "");	
						arList.get(i-1).add(j-1, val3.trim());
						}else {
							String ColumnValue = getText(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/thead/tr[1]/th["+j+"]/div/button"));
							String val=ColumnValue.replace("help_outline", "");
							String val1=val.replace("cancel", "");	
							String val2=val1.replace("create", "");	
							String val3=val2.replace(" ", "");
							arList.get(i-1).add(j-1, val3.trim());
					}
				}
					
				}
			}
			//for row values
			for(int i=2;i <= 2; i++) {
				int headerElementSize = getSizeOfElements(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/tbody/tr[1]/td"));
				arList.add(new ArrayList<String>());
				
				for (int j = 1; j <= headerElementSize; j++) {
					
					String ColumnValue = getText(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/tbody/tr[1]/td["+j+"]"));	
					String val=ColumnValue.replace(" ", "");
					String val1=val.replace("--", "");
					String val2=val1.replace("\n", "");
					String val3=val2.replace("\n", "");
					String val4=val3.replace("cancel", "");	
					String val5=val4.replace("create", "");	
					arList.get(i-1).add(j-1, val5.trim());
				}
			}
			
			
		}else {
			//Do nothing
		}
		return arList;
			}


	public void csvReader(String path, ArrayList<ArrayList<String>> columnValue) throws FileNotFoundException {
		int row= 0;
    	int column= 0;
	    try {	    	
	    	
	    	CSVReader reader  = new CSVReader(new FileReader(path));  
	    	String [] nextLine; 
	    	
	    	while ((nextLine = reader.readNext()) != null)  
	    	{  
	    		if(row==2) {
	    			break;
	    		}
		    	for(String token : nextLine)  
		    	{  	
		    		int size=nextLine.length;			
		    		
					    String val=token.replace(" ", "");
						String val1=val.replace("--", "");
						String val2=val1.replace("\n", "");
						String val3=val2.replace("\n", "");
						String val4=val3.replace("KeyEpisodesenabled", "");
						String val5=val4.replace("Â", "");
						String tokenValue=val5.replace("ï»¿", "");	
		    		if(columnValue.get(row).get(column).trim().equals(tokenValue.trim())) {
		    			extentReport.info("Spreadsheet and patient table values are matched");
		    			//System.out.print(tokenValue+"="+columnValue.get(row).get(column).trim()+"-Both inputs are matched"+"\r\n");
		    		}else {
		    			extentReport.fail("Spreadsheet and patient table values are NOT matched");
		    			//System.out.print(tokenValue+"="+columnValue.get(row).get(column).trim()+"-Both inputs are not matched"+"\n");
		    		}
		    		column++;
		    		if(column==size-1) {
		    			column=0;
		    			break;
		    		}		    				    
		    	}
		    	row++;
	    				  }
	        }catch(

	Exception ioe)
	{
		ioe.printStackTrace();
	}
	}

	public ArrayList<String> csvReader1(String path) throws FileNotFoundException {
		ArrayList<String> arList = null;
	    try {	    	
	    	
	    	CSVReader reader  = new CSVReader(new FileReader(path));  
	    	String [] nextLine = null; 
	    	int count= 0;
	    	
	    	while ((nextLine = reader.readNext()) != null)  
	    	{  int size=nextLine.length;
	    		if(count==size+size+2) {
		    		break;
		    	}
	    		arList = new ArrayList<String>();
		    	for(String token : nextLine)  
		    	{  			    
		    		String val=token.replace(" ", "");
					String val1=val.replace("--", "");
					String val2=val1.replace("\n", "");
					String val3=val2.replace("\n", "");
					String val4=val3.replace("KeyEpisodesenabled", "");					
		    		arList.add(val4);		    		
		    		count++;
		    		if(count==size+size+2) {
			    		break;
			    	}
		    		}
		    	
	    	
	    	}
	        }catch(

	Exception ioe)
	{
		ioe.printStackTrace();
	}
		return arList;
	    
	}	
	public void compareSpreadsheetAndUIValues(String path) throws FileNotFoundException {
		ArrayList<ArrayList<String>> value3=storeElementsFromUI("PatientTable");
		csvReader(path, value3);
		//ArrayList<String>value2=csvReader(path, value3);
		/*
		 * List<String> val=value3.get(1).subList(0, 12); value2.containsAll(val);
		 * for(int i=0;i<12;i++) { if(value2.get(i).equalsIgnoreCase(val.get(i))) {
		 * System.out.println(value2.get(i).toString()); }else {
		 * 
		 * } }
		 */
	}

	public void verifySelectionBoxesImagesLinks(String path, String type) throws FileNotFoundException {
		CSVReader reader  = new CSVReader(new FileReader(path));  
    	String [] nextLine;
    	int row=0;
    	int column=0;
		try {	    		    	
	    	if(type.equalsIgnoreCase("PatientTable")) {
	    		while ((nextLine = reader.readNext()) != null)  
		    	{  
	    			if(row==2) {
		    			break;
		    		}
			    	for(String token : nextLine)  
			    	{  	
			    		int size=nextLine.length;
			    		if(token.trim().contains("href")||token.trim().contains("input")||token.trim().contains("mat-icon")) {
			    			extentReport.fail("Verified no Selection boxes, Images and Hyperlinks are downloaded to the spreadsheet");
			    		}	else {
			    			extentReport.pass("Verified that Selection boxes, Images and Hyperlinks are NOT downloaded to the spreadsheet");
			    		}
			    		column++;
			    		if(column==size-1) {
			    			column=0;
			    			break;
			    		}
			    	}
		    		row++;
		    	
		    	 }		        
	    		
	    	}if(type.equalsIgnoreCase("PrintPreview")) {
	    		
	    		for(int i=2;i <= 2; i++) {
					int headerElementSize = getSizeOfElements(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/tbody/tr[1]/td"));					
					
					for (int j = 1; j <= headerElementSize; j++) {
						
						String ColumnValue = getText(By.xpath("(//table[@id='dtl_patient-list_table'])[2]/tbody/tr[1]/td["+j+"]"));	
						if(ColumnValue.contains("href")) {	
							extentReport.fail("Verified Hyperlinks are existing in print preview");
						}else {
							extentReport.pass("Verified no Hyperlinks are NOT existing in print preview");
						}
						if(ColumnValue.contains("mat-icon")) {
							extentReport.fail("Verified Selection boxes are existing in print preview ");
						}else {
							extentReport.pass("Verified no Selection boxes are NOT existing in print preview ");
						}
					}
				}
	    		}else {
	    		
	    	//Do nothing
	    	}
	    		
		}catch(Exception e) {
		e.printStackTrace();
		}
	}
	
	public void loginAndNavigateToPatientListpage(Login login, String tier2DropDownValue) throws Exception {
		/*
		 * loginPage.login(login); clinicianHomeTopNavPage.navigateToPatientListPage();
		 * assertions.assertEqualsWithReporting(true, verifyLandingPage(), extentReport,
		 * "PatientListPage is displayed");
		 * selectTireOneFilterOption("Active Clinic Patients");
		 * selectTier2FilterInDropdown();
		 * selectTireOTwoFilterOption(tier2DropDownValue);
		 */
		
	}

	public void validationOfPrintPreviewWithPatientTableValues(String type) throws Exception {
		String path=System.getProperty("user.dir")+"\\Downloads\\Merlin.net™ PCN.csv";
		switch(type) {
		case "RemoveOneOrMoreColumn":			
			clickElement("MoreAction");
			clickElement("AddOrRemoveColumns");
			clickElement("NextTransmission");
			clickElement("ModelWindowSaveButton");
			waitForLoading();
			ArrayList<ArrayList<String>> value21=storeElementsFromUI("PatientTable");
			clickElement("MoreAction");
			clickElement("PrintButton");			
			clickElement("PrintPreviewButton");
			waitForLoading();			
			ArrayList<ArrayList<String>> value22=storeElementsFromUI("PrintPreview");
			value21.containsAll(value22);
			verifySelectionBoxesImagesLinks(path,"PrintPreview");		
			clickElement("PrintButtonInPreview");
			break;
			
		case "FilterOption":
			loginAndNavigateToPatientListpage(login,"Clinic Location");		
			ArrayList<ArrayList<String>> value211=storeElementsFromUI("PatientTable");
			clickElement("MoreAction");
			clickElement("PrintButton");			
			clickElement("PrintPreviewButton");
								
			ArrayList<ArrayList<String>> value221=storeElementsFromUI("PrintPreview");
			value211.containsAll(value221);
			verifySelectionBoxesImagesLinks(path,"PrintPreview");		
			clickElement("PrintButtonInPreview");
			break;
		case "ColumnSearch":			
			loginAndNavigateToPatientListpage(login,"Patients with overdue follow-up");				
			ArrayList<ArrayList<String>> value2111=storeElementsFromUI("PatientTable");
			clickElement("MoreAction");
			clickElement("PrintButton");			
			clickElement("PrintPreviewButton");
								
			ArrayList<ArrayList<String>> value2211=storeElementsFromUI("PrintPreview");
			value2111.containsAll(value2211);
			verifySelectionBoxesImagesLinks(path,"PrintPreview");		
			clickElement("PrintButtonInPreview");
			break;
		case "ListSearch":
			loginAndNavigateToPatientListpage(login,"All");	
			sendKeys(patientListSearch_OR, patientListSearch_S, "xtest");
			ArrayList<ArrayList<String>> value3=storeElementsFromUI("PatientTable");
			clickElement("MoreAction");
			clickElement("PrintButton");			
			clickElement("PrintPreviewButton");
								
			ArrayList<ArrayList<String>> value4=storeElementsFromUI("PrintPreview");
			value3.containsAll(value4);
			verifySelectionBoxesImagesLinks(path,"PrintPreview");		
			clickElement("PrintButtonInPreview");
			break;
		case "SortFunctionality":
			loginAndNavigateToPatientListpage(login,"All");	
			clickElement(moreActionsLnk_OR, moreActionsLnk_S);
			clickElement(addOrRemoveCloumn_OR, addOrRemoveCloumn_S);
			clickElement(nextTransmissionInModelWindow_OR, nextTransmissionInModelWindow_S);
			clickElement(saveButtonInModelWindow_OR, saveButtonInModelWindow_S);			

			ArrayList<ArrayList<String>> value5=storeElementsFromUI("PatientTable");
			clickElement("MoreAction");
			clickElement("PrintButton");			
			clickElement("PrintPreviewButton");
								
			ArrayList<ArrayList<String>> value6=storeElementsFromUI("PrintPreview");
			value5.containsAll(value6);
			verifySelectionBoxesImagesLinks(path,"PrintPreview");		
			clickElement("PrintButtonInPreview");
			break;
		}
		
	}

	public void validationOfSpreadsheetWithPatientTableValues(String type) throws Exception {
		String path=System.getProperty("user.dir")+"\\Downloads\\Merlin.net™ PCN.csv";

		switch(type) {
		case "RemoveOneOrMoreColumn":
			selectTierTwoFilterOption("All");
			invisibleOfSpinner();
			verifyTotalColumnsInPatientList();
			clickElement("MoreAction");
			clickElement("AddOrRemoveColumns");
			clickElement("NextTransmission");
			clickElement("ModelWindowSaveButton");
			waitForLoading();
			clickElement("MoreAction");
			fileDeletion(path);
			waitForLoading();
			clickElement("DownloadSpreadsheet");
			waitForLoading();waitForLoading();
			compareSpreadsheetAndUIValues(path);
			verifySelectionBoxesImagesLinks(path,"PatientTable");
			clickElement("SignOut");
			waitForLoading();
			break;
			
		case "FilterOption":
			selectTierTwoFilterOption("Clinic Location");
			waitForLoading();
			clickElement("MoreAction");
			fileDeletion(path);
			waitForLoading();
			clickElement("DownloadSpreadsheet");
			waitForLoading();waitForLoading();
			compareSpreadsheetAndUIValues(path);
			verifySelectionBoxesImagesLinks(path,"PatientTable");
			clickElement("SignOut");
			waitForLoading();
			break;
		case "ColumnSearch":			
			selectTierTwoFilterOption("Patients with overdue follow-up");	
			waitForLoading();
			clickElement("MoreAction");
			fileDeletion(path);
			waitForLoading();
			clickElement("DownloadSpreadsheet");
			waitForLoading();waitForLoading();
			compareSpreadsheetAndUIValues(path);
			verifySelectionBoxesImagesLinks(path,"PatientTable");
			clickElement("SignOut");
			waitForLoading();
			break;
		case "ListSearch":
			selectTierTwoFilterOption("All");
			waitForLoading();
			sendKeys(patientListSearch_OR, patientListSearch_S, "xtest");
			clickElement("MoreAction");
			fileDeletion(path);
			clickElement("DownloadSpreadsheet");
			waitForLoading();waitForLoading();
			compareSpreadsheetAndUIValues(path);
			verifySelectionBoxesImagesLinks(path,"PatientTable");
			clickElement("SignOut");
			waitForLoading();
			break;
		case "SortFunctionality":
			selectTierTwoFilterOption("All");
			waitForLoading();
			clickElement(sortOption_OR,sortOption_S);
			waitForLoading();
			clickElement("MoreAction");
			fileDeletion(path);
			clickElement("DownloadSpreadsheet");
			waitForLoading();waitForLoading();
			compareSpreadsheetAndUIValues(path);
			verifySelectionBoxesImagesLinks(path,"PatientTable");
			clickElement("SignOut");
			waitForLoading();
			break;		
			}
		
	}
	public ArrayList<String> storeTheValueInArrayList() {
		ArrayList<String> list = new ArrayList<String>();		
		int firstRowElementSize = getSizeOfElements(totalNumberOfColumns_OR);
		for (int i = 1; i <= firstRowElementSize; i++) {
			String value = "//table[@id='dtl_patient-list_table']/tbody/tr[1]/td[" + i + "]";
			String ColumnValue = getText(By.xpath(value));
			list.add(ColumnValue);
		}
		return list;
	}
	
	public void fileDeletion(String path) {
		File f= new File(path);           //file to be delete  
		if(f.delete())                      //returns Boolean value  
		{  
			extentReport.pass(f.getName() + " deleted");		 
		}  
		else  
		{  
			extentReport.fail(f.getName() + " not deleted");
		}  
	}

	public void verifyPresenceOfPatientDetails(By element, String strElement, String type, String patientName) {
		int totalNoOfPatients = getSizeOfElements(element, strElement);
		if (type.equals("PatientList")) {
			if (totalNoOfPatients > 0) {
				extentReport.pass(strElement + " is displayed");
				extentReport.reportScreenShot(strElement + " is displayed in the list - " + patientName);
			} else {
				extentReport.fail(strElement + " is not displayed");
				extentReport.reportScreenShot(strElement + " is not displayed in the list - " + patientName);
			}

		} else if (type.equals("OverdueList")) {
			int totalNoOfOverduePatients = getSizeOfElements(clearedOverduePatient_OR, clearedOverduePatient_S);
			if (totalNoOfOverduePatients > 0) {
				extentReport.fail(patientName + " - Patient name is displayed even after cleared the overdue.");
				extentReport
						.reportScreenShot(patientName + " - Patient name is displayed even after cleared the overdue.");
			} else {
				extentReport.pass(patientName + " - Patient name is not displayed even after cleared the overdue.");
				extentReport.reportScreenShot(
						patientName + " - Patient name is not displayed even after cleared the overdue.");
			}

		} else {
			// Do nothing

		}
	}

	public void verifyPresenceOfPatient(String type, Customer customer) throws SQLException, InterruptedException {
		switch (type) {
		case "NoOfPatientsInOverdueList":
			verifyTheOverduePatientsInUIWithDB();
			extentReport.reportScreenShot(
					"Verified that patients which have not send transmissions on the scheduled date are displayed.");
			break;
		case "PatientPresenceInPatientsList":
			verifyPresenceOfPatientDetails(clearedOverduePatient_OR, clearedOverduePatient_S, "PatientList",
					customer.getPatientNames());
			// updatePatientToOverdueOrFutureStatus(customer.getCustomerApplicationID(),customer.getFollowupDateID(),false);
			extentReport.reportScreenShot(
					"Verified that the patient is displayed in ‘Patients with overdue follow-up’ filter.");
			break;
		case "verifyOverduePatientNotPresent":
			verifyPresenceOfPatientDetails(clearedOverduePatient_OR, clearedOverduePatient_S, "OverdueList",
					customer.getPatientNames());
			extentReport.reportScreenShot(
					"Verified that the patient is not displayed in ‘Patients with overdue follow-up’ filter.");
			break;
		}
	}

	public void keyboardActions(Keys key) {

		Actions act = new Actions(driver);
		act.sendKeys(key).build().perform();
	}

	public void verifyTheOverduePatientsInUIWithDB() throws SQLException, InterruptedException {
		dataBase.getConnection();
		String TotalRowCountLabelInUI = getText(pageNavigationLabel_OR, pageNavigationLabel_S);
		String[] TotalRowCount = TotalRowCountLabelInUI.split("of");
		ResultSet overDuePatients = dataBase.executeQuery("select count(*) from patients.v_patient_list\r\n"
				+ "where application_cd = 946 AND customer_id = 145382\r\n"
				+ "and patient_status IN ('A', 'I', 'R')\r\n" + "AND v_patient_list.customer_appl_patient_id IN\r\n"
				+ "(SELECT customer_appl_patient_id\r\n" + "FROM patients.followup_date fd\r\n"
				+ "WHERE fd.customer_appl_patient_id =\r\n" + "v_patient_list.customer_appl_patient_id\r\n"
				+ "AND fd.followup_status_cd = 204)");
		while (overDuePatients.next()) {
			int NoOfOverDuePatients = overDuePatients.getInt("count");
			int TotalRowCountValue = Integer.parseInt(TotalRowCount[1].trim());
			if (TotalRowCountValue == NoOfOverDuePatients) {
				extentReport.pass("Total Number of Overdue Patients data matching with UI and DB");
			} else {
				extentReport.fail("Total Number of Overdue Patients data not matching with UI and DB");
			}
		}
	}
	/*
	 * public void updatePatientToOverdueOrFutureStatus(String CustomerAppPatID,
	 * String FollowUpID, Boolean isScheduledRequired) throws SQLException,
	 * InterruptedException { dataBase.getConnection(); try{ dataBase.
	 * executeNonQuery("update patients.followup_date set followup_status_cd = 204 where "
	 * + "customer_appl_patient_id = "+CustomerAppPatID+" and followup_date_id = "
	 * +FollowUpID); if(isScheduledRequired) { dataBase.
	 * executeNonQuery("update patients.followup_date set followup_status_cd = 200 where "
	 * + "customer_appl_patient_id = "+CustomerAppPatID+" and followup_date_id = "
	 * +FollowUpID); } }catch(Exception e) { System.out.println(e.toString()); }
	 * 
	 * 
	 * }
	 */

	public void clickElement(String type) throws InterruptedException {
		switch (type) {
		
		case "CancelButtonInPreview":
			clickOnElementUsingJs(cancelButtonInPreview_OR, cancelButtonInPreview_S);
			break;
		case "PrintButtonInPreview":
			clickOnElementUsingJs(printPreviewButton_OR, printPreviewButton_S);
			break;
		case "PrintPreviewButton":
			verifyElement(printPreviewButton_OR);
			break;
		case "DownloadSpreadsheet":
			clickOnElementUsingJs(downloadSpreadsheet_OR, downloadSpreadsheet_S);
			break;
		case "PrintButton":
			clickOnElementUsingJs(printButton_OR, printButton_S);
			break;
		case "SearchedPatient":
			clickElement(selectFirstPatient_OR, selectFirstPatient_S);
			break;
		case "MoreAction":
			clickOnElementUsingJs(moreActionsLnk_OR, moreActionsLnk_S);
			extentReport.reportScreenShot("Verified that the More Actions drop down has Clear Overdue Status option.");
			break;
		case "AddOrRemoveColumns":
			clickOnElementUsingJs(addOrRemoveCloumn_OR, addOrRemoveCloumn_S);
			break;
		case "AddOrRemoveModelWindow":
			verifyElement(addOrRemoveModelWindow_OR);
			break;
		case "nextTransmissionColumnInPA001":
			isElementNotPresent(nextTransmissionColumnInPA001_OR);
			break;
		case "patientStatusColumnInPA001":
			isElementNotPresent(patientStatusColumnInPA001_OR);
			break;
		case "lastTransmissionColumnInPA001":
			isElementNotPresent(lastTransmissionColumnInPA001_OR);
			break;
		case "pastTransmissionColumnInPA001":
			isElementNotPresent(pastTransmissionColumnInPA001_OR);
			break;
		case "deviceImplantColumnInPA001":
			isElementNotPresent(deviceImplantColumnInPA001_OR);
			break;
		case "NextTransmission":
			scrollToViewWithoutReport(deviceImplantInModelWindow_OR, deviceImplantInModelWindow_S);
			clickOnElementUsingJs(nextTransmissionInModelWindow_OR, nextTransmissionInModelWindow_S);
			break;
		case "PatientStatus":
			scrollToViewWithoutReport(deviceImplantInModelWindow_OR, deviceImplantInModelWindow_S);
			clickOnElementUsingJs(patientStatusInModelWindow_OR, patientStatusInModelWindow_S);
			break;
		case "LastTransmission":
			scrollToViewWithoutReport(deviceImplantInModelWindow_OR, deviceImplantInModelWindow_S);
			clickOnElementUsingJs(lastTransmissionInModelWindow_OR, lastTransmissionInModelWindow_S);
			break;
		case "PastTransmission":
			scrollToViewWithoutReport(deviceImplantInModelWindow_OR, deviceImplantInModelWindow_S);
			clickOnElementUsingJs(pastTransmissionInModelWindow_OR, pastTransmissionInModelWindow_S);
			break;
		case "DeviceImplant":
			scrollToViewWithoutReport(deviceImplantInModelWindow_OR, deviceImplantInModelWindow_S);
			clickOnElementUsingJs(deviceImplantInModelWindow_OR, deviceImplantInModelWindow_S);
			break;
		case "SignOut":
			clickOnElementUsingJs(signOutBtn_OR, signOutBtn_S);
			break;
		case "ModelWindowSaveButton":
			clickElement(saveButtonInModelWindow_OR, saveButtonInModelWindow_S);
			break;
		case "ModelWindowCancelButton":
			clickElement(cancelButtonInModelWindow_OR, cancelButtonInModelWindow_S);
			break;
		case "ClearOverDue":
			clickElement(clearOverdue_OR, clearOverdue_S);
			extentReport.reportScreenShot("Clear Overdue option is available in More Actions Dropdown");
			break;		
		case "ViewMergeReportCancelBtn":
			clickElement(viewMergedReportCanBtn_OR, viewMergedReportCanBtn_S);
			break;
		case "TextSumamryReportTitle":
			verifyElement(textSummaryTitle_OR);
			break;
		case "TextSummaryBtn":
			clickElement(textSummary_OR, textSummary_S);
			break;
		case "ViewMergedReportBtn":
			clickElement(viewMergedReport_OR, viewMergedReport_S);
			break;
		case "ViewMergedReportTitle":
			verifyElement(viewMergedReportTitle_OR);
			break;
		case "TransmissionDetailsPage":
			verifyElement(transmissionDetailsLink_OR);
			break;
		case "EpidosdeEGMLink":
			clickElement(episodeEGMsLink_OR,episodeEGMsLink_S);
			break;
		case "dateTimeInEpisodeAndEGM":
			verifyElement(dateTimeInEpisodeAndEGM_OR);
			break;
		case "zoneTypeInEpisodeAndEGM":
			verifyElement(zoneTypeInEpisodeAndEGM_OR);
			break;
		case "clMSInEpisodeAndEGM":
			verifyElement(clMSInEpisodeAndEGM_OR);
			break;
		case "threapyInEpisodeAndEGM":
			verifyElement(threapyInEpisodeAndEGM_OR);
			break;
		case "durationInEpisodeAndEGM":
			verifyElement(durationInEpisodeAndEGM_OR);
			break;
		case "EGMInEpisodeAndEGM":
			verifyElement(EGMInEpisodeAndEGM_OR);
			break;
		case "alertInEpisodeAndEGM":
			verifyElement(alertInEpisodeAndEGM_OR);
			break;	
		case "firstEpisodeDateAndTimeValue":
			clickElement(firstEpisodeDateAndTimeValue_OR,firstEpisodeDateAndTimeValue_S);
			break;	
		case "scheduleCancelBtn":
			clickElement(scheduleCancelBtn_OR, scheduleCancelBtn_S);
			break;
		case "scheduleDialogBox":
			verifyElement(scheduleDialogBox_OR);
			break;	
		case "scheduleLink":
			clickElement(scheduleLink_OR,scheduleLink_S);
			break;
		case "printLink":
			clickElement(printLink_OR,printLink_S);
			break;
		case "printDialogBox":
			verifyElement(printDialogBox_OR);
			break;	
		case "printCancelBtn":
			clickElement(printCancelBtn_OR,printCancelBtn_S);
			break;
			//Author: Madhan/Sai
		/*case "deviceConnectivityColumnInPA001":
			verifyElement(deviceConnectivityColumnInPA001_OR);
			break;	
		case "deviceUnderAdvisoryColumnInPA001":
			verifyElement(deviceUnderAdvisoryColumnInPA001_OR);
			break;
		case "LastTrasnmitterCommunicationColumnInPA001":
			verifyElement(LastTrasnmitterCommunicationColumnInPA001_OR);
			break;*/
		case "ConnectivityNote":
			verifyElement(connectivityNote_OR);
			break;
		case "ConnectionBtn":
			clickElement(connectionChkBox_OR,connectionChkBox_S);
			break;
		case "DoneBtn":
			clickElement(doneButton_OR,doneButton_S);
			break;
		case "ConnectivityNoteAdd":
			clickElement(connectivityNoteAdd_OR);
			break;
		case "SnoozeNotifications":
			clickElement(snoozeNotifications_OR);
			break;
		case "snoozeOKButton_OR":
			clickElement(snoozeNotifications_OR);
			break;
	}
		
	}
	public void minimizeBrowser() {
		drivUtil.driver.manage().window().minimize();
	}
	public void PatientNamesearch(String patientname) {
		String[] patientNo = patientname.split(",");
		sendKeys(patientListSearch_OR, patientListSearch_S, patientNo[1]);
		extentReport.reportScreenShot("Patient was searched with name - " + patientNo[1]);
	}

	public void SelectCheckBoxForAllColumns() throws InterruptedException {
		int size = getSizeOfElements(totalNoOfColumnsInModelWindow_OR, totalNoOfColumnsInModelWindow_S);
		for (int i = 1; i <= size; i++) {
			String totalNoOfColumnInModelWindow_OR = "(//div[@id='btn_column_name_visible_column']//following::div[1]/div/div["+i+"]/mat-checkbox/label/div/input)[1]";
			boolean isSelected = isSelected(By.xpath(totalNoOfColumnInModelWindow_OR));
			if (isSelected) {
				// Do nothing
			} else {
				clickOnElementUsingJs((By.xpath(totalNoOfColumnInModelWindow_OR)));
			}
		}
	}

	public void verifyPatientNameInModelWindow() {
		int size = getSizeOfElements(totalNoOfColumnsInModelWindow_OR, totalNoOfColumnsInModelWindow_S);
		for (int i = 1; i <= size; i++) {
			String modelWindowColumnName = "//div[@id='btn_column_name_visible_column']//following::div[1]/div/div[" + i
					+ "]/mat-checkbox/label/span/span[2]";
			String columnName = getText(By.xpath(modelWindowColumnName));
			if (columnName.equalsIgnoreCase("Patient")) {
				extentReport.pass(
						"Verified the system does not allow removing of the following fields as they are not listed in PA001");
			} else {
				extentReport.fail(
						"Verified the system allows removing of the following fields as they are not listed in PA001");
			}
		}
	}

	public void verifyTotalColumnsInPatientList() {
		int size = getSizeOfElements(totalCoulmnsInPatientList_OR, totalCoulmnsInPatientList_S);
		if (size - 1 == 12) {
			extentReport
					.pass("Actor logged in to the clinic where no columns removed and navigated to patient list page");
		} else {
			extentReport.fail(
					"Actor does not log in to the clinic where no columns removed and navigated to patient list page");
		}
	}

	// Author:Abhishek name
	private final By capturevalueforpatientT1FilterList_OR = By
			.xpath("//mat-select[@id='dd_patient-list_t1filterList']//div/span/span");
	private final String capturevalueforpatientT1FilterList_S = "patient with T1 filter";

	private final By capturevalueforPatientT2FilterList_OR = By
			.xpath("//mat-select[@id='dd_patient-list_t2filterList']//div/span/span");
	private final String capturevalueforPatientT2FilterList_S = "patient with T2 filter";

	//// td[contains(@id,'lbl_patient-list_td-patientStatus') and text()='Patient
	//// Expired'] //for expired

	public String captureTier1FilterMyActivePatient() {
		return getText(capturevalueforpatientT1FilterList_OR, capturevalueforpatientT1FilterList_S);
	}

	public String captureTier2FilterPatientWithOverdueFollowUp() {
		return getText(capturevalueforPatientT2FilterList_OR, capturevalueforPatientT2FilterList_S);
	}
	public boolean verifyPatientInTable(String patientName) {
		elementToBeClickable(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S);
		if(isElementPresent(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S))
		{
		return true;
		}
		else {
		return false;
		}



		}	
	
	public void searchPatients(String value) {
		sendKeys(searchBox_OR, searchbox_S, value);
	}
	
	public void clickOnPatientName() {
		if(visibilityOfElementLocated(patientName_OR)) {
		clickElement(patientName_OR, patientName_S);
		}
	}
	//This method clicks on Patient checkbox based on patient name
	public void clickOnPatientCheckBox(String value) throws InterruptedException {
		List<WebElement> patientNamelist =findElementslist(patientListSize_OR);
		for(int i=1;i<patientNamelist.size();i++)
		{
			int j=i;
			int k=i-1;
			final By patientNamelocator=By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr["+j+"]/td[1]/a");	
			String patientName= getAttribute(patientNamelocator,"innerText");
			if(patientName.contains(value)) {	
				String patientcheckBox_S = "Patient Check Box";
				//Shafiya 24/02/202. Modified xpath and the element is hidden so used javascriptexecutor
				final By patientcheckBox_OR=By.xpath("//mat-checkbox[@id='chb_patient-list_td-isSelected"+k+"']//div/input");
				Actions action = new Actions(driver);
				action.moveToElement(findElement(patientcheckBox_OR));
				clickOnElementUsingJs(patientcheckBox_OR, patientcheckBox_S);
				break;
			}
		}
	}
	
	public void clickMoreActionsButton() {
		elementToBeClickable(moreActionsBtn_OR,moreActionsBtn_S);
		//As the element hidden changed the below method shafiya 24/02/2022
		clickOnElementUsingJs(moreActionsBtn_OR,moreActionsBtn_S);
	}
	
	public void clickReleasePatientLink() {
		elementToBeClickable(releasePatientLink_OR,releasePatientLink_S);
		clickElement(releasePatientLink_OR,releasePatientLink_S);
	}
	
	public void clickEnrollAPatientButton() {
		elementToBeClickable(enrollNewPatientButton_OR,enrollNewPatientButton_S);
		clickElementWithoutReport(enrollNewPatientButton_OR,enrollNewPatientButton_S);
	}
	
	public boolean verifyEnrollAPatientButton() {
		boolean checkEnrollButton = false;
		if(visibilityOfElementLocatedWithoutReport(enrollNewPatientButton_OR, enrollNewPatientButton_S)) 
		{
			extentReport.reportPass("Enrolled Button on Patient List Page is shown");
			checkEnrollButton = true;
		}
		else
			extentReport.reportFail("Enrolled Button on Patient List Page is shown");
		
		return checkEnrollButton;
	}
	
	public void selectValueInReasonForReleaseDropDown(String reason) throws InterruptedException {
		By reasonForRelease_OR = By.xpath("//*[contains(text(),'"+reason+"')]");
		String reasonForRelease_S = "Reason For Release";
		clickElement(reasonForReleaseDropDwn_OR, reasonForReleaseDropDwn_S);
		if(isElementPresent(reasonForRelease_OR)) {
			clickElement(reasonForRelease_OR, reasonForRelease_S);
		}
		
	}
	
	public void selectClinicName(String value) throws InterruptedException {
		List<WebElement> cliniclist =findElementslist(clinicListSize_OR);
		for(int i=1;i<cliniclist.size();i++)
		{
			int j=i;
			final By clinicNamelocator=By.xpath("//table[@id='dtl_patient-list_clinicDataSource']/tbody/tr["+j+"]/td[1]");	
			String clinicName= getAttribute(clinicNamelocator,"innerText");
			if(clinicName.contains(value)) {
				final By clinicRadioButton_OR=By.xpath("//mat-radio-button[@id='mat-radio-"+j+"']/label/div/input");
				String clinicRadioButton_S = "Clinic Radio Button";
				clickElement(clinicRadioButton_OR, clinicRadioButton_S);
			}
		}
	}
	
	public void clickReleaseButton() {
		clickElement(releaseBtn_OR,releaseBtn_S);
		//added by shafiya 24/02/2022 as the page is loading after release
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
	}
	
	public List<String> getEnrollTransferredPatientList() throws InterruptedException {
		List<WebElement> patientlist =findElementslist(patientsTrsnfrdToClinicSize_OR);
		List<String> trnsfdPatientList = new ArrayList<String>();
		for(int i=1;i<patientlist.size();i++)
		{
			int j=i;
			final By patientNamelocator=By.xpath("//*[@id='app-container']/app-patient-finder/div[1]/app-pending-enrollment-by-clinic/div[1]/table/tbody/tr["+j+"]/td[1]");	
			String patientName= getAttribute(patientNamelocator,"innerText");
			trnsfdPatientList.add(patientName);
		}
		return trnsfdPatientList;	
	}
	
	public List<String> getPatientList() throws InterruptedException {
		List<WebElement> patientList =findElementslist(patientList_OR);
		List<String> trnsfdPatientList = new ArrayList<String>();
		for(int i=1;i<patientList.size();i++)
		{
			int j=i;
			final By patientNamelocator=By.xpath("//table[@id='dtl_patient-list_table']/tbody/tr/td["+j+"]");	
			String patientName= getAttribute(patientNamelocator,"innerText");
			trnsfdPatientList.add(patientName);
		}
		return trnsfdPatientList;
	}

	//snehal
		private final By tier3FilterDrpdown_OR= By.xpath("//input[@id='txt_patient-list_search']");
		private final String tier3FilterDrpdown_S ="Tier3 filter searchbox";
		
		private final String patientNameFrmList_OR = "//td[contains(@id,'lbl_patient-list_td-patientName0')]/a/span[text()='{0}']";													
		private final String patientNameFrmList_S = "Patient Name in the List";

		private final String allTransmissionLinkFrmList_OR= "//td[contains(@id,'lbl_patient-list_td-patientName')]//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[contains(@id,'lbl_patient-list_td-allTransmission')]/a";
		private final String allTransmissionLinkFrmList_S = "Unviewed Transaction With Patient List";
		
		private final By latestTransmissionFrmList_OR = By.xpath("//td[contains(@id,'lbl_patient-list_td-latestTransmission0')]/a");
		private final String latestTransmissionFrmList_S = "Latest Transmission link for Patient on Patient List page";

		private final By latestTransmissionTblHdr_OR = By.xpath("//button[@class='mat-sort-header-button mat-focus-indicator ng-tns-c163-822']");
		private final String latestTransmissionTblHdr_S = "Latest Transmission Table Header";
		
		private final By firstPatientNameInList_OR = By.xpath("//td[@id='lbl_patient-list_td-patientName0']//span");
		private final String firstPatientNameInList_S = "Patient Name in the List";
		
		


		//Snehal
		public void enterTier3FilterInputBx(String text) {
			loading();
			elementToBeClickable(tier3FilterDrpdown_OR, tier3FilterDrpdown_S);
			driver.findElement(tier3FilterDrpdown_OR).clear();
			sendKeys(tier3FilterDrpdown_OR, text);
			extentReport.reportScreenShot(text + " entered in tier3filter searchbox");
		}
				
		public boolean verifySearchedPatientInTable(String patientName) {
			Boolean flag = false;
			if(visibilityOfElementLocatedWithReport(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S)) {
				extentReport.reportScreenShot("Searched result is displayed");
				flag = true;
			}
			return flag;
		}
		
		
				
		public void clickonAllTransmissionFrmList(String patientName) {
				if(verifySearchedPatientInTable(patientName)) {
					clickElement(By.xpath( allTransmissionLinkFrmList_OR.replace("{0}", patientName)), allTransmissionLinkFrmList_S);
				}
		}
		
		public void clickonLatestTransmissionFrmList(String patientName) {
			if(verifySearchedPatientInTable(patientName)) {
				clickElement(latestTransmissionFrmList_OR, latestTransmissionFrmList_S);
			}
	}
					
		public  void clickOnPatientNameFrmList(String patientName) {
				if(verifySearchedPatientInTable(patientName)) {				
					clickElement(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S);
				}
		}














	//Author:Abhishek name
	//xpath modified by Snehal	
		private final By searchForPatientTier3Filter_OR=By.xpath("//button[@id='btn_patient-list_advanceSearch']/span/mat-icon");
		private final String searchForPatientTier3Filter_S="search patient in table";
		
	////td[contains(@id,'lbl_patient-list_td-patientStatus') and text()='Patient Expired']  //for expired
		private final By patientStatusInTable_OR=By.xpath("//td[@id='lbl_patient-list_td-patientStatus0']/span");
		private final String patientStatusInTable_S="patient status";
		
		private final By patientStatusInList_OR=By.xpath("//td[@id='lbl_patient-list_td-patientStatus0']");
		private final String patientStatusInList_S="patient status";

	
	public void clickOnSearchOption() {
		clickElement(searchForPatientTier3Filter_OR, searchForPatientTier3Filter_S);
	}

	public boolean verifyPatientStatusInPatientListTable(String patientName) {
		enterTier3FilterInputBx(patientName);
		clickOnSearchOption();
		boolean flag=false;
		if(isDisplayedWithoutReport(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S)==true)
		{
		if(getText(patientStatusInTable_OR)=="Active"){
		extentReport.reportInfo("Status of patient is Active");
		return flag;
		}
		else if(getText(patientStatusInTable_OR)=="Released/Transfer to Another Clinic"){
		extentReport.reportInfo("Status of patient is Released/Transfer to Another Clinic");
		return flag;
		}
		

	}
		return flag;

}
	
	
public boolean verifyAllTransmissionInPatientList() {
	Boolean isPresent = false;
	int count = 0;
	List<WebElement> elementslist = findElementslist(allTransmission_OR, allTransmission_S);
	for (int i = 0; i < elementslist.size(); i++) {
		String valueOfAllTransmission = elementslist.get(i).getText();
		String[] values = valueOfAllTransmission.split("");
		count = Integer.valueOf(values[0]);
		isPresent = true;
	}
	if (isPresent == true) {
		extentReport.pass("Success - Remote and In-clinic Transmission count is displayed");

	} else {
		extentReport.fail("Failure - Remote and In-clinic Transmission count is not displayed");

	}

	return isPresent;
}


public boolean verifyPatientStatus(String patientName) {
	enterTier3FilterInputBx(patientName);
	clickOnSearchOption();
	boolean flag=false;
	
	if(getText(firstPatientNameInList_OR).equalsIgnoreCase(patientName)) {
		if(getText( patientStatusInList_OR).isEmpty()){
			flag=true;
		}else if(getText(patientStatusInTable_OR).equalsIgnoreCase("Released/Transfer to Another Clinic")) {
			flag=true;
		}
		
	}else {
		extentReport.fail(patientName + "is not found in the list");
	}
		
	return flag;
}























public final By tier1FilterActivePatient_OR=By.xpath("//mat-select[@id='dd_patient-list_t1filterList']//div/span/span");
public final String tier1FilterActivePatient_S="My Active patient";

private final By tier2FilterDrpdownOptionsPatientwith_OR= By.xpath("//mat-select[@id='dd_patient-list_t2filterList']//span");
private final String tier2FilterDrpdownOptionsPatientwith_S ="Patient dropdown for active and released";

private final String tier2FilterDrpdownOptionsPatientwithfuture_OR= "(//div[@id='dd_patient-list_t2filterList-panel']/mat-optgroup/mat-option)[{0}]";
private final String tier2FilterDrpdownOptionsPatientwithfuture_S ="Patient Filter with future Options";
public void validateActivePatientDropdown() {
	isDisplayedWithReport(tier1FilterActivePatient_OR, tier1FilterActivePatient_S); 
}

public boolean validateTier2filterPatientwithfuture(String quicklinkValue) {
	//quicklinkValue=quicklinkValue.trim();
	elementToBeClickable(tier2FilterDrpdownOptionsPatientwith_OR, tier2FilterDrpdownOptionsPatientwith_S);
	clickElement(tier2FilterDrpdownOptionsPatientwith_OR, tier2FilterDrpdownOptionsPatientwith_S);
	boolean flag=false;
	if(quicklinkValue.equalsIgnoreCase("Patients with no future schedule")) {
		flag=isDisplayedWithReport(By.xpath(tier2FilterDrpdownOptionsPatientwithfuture_OR.replaceAll("{0}", "4")), tier2FilterDrpdownOptionsPatientwithfuture_S); 
		return flag;
	}
	else if(quicklinkValue.equalsIgnoreCase("Patients with overdue follow-up")) {
		flag=isDisplayedWithReport(By.xpath(tier2FilterDrpdownOptionsPatientwithfuture_OR.replaceAll("{0}", "5")), tier2FilterDrpdownOptionsPatientwithfuture_S);
		return flag;
	}

	else {
		System.out.println("Not able to find the optionin dropdown");

	}
	return flag;


}
//Author :Dhaval
	public void clickAllTransmissionTab() {
		elementToBeClickable(allTransmissionTab_OR, allTransmissionTab_S);
		clickElement(allTransmissionTab_OR, allTransmissionTab_S);
	}
	
	/*
	 * Salin Gambhir
	 * For TC name: NV_PA001_PatLst_01
	 */
	
	private final By clinicalComment_OR = By.xpath("//td[@id='lbl_patient-list_td-latestComments0']");
	private final String clinicalComment_S = "Clinical Comment Pen icon";
	private final By clinicalCommentHdr_OR = By.xpath("//h6[@id='title_clinical-comment_clinical_comment']");
	private final String clinicalCommentHdr_S = "Clinical Comment Section";
	private final By clinicalCommentCancel_OR = By.xpath("//button[@id='btn_clinical-comment_cancel2']");
	private final String clinicalCommentCancel_S = "Cancel button on Clinical Comment Cancel";
	private final By releasePatientHdr_OR = By.xpath("//h6[@id='mat-dialog-title-0']");
	private final String releasePatientHdr_S = "Release Patient Pop-Up";
	private final By closeReleasePatient_OR = By.xpath("//h6[@id='mat-dialog-title-0']");
	private final String closeReleasePatient_S = "Close button on Release Patient";
	private final By nextTransmission_OR = By.xpath("//td[@id='lbl_patient-list_td-nextTransmission0']");
	private final String nextTransmission_S = "Next Transmission value of patient";
	private final By editFollowUpSchedule_OR = By.xpath("//mat-dialog-container[@id='mat-dialog-1']//app-followuppatient-schedule");
	private final String editFollowUpSchedule_S = "Schedule Pop-up";
	private final By editableSchedule_OR = By.xpath("//mat-select[@id='mat-select-10']");
	private final String editableSchedule_S = "Schedule Type";
	//xpath changed bhupendra edited
	//private final By paginationValue_OR = By.xpath("//mat-select[@role='listbox']/div/div[1]/span/span[@class='ng-tns-c149-154 ng-star-inserted']");
	private final By paginationValue_OR = By.xpath("//mat-select[@aria-label='Items per page:' and @role='listbox']//span/span");	
	private final String paginationValue_S = "Pagination value on Patient List page";
	//author Bhupendra
	private final By paginationOptions_OR = By.xpath("//mat-option[contains(@id,'mat-option')]/span");	
	private final String paginationOptions_S = "Pagination Options on Patient List page";

	
	public void getPatientSortOrder(List<String> unsortedList) {
		Collections.sort(unsortedList);
		
		
	}
	
	public boolean verifySortingPatient(List<String> beforeSorting, List<String> afterSorting) {
		
		return beforeSorting.equals(afterSorting);
		
	}
	
	//edited by bhupendra
	public void selectPaginationValue(String pageValue) {
		elementToBeClickable(paginationValue_OR, paginationValue_S);
		clickElement(paginationValue_OR, paginationValue_S);
		List<WebElement> paginationOptions = driver.findElements(paginationOptions_OR);
		for(WebElement ele : paginationOptions) {
		 String hhh = ele.getText();
			if(ele.getText().equalsIgnoreCase(pageValue)) {
				ele.click();
				break;
			}
		}
		//sendKeys(paginationValue_OR, paginationValue_S, pageValue);
	}
	
	public boolean verifyPaginationValue(String paginationValue)
	{
		boolean checkPaginationValue = false;
		String pageValue = "";
		try {
			pageValue= getText(paginationValue_OR,paginationValue_S);
			if(pageValue.equals(paginationValue))
			{
				extentReport.reportPass("Pagination value correctly done");
				checkPaginationValue = true;
			}//edited by bhupendra
			//else
				//extentReport.reportFail("Pagination value not done correctly");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		return checkPaginationValue;
	}
	
	
	// end salin gambhir
	
	public void clickOnCommentButton() {
		
		elementToBeClickable(clinicalComment_OR, clinicalComment_S);
		clickElement(clinicalComment_OR, clinicalComment_S);
			
	}

	public boolean verifyClinicalCommentPage() {
		// TODO Auto-generated method stub
		boolean checkClinicalComment=false;
		try {
			if (visibilityOfElementLocatedWithReport(clinicalCommentHdr_OR,clinicalCommentHdr_S))
			{
				extentReport.reportScreenShot("Clinical Comment Page is shown");
				checkClinicalComment = true;
			}
			else
				extentReport.reportFail("Clinical Comment page is not shown");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		return checkClinicalComment;
	}

	public void clickOnClinicalCommentCancelButton() {
		// TODO Auto-generated method stub
		elementToBeClickable(clinicalCommentCancel_OR, clinicalCommentCancel_S);
		clickElement(clinicalCommentCancel_OR, clinicalCommentCancel_S);
		
	}
	public boolean verifyReleasePatientPopUp() {
		// TODO Auto-generated method stub
		boolean checkReleasePatient = false;
		try {
			if (visibilityOfElementLocatedWithReport(releasePatientHdr_OR,releasePatientHdr_S))
			{
				extentReport.reportScreenShot("Clinical Comment Page is shown");
				checkReleasePatient = true;
			}
			else
				extentReport.reportFail("Clinical Comment page is not shown");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		return checkReleasePatient;
	}


	
	public void clickOnCancelReleasePatient() {
		elementToBeClickable(closeReleasePatient_OR, closeReleasePatient_S);
		clickElement(closeReleasePatient_OR, closeReleasePatient_S);
	}
	
	public void clickOnNextTransmission() {
		elementToBeClickable(nextTransmission_OR, nextTransmission_S);
		clickElement(nextTransmission_OR, nextTransmission_S);
		
	}
	
	public boolean verifyNextTransmissionPopUp() {
		boolean checkSchedule = false;
		try 
		{
			if (visibilityOfElementLocatedWithReport(editFollowUpSchedule_OR,editFollowUpSchedule_S))
			{
				extentReport.reportScreenShot("Next Transmission Schedule Page is shown");
				checkSchedule = true;
			}
			else
				extentReport.reportFail("Clinical Comment page is not shown");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return checkSchedule;
	}
	
	public boolean verifyNextTransmissionPopUpEditable() {
		boolean checkEditSchedule = false;
		
		try {
			if (isEnabledWithReport(editableSchedule_OR,editableSchedule_S))
			{
				extentReport.reportPass("Schedule page is editable");
				checkEditSchedule= true;
			}
			else
				extentReport.reportFail("Schedule page is not editable");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		return checkEditSchedule;
	}
	
	public void clickOnCancelSchedule() {
		
	}
	// end salin gambhir
	
	// merged next transmission 
	public boolean validateNextTransmissionValue(String patientName) {
		boolean flag=false;
		enterTier3FilterInputBx(patientName);
		verifyPatientInTable(patientName);
		Date currentDate = new Date();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM-dd-yyyy");
		String dateOnly = dateFormat.format(currentDate).toString();
		System.out.println(dateOnly);
		if(getText(nextTransmission_OR, nextTransmission_S)=="None") {
			flag=true;
			extentReport.reportInfo("Patient does not have next schedule");
			return flag;
		}
		else if(getText(nextTransmission_OR, nextTransmission_S).compareTo(dateOnly)<0){
			flag=true;
			extentReport.reportInfo("patient has overdue follow-up schedule ");
			return flag;
		}
		else if(getText(nextTransmission_OR, nextTransmission_S).compareTo(dateOnly)>0){
				{
					flag=true;
			extentReport.reportInfo("patient has future follow up schedule");
			return flag;
				}
	}
		return flag;
	}
	//Poojitha
			public boolean verifyPatientNameColumn(String patientName)
			{
				boolean check = false;
				String value = findElement(patientList_OR,patientList_S).getText();
				if (value.contains(patientName))
				check = true;
				return check;
			}
			
			private final String patientNameFrmPatientList_OR ="//td[contains(@id,'lbl_patient-list_td-patientName0')]/a/div/span[text()='{0}']";
			private final String patientNameFrmPatientList_S = "Patient Name in the List";
	
			private final By namefFirstPatientInTable_OR=By.xpath("//td[@id='lbl_patient-list_td-patientName0']/a");
			private final String namefFirstPatientInTable_S="FirstPatientName";
	
			
			
			//xpath for validating patient is belonging to medical team
			private final By medicalTeamMember_OR=By.xpath("(//div[@id='app-container']//div//p)[3]");
			private final String medicalTeamMember_S="Physcian notification";
	
			//This method is for validating whether a patient is active or released from the clinic
			public boolean verifyActiveAndReleasedPatientInPatientListPage(String patientName,String index){
				boolean flag=false;
				enterTier3FilterInputBx(patientName);
				if(isElementPresent(By.xpath(patientNameFrmPatientList_OR.replace("{0}",patientName).replace("{1}",index)),patientNameFrmPatientList_S)==true)
				{
				if(driver.findElement(By.xpath("//td[@id='lbl_transmission-list_td-alertsList1']")).getText()=="system'||'episodal")
					{
					extentReport.info("Patient enrolled is an active patient");
						return flag;
		        }
				else if(isElementPresent(By.xpath(patientNameFrmPatientList_OR.replace("{0}",patientName).replace("{1}",index)),patientNameFrmPatientList_S)==false)
				{
					extentReport.info("Patient enrolled is an Released patient");
					return flag;  
				}
					
					}
				return flag;
				}
			
			
			//Kundan
			private final By patList_Transmission_Tab_OR = By.xpath("//mat-toolbar-row[@id=\"sub-header\"]/div/a[2]");
			private final String patList_Transmission_Tab_S = "Patient list Transmission tab";
			
			private final By patList_Transmission_Moreaction_OR = By.xpath("//button[@id=\"btn_transmission_summary_selectMoreAction\"]");
			private final String patList_Transmission_Moreaction_S= "Patient list Transmission tab more action";
			
			private final By Transmission_Moreaction_Markunviewed_OR = By.xpath("//*[@id=\"btn_transmission-summary-more_action-list-item_markUnViewed\"]");
			private final String Transmission_Moreaction_Markunviewed_S= "Patient list Transmission tab more action markunviewed option";
			
			private final By patList_AllTransmission_Tab_OR = By.xpath("//mat-toolbar-row[@id=\"sub-header\"]/div/a[3]/span");
			private final String patList_AllTransmission_Tab_S = "Patient list All Transmission tab";
			
			private final By Transmission_Moreaction_ExportTransmission_OR = By.xpath("//button[@id=\"btn_transmission-summary-more_action-list-item_patient-2\"]");
			private final String Transmission_Moreaction_ExportTransmission_S= "Patient list Transmission tab more action Export Transmission option";
			
			private final By Transmission_Moreaction_Directcall_OR = By.xpath("//button[@id=\"btn_transmission-summary-more_action-list-item_sendDirectCall\"]");
			private final String Transmission_Moreaction_Directcall_S= "Patient list Transmission tab more action Direct call option";
			
			private final By Transmission_Moreaction_contactAColleague_OR = By.xpath("//button[@id=\"btn_transmission-summary-more_action-list-item_contactAColleague\"]");
			private final String Transmission_Moreaction_contactAColleague_S= "Patient list Transmission tab more action contactAColleague option";
			
			private final By Direct_call_Window_OR=By.xpath("//h6[@id=\"lbl_send-direct-call_send_a_directcall\"]");
			private final String Direct_call_Window_S="Send a direct call window verification";
			
			private final By Directcall_Callclinic_Radiobutton_OR=By.xpath("//mat-radio-button[@id=\"dtl_send-direct-call_callClinic0\"]/label/div[1]/div");
			private final String Directcall_Callclinic_Radiobutton_S="Send a direct call window call clinic Radion Button";
			
			private final By Directcall_Window_Send_Button_OR=By.xpath("//button[@id=\"dtl_send-direct-call_send\"]/span");
			private final String Directcall_Window_Send_Button_S="Send a direct call window send Button";
			
			private final By Contact_Acolleague_Window_OR=By.xpath("//div[@id=\"section_title_Contact_a colleague\"]");
			private final String Contact_Acolleague_Window_S="Contact a colleague window verification";
			
			private final By Contact_Acolleague_Window_Closebutton_OR=By.xpath("//button[@id=\"btn_contact-colleague_close\"]");
			private final String Contact_Acolleague_Window_Closebutton_S="Contact a colleague window close button";
			
			private final By Contact_Acolleague_Window_Savebutton_OR=By.xpath("//button[@id=\"btn_contact-colleague_send\"]");
			private final String Contact_Acolleague_Window_Savebutton_S="Contact a colleague window save button";
			
			private final By patList_All_Transmission_Moreaction_OR = By.xpath("//button[@id=\"btn_all-transmission_menu-trigger\"]");
			private final String patList_All_Transmission_Moreaction_S= "Patient list all transmission tab more action";
			
			private final By alltransmission_Moreaction_Markasunviewed_OR = By.xpath("//button[@id=\"dd_all-transmission_menuItem0\"]");
			private final String alltransmission_Moreaction_Markasunviewed_S= "Patient list all Transmission tab more action mark as unviewed option";
			
			private final By alltransmission_Moreaction_ExportTransmission_OR = By.xpath("//button[@id=\"dd_all-transmission_menuItem1\"]");
			private final String alltransmission_Moreaction_ExportTransmission_S= "Patient list all Transmission tab more action export transmission option";
			
			private final By alltransmission_Moreaction_Directcall_OR = By.xpath("//button[@id=\"dd_all-transmission_menuItem2\"]");
			private final String alltransmission_Moreaction_Directcall_S= "Patient list all Transmission tab more action Send a Direct call option";
			
			
			
			
			public void navigateToTranmissionTab() throws Exception
			{
				
				clickElement(patList_Transmission_Tab_OR);
			}
			
			public void navigateToTransmissionMoreaction() throws Exception
			{
				
				clickElement(patList_Transmission_Moreaction_OR);
			}
			
			public void naviagteToMarkunviewedOption() throws Exception
			{
				
				clickElement(Transmission_Moreaction_Markunviewed_OR);
			}
			
			public void navigateToAllTransmissionTab() throws Exception
			{
				clickElement(patList_AllTransmission_Tab_OR, patList_AllTransmission_Tab_S);
				
			}
			
			public void verifyTranmissionInBold() throws Exception
			{
				//Need to check how to verify this in UI
			}
			
			public void navigateToExportTransmission() throws Exception
			{
				clickElement(Transmission_Moreaction_ExportTransmission_OR, Transmission_Moreaction_ExportTransmission_S);
			}
			
			public void verifyExportTransmissionWindow() throws Exception
			{
				
			}
			
			public void navigateToDirectCallOption() throws Exception
			{
				clickElement(Transmission_Moreaction_Directcall_OR, Transmission_Moreaction_Directcall_S);
				
			}
			
			public void validatePtListDirectcallwindow() throws Exception
			{
				Boolean directcallwindow= isElementPresent(Direct_call_Window_OR, Direct_call_Window_S);
				System.out.println("Direct call window is present "+directcallwindow);
			}
			
			public void selectRadioButtonDirectCallWindow() throws Exception
			{
				clickElement(Directcall_Callclinic_Radiobutton_OR, Directcall_Callclinic_Radiobutton_S);
				clickElement(Directcall_Window_Send_Button_OR, Directcall_Window_Send_Button_S);
			}
			
			public void navigateToContactColleague() throws Exception
			{
				clickElement(Transmission_Moreaction_contactAColleague_OR, Transmission_Moreaction_contactAColleague_S);
			}
			
			public void validateContactAcolleagueWindow() throws Exception
			{
				Boolean contactcolleguewindow=isElementPresent(Contact_Acolleague_Window_OR, Contact_Acolleague_Window_S);
				System.out.println("Contact a colleague window displayed "+contactcolleguewindow);
				clickElement(Contact_Acolleague_Window_Closebutton_OR, Contact_Acolleague_Window_Closebutton_S);
			}
			
			public void navigateToAllTransmissionMoreaction() throws Exception
			{
				
				clickElement(patList_All_Transmission_Moreaction_OR);
			}
			public void navigateToMarkasUnviewedOption() throws Exception
			{
				clickElementWithoutReport(alltransmission_Moreaction_Markasunviewed_OR, alltransmission_Moreaction_Markasunviewed_S);
			}
			
			public void navigateToAllTransmissionExportTransmission() throws Exception
			{
				clickElement(alltransmission_Moreaction_ExportTransmission_OR, alltransmission_Moreaction_ExportTransmission_S);
			}
			
			public void navigateToAllTransmissionDirectCall() throws Exception
			{
				clickElement(alltransmission_Moreaction_Directcall_OR, alltransmission_Moreaction_Directcall_S);
			}
			
		    public void editPatientProfile() throws Exception
			{
						//Once it is will avaiable in d4 will write further in method
			}
					
			//Kundan End
		    
		  //Poojitha
		    public void clickonPatientSummaryFrmList(String patientName) {
				if(verifySearchedPatientInTable(patientName)) {
					clickElement(patientSummaryLinkFrmList_OR, patientSummaryLinkFrmList_S);
				}
}
//Ends here		    
		    public boolean verifyTierFilterText(By element,String patientName) {
		    	boolean tier1FilterValue=false;
		    	String tier1value = getText(element);
		    	System.out.println("Value :"+tier1value);
		    	if(tier1value.equals(patientName)) {
		    		tier1FilterValue=true;
		    	}
				return tier1FilterValue;
			}
		    
		    public boolean verifyTier1FilterValue(String patientName) {
		    	return verifyTierFilterText(tier1FilterDrpdown_OR, patientName);

			}
		    
		    public boolean verifyTier2FilterValue(String value) {
		    	return verifyTierFilterText(tier2FilterDrpdown_OR, value);
			}

		    public void clickonPatientNameFrmList() {
				if(isDisplayedWithoutReport(firstPatientNameInList_OR, firstPatientNameInList_S)) {
					clickElement(firstPatientNameInList_OR, firstPatientNameInList_S);
				}
		}
		    
		  //Alok
		    
			public void clickOnPatient() {
				presenceOfElementLocated(patients_OR);
				clickElement(patients_OR);
				loadingWithoutReport();
			}
			
			public void clickOnPatientInAllTrasmissionPage() {
					presenceOfElementLocated(patientsInAllTransmission_OR);
					clickElement(patientsInAllTransmission_OR);
					loadingWithoutReport();
				}
			
			public void clickOnEpisodesAndEGMs() {
				presenceOfElementLocated(EpisodesandEGM_OR);
				clickElement(EpisodesandEGM_OR);
				loadingWithoutReport();
			}
			
			public void verifyingDropDownValueForTier1FilterOnEPAndEGMPage(String option) {
				elementToBeClickable(ShowTier1DrpDwn_OR, tier1FilterDrpdown_S);
				clickOnElementUsingJs(ShowTier1DrpDwn_OR, tier1FilterDrpdown_S);
				if (option.equalsIgnoreCase("My Active Patients")) {
					elementToBeClickable(tier1FilterMyActivePatients_OR, tier1FilterMyActivePatients_S);
					clickOnElementUsingJs(tier1FilterMyActivePatients_OR, tier1FilterMyActivePatients_S);
				} else if (option.equalsIgnoreCase("Active Clinic Patients")) {
					elementToBeClickable(tier1FilterActiveClinicPatients_OR, tier1FilterActiveClinicPatients_S);
					clickElement(tier1FilterActiveClinicPatients_OR, tier1FilterActiveClinicPatients_S);
				} else if (option.equalsIgnoreCase("Inactive Patients")) {
					elementToBeClickable(tier1FilterInActivePatients_OR, tier1FilterInActivePatients_S);
					clickElement(tier1FilterInActivePatients_OR, tier1FilterInActivePatients_S);
				}
			}
			
			public void seletingDropDownValueForTier1FilterOnEPAndEGMPage(String option) {

				elementToBeClickable(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
				clickOnElementUsingJs(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
				switch (option) {
				case "All":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "1")),
							tier2FilterDrpdownOptions_S);
					clickOnElementUsingJs(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "1")), tier2FilterDrpdownOptions_S);
					break;
				case "Cardiac Monitor":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "2")),
							tier2FilterDrpdownOptions_S);
					clickOnElementUsingJs(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "2")), tier2FilterDrpdownOptions_S);
					break;
				case "ICD/Pacemaker":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "3")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "3")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients with no future schedule":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "4")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "4")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients with overdue follow-up":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "5")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "5")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients with pending transmissions due today":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "6")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "6")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients released for transfer":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "7")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "7")), tier2FilterDrpdownOptions_S);
					break;
				case "Release Requests from another clinic":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "8")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "8")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients with disconnected transmitters":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "9")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "9")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients with snoozed disconnected transmitter reporting":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "12")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "12")), tier2FilterDrpdownOptions_S);
					break;
				case "Patients ready for billing (Cardiac Monitors)":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "13")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "13")), tier2FilterDrpdownOptions_S);
					break;
				case "Patient Name":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "14")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "14")), tier2FilterDrpdownOptions_S);
					break;
				case "Patient ID":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "15")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "15")), tier2FilterDrpdownOptions_S);
					break;
				case "Patient Merlin.net™ Number":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "16")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "16")), tier2FilterDrpdownOptions_S);
					break;
				case "Physician Name/ID":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "17")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "17")), tier2FilterDrpdownOptions_S);
					break;
				case "Device Model Number":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "18")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "18")), tier2FilterDrpdownOptions_S);
					break;
				case "Device Serial Number":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "19")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "19")), tier2FilterDrpdownOptions_S);
					break;
				case "Device Type":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "20")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "20")), tier2FilterDrpdownOptions_S);
					break;
				case "Lead Model":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "21")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "21")), tier2FilterDrpdownOptions_S);
					break;
				case "Clinic Location":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "22")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "22")), tier2FilterDrpdownOptions_S);
					break;
				case "Latest Transmission Date Range":
					elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "23")),
							tier2FilterDrpdownOptions_S);
					clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "23")), tier2FilterDrpdownOptions_S);
					break;

				default:
					System.out.println("Not able to find the optionin dropdown");
				}

			}
			
			// Alok-End
			
			
			
//Snehal
		    
		    private final String rowInPatientListTable_OR = "//table[@id='dtl_patient-list_table']/tbody/tr";
		    private final String rowInPatientListTable_S = "row in PatientList Table";
		    
		    private final String collInPatientListTable_OR = "//table[@id='dtl_patient-list_table']/tbody/tr[1]/td";
		    private final String collInPatientListTable_S = "collumn in PatientList Table";
		    
		    
		  //snehal
		    public void performSearchOnAllFields(String value) {
		    			    	
		    	int rows= driver.findElements(By.xpath(rowInPatientListTable_OR)).size();
		    	int coll = driver.findElements(By.xpath(collInPatientListTable_OR)).size();
		    	
		    	for(int i=1; i<=rows; i++) {
		    		int rowCount = i;
	    			int collCount = 0;
	    			
		    		for (int j=1; j<coll; j++) {
		    			String xpath1 = rowInPatientListTable_OR + "[" + i + "]/td[" + j + "]";
		    			WebElement cell = driver.findElement(By.xpath(xpath1));
		    			String str = cell.getText().toLowerCase();
		    			if(str.contains(value)) {
		    				collCount++;
		    			}
		    		}
		    		System.out.println("Result found in: rownum: " + rowCount + "-" + collCount + " Collumns");
		    	}
		    	
		    }
		    
		    public boolean verifySearch() {
				Boolean flag = false;
				if(visibilityOfElementLocatedWithReport(By.xpath(rowInPatientListTable_OR), rowInPatientListTable_S)) {
					extentReport.reportScreenShot("Searched result is displayed");
					flag = true;
				}
				return flag;
			}
		    
		    public int countNumOfRecordsPresent() {
		    	int rows = 0;
		    	rows = driver.findElements(By.xpath(rowInPatientListTable_OR)).size();
		    	return rows;
		    }
		    //shafiya added below method on 24/02/2022
			//This method clicks on Re-activate Patient Link in More Actions 
		    public void clickReactivatePatientLink() {
		    	clickElement(reactivatePatientLink_OR,reactivatePatientLink_S);
			}
		    //shafiya added below method on 25/02/2022
	  		//This method is used to reActivate patient to run automation script successfully for 2nd time onwords
	  	    public void reactivatePatient(String patientName1, String patientName2, String patientName3) throws Exception{
	  	    	//Reactivate 1st patient
	  			clinicianHomeTopNavPage.clickPatientListLink();
	  			selectTierOneFilterOption("Inactive Patients");		   
	  			selectTierTwoFilterOption("All");
	  		   	   
	  		    searchPatients(patientName1);
	  		    
	  		    clickOnPatientCheckBox(patientName1);
	  		    clickMoreActionsButton();
	  		    clickReactivatePatientLink();
	  		    
	  		    
	  		   	//Reactivate 2nd patient   
	  		    searchPatients(patientName2);	    
	  		    clickOnPatientCheckBox(patientName2);
	  		    clickMoreActionsButton();
	  		    clickReactivatePatientLink();
	  		    
	  		    //Reactivate 3rd patient   
	  		    searchPatients(patientName3);	    
	  		    clickOnPatientCheckBox(patientName3);
	  		    clickMoreActionsButton();
	  		    clickReactivatePatientLink();
	  		}
	  	    
	  	    //Author:Madhan/Sai
			public Boolean toVerifyMistcondition(String searchText) {
				// TODO Auto-generated method stub
				try {
					String text = "";
					String actualText= "";
					text = getText(mistCondition_OR);
					actualText = text.replaceAll("[\r\n]+", " ");					
					Boolean flag = false;
					
					if(actualText.equalsIgnoreCase(searchText)) {
		  				flag= true;
		  				extentReport.pass("Getting the text is successful from webelement and the retrieved text is \""+actualText+"\"");
					}
					return flag;
					
				} catch (WebDriverException e) {
	  				extentReport.reportFail("Getting the text is not successful from webelement " + CommonUtils.convertStackTraceToString(e));
	  				throw new WebDriverException(e.getMessage());
	  				
	  			}	
				
			}
			public Boolean toVerifyICMcondition(String searchText) {
				// TODO Auto-generated method stub
				try {
		
					String actualText= "";
					actualText = getText(icmCondition_OR);					
					Boolean flag = false;
					
					if(actualText.equalsIgnoreCase(searchText)) {
		  				flag= true;
		  				extentReport.pass("Getting the text is successful from webelement and the retrieved text is \""+actualText+"\"");
					}
					return flag;
					
				} catch (WebDriverException e) {
	  				extentReport.reportFail("Getting the text is not successful from webelement " + CommonUtils.convertStackTraceToString(e));
	  				throw new WebDriverException(e.getMessage());
	  				
	  			}	
				
			}
			
			public Boolean toImplantDate(String searchText) {
				// TODO Auto-generated method stub
				try {
					String actualText= "";
					actualText = getText(implantDate_OR);					
					Boolean flag = false;
					
					if(actualText.equalsIgnoreCase(searchText)) {
		  				flag= true;
		  				extentReport.pass("Getting the text is successful from webelement and the retrieved text is \""+actualText+"\"");
					}
					return flag;
					
				} catch (WebDriverException e) {
	  				extentReport.reportFail("Getting the text is not successful from webelement " + CommonUtils.convertStackTraceToString(e));
	  				throw new WebDriverException(e.getMessage());
	  				
	  			}	
				
			}
			
			public Boolean toVerifyDevice(String searchText) {
				// TODO Auto-generated method stub
				try {
					String text = "";
					String actualText= "";
					
					text = getText(deviceAndSerial_OR);
					System.out.println(text);
					actualText = text.replaceAll("[\r\n]+", " ");
					System.out.println(actualText);
					Boolean flag = false;
					
					if(actualText.equalsIgnoreCase(searchText)) {
		  				flag= true;
		  				extentReport.pass("Getting the text is successful from webelement and the retrieved text is \""+actualText+"\"");
					}
					return flag;
					
				} catch (WebDriverException e) {
	  				extentReport.reportFail("Getting the text is not successful from webelement " + CommonUtils.convertStackTraceToString(e));
	  				throw new WebDriverException(e.getMessage());
	  				
	  			}	
				
			}
			
			public Boolean toVerifyLastTransmitterDate(String searchText) {
				// TODO Auto-generated method stub
				try {
					String actualText= "";
					actualText = getText(LastTrasnmitterCommunicationDatePA001_OR);					
					Boolean flag = false;
					
					if(actualText.equalsIgnoreCase(searchText)) {
		  				flag= true;
		  				extentReport.pass("Getting the text is successful from webelement and the retrieved text is \""+actualText+"\"");
					}
					return flag;
					
				} catch (WebDriverException e) {
	  				extentReport.reportFail("Getting the text is not successful from webelement " + CommonUtils.convertStackTraceToString(e));
	  				throw new WebDriverException(e.getMessage());
	  				
	  			}	
				
			}
			
			public Boolean toVerifyCommunicationType(String searchText) {
				// TODO Auto-generated method stub
				try {
					String text = "";
					String actualText= "";
					
					text = getText(communicationType_OR);
					System.out.println(text);
					actualText = text.replaceAll("[\r\n]+", " ");
					System.out.println(actualText);
					Boolean flag = false;
					
					if(actualText.equalsIgnoreCase(searchText)) {
		  				flag= true;
		  				extentReport.pass("Getting the text is successful from webelement and the retrieved text is \""+actualText+"\"");
					}
					return flag;
					
				} catch (WebDriverException e) {
	  				extentReport.reportFail("Getting the text is not successful from webelement " + CommonUtils.convertStackTraceToString(e));
	  				throw new WebDriverException(e.getMessage());
	  				
	  			}			
				
			}
				
			public boolean verifyConnectivityColumn() {
				boolean connectivityColumn = false;
				if(visibilityOfElementLocatedWithoutReport(deviceConnectivityColumnInPA001_OR, deviceUnderAdvisoryColumnInPA001_S)) 
				{
					extentReport.reportPass("Enrolled Button on Patient List Page is shown");
					connectivityColumn = true;
				}
				return connectivityColumn;
			}	
			
			public boolean verifyAdviosryColumn() {
				boolean AdviosryColumn = false;
				if(visibilityOfElementLocatedWithoutReport(deviceUnderAdvisoryColumnInPA001_OR,deviceUnderAdvisoryColumnInPA001_S)) 
				{
					extentReport.reportPass("Enrolled Button on Patient List Page is shown");
					AdviosryColumn = true;
				}
				return AdviosryColumn;
			}
			
			public boolean connectionColumnIsNotDisplay(){
				boolean connection = false;
				loading();
				
				try {
					if(isElementNotPresent(connection_OR))
					{
					connection = true;
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return connection;
			}
			
			public boolean toVerifyConnectivityNoteIsPresent(){
				boolean connectivityNote = false;
				loading();
				try {
					if(isElementNotPresentWithoutReport(connectivityNote_OR, connectivityNote_S))
					{
						connectivityNote = true;
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return connectivityNote;
			}
			
			public void connectivitityNote(String type) throws InterruptedException {
				switch (type) {
				
				case "addConnectivityNote":
					clickOnElementUsingJs(connectivityNoteAdd_OR, connectivityNoteAdd_S);
					loading();
					sendKeys(connectivityNoteTxtArea_OR, "Hello Abbott");
					loading();
					clickElement(saveButton_OR);
					break;
					
				case "modifyConnectivityNote":
					clickOnElementUsingJs(connectivityNoteAdd_OR, connectivityNoteTxtArea_S);
					loading();
					clear(connectivityNoteTxtArea_OR, connectivityNoteTxtArea_S);
					sendKeys(connectivityNoteTxtArea_OR, "Welcome Abbott");
					loading();
					clickElement(saveButton_OR);
					break;
					
				case "clearConnectivityNote":
					clickOnElementUsingJs(connectivityNoteAdd_OR, connectivityNoteTxtArea_S);
					loading();
					clear(connectivityNoteTxtArea_OR, connectivityNoteTxtArea_S);
					loading();
					clickElement(saveButton_OR);
					break;
				}
			}
			
			public void selectCheckBox() {
				clickElement(checkBox1_OR);
				loading();
				clickElement(checkBox2_OR);
			}
			
			/*public void addConnectivityNote(String text) {
				loading();
				try {
					clickElement(connectivityNoteAdd_OR);
					sendKeys(connectivityNoteTxtArea_OR, text);
					loading();
					clickElement(saveButton_OR);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			public void modifyConnectivityNote(String text) {
				loading();
				clickElement(connectivityNoteAdd_OR);
				sendKeys(connectivityNoteTxtArea_OR, text);
				loading();
				clickElement(saveButton_OR);
			}*/
			
			
}
			
