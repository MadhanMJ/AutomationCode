package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

//Author - Poojitha

public class PL_PatientProfile_LeftNavPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public PL_PatientProfile_LeftNavPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	// Poojitha
	private final By editButton_OR = By.xpath("//button[@id='profileEditButton']");
	private final String editButton_S = "Edit button";
	private final By patientDeviceData_OR = By
			.xpath("//div[@id='app-container']//div[@class='col-xs-2 navContainer']/div[2]");
	private final String patientDeviceData_S = "Patient Device & Data link";
	private final By transmitter_OR = By
			.xpath("//div[@id='app-container']//div[@class='col-xs-2 navContainer']/div[3]");
	private final String transmitter_S = "Transmitter link";
	private final By followupSchedule_OR = By
			.xpath("//div[@id='app-container']//div[@class='col-xs-2 navContainer']/div[4]");
	private final String followupSchedule_S = "Follow up schedule link";
	private final By directAlertsNotification_OR = By
			.xpath("//div[@id='app-container']//div[@class='col-xs-2 navContainer']/div[5]");
	private final String directAlertsNotification_S = "Direct Alerts notification link";
	private final By baselineClinicalData_OR = By
			.xpath("//div[@id='app-container']//div[@class='col-xs-2 navContainer']/div[6]");
	private final String baselineClinicalData_S = "Baseline Clinical Data link";
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	// Ends here

	// Poojitha
	public void navigateToPatientDeviceData() {
		clickElement(patientDeviceData_OR, patientDeviceData_S);
	}

	public void navigateToTransmitter() {
		clickElement(transmitter_OR, transmitter_S);
	}

	public void navigateToFollowUpSchedule() {
		clickElement(followupSchedule_OR, followupSchedule_S);
	}

	public void navigateToDirectAlertsNotifications() {
		clickElement(directAlertsNotification_OR, directAlertsNotification_S);
	}

	public void navigateToBaselineClinicalData() {
		clickElement(baselineClinicalData_OR, baselineClinicalData_S);
	}

	// Ends here

	@Override
	public boolean verifyLandingPage() {
		Boolean patientProfileLeftNavCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(editButton_OR, editButton_S)) {
			patientProfileLeftNavCheck = true;
		}
		return patientProfileLeftNavCheck;
	}

}
