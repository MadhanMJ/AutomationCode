package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

//Author: Salin Gambhir

public class PL_PatientEnrollment_BaselineClinicalData extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientEnrollment_BaselineClinicalData(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By baselineClinicalDataHeader_OR = By.xpath("//div[@id='baseline-clinical-data']/form/div[1]/h5");
	private final String baselineClinicalDataHeader_S = "Baseline Clinic Data Header";
//Poojitha
	private final By continueButton_OR = By.xpath("//*[@id=\"baseline-clinical-data\"]/form/div[5]/button[3]");
	private final String continueButton_S = "Continue button";
//Ends here
	
	//Poojitha
	public void clickContinueButton()
	{
		clickElement(continueButton_OR,continueButton_S);
	}
	
	@Override
	public boolean verifyLandingPage() {
		Boolean baselineClinicDataPageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(baselineClinicalDataHeader_OR, baselineClinicalDataHeader_S)) {
			baselineClinicDataPageCheck = true;
		}
		return baselineClinicDataPageCheck;
	}
	

}
