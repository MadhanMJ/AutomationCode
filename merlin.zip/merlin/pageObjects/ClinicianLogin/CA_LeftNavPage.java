package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_LeftNavPage extends BasePage {



	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public CA_LeftNavPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}


	private final By reportSettingsLink_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-settings/report-settings']/..");
	private final String reportSettingsLink_S = "Report Settings Link in Left Nav";

	private final By exportSettingsLink_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-settings/export-options']/..");
	private final String exportSettingsLink_S = "Export Settings Link in Left Nav";
	//Shafiya modified xpath as it is not working
//<<<<<<< HEAD
//	private final By merlinHomeTransmitterLink_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/icd-crt-d/merlin-at-home-transmitter");
	private final By merlinHomeTransmitterLink_OR = By.xpath(".//div[@id='icd-crt-d']//li[1]/a");
	
//=======
//	//ChandraMohan modified Xpath as it is NOT working as on 02/11/2020 .... :) 
//	private final By merlinHomeTransmitterLink_OR = By.xpath("//div[@id='icd-crt-d']/ul/li[1]");
//>>>>>>> refs/remotes/origin/feature/VinayBabu
	private final String merlinHomeTransmitterLink_S = "Direct Alerts Settings-> ICD/CRT-D->Merin@Home Transmitter";

//	private final By schedMessagingLink_OR = By.xpath("//div[@id=\"app-container\"]/app-clinic-admin-layout-cmp/div/app-clinic-admin-sidebar-cmp/div/div[3]/ul/li[2]/a");
	private final By schedMessagingLink_OR = By.xpath("//div[@id='app-container']//app-clinic-admin-sidebar-cmp/div/div[3]/ul/li[2]/a");
	private final String schedMessagingLink_S = "Scheduling and Messaging Link in Left Nav";
	//ChandraMohan Updated the XPAth as it NOT properly clicking.
	private final By pacemaker_CRTP_OR =By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/pacemaker-crt-p']");
	private final String pacemaker_CRTP_S = "Pacemaker Link in Left Nav";

	private final By MerlinHome_OR =By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/icd-crt-d/merlin-at-home-transmitter']");
	private final String MerlinHome_S ="Merlin@Home Link in Left Nav";
	private final By CardiacMonitor_OR =By.xpath("//div[@id='direct-alert-settings']/ul[@class='nav']/li[@class='nav-item ng-star-inserted'][3]/a");
	private final String CardiacMonitor_S ="Cardiac Monitor Link in Left Nav";
	private final By directAlertSettings_CRTP_OR =By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/icd-crt-d/mobile-app-transmitter']/ancestor::ul/li[4]/div/span");
	private final String directAlertSettings_CRTP_S="Direct Alert settings Link in Left Nav";
	private final By mobileAppTransmitter_CRTP_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/icd-crt-d/mobile-app-transmitter']");
	private final String MobilAppTransmitter_S ="Mobile App Aransmitter Link in Left Nav";
	private final By cardiacMonitorLink_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/cardiac-monitor']/span");
	private final String cardiacMonitorLink_S = "Cardiac Monitor Link in Left Nav";
	private final By directAlertSettings_ICDCRTD_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/direct-alerts-settings/icd-crt-d']");
	private final String directAlertSettings_ICDCRTD_S = "ICD/CRT-D Link under Direct Alerts Setting header in Left Nav";
	private final By directAlertSettings_ICDCRTD_MerlinHome_OR = By.xpath("//div[@id='icd-crt-d']/ul/li[1]/a");
	private final String directAlertSettings_ICDCRTD_MerlinHome_S = "Merlin@Home transmitter link under Direct Alerts Setting header in Left Nav";
	private final By directAlertSettings_ICDCRTD_MobileApp_OR = By.xpath("//*[@id=\"icd-crt-d\"]/ul/li[2]/a");
	private final String directAlertSettings_ICDCRTD_MobileApp_S = "Mobile App transmitter link under Direct Alerts Setting header in Left Nav";
	private final By ClinicLocations_link_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-locations']");
	private final String ClinicLocations_link_S = "Clinic Locations Link";
    private final By clinicSettings_OR=By.xpath("(//div[@id='direct-alert-settings']/ul[@class='nav']/li[3]/following::li[@class='nav-item ng-star-inserted']/a[@class='nav-link ng-star-inserted'])[1]");
    private final String clinicSetting_S="Clinic Setting Link";


	private final By clinicProfileLink_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-profile']");
	private final String clinicProfileLink_S = "Clinic Profile Page Link";
	private final By clinicUser_OR=By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-users']");
	private final String clinicUser_S="Clinic User Link";
	private final By clinicHoursHoliday_OR=By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-hours-holidays']");
	private final String clinicHoursHoliday_S="clinic hours holidays";
	private final By clinicalComments_OR=By.xpath("//*[@id='clinic-settings']/ul/li[3]/a");
	private final String clinicalComments_S="Clinical Comments";
	
    private final By pacemaker_CRT_PTab_OR = By.xpath("//div[@id=\"direct-alert-settings\"]/ul/li[2]/a/span");
    private final String pacemaker_CRT_PTab_S = "Pacemaker_CRT_PTab";

	//Poojitha - Added XPath - Date: 28th Dec 2021
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "Page loading symbol";
	//Ends here
	//victor
	public void clickPacemaker_CRT_PLink () throws InterruptedException
	{
		presenceOfElementLocated(pacemaker_CRT_PTab_OR);
		waitForLoading();
		//extentReport.reportScreenShot("Clicking Merlin Home Transmitter Link");
		clickElement(pacemaker_CRT_PTab_OR);
	}
	
	//Vrushali -- start
	private final By userProfile_OR = By.xpath("//a[contains(@href, 'clinic-profile')]");
	private final String userProfile_S = "User Profile";
	
	public void clickUserProfile() {
		clickElement(userProfile_OR, userProfile_S);
	}
	//vrushali -- end
   //Abhishek kumar for varifying tabs availability
	public boolean verifyLeftTabLink(String leftTabLink) throws Exception{
		boolean flag=false;

		String lefttaboption=leftTabLink.toLowerCase().trim();
		if(lefttaboption.contains("cliniclocationslink")) {
			flag=isDisplayedWithReport(ClinicLocations_link_OR, ClinicLocations_link_S);
			return flag;
		}
		else if(lefttaboption.contains("clinicprofilepagelink")) {
			flag=isDisplayedWithReport(clinicProfileLink_OR, clinicProfileLink_S);
			return flag;
		}
		else if(lefttaboption.contains("clinicuserlink")) {
			flag=isDisplayedWithReport(clinicUser_OR, clinicUser_S);
			return flag;
		}
		else if(lefttaboption.contains("schedulingandmessaginglinkinleftnav")) {
			flag=isDisplayedWithReport(schedMessagingLink_OR, schedMessagingLink_S);
			return flag;
		}
		else if(lefttaboption.contains("clinichoursholidays")) {
			flag=isDisplayedWithReport(clinicHoursHoliday_OR, clinicHoursHoliday_S);
			return flag;
		}
		else if(lefttaboption.contains("directalertssettings")) {
			flag=isDisplayedWithReport(directAlertSettings_CRTP_OR, directAlertSettings_CRTP_S);
			return flag;
		}
		else if(lefttaboption.contains("clinicsettinglink")) {
			flag=isDisplayedWithReport(clinicSettings_OR, clinicSetting_S);
			return flag;
		}


		return flag;


	}
	
	
	public void clinicUserPage() throws Exception{
		loadingWithoutReport();
		presenceOfElementLocatedWithReport(clinicUser_OR, clinicUser_S);
		clickOnElementUsingJs(clinicUser_OR, clinicUser_S);
		//loadingWithoutReport();
		//loadingWithoutReport();
		
	}

	public void clickCardiacMonitorLink() throws InterruptedException 
	{
		presenceOfElementLocated(cardiacMonitorLink_OR);
		waitForLoading();
		extentReport.reportScreenShot("Clicking on Cardiac Monitor Link");
		clickElement(cardiacMonitorLink_OR);
	}

	public  void navigateToClinicLocationsPage() throws Exception
	{ 
		loadingWithoutReport();
		clickElement(ClinicLocations_link_OR, ClinicLocations_link_S);
		loadingWithoutReport();
	}

	//poojitha 
	public void navigateToSchedMessagingPage() throws InterruptedException
	{
	waitForLoading();
	presenceOfElementLocatedWithoutReport(schedMessagingLink_OR,schedMessagingLink_S);
	clickElement(schedMessagingLink_OR,schedMessagingLink_S); 
	}

	// ends here

	public void clickClinicHoursAndHolidaysLink() throws InterruptedException {
		loadingWithoutReport();
		clickElement(clinicHoursHoliday_OR, clinicHoursHoliday_S);
		loadingWithoutReport();
	}
	
	public void clickDirectAlertsICD_CRTD_MerlinHomeLink(){
		loadingWithoutReport();
		clickElement(directAlertSettings_ICDCRTD_MerlinHome_OR, directAlertSettings_ICDCRTD_MerlinHome_S);
		loadingWithoutReport();
	}
	
	public void clickDirectAlertsICD_CRTD_MobileAppLink(){
		loadingWithoutReport();
		clickElement(directAlertSettings_ICDCRTD_MobileApp_OR, directAlertSettings_ICDCRTD_MobileApp_S);
		loadingWithoutReport();
	}
	
	
	public boolean verifyCardiacMonitorlink() {
		Boolean isCardiacMonitorlink=false;
		if(visibilityOfElementLocated(CardiacMonitor_OR)) {
			isCardiacMonitorlink=true;
			extentReport.reportScreenShot("CardiacMonitorpage is visible");
		}
		else {

			extentReport.reportScreenShot("CardiacMonitorpage is not visible");
		}
		return isCardiacMonitorlink;
	}

	public void clickReportSettingsLink() throws InterruptedException
	{
		loadingWithoutReport();
		clickElement(reportSettingsLink_OR, reportSettingsLink_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on Report Settings Link");
	}

	public void navigateExportSettingsPage() throws InterruptedException
	{
		loadingWithoutReport();
		presenceOfElementLocatedWithReport(exportSettingsLink_OR ,exportSettingsLink_S);
		clickElement(exportSettingsLink_OR ,exportSettingsLink_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on  Export Options page");
		loadingWithoutReport();
	}

	public void clickMerlinHomeTransmitterLink() throws InterruptedException
	{
		presenceOfElementLocated(merlinHomeTransmitterLink_OR);
		waitForLoading();
		extentReport.reportScreenShot("Clicking Merlin Home Transmitter Link");
		clickElement(merlinHomeTransmitterLink_OR);

	}

	public void clickSchedMessagingLink() throws InterruptedException
	{
		scrollToView(schedMessagingLink_OR);
		loadingWithoutReport();
		clickElement(schedMessagingLink_OR, schedMessagingLink_S);
		try {
			loadingWithoutReport();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	/*
	 * created by Salin Gambhir
	 * 
	 */
	private final By hoursAndHolidaysLink_OR = By.xpath("//div[@id=\"app-container\"]/app-clinic-admin-layout-cmp/div/app-clinic-admin-sidebar-cmp/div/div[3]/ul/li[3]/a");
    private final String hoursAndHolidays_S = "Hours and Holidays page Link in Left Nav";
  
	
    public void clickHoursAndHolidayLink() throws InterruptedException
	{
		presenceOfElementLocated(hoursAndHolidaysLink_OR);
		waitForLoading();
		//extentReport.reportScreenShot("Clicking Hour and Holiday Link");
		clickElement(hoursAndHolidaysLink_OR);
		
	}
    
    public void clickClinicUserLink() throws InterruptedException
	{
    	waitForLoading();
    	presenceOfElementLocated(clinicUser_OR);
		//extentReport.reportScreenShot("Clicking Hour and Holiday Link");
		clickOnElementUsingJs(clinicUser_OR);
		
	}
	// Each page class should have this overridden method of Verify Landing page


	//Kundan
	public void navigateToCardiacMonitorLink() throws InterruptedException
	{

		presenceOfElementLocated(CardiacMonitor_OR);
		waitForPageLoad();
		clickElement(CardiacMonitor_OR);
		//waitForLoading();
		//extentReport.reportScreenShot("Clicking Report Settings Link");

	}


	public void verifyCardiacMoitorTabIsPresent() 
	{
		Boolean cardiactab=isElementNotPresentWithReport(CardiacMonitor_OR, CardiacMonitor_S);
		System.out.println("Cardiac tab is present "+cardiactab);
		
	}
	
	//Ends here

	// Each page class should have this overridden method of Verify Landing page
	//Poojitha - Updated Override method as per new standards - Date: 28th Dec 2021
	@Override
	public boolean verifyLandingPage() {
		Boolean clinicAdminPageCheck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR,pageLoading_S);
		if(isElementPresentwithoutException(clinicUser_OR,clinicUser_S)) {
			clinicAdminPageCheck=true;
		}
		return clinicAdminPageCheck;
	}







	public boolean verifyMerlinHomeTransmitterTab() {
		Boolean isMerlinHomepresent=false;
		if(visibilityOfElementLocated(MerlinHome_OR)) {
			isMerlinHomepresent=true;
			extentReport.reportScreenShot("Merlin Home Transmitter is displayed");
		}
		else {
			extentReport.reportScreenShot("Merlin Home Transmitter is not displayed");
		}
		return isMerlinHomepresent;
	}




	public void clickMobileAppTransmitterLink() throws InterruptedException
	{
		presenceOfElementLocated(mobileAppTransmitter_CRTP_OR);
		waitForLoading();
		extentReport.reportScreenShot("Clicking Mobile App Transmitter Link");
		clickElement(mobileAppTransmitter_CRTP_OR);
	}



	public boolean verifyMobileAppTransmitterTab() {
		Boolean isMobileAppTransmitterpresent=false;
		if(visibilityOfElementLocated(mobileAppTransmitter_CRTP_OR)) {
			isMobileAppTransmitterpresent=true;
			extentReport.reportScreenShot("Mobile App Transmitter is displayed");
		}
		else {
			extentReport.reportScreenShot("Mobile App Transmitter is not displayed");
		}
		return isMobileAppTransmitterpresent;
	}



	public void navigatePacemaker_CRTPLink() throws InterruptedException
	{
		waitForPageLoadingWithReport();// Added by ChandraMohan.S
		waitForElementToBeClickable(pacemaker_CRTP_OR,pacemaker_CRTP_S);
		//clickElement(pacemaker_CRTP_OR, pacemaker_CRTP_S);
		clickOnElementUsingJs(pacemaker_CRTP_OR);// Replaced above Normal click to Java script ... to achieve consistency- ChandraMohan.S
		waitForLoading();
		waitForLoading();
		waitForLoading();
		waitForLoading();
	}

	public void clickCardiacMonitor_Link() throws InterruptedException
	{
		loadingWithoutReport();
		clickElement(CardiacMonitor_OR, CardiacMonitor_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on Cardiac Monitor Link");
	}
	
	public  void navigateToMerlinAtHomeTransmitterPage() throws Exception
	{ 
		clickElement(MerlinHome_OR, MerlinHome_S);
	}
	
	public  void navigateToSchedulingMessagingPage() throws Exception
	{ 
		clickElement(schedMessagingLink_OR, schedMessagingLink_S);
	}

	public  void navigateToMobileAppTransmitterPage() throws Exception
	{ 
		clickElement(mobileAppTransmitter_CRTP_OR, MobilAppTransmitter_S);
	}


	public boolean verifypacemaker_CRTPTab() {


		Boolean isPacemakerCRTPpresent=false;
		if(visibilityOfElementLocated(pacemaker_CRTP_OR)) {
			isPacemakerCRTPpresent=true;
			extentReport.reportScreenShot("Pacemaker CRTP is displayed");
		}
		else {
			extentReport.reportScreenShot("Pacemaker CRTP is not displayed");
		}
		return isPacemakerCRTPpresent;
	}


	//created by bhupi
	public void verifypacemaker_CRTPTab_new() {
		presenceOfElementLocatedWithReport(pacemaker_CRTP_OR,pacemaker_CRTP_S);
	}



	public boolean verifyDirectAlertTab() {
		Boolean isDirectAlertTabpresent=false;
		if(visibilityOfElementLocated(directAlertSettings_CRTP_OR)) {
			isDirectAlertTabpresent=true;
			extentReport.reportScreenShot("Direct Alert is displayed");
		}
		else {
			extentReport.reportScreenShot("Direct Alert is not displayed");
		}
		return isDirectAlertTabpresent;
	}


	//create by bhupi
	public void verifyDirectAlertTab_new()
	{ 
		presenceOfElementLocatedWithReport(directAlertSettings_CRTP_OR,directAlertSettings_CRTP_S);
	}

	public void verifyDirectAlertsICD_CRTDLink() {
		presenceOfElementLocatedWithReport(directAlertSettings_ICDCRTD_OR, directAlertSettings_ICDCRTD_S);
	}

	public void verifypacemaker_CRTPLink() {
		presenceOfElementLocatedWithReport(pacemaker_CRTP_OR, pacemaker_CRTP_S);
	}

	public void verifyCardiacMonitorLink() {
		presenceOfElementLocatedWithReport(cardiacMonitorLink_OR, cardiacMonitorLink_S);
	}	

	public void clickpacemaker_CRTPLink() throws InterruptedException
	{
		loadingWithoutReport();
		clickElement(pacemaker_CRTP_OR, pacemaker_CRTP_S);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked on Pacemaker CRTP Link");

	}
	
	public void clickClinicalCommentsLink() throws InterruptedException
	{
		loadingWithoutReport();
		clickElement(clinicalComments_OR, clinicalComments_S);
		loadingWithoutReport();

	}
	
	public  void navigateToMerlinHomeTransmitterPage() throws Exception
	{ 
		loadingWithoutReport();
		clickElement(MerlinHome_OR, MerlinHome_S);
		loadingWithoutReport();
	}

	//Poojitha
		public void navigateToReportSettingsPage() throws InterruptedException
		{
			clickElement(reportSettingsLink_OR, reportSettingsLink_S);
			}
		//Ends here

	
		//snehal
		  public boolean verifyCardiacMonitorLinkNotPresent() {
			  Boolean flag = false;			  
			  if(isElementNotPresentWithReport(cardiacMonitorLink_OR, cardiacMonitorLink_S)) {
				  flag = true;
				  extentReport.reportScreenShot("Cardiac Monitor link not present");		  
			  }
			  return flag;
		  }
	 
	  }