package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;


public class CA_ClinicHoursAndHolidays extends BasePage{
	
	//Below three references needs to be there and webelements as per pages
    public WebDriver driver;
    public ExtentReport extentReport;
    public static Log logger = new Log();
    ExtentTest extentTest, child1;
    
    public final By lblClinicalHoursAndHoliday = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-hours-holidays']");
    public final By clinicHourAndHolidayHeader = By.xpath("");
    public final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");
    public final By textClinicHoursHolidays_OR = By.xpath("//div[contains(text(),'Clinic hours / holidays')]");
    private final String textClinicHoursHolidays_S = "Clinic Hours and Holidays Link";
    public final By textMonday = By.xpath("//th[contains(text(), 'Monday')]");
    public final By inputMondayOpenTime = By.xpath("//merlin-textbox[@controlname='mondayOpenTime']//input");
	public final By inputMondayOpenAMPM = By.xpath("//mat-select[@formcontrolname='mondayOpenAMPM']");
	public final By inputMondayCloseTime = By.xpath("//merlin-textbox[@controlname='mondayCloseTime']//input");
	public final By inputMondayCloseAMPM = By.xpath("//mat-select[@formcontrolname='mondayCloseAMPM']");
	public final By textTuesday = By.xpath("//th[contains(text(), 'Tuesday')]");
	public final By textWednesday = By.xpath("//th[contains(text(), 'Wednesday')]");
	public final By textThursday = By.xpath("//th[contains(text(), 'Thursday')]");
	public final By textFriday = By.xpath("//th[contains(text(), 'Friday')]");
	public final By textSaturday = By.xpath("//th[contains(text(), 'Saturday')]");
	public final By textSunday = By.xpath("//th[contains(text(), 'Sunday')]");
	public final By inputTuesdayOpenTime = By.xpath("//merlin-textbox[@controlname='tuesdayOpenTime']//input");
	public final By inputTuesdayOpenAMPM = By.xpath("//mat-select[@formcontrolname='tuesdayOpenAMPM']");
	public final By inputTuesdayCloseTime = By.xpath("//merlin-textbox[@controlname='tuesdayCloseTime']//input");
	public final By inputTuesdayCloseAMPM = By.xpath("//mat-select[@formcontrolname='tuesdayCloseAMPM']");
	public final By inputWednesdayOpenTime = By.xpath("//merlin-textbox[@controlname='wednesdayOpenTime']//input");
	public final By inputWednesdayOpenAMPM = By.xpath("//mat-select[@formcontrolname='wednesdayOpenAMPM']");
	public final By inputWednesdayCloseTime = By.xpath("//merlin-textbox[@controlname='wednesdayCloseTime']//input");
	public final By inputWednesdayCloseAMPM = By.xpath("//mat-select[@formcontrolname='wednesdayCloseAMPM']");
	public final By inputThursdayOpenTime = By.xpath("//merlin-textbox[@controlname='thursdayOpenTime']//input");
	public final By inputThursdayOpenAMPM = By.xpath("//mat-select[@formcontrolname='thrusdayOpenAMPM']");
	public final By inputThursdayCloseTime = By.xpath("//merlin-textbox[@controlname='thursdayCloseTime']//input");
	public final By inputThursdayCloseAMPM = By.xpath("//mat-select[@formcontrolname='thrusdayCloseAMPM']");
	public final By inputFridayOpenTime = By.xpath("//merlin-textbox[@controlname='fridayOpenTime']//input");
	public final By inputFridayOpenAMPM = By.xpath("//mat-select[@formcontrolname='fridayOpenAMPM']");
	public final By inputFridayCloseTime = By.xpath("//merlin-textbox[@controlname='fridayCloseTime']//input");
	public final By inputFridayCloseAMPM = By.xpath("//mat-select[@formcontrolname='fridayCloseAMPM']");
	public final By inputSaturdayOpenTime = By.xpath("//merlin-textbox[@controlname='saturdayOpenTime']//input");
	public final By inputSaturdayOpenAMPM = By.xpath("//mat-select[@formcontrolname='saturdayOpenAMPM']");
	public final By inputSaturdayCloseTime = By.xpath("//merlin-textbox[@controlname='saturdayCloseTime']//input");
	public final By inputSaturdayCloseAMPM = By.xpath("//mat-select[@formcontrolname='saturdayCloseAMPM']");
	public final By inputSundayOpenTime = By.xpath("//merlin-textbox[@controlname='sundayOpenTime']//input");
	public final By inputSundayOpenAMPM = By.xpath("//mat-select[@formcontrolname='sundayOpenAMPM']");
	public final By inputSundayCloseTime = By.xpath("//merlin-textbox[@controlname='sundayCloseTime']//input");
	public final By inputSundayCloseAMPM = By.xpath("//mat-select[@formcontrolname='sundayCloseAMPM']");
	public final By textHolidays = By.xpath("//h3[contains(text(), 'Holidays')]");
	public final By textHolidayName = By.xpath("//b[contains(text(), 'Holiday name')]");
	public final By textOutOfOffice = By.xpath("//b[contains(text(), 'Out of Office')]");
	public final By textBackInOffice = By.xpath("//b[contains(text(), 'Back in Office')]");
    public final By editButton = By.xpath("//span[contains(text(),' Edit ')]/..");
	public final By saveButton = By.xpath("//span[contains(text(),' Save')]/..");
	public final By cancelButton = By.xpath("//span[contains(text(),' Cancel')]/..");

	public CA_ClinicHoursAndHolidays(WebDriver driver, ExtentReport extentReport) {
        super(driver, extentReport);
        this.extentReport = extentReport;
        this.driver = driver;
    }
	
	public String checkPageInViewMode() {
		String pageViewMode = "";

		if (isEnabled(editButton)) {
			pageViewMode = "Page is in view mode";
			extentReport.reportScreenShot("Page is in view mode");
		} else {
			pageViewMode = "Page is NOT in view mode";
			extentReport.reportScreenShot("Page is NOT in view mode");
		}

		return pageViewMode;
	}

	public boolean elementVisibleOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			/*
			 * if (!verifyLandingPage()) { extentReport.reportFail(reportFailMsg); return
			 * false; }
			 */
			
			invisibilityOfElementLocated(pageLoading);
			waitForPageLoad();
			
			if (visibilityOfElementLocated(element)) {
				extentReport.reportPass(reportPassMsg);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		extentReport.reportFail(reportFailMsg);
		return false;
	}
	
	
	@Override
	public boolean verifyLandingPage() {
		Boolean clinicHourAndHolidayPageCheck = false;
		if(isElementPresentwithoutException(textClinicHoursHolidays_OR, textClinicHoursHolidays_S)) {
			clinicHourAndHolidayPageCheck=true;
			extentReport.reportScreenShot("Clinic Hours and holidays page is displayed");
		}
		return clinicHourAndHolidayPageCheck;
	}
	

	public Boolean verifyClinicHours(String weekday, String startTime, String closeTime) {
		// TODO Auto-generated method stub
		
			
		
		boolean checkClinicHourforWeek = false;
		boolean defaultTimeCheck = false;
		boolean checkWeekOpenCloseExists = false;
		try {
			
		switch(weekday) {
		case "Monday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textMonday, inputMondayOpenTime, inputMondayCloseTime);
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputMondayOpenTime)), (getText(inputMondayOpenAMPM)), getText(inputMondayCloseTime), getText(inputMondayCloseAMPM),startTime, closeTime);	
			break;
		case "Tuesday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textTuesday, inputTuesdayOpenTime, inputTuesdayCloseTime);	
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputTuesdayOpenTime)), (getText(inputTuesdayOpenAMPM)), getText(inputTuesdayCloseTime), getText(inputTuesdayCloseAMPM),startTime, closeTime);
			break;
		case "Wednesday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textWednesday, inputWednesdayOpenTime, inputWednesdayCloseTime);
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputWednesdayOpenTime)), (getText(inputWednesdayOpenAMPM)), getText(inputWednesdayCloseTime), getText(inputWednesdayCloseAMPM),startTime, closeTime);
			break;
		case "Thursday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textThursday, inputThursdayOpenTime, inputThursdayCloseTime);
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputThursdayOpenTime)), (getText(inputThursdayOpenAMPM)), getText(inputThursdayCloseTime), getText(inputThursdayCloseAMPM),startTime, closeTime);
			break;
		case "Friday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textFriday, inputFridayOpenTime, inputFridayCloseTime);
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputFridayOpenTime)), (getText(inputFridayOpenAMPM)), getText(inputFridayCloseTime), getText(inputFridayCloseAMPM),startTime, closeTime);
			break;
		case "Saturday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textSaturday, inputSaturdayOpenTime, inputSaturdayCloseTime);
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputSaturdayOpenTime)), (getText(inputSaturdayOpenAMPM)), getText(inputSaturdayCloseTime), getText(inputSaturdayCloseAMPM),startTime, closeTime);
			break;
		case "Sunday":
			checkWeekOpenCloseExists = calculateDataForWeekDay(weekday, textSunday, inputSundayOpenTime, inputSundayCloseTime);
			defaultTimeCheck = calculateDefaultTimings(weekday, (getText(inputSundayOpenTime)), (getText(inputSundayOpenAMPM)), getText(inputSundayCloseTime), getText(inputSundayCloseAMPM),startTime, closeTime);
			break;
		}
		if (checkWeekOpenCloseExists && defaultTimeCheck){
			checkClinicHourforWeek = true;
		}
		else {
			checkClinicHourforWeek = false;
		}
		
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return checkClinicHourforWeek;
	}
	private boolean calculateDefaultTimings(String weekday, String actualOpenTime, String actualOpenTimeAMPM, String actualCloseTime, String actualCloseTimeAMPM, String expectedStartTime, String expectedCloseTime) {
		
		// TODO Auto-generated method stub
		String actualTimeOpen = actualOpenTime + " " + actualOpenTimeAMPM;
		String actualTimeClose = actualCloseTime + " " + actualCloseTimeAMPM; 
		try {
			
		
		if (actualTimeOpen.equals(expectedStartTime) && actualTimeClose.equals(expectedCloseTime)) {
			extentReport.reportPass(weekday + "Start Time and Close Time for Clinic matches expected time.");
			return true;
		}	 
		else
		{
			extentReport.reportFail(weekday + "Start Time and Close Time for Clinic doesn't match expected time.");
			return false;
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
			
	}

	public boolean calculateDataForWeekDay(String weekday, By textWeek, By weekOpenTime, By weekCloseTime) {
		boolean validateValue = false;
		if (weekday.equals(getText(textWeek))&&visibilityOfElementLocated(textWeek) && visibilityOfElementLocated(weekOpenTime) &&  visibilityOfElementLocated(weekCloseTime))
		{
			extentReport.reportPass(weekday + "has all label present");
			validateValue = true;
		}
		else
		{
			extentReport.reportFail(weekday + "has some missing fields");
			validateValue = false;
		}
		
		return validateValue;
		
	}
	
	public Boolean verifyHoliday(String expectedHolidayName, String expectedOutOfOffice, String expectedBackInOffice) {
		
		try{
			String actualHolidayName = getText(textHolidayName);
		
		String actualBackInOffice = getText(textBackInOffice);
		String actualOutOfOffice = getText(textOutOfOffice);
		if (expectedHolidayName.equalsIgnoreCase(actualHolidayName) && expectedOutOfOffice.equalsIgnoreCase(actualOutOfOffice) && expectedBackInOffice.equalsIgnoreCase(actualBackInOffice)) {
			extentReport.reportPass("All Labels exist on page");
			return true;	
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		extentReport.reportFail("Some Missings labels on page");
		return false;
		
	}

	public boolean verifyDefaultHolidays(List<String> defaultHolidays) {
		// TODO Auto-generated method stub
		boolean checkDefaultHolidays = false;
		List<WebElement> actualHolidaysList = null;
		int sizeOfList=0;
		List<String> actualHolidays = null;
		try {
			
			actualHolidaysList = findElementslist(holidayName_OR, holidayName_S);
			sizeOfList = getSizeOfElements(holidayName_OR, holidayName_S);
			boolean checkListData = false;
			if (sizeOfList == 0) {
				extentReport.reportFail("Holiday list is Empty");	
			}
			else
			{
				extentReport.reportInfo("Holiday list is not empty");
				Iterator<WebElement> itr = actualHolidaysList.iterator();
				while (itr.hasNext())
				{
					actualHolidays.add(itr.next().getText());
				}
				
				Collections.sort(defaultHolidays);
				Collections.sort(actualHolidays);
				
				checkListData = actualHolidays.equals(defaultHolidays);
				if (checkListData)
				{
					extentReport.reportPass("Holidays are in choronological Order");
					checkDefaultHolidays = true;
				
				}
				else
					extentReport.reportFail("Holidays are not in choronological Order");	
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
	
		return checkDefaultHolidays;
	}

	private final By holidayName_OR = By.xpath("//input[@id='cliniCodeDesc']");
	private final String holidayName_S = "Holidays List";
	
	@SuppressWarnings("null")
	public boolean verifyHolidayInChronologicalOrder(List<String> defaultHolidays) {
		// TODO Auto-generated method stub
		boolean checkHolidayChronogicalOrder = false;
		List<WebElement> actualHolidaysList = null;
		int sizeOfList=0;
		List<String> actualHolidays = null;
		try {
			
			actualHolidaysList = findElementslist(holidayName_OR, holidayName_S);
			sizeOfList = getSizeOfElements(holidayName_OR, holidayName_S);
			boolean checkListData = false;
			if (sizeOfList == 0) {
				extentReport.reportFail("Holiday list is Empty");	
			}
			else
			{
				extentReport.reportInfo("Holiday list is not empty");
				Iterator<WebElement> itr = actualHolidaysList.iterator();
				while (itr.hasNext())
				{
					actualHolidays.add(itr.next().getText());
				}
				
				checkListData = actualHolidays.equals(defaultHolidays);
				if (checkListData)
				{
					extentReport.reportPass("Holidays are in choronological Order");
					checkHolidayChronogicalOrder = true;
				
				}
				else
					extentReport.reportFail("Holidays are not in choronological Order");	
			}	
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return checkHolidayChronogicalOrder;
	}


	
	

}
