
package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import static com.test.qa.utilities.CommonUtils.*;


public class CA_ClinicSettings_ExportOptions extends BasePage {

	//Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;


	//Author - Bhupendra
	private final By exportOptions_PageHeader_OR = By.xpath("//div[@class='main-panel main-content']//header[div[text()='Export Options']]");
	private final String exportOptions_PageHeader_S= "Export Options Header";

	private final By setUpexprtEHRChlBx_OR = By.xpath("//input[@id='exportSession-input']");
	private final String setUpexprtEHRChlBx_S ="Setup Export to EHR check box";

	private final By enblAutEprtToEHR_OR = By.xpath("//input[@id='ehrReceipt-input']");
	private final String enblAutEprtToEHR_S = "Enable Automatic Update To EHR check box";

	private final By incCmntInEprt_OR = By.xpath("//input[@id='includeCommentsInExport-input']");
	private final String incCmntInEprt_S = "Include Comment In Export check box";

	private final By setupExprtToPcChkBx_OR = By.xpath("//input[@id='setupPCData-input']");
	private final String setupExprtToPcChkBx_S = "Setup Export To Pc check box";

	private final By setupExprtOfTransData_OR = By.xpath("//input[@id='setUpDownload-input']");
	private final String setupExprtOfTransData_S = "Setup Export of Transmission data check box";

	//private final By ipInputBox_OR = By.xpath("//input[@id='merlin_textbox_downloadIP']");
	//xpath change edited by bhupendra
	private final By ipInputBox_OR = By.xpath("//input[@id='ip_downloadIP']");
	private final String ipInputBox_S = "Ip Input Box";

	//xpath change edited by bhupendra
	//private final By portInputBox_OR = By.xpath("//input[@id='merlin_textbox_downloadPort']");
	private final By portInputBox_OR = By.xpath("//input[@id='port_downloadPort']");
	private final String portInputBox_S = "Port Input Box";

	//xpath change edited by bhupendra
	//private final By ehrAppNameInputBox_OR = By.xpath("//input[@id='merlin_textbox_appName']");
	private final By ehrAppNameInputBox_OR = By.xpath("//input[@id='applicationName_appName']");
	private final String ehrAppNameInputBox_S = "EHR App Name input Box";

	//xpath change edited by bhupendra
	//private final By ehrFacilityNameInputBox_OR = By.xpath("//input[@id='merlin_textbox_facilityName']");
	private final By ehrFacilityNameInputBox_OR = By.xpath("//input[@id='facName_facilityName']");
	private final String ehrFacilityNameInputBox_S = "EHR Facility Name Input Box";

	//xpath change edited by bhupendra
	//private final By msgFormatDrpDwn_OR = By.xpath("//mat-select[@id='messageFormat']//span/span");
	private final By msgFormatDrpDwn_OR = By.xpath("//mat-select[@id='messageFormat']//span");
	private final String msgFormatDrpDwn_S = "Message Format select dropdown";

	//xpath change edited by bhupendra
	//private final By chrEncdingSlctDrpDwn_OR = By.xpath("//mat-select[@id='exportEMR']//span/span");
	private final By chrEncdingSlctDrpDwn_OR = By.xpath("//mat-select[@id='exportEMR']//span");
	private final String chrEncdingSlctDrpDwn_S = "Character Encoding select dropdown";

	//enblAutEprtToEHR_OR,incCmntInEprt_OR, ipInputBox_OR,  portInputBox_OR, ehrAppNameInputBox_OR, ehrFacilityNameInputBox_OR

	private final By editButton_OR = By.xpath("//div[@class='action-buttons']/button/span");
	private final String editButton_S = "Edit Button Pacemaker Page";

	private final By cancelButton_OR = By.xpath("(//div[@class='action-buttons']/button/span)[1]");
	private final String  cancelButton_S = "Cancel Button Pacemaker Page";

	private final By saveButton_OR = By.xpath("(//div[@class='action-buttons']/button/span)[2]");
	private final String  saveButton_S = "Save Button Pacemaker Page";

	private final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");



	public static Log logger = new Log();

	public CA_ClinicSettings_ExportOptions(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	//Verify Functions
	//created by bhupi 
	public void verifyEditButton() {
		scrollToViewWithReport(editButton_OR,editButton_S);				
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(editButton_OR,editButton_S), "Edit button is displayed.");
		extentReport.reportScreenShot("Edit button is displayed.");	
	}

	public void verifyCancelButton() {
		scrollToViewWithReport(cancelButton_OR,cancelButton_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(cancelButton_OR,cancelButton_S), "Cancel button is displayed.");
		extentReport.reportScreenShot("Cancel button is displayed.");	
	}


	public void verifySaveButton() {
		scrollToViewWithReport(saveButton_OR,saveButton_S);		
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(saveButton_OR,saveButton_S), "Save button is displayed.");
		extentReport.reportScreenShot("Save button is displayed.");
	}

	public void verifySetUpEprtToEhrChkBx() {
		scrollToViewWithReport(setUpexprtEHRChlBx_OR,setUpexprtEHRChlBx_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithReport(setUpexprtEHRChlBx_OR,setUpexprtEHRChlBx_S), "Setup Export to Ehr checkbox is displayed.");
		extentReport.reportScreenShot("Setup Export to Ehr checkbox is displayed.");
	}

	public void verifyEnablAutoExprToEHRChkBx() {
		scrollToViewWithReport(enblAutEprtToEHR_OR,enblAutEprtToEHR_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithReport(enblAutEprtToEHR_OR,enblAutEprtToEHR_S), "Enable auto export to EHR  is displayed.");
		extentReport.reportScreenShot("Enable auto export to EHr is displayed.");	
	}
	public void verifyInclCmntInExprtRprtChkBx() {
		scrollToViewWithReport(incCmntInEprt_OR,incCmntInEprt_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithReport(incCmntInEprt_OR,incCmntInEprt_S), "Preference to include clinical comments is displayed.");
		extentReport.reportScreenShot("Preference to include clinical comments is displayed.");	
	}

	public void verifyIpInputBx() {
		scrollToViewWithReport(ipInputBox_OR,ipInputBox_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(ipInputBox_OR,ipInputBox_S), "Ip Input box is displayed.");
		extentReport.reportScreenShot("Ip input box is displayed.");	
	}
	public void verifyPortInputBx() {
		scrollToViewWithReport(portInputBox_OR,portInputBox_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(portInputBox_OR,portInputBox_S), "Portal Input box is displayed.");
		extentReport.reportScreenShot("Portal input box is displayed.");
	}
	public void verifyEHRAppNameInputBx() {
		scrollToViewWithReport(ehrAppNameInputBox_OR,ehrAppNameInputBox_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(ehrAppNameInputBox_OR,ehrAppNameInputBox_S), "EHR App Name Input box is displayed.");
		extentReport.reportScreenShot("EHR App Name Input box is displayed.");
	}
	public void verifyEHRFacilityNameInputBx() {
		scrollToViewWithReport(ehrFacilityNameInputBox_OR,ehrFacilityNameInputBox_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(ehrFacilityNameInputBox_OR,ehrFacilityNameInputBox_S), "EHR Facility Name Input box is displayed.");
		extentReport.reportScreenShot("EHR Facility Name Input box is displayed.");
	}

	public void verifyMsgFormtDrpDwn() {
		scrollToViewWithReport(msgFormatDrpDwn_OR,msgFormatDrpDwn_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithoutReport(msgFormatDrpDwn_OR,msgFormatDrpDwn_S), "Message Format Field is displayed.");
		extentReport.reportScreenShot("Message Format Field is displayed.");
	}

	public void verifyChrEncodingFormatDrpDwn() {
		scrollToViewWithReport(chrEncdingSlctDrpDwn_OR,chrEncdingSlctDrpDwn_S);
		assertion.assertEquals(true,visibilityOfElementLocatedWithReport(chrEncdingSlctDrpDwn_OR,chrEncdingSlctDrpDwn_S), "Charachter Encoding Format Field is displayed.");
		extentReport.reportScreenShot("Charachter Encoding Format Field is displayed.");
	}


	public boolean verifySetUpEprtToEhrChkBxIsEnable() {
		boolean flg= false;
		if(isSelectedWithReport(setUpexprtEHRChlBx_OR,setUpexprtEHRChlBx_S) && isEnabledWithReport(setUpexprtEHRChlBx_OR,setUpexprtEHRChlBx_S))
			flg=true;
		return flg;

	}

	public boolean verifyIpInputBxIsEnable() {
		return isEnabledWithReport(setUpexprtEHRChlBx_OR,setUpexprtEHRChlBx_S);
	}

	public boolean verifyPortInputBxIsEnable() {
		return isEnabledWithReport(portInputBox_OR,portInputBox_S);
	}

	public boolean verifyEHRAppNameInputBxIsEnable() {
		return isEnabledWithReport(ehrAppNameInputBox_OR,ehrAppNameInputBox_S);
	}

	//Bhupendra
	public boolean verifyEHRFacilityNameInputBxIsEnable() {
		return isEnabledWithReport(ehrFacilityNameInputBox_OR,ehrFacilityNameInputBox_S);
	}

	//Bhupendra
	public void verifyEnablAutoExprToEHRChkBxIsDisable() {
		scrollToViewWebElementWithReport(driver.findElement(enblAutEprtToEHR_OR),enblAutEprtToEHR_S);
		if(!isSelectedWithoutReport(enblAutEprtToEHR_OR,enblAutEprtToEHR_S)) {			
			assertion.assertEquals(false,isSelectedWithoutReport(enblAutEprtToEHR_OR,enblAutEprtToEHR_S),"The default value for Auto Export to EHR is 'OFF'.") ;
			extentReport.reportScreenShot("The default value for Auto Export to EHR is 'OFF'.");	
		}else {
			extentReport.reportScreenShot("The default value for Auto Export to EHR is 'ON'.");	
		}
	}

	//Bhupendra
	public void verifySetupEcprtToPcChkBxIsDisable() {
		scrollToViewWebElementWithReport(driver.findElement(setupExprtToPcChkBx_OR),setupExprtToPcChkBx_S);
		if(!isSelectedWithoutReport(setupExprtToPcChkBx_OR,setupExprtToPcChkBx_S)) {			
			assertion.assertEquals(false,isSelectedWithoutReport(setupExprtToPcChkBx_OR,setupExprtToPcChkBx_S),"The default value for Setup Export to PC is 'OFF'.") ;
			extentReport.reportScreenShot("The default value for Setup Export to PC is 'OFF'.");	
		}else {
			extentReport.reportScreenShot("The default value for Setup Export to PC is 'ON'.");	
		}
	}

	//Bhupendra
	public void verifySetupExprtOfTrnsDataChkBxIsDisable() {
		scrollToViewWebElementWithReport(driver.findElement(setupExprtOfTransData_OR),setupExprtOfTransData_S);
		if(!isSelectedWithoutReport(setupExprtOfTransData_OR,setupExprtOfTransData_S)) {			
			assertion.assertEquals(false,isSelectedWithoutReport(setupExprtOfTransData_OR,setupExprtOfTransData_S),"The default value for Setup Export Of Transmission Data Files is 'OFF'.") ;
			extentReport.reportScreenShot("The default value for Setup Export Of Transmission Data Files is 'OFF'.");	
		}else {
			extentReport.reportScreenShot("The default value for Setup Export Of Transmission Data Files is 'ON'.");	
		}
		scrollToViewWebElementWithReport(driver.findElement(setupExprtOfTransData_OR),setupExprtOfTransData_S);
		
		//return isSelectedWithoutReport(setupExprtOfTransData_OR,setupExprtOfTransData_S);
	}

	/*
	 * Click functions
	 */

	public void validateEditButton() throws Exception {
		elementToBeClickable(editButton_OR,editButton_S );
		clickElement(editButton_OR,editButton_S );
	}

	public void validateCancelButton() throws Exception {
		elementToBeClickable(cancelButton_OR,cancelButton_S);
		clickElement(cancelButton_OR,cancelButton_S);
	}

	public void validateSaveButton() throws Exception {
		elementToBeClickable(saveButton_OR,saveButton_S);
		clickElement(saveButton_OR,saveButton_S);
	}


	//capture value of locaor functions
	public String captureChrEncodingDrpDwnValue() throws Exception {
		String ipBoxValue="";
		ipBoxValue = driver.findElement(chrEncdingSlctDrpDwn_OR).getText();
		//ipBoxValue = getAttributeWithoutReport(chrEncdingSlctDrpDwn_OR,chrEncdingSlctDrpDwn_S,"value");
		return ipBoxValue;
	}

	public void verifyExportOptionInputFields() throws Exception {
		extentReport.reportScreenShot("a) IP, b) Port,c) Character Encoding with value UTF-8,d) EHR Application name, e) EHR Facility name,f) Message payload format is displayed when setup export to EHR field is enabled for the clinic in the Export to EHRsection .");
		validateEditButton();
		verifySaveButton();
		verifyEnablAutoExprToEHRChkBx();
		assertion.assertEqualsWithReporting(true,verifySetUpEprtToEhrChkBxIsEnable(), extentReport, "setup export to EHR field is enabled for the clinic in the Export to EHRsection") ;			
		verifyIpInputBx();
		verifyPortInputBx();
		verifyChrEncodingFormatDrpDwn();
		verifyEHRAppNameInputBx();
		verifyEHRFacilityNameInputBx();	
		verifyMsgFormtDrpDwn();
		assertion.assertEqualsWithReporting(true,captureChrEncodingDrpDwnValue().equalsIgnoreCase("UTF8"), extentReport, "Character Encoding input box has value UTF-8") ;			

	}





	// Each page class should have this overridden method of Verify Landing page 
	@Override
	public boolean verifyLandingPage() {
		Boolean verifyPacemakerCRTPPage = false;

		if(isElementPresentwithoutException(exportOptions_PageHeader_OR,exportOptions_PageHeader_S)) {
			verifyPacemakerCRTPPage = true;
			extentReport.reportScreenShot("Export Options page is displayed");
		} else {
			extentReport.reportScreenShot("Export Options page is not displayed");
		}
		extentReport.reportScreenShot("Naviated to  Export Options page");
		return verifyPacemakerCRTPPage;
	}



}