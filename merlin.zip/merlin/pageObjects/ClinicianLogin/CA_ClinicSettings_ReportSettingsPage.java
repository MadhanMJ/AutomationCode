package com.test.qa.ui.pageObjects.ClinicianLogin;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;

import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import static com.test.qa.utilities.CommonUtils.*;

public class CA_ClinicSettings_ReportSettingsPage extends BasePage {

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public CA_ClinicSettings_ReportSettingsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By reportSettingsInfo_OR = By.xpath("//div[@id='reportPreferencesForm']//*[@class='info']");
	private final String reportSettingsInfo_S = "Report Settings Heading Text";

	private final By alwaysPrintSectionHeader_OR = By
			.xpath("(//div[@id='reportPreferencesForm']//*[@class='card']/h3[@class='merlin-header'])[1]");
	private final String alwaysPrintSectionHeader_S = "Always Print Section Heading Text";

	private final By editButton_OR = By.xpath("//div[@id=\"report-settings-wrapper\"]/div/div/div[2]/button");
	private final String editButton_S = "Edit Button";
	
	private final By saveButton_OR = By.xpath("//div[@id=\"report-settings-wrapper\"]/div/div/div[2]/button[2]");
	private final String saveButton_S = "Save Button";
	
	

//    	FOR A SESSION, ALWAYS PRINT elements
//SelectAll Checkbox
	private final By selectAll_checkbox_OR = By.xpath("//input[@id='selectAllCheck-input']");
	private final String selectAll_checkbox_S = "Select All Checkbox";

	private final By selectAll_label_OR = By.xpath("//mat-checkbox[@id='selectAllCheck']/label/span");
	private final String selectAll_label_S = "Select All Label";
	
// Summary section
	private final By summary_checkbox_OR = By.xpath("//input[@id='summaryCheck-input']");
	private final String summary_checkbox_S = "Summary Checkbox";

	private final By summary_label_OR = By.xpath("//mat-checkbox[@id='summaryCheck']/label/span");
	private final String summary_label_S = "Summary Label";

	private final By fastPathSummary_checkbox_OR = By.xpath("//input[@id='fastpathSummary-input']");
	private final String fastPathSummary_checkbox_S = "FastPath Summary Checkbox";

	private final By fastPathSummary_label_OR = By.xpath("//mat-checkbox[@id='fastpathSummary']/label/span");
	private final String fastPathSummary_label_S = "FastPath Summary Label";

	private final By episodesSummary_checkbox_OR = By.xpath("//input[@id='epiodeSummary-input']");
	private final String episodesSummary_checkbox_S = "Episode Summary Checkbox";

	private final By episodesSummary_label_OR = By.xpath("//mat-checkbox[@id='epiodeSummary']/label/span");
	private final String episodesSummary_label_S = "Episode Summary Label";

	private final By diagnosticsSummary_checkbox_OR = By.xpath("//input[@id='diagnosticSummary-input']");
	private final String diagnosticsSummary_checkbox_S = "Diagnostics Summary Checkbox";

	private final By diagnosticsSummary_label_OR = By.xpath("//mat-checkbox[@id='diagnosticSummary']/label/span");
	private final String diagnosticsSummary_label_S = "Diagnostics Summary Label";

	private final By patientInfoAndLeads_checkbox_OR = By.xpath("//input[@id='patientInfoLeads-input']");
	private final String patientInfoAndLeads_checkbox_S = "Patient Info and Leads Checkbox";

	private final By patientInfoAndLeads_label_OR = By.xpath("//mat-checkbox[@id='patientInfoLeads']/label/span");
	private final String patientInfoAndLeads_label_S = "Patient Info and Leads Label";

	private final By mriSummary_checkbox_OR = By.xpath("//input[@id='mriSummaryCheck-input']");
	private final String mriSummary_checkbox_S = "MRI Summary Checkbox";

	private final By mriSummary_label_OR = By.xpath("//mat-checkbox[@id='mriSummaryCheck']/label/span");
	private final String mriSummary_label_S = "MRI Summary Label";

// All Tests section
	private final By allTests_checkbox_OR = By
			.xpath("//div[@id='reportSettings']/div[2]/div/div[2]/mat-checkbox[1]/label/div/input");
	private final String allTests_checkbox_S = "All Tests Checkbox";

	private final By allTests_label_OR = By
			.xpath("//div[@id='reportSettings']/div[2]/div/div[2]/mat-checkbox[1]/label/span");
	private final String allTests_label_S = "All Tests Label";

	private final By rtmTrend_checkbox_OR = By.xpath("//input[@id='trmTrendCheck-input']");
	private final String rtmTrend_checkbox_S = "RTM Trend Checkbox";

	private final By rtmTrend_label_OR = By.xpath("//mat-checkbox[@id='trmTrendCheck']/label/span");
	private final String rtmTrend_label_S = "RTM Trend Label";

	private final By captureThreshold_checkbox_OR = By.xpath("//input[@id='captureThreshold-input']");
	private final String captureThreshold_checkbox_S = "Capture Threshold Checkbox";

	private final By captureThreshold_label_OR = By.xpath("//mat-checkbox[@id='captureThreshold']/label/span");
	private final String captureThreshold_label_S = "Capture Threshold Lable";

	private final By testResults_checkbox_OR = By.xpath("//input[@id='testResult-input']");
	private final String testResults_checkbox_S = "Test Results Checkbox";

	private final By testResults_label_OR = By.xpath("//mat-checkbox[@id='testResult']/label/span");
	private final String testResults_label_S = "Test Results Label";

	private final By crtToolkit_checkbox_OR = By.xpath("//input[@id='crtToolKitCheck-input']");
	private final String crtToolkit_checkbox_S = "CRT Toolkit Checkbox";

	private final By crtToolkit_label_OR = By.xpath("//mat-checkbox[@id='crtToolKitCheck']/label/span");
	private final String crtToolkit_label_S = "CRT Toolkit Label";

// All Alerts and Episodes
	private final By allAlertsAdnEpisodes_checkbox_OR = By.xpath("//input[@id='allEpisodesCheck-input']");
	private final String allAlertsAdnEpisodes_checkbox_S = "All Alerts and Episodes Checkbox";

	private final By allAlertsAdnEpisodes_label_OR = By.xpath("//mat-checkbox[@id='allEpisodesCheck']/label/span");
	private final String allAlertsAdnEpisodes_label_S = "All Alerts and Episodes Label";

	private final By alertSummary_checkbox_OR = By.xpath("//input[@id='alertSummaryCheck-input']");
	private final String alertSummary_checkbox_S = "Alert Summary Checkbox";

	private final By alertSummary_label_OR = By.xpath("//mat-checkbox[@id='alertSummaryCheck']/label/span");
	private final String alertSummary_label_S = "Alert Summary Label";

	private final By realTimeEGMs_checkbox_OR = By.xpath("//input[@id='realTimeEgm-input']");
	private final String realTimeEGMs_checkbox_S = "Real-Time EGMs Checkbox";

	private final By realTimeEGMs_label_OR = By.xpath("//mat-checkbox[@id='realTimeEgm']/label/span");
	private final String realTimeEGMs_label_S = "Real-Time EGMs Label";

	private final By extendedEpisodes_checkbox_OR = By.xpath("//input[@id='epioseExtended-input']");
	private final String extendedEpisodes_checkbox_S = "Extended Episodes Checkbox";

	private final By extendedEpisodes_label_OR = By.xpath("//mat-checkbox[@id='epioseExtended']/label/span");
	private final String extendedEpisodes_label_S = "Extended Episodes Label";

	// All Alerts and Episodes -> ICD/Pacemaker
	private final By vtVfEpisodes_checkbox_OR = By.xpath("//input[@id='vtvfLastEpsd-input']");
	private final String vtVfEpisodes_checkbox_S = "ICD/Pacemaker -> Last VT/VF Episodes Checkbox";

	private final By vtVfEpisodes_label_OR = By.xpath("//mat-select[@id='vtvfEpsdCd']/following-sibling::mat-label");
	private final String vtVfEpisodes_label_S = "ICD/Pacemaker -> Last VT/VF Episodes Label";

	private final By vtVfEpisodes_select_OR = By.xpath("//mat-select[@id='vtvfEpsdCd']");
	private final String vtVfEpisodes_select_S = "ICD/Pacemaker -> Last VT/VF Episodes Select";

	private final By svtEpisodes_checkbox_OR = By.xpath("//input[@id='svtLastEpsd-input']");
	private final String svtEpisodes_checkbox_S = "ICD/Pacemaker -> Last SVT Episodes Checkbox";

	private final By svtEpisodes_label_OR = By.xpath("//mat-select[@id='svtEpsdCd']/following-sibling::mat-label");
	private final String svtEpisodes_label_S = "ICD/Pacemaker -> Last SVT Episodes Label";

	private final By svtEpisodes_select_OR = By.xpath("//mat-select[@id='svtEpsdCd']");
	private final String svtEpisodes_select_S = "ICD/Pacemaker -> Last SVT Episodes Select";

	private final By atAfEpisodes_checkbox_OR = By.xpath("//input[@id='atafLastEpsd-input']");
	private final String atAfEpisodes_checkbox_S = "ICD/Pacemaker -> Last AT/AF Episodes Checkbox";

	private final By atAfEpisodes_label_OR = By.xpath("//mat-select[@id='atafEpsdCd']/following-sibling::mat-label");
	private final String atAfEpisodes_label_S = "ICD/Pacemaker -> Last AT/AF Episodes Label";

	private final By atAfEpisodes_select_OR = By.xpath("//mat-select[@id='atafEpsdCd']");
	private final String atAfEpisodes_select_S = "ICD/Pacemaker -> Last AT/AF Episodes Select";

//Non sustained events episodes xpath have to be updated after defect fix
	private final By nonSustainedEvents_checkbox_OR = By
			.xpath("//div[@id='reportSettings']/div[2]/div[2]/div/div/div[5]/mat-checkbox[1]");
	private final String nonSustainedEvents_checkbox_S = "ICD/Pacemaker -> Last Non-sustained Episodes Checkbox";

	private final By nonSustainedEvents_label_OR = By
			.xpath("//div[@id=\"reportSettings\"]/div[2]/div[2]/div/div/div[5]/mat-label");
	private final String nonSustainedEvents_label_S = "ICD/Pacemaker -> Last Non-sustained Episodes Label";

	private final By nonSustainedEvents_select_OR = By
			.xpath("//div[@id=\"reportSettings\"]/div[2]/div[2]/div/div/div[5]/mat-select");
	private final String nonSustainedEvents_select_S = "ICD/Pacemaker -> Last Non-sustained Episodes Select";

	private final By otherEpisodes_checkbox_OR = By.xpath("//input[@id='otherEpsd-input']");
	private final String otherEpisodes_checkbox_S = "ICD/Pacemaker -> Last Other Episodes Checkbox";

	private final By otherEpisodes_label_OR = By.xpath("//mat-select[@id='otherEpsdCd']/following-sibling::mat-label");
	private final String otherEpisodes_label_S = "ICD/Pacemaker -> Last Other Episodes Label";

	private final By otherEpisodes_select_OR = By.xpath("//mat-select[@id='otherEpsdCd']");
	private final String otherEpisodes_select_S = "ICD/Pacemaker -> Last Other Episodes Select";

	// All Alerts and Episodes -> Cardiac Monitor
	private final By cardiacMonitor_episodes_checkbox_OR = By.xpath("//input[@id='icmEpsd-input']");
	private final String cardiacMonitor_episodes_checkbox_S = "Cardiac Monitor -> Last Episodes Checkbox";

	private final By cardiacMonitor_episodes_label_OR = By
			.xpath("//mat-select[@id='icmEpsdCd']/following-sibling::mat-label");
	private final String cardiacMonitor_episodes_label_S = "Cardiac Monitor -> Last Episodes Label";

	private final By cardiacMonitor_episodes_select_OR = By.xpath("//mat-select[@id='icmEpsdCd']");
	private final String cardiacMonitor_episodes_select_S = "Cardiac Monitor -> Last Episodes Select";
	
	//episode select common dropdown elements. this is common all episode select dropdowns.
	private final By episodes_select_drpdwn_All_OR = By
			.xpath("//div[@class=\"cdk-overlay-container\"]/div[2]/div/div/div/mat-option[1]");
	private final String episodes_select_drpdwn_All_S = "Episodes select drop down -> All";
	private final By episodes_select_drpdwn_1_OR = By
			.xpath("//div[@class=\"cdk-overlay-container\"]/div[2]/div/div/div/mat-option[2]");
	private final String episodes_select_drpdwn_1_S = "Episodes select drop down -> 1";
	private final By episodes_select_drpdwn_2_OR = By
			.xpath("//div[@class=\"cdk-overlay-container\"]/div[2]/div/div/div/mat-option[3]");
	private final String episodes_select_drpdwn_2_S = "Episodes select drop down -> 2";
	private final By episodes_select_drpdwn_3_OR = By
			.xpath("//div[@class=\"cdk-overlay-container\"]/div[2]/div/div/div/mat-option[4]");
	private final String episodes_select_drpdwn_3_S = "Episodes select drop down -> 3";
	private final By episodes_select_drpdwn_4_OR = By
			.xpath("//div[@class=\"cdk-overlay-container\"]/div[2]/div/div/div/mat-option[5]");
	private final String episodes_select_drpdwn_4_S = "Episodes select drop down -> 4";
	private final By episodes_select_drpdwn_5_OR = By
			.xpath("//div[@class=\"cdk-overlay-container\"]/div[2]/div/div/div/mat-option[6]");
	private final String episodes_select_drpdwn_5_S = "Episodes select drop down -> 5";

// All Diagnostics
	private final By allDiagnostics_checkbox_OR = By
			.xpath("//div[@id='reportSettings']/div[2]/div[3]/div/mat-checkbox[1]/label/div/input");
	private final String allDiagnostics_checkbox_S = "All Diagnostics Checkbox";

	private final By allDiagnostics_label_OR = By
			.xpath("//div[@id='reportSettings']/div[2]/div[3]/div/mat-checkbox[1]/label/span");
	private final String allDiagnostics_label_S = "All Diagnostics Label";

	private final By extendedDiagnostics_checkbox_OR = By.xpath("//input[@id='extendedDiag-input']");
	private final String extendedDiagnostics_checkbox_S = "All Diagnostics -> Extended Diagnostics Checkbox";

	private final By extendedDiagnostics_label_OR = By.xpath("//mat-checkbox[@id='extendedDiag']/label/span");
	private final String extendedDiagnostics_label_S = "All Diagnostics -> Extended Diagnostics Label";

	private final By tachy_checkbox_OR = By.xpath("//input[@id='tatcyCheck-input']");
	private final String tachy_checkbox_S = "All Diagnostics -> Tachy Checkbox";

	private final By tachy_label_OR = By.xpath("//mat-checkbox[@id='tatcyCheck']/label/span");
	private final String tachy_label_S = "All Diagnostics -> Tachy Label";

	private final By brady_checkbox_OR = By.xpath("//input[@id='bradyCheck-input']");
	private final String brady_checkbox_S = "All Diagnostics -> Brady Checkbox";

	private final By brady_label_OR = By.xpath("//mat-checkbox[@id='bradyCheck']/label/span");
	private final String brady_label_S = "All Diagnostics -> Brady Label";

	private final By heartInFocus_checkbox_OR = By.xpath("//input[@id='heartInFocus-input']");
	private final String heartInFocus_checkbox_S = "All Diagnostics -> Heart in Focus Checkbox";

	private final By heartInFocus_label_OR = By.xpath("//mat-checkbox[@id='heartInFocus']/label/span");
	private final String heartInFocus_label_S = "All Diagnostics -> Heart in Focus Label";

	private final By stMonitoring_checkbox_OR = By.xpath("//input[@id='stMonitoring-input']");
	private final String stMonitoring_checkbox_S = "All Diagnostics -> ST Monitoring Checkbox";

	private final By stMonitoring_label_OR = By.xpath("//mat-checkbox[@id='stMonitoring']/label/span");
	private final String stMonitoring_label_S = "All Diagnostics -> ST Monitoring Label";

	private final By corvueReporting_checkbox_OR = By.xpath("//input[@id='corvureReport-input']");
	private final String corvueReporting_checkbox_S = "All Diagnostics -> Corvue Report Checkbox";

	private final By corvueReporting_label_OR = By.xpath("//mat-checkbox[@id='corvureReport']/label/span");
	private final String corvueReporting_label_S = "All Diagnostics -> Corvue Report Label";

	private final By atAf_checkbox_OR = By.xpath("//input[@id='atafCheck-input']");
	private final String atAf_checkbox_S = "All Diagnostics -> AT/AF Checkbox";

	private final By atAf_label_OR = By.xpath("//mat-checkbox[@id='atafCheck']/label/span");
	private final String atAf_label_S = "All Diagnostics -> AT/AF Label";

	private final By directTrendReport_checkbox_OR = By.xpath("//input[@id='directTrendReport-input']");
	private final String directTrendReport_checkbox_S = "All Diagnostics -> DirectTrend Report Checkbox";

	private final By directTrendReport_label_OR = By.xpath("//mat-checkbox[@id='directTrendReport']/label/span");
	private final String directTrendReport_label_S = "All Diagnostics -> DirectTrend Report Label";

	private final By parameters_checkbox_OR = By.xpath("//input[@id='parametersCheck-input']");
	private final String parameters_checkbox_S = "Parameters Checkbox";

	private final By parameters_label_OR = By.xpath("//mat-checkbox[@id='parametersCheck']/label/span");
	private final String parameters_label_S = "Parameters Label";

	private final By wrapUpOverview_checkbox_OR = By.xpath("//input[@id='wrapUpOverview-input']");
	private final String wrapUpOverview_checkbox_S = "Wrap Up Overview Checkbox";

	private final By wrapUpOverview_label_OR = By.xpath("//mat-checkbox[@id='wrapUpOverview']/label/span");
	private final String wrapUpOverview_label_S = "Wrap Up Overview Label";

//Always Print Comments
	private final By alwaysPrintComments_checkbox_OR = By.xpath("//input[@id='printComments-input']");
	private final String alwaysPrintComments_checkbox_S = "Always print comments starting days prior to print date Checkbox";

	private final By alwaysPrintComments_label_OR = By.xpath("//mat-checkbox[@id='printComments']/label/span");
	private final String alwaysPrintComments_label_S = "Always print comments starting days prior to print date Label";

	private final By printCommentsStartingDays_select_OR = By.xpath("//mat-select[@id='commentsCd']");
	private final String printCommentsStartingDays_select_S = "Print comments starting days prior to list box";

	private final String printCommentsDaysDropdown_OR = "//div[@id='commentsCd-panel']/mat-option[{0}]";
	private final String printCommentsDaysDropdown_S = "Print comments starting days in dropdown";

	private final By alwaysPrintComments_days_OR = By.xpath("//mat-select[@id='commentsCd']/div/div/span");
	private final String alwaysPrintComments_days_S = "Always print comments days";

	// COVER SHEET Elements
	private final By alwaysPrintCoverSheet_checkbox_OR = By
			.xpath("//div[@id='coverSheet']/div/div/div/mat-checkbox[1]/label/div/input");
	private final String alwaysPrintCoverSheet_checkbox_S = "Always print cover sheet Checkbox";

	private final By alwaysPrintCoverSheet_label_OR = By
			.xpath("//div[@id='coverSheet']/div/div/div/mat-checkbox[1]/label/span");
	private final String alwaysPrintCoverSheet_label_S = "Always print cover sheet Label";

	private final By patientName_checkbox_OR = By.xpath("//input[@id='repPatientName-input']");
	private final String patientName_checkbox_S = "And Include: Patient name Checkbox";

	private final By patientName_label_OR = By.xpath("//mat-checkbox[@id='repPatientName']/label/span");
	private final String patientName_label_S = "And Include: Patient name Label";

	private final By clinicName_checkbox_OR = By.xpath("//input[@id='repClinicName-input']");
	private final String clinicName_checkbox_S = "And Include: Clinic name Checkbox";

	private final By clinicName_label_OR = By.xpath("//mat-checkbox[@id='repClinicName']/label/span");
	private final String clinicName_label_S = "And Include: Clinic name Label";

	private final By commentBox_checkbox_OR = By.xpath("//input[@id='repComments-input']");
	private final String commentBox_checkbox_S = "And Include: Comment box Checkbox";

	private final By commentBox_label_OR = By.xpath("//mat-checkbox[@id='repComments']/label/span");
	private final String commentBox_label_S = "And Include: Comment box Label";

	private final By medicalTeam_checkbox_OR = By.xpath("//input[@id='repClinicians-input']");
	private final String medicalTeam_checkbox_S = "And Include: Medical Team Checkbox";

	private final By medicalTeam_label_OR = By.xpath("//mat-checkbox[@id='repClinicians']/label/span");
	private final String medicalTeam_label_S = "And Include: Medical Team Label";

	private final By pageNumber_checkbox_OR = By
			.xpath("//input[@id='repPgNumber-input']");
	private final String pageNumber_checkbox_S = "And Include: Page Number Checkbox";

	private final By pageNumber_label_OR = By.xpath("//mat-checkbox[@id='repPgNumber']/label/span");
	private final String pageNumber_label_S = "And Include: Page Number Label";

	private final By todaysDate_checkbox_OR = By.xpath("//input[@id='repDt-input']");
	private final String todaysDate_checkbox_S = "And Include: Today's date Checkbox";

	private final By todaysDate_label_OR = By.xpath("//mat-checkbox[@id='repDt']/label/span");
	private final String todaysDate_label_S = "And Include: Today's date Label";

// Other Features
	private final By doNotShowAlertsForAvlDev_checkbox_OR = By.xpath("//input[@id='devUpgrade-input']");
	private final String doNotShowAlertsForAvlDevc_checkbox_S = "Do not show alerts for available device upgrades Checkbox";

	private final By doNotShowAlertsForAvlDev_label_OR = By.xpath("//mat-checkbox[@id='devUpgrade']/label/span");
	private final String doNotShowAlertsForAvlDevc_label_S = "Do not show alerts for available device upgrades Label";

	//Ends here - Poojitha
	
	// private final By identifyKeyEpisodes_checkbox_OR =By.xpath("//input[@id=\"mat-checkbox-55-input\"]");
	//private final By identifyKeyEpisodes_checkbox_OR = By.xpath("//div[@id='otherFeatures']/div/div/div/div[2]/mat-checkbox[1]/label/div/input");
		//modified by jais
	private final By identifyKeyEpisodes_checkbox_OR = By.xpath("//input[@id='keyEpisodes-input']");
	private final By identifyKeyEpisodes_checkbox_edit_OR = By.xpath("//input[@id='keyEpisodes-input']/following-sibling::div");
																							 
	private final String identifyKeyEpisodes_checkbox_S = "Identify Key Episodes Checkbox";

	// private final By identifyKeyEpisodes_label_OR =
	// By.xpath("//mat-checkbox[@id=\"mat-checkbox-55\"]/label/span");
	private final By identifyKeyEpisodes_label_OR = By
			.xpath("//div[@id='otherFeatures']/div/div/div/div[2]/mat-checkbox[1]/label/span");
	private final String identifyKeyEpisodes_label_S = "Identify Key Episodes Label";

//Added by Jais
	private final By saveBtn_OR = By.xpath("//div[@id=\"report-settings-wrapper\"]/div/div/div[2]/button[2]/span");
	private final String saveBtn_OR_S = "Report settings save";
	//End by Jais
	
	private final By patient_Summary_Report_OR = By
			.xpath("//div[@class='card ng-star-inserted']/h3");
	private final String patient_Summary_Report_S = "Patient Summary Report Label";
	
	private final By patient_Summary_OR = By
			.xpath("//div[@id='summaryReport']");
	private final String patient_Summary_S = "Patient Summary Label";
	
	private final By billingInterval_OR = By.xpath("//matselect[@id='billIntervalCode']/div/div/span/span");
	private final String billingInterval_S = "Default Billing interval after clicking on Edit button";

	private final By billingInterval31_OR = By 
			.xpath("//div[@id='billIntervalCode-panel']/mat-option[@id='mat-option-561']/span");
	private final String billingInterval31_S = "Billing Interval select drop down -> 31";
	private final By billingInterval91_OR = By
			.xpath("//div[@id='billIntervalCode-panel']/mat-option[@id='mat-option-562']/span");
	private final String billingInterval91_S = "Billing Interval select drop down -> 91";

	//Poojitha
	private final By pageLoading_OR = By.xpath("//div[@class='spinnerWrapper']");
	private final String pageLoading_S = "Page loading symbol";
	//Ends here
	
	
	
	//Victor 
	public boolean verifyReportsSettingsEditButton() throws InterruptedException { 
		boolean isDisplayEditBtn = false;
		if (isDisplayed(editButton_OR)) {
		isDisplayEditBtn = true;
		extentReport.reportScreenShot("ReportSetting page is display in edit mode");
	}else {
		isDisplayEditBtn = false;
		extentReport.reportScreenShot("ReportSetting page is not display in edit mode");
	}
		return isDisplayEditBtn;
		}
	//victor
	 public boolean verifyPatientSummaryReport() {
		 scrollToView(patient_Summary_Report_OR);
		  Boolean isPatientSummaryReportPresent=false;
		  if(visibilityOfElementLocated(patient_Summary_Report_OR)) {
			  isPatientSummaryReportPresent=true;
			   extentReport.reportScreenShot("Patient Summary Report Label is displayed");
		   }
		   else {
			   extentReport.reportScreenShot("Patient Summary Report Label is not displayed");
		   }
		return isPatientSummaryReportPresent;
	  }
	 
	//victor
	 public String verifyDefaultBillingInterval() { 
			return getText(billingInterval_OR, billingInterval_S);
			}
	 
	 public boolean verifyBillingIntervalDropdown() { 
		 return isDisplayedWithReportScreenshot(billingInterval_OR, billingInterval_S);
		 }
	
	//victor
	 public List getBillingIntervalsListValues() throws Exception{ 
			List values = new ArrayList<String> ();
			clickElement(billingInterval_OR, billingInterval_S);
			values.add(getText(billingInterval31_OR, billingInterval31_S));
			values.add(getText(billingInterval91_OR, billingInterval91_S));
			return values;
			}

	 //victor
		public void selectBillingInterval91_andSave() { 
			clickElement(billingInterval_OR, billingInterval_S);
			clickElement(billingInterval91_OR, billingInterval91_S);
			clickElement(saveButton_OR, saveButton_S);
			}
		
		//victor
		public boolean verify_Alert_Is_Present_Patient_SummaryReport() throws InterruptedException{
			boolean isAlertdisplayed = false;
			if(isAlertPresent()) {
				isAlertdisplayed = true;
			}
			return isAlertdisplayed;
		}
		
		//victor
		public void acceptAlertIsPresent_Patient_SummaryReport() throws InterruptedException{
			acceptAlert_KeyEpisodes();
		}
		//victor
		public void selectBillingInterval31_andSave() { 
			clickElement(billingInterval_OR, billingInterval_S);
			clickElement(billingInterval31_OR, billingInterval31_S);
			clickElement(saveButton_OR, saveButton_S);
			}
		
	
	
	// Poojitha - Feb 4th,2021
	public boolean verifyPrintCommentsDropdownValues() {
		boolean dropdown = false;
		try
		{
			clickElementWithoutReport(printCommentsStartingDays_select_OR,printCommentsStartingDays_select_S);
			if(getText(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "1"))).trim().equals("10") &&
			getText(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "2"))).trim().equals("20") &&
			getText(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "3"))).trim().equals("30") &&
			getText(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "4"))).trim().equals("60") &&
			getText(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "5"))).trim().equals("90"))
			dropdown = true;	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return dropdown;
	}

	public boolean verifyAbleToChoosePrintCommentStartingDays(String days) {
		boolean ableToSelect = false;
		switch(days)
		{
		case "10 days":
			clickElementWithoutReport(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "1")),printCommentsStartingDays_select_S);
			ableToSelect = true;
			break;
		case "20 days":
			clickElementWithoutReport(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "2")),printCommentsStartingDays_select_S);
			ableToSelect = true;
			break;
		case "30 days":
			clickElementWithoutReport(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "3")),printCommentsStartingDays_select_S);
			ableToSelect = true;
			break;
		case "60 days":
			clickElementWithoutReport(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "4")),printCommentsStartingDays_select_S);
			ableToSelect = true;
			break;
		case "90 days":
			clickElementWithoutReport(By.xpath(printCommentsDaysDropdown_OR.replace("{0}", "5")),printCommentsStartingDays_select_S);
			ableToSelect = true;
			break;
		}
		return ableToSelect;	
	}
	// verify if the checkbox is checked
	public boolean isCheckboxSelected(By checkbox, String elementName) {
		boolean status = false;

		if (isDisplayedWithReportScreenshot(checkbox, elementName)) {
			if (isSelectedWithoutReport(checkbox,elementName)) {
				status = true;
			}
		} 
		return status;
	}
	
	//Verify whether checkbox is enabled
	public String isCheckboxEnabled(By checkbox, String elementName) {
		String status = "";

		if (isEnabledWithReport(checkbox, elementName)) {
				status = "Enabled";
			} else {
				status = "Disabled";
			}
		return status;
	}


	/*
	 * Author: Vinay Babu Date: 05 Dec 2021
	 * 
	 * Below All Methods are used in TC:
	 * WA_CA_600_Report_Settings_Dynamic_Components_01
	 * 
	 */

//-----------------------Start: WA_CA_600_Report_Settings_Dynamic_Components_01--------------------------------------------------------------------------------//

	// Verify all checkboxes
//Poojitha - updated to switch case to be more generic  - Feb 4th 2021
	public boolean verifyCheckBox(String name)
	{
		boolean checkbox = false;
		switch(name)
		{
		case "SelectAll":
			checkbox = isCheckboxSelected(selectAll_checkbox_OR, selectAll_checkbox_S);
			break;
		case "Summary":
			checkbox = isCheckboxSelected(summary_checkbox_OR, summary_checkbox_S);
			break;
		case "FastPathSummary":
			checkbox = isCheckboxSelected(fastPathSummary_checkbox_OR, fastPathSummary_checkbox_S);
			break;
		case "EpisodesSummary":
			checkbox = isCheckboxSelected(episodesSummary_checkbox_OR, episodesSummary_checkbox_S);
			break;
		case "DiagnosticSummary":
			checkbox = isCheckboxSelected(diagnosticsSummary_checkbox_OR, diagnosticsSummary_checkbox_S);
			break;
		case "PatientInfoLeads":
			checkbox = isCheckboxSelected(patientInfoAndLeads_checkbox_OR, patientInfoAndLeads_checkbox_S);
			break;
		case "MRISummary":
			checkbox = isCheckboxSelected(mriSummary_checkbox_OR, mriSummary_checkbox_S);
			break;
		case "AllTests":
			checkbox = isCheckboxSelected(allTests_checkbox_OR, allTests_checkbox_S);
			break;
		case "RTMTrend":
			checkbox = isCheckboxSelected(rtmTrend_checkbox_OR, rtmTrend_checkbox_S);
			break;
		case "CaptureThreshold":
			checkbox = isCheckboxSelected(captureThreshold_checkbox_OR, captureThreshold_checkbox_S);
			break;
		case "TestResults":
			checkbox = isCheckboxSelected(testResults_checkbox_OR, testResults_checkbox_S);
			break;
		case "CRTToolKit":
			checkbox = isCheckboxSelected(crtToolkit_checkbox_OR, crtToolkit_checkbox_S);
			break;
		case "AllAlertsEpisodes":
			checkbox = isCheckboxSelected(allAlertsAdnEpisodes_checkbox_OR, allAlertsAdnEpisodes_checkbox_S);
			break;
		case "AlertSummary":
			checkbox = isCheckboxSelected(alertSummary_checkbox_OR, alertSummary_checkbox_S);
			break;
		case "RealtimeEGM":
			checkbox = isCheckboxSelected(realTimeEGMs_checkbox_OR, realTimeEGMs_checkbox_S);
			break;
		case "ExtendedEpisodes":
			checkbox = isCheckboxSelected(extendedEpisodes_checkbox_OR, extendedEpisodes_checkbox_S);
			break;
		case "VT/VFEpisodes":
			checkbox = isCheckboxSelected(vtVfEpisodes_checkbox_OR, vtVfEpisodes_checkbox_S);
			break;
		case "SVTEpisodes":
			checkbox = isCheckboxSelected(svtEpisodes_checkbox_OR, svtEpisodes_checkbox_S);
			break;
		case "AT/AFEpisodes":
			checkbox = isCheckboxSelected(atAfEpisodes_checkbox_OR, atAfEpisodes_checkbox_S);
			break;
		case "NonSustainedEpisodes":
			checkbox = isCheckboxSelected(nonSustainedEvents_checkbox_OR, nonSustainedEvents_checkbox_S);
			break;
		case "OtherEpisodes":
			checkbox = isCheckboxSelected(otherEpisodes_checkbox_OR, otherEpisodes_checkbox_S);
			break;
		case "CardiacMonitor":
			checkbox = isCheckboxSelected(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S);
			break;
		case "AllDiagnostics":
			checkbox = isCheckboxSelected(allDiagnostics_checkbox_OR, allDiagnostics_checkbox_S);
			break;
		case "ExtendedDiagnostics":
			checkbox = isCheckboxSelected(extendedDiagnostics_checkbox_OR, extendedDiagnostics_checkbox_S);
			break;
		case "Tachy":
			checkbox = isCheckboxSelected(tachy_checkbox_OR, tachy_checkbox_S);
			break;
		case "HeartInFocus":
			checkbox = isCheckboxSelected(heartInFocus_checkbox_OR, heartInFocus_checkbox_S);
			break;
		case "Brady":
			checkbox = isCheckboxSelected(brady_checkbox_OR, brady_checkbox_S);
			break;
		case "STMonitoring":
			checkbox = isCheckboxSelected(stMonitoring_checkbox_OR, stMonitoring_checkbox_S);
			break;
		case "AT/AF":
			checkbox = isCheckboxSelected(atAf_checkbox_OR, atAf_checkbox_S);
			break;
		case "Corvue":
			checkbox = isCheckboxSelected(corvueReporting_checkbox_OR, corvueReporting_checkbox_S);
			break;
		case "DirectTrend":
			checkbox = isCheckboxSelected(directTrendReport_checkbox_OR, directTrendReport_checkbox_S);
			break;
		case "Parameters":
			checkbox = isCheckboxSelected(parameters_checkbox_OR, parameters_checkbox_S);
			break;
		case "WrapUp":
			checkbox = isCheckboxSelected(wrapUpOverview_checkbox_OR, wrapUpOverview_checkbox_S);
			break;
		case "PrintComments":
			checkbox = isCheckboxSelected(alwaysPrintComments_checkbox_OR, alwaysPrintComments_checkbox_S);
			break;
		case "PrintCoverSheet":
			checkbox = isCheckboxSelected(alwaysPrintCoverSheet_checkbox_OR, alwaysPrintCoverSheet_checkbox_S);
			break;
		case "PatientName":
			checkbox = isCheckboxSelected(patientName_checkbox_OR, patientName_checkbox_S);
			break;
		case "ClinicName":
			checkbox = isCheckboxSelected(clinicName_checkbox_OR, clinicName_checkbox_S);
			break;
		case "CommentBox":
			checkbox = isCheckboxSelected(commentBox_checkbox_OR, commentBox_checkbox_S);
			break;
		case "MedicalTeam":
			checkbox = isCheckboxSelected(medicalTeam_checkbox_OR, medicalTeam_checkbox_S);
			break;
		case "PageNumber":
			checkbox = isCheckboxSelected(pageNumber_checkbox_OR, pageNumber_checkbox_S);
			break;
		case "TodayDate":
			checkbox = isCheckboxSelected(todaysDate_checkbox_OR, todaysDate_checkbox_S);
			break;		
		case "DeviceUpgrade":
			checkbox = isCheckboxSelected(doNotShowAlertsForAvlDev_checkbox_OR, doNotShowAlertsForAvlDevc_checkbox_S);
			break;		
		case "KeyEpisodes":
			checkbox = isCheckboxSelected(identifyKeyEpisodes_checkbox_OR, identifyKeyEpisodes_checkbox_S);
			break;	
		}
		return checkbox;
	}
	
	// Below section verifies the text displayed for each check box.

	public String verifyLabelText(String name)
	{
		String text = null;
		switch(name)
		{
		case "SelectAll":
			text = getText(selectAll_label_OR, selectAll_label_S);
			break;
		case "Summary":
			text = getText(summary_label_OR, summary_label_S);
			break;
		case "FastPathSummary":
			text = getText(fastPathSummary_label_OR, fastPathSummary_label_S);
			break;
		case "EpisodesSummary":
			text = getText(episodesSummary_label_OR, episodesSummary_label_S);
			break;
		case "DiagnosticSummary":
			text = getText(diagnosticsSummary_label_OR, diagnosticsSummary_label_S);
			break;
		case "PatientInfoLeads":
			text = getText(patientInfoAndLeads_label_OR, patientInfoAndLeads_label_S);
			break;
		case "MRISummary":
			text = getText(mriSummary_label_OR, mriSummary_label_S);
			break;
		case "AllTests":
			text = getText(allTests_label_OR, allTests_label_S);
			break;
		case "RTMTrend":
			text = getText(rtmTrend_label_OR, rtmTrend_label_S);
			break;
		case "CaptureThreshold":
			text = getText(captureThreshold_label_OR, captureThreshold_label_S);
			break;
		case "TestResults":
			text = getText(testResults_label_OR, testResults_label_S);
			break;
		case "CRTToolKit":
			text = getText(crtToolkit_label_OR, crtToolkit_label_S);
			break;
		case "AllAlertsEpisodes":
			text = getText(allAlertsAdnEpisodes_label_OR, allAlertsAdnEpisodes_label_S);
			break;
		case "AlertSummary":
			text = getText(alertSummary_label_OR, alertSummary_label_S);
			break;
		case "RealtimeEGM":
			text = getText(realTimeEGMs_label_OR, realTimeEGMs_label_S);
			break;
		case "ExtendedEpisodes":
			text = getText(extendedEpisodes_label_OR, extendedEpisodes_label_S);
			break;
		case "VT/VFEpisodes":
			text = getText(vtVfEpisodes_label_OR, vtVfEpisodes_label_S);
			break;
		case "SVTEpisodes":
			text = getText(svtEpisodes_label_OR, svtEpisodes_label_S);
			break;
		case "AT/AFEpisodes":
			text = getText(atAfEpisodes_label_OR, atAfEpisodes_label_S);
			break;
		case "NonSustainedEpisodes":
			text = getText(nonSustainedEvents_label_OR, nonSustainedEvents_label_S);
			break;
		case "OtherEpisodes":
			text = getText(otherEpisodes_label_OR, otherEpisodes_label_S);
			break;
		case "CardiacMonitor":
			text = getText(cardiacMonitor_episodes_label_OR, cardiacMonitor_episodes_label_S);
			break;
		case "AllDiagnostics":
			text = getText(allDiagnostics_label_OR, allDiagnostics_label_S);
			break;
		case "ExtendedDiagnostics":
			text = getText(extendedDiagnostics_label_OR, extendedDiagnostics_label_S);
			break;
		case "Tachy":
			text = getText(tachy_label_OR, tachy_label_S);
			break;
		case "HeartInFocus":
			text = getText(heartInFocus_label_OR, heartInFocus_label_S);
			break;
		case "Brady":
			text = getText(brady_label_OR, brady_label_S);
			break;
		case "STMonitoring":
			text = getText(stMonitoring_label_OR, stMonitoring_label_S);
			break;
		case "AT/AF":
			text = getText(atAf_label_OR, atAf_label_S);
			break;
		case "Corvue":
			text = getText(corvueReporting_label_OR, corvueReporting_label_S);
			break;
		case "DirectTrend":
			text = getText(directTrendReport_label_OR, directTrendReport_label_S);
			break;
		case "Parameters":
			text = getText(parameters_label_OR, parameters_label_S);
			break;
		case "WrapUp":
			text = getText(wrapUpOverview_label_OR, wrapUpOverview_label_S);
			break;
		case "PrintComments":
			text = getText(alwaysPrintComments_label_OR, alwaysPrintComments_label_S);
			break;
		case "PrintCoverSheet":
			text = getText(alwaysPrintCoverSheet_label_OR, alwaysPrintCoverSheet_label_S);
			break;
		case "PatientName":
			text = getText(patientName_label_OR, patientName_label_S);
			break;
		case "ClinicName":
			text = getText(clinicName_label_OR, clinicName_label_S);
			break;
		case "CommentBox":
			text = getText(commentBox_label_OR, commentBox_label_S);
			break;
		case "MedicalTeam":
			text = getText(medicalTeam_label_OR, medicalTeam_label_S);
			break;
		case "PageNumber":
			text = getText(pageNumber_label_OR, pageNumber_label_S);
			break;
		case "TodayDate":
			text = getText(todaysDate_label_OR, todaysDate_label_S);
			break;		
		case "DeviceUpgrade":
			text = getText(doNotShowAlertsForAvlDev_label_OR, doNotShowAlertsForAvlDevc_label_S);
			break;		
		case "KeyEpisodes":
			text = getText(identifyKeyEpisodes_label_OR, identifyKeyEpisodes_label_S);
			break;	
		}
		return text;
	}

	public String verifyCheckBoxEnabled(String name)
	{
		String enable = null;
		switch(name)
		{
		case "SelectAll":
			enable = isCheckboxEnabled(selectAll_checkbox_OR, selectAll_checkbox_S);
			break;
		case "Summary":
			enable = isCheckboxEnabled(summary_checkbox_OR, summary_checkbox_S);
			break;
		case "FastPathSummary":
			enable = isCheckboxEnabled(fastPathSummary_checkbox_OR, fastPathSummary_checkbox_S);
			break;
		case "EpisodesSummary":
			enable = isCheckboxEnabled(episodesSummary_checkbox_OR, episodesSummary_checkbox_S);
			break;
		case "DiagnosticSummary":
			enable = isCheckboxEnabled(diagnosticsSummary_checkbox_OR, diagnosticsSummary_checkbox_S);
			break;
		case "PatientInfoLeads":
			enable = isCheckboxEnabled(patientInfoAndLeads_checkbox_OR, patientInfoAndLeads_checkbox_S);
			break;
		case "MRISummary":
			enable = isCheckboxEnabled(mriSummary_checkbox_OR, mriSummary_checkbox_S);
			break;
		case "AllTests":
			enable = isCheckboxEnabled(allTests_checkbox_OR, allTests_checkbox_S);
			break;
		case "RTMTrend":
			enable = isCheckboxEnabled(rtmTrend_checkbox_OR, rtmTrend_checkbox_S);
			break;
		case "CaptureThreshold":
			enable = isCheckboxEnabled(captureThreshold_checkbox_OR, captureThreshold_checkbox_S);
			break;
		case "TestResults":
			enable = isCheckboxEnabled(testResults_checkbox_OR, testResults_checkbox_S);
			break;
		case "CRTToolKit":
			enable = isCheckboxEnabled(crtToolkit_checkbox_OR, crtToolkit_checkbox_S);
			break;
		case "AllAlertsEpisodes":
			enable = isCheckboxEnabled(allAlertsAdnEpisodes_checkbox_OR, allAlertsAdnEpisodes_checkbox_S);
			break;
		case "AlertSummary":
			enable = isCheckboxEnabled(alertSummary_checkbox_OR, alertSummary_checkbox_S);
			break;
		case "RealtimeEGM":
			enable = isCheckboxEnabled(realTimeEGMs_checkbox_OR, realTimeEGMs_checkbox_S);
			break;
		case "ExtendedEpisodes":
			enable = isCheckboxEnabled(extendedEpisodes_checkbox_OR, extendedEpisodes_checkbox_S);
			break;
		case "VT/VFEpisodes":
			enable = isCheckboxEnabled(vtVfEpisodes_checkbox_OR, vtVfEpisodes_checkbox_S);
			break;
		case "SVTEpisodes":
			enable = isCheckboxEnabled(svtEpisodes_checkbox_OR, svtEpisodes_checkbox_S);
			break;
		case "AT/AFEpisodes":
			enable = isCheckboxEnabled(atAfEpisodes_checkbox_OR, atAfEpisodes_checkbox_S);
			break;
		case "NonSustainedEpisodes":
			enable = isCheckboxEnabled(nonSustainedEvents_checkbox_OR, nonSustainedEvents_checkbox_S);
			break;
		case "OtherEpisodes":
			enable = isCheckboxEnabled(otherEpisodes_checkbox_OR, otherEpisodes_checkbox_S);
			break;
		case "CardiacMonitor":
			enable = isCheckboxEnabled(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S);
			break;
		case "AllDiagnostics":
			enable = isCheckboxEnabled(allDiagnostics_checkbox_OR, allDiagnostics_checkbox_S);
			break;
		case "ExtendedDiagnostics":
			enable = isCheckboxEnabled(extendedDiagnostics_checkbox_OR, extendedDiagnostics_checkbox_S);
			break;
		case "Tachy":
			enable = isCheckboxEnabled(tachy_checkbox_OR, tachy_checkbox_S);
			break;
		case "HeartInFocus":
			enable = isCheckboxEnabled(heartInFocus_checkbox_OR, heartInFocus_checkbox_S);
			break;
		case "Brady":
			enable = isCheckboxEnabled(brady_checkbox_OR, brady_checkbox_S);
			break;
		case "STMonitoring":
			enable = isCheckboxEnabled(stMonitoring_checkbox_OR, stMonitoring_checkbox_S);
			break;
		case "AT/AF":
			enable = isCheckboxEnabled(atAf_checkbox_OR, atAf_checkbox_S);
			break;
		case "Corvue":
			enable = isCheckboxEnabled(corvueReporting_checkbox_OR, corvueReporting_checkbox_S);
			break;
		case "DirectTrend":
			enable = isCheckboxEnabled(directTrendReport_checkbox_OR, directTrendReport_checkbox_S);
			break;
		case "Parameters":
			enable = isCheckboxEnabled(parameters_checkbox_OR, parameters_checkbox_S);
			break;
		case "WrapUp":
			enable = isCheckboxEnabled(wrapUpOverview_checkbox_OR, wrapUpOverview_checkbox_S);
			break;
		case "PrintComments":
			enable = isCheckboxEnabled(alwaysPrintComments_checkbox_OR, alwaysPrintComments_checkbox_S);
			break;
		case "PrintCoverSheet":
			enable = isCheckboxEnabled(alwaysPrintCoverSheet_checkbox_OR, alwaysPrintCoverSheet_checkbox_S);
			break;
		case "PatientName":
			enable = isCheckboxEnabled(patientName_checkbox_OR, patientName_checkbox_S);
			break;
		case "ClinicName":
			enable = isCheckboxEnabled(clinicName_checkbox_OR, clinicName_checkbox_S);
			break;
		case "CommentBox":
			enable = isCheckboxEnabled(commentBox_checkbox_OR, commentBox_checkbox_S);
			break;
		case "MedicalTeam":
			enable = isCheckboxEnabled(medicalTeam_checkbox_OR, medicalTeam_checkbox_S);
			break;
		case "PageNumber":
			enable = isCheckboxEnabled(pageNumber_checkbox_OR, pageNumber_checkbox_S);
			break;
		case "TodayDate":
			enable = isCheckboxEnabled(todaysDate_checkbox_OR, todaysDate_checkbox_S);
			break;		
		case "DeviceUpgrade":
			enable = isCheckboxEnabled(doNotShowAlertsForAvlDev_checkbox_OR, doNotShowAlertsForAvlDevc_checkbox_S);
			break;		
		case "KeyEpisodes":
			enable = isCheckboxEnabled(identifyKeyEpisodes_checkbox_OR, identifyKeyEpisodes_checkbox_S);
			break;	
		}
		return enable;
	}
	
	public void selectCheckBox(String checkBoxName)
	{
		switch(checkBoxName)
		{
		case "PrintComments":
			clickElement(alwaysPrintComments_checkbox_OR,alwaysPrintComments_checkbox_S);
		}
		
	}
	
	public boolean verifyTextInAlwaysPrintCommentsStarting_span_ClncMgt27010(String expectedText) {
		boolean textCorrect = false;
		String actualText = getText(alwaysPrintComments_days_OR,
				alwaysPrintComments_days_S);

		if (actualText.equalsIgnoreCase(expectedText)) {
			textCorrect = true;
		}

		return textCorrect;
	}

	
	
	public String verifyidentkeyepisodesCheckbox() {
		waitForPageLoad();
		
		String status = "";

		if (isDisplayedWithReportScreenshot(identifyKeyEpisodes_checkbox_OR, identifyKeyEpisodes_checkbox_S)) {
			if (isSelectedWithoutReport(identifyKeyEpisodes_checkbox_OR,identifyKeyEpisodes_checkbox_S)) {
				status = "Checked";
			}
			else
			status = "Unchecked";
			}
		return status;
	}

//--------------------------End: WA_CA_600_Report_Settings_Dynamic_Components_01-----------------------------------------------------------------------------//

	/*
	 * Author: Vinay Babu Date: 06 Dec 2021
	 * 
	 * Below All Methods are used in TC:
	 * ICM_WA_CA600_ReportSetting_ICMEpisodes_01
	 * 
	 */

//-----------------------Start: ICM_WA_CA600_ReportSetting_ICMEpisodes_01--------------------------------------------------------------------------------//

	public boolean clickEditButtonAndVerify() {
		boolean success = false;

		clickElement(editButton_OR, editButton_S);

		if (isEnabled(alertSummary_checkbox_OR)) {
			success = true;
		}

		return success;
	}

	public boolean verifyAllAlertEpisodes_cardiacMonitorOptionsAvailability() {
		boolean success = false;

		if ((isDisplayedWithReportScreenshot(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S))
				&& (isDisplayed(cardiacMonitor_episodes_select_OR))
				&& (isDisplayed(cardiacMonitor_episodes_label_OR))) {
			success = true;
		} 
		else
			success=false;

		return success;
	}
	
	public boolean verifycardiacMonitorOptionsAvailability() {
		boolean success = false;

		if ((isElementNotPresentWithoutReport(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S))
				&& (isElementNotPresentWithoutReport(cardiacMonitor_episodes_select_OR,cardiacMonitor_episodes_select_S))
				&& (isElementNotPresentWithoutReport(cardiacMonitor_episodes_label_OR,cardiacMonitor_episodes_label_S))) {
			success = true;
		} 
		return success;
	}
	
	public String verifyAllAlertEpisodes_cardiacMonitorOptionsAvailableEnabled() {
		String success = "";

		if ((isDisplayedWithReportScreenshot(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S))
				&& (isDisplayed(cardiacMonitor_episodes_select_OR))
				&& (isDisplayed(cardiacMonitor_episodes_label_OR))
				&& isEnabled(cardiacMonitor_episodes_checkbox_OR)) {

			success = "Cardiac Monitor Options Available and Enabled";

		} else {
			success = "Cardiac Monitor Options NOT Available or Enabled";
		}

		return success;
	}
	
	public void selectCardiacMonitor_checkbox() {
		
		if(!(isEnabled(cardiacMonitor_episodes_checkbox_OR))) {
			clickElement(editButton_OR, editButton_S);
		}
		clickElement(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S);
		}
	
	public boolean cardiacMonitorCheckboxValidation()
	{
		boolean checkBox = false;
		if(isSelectedWithoutReport(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S));
		checkBox = true;
		return checkBox;
	}
	
	public boolean clickCardiacMonitorNbrEpisodes_select() {
		boolean success = false;
		
		try {
		
		if(!(isEnabled(cardiacMonitor_episodes_select_OR))) {
			clickElement(editButton_OR, editButton_S);
		}
		clickElement(cardiacMonitor_episodes_select_OR, cardiacMonitor_episodes_select_S);
		success = true;

		} catch (Exception e) {
			success = false;
			throw new AssertionError(e.getMessage());
		}

		return success;
	}
	
	public void selectCardiacMonitorNbrEpisodes_andSave() {
	
		
		clickElement(episodes_select_drpdwn_All_OR, episodes_select_drpdwn_All_S);
		
		clickElement(saveButton_OR, saveButton_S);
		
		acceptAlert_KeyEpisodes();
		isAlertPresent();
		acceptAlert_KeyEpisodes();
		
	}
	
	public String saveCheckCardiacMonitor_EpisodesWithNumber() {
		String success = "";
		
		try {
		
		if(!(isEnabled(cardiacMonitor_episodes_checkbox_OR))) {
			clickElement(editButton_OR, editButton_S);
		}
		
		
		
		clickElement(cardiacMonitor_episodes_checkbox_OR, cardiacMonitor_episodes_checkbox_S);
		
		clickElement(cardiacMonitor_episodes_select_OR, cardiacMonitor_episodes_select_S);
		
		clickElement(episodes_select_drpdwn_All_OR, episodes_select_drpdwn_All_S);
		
		clickElement(saveButton_OR, saveButton_S);
		
		acceptAlert_KeyEpisodes();
		waitForLoading();
		waitForLoading();
		acceptAlert_KeyEpisodes();
		
		
		success = "Checking and Save Cardiac Monitor Episodes is successful";

		} catch (Exception e) {
			success = "Checking and Save Cardiac Monitor Episodes is NOT successful";
			throw new AssertionError(e.getMessage());
		}

		return success;
	}
	
	
	
	//Added by jais
		public void acceptAlert_KeyEpisodes()
		{		
				isAlertPresent();
				extentReport.reportScreenShot("Accepted alert popup");
				acceptAlert();
				isAlertPresent();
				extentReport.reportScreenShot("Accepted alert popup");
				acceptAlert();	
				waitForPageLoadingWithReport();
		}
		public void clickEditButton()
		{
			try {
				presenceOfElementLocated(editButton_OR);
				waitForLoading();
				extentReport.reportScreenShot("Edit button  is displayed");
				clickElement(editButton_OR);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public void clickIdentifyKeyEpisodeChkBox()
		{		
				try {
					scrollToViewWithoutReport(identifyKeyEpisodes_checkbox_OR, identifyKeyEpisodes_checkbox_S);
					//waitForElementToBeClickable(identifyKeyEpisodes_checkbox_OR, identifyKeyEpisodes_checkbox_S);
					extentReport.reportScreenShot("Identify Key Episode Checkbox is displayed");
					//to be removed once driverUtils class method clickOnElementUsingJs handles wait
					//waitForLoading();
					clickOnElementUsingJs(identifyKeyEpisodes_checkbox_OR,identifyKeyEpisodes_checkbox_S);
					extentReport.reportScreenShot("Clicked on identify key episode check box");
				} catch (Exception e) {
					e.printStackTrace();
				}		
		}
		public void saveReportSettings()
		{
			try {
				presenceOfElementLocated(saveBtn_OR);
				waitForLoading();
				extentReport.reportScreenShot("Save button  is displayed");
				clickElement(saveBtn_OR);
				extentReport.reportScreenShot("Clicked on save button");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public Boolean isIdentifyKeyEpisodesPresent() throws InterruptedException
		{
			Boolean isEditbuttonpresent=false;
			   try {
				if(visibilityOfElementLocated(identifyKeyEpisodes_checkbox_OR)) {
					   isEditbuttonpresent=true;
					   extentReport.reportScreenShot("Identify Key Episodes checkbox is displayed");
				   }
				   else {
					   extentReport.reportScreenShot("Identify Key Episodes checkbox is not displayed");
				   }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return isEditbuttonpresent;
			
		}
		
		//end jais
	
	
	
	
	public boolean verifyAbletoCheckICD_PM_EpisodesWithNumber() {
		boolean success = false;
		
		try {
		
		if(!(isEnabled(vtVfEpisodes_checkbox_OR))) {
			clickElement(editButton_OR, editButton_S);
		}
		
		clickElement(vtVfEpisodes_checkbox_OR, vtVfEpisodes_checkbox_S);
		clickElement(svtEpisodes_checkbox_OR,svtEpisodes_checkbox_S);
		clickElement(atAfEpisodes_checkbox_OR, atAfEpisodes_checkbox_S);
		clickElement(nonSustainedEvents_checkbox_OR, nonSustainedEvents_checkbox_S);
		clickElement(otherEpisodes_checkbox_OR, otherEpisodes_checkbox_S);
		
		clickElement(vtVfEpisodes_select_OR, vtVfEpisodes_select_S);
		clickElement(episodes_select_drpdwn_All_OR, episodes_select_drpdwn_All_S);
		
		clickElement(svtEpisodes_select_OR,svtEpisodes_select_S);
		clickElement(episodes_select_drpdwn_1_OR, episodes_select_drpdwn_1_S);
		
		clickElement(atAfEpisodes_select_OR, atAfEpisodes_select_S);
		clickElement(episodes_select_drpdwn_2_OR, episodes_select_drpdwn_2_S);
		
		clickElement(nonSustainedEvents_select_OR, nonSustainedEvents_select_S);
		clickElement(episodes_select_drpdwn_4_OR, episodes_select_drpdwn_4_S);
		
		clickElement(otherEpisodes_select_OR, otherEpisodes_select_S);
		clickElement(episodes_select_drpdwn_5_OR, episodes_select_drpdwn_5_S);
		
		clickElement(saveButton_OR, saveButton_S);
		
		acceptAlert_KeyEpisodes();
		isAlertPresent();
		acceptAlert_KeyEpisodes();
		
		success = true;

		} catch (Exception e) {
			success = false;
			throw new AssertionError(e.getMessage());
		}

		return success;
	}

//-----------------------End: ICM_WA_CA600_ReportSetting_ICMEpisodes_01--------------------------------------------------------------------------------//

	// Each page class should have this overridden method of Verify Landing page


	
	//Poojitha  updated the method to wait till the page gets loaded - Jan 31st
	//Vrushali
	@Override
	public boolean verifyLandingPage() {
	Boolean reportSettingsPageCheck = false;

	if (isElementPresentwithoutException(reportSettingsInfo_OR, reportSettingsInfo_S)) {
		invisibilityOfElementLocated(pageLoading_OR);
	reportSettingsPageCheck = true;
	extentReport.reportScreenShot("Report Settings page is displayed successfully");
	}
	return reportSettingsPageCheck;
	}
}
