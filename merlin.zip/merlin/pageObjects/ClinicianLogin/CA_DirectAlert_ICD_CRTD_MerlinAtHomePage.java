package com.test.qa.ui.pageObjects.ClinicianLogin;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

/**
 * Clinic Administration page for regular user. Navigate to ICD / CRT-D in
 * sidebar.
 */
public class CA_DirectAlert_ICD_CRTD_MerlinAtHomePage extends BasePage {

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	public static Log logger = new Log();

	public CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By pageHeading_OR = By.xpath("//div[@id=\"merlin-home-wrapper\"]/div[1]/div[1]/h5");
	private final String pageHeading_S = "Page Heading";
/***************Alert Table**********************/
	 //*[@id="merlinAlertType"]/div/div[2]/div[1]/div[1]/MAT-LABEL
	 //*[@id="merlinAlertType"]/div/div[2]/div[1]/div[2]/MAT-RADIO-GROUP/DIV/DIV[1]
	 //*[@id="merlinAlertType"]/div/div[2]/div[1]/div[2]/MAT-RADIO-GROUP/DIV/DIV[2]
	 //*[@id="merlinAlertType"]/div/div[2]/div[1]/div[2]/MAT-RADIO-GROUP/DIV/DIV[3]
	 //*[@id="merlinAlertType"]/div/div[2]/div[1]/div[3]/div/MAT-CHECKBOX
	
	//shafiya changed xpath 15/02/2022
	private final By additionalAlertNotificationHeading_OR = By.xpath("//div[@id='merlinHomeProfileForm']/div[3]/h3");
	private final String additionalAlertNotificationHeading_S = "Additional Alert Notification Heading";

	private final By saveButton_OR = By.xpath("//div[@id=\"merlin-home-wrapper\"]/div[1]/div[2]/button[2]");
	private final String saveButton_S = "saveButton";

	private final By cancelButton_OR = By.xpath("//div[@id=\"merlin-home-wrapper\"]/div[1]/div[2]/button[2]");
	private final String cancelButton_S = "cancelButton";
	
	//Clinic Contact Info : ChandraMohan.S
	private final By textMsgField_OR= By.xpath("//input[@id=\"merlin_textbox_sms\"]");
	private final String textMsgField_S = "TextMsgField";
	
	private final By areaCodeField_OR= By.xpath("//div[@id=\"alertClinicContact\"]//div[2]/div[2]//input[@id=\"merlin_textbox_areaCode\"]");
	private final String areaCodeField_S = "AreaCodeField";
	
	private final By phoneNumField_OR= By.xpath("//div[@id=\"alertClinicContact\"]//div[2]/div[3]//input[@id=\"merlin_textbox_phoneNum\"]");
	private final String phoneNumField_S = "PhoneNumField";
	//Ends
	private final By mandateAlertMsg_OR= By.xpath("//div[@id=\"toast-container\"]/div/div[2]");
	private final String mandateAlertMsg_S = "mandateAlertMsg";
	
	//Shafiya changed xpath Date 15/02/2022
	private final By additionalAlertNotificationIcon_OR = By
			.xpath("//div[@id='merlinHomeProfileForm']/div[3]/h3/mat-icon");
	private final String additionalAlertNotificationIcon_S = "Additional Alert Notification Icon";
	//Shafiya changed xpath Date 15/02/2022
	private final By additionalAlertNotification_section_text_OR = By
			.xpath("//div[@id='merlinHomeProfileForm']/div[3]/div[1]/app-merlin-additional-alerts/div/span[1]");
	private final String additionalAlertNotification_section_text_S = "Additional Alert Notification Section Text";

	private final By additionalAlertNotification_section_OR = By
			.xpath("//div[@id=\"merlinHomeProfileForm\"]/div[4]");
	private final String additionalAlertNotification_section_S = "Additional Alert Notification Section Text";

	
	// div[@id="merlinHomeProfileForm"]/div[3]/div[1]/app-merlin-additional-alerts/div/span[1]

	private final By edit_Button_OR = By.xpath("//div[@id=\"merlin-home-wrapper\"]/div[1]/div[2]/button");
	private final String edit_Button_S = "Edit Button";
	
	private final By red_Alert_OR = By.xpath(
			"//*[@id=\"merlinHomeProfileForm\"]/div[1]/div/app-alert-distribution/form/div/div[1]/h4");
	private final String red_Alert_S = "Red Alert ";
	
	private final By yellow_alert_OR = By.xpath(
			"//*[@id=\"merlinHomeProfileForm\"]/div[1]/div/app-alert-distribution/form/div/div[1]/h4");
	private final String yellow_alert_S = "Red Alert ";


	// private final By additionalAlertNotif_sendNotif_select_OR =
	// By.xpath("//mat-select[@id=\"mat-select-23\"]");
	//Shafiya added this xpath 16/02/2022
	private final By additionalAlertNotif_sendNotif_1st_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[1]");	
	private final String additionalAlertNotif_sendNotif_1st_select_Arrow_S = "1st Send Notification to Select box";
	
	private final By additionalAlertNotif_sendNotif_2nd_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[2]");
	private final String additionalAlertNotif_sendNotif_2nd_select_Arrow_S = "2nd Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_3rd_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[3]");
	private final String additionalAlertNotif_sendNotif_3rd_select_Arrow_S = "3rd Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_4th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[4]");
	private final String additionalAlertNotif_sendNotif_4th_select_Arrow_S = "4th Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_5th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[5]");
	private final String additionalAlertNotif_sendNotif_5th_select_Arrow_S = "5th Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_6th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[6]");
	private final String additionalAlertNotif_sendNotif_6th_select_Arrow_S = "6th Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_7th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[7]");
	private final String additionalAlertNotif_sendNotif_7th_select_Arrow_S = "7th Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_8th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[8]");
	private final String additionalAlertNotif_sendNotif_8th_select_Arrow_S = "8th Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_9th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[9]");
	private final String additionalAlertNotif_sendNotif_9th_select_Arrow_S = "9th Send Notification to Select box";

	private final By additionalAlertNotif_sendNotif_10th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[10]");
	private final String additionalAlertNotif_sendNotif_10th_select_Arrow_S = "10th Send Notification to Select box";
	
	private final By additionalAlertNotif_sendNotif_11th_select_Arrow_OR = By.xpath(
			"(//div[@id='additionalAlerts']//mat-select[@id='selectedNotif'])[11]");
	private final String additionalAlertNotif_sendNotif_11th_select_Arrow_S = "11th Send Notification to Select box";
	// private final By additionalAlertNotif_sendNotif_select_text_OR = By
	// .xpath("//mat-select[@id=\"mat-select-23\"]/div/div[1]/span");
	private final By additionalAlertNotif_sendNotif_select_text_OR = By.xpath(
			"//div[@id=\"additionalAlerts\"]/div/div/div[2]/div/div[1]/mat-form-field/div/div[1]/div[3]/mat-select/div/div[1]/span");
	private final String additionalAlertNotif_sendNotif_select_text_S = "Text displayed in Send Notification to Select box";
	//shafiya changed xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_default_Value_OR = By.xpath(
			"//div[@id='selectedNotif-panel']/mat-option[1]");	
	private final String additionalAlertNotif_sendNotif_default_Value_S = "Default Value in Send Notification to Select box";
	//shafiya changed xpath 15/02/2022
	private final By additionalAlertNotif_Add_link_OR = By.xpath("//div[@id='additionalAlerts']//a[@id='add']");
	private final String additionalAlertNotif_Add_link_S = "Add  Link ";
	
	
	
	private final By Send_RedAlertsduringOfficeHoursvalue_OR = By.xpath("//*[@id=\"mat-select-18\"]/div/div[1]/span/span");
	private final String Send_RedAlertsduringOfficeHoursvalue_S = "Send RedAlerts during OfficeHours value  ";
	
	private final By SendRedAlertsafterOfficeHoursto_OR = By.xpath("//*[@id=\"redAlertsAfterOffice\"]/div/div[1]/span/span");
	private final String SendRedAlertsafterOfficeHoursto_S = "Send RedAlerts After OfficeHours value  ";
	
	
//	private final By additionalAlertNotif_Second_Add_noselection_link_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[2]/div/div[2]/div/a");
//	private final String additionalAlertNotif_First_Add_noselection_link_S = "Add / Remove Link - when nothing selected";
//
//	private final By additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[2]/div/div[3]/div/a");
//	private final String additionalAlertNotif_2nd_AddOrRemove_link_notiftypeSelected_S = "Second Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_3rd_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[3]/div/div[3]/div/a");
//	private final String additionalAlertNotif_3rd_AddOrRemove_link_notiftypeSelected_S = "Third Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_4th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[4]/div/div[3]/div/a");
//	private final String additionalAlertNotif_4th_AddOrRemove_link_notiftypeSelected_S = "Fourth Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_5th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[5]/div/div[3]/div/a");
//	private final String additionalAlertNotif_5th_AddOrRemove_link_notiftypeSelected_S = "Fifth Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_6th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[6]/div/div[3]/div/a");
//	private final String additionalAlertNotif_6th_AddOrRemove_link_notiftypeSelected_S = "Sixth Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_7th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[7]/div/div[3]/div/a");
//	private final String additionalAlertNotif_7th_AddOrRemove_link_notiftypeSelected_S = "Seventh Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_8th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[8]/div/div[3]/div/a");
//	private final String additionalAlertNotif_8th_AddOrRemove_link_notiftypeSelected_S = "Eighth Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_9th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[9]/div/div[3]/div/a");
//	private final String additionalAlertNotif_9th_AddOrRemove_link_notiftypeSelected_S = "Nineth Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_10th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[10]/div/div[3]/div/a");
//	private final String additionalAlertNotif_10th_AddOrRemove_link_notiftypeSelected_S = "Tenth Add / Remove Link after selecting Notification";
//
//	private final By additionalAlertNotif_11th_AddOrRemove_link_notif_typeSelected_OR = By
//			.xpath("//div[@id=\"additionalAlerts\"]/div/div/div[11]/div/div[2]/div/a");
//	private final String additionalAlertNotif_11th_AddOrRemove_link_notiftypeSelected_S = "Tenth Add / Remove Link after selecting Notification";
	//Shafiya added below xpaths 16/02/2022
	private final By additionalAlertNotif_1st_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[1]");
	private final String additionalAlertNotif_1st_Remove_link_notif_typeSelected_S = "1st Remove Link after selecting Notification";
	private final By additionalAlertNotif_2nd_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[2]");
	private final String additionalAlertNotif_2nd_Remove_link_notif_typeSelected_S = "2nd Remove Link after selecting Notification";

	private final By additionalAlertNotif_3rd_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[3]");
	private final String additionalAlertNotif_3rd_Remove_link_notif_typeSelected_S = "3rd Remove Link after selecting Notification";

	private final By additionalAlertNotif_4th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[4]");
	private final String additionalAlertNotif_4th_Remove_link_notif_typeSelected_S = "4th Remove Link after selecting Notification";

	private final By additionalAlertNotif_5th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[5]");
	private final String additionalAlertNotif_5th_Remove_link_notif_typeSelected_S = "5th Remove Link after selecting Notification";

	private final By additionalAlertNotif_6th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[6]");
	private final String additionalAlertNotif_6th_Remove_link_notif_typeSelected_S = "6th Remove Link after selecting Notification";

	private final By additionalAlertNotif_7th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[7]");
	private final String additionalAlertNotif_7th_Remove_link_notif_typeSelected_S = "7th Remove Link after selecting Notification";

	private final By additionalAlertNotif_8th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[8]");
	private final String additionalAlertNotif_8th_Remove_link_notif_typeSelected_S = "8th Remove Link after selecting Notification";

	private final By additionalAlertNotif_9th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[9]");
	private final String additionalAlertNotif_9th_Remove_link_notif_typeSelected_S = "9th Remove Link after selecting Notification";

	private final By additionalAlertNotif_10th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[10]");
	private final String additionalAlertNotif_10th_Remove_link_notif_typeSelected_S = "10th Remove Link after selecting Notification";

	private final By additionalAlertNotif_11th_Remove_link_notif_typeSelected_OR = By
			.xpath("(//div[@id='additionalAlerts']//a[@id='remove'])[11]");
	private final String additionalAlertNotif_11th_Remove_link_notif_typeSelected_S = "11th Remove Link after selecting Notification";


	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Email_drpdwn_OR = By
			.xpath("//div[@id='selectedNotif-panel']/mat-option[@id='Email']");
	private final String additionalAlertNotif_sendNotif_Email_drpdwn_S = "Send Notification drop down -> Email";

	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Email_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='email'])[1]");
	private final String additionalAlertNotif_sendNotif_Email_input_S = "Send Notification Email Input box";

	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Fax_drpdwn_OR = By
			.xpath("//div[@id='selectedNotif-panel']/mat-option[@id='Fax']");
	private final String additionalAlertNotif_sendNotif_Fax_drpdwn_S = "Send Notification drop down -> Fax";

	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Fax_cntry_code_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='faxCountryCd_countryCode'])[1]");
	private final String additionalAlertNotif_sendNotif_Fax_cntry_code_input_S = "Send Notification Fax - Country Code Input box";

	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Fax_area_code_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='faxAreaCd_areaCode'])[1]");
	private final String additionalAlertNotif_sendNotif_Fax_area_code_input_S = "Send Notification Fax - Area Code Input box";

	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Fax_phn_nbr_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='faxNum_phoneNum'])[1]");
	private final String additionalAlertNotif_sendNotif_Fax_phn_nbr_input_S = "Send Notification Fax - Phone Number Input box";

	//shafiya modified xpath 15/02/2022
	private final By additionalAlertNotif_sendNotif_Text_drpdwn_OR = By
			.xpath("//div[@id='selectedNotif-panel']/mat-option[@id='Text Message']");
	private final String additionalAlertNotif_sendNotif_Text_drpdwn_S = "Send Notification drop down -> Text";
	private final By additionalAlertNotif_sendNotif_Text_Input_OR = By
			.xpath("(//div[@id='additionalAlerts']//input[@id='textMessage'])[1]");
	private final String additionalAlertNotif_sendNotif_Text_Input_S = "Send Notification Text Message - Text Message Input box";
	//shafiya modified xpath 16/02/2022
	private final By additionalAlertNotif_sendNotif_Text_2nd_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[2]");
	private final String additionalAlertNotif_sendNotif_Text_2nd_input_S = "2nd Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_3rd_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[3]");
	private final String additionalAlertNotif_sendNotif_Text_3rd_input_S = "3rd Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_4th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[4]");
	private final String additionalAlertNotif_sendNotif_Text_4th_input_S = "4th Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_5th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[5]");
	private final String additionalAlertNotif_sendNotif_Text_5th_input_S = "5th Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_6th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[6]");
	private final String additionalAlertNotif_sendNotif_Text_6th_input_S = "6th Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_7th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[7]");
	private final String additionalAlertNotif_sendNotif_Text_7th_input_S = "7th Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_8th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[8]");
	private final String additionalAlertNotif_sendNotif_Text_8th_input_S = "8th Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_9th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[9]");
	private final String additionalAlertNotif_sendNotif_Text_9th_input_S = "9th Send Notification Text Input box";

	private final By additionalAlertNotif_sendNotif_Text_10th_input_OR = By.xpath(
			"(//div[@id='additionalAlerts']//input[@id='textMessage'])[10]");
	private final String additionalAlertNotif_sendNotif_Text_10th_input_S = "10th Send Notification Text Input box";
	
	//private final By radioButtonYellow_OR=By.xpath("//mat-radio-group//*[@id='yellowButton']");
	//private final String radioButtonYellow_S="Yellow radio button";
	
	/*
	 * private final By additionalAlertNotif_sendNotif_Text_input_2_OR =
	 * By.xpath("//input[@id=\"mat-input-32\"]"); private final String
	 * additionalAlertNotif_sendNotif_Text_input_2_S =
	 * "Send Notification Text Input box";
	 */
	
	private final By alertType_OR =By.xpath("//*[@id=\"merlinAlertType\"]/div/div[2]/div/div[1]");
	private final String alertTyp_S = "AlertType";

	//private final By redRadioButton_OR =By.xpath("//*[@id=\"merlinAlertType\"]/div/div[2]/div[i]/div[2]/MAT-RADIO-GROUP/DIV/DIV[1]");
	private final By redRadioButton_OR =By.xpath("//*[@id=\"merlinAlertType\"]/div/div[2]/div/div[2]/MAT-RADIO-GROUP/DIV/DIV[1]/MAT-RADIO-BUTTON//input");
	private final String redRadioButton_S = "RedRadioButton";

	private final By yellowRadioButton_OR =By.xpath("//div[@id='merlinAlertType']/div/div[2]/div/div[2]/MAT-RADIO-GROUP/DIV/DIV[2]/MAT-RADIO-BUTTON//input");
	private final String yellowRadioButton_S = "YellowRadioButton";

	private final By offRadioButton_OR =By.xpath("//div[@id='merlinAlertType']/div/div[2]/div/div[2]/MAT-RADIO-GROUP/DIV/DIV[3]/MAT-RADIO-BUTTON//input");
	private final String offRadioButton_S = "OFFRadioButton";

	private final By informPatientChkBox_OR =By.xpath("//div[@id='merlinAlertType']/div/div[2]/div/div[3]/div/MAT-CHECKBOX//input");
	private final String informPatientChkBox_S = "InformPatientChkBox";

	private final By additionalAlertNotif_sendNotif_None_drpdwn_OR = By
			.xpath("//mat-option[@id=\"mat-option-284\"]/span");
	private final String additionalAlertNotif_sendNotif_None_drpdwn_S = "Send Notification drop down -> None";
	
	private final By showDevicesLink_OR = By.xpath("//div[@id='merlin-home-wrapper']//div/a");
	private final String showDevicesLink_S = "ShowDevices Link";
	
	private final By merlinAlertType_OR=By.xpath(".//div[@id='merlinAlertType']//div[@formarrayname='alertTypes']//mat-label");

	private final By expandAlert_OR =By.xpath("//span[@class='ng-star-inserted' and contains(text(),'+')]");
	private final String expandAlert_S="expanding Alert Name under Lead Assurance";

	private final By allMerlinHomeAlert_OR=By.xpath("(//div[@formarrayname='alertTypes']//mat-label)");
	private final String allMerlinHomeAlert_S="Merlin@Home Alert Name";
	//Shafiya Added these xpath for the tc: $_11_0_WA_EP_Alert_Sub_Categories
	//private final String allMerlinHomeAlert_S="Merlin@Home Alert Name";
	private final String merlinHomeAlertType_OR = "//div[@formarrayname='alertTypes']//mat-label[contains(text(),'{0}')]";
	private final String merlinHomeAlertType_S = "Merlin@Home Alert Type";
	private final By editButton_OR = By.xpath("//button[@id='edit']");
	private final String editButton_S = "Edit Button";
	private final String merlinHomeAlertTypeLabel_OR = "//div[@formarrayname='alertTypes']//mat-label[contains(text(),'{0}')]/ancestor::div[2]";
	private final By collapseAlert_OR = By.xpath("//div[@formarrayname='alertTypes']//mat-label[contains(text(),'LeadAssurance')]/ancestor::div[1]/child::span[1]//span[contains(text(),'-')]");
	private final String collapseAlert_S  ="Collapsing Alert Name under Lead Assurance";
	
	
	public String xPathAlertType(String rowNum) {
		String xPath ="";
		String xPath1 ="";
		String xPath2 ="";
		String xPathV ="";
		xPath =" //*[@id=\"merlinAlertType\"]/div/div[2]/div[1]/div[1]/MAT-LABEL";
		xPath1 =" //*[@id=\"merlinAlertType\"]/div/div[2]/div[";
		xPathV =rowNum;
		xPath2="]/div[1]/MAT-LABEL";
		xPath=xPath1.concat(xPathV).concat(xPath2);
		
		
		return xPath;
		
	}
	
	public boolean selectAlert(String AlertType) {
		boolean flag=false;
		String xpath1="";
		String xpath2="";
		String xpath_yellow="//mat-radio-group//*[@id='yellowButton']";
		String xpath_Red="//mat-radio-group//*[@id='redButton']";
		List<WebElement> li=driver.findElements(merlinAlertType_OR);
		for(int i=1;i<=li.size();i++) {

		if(li.get(i).getText().contains(AlertType)) {

		flag=true;
		int alertindex=i;
		System.out.println(alertindex);
		xpath1="("+xpath_yellow+")"+"["+alertindex+"]";
		xpath2="("+xpath_Red+")"+"["+alertindex+"]";
		WebElement redAlertRadio=driver.findElement(By.xpath(xpath2));
		if(redAlertRadio.isEnabled()) {
		WebElement yellowAlertRadio=driver.findElement(By.xpath(xpath1));
		scrollToViewWebElementWithoutReport(yellowAlertRadio, "Scroll down to validate all types of alerts");
		System.out.println(xpath1);
		yellowAlertRadio.click();
		extentReport.reportScreenShot("Alert Category changed to Standard for the alert type: "+ AlertType);
		}
		else {
		redAlertRadio.click();
		extentReport.reportScreenShot("Alert Category changed to Urgent for the alert type: "+ AlertType);
		}
				break;
				
			
				
				
				
			}
		}
		
		return flag;
		
		
	}
	
	
	
  public boolean disableAlert(String AlertType) {
	  boolean flag=false;
	  String xpath1="";
		String xpath_off="//mat-radio-group//*[@id='offButton']";
		List<WebElement> li=driver.findElements(merlinAlertType_OR);
		for(int i=1;i<=li.size();i++) {
	    if(li.get(i).getText().contains(AlertType)) {
				
				flag=true;
				int alertindex=i;
				System.out.println(alertindex);
				xpath1="("+xpath_off+")"+"["+alertindex+"]";
				WebElement OffAlertRadio=driver.findElement(By.xpath(xpath1));
				scrollToViewWebElementWithoutReport(OffAlertRadio, "Scroll down to validate all types of alerts");
				System.out.println(xpath1);
				OffAlertRadio.click();
				extentReport.reportScreenShot("Yellow radio button is selected");
	            break;
	  
	  
  }
	
		}
		return flag;
  }
		
  
  
  
  public boolean verifyRedAlert() {
		Boolean alert=false;
		if(visibilityOfElementLocatedWithReport(red_Alert_OR,red_Alert_S)) {
			alert=true;
			
		}
		
		return alert;
	}
  private final By medicalteamnotificationsettingafterhours_OR =By.xpath("//*[@id=\"medicalTeamAlerts\"]/div/div[1]/span/span");
  private final String medicalteamnotificationsettingafterhours_S = "medical team notification setting afterhours";
	
	private final By OnCallPhysiciancontactinformation_OR =By.xpath("//*[@id=\"onCallPhysician\"]/div/div[1]/span/span");
  private final String OnCallPhysiciancontactinformation_S = "OnCall Physician contact information";


public Boolean medicalteamnotificationsettingafterhours() {
		//String alert =getText(medicalteamnotificationsettingafterhours_OR,medicalteamnotificationsettingafterhours_S);
		Boolean alert=false;
		if(visibilityOfElementLocatedWithReport(medicalteamnotificationsettingafterhours_OR,medicalteamnotificationsettingafterhours_S)) {
			alert=true;
			
		}
		
		return alert;
	}

public Boolean OnCallPhysiciancontactinformation() {
		//String alert =getText(OnCallPhysiciancontactinformation_OR,OnCallPhysiciancontactinformation_S);
	Boolean alert=false;
	if(visibilityOfElementLocatedWithReport(OnCallPhysiciancontactinformation_OR,OnCallPhysiciancontactinformation_S)) {
		alert=true;
		
	}
	
	return alert;
	}
  
    private final By yelloAlertsDuringOffice_OR =By.xpath("//*[@id=\"yellowAlertsDuringOffice\"]/div/div[1]/span/span");
    private final String yelloAlertsDuringOffice_S = "RedRadioButton";
	
	private final By yelloAlertsAfterOffice_OR =By.xpath("//*[@id=\"yellowAlertsAfterOffice\"]/div/div[1]/span/span");
    private final String yelloAlertsAfterOffice_S = "RedRadioButton";


  public String yellowalertduringofficehours() {
		String alert =getText(yelloAlertsDuringOffice_OR,yelloAlertsDuringOffice_S);
		return alert;
	}
  
  public String yellowalertafterofficehours() {
		String alert =getText(yelloAlertsAfterOffice_OR,yelloAlertsAfterOffice_S);
		return alert;
	}
  public String UrgentAlertsduringofficehours() {
		String alert =getText(Send_RedAlertsduringOfficeHoursvalue_OR,Send_RedAlertsduringOfficeHoursvalue_S);
		return alert;
	}
  public String UrgentAlertsAfterofficehours() {
		String alert =getText(SendRedAlertsafterOfficeHoursto_OR,SendRedAlertsafterOfficeHoursto_S);
		return alert;
	}
  public boolean verifyYellowAlert() {
		Boolean alert=false;
		if(visibilityOfElementLocatedWithReport(yellow_alert_OR,yellow_alert_S)) {
			alert=true;
			
		}
		
		return alert;
	}
  
  
  
  
  	//shafiya. Updated the method 15/02/2022
	public boolean verifyAdditionAlertNotifSectionDisplayed() throws Exception{
		Boolean isDisplayed = false;

		if (isElementNotPresentWithoutReport(additionalAlertNotificationHeading_OR, additionalAlertNotificationHeading_S)) {
			isDisplayed = false; 
		} 
		if (isElementNotPresentWithoutReport(additionalAlertNotificationIcon_OR, additionalAlertNotificationIcon_S)) {
			isDisplayed = false;;
		} else {
			expandAdditionalAlertNotif_section();
			if (isElementPresent(additionalAlertNotification_section_text_OR,  additionalAlertNotification_section_text_S)
					&& isDisplayedWithoutReport(additionalAlertNotification_section_text_OR,additionalAlertNotification_section_text_S ) ) {
				isDisplayed = true;
			} else {
				isDisplayed = false;
			}
		}
		return isDisplayed;

	}
	//shafiya added this method. This method expands the additional alert Notification section added on 15/02/2022
	public void expandAdditionalAlertNotif_section() throws Exception{
		if(isElementPresent(additionalAlertNotificationIcon_OR, additionalAlertNotificationIcon_S)) {
			clickElement(additionalAlertNotificationIcon_OR, additionalAlertNotificationIcon_S);
		}
	}

	public void openEditAdditonalNotificationSection() {
		clickElement(edit_Button_OR, edit_Button_S);
		scrollToViewWithReport(additionalAlertNotificationIcon_OR, additionalAlertNotificationIcon_S);
		// clickElementWithReport(additionalAlertNotificationIcon_OR,additionalAlertNotificationIcon_S);
		//scrollToViewWithReportScreenshot(additionalAlertNotification_section_OR, additionalAlertNotification_section_S);
		try {
			waitForLoading();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void openEditAdditonalNotificationSectioon() throws InterruptedException {
		scrollToView(edit_Button_OR);
		waitForLoading();
		extentReport.reportScreenShot("Clicking Edit Button ");
		waitForLoading();
		clickElement(edit_Button_OR, edit_Button_S);
		//scrollToView(additionalAlertNotificationIcon_OR);
		scrollToView(additionalAlertNotification_section_OR);
		extentReport.reportScreenShot("additionalAlertNotification_section ");
		try {
			waitForLoading();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	//shafiya commented and written new method 16/02/2022
//	public String verifyFirstAddLinkAfter_openEditAdditonalNotificationSection() {
//		String text = "Add link is available";
//		String notext = "Add link is NOT available";
//		scrollToViewWithReport(additionalAlertNotif_Second_Add_noselection_link_OR,
//				additionalAlertNotif_First_Add_noselection_link_S);
//		try {
//			waitForLoading();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		if (isDisplayed(additionalAlertNotif_Second_Add_noselection_link_OR)) {
//			return text;
//		} else {
//			return notext;
//		}
//	}
	//shafiya updated method  15/Feb/2022
	public String verifyNotificationMethods_in_sendNotifications_drpdwn() {
		String eMethod = "";
		String fMethod = "";
		String tMethod = "";
		//shafiya changed the xpath 15/Feb/2022
		clickElement(additionalAlertNotif_sendNotif_1st_select_Arrow_OR, additionalAlertNotif_sendNotif_1st_select_Arrow_S);

		if (isDisplayed(additionalAlertNotif_sendNotif_Email_drpdwn_OR)) {
			eMethod = "Email Available|";
		} else {
			eMethod = "Email NOT Available";
		}
		if (isDisplayed(additionalAlertNotif_sendNotif_Fax_drpdwn_OR)) {
			fMethod = "Fax Available|";
		} else {
			fMethod = "Fax NOT Available";
		}
		if (isDisplayed(additionalAlertNotif_sendNotif_Text_drpdwn_OR)) {
			tMethod = "Text Message Available|";
		} else {
			tMethod = "Text Message NOT Available";
		}

		return eMethod + fMethod + tMethod;

	}
	
	private final By ALERTTYPE_OR = By.xpath("//*[@id=\"merlinAlertType\"]/div/div[2]/div/div[1]");
	private final String ALERTTYPE_S = "Alert Type";
	private final By ALERTCLASSIFICATION_OR = By.xpath("//*[@id=\"merlinAlertType\"]/div/div[2]/div/div[2]");
	private final String ALERTCLASSIFICATION_S = "Alert Classfication";
	private final By INFORMPATIENT_OR = By.xpath("(//*[@id=\"merlinAlertType\"]/div/div[2]/div/div[3]//mat-checkbox");
	private final String INFORMPATIENT_S = "Inform Pattient";
	
	public boolean verifyAlertTypelist() throws Exception {
		Boolean isdisplayed = false;
		scrollToView(ALERTTYPE_OR);
		//clickElement(additionalAlertNotif_sendNotif_1st_select_Arrow_OR, additionalAlertNotif_sendNotif_1st_select_Arrow_S);
		if (isDisplayedWithoutReport(ALERTTYPE_OR, ALERTTYPE_S) && isDisplayedWithoutReport(ALERTCLASSIFICATION_OR, ALERTCLASSIFICATION_S) ) 
			isdisplayed = true;
				
		else
			isdisplayed = false;
			
	
		
		return isdisplayed;
	}
	//Shafiya added below for tc:WA_96_ClinicAdmin_ICDAlertsPage 15/02/2022
	public boolean verifySendNotificationAlert_defaultBlank() throws Exception {
		Boolean isdefaultSendNotifBlank = false;
		//clickElement(additionalAlertNotif_sendNotif_1st_select_Arrow_OR, additionalAlertNotif_sendNotif_1st_select_Arrow_S);
		String defalutValue = getText(additionalAlertNotif_sendNotif_default_Value_OR, additionalAlertNotif_sendNotif_default_Value_S);
		if (defalutValue.equals(""))
			isdefaultSendNotifBlank = true;
		else 
			isdefaultSendNotifBlank = false;
		return isdefaultSendNotifBlank;
	}
	//shafiya added below code 15/02/2022
	public boolean isTexboxdisplayed_ForOptions_inSendNotificatonAlertList(String option) {
		Boolean isdisplayed = false;
		clickElement(additionalAlertNotif_sendNotif_1st_select_Arrow_OR, additionalAlertNotif_sendNotif_1st_select_Arrow_S);
		
		try {
			switch(option) {
			case "Email":
				clickElement(additionalAlertNotif_sendNotif_Email_drpdwn_OR, additionalAlertNotif_sendNotif_Email_drpdwn_S);
				if (isElementPresent(additionalAlertNotif_sendNotif_Email_input_OR, additionalAlertNotif_sendNotif_Email_input_S)
						&& isDisplayedWithoutReport(additionalAlertNotif_sendNotif_Email_input_OR, additionalAlertNotif_sendNotif_Email_input_S)) 
					isdisplayed = true;
				
				break;
			case "Fax":
				clickElement(additionalAlertNotif_sendNotif_Fax_drpdwn_OR, additionalAlertNotif_sendNotif_Fax_drpdwn_S);
				if (isElementPresent(additionalAlertNotif_sendNotif_Fax_cntry_code_input_OR, additionalAlertNotif_sendNotif_Fax_cntry_code_input_S)
						&& isDisplayedWithoutReport(additionalAlertNotif_sendNotif_Fax_cntry_code_input_OR, additionalAlertNotif_sendNotif_Fax_cntry_code_input_S)
						&& isElementPresent(additionalAlertNotif_sendNotif_Fax_area_code_input_OR, additionalAlertNotif_sendNotif_Fax_area_code_input_S)
						&& isDisplayedWithoutReport(additionalAlertNotif_sendNotif_Fax_area_code_input_OR, additionalAlertNotif_sendNotif_Fax_area_code_input_S)
						&& isElementPresent(additionalAlertNotif_sendNotif_Fax_phn_nbr_input_OR, additionalAlertNotif_sendNotif_Fax_phn_nbr_input_S)
						&& isDisplayedWithoutReport(additionalAlertNotif_sendNotif_Fax_phn_nbr_input_OR, additionalAlertNotif_sendNotif_Fax_phn_nbr_input_S))				
					isdisplayed = true;
				break;
			case "TextMessage":
				clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
				if (isElementPresent(additionalAlertNotif_sendNotif_Text_Input_OR, additionalAlertNotif_sendNotif_Text_Input_S)
						&& isDisplayedWithoutReport(additionalAlertNotif_sendNotif_Text_Input_OR, additionalAlertNotif_sendNotif_Text_Input_S))			
					isdisplayed = true;
				break;
			
			}
			return isdisplayed;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}			
	}
	public boolean isAddLinkAvailable() {
		Boolean isAvailable = false;
		if (isElementPresent(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S ) 
				&& isDisplayedWithoutReport(additionalAlertNotif_Add_link_OR, additionalAlertNotif_Add_link_S)) {
			isAvailable = true;
		} 
		return isAvailable;
	}	
	
	public boolean verifyOFFAndCheckBox() throws InterruptedException
	{
		boolean checked =false;
		@SuppressWarnings("unused")
		boolean enabled = true;
		List<WebElement> alterTypes=findElementslist(alertType_OR,alertTyp_S);
		List<WebElement> Off=findElementslist(offRadioButton_OR,offRadioButton_S);
		List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
		for(int i=0;i<alterTypes.size();i++)
		{				
			checked=Off.get(i).isSelected();
			if(checked==true) {
				System.out.println("Alert Type Name --->"+alterTypes.get(i).getText());
				enabled=informPatient.get(i).isEnabled();	
				System.out.println("Actual informPatient  check box Enabled Value is "+enabled);
				enabled=!informPatient.get(i).isEnabled();	
				System.out.println("Later informPatient  check box Enabled Value is "+enabled);
				System.out.println("Is informPatient check  box is  NON Editable--->"+enabled);
				break;
			}
		}
		return enabled;
	}
	
	public boolean  alertNotificationEditModeVerify(String alertType, String verify) throws InterruptedException
	{
		boolean editable =false;
		List<WebElement> alterTypes=findElementslist(alertType_OR,alertTyp_S);
		for(int i=0;i<alterTypes.size();i++)
		{
			//System.out.println("Serial NO.:  "+i+" Name:  "+alterTypes.get(i).getText());
			//System.out.println("Comparing with :    "+alertType);
			if(alterTypes.get(i).getText().toLowerCase().trim().contains(alertType.toLowerCase().trim()))
			{	
				switch(verify) {
				case "Red":
					List<WebElement> Red=findElementslist(redRadioButton_OR,redRadioButton_S);
					editable=Red.get(i).isEnabled();
					System.out.println("Is RED Radio Button check Editable --->"+editable);
					break;
				case "Yellow":
					List<WebElement> Yellow=findElementslist(yellowRadioButton_OR,yellowRadioButton_S);
					editable=Yellow.get(i).isEnabled();
					System.out.println("Is YELLOW Radio Button check Editable --->"+editable);
					break;
				case "Off":
					List<WebElement> Off=findElementslist(offRadioButton_OR,offRadioButton_S);
					editable=Off.get(i).isEnabled();
					System.out.println("Is OFF Radio Button check Editable--->"+editable);
					break;
				case "InformPatient":
					List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
					editable=informPatient.get(i).isEnabled();
					System.out.println("Is InformPatient Check Box check Editable --->"+editable);
					break;
				}
			}
		}
		return editable;
	}

	//shafiya commented this and written new code 15/02/2022
//	public String verifySendNotificationAlert_defaultBlank() {
//		String listdefault = "";
//
//		if (getText(additionalAlertNotif_sendNotif_select_text_OR, additionalAlertNotif_sendNotif_select_text_S)
//				.equals("Send Notifications To")) {
//			listdefault = "Default is Blank";
//
//		} else {
//
//			listdefault = "Default is NOT Blank";
//
//		}
//
//		return listdefault;
//
//	}
	//shafiya commented this and written new code 15/02/2022
//	public String verifyEmailSelectionInSendNotificationAlertList() {
//		String eresult = "";
//		String addlinkresult = "";
//
//		clickElement(additionalAlertNotif_sendNotif_2nd_select_OR, additionalAlertNotif_sendNotif_2nd_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Email_drpdwn_OR, additionalAlertNotif_sendNotif_Email_drpdwn_S);
//
//		if (isDisplayed(additionalAlertNotif_sendNotif_Email_input_OR)) {
//			eresult = "Email Input Box Available - ";
//		} else {
//			eresult = "Email Input Box NOT Available - ";
//		}
//
//		if (isDisplayed(additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR)) {
//			addlinkresult = "Add Link Available";
//		} else {
//			addlinkresult = "Add Link NOT Available";
//		}
//
//		return eresult + addlinkresult;
//
//	}
//
//	public String verifyTextSelectionInSendNotificationAlertList() {
//		String tresult = "";
//		String addlinkresult = "";
//
//		clickElement(additionalAlertNotif_sendNotif_2nd_select_OR, additionalAlertNotif_sendNotif_2nd_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		if (isDisplayed(additionalAlertNotif_sendNotif_Text_2nd_input_OR)) {
//			tresult = "Text Message Input Box Available - ";
//		} else {
//			tresult = "Text Message Input Box NOT Available - ";
//		}
//
//		if (isDisplayed(additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR)) {
//			addlinkresult = "Add Link Available";
//		} else {
//			addlinkresult = "Add Link NOT Available";
//		}
//
//		return tresult + addlinkresult;
//
//	}
//
//	public String verifyFaxSelectionInSendNotificationAlertList() {
//		String fareacode = "";
//		String fcntrycode = "";
//		String fphone = "";
//		String addlinkresult = "";
//
//		clickElement(additionalAlertNotif_sendNotif_2nd_select_OR, additionalAlertNotif_sendNotif_2nd_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Fax_drpdwn_OR, additionalAlertNotif_sendNotif_Fax_drpdwn_S);
//
//		if (isDisplayed(additionalAlertNotif_sendNotif_Fax_cntry_code_input_OR)) {
//			fcntrycode = "Country Code Input Box Available - ";
//		} else {
//			fcntrycode = "Country Code Input Box NOT Available - ";
//		}
//
//		if (isDisplayed(additionalAlertNotif_sendNotif_Fax_area_code_input_OR)) {
//			fareacode = "Area Code Input Box Available - ";
//		} else {
//			fareacode = "Area Code Input Box NOT Available - ";
//		}
//
//		if (isDisplayed(additionalAlertNotif_sendNotif_Fax_phn_nbr_input_OR)) {
//			fphone = "Phone Input Box Available - ";
//		} else {
//			fphone = "Phone Input Box NOT Available - ";
//		}
//
//		if (isDisplayed(additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR)) {
//			addlinkresult = "Add Link Available";
//		} else {
//			addlinkresult = "Add Link NOT Available";
//		}
//
//		return fcntrycode + fareacode + fphone + addlinkresult;
//
//	}

	//shafiya modified the method- 15/02/2022
	public boolean isTextMessageAdded_SendNotification() throws Exception{
		Boolean isTexAddedwithRemoveLink = false;
		String expectedText = "Hi";
		//clickElement(additionalAlertNotif_sendNotif_2nd_select_OR, additionalAlertNotif_sendNotif_2nd_select_S);
		clickElement(additionalAlertNotif_sendNotif_1st_select_Arrow_OR, additionalAlertNotif_sendNotif_1st_select_Arrow_S);		
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

//			sendKeys(additionalAlertNotif_sendNotif_Text_2nd_input_OR, additionalAlertNotif_sendNotif_Text_2nd_input_S,
//					"Some Text");
		sendKeys(additionalAlertNotif_sendNotif_Text_Input_OR, additionalAlertNotif_sendNotif_Text_Input_S, expectedText);
		

//			clickElement(additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR,
//					additionalAlertNotif_2nd_AddOrRemove_link_notiftypeSelected_S);
		
		clickElement(additionalAlertNotif_Add_link_OR,
				additionalAlertNotif_Add_link_S);
		String removeText = getText(additionalAlertNotif_1st_Remove_link_notif_typeSelected_OR,
				additionalAlertNotif_1st_Remove_link_notif_typeSelected_S);
		String textMsgAfterAdd = getText(additionalAlertNotif_sendNotif_Text_Input_OR,
				additionalAlertNotif_sendNotif_Text_Input_S);
		if (removeText.equals("Remove") && textMsgAfterAdd.equals(expectedText)) {
			isTexAddedwithRemoveLink = true;
			
		}

		return isTexAddedwithRemoveLink;

	}
	//shafiya added the method 16/02/2022
	public boolean isEmailTextAdded_SendNotification() throws Exception{
		Boolean isEmailAddedwithRemoveLink = false;
		String expectedEmail = "varsha.sha@abbott.com";
		String expectedRemoveText = "Remove";
		clickElement(additionalAlertNotif_sendNotif_2nd_select_Arrow_OR, additionalAlertNotif_sendNotif_2nd_select_Arrow_S);		
		clickElement(additionalAlertNotif_sendNotif_Email_drpdwn_OR, additionalAlertNotif_sendNotif_Email_drpdwn_S);
		
		sendKeys(additionalAlertNotif_sendNotif_Email_input_OR, additionalAlertNotif_sendNotif_Email_input_S, expectedEmail);	
		
		clickElement(additionalAlertNotif_Add_link_OR, additionalAlertNotif_Add_link_S);
		
		String actualRemoveText = getText(additionalAlertNotif_2nd_Remove_link_notif_typeSelected_OR,
				additionalAlertNotif_2nd_Remove_link_notif_typeSelected_S);
		String actualEmailText = getText(additionalAlertNotif_sendNotif_Email_input_OR,
				additionalAlertNotif_sendNotif_Email_input_S);
		if (actualRemoveText.equals(expectedRemoveText) && actualEmailText.equals(expectedEmail)) {
			isEmailAddedwithRemoveLink = true;
		}

		return isEmailAddedwithRemoveLink;

	}
	//shafiya added the method 16/02/2022	
	public boolean isFaxAdded_SendNotification() throws Exception{
		Boolean isFaxAddedwithRemoveLink = false;
		String expectedFaxAreacode = "222";
		String expectedFaxCountrycode = "1";
		String expectedFaxNumber = "2222222";
		String expectedRemoveText = "Remove";
		clickElement(additionalAlertNotif_sendNotif_3rd_select_Arrow_OR, additionalAlertNotif_sendNotif_2nd_select_Arrow_S);		
		clickElement(additionalAlertNotif_sendNotif_Fax_drpdwn_OR, additionalAlertNotif_sendNotif_Fax_drpdwn_S);
		
		sendKeys(additionalAlertNotif_sendNotif_Fax_cntry_code_input_OR, additionalAlertNotif_sendNotif_Fax_cntry_code_input_S, expectedFaxCountrycode);	
		sendKeys(additionalAlertNotif_sendNotif_Fax_area_code_input_OR, additionalAlertNotif_sendNotif_Fax_area_code_input_S, expectedFaxAreacode);
		sendKeys(additionalAlertNotif_sendNotif_Fax_phn_nbr_input_OR, additionalAlertNotif_sendNotif_Fax_phn_nbr_input_S, expectedFaxNumber);
		
		clickElement(additionalAlertNotif_Add_link_OR, additionalAlertNotif_Add_link_S);
		
		String actualRemoveText = getText(additionalAlertNotif_3rd_Remove_link_notif_typeSelected_OR,
				additionalAlertNotif_3rd_Remove_link_notif_typeSelected_S);
		String actualFaxAreaCode = getText(additionalAlertNotif_sendNotif_Fax_area_code_input_OR,additionalAlertNotif_sendNotif_Fax_area_code_input_S);
		String actualFaxCountryCode = getText(additionalAlertNotif_sendNotif_Fax_cntry_code_input_OR,additionalAlertNotif_sendNotif_Fax_cntry_code_input_S);
		String actualFaxNumber = getText(additionalAlertNotif_sendNotif_Fax_phn_nbr_input_OR,additionalAlertNotif_sendNotif_Fax_phn_nbr_input_S);
		if (actualRemoveText.equals(expectedRemoveText) && actualFaxAreaCode.equals(expectedFaxAreacode) 
				&& actualFaxCountryCode.equals(expectedFaxCountrycode) && actualFaxNumber.equals(expectedFaxNumber)) {
			isFaxAddedwithRemoveLink = true;
		}

		return isFaxAddedwithRemoveLink;

	}
	//shafiya added this method 16/02/2022
	public boolean verifyCanAddOnly10NotificationAlertS() throws Exception{
		Boolean isMorethan10NotifsAdded = false;
		String text1 ="Hello";
		String text2 = "How are you";
		String text3 = "aaa";
		String text4 = "bbb";
		String text5 = "ccc";
		String text6 = "ddd";
		String text7 = "eee";

		//1st
		if(isTextMessageAdded_SendNotification())
			extentReport.reportScreenShot("1st Alert Notification is addedd successfully");
		//2nd
		if(isEmailTextAdded_SendNotification())
			extentReport.reportScreenShot("2nd Alert Notification is addedd successfully");
		//3rd
		if(isFaxAdded_SendNotification())
			extentReport.reportScreenShot("3rd Alert Notification is addedd successfully");
		// 4th

		clickElement(additionalAlertNotif_sendNotif_4th_select_Arrow_OR, additionalAlertNotif_sendNotif_4th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_2nd_input_OR, additionalAlertNotif_sendNotif_Text_2nd_input_S,text1);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		
		String removeText4 = getText(additionalAlertNotif_4th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_4th_Remove_link_notif_typeSelected_S);
		String actualtext1 = getText(additionalAlertNotif_sendNotif_Text_2nd_input_OR, additionalAlertNotif_sendNotif_Text_2nd_input_S);
		if (removeText4.equals("Remove") && actualtext1.equals(text1)) {
			extentReport.reportScreenShot("4th Alert Notification is addedd successfully");
		}

		// 5th

		clickElement(additionalAlertNotif_sendNotif_5th_select_Arrow_OR, additionalAlertNotif_sendNotif_5th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_3rd_input_OR, additionalAlertNotif_sendNotif_Text_3rd_input_S,text2);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		String removeText5 = getText(additionalAlertNotif_5th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_5th_Remove_link_notif_typeSelected_S);
		String actualtext2 = getText(additionalAlertNotif_sendNotif_Text_3rd_input_OR, additionalAlertNotif_sendNotif_Text_3rd_input_S);
		if (removeText5.equals("Remove") && actualtext2.equals(text2)) {
			extentReport.reportScreenShot("5th Alert Notification is addedd successfully");
		}
		// 6th

		clickElement(additionalAlertNotif_sendNotif_6th_select_Arrow_OR, additionalAlertNotif_sendNotif_6th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_4th_input_OR, additionalAlertNotif_sendNotif_Text_4th_input_S,text3);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		String removeText6 = getText(additionalAlertNotif_6th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_6th_Remove_link_notif_typeSelected_S);
		String actualtext3 = getText(additionalAlertNotif_sendNotif_Text_4th_input_OR, additionalAlertNotif_sendNotif_Text_4th_input_S);
		if (removeText6.equals("Remove") && actualtext3.equals(text3)) {
			extentReport.reportScreenShot("6th Alert Notification is addedd successfully");
		}
		// 7th

		clickElement(additionalAlertNotif_sendNotif_7th_select_Arrow_OR, additionalAlertNotif_sendNotif_7th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_5th_input_OR, additionalAlertNotif_sendNotif_Text_5th_input_S,text4);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		String removeText7 = getText(additionalAlertNotif_7th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_7th_Remove_link_notif_typeSelected_S);
		String actualtext4 = getText(additionalAlertNotif_sendNotif_Text_5th_input_OR, additionalAlertNotif_sendNotif_Text_5th_input_S);
		if (removeText7.equals("Remove") && actualtext4.equals(text4)) {
			extentReport.reportScreenShot("7th Alert Notification is addedd successfully");
		}
		// 8th

		clickElement(additionalAlertNotif_sendNotif_8th_select_Arrow_OR, additionalAlertNotif_sendNotif_8th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_6th_input_OR, additionalAlertNotif_sendNotif_Text_6th_input_S,text5);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		String removeText8 = getText(additionalAlertNotif_8th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_8th_Remove_link_notif_typeSelected_S);
		String actualtext5 = getText(additionalAlertNotif_sendNotif_Text_6th_input_OR, additionalAlertNotif_sendNotif_Text_6th_input_S);
		if (removeText8.equals("Remove") && actualtext5.equals(text5)) {
			extentReport.reportScreenShot("8th Alert Notification is addedd successfully");
		}
		// 9th

		clickElement(additionalAlertNotif_sendNotif_9th_select_Arrow_OR, additionalAlertNotif_sendNotif_9th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_7th_input_OR, additionalAlertNotif_sendNotif_Text_7th_input_S,text6);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		String removeText9 = getText(additionalAlertNotif_9th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_9th_Remove_link_notif_typeSelected_S);
		String actualtext6 = getText(additionalAlertNotif_sendNotif_Text_7th_input_OR, additionalAlertNotif_sendNotif_Text_7th_input_S);
		if (removeText9.equals("Remove") && actualtext6.equals(text6)) {
			extentReport.reportScreenShot("9th Alert Notification is addedd successfully");
		}
		// 10th

		clickElement(additionalAlertNotif_sendNotif_10th_select_Arrow_OR, additionalAlertNotif_sendNotif_10th_select_Arrow_S);
		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);

		sendKeys(additionalAlertNotif_sendNotif_Text_8th_input_OR, additionalAlertNotif_sendNotif_Text_8th_input_S,text7);

		clickElement(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S);
		String removeText10 = getText(additionalAlertNotif_10th_Remove_link_notif_typeSelected_OR,additionalAlertNotif_10th_Remove_link_notif_typeSelected_S);
		String actualtext7 = getText(additionalAlertNotif_sendNotif_Text_8th_input_OR, additionalAlertNotif_sendNotif_Text_8th_input_S);
		if (removeText10.equals("Remove") && actualtext7.equals(text7)) {
			extentReport.reportScreenShot("10th Alert Notification is addedd successfully");
		}
		//Check if 11th notification add option is disabled need to change this once the defec is fixed.

		if (isDisplayedWithoutReport(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S)) {
			if (!isEnabledWithoutReport(additionalAlertNotif_Add_link_OR,additionalAlertNotif_Add_link_S)) {
				isMorethan10NotifsAdded = true;
				scrollToViewWithReport(additionalAlertNotif_Add_link_OR, additionalAlertNotif_Add_link_S);
				extentReport.reportScreenShot("User can't add more than 10 alert Notifications");
			}
		}

		return isMorethan10NotifsAdded;

	}

	//shafiya added the below method 16/02/2022
	public boolean isAlertNotif_Removed()  throws Exception{
		Boolean isAlertNotifRemoved= false;
		
		clickElement(additionalAlertNotif_1st_Remove_link_notif_typeSelected_OR,additionalAlertNotif_1st_Remove_link_notif_typeSelected_S);
		
		if(isElementNotPresentWithoutReport(additionalAlertNotif_1st_Remove_link_notif_typeSelected_OR, additionalAlertNotif_1st_Remove_link_notif_typeSelected_S)
				&& isElementNotPresentWithoutReport(additionalAlertNotif_sendNotif_Text_Input_OR, additionalAlertNotif_sendNotif_Text_Input_S))
			isAlertNotifRemoved = true;
		return isAlertNotifRemoved;
	}

//shafiya commented and written new method 16/02/2022
//	public String verifyCanAddOnly10NotificationAlertS() {
//		String success = "Only 10 Notification Alerts can be added";
//
//		// 2nd
//
//		clickElement(additionalAlertNotif_sendNotif_2nd_select_OR, additionalAlertNotif_sendNotif_2nd_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_2nd_input_OR, additionalAlertNotif_sendNotif_Text_2nd_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_2nd_AddOrRemove_link_notiftypeSelected_S);
//
//		// 3rd
//
//		clickElement(additionalAlertNotif_sendNotif_3rd_select_OR, additionalAlertNotif_sendNotif_3rd_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_3rd_input_OR, additionalAlertNotif_sendNotif_Text_3rd_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_3rd_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_3rd_AddOrRemove_link_notiftypeSelected_S);
//
//		// 4th
//
//		clickElement(additionalAlertNotif_sendNotif_4th_select_OR, additionalAlertNotif_sendNotif_4th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_4th_input_OR, additionalAlertNotif_sendNotif_Text_4th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_4th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_4th_AddOrRemove_link_notiftypeSelected_S);
//
//		// 5th
//
//		clickElement(additionalAlertNotif_sendNotif_5th_select_OR, additionalAlertNotif_sendNotif_5th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_5th_input_OR, additionalAlertNotif_sendNotif_Text_5th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_5th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_5th_AddOrRemove_link_notiftypeSelected_S);
//
//		// 6th
//
//		clickElement(additionalAlertNotif_sendNotif_6th_select_OR, additionalAlertNotif_sendNotif_6th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_6th_input_OR, additionalAlertNotif_sendNotif_Text_6th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_6th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_6th_AddOrRemove_link_notiftypeSelected_S);
//
//		// 7th
//
//		clickElement(additionalAlertNotif_sendNotif_7th_select_OR, additionalAlertNotif_sendNotif_7th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_7th_input_OR, additionalAlertNotif_sendNotif_Text_7th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_7th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_7th_AddOrRemove_link_notiftypeSelected_S);
//
//		// 8th
//
//		clickElement(additionalAlertNotif_sendNotif_8th_select_OR, additionalAlertNotif_sendNotif_8th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_8th_input_OR, additionalAlertNotif_sendNotif_Text_8th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_8th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_8th_AddOrRemove_link_notiftypeSelected_S);
//
//		// 9th
//
//		clickElement(additionalAlertNotif_sendNotif_9th_select_OR, additionalAlertNotif_sendNotif_9th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_9th_input_OR, additionalAlertNotif_sendNotif_Text_9th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_9th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_9th_AddOrRemove_link_notiftypeSelected_S);
//
//		// 10th
//
//		clickElement(additionalAlertNotif_sendNotif_10th_select_OR, additionalAlertNotif_sendNotif_10th_select_S);
//		clickElement(additionalAlertNotif_sendNotif_Text_drpdwn_OR, additionalAlertNotif_sendNotif_Text_drpdwn_S);
//
//		sendKeys(additionalAlertNotif_sendNotif_Text_10th_input_OR, additionalAlertNotif_sendNotif_Text_10th_input_S,
//				"Some Text");
//
//		clickElement(additionalAlertNotif_10th_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_10th_AddOrRemove_link_notiftypeSelected_S);
//		
//		//Check if 11th notification add option available.
//
//		if (isDisplayed(additionalAlertNotif_sendNotif_11th_select_OR)) {
//			if (isEnabled(additionalAlertNotif_sendNotif_11th_select_OR)) {
//				success = "More than 10 Notification Alerts can be added";
//				scrollToView(additionalAlertNotif_sendNotif_11th_select_OR);
//				extentReport.reportScreenShot("11th Add Link is enabled. So, more than 10 Notification Alerts can be added");
//			}
//		}
//
//		return success;
//
//	}
//shafiya commented and written new method 16/02/2022
//	public String removeTextAlert() {
//		String success = "Remove Notification Not Successful";
//		clickElement(additionalAlertNotif_2nd_AddOrRemove_link_notif_typeSelected_OR,
//				additionalAlertNotif_2nd_AddOrRemove_link_notiftypeSelected_S);
//		if (getText(additionalAlertNotif_Second_Add_noselection_link_OR,
//				additionalAlertNotif_First_Add_noselection_link_S).equals("Add")) {
//			success = "Remove Notification Successful";
//		}
//		return success;
//	}
	
	//shafiya added throws and try catch
	public void clickSave() throws Exception{
		try {
			if (visibilityOfElementLocated(saveButton_OR)) {
				elementToBeClickable(saveButton_OR);				
				clickElement(saveButton_OR,saveButton_S);
				extentReport.reportScreenShot("User click on Save Button");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}				
	}
	
	
	
	public void clickCancel() {
		scrollToViewWithReport(cancelButton_OR,cancelButton_S);
		clickElement(cancelButton_OR,cancelButton_S);
	}
	
	public void verifyEditMode() {
		scrollToViewWithoutReport(edit_Button_OR, edit_Button_S);
		clickElement(edit_Button_OR, edit_Button_S);

	}
	
	public void closeMandateAlertMsg() {
		scrollToViewWithReport(mandateAlertMsg_OR,mandateAlertMsg_S);
		clickElement(mandateAlertMsg_OR,mandateAlertMsg_S);
	}
	
	public void selectAlertclassification () {
		scrollToViewWithReport(mandateAlertMsg_OR,mandateAlertMsg_S);
		clickElement(cancelButton_OR,cancelButton_S);
	}
	
	
	public boolean DeselectAllNotifypatient() {
		  boolean flag=false;

			String default_checkedxpath="//input[@id='checkboxes-input' and @aria-checked='true']";
			
			
			List<WebElement> li=driver.findElements(By.xpath(default_checkedxpath));
			for(int i=1;i<=li.size();i++) {
				li.get(i).click();
				
				   }
			return flag;
			
		  
		  
	  }
	
	public boolean selectNotifyPatient(String alertType) {
		  boolean flag=false;
		  String xpath1="";
		  String xpath_informPatient="//mat-checkbox[@id='checkboxes']";
		  List<WebElement> li2=driver.findElements(By.xpath(xpath_informPatient));
		  		for(int i=1;i<=li2.size();i++) {
		  	    if(li2.get(i).getText().contains(alertType)) {
		  				
		  				flag=true;
		  				int alertindex=i;
		  				System.out.println(alertindex);
		  				xpath1="("+xpath_informPatient+")"+"["+alertindex+"]";
		  				WebElement parcentPacingCheckbox=driver.findElement(By.xpath(xpath1));
		  				scrollToViewWebElementWithoutReport(parcentPacingCheckbox, "Scroll down to validate all types of alerts");
		  				System.out.println(xpath1);
		  				parcentPacingCheckbox.click();
		  				extentReport.reportScreenShot("button is selected");
		  				 break;
		  	  
		  	  
		    }
		  	
		  	 
	  }
				return flag;
	  }
	  
	
	
	public boolean verifyEditButton() {
		   Boolean isEditbuttonpresent=false;
		   if(visibilityOfElementLocated(edit_Button_OR)) {
			   isEditbuttonpresent=true;
			   extentReport.reportScreenShot("Edit Button is displayed");
		   }
		   else {
			   extentReport.reportScreenShot("Edit Button is not displayed");
		   }
		return isEditbuttonpresent;
	   }
	   
	 
	 public boolean verifyCancelButton() {
		  Boolean isCancelButtonPresent=false;
		  if(visibilityOfElementLocated(cancelButton_OR)) {
			  isCancelButtonPresent=true;
			   extentReport.reportScreenShot("Cancel Button is displayed");
		   }
		   else {
			   extentReport.reportScreenShot("Cancel Button is not displayed");
		   }
		return isCancelButtonPresent;
	  }
	  
	  public boolean verifySaveButton() {
		  Boolean isSaveButtonPresent=false;
		  if(visibilityOfElementLocated(saveButton_OR)) {
			  isSaveButtonPresent=true;
			   extentReport.reportScreenShot("Save Button is displayed");
		   }
		   else {
			   extentReport.reportScreenShot("Save Button is not displayed");
		   }
		return isSaveButtonPresent;
	  }
	
	  public boolean verifyShowDevicesLink() {
		  Boolean flag=false;
		  if(visibilityOfElementLocated(showDevicesLink_OR)) {
			  flag=true;
			   extentReport.reportScreenShot("ShowDevices link is present");
		   }
		   else {
			   extentReport.reportScreenShot("ShowDevices link is not present");
		   }
		return flag;
	  }


	  public void clickShowDevicesLink() {
			scrollToViewWithReport(showDevicesLink_OR,showDevicesLink_S);
			clickElement(showDevicesLink_OR,showDevicesLink_S);
		}
	  
	  
	//-------------------------- Jeetendra  ---------------------------------------
//	  private final By getmerlin_offAlertCount = By.xpath(".//div[@id='merlinAlertType']//div[@formarrayname='alertTypes']//mat-radio-group//*[@id='offButton' and contains(@class,'checked')]");
	  private final By getmerlin_offAlertCount = By.xpath(".//div[@id='merlinAlertType']//div[@formarrayname='alertTypes']//mat-radio-group//div[3]/mat-radio-button[contains(@class,'checked')]");	
	  public boolean verify_percent_pacing_alert() throws InterruptedException {
		  boolean flag =false;
			if(getSizeOfElements(merlinAlertType_OR)>0) {
				int NumberofAlert = getSizeOfElements(merlinAlertType_OR);
				int NumberofAlertInoffstate = getSizeOfElements(getmerlin_offAlertCount);
				if(NumberofAlert==NumberofAlertInoffstate) {
					extentReport.reportPass("Only "+NumberofAlertInoffstate+" are in off State out of total "+NumberofAlert+" Alert Type");
					flag =true;
				}else {
					extentReport.reportFail("Only "+NumberofAlertInoffstate+" are in off State out of total "+NumberofAlert+" Alert Type");
				}
				return flag;
			}else {
				throw new IllegalStateException("Merlin Alert type is not dispalyed on the Page");
			}
		}
	  String DirectAlertsSettings_S=null;
	  By AlertTypeDefaultState_Red_OR = By.xpath("");
	  By AlertTypeDefaultState_OR = By.xpath("");
	  
	  public boolean verifyAlertTypeDefaultState(String PageName, String defaultState) {
			boolean flag=false;
			if(PageName.matches(DirectAlertsSettings_S)&&defaultState.matches("RED")) {
			int NumberofAlertinRedState = getSizeOfElements(AlertTypeDefaultState_Red_OR);
			int NumberofAlert = getSizeOfElements(AlertTypeDefaultState_OR);
			if(NumberofAlertinRedState==NumberofAlert) {
					flag=true;	
				}	
			}
			return flag;	
		}
	  
	  public void clickEditButton() {
			clickElement(editButton_OR, editButton_S);
		}
	  
	  public boolean verifyPatientNotificationcheckboxState(String val1, String val2) throws InterruptedException {
		By informPatient_list_OR = By.xpath(".//div[@id='merlinAlertType']//mat-checkbox[@id='checkboxes'and contains(@class,'checked')]");
		boolean flag = false;
		List<WebElement> getpatientnotification = findElements(informPatient_list_OR);
		if(getpatientnotification.size()==0) {
			flag=true;
			extentReport.reportPass("Default value for Inform Patient is in OFF State");
			
		}else {
			extentReport.reportFail("Number of Inform Patient not in OFF State : "+getpatientnotification.size());
		flag=true;	
		}
		return flag;  
	  }
	  
	  public boolean verifyandclickAlert() {
		return false;
		  
	  }

	  public boolean VerifySavepopupandclick(){
		return false;
		  
	  }

	  public boolean verifychangesonPage() {
		return false;
		  
	  }
	  
	  public boolean checkPatientcheckbox_with_alertsetting(String val1,String val2, String val3) {
		return false;
		  
	  }
	  public boolean SelectPatientNotificationcheckbox(String val1, String val2){
		return false;
		  
	  }
	  
	  public boolean ClickEditButton() {
		  System.out.println("Under Development");
		return false;
	  }
	  //---------------------------- Jeetendra End ----------------------------------
	  
	  
	@Override
	public boolean verifyLandingPage() {
		Boolean pageCheck = false;
		if (isElementPresentwithoutException(pageHeading_OR, pageHeading_S)) {
			pageCheck = true;
			extentReport.reportScreenShot("Merlin Home Transmitter page is displayed ");
		}
		return pageCheck;
	}
	
	private final By onCallPhysicianContact_OR = By.xpath("//mat-select[@id='onCallPhysician']");
	private final String onCallPhysicianContact_S = "On call Physician Contact";	
	private final By onCallPhysicianContactFaxCountryCode_OR = By.xpath("//div[@id='merlinHomeProfileForm']/div[1]/div/app-merlin-alerts/form/div/div[3]/div/div/span[1]/merlin-textbox/mat-form-field/div/div[1]/div[3]/input");
	private final String onCallPhysicianContactFaxCountryCode_S = "Fax Country Code";
	private final By onCallPhysicianContactFaxAreaCode_OR = By.xpath("//div[@id='merlinHomeProfileForm']/div[1]/div/app-merlin-alerts/form/div/div[3]/div/div/span[2]/merlin-textbox/mat-form-field/div/div[1]/div[3]/input");
	private final String onCallPhysicianContactFaxAreaCode_S = "Fax Area Code";
	private final By dropDownFax_OR = By.xpath("//mat-option[@id='Fax']/span");
	private final String dropDownFax_S = "Fax value in Dropdown";
	private final By onCallPhysicianContactFaxNumber_OR = By.xpath("//div[@id='merlinHomeProfileForm']/div[1]/div/app-merlin-alerts/form/div/div[3]/div/div/span[3]/merlin-textbox/mat-form-field/div/div[1]/div[3]/input");
	private final String onCallPhysicianContactFaxNumber_S = "Fax Number";
	
	public void changeOncallPhysicianContact(String type, String faxNumber) throws Exception {
		
		String[] phoneNumber = faxNumber.split("-");
		
		
		try{
			scrollToView(onCallPhysicianContact_OR);
			clickElement(onCallPhysicianContact_OR, onCallPhysicianContact_S);
			if (type.equals(getText(dropDownFax_OR)))
				clickElement(dropDownFax_OR, dropDownFax_S);
			waitForLoading();
			//selectValuefromDropdownviaVisibleText(onCallPhysicianContact_OR, "Fax");
			
			if (isDisplayedWithReport(onCallPhysicianContactFaxNumber_OR, onCallPhysicianContactFaxNumber_S))
			{
				//extentReport.reportScreenShot("Entering Country Code");
				//clickElement(onCallPhysicianContactFaxCountryCode_OR, onCallPhysicianContactFaxCountryCode_S);
				//sendKeys(onCallPhysicianContactFaxCountryCode_OR, onCallPhysicianContactFaxCountryCode_S, phoneNumber[0]);
				//extentReport.reportScreenShot("Entering Area Code");
				//clickElement(onCallPhysicianContactFaxAreaCode_OR, onCallPhysicianContactFaxAreaCode_S);
				//sendKeys(onCallPhysicianContactFaxAreaCode_OR, onCallPhysicianContactFaxAreaCode_S, phoneNumber[1]);
				extentReport.reportScreenShot("Entering fax number");
				clickElement(onCallPhysicianContactFaxNumber_OR, onCallPhysicianContactFaxNumber_S);
				sendKeys(onCallPhysicianContactFaxNumber_OR, onCallPhysicianContactFaxNumber_S, phoneNumber[2]);
				
			}
			
			clickElement(saveButton_OR);
			/*
			if (isDisplayed(successMessage)) {
				extentReport.reportPass("Oncall Physician Contact details saved properly");
			}
			else
			extentReport.reportFail("");
						*/
			
			
		}
		catch (Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		
	}
	
public boolean verifyOnCallPhysicianContact(String fax, String faxNumber) {
		
		boolean checkOncallPhysicianContact = false;
		String[] phoneNumber = faxNumber.split("-");
		
		
		try {
			if (onCallPhysicianContact_OR.equals(fax)) {
				extentReport.reportInfo("Oncall DEtails matched");
				
				if (onCallPhysicianContactFaxCountryCode_OR.equals(phoneNumber[0]))
						{
							extentReport.reportInfo("Oncall Country code details matched");
							if (onCallPhysicianContactFaxAreaCode_OR.equals(phoneNumber[1]))
								{
									extentReport.reportInfo("On call Area code matched");
									if (onCallPhysicianContactFaxNumber_OR.equals(phoneNumber[2]))
									{
										extentReport.reportInfo("Oncall fax number matched");
										checkOncallPhysicianContact = true;
										}
									else 
									{
										extentReport.reportInfo("Oncall fax number didnt matched");
										checkOncallPhysicianContact = false;
									}
								}
							else 
							{
								extentReport.reportInfo("On call Area code matched");
								checkOncallPhysicianContact = false;
							}
					}
				else 
				{
					extentReport.reportInfo("On call Country code matched");
					checkOncallPhysicianContact = false;
					
				}
				}
			else {
			checkOncallPhysicianContact = false;
			extentReport.reportFail("Oncall Pyhsician Contact details are not successfully");
			}
			
			return checkOncallPhysicianContact;
			}
		catch(Exception e)
		{
		e.getStackTrace();
		throw e;
		}
	}


public String changeAlertClassification(String alertTypeName) throws InterruptedException {
	String radioButtonEnabled = "";
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	List<WebElement> alerttTypes = findElementslist(alertType_OR);
	List<WebElement> Red = findElementslist(redRadioButton_OR);
	List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
	List<WebElement> Off = findElementslist(offRadioButton_OR);
	for (int i = 0; i <= alerttTypes.size(); i++) {
		System.out.println(alerttTypes.get(i).getText());
		if (alerttTypes.get(i).getText().contains(alertTypeName)) {
			scrollToViewlist(alerttTypes.get(i));
			if (Red.get(i).isSelected()) {
//				WebElement element2 = Red.get(i);
//				WebElement element = driver.findElements((yellowRadioButton_OR)).get(i);
				js.executeScript("arguments[0].click();", Yellow.get(i));
				radioButtonEnabled="Yellow";
			}					
			else if (Yellow.get(i).isSelected()) {
//				WebElement element = driver.findElements((offRadioButton_OR)).get(i);
//				js.executeScript("arguments[0].click();", element);
				js.executeScript("arguments[0].click();", Off.get(i));
				radioButtonEnabled="OFF";			
			}
			else if (Off.get(i).isSelected()) {
//				WebElement element = driver.findElements((redRadioButton_OR)).get(i);
//				js.executeScript("arguments[0].click();", element);
				js.executeScript("arguments[0].click();", Red.get(i));
				radioButtonEnabled="Red";				
			}
			break;
		}
	}
	return radioButtonEnabled;
}
//shafiya added switch case and reporting
public boolean verifyAlertClassification(String alertTypeName, String classification) throws Exception {
	Boolean isAlertSaved= false;
	WebElement element = null;
	List<WebElement> alerttTypes = findElementslist(alertType_OR);
	System.out.println("size:"+alerttTypes.size());
	for (int i = 0; i < alerttTypes.size(); i++) {
		System.out.println("Alert Tyep:"+alertTypeName);
		if (alerttTypes.get(i).getText().contains(alertTypeName)) {
			switch(classification) {
			case "Red":
				 element = driver.findElements((redRadioButton_OR)).get(i);
				//shafiya added one more condition if radio button is selected
				if(element.isEnabled() && element.isSelected() ) {
					isAlertSaved=true;
					extentReport.reportScreenShot(alertTypeName+ " is selected with  "+classification+ " Alert Classification ");					
				}
				else 
					extentReport.reportScreenShot(alertTypeName+ " is not selected with  "+classification+ " Alert Classification ");					
				
				break;
			case "Yellow":
				element = driver.findElements((yellowRadioButton_OR)).get(i);
				//shafiya added one more condition if radio button is selected
				if(element.isEnabled() && element.isSelected()) {
					isAlertSaved=true;
					extentReport.reportScreenShot(alertTypeName+ " is selected with  "+classification+ " Alert Classification ");
					
				}
				else 
					extentReport.reportScreenShot(alertTypeName+ " is not selected with  "+classification+ " Alert Classification ");
				break;
			case "OFF":
				 element = driver.findElements((offRadioButton_OR)).get(i);
				//shafiya added one more condition if radio button is selected
				if(element.isEnabled() && element.isSelected()) {
					isAlertSaved=true;
					extentReport.reportScreenShot(alertTypeName+ " is selected with  "+classification+ " Alert Classification ");
				}
				else 
					extentReport.reportScreenShot(alertTypeName+ " is not selected with  "+classification+ " Alert Classification ");
				break;
			}
			break;
			}			
	}
	return isAlertSaved;
}

public void clickOkButton() {
	acceptAlert();
}

public boolean validateMerlinHomeAlertValueInTable() throws InterruptedException, IOException{
	boolean flag = true;
	int i;

	clickElement(expandAlert_OR, expandAlert_S);
	By alertname=By.xpath("//mat-label[text()='Alert Type'])");
	scrollToView(alertname);

	List<WebElement> allAlertsMerlinHome=findElements(allMerlinHomeAlert_OR);
	ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("MerlinHome");
	for (String string : directAlerts) {
		System.out.println(string);
	}
	//Collections.sort(directAlerts);
	//&& statement will be removed once hidden value "Excessive charge time" will come in UI
	for (i=1;i<=allAlertsMerlinHome.size();i++)
	{

		String AlertMerlinHome=(driver.findElement(By.xpath("(//div[@formarrayname='alertTypes']//mat-label)["+i+"]"))).getText().trim();
		String alert1=directAlerts.get(i-1);
		System.out.println(alert1);
		System.out.println(AlertMerlinHome);
		if(!directAlerts.get(i-1).equalsIgnoreCase(AlertMerlinHome)) {
			flag=false;
			break;

		}

	}
	return flag;

	}


//Author: Shafiya Sunkesala
	public void clickParentCategoryExpandIcon() throws Exception{	
		try {
			if(isElementPresentwithoutException(expandAlert_OR, expandAlert_S)) {
				clickElement(expandAlert_OR, expandAlert_S);
				extentReport.reportScreenShot("User click on Expand icon of Parent Alert Type");
			}
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	//Author: Shafiya Sunkesala
	public boolean verifySubCategories_AsGroup() throws Exception {
  	Boolean inGroup = false;
  	try {  
  		
  		if(isElementPresent(By.xpath(merlinHomeAlertType_OR.replace("{0}", "LeadAssurance™ Alert")),merlinHomeAlertType_S)) {
  			clickParentCategoryExpandIcon();
  			List<String> leadAssuranceSubCategories = expectedLeadAssuranceSubCateogires();
  			if(isSubCategoriesExpanded()) {   				
	    			if(leadAssuranceSubCategories.equals(leadAssurance_TargetSubCategories(leadAssuranceSubCategories))) {
	    				inGroup = true;
	    				extentReport.reportScreenShot("Lead Assurance Alert Group has all it's subcategories under group");
	    			}
	    			else	    		
	    				extentReport.reportScreenShot("Lead Assurance Alert Group doesnot have all it's subcategories under its group");
  			}
  			else
  				extentReport.reportScreenShot("Lead Assurance Alert Group and it's subcategories are not displayed as group");
  		}    		   		    		
  		return inGroup;
  	} catch (Exception e) {
  		e.printStackTrace();
			throw e;
	
  		}	
	}
	//Author: Shafiya Sunkesala
    public List<String> leadAssurance_TargetSubCategories(List<String> subCategories) throws Exception{
    	List<WebElement> optionsElements =  new ArrayList<WebElement>(); 
    	List<String> actualOptions=null;
    	try {
	    		for (int i = 0; i < subCategories.size(); i++) {
	    			optionsElements.add(i,findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}",subCategories.get(i)))));
	    		}
	    		actualOptions = new ArrayList<String>();
				for (int i = 0; i < optionsElements.size(); i++) {
					actualOptions.add(optionsElements.get(i).getText().trim());
				}
				return actualOptions;
    		}  catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    }
    //Author: Shafiya Sunkesala
  	public boolean verifyAlignment_SubCategories_NoParent() throws Exception {
      	Boolean isAligned = false;
      	try {
      		int leadAssuranceX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "LeadAssurance™ Alert"))).getLocation().getX();
      		int tachyTeraphyX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "Tachy Therapy Disabled"))).getLocation().getX();
      		if(leadAssuranceX == tachyTeraphyX) {
      			isAligned = true;
      			extentReport.reportScreenShot("Sub Categories without Parent are aligned properly");
      		} else
      			extentReport.reportScreenShot("Sub Categories without Parent are not aligned properly");      		
      		return isAligned;    	
      	  		    		      	
      	} catch (Exception e) {
      		e.printStackTrace();
  			throw e;
  	
       }
      	
  	}
  //Author: Shafiya Sunkesala
  	public boolean verifyAlignment_SubCategories_HavingParent() throws Exception {
      	Boolean isAligned = false;
      	try {
      		int leadAssuranceX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "LeadAssurance™ Alert"))).getLocation().getX();
      		int RVPacingX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "RV Pacing Lead Impedance Out of Range"))).getLocation().getX();
      		int highVoltageX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "High Voltage Lead Impedance Out of Range"))).getLocation().getX();
      		int possibleHighVoltageX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "Possible High Voltage Lead Issue"))).getLocation().getX();
      		int secureSence_SustainedX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "*SecureSense™ Sustained RV lead noise detected"))).getLocation().getX();
      		int secureSence_Non_SustainedX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "*SecureSense™ Non-sustained RV oversensing detected"))).getLocation().getX();
      		int noiseRevX = driver.findElement(By.xpath(merlinHomeAlertType_OR.replace("{0}", "V. Noise Reversion"))).getLocation().getX();
      		if(leadAssuranceX > RVPacingX &&  leadAssuranceX > highVoltageX && leadAssuranceX > possibleHighVoltageX 
      				&& leadAssuranceX > secureSence_SustainedX && leadAssuranceX > secureSence_Non_SustainedX && leadAssuranceX > noiseRevX)
      		if(RVPacingX == highVoltageX && RVPacingX == possibleHighVoltageX 
      				&& RVPacingX == secureSence_SustainedX && RVPacingX == secureSence_Non_SustainedX && RVPacingX ==noiseRevX ) {
      			isAligned = true;
      			extentReport.reportScreenShot("Sub Categories with Parent are aligned One level deeper");
      		}
      		 else
      			extentReport.reportScreenShot("Sub Categories with Parent are not aligned One level deeper");      		
      		return isAligned;    	
      	  		    		      	
      	} catch (Exception e) {
      		e.printStackTrace();
  			throw e;
  	
       }
      	
  	}
  	//Author: Shafiya Sunkesala
  	//This will select the Inform Patient checkbox if it is enabled
  	public boolean  selectOrUnSelectInformPatient(String alertType) throws Exception
	{
		boolean editable =false;
		List<WebElement> alterTypes=findElementslist(alertType_OR,alertTyp_S);
		
		for(int i=0;i<alterTypes.size();i++)
		{	
			if(alterTypes.get(i).getText().contains(alertType))
			{					
				List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
				editable=informPatient.get(i).isEnabled();
				if(editable) {
					editable = true;
					js.executeScript("arguments[0].click();", informPatient.get(i));
					extentReport.reportScreenShot(alertType+ " Inform Patient checkbox is editable and selected");
					break;
				}
				else 
					extentReport.reportScreenShot(alertType+ " Inform Patient checkbox is non editable and can not be selected");				
				}
			}
		return editable;
	}
  //Author: Shafiya Sunkesala
  	public boolean verifyInformPatient(String alertTypeName) throws Exception {
  		Boolean isInformPatientSaved= false;	
  		List<WebElement> alerttTypes = findElementslist(alertType_OR);
  		for (int i = 0; i <= alerttTypes.size(); i++) {
  			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
  				List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
  				WebElement element = informPatient.get(i);
				if(element.isSelected()) {
					isInformPatientSaved=true;
					extentReport.reportScreenShot(alertTypeName+ " Inform Patient checkbox is saved and selected");
					break;
				}
				else {
					extentReport.reportScreenShot(alertTypeName+ " Inform Patient checkbox is not saved and not selected");  	
					break;
				}
  			}
  		}
  		return isInformPatientSaved;
  	}
  	//Author: Shafiya Sunkesala
  	public String changeAlertClassification(String alertTypeName, String classification) throws Exception {
  		String radioButtonEnabled = "";
  		JavascriptExecutor js = (JavascriptExecutor) driver;
  		
  		List<WebElement> alerttTypes = findElementslist(alertType_OR);
  		List<WebElement> Red = findElementslist(redRadioButton_OR);
  		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
  		List<WebElement> Off = findElementslist(offRadioButton_OR);
  		for (int i = 0; i < alerttTypes.size(); i++) {
  			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
  				switch (classification){
  				case "Red":
  					if (!Red.get(i).isSelected()) {
  						
						js.executeScript("arguments[0].click();", Red.get(i));
						radioButtonEnabled="Red button is clicked";
						scrollToViewlist(Red.get(i));
  					}
  					else
  						radioButtonEnabled="Red button is not clicked";
  					break;
  				case "Yellow":
  					if (!Yellow.get(i).isSelected()) {
  						
						js.executeScript("arguments[0].click();", Yellow.get(i));
						radioButtonEnabled="Yellow button is clicked";
						scrollToViewlist(Yellow.get(i));
  					}
  					else
  						radioButtonEnabled="Yellow button is not clicked";
  					break;
  				case "OFF":
  					if (!Off.get(i).isSelected()) {
  						
						js.executeScript("arguments[0].click();", Off.get(i));
						radioButtonEnabled="OFF button is clicked";
						scrollToViewlist(Off.get(i));
  					}
  					else
  						radioButtonEnabled="OFF button is not clicked";		
  					break;
  				}
  				
  			
  				break;
  			}
  			
  		}
  				
  		//Shafiya added to know which alert type radio button is clicked

  		extentReport.reportScreenShot(radioButtonEnabled+ " for "+alertTypeName+ " Alert Type ");
  		return radioButtonEnabled;
  	} 
  //Author: Shafiya Sunkesala
  	public boolean isPatientNotificationEnabled(String alertTypeName) throws Exception{
  		Boolean isInformPatientEnabled = false;
  		try {
  		//need to change this once dev team adds id for group so that we can retrieve only group related alerts
  	  		List<WebElement> alerttTypes = findElementslist(alertType_OR);  	  		
  	  		for (int i = 0; i < alerttTypes.size(); i++) {
  	  			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
  	  				List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
  	  				WebElement element = informPatient.get(i);
  					if(element.isEnabled()) {
  						isInformPatientEnabled=true;
  						extentReport.reportScreenShot(alertTypeName+ " Inform Patient checkbox is Enabled");
  						break;
  					}
  					else {
  						extentReport.reportScreenShot(alertTypeName+ " Inform Patient checkbox is diabled");
  						break;
  					}
  	  			}
  	  		}
  	  	return isInformPatientEnabled;
  		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}  		  		
  	}
  	//Author: Shafiya Sunkesala 
  	public void clickParentCategoryCollapseIcon() throws Exception{	
  		try {
  			if(isElementPresentwithoutException(collapseAlert_OR, collapseAlert_S)) {
  	  			clickElement(collapseAlert_OR, collapseAlert_S);
  	  			extentReport.reportScreenShot("User click on Collpase icon of Parent Alert Type");
  	  		}
  		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
  		
  	}
	private final By INFORMPATIENTcheckbox_OR = By.xpath("//*[@id=\"checkboxes0-input\"]");
	private final String INFORMPATIENTcheckbox_S  ="INFORM PATIENT";

	public boolean checkboxvalue() throws Exception{	
		Boolean isExpanded = false;
  		try {
  			
  			isExpanded= Boolean.parseBoolean(getAttributeWithReport(INFORMPATIENTcheckbox_OR,"aria-checked",INFORMPATIENTcheckbox_S));
  			
  		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return isExpanded;
  		
  	}
  	public List<String> expectedLeadAssuranceSubCateogires() throws Exception{
  		List<String> leadAssuranceSubCategories = new ArrayList<String>();   	
      	Collections.addAll(leadAssuranceSubCategories,"RV Pacing Lead Impedance Out of Range","High Voltage Lead Impedance Out of Range",
      			"Possible High Voltage Lead Issue","*SecureSense™ Sustained RV lead noise detected",
      			"*SecureSense™ Non-sustained RV oversensing detected", "V. Noise Reversion");
      	return leadAssuranceSubCategories;
  	}
  	//Author: Shafiya Sunkesala
  	public boolean isSubCategoriesExpanded() throws Exception {
      	Boolean isExpanded = false;
      	String styleBlock = "display: block;";     	
      	try {        		
      		if(isElementPresent(By.xpath(merlinHomeAlertType_OR.replace("{0}", "LeadAssurance™ Alert")),merlinHomeAlertType_S)) {      				
      			List<String> leadAssuranceSubCategories = expectedLeadAssuranceSubCateogires();
      			WebElement element1 = findElement(By.xpath(merlinHomeAlertTypeLabel_OR.replace("{0}", leadAssuranceSubCategories.get(0))));
      			WebElement element2 = findElement(By.xpath(merlinHomeAlertTypeLabel_OR.replace("{0}", leadAssuranceSubCategories.get(1))));
      			WebElement element3 = findElement(By.xpath(merlinHomeAlertTypeLabel_OR.replace("{0}", leadAssuranceSubCategories.get(2))));
      			WebElement element4 = findElement(By.xpath(merlinHomeAlertTypeLabel_OR.replace("{0}", leadAssuranceSubCategories.get(3))));
      			WebElement element5 = findElement(By.xpath(merlinHomeAlertTypeLabel_OR.replace("{0}", leadAssuranceSubCategories.get(4))));
      			WebElement element6 = findElement(By.xpath(merlinHomeAlertTypeLabel_OR.replace("{0}", leadAssuranceSubCategories.get(5))));
      			
      			if(element1.getAttribute("style").equals(styleBlock) && element2.getAttribute("style").equals(styleBlock)
      					&& element3.getAttribute("style").equals(styleBlock) && element4.getAttribute("style").equals(styleBlock)
      					&&element5.getAttribute("style").equals(styleBlock) && element6.getAttribute("style").equals(styleBlock)) {
      				isExpanded = true;
  	    			extentReport.reportScreenShot("Lead Assurance Alert Group is expanded and it's subcategories are displayed");
      			}
      			else
      				extentReport.reportScreenShot("Lead Assurance Alert Group  is collapsed and it's subcategories are not displayed");
      		}    		   		    		
      		return isExpanded;
      	} catch (Exception e) {
      		e.printStackTrace();
  			throw e;
  	
       }
      	
  	}

  	//snehal
  	
  	private final By showDeviceDialogBox_OR = By.xpath("//div[@class='cdk-overlay-pane']//app-show-devices-dialog/h2");
  	private final String showDeviceDialogBox_S = "Show Devices Dialogue Box";
  	
  	private final String deviceNameInShowDeviceDialogBox_OR = "//td[@class='mat-cell cdk-cell cdk-column-deviceName mat-column-deviceName ng-star-inserted'][contains(text(),'$deviceName')]";
  	private final String deviceNameInShowDeviceDialogBox_S = "Device Name under Show Devices Dialogue Box";
  	
  	private final By showDeviceCloseBtn_OR = By.xpath("//mat-dialog-actions/button/span");
  	private final String showDeviceCloseBtn_S = "Show Devices Close Button";
  	
  	private final By savePopup_OR = By.xpath("//div[@id='toast-container']/div");
  	private final String savePopup_S = "Save pop-up message";
  	
  	public boolean validateDeviceInShowDeviceDialogBox(String deviceName) {
  		Boolean flag = false;
  		
  		if(visibilityOfElementLocatedWithReport(showDeviceDialogBox_OR, showDeviceDialogBox_S)) {
  			extentReport.reportScreenShot("Show Devices DialogBox is displayed");
  			if(visibilityOfElementLocatedWithReport(By.xpath(deviceNameInShowDeviceDialogBox_OR.replace("$deviceName", deviceName)), deviceNameInShowDeviceDialogBox_S)) {
  				flag = true;
  				extentReport.reportScreenShot(deviceName+" is present");
  				
  			}
  		}
  		clickElement(showDeviceCloseBtn_OR, showDeviceCloseBtn_S);
  		return flag;
  	}
  	
  	public String verifyAlertClassificationStatus(String alertTypeName) throws InterruptedException {
		String statusFlg="";
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for (int i = 0; i <= alerttTypes.size(); i++) {
			if (alerttTypes.get(i).getText().contains(alertTypeName)) {
				if (Red.get(i).isSelected()) {
					statusFlg= "red";
				}					
				else if (Yellow.get(i).isSelected()) {
					statusFlg= "yellow";			
				}
				else if (Off.get(i).isSelected()) {
					statusFlg= "off";			
				}else {
					statusFlg="0";
				}
				break;
			}
		}
		return statusFlg;
	}
  	
  	public String VerifySavePopup() {
  		String alertText="";
  		if(visibilityOfElementLocatedWithReport(savePopup_OR, savePopup_S)) {
  		alertText = driver.findElement(savePopup_OR).getText();
  		}
  		return alertText;
  	}

  	public void clickSavePopup() {
  		clickElement(savePopup_OR, savePopup_S);
  	}
  	
  	public void acceptSavePopup() {
  		acceptAlert();
  		loading();
  	}
  	
  	public boolean verifyAfterclickSavePopup()
  	{
  		Boolean flag = false;
  		loading();
  		if(isElementNotPresentWithoutReport(savePopup_OR, savePopup_S)) {
  			extentReport.reportScreenShot("Popup message is not present");
  			flag = true;
  		}
  		return flag;
  	}
  	
  	public void verifyEditButton_new() {
		presenceOfElementLocatedWithReport(editButton_OR,editButton_S);
	}
  	
  	public void verifySaveButton_new() {
		presenceOfElementLocatedWithReport(saveButton_OR,saveButton_S);
	}
  	
  	public void verifyCancelButton_new() {
		presenceOfElementLocatedWithReport(cancelButton_OR,cancelButton_S);
	}
  	
  	public void validateEditMode() throws InterruptedException {
		verifyEditButton_new();
		extentReport.reportScreenShot("Edit Button is dispalyed on Merlin@Home page");	
		verifyEditMode();
		verifySaveButton_new();
		verifyCancelButton_new();
		extentReport.reportScreenShot("Save and cancel button displayed after clicking on edit button on Merlin@Home page.");	
	}
  	
  	
  	/***Author: ChandraMohan.S
  	 * 
  	 * @param alertName
  	 * @param alertClassification
  	 * @return
  	 * @throws InterruptedException
  	 */
  	
  	public boolean  verifyEditModeOfAlertClassification(String alertName, String alertClassification) throws InterruptedException
	{
		boolean editable =false;
		List<WebElement> alterTypes=findElementslist(alertType_OR,alertTyp_S);
		for(int i=0;i<alterTypes.size();i++)
		{
			if(alterTypes.get(i).getText().toLowerCase().trim().contains(alertName.toLowerCase().trim()))
			{	
				switch(alertClassification) {
				case "Red":
					List<WebElement> Red=findElementslist(redRadioButton_OR,redRadioButton_S);
					editable=Red.get(i).isEnabled();
					System.out.println("Is RED Radio Button check Editable --->"+editable);
					break;
				case "Yellow":
					List<WebElement> Yellow=findElementslist(yellowRadioButton_OR,yellowRadioButton_S);
					editable=Yellow.get(i).isEnabled();
					System.out.println("Is YELLOW Radio Button check Editable --->"+editable);
					break;
				case "Off":
					List<WebElement> Off=findElementslist(offRadioButton_OR,offRadioButton_S);
					editable=Off.get(i).isEnabled();
					System.out.println("Is OFF Radio Button check Editable--->"+editable);
					break;
				case "InformPatient":
					List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
					editable=informPatient.get(i).isEnabled();
					System.out.println("Is InformPatient Check Box check Editable --->"+editable);
					break;
				}
				break;
			}
		}
		return editable;
	}

/***ChandraMohan.S****
 * 
 * @param alertName
 * @param alertClassification
 * @throws InterruptedException
 */
  	public void  selectAlertClassification(String alertName, String alertClassification) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		List<WebElement> alterTypes=findElementslist(alertType_OR,alertTyp_S);
		for(int i=0;i<alterTypes.size();i++)
		{
			if(alterTypes.get(i).getText().toLowerCase().trim().contains(alertName.toLowerCase().trim()))
			{	
				switch(alertClassification) {
				case "Red":
					List<WebElement> Red=findElementslist(redRadioButton_OR,redRadioButton_S);
					//Red.get(i).click();
					js.executeScript("arguments[0].click();", Red.get(i));
					break;
				case "Yellow":
					List<WebElement> Yellow=findElementslist(yellowRadioButton_OR,yellowRadioButton_S);
					//Yellow.get(i).click();
					js.executeScript("arguments[0].click();", Yellow.get(i));
					break;
				case "Off":
					List<WebElement> Off=findElementslist(offRadioButton_OR,offRadioButton_S);
					//Off.get(i).click();
					js.executeScript("arguments[0].click();", Off.get(i));
					break;
				case "InformPatient":
					List<WebElement> informPatient=findElementslist(informPatientChkBox_OR,informPatientChkBox_S);
					//informPatient.get(i).click();
					js.executeScript("arguments[0].click();", informPatient.get(i));
					break;
				}
				break;
			}
		}
	}

  	
  	
  	public void verifyUpdatedClassificationSTatus(ArrayList<String> updatedClassificationSTatus) throws Exception {
  		ArrayList<String> directAlerts=TestDataProvider.readDirectAlertsFromExcel("MerlinHome_PercentPacingAlert");
  		for(int i=0;i<updatedClassificationSTatus.size();i++) {
  			assertEquals(true,verifyAlertClassificationStatus(directAlerts.get(i)).contentEquals(updatedClassificationSTatus.get(i)), "classification for alert"+updatedClassificationSTatus.get(i)+"is verified successfully."); 
  		}
  	}
       
  	
  	
  	public void validateSaveButton() {
		elementToBeClickable(saveButton_OR, saveButton_S);
		clickElement(saveButton_OR, saveButton_S);
	}
  	
  	public void editAndVerifyAlertCategory(ArrayList<String> directAlerts) throws Exception {
  		List<String>  alertSTatusUpdated= new ArrayList<String>() ,alertSTatusAfterUpdated= new ArrayList<String>(), alertSTatusAfterSave= new ArrayList<String>();



  		for(int j=0;j<3;j++) {
  			int i =0;
  			for (String alertName : directAlerts) {	
  				alertSTatusUpdated.add( changeAlertClassification(alertName));
  				alertSTatusAfterUpdated.add(verifyAlertClassificationStatus(alertName));
  				assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterUpdated.get(i)));	
  				extentReport.reportScreenShot("Changed  Alert Categories  to "+alertSTatusUpdated.get(i)+" for "+alertName);				
  				i++;					
  			}
  			validateSaveButton();
  			i=0;
  			for (String alertName : directAlerts) {						
  				alertSTatusAfterSave.add(verifyAlertClassificationStatus(alertName));
  				assertEquals(true,alertSTatusUpdated.get(i).equalsIgnoreCase(alertSTatusAfterSave.get(i)));
  				extentReport.reportScreenShot("Changed  Alert Categories to "+alertSTatusAfterSave.get(i)+" for "+alertName);				
  				i++;
  			}
  			alertSTatusUpdated.clear();
  			alertSTatusAfterUpdated.clear();
  			alertSTatusAfterSave.clear();
  			if(j!=2) {
  				//	clickClinicEditButton();
  			}

		}
	}
  	
  	
  	public List<String> getAlertValueFromExcelandCompareWithUI(String sheetName) throws IOException, InterruptedException {
  		ArrayList<String> directAlerts=new ArrayList<String>();
  		ArrayList<String> updatedClassificationSTatus=new ArrayList<String>();
		
		if(sheetName.equalsIgnoreCase("PercentPacingAlert")) {				
			directAlerts=TestDataProvider.readDirectAlertsFromExcel("MerlinHome_PercentPacingAlert");
	}
		for(int i=0;i<directAlerts.size();i++) {
			updatedClassificationSTatus.add(changeAlertClassification(directAlerts.get(i)));
		}
		return updatedClassificationSTatus;
		
  	}
  	
  	public String changeAlertClassificationToanyAlert(String AlertNamefromExcel, String classification) throws Exception {
		String radioButtonEnabled = "";
		JavascriptExecutor js = (JavascriptExecutor) driver;
			ArrayList<String> directAlerts=new ArrayList<String>();
			if(AlertNamefromExcel.equalsIgnoreCase("PercentPacingAlert")) {				
	         directAlerts=TestDataProvider.readDirectAlertsFromExcel("MerlinHome_PercentPacingAlert");
		}
		List<WebElement> alerttTypes = findElementslist(alertType_OR);
		List<WebElement> Red = findElementslist(redRadioButton_OR);
		List<WebElement> Yellow = findElementslist(yellowRadioButton_OR);
		List<WebElement> Off = findElementslist(offRadioButton_OR);
		for(int j=0;j<directAlerts.size();j++) {
			for (int i = 0; i <=alerttTypes.size(); i++) {
				scrollToViewlist(alerttTypes.get(i));
				System.out.println("total alert is "+(alerttTypes.size()));
				System.out.println("Alert name in ui"+alerttTypes.get(i).getText());
				if (alerttTypes.get(i).getText().contains(directAlerts.get(j))) {
					switch (classification){
					case "Red":
						if (!Red.get(i).isSelected()) {

							js.executeScript("arguments[0].click();", Red.get(i));
							radioButtonEnabled="Red button is clicked";
							scrollToViewlist(Red.get(i));
						}
						else
							radioButtonEnabled="Red button is not clicked";
						break;
					case "Yellow":
						if (!Yellow.get(i).isSelected()) {

							js.executeScript("arguments[0].click();", Yellow.get(i));
							radioButtonEnabled="Yellow button is clicked";
							scrollToViewlist(Yellow.get(i));
						}
						else
							radioButtonEnabled="Yellow button is not clicked";
						break;
					case "OFF":
						boolean flag=Off.get(i).isSelected();
						System.out.println(flag);
						if (!Off.get(i).isSelected()) {

							js.executeScript("arguments[0].click();", Off.get(i));
							radioButtonEnabled="OFF button is clicked";
							scrollToViewlist(Off.get(i));
						}
						else
							radioButtonEnabled="OFF button is not clicked";		
						break;
					}

					
					break;
				}

			}
		}
		return radioButtonEnabled;


	
	
	
	
}

}


