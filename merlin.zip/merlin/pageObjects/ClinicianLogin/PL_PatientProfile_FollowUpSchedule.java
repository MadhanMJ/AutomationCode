package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

// Author - Poojitha

public class PL_PatientProfile_FollowUpSchedule extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public PL_PatientProfile_FollowUpSchedule(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		
	}
	
	private final By smartScheduleCalendar_OR = By.xpath("//mat-radio-button[@id='smartModeRadioButton']");
	private final String smartScheduleCalendar_S = "Smart schedule calendar radio button";
	private final By cardiacMonitor_OR = By.xpath(""); //dummy xpath
	private final String cardiacMonitor_S = "Cardiac monitor check box";
	private final By editButton_OR = By.xpath("//button[@id='profileEditButton']"); 
	private final String editButton_S = "Edit button";
	private final By saveButton_OR = By.xpath("//button[@id='profileSaveButton']"); 
	private final String saveButton_S = "Save button";
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	
			
	// Poojitha
		public boolean verifyCardiacMonitorCheckbox() {
			Boolean checkBox = false;
			scrollToViewWithoutReport(cardiacMonitor_OR,cardiacMonitor_S);
			if (isSelectedWithReport(cardiacMonitor_OR,cardiacMonitor_S).equals(true)) {
				checkBox = true;
				}
			return checkBox;
		}
		
		public void selectCardiacCheckBox()
		{
		clickElement(cardiacMonitor_OR,cardiacMonitor_S);	
		}

		public void clickEditButton()
		{
		clickElement(editButton_OR,editButton_S);	
		}
		public void clickSaveButton()
		{
		clickElement(saveButton_OR,saveButton_S);	
		}

    
	@Override
	public boolean verifyLandingPage() {
		Boolean followupSchedulePageCHeck = false;
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		if (visibilityOfElementLocatedWithoutReport(smartScheduleCalendar_OR,smartScheduleCalendar_S)) {
			followupSchedulePageCHeck = true;
	}
		return followupSchedulePageCHeck;
	}

}
