package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_SchedulingAndMessagingPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	Assertions assertion =  new Assertions(extentTest);
	
	public CA_SchedulingAndMessagingPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
//	-------------------------------- Jeetendra Start -----------------------------------
	private final By MoniterPatientTranComm_Status_OR = By.xpath(".//*[@id='mat-checkbox-29']/label/span");
	private final By MonitorPatientDirect_Alert_Check_OR = By.xpath(".//mat-checkbox[@id='directAlert']/label/span");
//	private final By schedulingAndMessagingHeader_OR=By.xpath(".//div[@id='app-container']//header/div");
	private final By MoniterPatientTranCommDefaultvalue_OR = By
			.xpath("//*[@id=\"customer-scheduling-messaging-wrapper\"]/div/div[2]/div[2]/div[1]/div[2]");
	private final String MoniterPatientTranCommDefaultvalue_S= "Moniter Patient Tran Comm Default value";
	private final By MonitorPatientDirect_Alert_Check_Default_Value_OR = By
			.xpath("//*[@id=\"customer-scheduling-messaging-wrapper\"]/div/div[2]/div[2]/div[2]/div[2]");

	private final String MonitorPatientDirect_Alert_Check_Default_Value_S = "Monitor Patient Direct Alert Check Default Value";
	
	private final String MoniterPatientTranComm_Status_Checkboxvalue_S = "monitor patient�s transmitter communication status";
	private final String MoniterPatientTranComm_Status_dropdown_S = "monitor patient�s transmitter communication status";
	private final By MonitorPatientDirect_Alert_Checkboxvalue_No_ofdaysdropdown_OR = By
			.xpath(".//*[@id='mat-select-19']");
	private final String dropdown1_MoniterPatientTranComm_Status = ".//div[@id='bluetoothMistThreshold-panel']/mat-option[";
	private final String dropdown2_MoniterPatientTranComm_Status = "]/span";
	private final String dropdown1_MoniterPatientDirectAlert_Status = ".//div[@id='mat-select-19-panel']/mat-option[";
	private final String dropdown2_MoniterPatientDirectAlert_Status = "]/span";
	private final By MoniterPatientTranComm_Status_Checkboxvalue_OR = By
			.xpath("//input[@id='monitorTransmitter-input']");
	private final By MoniterPatientTranComm_Status_Checkbox_OR = By
			.xpath("//input[@id='monitorTransmitter-input']/parent::div");
	
	private final By MonitorPatientDirect_Alert_dropdown_OR = By
			.xpath(".//app-scheduling//mat-select[@id='mat-select-19']");
	private final By MonitorPatientDirect_Alert_dropdownOption_OR = By.xpath(".//div[@id='mat-select-19-panel']//span");
	private final By MonitorPatientDirect_Alert_Checkboxvalue_OR = By.xpath(".//*[@id='mat-checkbox-35-input']");
	private final String MonitorPatientDirect_Alert_Checkboxvalue_S = "Monitor Patient�s Direct Alert� Check status";
	private final String MonitorPatientDirect_Alert_dropdown_S = "Monitor Patient�s Direct Alert� Check status";
	private final By MoniterPatientTranComm_Status_dropdown_OR = By
			.xpath(".//mat-select[@id='bluetoothMistThreshold']//span/span");
	private final By MoniterPatientTranComm_Status_dropdownOption_OR = By
			.xpath(".//div[@id='bluetoothMistThreshold-panel']//span");
	private final String PatientwithMobileApp_S="Patient with MobileApp";
	private final String MoniterPatientTranComm_Status_S="Moniter Patient Trans Comm Status";
	private final String MonitorPatientDirect_Alert_Check_S="MonitorPatientDirect Alert Check";
	

//	-------------------------------- Jeetendra End -----------------------------------
	public final By pageLoading = By.xpath("//*[@class='spinnerWrapper']"); // Poojitha - updated pageLoading xpath
																			// Date: 28th Dec 2021
//<<<<<<< HEAD
//	private final By schedulingAndMessagingHeader_OR = By.xpath("//app-scheduling/div/div/div/header/div");
//<<<<<<< HEAD
//=======
	private final By schedulingAndMessagingHeader_OR = By.xpath("//div[@id='customer-scheduling-messaging-wrapper']/div/div[1]/div[1]/header/div");
//>>>>>>> refs/remotes/origin/feature/VinayBabu
	private final By preferredSchedulingMethods_OR = By
			.xpath("//mat-radio-group[@formcontrolname='schedulingMethodCd']/mat-radio-button/label/div[2]");
	public final By directCallAutomatedReferences_OR = By
			.xpath("//mat-checkbox[@formcontrolname='patientMessagingReminderFlg']");
	public final String directCallAutomatedReferences_S = "DirectCall Automated Followup Reminder Check Box";
	public final By directCallAutomatedReferencesInput_OR = By
			.xpath("//input[@id='patientMessagingReminder-input']");
	public final String directCallAutomatedReferencesInput_S = "DirectCall Automated Followup Reminder Check Box Input";
	
	public final By directCallOverdueMessages_OR = By
			.xpath("//mat-checkbox[@formcontrolname='patientMessagingOverdueFlg']");
	public final String directCallOverdueMessages_S =" DirectCall Automated overdue Check Box";
	
	public final By directCallOverdueMessagesInput_OR = By
			.xpath("//input[@id='patientMessagingOverdue-input']");
	public final String directCallOverdueMessagesInput_S =" DirectCall Automated overdue Check Box Input";
	private final String schedulingAndMessagingHeader_S = "Scheduling and Messaging Link";
	public final By sendMessagesBetweenBox_OR = By.xpath("//merlin-textbox[@controlname='patientMessagingStartTime']");
	public final String sendMessagesBetweenBox_S = "DirectCall Time Range - Send Message Between Box";
	public final By sendMessagesAndBox_OR = By.xpath("//merlin-textbox[@controlname='patientMessagingEndTime']");
	public final String sendMessagesAndBox_S = "DirectCall Time Range - Send Message And Box";
	public final By dailyDirectAlertsCheck_OR = By.xpath("//mat-checkbox[@formcontrolname='deviceCheckFlg']");
	public final String dailyDirectAlertsCheck_S = "Daily Direct Alerts Check Check Box";
	public final By lockoutUnscheduledTransmissions_OR = By
			.xpath("//mat-checkbox[@formcontrolname='lockoutPatientInitTransFlg']");
	public final String lockoutUnscheduledTransmissions_S = "Lockout Unscheduled Transmissions Check Box";
	public final By lockoutUnscheduledDirectAlertCheck_OR = By
			.xpath("//mat-checkbox[@formcontrolname='lockoutPatientInitDcFlg']");
	public final String lockoutUnscheduledDirectAlertCheck_S = "Lockout Unscheduled Direct Alert Check Checkbox";
	public final By collectDirectTrendViewerDiagnostics_OR = By.xpath("//mat-checkbox[@formcontrolname='enableMedFlg']");
	public final By disgnostics_OR = By.xpath("//mat-checkbox[@formcontrolname='clearStatsDiagnosticsFlg']");
	public final String disgnostics_S = "Diagnostics CheckBox";
	public final By disgnosticsInput_OR = By.xpath("//input[@id='clearStatsDiagnostics-input']");
	public final String disgnosticsInput_S = "Diagnostics CheckBox Input";
	public final By episodes_OR = By.xpath("//input[@id='clearEpisodalDiagnostics-input']");
	public final String episodes_S = "Episodes Check Box";
	public final By storesEGMS_OR = By.xpath("//input[@id='clearEgms-input']");
	public final String storesEGMS_S = "Stores EGMS Check Box";
	public final By stDiagnostics_OR = By.xpath("//input[@id='clearStMonitor-input']");
	public final String stDiagnostics_S = "ST Diagnostics";

	public final By patientTransmitterCommStatus = By
			.xpath("//mat-checkbox[@formcontrolname='bluetoothMistThresholdFlg']/label/div/input");
	public final By patientTransmitterCommStatusCheckBox = By
			.xpath("//mat-checkbox[@formcontrolname='bluetoothMistThresholdFlg']");
	public final By patientDirectAlertCheckCheckBox = By
			.xpath("//mat-checkbox[@formcontrolname='bluetoothNodcThresholdFlg']");
	public final By patientTransmitterStatusDropDownArrow_OR = By
			.xpath("//mat-select[@id='bluetoothMistThreshold']/div/div[2]");
	public final String patientTransmitterStatusDropDownArrow_S = "patient Transmitter Status DropDown Arrow";
	public final By patientDirectAlertCheckDropDownArrow = By
			.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div[2]");

	
//	public final By patientTransmitterCommStatus = By.xpath("//mat-checkbox[@formcontrolname='bluetoothMistThresholdFlg']/label/div/input");
//	public final By patientTransmitterCommStatusCheckBox = By.xpath("//mat-checkbox[@formcontrolname='bluetoothMistThresholdFlg']");
//	public final By patientTransmitterStatusDropDownArrow = By.xpath("//mat-select[@id='bluetoothMistThreshold']/div/div[2]");
//>>>>>>> refs/remotes/origin/feature/VinayBabu
	public final By patientTransmitterStatusDropDown = By.xpath("//mat-select[@id='bluetoothMistThreshold']");
//<<<<<<< HEAD
	public final By patientDirectAlertCheckDropDown = By.xpath("//mat-select[@id='bluetoothNodcThreshold']");
	public final By patientDirectAlertCheckStatus = By
			.xpath("//mat-checkbox[@formcontrolname='bluetoothNodcThresholdFlg']/label/div/input");
	public final By patientTransmitterCommStatusDropDown = By
			.xpath("//mat-select[@id='bluetoothMistThreshold']/div/div/span/span");
	public final By patientDirectAlertCheckStatusDropDown = By
			.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div/span/span");
//	public final By editButton_OR = By.xpath(
//			"//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button");
//	private final String editButton_S="Edit Button";
	public final By patientTransmitterCommStatusDropDownOptions = By
			.xpath("//div[@id='bluetoothMistThreshold-panel']/mat-option/span");
	public final By patientDirectAlertCheckDropDownOptions = By
			.xpath("//div[@id='bluetoothNodcThreshold-panel']/mat-option/span");
	public final By saveButton = By.xpath(
			"//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button[2]");
//=======
//	public final By patientDirectAlertCheckStatus = By.xpath("//mat-checkbox[@formcontrolname='bluetoothNodcThresholdFlg']/label/div/input");
//	public final By patientTransmitterCommStatusDropDown = By.xpath("//mat-select[@id='bluetoothMistThreshold']/div/div/span/span");
//	public final By patientDirectAlertCheckStatusDropDown = By.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div/span/span']");
//	public final By editButton = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button");
//	public final By patientTransmitterCommStatusDropDownOptions = By.xpath("//div[@id='bluetoothMistThreshold-panel']/mat-option/span");
//	public final By saveButton = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button[2]");
//	public final By patientDirectAlertCheckCheckBox = By.xpath("//mat-checkbox[@formcontrolname='bluetoothNodcThresholdFlg']");
//	public final By patientDirectAlertCheckDropDownArrow = By.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div[2]");
//	public final By patientDirectAlertCheckDropDown = By.xpath("//mat-select[@id='bluetoothNodcThreshold']");
//	public final By patientDirectAlertCheckDropDownOptions = By.xpath("//div[@id='bluetoothNodcThreshold-panel']/mat-option/span");
//	
//>>>>>>> refs/remotes/origin/feature/VinayBabu
	/*
	 * Author: Vinay Babu Test Case:
	 * WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_02
	 */

	private final By pageHeading_OR = By.xpath(
			"//div[@id=\"app-container\"]/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[1]/header/div");
	private final String pageHeading_S = "Scheduling & Messaging Page Heading";

//	private final By edit_button_OR = By.xpath(
//			"//div[@id=\"app-container\"]/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button");
//	private final String edit_button_S = "Edit Button";
	private final By cancel_button_OR = By.xpath(
			"//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button[1]");
	private final String cancel_button_S = "Cancel Button";
//	private final By save_button_OR = By.xpath(
//			"//div[@id=\"app-container\"]/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[1]/div[2]/button[2]");
//	private final String save_button_S = "Save Button";
//
//	private final By smartScheduleCalendar_inputRadio_OR = By
//			.xpath("//mat-radio-group[@id=\"schedulingMethod\"]/mat-radio-button[1]//input");
//	private final String smartScheduleCalendar_inputRadio_S = "SmartSchedule™ calendar radio button";
//
//	private final By manualentryCalendar_inputRadio_OR = By
//			.xpath("//mat-radio-group[@id=\"schedulingMethod\"]/mat-radio-button[2]//input");
//	private final String manualentryCalendar_inputRadio_S = "Manual entry calendar radio button";

	private final By disconnectedTransmitterThresholds_heading_OR = By.xpath(
			"//div[@id='customer-scheduling-messaging-wrapper']/div/div[2]/div[2]/h3[1]");
	private final String disconnectedTransmitterThresholds_heading_S = "Disconnected Transmitter Thresholds Heading";

	private final By transmitterStatusMobileApp_checkbox_OR = By.xpath(".//input[@id='monitorTransmitter-input']");
	private final String transmitterStatusMobileApp_checkbox_S = "MobileApp patient transmitter status checkbox";

	private final By transmitterStatusMobileApp_select_OR = By.xpath("//mat-select[@id=\"bluetoothMistThreshold\"]");
	private final String transmitterStatusMobileApp_select_S = "MobileApp patient transmitter status select";

	private final By transmitterStatusMerlinHome_checkbox_OR = By.xpath("//input[@id=\"mistThresholdCheck-input\"]");
	private final String transmitterStatusMerlinHome_checkbox_S = "MerlinHome patient transmitter status checkbox";

	private final By transmitterStatusMerlinHome_select_OR = By.xpath("//mat-select[@id=\"mistThreshold\"]");
	private final String transmitterStatusMerlinHome_select_S = "MerlinHome patient transmitter status checkbox";

	private final By batteryAdvisory_heading_OR = By.xpath(
			"//div[@id=\"app-container\"]/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[2]/div[2]/div[2]/h3[2]");
	private final String batteryAdvisory_heading_S = "Battery Advisory Heading";

	private final By advisorytransmitterStatusMobileApp_checkbox_OR = By
			.xpath("//input[@id=\"baMistThresholdCheck-input\"]");
	private final String advisorytransmitterStatusMobileApp_checkbox_S = "Advisory patient transmitter status checkbox";

	private final By advisorytransmitterStatusMobileApp_select_OR = By.xpath("//mat-select[@id=\"baMistThreshold\"]");
	private final String advisorytransmitterStatusMobileApp_select_S = "Advisory patient transmitter status select";

	private final By transmitternocommunicate1day_checkbox_OR = By.xpath("//input[@id=\"mat-checkbox-45-input\"]");
	private final String transmitternocommunicate1day_checkbox_S = "Notify transmitter not communicate 1 day checkbox";

	private final By dailydeviceCheck_checkbox_OR = By.xpath("//input[@id=\"baNodcThresholdCheck-input\"]");
	private final String dailydeviceCheck_checkbox_S = "Daily Device Check checkbox";

	private final By dailydeviceCheck_select_OR = By.xpath("//mat-select[@id=\"baNodcThreshold\"]");
	private final String dailydeviceCheck_select_S = "Daily Device Check select";
	
	//Shafiya
	//Xpaths related to ICD section: patients with Merlin@home transmitters  and Battery advisory section
    private final By smartScheduleCalendar_inputRadio_OR = By
                          .xpath("//mat-radio-group[@formcontrolname='schedulingMethodCd']/mat-radio-button/label[1]/div[1]//input[@id='smartSchedule-input']");
    private final String smartScheduleCalendar_inputRadio_S = "SmartScheduleâ„¢ calendar radio button";
    private final By manualentryCalendar_inputRadio_OR = By
                                 .xpath("//mat-radio-group[@formcontrolname='schedulingMethodCd']/mat-radio-button/label[1]/div[1]//input[@id='manualEntry-input']");
    private final String manualentryCalendar_inputRadio_S = "Manual entry calendar radio button";
    private final By monitorPatientTransmitterStatusMerlinHome_Checkbox_OR  = By.xpath("//mat-checkbox[@id='mistThresholdCheck']/label/div/input");
    private final String monitorPatientTransmitterStatusMerlinHome_Checkbox_S  = "Patient Transmitter Communication Status Checkbox";
    private final By monitorPatientTransmitterStatusMerlinHome_NoofDaysText_OR  = By.xpath("//mat-select[@id='mistThreshold']/div/div[1]/span/span");
    private final String monitorPatientTransmitterStatusMerlinHome_NoofDaysText_S  = "Merlin Home Patient Transmitter status No of days Text";
    private final By edit_button_OR = By.xpath("//button[@id='edit']/span");
    private final String edit_button_S = "Edit Button";
    private final By save_button_OR = By.xpath("//button[@id='save']/span");
    private final String save_button_S = "Save Button";
    private final By transmitterStatusMerlinHome_Dropdown_Arrow_OR = By.xpath("//mat-select[@id='mistThreshold']/div/div[2]/div");
    private final String transmitterStatusMerlinHome_Dropdown_Arrow_S = "MerlinHome patient transmitter status dropdown";
    private final By transmitterStatusMerlinHome_DropdownValueEight_OR = By.xpath("//div[@id='mistThreshold-panel']/mat-option[2]/span");
    private final String transmitterStatusMerlinHome_DropdownValueEight_S = "Merlin Home Patient Transmitter status Drop down value 8";
    private final By transmitterStatusMerlinHome_DropdownValueTen_OR = By.xpath("//div[@id='mistThreshold-panel']/mat-option[4]/span");
    private final String transmitterStatusMerlinHome_DropdownValueTen_S = "Merlin Home Patient Tramsmitter status dropdown value 10";
    private final By transmitterStatusMerlinHome_DropdownValues = By.xpath("//div[@id='mistThreshold-panel']/mat-option/span");
    private final By transmitterStatusMerlinHome_Dropdown_OR = By.xpath("//mat-select[@id='mistThreshold']/div");
    private final String transmitterStatusMerlinHome_Dropdown_S = "MerlinHome patient transmitter status DropDown";
    private final By monitorDirectAlertStatusMerlinHome_Checkbox_OR  = By.xpath("//mat-checkbox[@id='monitorAlerts']/label/div/input");
    private final String monitorDirectAlertStatusMerlinHome_Checkbox_S  = "MerlinHomeDirect Alert Check Status Checkbox";
    private final By monitorDirectAlertStatusMerlinHome_NoofDaysText_OR  = By.xpath("//mat-select[@id='deviceCheckThreshold']/div/div[1]/span/span");
    private final String monitorDirectAlertStatusMerlinHome_NoofDaysText_S  = "Merlin Home Direct Alert status No of days Text";
    private final By deviceCheckMerlinHome_Dropdown_Arrow_OR = By.xpath("//mat-select[@id='deviceCheckThreshold']/div/div[2]/div");
    private final String deviceCheckMerlinHome_Dropdown_Arrow_S = "MerlinHome Device Check status dropdown Arrow";
    private final By deviceCheckMerlinHome_DropdownValueEight_OR = By.xpath("//div[@id='deviceCheckThreshold-panel']/mat-option[8]/span");
    private final String deviceCheckMerlinHome_DropdownValueEight_S = "Merlin Home Device Check status dropdown value 8";
    private final By deviceCheckMerlinHome_DropdownValueNine_OR = By.xpath("//div[@id='deviceCheckThreshold-panel']/mat-option[9]/span");
    private final String deviceCheckMerlinHome_DropdownValueNine_S = "Merlin Home Device Check status dropdown value 9";
    private final String merlinHomePatientTransmitterStatus = "Merlin Home patient transmitter status";
    private final String merlinHomeDeviceCheck = "Merlin Home Device Check";
    private final String batteryAdvisoryPatientTransmitterStatus = "Battery Advisory Patient Status";
    private final String batteryAdvisoryDeviceCheck = "Battery Advisory Device Check";
    private final String batteryAdvisoryDailyMIST = "Battery Advisory Daily MIST";
    
    private final By deviceCheckMerlinHome_DropdownValues = By.xpath("//div[@id='deviceCheckThreshold-panel']/mat-option/span");
    private final By monitorPatientTransmitterStatusMerlinHome_SelectBox_OR = By.xpath("//mat-select[@id='mistThreshold']");
    private final String monitorPatientTransmitterStatusMerlinHome_SelectBox_S = "MerlinHome Patient Transmitter status dropdown";
    private final By deviceCheckMerlinHome_SelectBox_OR = By.xpath("//mat-select[@id='deviceCheckThreshold']");
    private final String deviceCheckMerlinHome_SelectBox_S = "MerlinHome Device Check status dropdown";
    private final By deviceCheckMerlinHome_Dropdown_OR = By.xpath("//mat-select[@id='deviceCheckThreshold']/div");
    private final String deviceCheckMerlinHome_Dropdown_S = "MerlinHome Device Check status DropDown";
    private final By batteryAdvisoryPatientTransmitterStatus_Checkbox_OR  = By.xpath("//mat-checkbox[@id='baMistThresholdCheck']/label/div/input");
    private final String batteryAdvisoryPatientTransmitterStatus_Checkbox_S  = "Battery Advisory Patient Transmitter Status Checkbox";
    private final By batteryAdvisoryDeviceCheck_Checkbox_OR  = By.xpath("//mat-checkbox[@id='baNodcThresholdCheck']/label/div/input");
    private final String batteryAdvisoryDeviceCheck_Checkbox_S  = "Battery Advisory Device Check Status Checkbox";
    private final By batteryAdvisoryPatientTransmitterStatus_NoofDaysText_OR  = By.xpath("//mat-select[@id='baMistThreshold']/div/div[1]/span/span");
    private final String batteryAdvisoryPatientTransmitterStatus_NoofDaysText_S  = "Battery Advisory Patient Transmitter status No of days Text";
    private final By batteryAdvisoryDeviceCheckStatus_NoofDaysText_OR  = By.xpath("//mat-select[@id='baNodcThreshold']/div/div[1]/span/span");
    private final String batteryAdvisoryDeviceCheckStatus_NoofDaysText_S  = "Battery Advisory Device Check status No of days Text";
    private final By batteryAdvisoryPatientTransmitterStatus_DropdownValues = By.xpath("//div[@id='baMistThreshold-panel']/mat-option/span");
    private final By batteryAdvisoryDeviceCheck_DropdownValues = By.xpath("//div[@id='baNodcThreshold-panel']/mat-option/span");
    private final By batteryAdvisoryDailyMIST_Checkbox_OR  = By.xpath("//mat-checkbox[@id='dailymistWhenDailydevmedFlg']/label/div/input");
    private final String batteryAdvisoryDailyMIST_Checkbox_S  = "Battery Advisory Daily MIST Checkbox";
    private final By batteryAdvisoryPatientStatusField  = By.xpath("//mat-checkbox[@id='baMistThresholdCheck']");
    private final By batteryAdvisoryPatientStatusDropdownField  = By.xpath("//mat-select[@id='baMistThreshold']/div");
    private final By batteryAdvisoryDailyMISTField  = By.xpath("//mat-checkbox[@id='dailymistWhenDailydevmedFlg']");    
    private final By batteryAdvisoryDeviceCheckField  = By.xpath("//mat-checkbox[@id='baNodcThresholdCheck']");
    private final By batteryAdvisoryDeviceCheckDropdownField  = By.xpath("//mat-select[@id='baNodcThreshold']/div");
    private final By batteryAdvisory_Heading_OR = By.xpath("//div[@id='app-container']//mat-checkbox[@id='monitorAlerts']/following-sibling::h3[1]");
    private final By batteryAdvisory_DailyMIST_Section_OR = By.xpath("//mat-checkbox[@id='dailymistWhenDailydevmedFlg']");
    private final String batteryAdvisory_DailyMIST_Section_S = "Battery Advisory Daily MIST section";
    private final By batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_OR = By.xpath("//mat-select[@id='baMistThreshold']/div/div[2]/div");
    private final String batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_S = "Battery Advisory Patient Transmitter status dropdown";
    private final By batteryAdvisoryDeviceCheckStatus_Dropdown_Arrow_OR = By.xpath("//mat-select[@id='baNodcThreshold']/div/div[2]/div");
    private final String batteryAdvisoryDeviceCheckStatus_Dropdown_Arrow_S = "Battery Advisory Device Check status dropdown";
    private final By batteryAdvisoryPatientTransmitterStatus_DropdownValueEight_OR = By.xpath("//div[@id='baMistThreshold-panel']/mat-option[2]/span");
    private final String batteryAdvisoryPatientTransmitterStatus_DropdownValueEight_S = "Battery Advisory Patient Transmitter dropdown value 8"; 
    private final By batteryAdvisoryDeviceCheckStatus_DropdownValueEight_OR = By.xpath("//div[@id='baNodcThreshold-panel']/mat-option[2]/span");
    private final By batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_OR = By.xpath("//div[@id='baMistThreshold-panel']/mat-option[4]/span");
    private final String batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_S  = "Battery Advisory Patient Transmitter dropdown value 10";
    
    private final By monitorPatientTransmitterStatusMerlinHome_ViewMode_NoofDaysText_OR = By.xpath("//mat-checkbox[@id='mistThresholdCheck']/following-sibling::div[1]/div[2]");
    private final String monitorPatientTransmitterStatusMerlinHome_ViewMode_NoofDaysText_S = "Merlin Home Patient Transmitter Status default value in Veiw mode";
    private final By monitorDirectAlertStatusMerlinHome_ViewMode_NoofDaysText_OR  = By.xpath("//mat-checkbox[@id='monitorAlerts']/following-sibling::div[1]/div[2]");
    private final String monitorDirectAlertStatusMerlinHome_ViewMode_NoofDaysText_S  = "Merlin Home Direct Alert status default value in View mode";
    private final By batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_OR  = By.xpath("//mat-checkbox[@id='baMistThresholdCheck']/following-sibling::div[1]/div[2]");
    private final String batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_S  = "Battery Advisory Patient Transmitter status default value in View mode";
    private final By batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_OR  = By.xpath("//mat-checkbox[@id='baNodcThresholdCheck']/following-sibling::div[1]/div[2]");
    private final String batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_S  = "Battery Advisory Device Check status defalut value in View mode";
    
	   //---------------------------- Shafiya End-----------------------------------------//


//<<<<<<< HEAD
//
//	// ------------------------------------Alok----------------------------------------------//
//
//	private final By PatientswithMobileApptransmitters_OR = By
//			.xpath("//h3[contains(text(),'Patients with Mobile App transmitters:')]");
//	private final String PatientswithMobileApptransmitters_S = "Patients with Mobile App transmitters";
//	private final By Monitorpatientstransmittercommunicationstatus_OR = By
//			.xpath("//mat-checkbox[@id='monitorTransmitter']/label/span");
//	private final String Monitorpatientstransmittercommunicationstatus_S = "Monitor patient�s transmitter communication status:";
//	private final By MonitorpatientDirectAlertCheckstatus_OR = By.xpath("//mat-checkbox[@id='directAlert']/label/span");
//	private final String MonitorpatientDirectAlertCheckstatus_S = "Monitor patient�s DirectAlert� Check status:";
//	private final By Monitorpatientstransmittercommunicationstatusnoofdays_OR = By
//			.xpath("//mat-select[@id='bluetoothMistThreshold']/div/div[1]/span");
//	private final String Monitorpatientstransmittercommunicationstatusnoofdays_S = "No Of Days";
//	private final By MonitorpatientDirectAlertCheckstatusnoofdays_OR = By
//			.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div[1]/span");
//	private final String MonitorpatientDirectAlertCheckstatusnoofdays_S = "No of Days";
//	private final By PatientswithMerlinhometransmitters_OR = By
//			.xpath("//h3[contains(text(),'Patients with Merlin@home transmitters:')]");
//	private final String PatientswithMerlinhometransmitters_S = "Patients with Merlin@home transmitters:";
//	private final By Monitorpatientstransmittercommunicationstatusmerlinhome_OR = By
//			.xpath("//mat-checkbox[@id='mistThresholdCheck']/label/span");
//	private final String Monitorpatientstransmittercommunicationstatusmerlinhome_S = "Monitor patient�s transmitter communication status:";
//	private final By MonitorpatientDirectAlertCheckstatusmerlinhome_OR = By
//			.xpath("//mat-checkbox[@id='monitorAlerts']/label/span");
//	private final String MonitorpatientDirectAlertCheckstatusmerlinhome_S = " Monitor patient�s DirectAlert� Check status:";
//	private final By Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome_OR = By
//			.xpath("//mat-select[@id='mistThreshold']/div/div[1]/span");
//	private final String Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome_S = "No Of Days";
//	private final By MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome_OR = By
//			.xpath("//mat-select[@id='deviceCheckThreshold']/div/div[1]/span");
//	private final String MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome_S = "No of Days";
//
//	// ---------------------------- Alok
//	// End-----------------------------------------//
//
//	// Poojitha
//	private final By cardiacMonitorDiagnostics_checkbox_OR = By.xpath("//mat-checkbox[@id='clearEpisodeEgmDiag']");
//	private final String cardiacMonitorDiagnostics_checkbox_S = "Cardiac Monitor - Diagnostics, Episodes and EGMs checkbox";
//	private final By editButton_OR = By.xpath("//span[text()=' Edit ']");
//	private final String editButton_S = "Edit button";
//	private final By saveButton_OR = By.xpath("//span[text()=' Save ']");
//	private final String saveButton_S = "Save button";
//	// Ends here
//
////=======
	
	private final By collectDirectTrend_OR= By.xpath("//mat-checkbox[@id='enableMed']");
	private final String collectDirectTrend_S = "Collect DirectTrend checkbox";
	
	
	//------------------------------------Alok----------------------------------------------//
	
		private final By PatientswithMobileApptransmitters_OR = By.xpath("//h3[contains(text(),'Patients with Mobile App transmitters:')]");
		private final String PatientswithMobileApptransmitters_S = "Patients with Mobile App transmitters";
		private final By Monitorpatientstransmittercommunicationstatus_OR = By.xpath("//mat-checkbox[@id='monitorTransmitter']/label/span");
		private final String Monitorpatientstransmittercommunicationstatus_S = "Monitor patient�s transmitter communication status:";
		private final By MonitorpatientDirectAlertCheckstatus_OR = By.xpath("//mat-checkbox[@id='directAlert']/label/span");
		private final String MonitorpatientDirectAlertCheckstatus_S = "Monitor patient�s DirectAlert� Check status:";
		private final By Monitorpatientstransmittercommunicationstatusnoofdays_OR = By.xpath("//mat-select[@id='bluetoothMistThreshold']/div/div[1]/span");
		private final String Monitorpatientstransmittercommunicationstatusnoofdays_S = "No Of Days";
		private final By MonitorpatientDirectAlertCheckstatusnoofdays_OR = By.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div[1]/span");
		private final String MonitorpatientDirectAlertCheckstatusnoofdays_S = "No of Days";
		private final By PatientswithMerlinhometransmitters_OR = By.xpath("//h3[contains(text(),'Patients with Merlin@home transmitters:')]");
		private final String PatientswithMerlinhometransmitters_S = "Patients with Merlin@home transmitters:";
		private final By Monitorpatientstransmittercommunicationstatusmerlinhome_OR = By.xpath("//mat-checkbox[@id='mistThresholdCheck']/label/span");
		private final String Monitorpatientstransmittercommunicationstatusmerlinhome_S = "Monitor patient�s transmitter communication status:";
		private final By MonitorpatientDirectAlertCheckstatusmerlinhome_OR = By.xpath("//mat-checkbox[@id='monitorAlerts']/label/span");
		private final String MonitorpatientDirectAlertCheckstatusmerlinhome_S = " Monitor patient�s DirectAlert� Check status:";
		private final By Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome_OR = By.xpath("//mat-select[@id='mistThreshold']/div/div[1]/span");
		private final String Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome_S = "No Of Days";
		private final By MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome_OR = By.xpath("//mat-select[@id='deviceCheckThreshold']/div/div[1]/span");
		private final String MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome_S = "No of Days";
		
		//---------------------------- Alok End-----------------------------------------//
	
	//Poojitha
		private final By cardiacMonitorDiagnostics_checkbox_OR = By.xpath("//mat-checkbox[@id='clearEpisodeEgmDiag']"); // dummy xpath
		private final String cardiacMonitorDiagnostics_checkbox_S = "Cardiac Monitor - Diagnostics, Episodes and EGMs checkbox";
		private final By editButton_OR = By.xpath("//span[text()=' Edit ']");
		private final String editButton_S = "Edit button";
		private final By saveButton_OR = By.xpath("//span[text()=' Save ']");
		private final String saveButton_S = "Save button";
		//Ends here
		
	//ChandraMohan.S
		private final By directDiagnostics_checkbox_OR = By.xpath("//input[@id=\"enableMed-input\"]"); // dummy xpath
		private final String directDiagnostics_checkbox_S = "DirectDiagnostics_checkbox";
	
		//Vinay. Updated by shafiya. To verify the scheduling and messaging page is in non editable mode
		public boolean checkPageInViewMode() throws Exception {
			Boolean pageViewMode = false;

			if (isDisplayed(smartScheduleCalendar_inputRadio_OR)
					&& isDisplayed(manualentryCalendar_inputRadio_OR)
					&& (!isEnabled(manualentryCalendar_inputRadio_OR) && !isEnabled(smartScheduleCalendar_inputRadio_OR))) {
				pageViewMode = true;
				extentReport.takeFullSnapShot(driver, "Scheduling and Messaging Page is in view mode");
			} else {
				pageViewMode = false;
				extentReport.takeFullSnapShot(driver, "Scheduling and Messaging Page is not in view mode");
			}

			return pageViewMode;
		}

	////////////////////////////////////// End: Vinay
	////////////////////////////////////// Babu//////////////////////////////////

	public List<String> getSchedulingMethods() throws InterruptedException {
		List<WebElement> optionsElements = findElements(preferredSchedulingMethods_OR);
		List<String> actualOptions = new ArrayList<String>();
		for (int i = 0; i < optionsElements.size(); i++) {
			actualOptions.add(optionsElements.get(i).getText().trim());
		}
		return actualOptions;
	}

	public List<String> getPatientTransmitterCommStatusDropDownOptions() throws InterruptedException {
		List<WebElement> optionsElements = findElements(patientTransmitterCommStatusDropDownOptions);
		List<String> actualOptions = new ArrayList<String>();
		for (int i = 0; i < optionsElements.size(); i++) {
			actualOptions.add(optionsElements.get(i).getText().trim());
		}
		return actualOptions;
	}

	public List<String> getDeviceCheckDropDownOptions() throws InterruptedException {
		List<WebElement> optionsElements = findElements(patientDirectAlertCheckDropDownOptions);
		List<String> actualOptions = new ArrayList<String>();
		for (int i = 0; i < optionsElements.size(); i++) {
			actualOptions.add(optionsElements.get(i).getText().trim());
		}
		return actualOptions;
	}

	public void clickEditButton() throws Exception {
		try {
			if (visibilityOfElementLocated(editButton_OR)) {
				invisibilityOfElementLocated(pageLoading);
				elementToBeClickable(editButton_OR);
				//removed below code as it is not correct info
				//extentReport.reportScreenShot("User click on Edit Button");
				clickElement(editButton_OR,editButton_S);
				extentReport.reportScreenShot("User click on Edit Button");
				//Shafiya added this since after edit clicked , the page is loading and getting Scheduling and messaging tc failed 
				if(isEnabledWithoutReport(smartScheduleCalendar_inputRadio_OR, smartScheduleCalendar_inputRadio_S))
					extentReport.reportScreenShot("Page is in Edit mode");
				else
					extentReport.reportScreenShot("Page not in Edit mode");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickSaveButton() throws Exception {
		try {
			if (visibilityOfElementLocated(saveButton)) {
				elementToBeClickable(saveButton);
				extentReport.reportScreenShot("User click on Save Button");
				clickElement(saveButton);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void acceptAlertPopUp() throws Exception {
		try {
			acceptAlert();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void selectValueInPatientTransmitterStatusDropDown(String value) throws Exception {
		By patientTransmitterCommStatusDDOption = By.xpath("//mat-option/span[contains(text(),'" + value + "')]");
		try {
			clickPatientTransmitterStatusDropDown();
			extentReport.reportScreenShot("User select " + value + " in DropDown");
			clickElement(patientTransmitterCommStatusDDOption);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void selectValueInPatientDeviceCheckDropDown(String value) throws Exception {
		By patientTransmitterCommStatusDDOption = By.xpath("//mat-option/span[contains(text(),'" + value + "')]");
		try {
			clickDeviceCheckDropDown();
			extentReport.reportScreenShot("User select " + value + " in DropDown");
			clickElement(patientTransmitterCommStatusDDOption);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickPatientTransmitterStatusDropDown() throws Exception {
		try {
			if (visibilityOfElementLocated(patientTransmitterStatusDropDownArrow_OR)) {
				elementToBeClickable(patientTransmitterStatusDropDownArrow_OR);
				clickElement(patientTransmitterStatusDropDownArrow_OR);
				extentReport.reportScreenShot("User clicked on Patient Transmitter Status DropDown");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickDeviceCheckDropDown() throws Exception {
		try {
			if (visibilityOfElementLocated(patientDirectAlertCheckDropDownArrow)) {
				elementToBeClickable(patientDirectAlertCheckDropDownArrow);
				clickElement(patientDirectAlertCheckDropDownArrow);
				extentReport.reportScreenShot("User clicked on Device Check DropDown");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	// Each page class should have this overridden method of Verify Landing page

	// Poojitha
	public boolean verifyCardiacMonitorCheckbox() {
		Boolean checkBox = false;
		scrollToViewWithoutReport(cardiacMonitorDiagnostics_checkbox_OR,cardiacMonitorDiagnostics_checkbox_S);
		if (isSelectedWithReport(cardiacMonitorDiagnostics_checkbox_OR,cardiacMonitorDiagnostics_checkbox_S).equals(true)) {
			checkBox = true;
			}
		return checkBox;
	}


	// ChandraMohan.S
		public boolean verifyCollectDirectTrendDiagnosticsCheckbox() {
			Boolean checkBox = false;
			scrollToViewWithoutReport(directDiagnostics_checkbox_OR,directDiagnostics_checkbox_S);
			if (isSelectedWithReport(directDiagnostics_checkbox_OR,directDiagnostics_checkbox_S).equals(true)) {
				checkBox = true;
				}
			return checkBox;
		}
	
	public void unselectCheckBox() throws Exception {
		try {
			scrollUp();
			clickElement(editButton_OR, editButton_S);
			waitForLoading();
			scrollDown();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	public void selectCardiacMonitorCheckbox() {
		scrollToViewWithoutReport(cardiacMonitorDiagnostics_checkbox_OR,cardiacMonitorDiagnostics_checkbox_S);
//>>>>>>> branch 'feature/VinayBabu' of ssh://git@bitbucket.sjm.com:7999/mnet/merlintest.git
			clickElement(cardiacMonitorDiagnostics_checkbox_OR, cardiacMonitorDiagnostics_checkbox_S);
			
	}
	// ends here

	// -------------------------------------------Alok-----------------------------//

	public void VerifyField(String FieldName) throws Exception {

		Boolean value = false;
		try {

			switch (FieldName) {

			case "disconnectedTransmitterThresholds":
				value = isDisplayedWithReportScreenshot(disconnectedTransmitterThresholds_heading_OR,
						"DISCONNECTED TRANSMITTER THRESHOLDS");
				break;

			case "PatientswithMobileApptransmitters":
				value = isDisplayedWithReportScreenshot(PatientswithMobileApptransmitters_OR,
						"Patients with Mobile App transmitters");
				break;

			case "Monitorpatientstransmittercommunicationstatus":
				value = isDisplayedWithReportScreenshot(Monitorpatientstransmittercommunicationstatus_OR,
						"Monitor patients transmitter communication status");
				break;

			case "MonitorpatientDirectAlertCheckstatus":
				value = isDisplayedWithReportScreenshot(MonitorpatientDirectAlertCheckstatus_OR,
						"Monitor patient Direct Alert Check status");
				break;

			/*
			 * case "Monitorpatientstransmittercommunicationstatusnoofdays": value =
			 * isDisplayedWithReportScreenshot(
			 * Monitorpatientstransmittercommunicationstatusnoofdays_OR,
			 * "Monitor patients transmitter communication status no of days"); break;
			 
			case "MonitorpatientDirectAlertCheckstatusnoofdays":
				value = isDisplayedWithReportScreenshot(MonitorpatientDirectAlertCheckstatusnoofdays_OR,
						"Monitor patient Direct Alert Check status no of days");
				break;
*/
			case "PatientswithMerlinhometransmitters":
				value = isDisplayedWithReportScreenshot(PatientswithMerlinhometransmitters_OR,
						" Patients with Merlin home transmitters");
				break;

			case "Monitorpatientstransmittercommunicationstatusmerlinhome":
				value = isDisplayedWithReportScreenshot(Monitorpatientstransmittercommunicationstatusmerlinhome_OR,
						" Monitor patients transmitter communication status merlinhome");
				break;

			case "MonitorpatientDirectAlertCheckstatusmerlinhome":
				value = isDisplayedWithReportScreenshot(MonitorpatientDirectAlertCheckstatusmerlinhome_OR,
						" Monitor patient Direct Alert Check status merlinhome");
				break;

			/*
			 * case "Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome": value
			 * = isDisplayedWithReportScreenshot(
			 * Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome_OR,
			 * " Monitor patients transmitter communication status no of days merlinhome");
			 * break;
			 * 
			 * case "MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome": value =
			 * isDisplayedWithReportScreenshot(
			 * MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome_OR,
			 * " Monitor patient Direct Alert Check status no of days merlinhome"); break;
			 */

			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	// ------------------------------------- Alok
	// End-------------------------------------------//

	// ------------------------- Jeetendra
	// -------------------------------------------------------
	// added by jitendra
	public final String collectDirectTrendViewerDiagnostics_S = "Collect DirectTrend™ Viewer Diagnostics";
	private final By Transmitter_Setting_OR = By.xpath(".//app-scheduling//h3[3]");

	private final String Transmitter_Setting_S = "Transmitter Settings";

	public boolean presenceof_Enhanced_diagnostics_collection_feature() {
		boolean check = false;
		presenceOfElementLocatedWithReport(collectDirectTrendViewerDiagnostics_OR, collectDirectTrendViewerDiagnostics_S);
		presenceOfElementLocatedWithReport(Transmitter_Setting_OR, Transmitter_Setting_S);
		String name = getText(collectDirectTrendViewerDiagnostics_OR,collectDirectTrendViewerDiagnostics_S);
		String header = getText(Transmitter_Setting_OR,Transmitter_Setting_S);
		if (header.trim().matches(Transmitter_Setting_S.trim().toUpperCase())) {
			if (name.trim().contains(collectDirectTrendViewerDiagnostics_S.trim())) {
				extentReport.reportScreenShot("presence of enhanced diagnostic collection feature");
				check = true;
			}
			return check;
		} else {
			return false;
		}
	}

	private final By Checkbox_CollectDirectTrendViewerDiagnostics_OR = By
			.xpath("//mat-checkbox[@formcontrolname='enableMedFlg']//input[@id='enableMed-input']");

	private final String Checkbox_CollectDirectTrendViewerDiagnostics_S="Checkbox Collect Direct Trend Viewer Diagnostics";
	public boolean verifydefaultValue() throws InterruptedException {
		String value = getAttribute(Checkbox_CollectDirectTrendViewerDiagnostics_OR, "aria-checked");
		if (value.matches("true")) {
			extentReport.reportScreenShot("Default Value is Enabled");
			return true;
		} else {
			extentReport.reportScreenShot("Default value is not Enabled");
			return false;
		}

	}

	public boolean ClickEditButton() {
		presenceOfElementLocatedWithReport(edit_button_OR,edit_button_S);
		clickElement(edit_button_OR,edit_button_S);
		extentReport.reportScreenShot("Click Edit button");
		return true;

	}

	public boolean EditValue_and_Save_Changes() throws InterruptedException {
		presenceOfElementLocatedWithReport(Checkbox_CollectDirectTrendViewerDiagnostics_OR,Checkbox_CollectDirectTrendViewerDiagnostics_S);
		try {

			clickElement(collectDirectTrendViewerDiagnostics_OR,collectDirectTrendViewerDiagnostics_S);
		} catch (Exception e) {
			System.out.println(e);
		}
		presenceOfElementLocatedWithReport(save_button_OR,save_button_S);
		clickElement(save_button_OR,save_button_S);
		waitForLoading();
		acceptAlert();
		waitForLoading();
		acceptAlert();
		waitForLoading();
		acceptAlert();
		return true;
	}

	private final By DisconnectTransmitterThresholdheader_OR = By.xpath("(.//div[@id='customer-scheduling-messaging-wrapper']//div[2]/div[2]/h3[1])[1]");
//	private final String DisconnectTransmitterThresholdheader_S = "Disconnect Transmitter Threshold header";
//			
	
	private final By PatientwithMobileApp_OR = By.xpath("(.//div[@id='customer-scheduling-messaging-wrapper']//div[2]/div[2]/h3[1])[2]");

	
	
	// Poojitha - updated exising method to include other sections 01/24/2022
	public boolean verifyAppUnderSection(String section, String subSection) {
		String DisconnectTransmitterThresholdheader_S = section;
		String PatientwithMobileApp_S = subSection;
		boolean check = false;
		presenceOfElementLocatedWithReport(DisconnectTransmitterThresholdheader_OR,DisconnectTransmitterThresholdheader_S);
		String header = getText(DisconnectTransmitterThresholdheader_OR,DisconnectTransmitterThresholdheader_S);
		switch (subSection)
		{
		case "Patients with Mobile App transmitters:":
			presenceOfElementLocatedWithReport(PatientwithMobileApp_OR,PatientwithMobileApp_S);
		String name = getText(PatientwithMobileApp_OR,PatientwithMobileApp_S);
System.out.println("Header value is:"+header.trim());
System.out.println("section value is:"+name.trim());
		if (header.trim().equalsIgnoreCase(DisconnectTransmitterThresholdheader_S.trim().toUpperCase())) {
				extentReport.reportScreenShot(
						"Patient with Mobile App Transmitter is displayed under Disconnected Transmitter Thresholds section");
				check = true;
			
		} break;
		case "Patients with Merlin@home transmitters:":
			presenceOfElementLocated(ICDPacemaker_Heading_OR);
			name = getText(ICDPacemaker_Heading_OR);

			if (header.trim().matches(DisconnectTransmitterThresholdheader_S.trim().toUpperCase())) {
				if (name.trim().matches(PatientwithMobileApp_S.trim())) {
					extentReport.reportScreenShot(
							"Patients with Merlin@home transmitters is displayed under Disconnected Transmitter Thresholds section");
					check = true;
				}
			}
			break;
		case "Battery Advisory Patients:":
			presenceOfElementLocated(batteryAdvisory_Heading_OR);
			 name = getText(batteryAdvisory_Heading_OR);

			if (header.trim().matches(DisconnectTransmitterThresholdheader_S.trim().toUpperCase())) {
				if (name.trim().matches(PatientwithMobileApp_S.trim())) {
					extentReport.reportScreenShot(
							"Battery Advisory Patients is displayed under Disconnected Transmitter Thresholds section");
					check = true;
				}
				
		}break;
		}
		return check;
		}
	


	
	public boolean verifyPatientwithMobileAppcheckboxanddefaultvalue(String defaultvalue) {
		presenceOfElementLocatedWithReport(transmitterStatusMobileApp_checkbox_OR,
				transmitterStatusMobileApp_checkbox_S);
		boolean check = false;
		if (visibilityOfElementLocated(transmitterStatusMobileApp_checkbox_OR)) {
			String outputtext = getText(MoniterPatientTranCommDefaultvalue_OR,MoniterPatientTranCommDefaultvalue_S).trim();
			if (defaultvalue.trim().matches(outputtext)) {
				extentReport.reportScreenShot(
						"Default Value for the Monitor patient�s transmitter communication status is dispalyed as "
								+ outputtext);
				check = true;
			}
		}
		return check;
	}

	public boolean MonitorPatientsDirectAlertCheckanddefaultvalue(String defaultvalue) {
//		scrollToView(MonitorPatientDirect_Alert_Check_OR);
		presenceOfElementLocatedWithReport(MonitorPatientDirect_Alert_Check_OR,
				"Monitor patient's DirectAlert� Check status");
		boolean check = false;
		String outputtext = getText(MonitorPatientDirect_Alert_Check_Default_Value_OR,MonitorPatientDirect_Alert_Check_Default_Value_S).trim();
		
		if (defaultvalue.trim().matches(outputtext)) {
			extentReport.reportScreenShot(
					"Default Value for the Monitor patient's DirectAlert� Check status is dispalyed as " + outputtext);
			check = true;
		}
		return check;
	}
	
	public boolean verifycheckboxanddefaultvalue(String checkbox_header, String defaultvalue) {
		presenceOfElementLocatedWithReport(PatientwithMobileApp_OR,PatientwithMobileApp_S);
		boolean check = false;
		if (visibilityOfElementLocated(PatientwithMobileApp_OR)) {
			if (checkbox_header.matches(getText(MoniterPatientTranComm_Status_OR,MoniterPatientTranComm_Status_S))) {
				String outputtext = getText(MoniterPatientTranCommDefaultvalue_OR,MoniterPatientTranCommDefaultvalue_S).trim();
				if (defaultvalue.trim().matches(outputtext)) {
					extentReport.reportScreenShot(
							"Default Value for the " + checkbox_header + " is dispalyed as " + outputtext);
					check = true;
				}
			}
			if (checkbox_header.matches(getText(MonitorPatientDirect_Alert_Check_OR,MonitorPatientDirect_Alert_Check_S))) {
				String outputtext = getText(MonitorPatientDirect_Alert_Check_Default_Value_OR,MonitorPatientDirect_Alert_Check_Default_Value_S).trim();
				if (defaultvalue.trim().matches(outputtext)) {
					extentReport.reportScreenShot(
							"Default Value for the " + checkbox_header + " is dispalyed as " + outputtext);
					check = true;
				}
			}
			return check;
		} else {
			throw new IllegalStateException("Patients with Mobile App transmitters: Section is not Present");
		}

	}

	public boolean verifyMoniterPatientTranComm_Status_Checkbox(String inputValue) throws InterruptedException {
		boolean checkbox = false;
		if (visibilityOfElementLocated(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
			if (inputValue.toUpperCase().matches("CHECK")) {
				if (isSelected(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: Check");
					checkbox = true;
				} else {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: UnCheck");
					checkbox = false;
				}
			}

			if (inputValue.toUpperCase().matches("UNCHECK")) {
				if (isSelected(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: Check");
					checkbox = false;
				} else {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: UnCheck");
					checkbox = true;
				}
			}
		}

		return checkbox;
	}

	public boolean MoniterPatientTranComm_Status_Checkbox_action(String inputValue) throws InterruptedException {
		boolean checkbox = false;
		if (visibilityOfElementLocated(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
			if (inputValue.toUpperCase().matches("CHECK")) {
				if (isSelected(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
					checkbox = true;
				} else {
					clickElement(MoniterPatientTranComm_Status_Checkbox_OR,"Moniter Patient Transmission Communication Status Checkbox");
					checkbox = true;
				}
			}

			if (inputValue.toUpperCase().matches("UNCHECK")) {
				if (isSelected(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
					clickElement(MoniterPatientTranComm_Status_Checkbox_OR,"");
					checkbox = true;
				} else {
					checkbox = true;
				}
			}
		}

		return checkbox;
	}

	public boolean verifyMonitorPatientDirect_Alert_Checkbox(String inputValue) throws InterruptedException {
		boolean checkbox = false;
		if (visibilityOfElementLocated(MonitorPatientDirect_Alert_Checkboxvalue_OR)) {
			if (inputValue.toUpperCase().matches("CHECK")) {
				if (isSelected(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: Check");
					checkbox = true;
				} else {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: UnCheck");
					checkbox = false;
				}
			}
			if (inputValue.toUpperCase().matches("UNCHECK")) {
				if (isSelected(MoniterPatientTranComm_Status_Checkboxvalue_OR)) {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: Check");
					checkbox = false;
				} else {
					extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: UnCheck");
					checkbox = true;
				}
			}
		}

		return checkbox;
	}

//				private boolean verifycheckbox(By locator, String inputValue) throws InterruptedException {
//					boolean checkbox = false;
//					if (visibilityOfElementLocated(locator)) {
//						if (inputValue.toUpperCase().matches("CHECK")) {
//							if (isSelected(locator)) {
//								extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: Check");
//								checkbox = true;
//							} else {
//								extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: UnCheck");
//								checkbox = false;
//							}
//						}
	//
//						if (inputValue.toUpperCase().matches("UNCHECK")) {
//							if (isSelected(locator)) {
//								extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: Check");
//								checkbox = false;
//							} else {
//								extentReport.reportScreenShot("Expected value ::" + inputValue + "  Actual Value:: UnCheck");
//								checkbox = true;
//							}
//						}
//						return checkbox;
//					} else {
//						extentReport.reportScreenShot("Locator is not present on Page");
//						return false;
//					}
	//
//				}

	public boolean verifyUserCapabilityDirectAlertCheckbox(String value, String usercap) throws InterruptedException {
		boolean check = false;
		String text = null;
		By MonitorPatientDirect_Alert_Checkboxvalue_OR = By.xpath(".//mat-checkbox[@id='directAlert']");
		if (value.matches("check")) {
			text = getAttribute(MonitorPatientDirect_Alert_Checkboxvalue_OR, "class");
			if (!text.contains("disable")) {
				extentReport.reportScreenShot("No fo days dropdown is visible in edit mode");
				check = true;
			}

		} else if (value.matches("Uncheck")) {
			text = getAttribute(MonitorPatientDirect_Alert_Checkboxvalue_OR, "class");
			if (text.contains("disable")) {
				extentReport.reportScreenShot("No fo days dropdown is visible in edit mode");
				check = true;
			}
		}
//					
//					if (header.matches(MoniterPatientTranComm_Status_Checkboxvalue_S)) {
//						check = verifycheckbox(MoniterPatientTranComm_Status_Checkboxvalue_OR, value);
//						visibilityOfElementLocated(Check_Enablement);
//					}
//					if (header.matches(MonitorPatientDirect_Alert_Checkboxvalue_S)) {
//						check = verifycheckbox(MonitorPatientDirect_Alert_Checkboxvalue_OR, value);
//						if (check && usercap.matches("Enabled")) {
//							visibilityOfElementLocated(MonitorPatientDirect_Alert_Checkboxvalue_No_ofdaysdropdown_OR);
//							extentReport.reportScreenShot("No fo days dropdown is visible in edit mode");
//							check = true;
//						} else if (usercap.matches("Disabled")) {
//							System.out.println("Checking");
//							try {
//								clickElement(MonitorPatientDirect_Alert_Checkboxvalue_OR);
//								waitForLoading();
//								invisibilityOfElementLocated(MonitorPatientDirect_Alert_Checkboxvalue_No_ofdaysdropdown_OR);
//								check = true;
//							} catch (Exception e) {
//								System.out.println(e);
//								check = false;
//							}
		//
//							extentReport.reportScreenShot("No fo days dropdown is not visible in edit mode");
//							check = true;
//						}
		//
//					}

		return check;
	}

	public boolean verifyMoniterPatientTranComm_Status_dropdownvalues(String value) {
		boolean result = false;
		ArrayList tempinput;

		tempinput = DropdowngetOptions(MoniterPatientTranComm_Status_dropdown_OR,
				MoniterPatientTranComm_Status_dropdownOption_OR);
//		tempinput.trimToSize();
//		List<String> output= tempinput;
		
		List<String> lis = Arrays.asList(value.split(","));
		ArrayList<String> temp2 = new ArrayList<>(lis);
		System.out.println(tempinput.toString());
		System.out.println(temp2.toString());
		for(int i =0;i<temp2.size();i++) {
		String val = tempinput.get(i).toString().trim();
			if(val.matches(temp2.get(i).toString().trim())) {
				result=true;				
			}			
		}
//		result = tempinput.contains(temp2);

		return result;
	}

	public boolean verifyMonitorPatientDirect_Alert_dropdownvalues(String value) {
		boolean result = false;
		ArrayList tempinput;

		tempinput = DropdowngetOptions(MonitorPatientDirect_Alert_dropdown_OR,
				MonitorPatientDirect_Alert_dropdownOption_OR);

		List<String> lis = Arrays.asList(value.trim().split(","));
		ArrayList<String> temp2 = new ArrayList<>(lis);
		result = tempinput.equals(temp2);

		return result;

	}

//				public boolean verifydropdownvalues(String dropdownName, String value) {
//					boolean result = false;
//					ArrayList tempinput;
//					if (dropdownName.matches(MoniterPatientTranComm_Status_dropdown_S)) {
	//
//						 tempinput = DropdowngetOptions(MoniterPatientTranComm_Status_dropdown_OR,
//								MoniterPatientTranComm_Status_dropdownOption_OR);
	//
//						List<String> lis = Arrays.asList(value.trim().split(","));
//						ArrayList<String> temp2 = new ArrayList<>(lis);
//						result = tempinput.equals(temp2);
//					}
	// if (dropdownName.matches(MonitorPatientDirect_Alert_dropdown_S)) {
//						tempinput = DropdowngetOptions(MonitorPatientDirect_Alert_dropdown_OR,
//								MonitorPatientDirect_Alert_dropdownOption_OR);
	//
//						List<String> lis = Arrays.asList(value.trim().split(","));
//						ArrayList<String> temp2 = new ArrayList<>(lis);
//						result = tempinput.equals(temp2);
//					}
	//
//					return result;
//					// TODO Auto-generated method stub
	//
//				}

	public boolean selectMoniterPatientTranComm_Status_dropdownvalues(String value) throws InterruptedException {
		boolean result = false;
//		System.out.println("check1");
		int size;
		try {

			size = getSizeOfElements(MoniterPatientTranComm_Status_dropdownOption_OR);
			SelectfromList(dropdown1_MoniterPatientTranComm_Status, dropdown2_MoniterPatientTranComm_Status, size,
					value.trim());
			result = true;
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}

	public boolean selectMonitorPatientDirect_Alert_dropdownvalues(String value) throws InterruptedException {
		boolean result = false;
		int size;
		try {
			size = getSizeOfElements(MoniterPatientTranComm_Status_dropdownOption_OR);
			SelectfromList(dropdown1_MoniterPatientDirectAlert_Status, dropdown2_MoniterPatientDirectAlert_Status, size,
					value);
			result = true;
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}

	private boolean SelectfromList(String dropdown_part1, String dropdown_part2, int size, String Expectedvalue) {
		for (int i = 1; i <= size; i++) {
			String actual_value = getText(By.xpath(dropdown_part1 + i + dropdown_part2),"");
			if (actual_value.matches(Expectedvalue)) {
				clickElement(By.xpath(dropdown_part1 + i + dropdown_part2),Expectedvalue);
				break;
			}
		}

		return true;

	}

	public boolean clicksavebutton() throws InterruptedException {
		clickElement(save_button_OR,save_button_S);
		waitForLoading();
		acceptAlert();
		waitForLoading();
		acceptAlert();
		waitForLoading();
		acceptAlert();
		
		return true;
	}
	
	

	// ------------- Jeetendra End----------------------------------------------

	// Each page class should have this overridden method of Verify Landing page
	@Override
	public boolean verifyLandingPage() {
		Boolean schedulingAndMessagingPageCheck = false;
		try {
			waitForLoading();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(isElementPresentwithoutException(schedulingAndMessagingHeader_OR,schedulingAndMessagingHeader_S)) {
			schedulingAndMessagingPageCheck=true;
			extentReport.reportScreenShot("Scheduling & Messaging page is displayed");
		}
		return schedulingAndMessagingPageCheck;
	}
	
	
	/*
	 * Author Salin Gambhir
	 * for test case: ICM_WA_Clinic_Administrator_Scheduling_and_Messaging_01
	 */
	public final By automaticallyClear_Heading_OR = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[2]/div[1]/h3[4]");
	public final String automaticallyClear_Heading_S = "Automatically Clear";
	public final By inputCardiacMonitor_OR = By.xpath("//input[@id='clearEpisodeEgmDiag-input']");
	public final String inputCardiacMonitor_S = "Cardiac Monitor Checkbox"; 
	public final By ICDSection_Heading_OR = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[2]/div[1]/div[4]/div[2]/p[1]");
	public final String ICDSection_Heading_S = "ICD/CRT-D Pacemaker section";
	public final By patientWitMobileAPPTransmitter_Heading_OR = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[2]/div[2]/h3[2]");
	public final String patientWitMobileAPPTransmitter_Heading_S = "Patient with Mobile App transmitter section";
	public final By ICDPacemaker_Heading_OR = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[2]/div[2]/div[2]/h3[1]");
	public final String ICDPacemaker_Heading_S = "Patient with Merlin at home transmitter section";
	public final By mobileAPPTransmitter_OR = By.xpath("//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-scheduling/div/div[2]/div[1]/div[4]/div[2]/h3");
	public final String mobileAPPTransmitter_S = "Mobile App Transmitter header section";
	public final By defaultMISTPatientAppTransmitter_OR = By.xpath("//mat-checkbox[@id='bluetoothMistThreshold']/div/div[1]/span");
	public final String defaultMISTPatientAppTransmitter_s = "Default value for MIST Patient Mobile App threshold";
	public final By defaultNODCPatientAppTransmitter_OR = By.xpath("//mat-select[@id='bluetoothNodcThreshold']/div/div[1]/span");
	public final String defaultNODCPatientAppTransmitter_s = "Default value for NODC Patient Mobile threshold";
	

	public boolean verifySections(String section) throws Exception {
		// TODO Auto-generated method stub
		boolean checkSection = false;
		try {
			switch (section)
			{
			case "Automatically Clear":
				if (isElementPresent(automaticallyClear_Heading_OR)) {
					extentReport.reportPass("Automatically Clear section is present");
					checkSection = true;
				}
				else
				{
					extentReport.reportFail("Automatically Clear section is not present");
					checkSection = false;
				}
				
				break;
			case "Compliance with Patient Transmitter":
				if (isElementPresent(disconnectedTransmitterThresholds_heading_OR))
				{
					extentReport.reportPass("Compliance Patient Transmitter section is present");
					checkSection = true;
				}
				else
				{
					extentReport.reportFail("Compliance Patient Transmitter section is not present");
					checkSection = false;
				}
				break;
			}
					
			
		}catch(Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		return checkSection;
	}

	public boolean verifyCardiacMonitor() {
	
		boolean checkCardiacMonitor=false;
		try {
			if (visibilityOfElementLocated(inputCardiacMonitor_OR))
			{
				extentReport.reportPass(inputCardiacMonitor_S + "element is present");
				checkCardiacMonitor = true;
				
			}
			else
				extentReport.reportFail(inputCardiacMonitor_S + "element is not present");
			
		}
		catch (Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		return checkCardiacMonitor;
	}

	public boolean verifyPartition() {
		// code to check if all partitions are available
		return false;
	}
	
	public String checkPageInEditMode() {
		String pageMode = "";

		if (isDisplayed(smartScheduleCalendar_inputRadio_OR)
				&& isDisplayed(manualentryCalendar_inputRadio_OR)
				&& (isEnabled(manualentryCalendar_inputRadio_OR) && isEnabled(smartScheduleCalendar_inputRadio_OR))) {
			pageMode = "Page is in Edit mode";
			extentReport.reportScreenShot("Page is in Edit mode");
		} else {
			pageMode = "Page is in View mode";
			extentReport.reportScreenShot("Page is in view mode");
		}

		return pageMode;
	}

	public void clickCancelButton() {
		try {
			if (isDisplayed(cancel_button_OR)) {
				clickElement(cancel_button_OR,cancel_button_S);
				//shafiya changed text edit to cancel
				extentReport.reportScreenShot("Clicking on Cancel button");	
			}
			
		}catch (Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		
	}

	public boolean verifyCancelButton() {
		// TODO Auto-generated method stub
		boolean cancelButtonStatus = false;
		try {
			if (isDisplayed(cancel_button_OR)) {
				cancelButtonStatus = true;
				extentReport.reportScreenShot("Cancel button exist on Page");	
			}
			else
			
				
				extentReport.reportScreenShot("Cancel button doesn't exist on Page");
			
			
		}catch (Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		
		
		return cancelButtonStatus;
	}

	public void changeStateOfDiagnosticsCheckBox() {
		// code to update Cardian Monitor Checkbox
		boolean checkStateOfDiagnosticCheckbox = false;
		
		try {
			if (visibilityOfElementLocated(inputCardiacMonitor_OR)) {
				
					
					clickElement(cancel_button_OR,cancel_button_S);
					extentReport.reportScreenShot("Clicking on Cardiac Monitor checkbox"  + inputCardiacMonitor_S);
						
			}
		}
		catch (Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		
	}

	public String getCardiacCheckBoxStatus() throws Exception {
		String checkStatus = "not selected";
		
		try {
			if (isElementPresent(inputCardiacMonitor_OR)) {
				if(isSelected(inputCardiacMonitor_OR))
					checkStatus = "selected";	
			}
		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		
		return checkStatus;
	}

	public boolean verifyMobileAPPTransmitterSection() {
		// TODO Auto-generated method stub
		boolean checkAppTransmitter = false;
		try {
			if (visibilityOfElementLocated(mobileAPPTransmitter_OR)) {
				extentReport.reportPass("Mobile App Transmitter section is available");
				checkAppTransmitter = true;
				
			}
			else
				extentReport.reportPass("Mobile App Transmitter section is not available");
		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
			
		}
		return checkAppTransmitter;
	}
	
	public boolean verifypatientAPPTransmitter() {
		// TODO Auto-generated method stub
		
		boolean checkPatientAppTransmitter = false;
		try {
			if (visibilityOfElementLocated(patientWitMobileAPPTransmitter_Heading_OR)) {
				extentReport.reportPass("Patient with Mobile APP transmitter section is available");
				checkPatientAppTransmitter = true;
				
			}
			else
				extentReport.reportPass("Patient with Mobile APP Transmitter section is not available");
		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
			
		}
		return checkPatientAppTransmitter;
	}

	public boolean verifyICDPatient() {
		// TODO Auto-generated method stub
		boolean checkICDAppTransmitter = false;
		try {
			if (visibilityOfElementLocated(ICDPacemaker_Heading_OR)) {
				extentReport.reportPass("Patient with Merlin APP Transmitter section is available");
				checkICDAppTransmitter = true;
				
			}
			else
				extentReport.reportFail("Patient with Merlin APP Transmitter section is not available");
		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
			
		}
		return checkICDAppTransmitter;
	}
	
	public boolean verifyICDCRTPsection() {
		boolean checkICDCRTPTransmitter = false;
		try {
			if (visibilityOfElementLocated(ICDSection_Heading_OR)) {
				extentReport.reportPass("ICD/ CRP-T Transmitter section is available");
				checkICDCRTPTransmitter = true;
				
			}
			else
				extentReport.reportFail("ICD/ CRP-T Transmitter section is not available");
		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
			
		}
		return checkICDCRTPTransmitter;
	}
	
	public boolean verifyDefaultValueForPatientAppTransmitter(String defaultTime) {
		
		boolean checkdefaultValue = false;
		try {
			if ((getText(defaultMISTPatientAppTransmitter_OR).equals(defaultTime)) && (getText(defaultNODCPatientAppTransmitter_OR).equals(defaultTime))) 
					{
				extentReport.reportScreenShot("Default MIST and NODC Value for Patient Mobile App Tansmitter matches");
				checkdefaultValue = true;
			
			}
			else
				extentReport.reportScreenShot("Default MIST and NODC Value for Patient Mobile App Tansmitter doesn't matches");
				
		}catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
		
		return checkdefaultValue;
	}
	
	/*
	 * Author Salin Gambhir for Test case:
	 * WA_80Rev6_UC021A_ClinicAdmin_01 
	 */
	
	public final By patientMessagingReminder_OR = By.xpath("//mat-checkbox[@id='patientMessagingReminder']");
	public final String patientMessagingReminder_S = "Patient Remainder check box";
	public final By patientSendMessagingStartTime_OR= By.xpath("//input[@id='merlin_textbox_patientMessagingStartTime']");
	public final String patientSendMessagingStartTime_S = "Start time for Patient Remainder";
	public final By patientSendMessagingEndTime_OR = By.xpath("//input[@id='merlin_textbox_patientMessagingEndTime']");
	public final String patientSendMessagingEndTime_S = "Stop Time for Patient Remainder";
	public final By patientSendMessagingStartTimeAmPm_OR = By.xpath("//mat-select[@id='patientMessagingStartTimeAmpm']");
	public final String patientSendMessagingStartTimeAmPm_S = "AM/PM Start Time";
	public final By patientSendMessagingEndTimeAmPm_OR = By.xpath("//mat-select[@id='patientMessagingEndTimeAmpm']");
	public final String patientSendMessagingEndTimeAmPm_S = "AM/PM Stop Time";

	public void alterMessagingDetails(String startTime, String startTimeAmPm, String endTime, String endTimeAmPm) throws Exception {
		
		try {
			
			scrollToView(patientMessagingReminder_OR);
			waitForLoading();
			if (!isSelectedWithoutReport(patientMessagingReminder_OR, patientMessagingReminder_S))
			{
				extentReport.reportScreenShot("Clicking on Patient Reminder");
				clickElement(patientMessagingReminder_OR, patientMessagingReminder_S);
			}
			clickElement(patientSendMessagingStartTime_OR, patientSendMessagingStartTime_S);
			sendKeys(patientSendMessagingStartTime_OR, patientSendMessagingStartTime_S, startTime);
			//clickElement(patientSendMessagingStartTimeAmPm_OR, patientSendMessagingStartTimeAmPm_S);
			//sendKeys(patientSendMessagingStartTimeAmPm_OR, patientSendMessagingStartTimeAmPm_S, startTimeAmPm);
			clickElement(patientSendMessagingEndTime_OR, patientSendMessagingEndTime_S);
			sendKeys(patientSendMessagingEndTime_OR, patientSendMessagingEndTime_S, endTime);
			//clickElement(patientSendMessagingEndTimeAmPm_OR);
			//sendKeys(patientSendMessagingEndTimeAmPm_OR, patientSendMessagingEndTimeAmPm_S,endTimeAmPm);
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}

	public boolean verifyAlertTextForAccepting(String msg) {
		// TODO Auto-generated method stub
		boolean checkAlertMessage = false;
		try {
			
			if (msg.contains(getAlertText())){
				extentReport.reportPass("Alert message box has correct Message");
				checkAlertMessage = true;
			}
			else 
				extentReport.reportFail("Alert message not correct");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
			
		}
		return checkAlertMessage;
	}

	public void clickAlerts() throws Exception {
		try {
			acceptAlert();
			acceptAlert();
			waitForLoading();
			acceptAlert();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		
	}
	
	public boolean verifyEnhancedDiagnosticsCollection() {
		Boolean isEnhancedEnabled=false;
		if (visibilityOfElementLocated(collectDirectTrend_OR)) {
			scrollToViewWithoutReport(collectDirectTrend_OR, collectDirectTrend_S);
			if (driver.findElement(collectDirectTrend_OR).getAttribute("class").contains("checked")) {
				extentReport.reportScreenShot("Enhanced diagnostics collection feature is enabled");
				isEnhancedEnabled=true;
			}else {
				extentReport.reportScreenShot("Enhanced diagnostics collection feature is not disabled");
			}
		}
		return isEnhancedEnabled;

	}
	//Author: Shafiya Sunkesala
		public boolean verifyCheckBox(String checkBoxName) throws Exception {
	    	Boolean checkboxstatus = false;
	    	try {
	    		switch(checkBoxName) {		
	    		case merlinHomePatientTransmitterStatus:
	    			isElementPresentwithoutException(monitorPatientTransmitterStatusMerlinHome_Checkbox_OR, monitorPatientTransmitterStatusMerlinHome_Checkbox_S);
	                if(isSelected(monitorPatientTransmitterStatusMerlinHome_Checkbox_OR)) {
	                     checkboxstatus= true;
	                     extentReport.reportScreenShot("ICD Section-Monitor Patient's transmitter communication status checkbox at Merlin@home is displayed as checked");
	                 }
	                else
	                     extentReport.reportScreenShot("ICD Section-Monitor Patient's transmitter communication status checkbox at Merlin@home is not displayed as checked ");
	                break;

	    			case merlinHomeDeviceCheck:
	    			isElementPresentwithoutException(monitorDirectAlertStatusMerlinHome_Checkbox_OR, monitorDirectAlertStatusMerlinHome_Checkbox_S);
	                if(isSelected(monitorDirectAlertStatusMerlinHome_Checkbox_OR)) {
	                	 checkboxstatus= true;
	                     extentReport.reportScreenShot("ICD Section-Monitor Patient's Direct Alert Check status checkbox at Merlin@home is displayed as checked");
	                }                                
	                else
	                     extentReport.reportScreenShot("ICD Section-Monitor Patient's Direct Alert Check status checkbox at Merlin@home is not displayed as checked ");
	                break;
	                
	    			case batteryAdvisoryPatientTransmitterStatus:
	    			isElementPresentwithoutException(batteryAdvisoryPatientTransmitterStatus_Checkbox_OR, batteryAdvisoryPatientTransmitterStatus_Checkbox_S);
	                if(isSelected(batteryAdvisoryPatientTransmitterStatus_Checkbox_OR)) {
	                    checkboxstatus= true;
	                    extentReport.reportScreenShot("Battery Advisory Section- Patient Transmitter Status checkbox is displayed as checked");
	                }                                
	                else
	    			   extentReport.reportScreenShot("Battery Advisory Section- Patient Transmitter Status checkbox is not displayed as checked");
	                break;
	    			case batteryAdvisoryDeviceCheck:
	    			isElementPresentwithoutException(batteryAdvisoryDeviceCheck_Checkbox_OR, batteryAdvisoryDeviceCheck_Checkbox_S);
	                if(isSelected(batteryAdvisoryDeviceCheck_Checkbox_OR)) {
	                    checkboxstatus= true;
	                    extentReport.reportScreenShot("Battery Advisory Section- Device Check Status checkbox is displayed as checked");
	                }                                
	                else
	    			   extentReport.reportScreenShot("Battery Advisory Section- Device Check Status checkbox is not displayed as checked");
	                break;
	    			case batteryAdvisoryDailyMIST:
	    				isElementPresentwithoutException(batteryAdvisoryDailyMIST_Checkbox_OR, batteryAdvisoryDailyMIST_Checkbox_S);
		                if(isSelected(batteryAdvisoryDailyMIST_Checkbox_OR)) {
		                    checkboxstatus= true;
		                    extentReport.reportScreenShot("Battery Advisory Section- Daily MIST checkbox is displayed as checked");
		                }                                
		                else
		    			   extentReport.reportScreenShot("Battery Advisory Section- Daily MIST checkbox is not displayed as checked");
		                break;
	    		}  
	    		return checkboxstatus;
	    	} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	     }

		//Author: Shafiya Sunkesala

	    public boolean verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue(String value, String checkBoxName, String viewMode) throws Exception{
	       boolean status = false;
	       String noofdaysvalue = null;
	       try {
	    	   switch(checkBoxName) {
	    	   case merlinHomePatientTransmitterStatus:	    		  
	    		   if(viewMode.equals("View Mode")) {
	    			   isElementPresentwithoutException(monitorPatientTransmitterStatusMerlinHome_ViewMode_NoofDaysText_OR, monitorPatientTransmitterStatusMerlinHome_ViewMode_NoofDaysText_S);
	    			   noofdaysvalue = getText(monitorPatientTransmitterStatusMerlinHome_ViewMode_NoofDaysText_OR,monitorPatientTransmitterStatusMerlinHome_ViewMode_NoofDaysText_S);
	    		   }
	    		   else {  		
	    			   isElementPresentwithoutException(monitorPatientTransmitterStatusMerlinHome_NoofDaysText_OR, monitorPatientTransmitterStatusMerlinHome_NoofDaysText_S);
	    			   noofdaysvalue = getText(monitorPatientTransmitterStatusMerlinHome_NoofDaysText_OR,monitorPatientTransmitterStatusMerlinHome_NoofDaysText_S);
	    		   }
	    		   break;
	    	   case merlinHomeDeviceCheck:
	    		   isElementPresentwithoutException(monitorDirectAlertStatusMerlinHome_NoofDaysText_OR, monitorDirectAlertStatusMerlinHome_NoofDaysText_S);
	    		   if(viewMode.equals("View Mode"))
	    			   noofdaysvalue = getText(monitorDirectAlertStatusMerlinHome_ViewMode_NoofDaysText_OR,monitorDirectAlertStatusMerlinHome_ViewMode_NoofDaysText_S);
	    		   else	
	    			   noofdaysvalue = getText(monitorDirectAlertStatusMerlinHome_NoofDaysText_OR,monitorDirectAlertStatusMerlinHome_NoofDaysText_S);
	    		   break;
	    	   case batteryAdvisoryPatientTransmitterStatus:	    		 
	    		   if(viewMode.equals("View Mode")) {
	    			   isElementPresentwithoutException(batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_OR, batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_S);
	    			   noofdaysvalue = getText(batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_OR,batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_S);
	    		   }
	    		   else {
	    			   isElementPresentwithoutException(batteryAdvisoryPatientTransmitterStatus_NoofDaysText_OR, batteryAdvisoryPatientTransmitterStatus_NoofDaysText_S);
	    			   noofdaysvalue = getText(batteryAdvisoryPatientTransmitterStatus_NoofDaysText_OR,batteryAdvisoryPatientTransmitterStatus_NoofDaysText_S);
	    		   }
	    		   break;
	    	   case batteryAdvisoryDeviceCheck:	    		  
	    		   if(viewMode.equals("View Mode")) {
	    			   isElementPresentwithoutException(batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_OR,batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_S );
	    			   noofdaysvalue = getText(batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_OR,batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_S);
	    		   }
	    		   else	{
	    			   isElementPresentwithoutException(batteryAdvisoryDeviceCheckStatus_NoofDaysText_OR,batteryAdvisoryDeviceCheckStatus_NoofDaysText_S );
	    			   noofdaysvalue = getText(batteryAdvisoryDeviceCheckStatus_NoofDaysText_OR,batteryAdvisoryDeviceCheckStatus_NoofDaysText_S);
	    		   }
	    		   break;
	    	   }
	    	   if(noofdaysvalue.equals(value)){
	               status= true;
	               extentReport.reportScreenShot("Number of days Actual value is "+noofdaysvalue+" in "+checkBoxName+" drop down");
	    	   }
	    	   else {
	    		   extentReport.reportScreenShot("Number of days value is not "+value+" in "+checkBoxName+" drop down");
	    	   }
	    	   return status;
	       }catch (Exception e) {
			e.printStackTrace();
			throw e;
	   		}                          
	    }

	    //Author: Shafiya Sunkesala
	    //Under Patients with Merlin@home transmitters section, clicks the drop down based on string value if it is patient transmitter status or device check

	    public boolean clickPatientTransmitter_DeviceCheck_DropdownBox(String dropdownName) throws Exception{
	       Boolean drodownClick = false;
	       try {
	    	   switch(dropdownName) {
	    	   case merlinHomePatientTransmitterStatus:
	    		   scrollToViewWithoutReport(transmitterStatusMerlinHome_Dropdown_Arrow_OR, transmitterStatusMerlinHome_Dropdown_Arrow_S);
	    		   clickElementWithoutReport(transmitterStatusMerlinHome_Dropdown_Arrow_OR, transmitterStatusMerlinHome_Dropdown_Arrow_S);
	               if(isDisplayed(transmitterStatusMerlinHome_DropdownValueEight_OR)) {
	                      drodownClick= true;
	                      extentReport.reportScreenShot("Merlin@home transmitters section-Patient transmitters communication status drop down clicked");
	                }
	                else {
	                      extentReport.reportScreenShot("Merlin@home transmitters section-Patient transmitters communication status drop down not clicked");
	                }
	    		   break;
	    	   case merlinHomeDeviceCheck:
	    		   scrollToViewWithoutReport(deviceCheckMerlinHome_Dropdown_Arrow_OR, deviceCheckMerlinHome_Dropdown_Arrow_S);
	    		   clickElementWithoutReport(deviceCheckMerlinHome_Dropdown_Arrow_OR, deviceCheckMerlinHome_Dropdown_Arrow_S);
	               if(isDisplayed(deviceCheckMerlinHome_DropdownValueEight_OR)) {
	                     drodownClick= true;
	                     extentReport.reportScreenShot("Merlin@home transmitters section-Device Check status drop down clicked");	
	               }
	               else {	
	             		extentReport.reportScreenShot("Merlin@home transmitters section-Device Check status drop down not clicked");	
	               }
	    		   break;
	    	   case batteryAdvisoryPatientTransmitterStatus:
	    		   scrollToViewWithoutReport(batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_OR, batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_S);
	    		   clickElementWithoutReport(batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_OR, batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_S);
	               if(isDisplayed(batteryAdvisoryPatientTransmitterStatus_DropdownValueEight_OR)) {
	                     drodownClick= true;
	                     extentReport.reportScreenShot("Battery Advisory Section-Patient Transmitter status drop down clicked");	
	               }
	               else {	
	             		extentReport.reportScreenShot("Battery Advisory Section-Patient Transmitter status drop down not clicked");	
	               }
	    		   break;
	    	   case batteryAdvisoryDeviceCheck:
	    		   scrollToViewWithoutReport(batteryAdvisoryDeviceCheckStatus_Dropdown_Arrow_OR, batteryAdvisoryDeviceCheckStatus_Dropdown_Arrow_S);
	    		   clickElementWithoutReport(batteryAdvisoryDeviceCheckStatus_Dropdown_Arrow_OR, batteryAdvisoryDeviceCheckStatus_Dropdown_Arrow_S);
	               if(isDisplayed(batteryAdvisoryDeviceCheckStatus_DropdownValueEight_OR)) {
	                     drodownClick= true;
	                     extentReport.reportScreenShot("Battery Advisory Section-Device Check status drop down clicked");	
	               }
	               else {	
	             		extentReport.reportScreenShot("Battery Advisory Section-Device Check status drop down not clicked");	
	               }
	    		   break;
	           
	           }
	    	   return drodownClick;
	       }catch (Exception e) {
				e.printStackTrace();
				throw e;
			}                                 
	    }

	    //Author: Shafiya Sunkesala
	    //Under Patients with Merlin@home transmitters section, Adds the dropdown values 7, 8,9-- upto 15 days to arraylist

	    public List<String> patientTransmitter_DeviceCheck_TargetDropdownValues(String checkBoxName) throws InterruptedException{
	    	List<WebElement> optionsElements=null;
	    	List<String> actualOptions=null;
	    	try {
	    		switch(checkBoxName) {
	    		case merlinHomePatientTransmitterStatus:
	    			optionsElements = findElements(transmitterStatusMerlinHome_DropdownValues);
	    			break;
	    		case merlinHomeDeviceCheck:
	    			optionsElements = findElements(deviceCheckMerlinHome_DropdownValues);
	    			break;
	    		case batteryAdvisoryPatientTransmitterStatus:
	    			optionsElements = findElements(batteryAdvisoryPatientTransmitterStatus_DropdownValues);
	         	   break;
	            case batteryAdvisoryDeviceCheck:
	            	optionsElements = findElements(batteryAdvisoryDeviceCheck_DropdownValues);
	            	break;
	    		}
	    		actualOptions = new ArrayList<String>();
				for (int i = 0; i < optionsElements.size(); i++) {
					actualOptions.add(optionsElements.get(i).getText().trim());
				}
	    		return actualOptions;
	    	}catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	    }

	    //Author: Shafiya Sunkesala
	    //Verifies the dropwdown is actually a Select box returns true if it is selectbox

	    public boolean verifySelectBox(String checkBoxName) throws InterruptedException {
	       Boolean selectBox = false;
	       if(checkBoxName.equals(merlinHomePatientTransmitterStatus)) { 	  
	    	   if( isElementPresentwithoutException(monitorPatientTransmitterStatusMerlinHome_SelectBox_OR, monitorPatientTransmitterStatusMerlinHome_SelectBox_S) 
	    			   && isDisplayed(monitorPatientTransmitterStatusMerlinHome_SelectBox_OR)) {
	    		   selectBox = true;
	    		   extentReport.reportScreenShot(checkBoxName+" is select box. User is not able to enter any value");
	    	   }
	    	   else {
	    		   selectBox = false;
	    	   extentReport.reportScreenShot(checkBoxName+" is not select box. User is able to enter any value");
	    	   }
	       } else if(checkBoxName.equals(merlinHomeDeviceCheck)) {
	    	   if(isElementPresentwithoutException(deviceCheckMerlinHome_SelectBox_OR, deviceCheckMerlinHome_SelectBox_S) 
	    			   && isDisplayed(deviceCheckMerlinHome_SelectBox_OR)) {
	    		   selectBox = true;
	    		   extentReport.reportScreenShot(checkBoxName+" is select box. User is not able to enter any value");
	    	   }
	    	   else {
	    		   selectBox = false;
	    		   extentReport.reportScreenShot(checkBoxName+" is not select box. User is able to enter any value");
	    	   }
	       }
	      
	       return selectBox;
	    }
	   
	    //Author: Shafiya Sunkesala
	    //This method selects the dropdown value other than the default value 8 and saves the value

	    public void selectValueFromDropdown(String checkBoxName) throws Exception{
	    	try {
		    	Boolean status = false;
		    	switch(checkBoxName) {
		    	case merlinHomePatientTransmitterStatus:
		    		//elementToBeClickable(transmitterStatusMerlinHome_DropdownValueTen_OR, transmitterStatusMerlinHome_DropdownValueTen_S);
		    		
		    		clickElementWithoutReport(transmitterStatusMerlinHome_DropdownValueTen_OR, transmitterStatusMerlinHome_DropdownValueTen_S);
		    		extentReport.reportScreenShot("Selected "+transmitterStatusMerlinHome_DropdownValueTen_S);
		    		break;
		    	case merlinHomeDeviceCheck:
		    		//elementToBeClickable(deviceCheckMerlinHome_DropdownValueNine_OR, deviceCheckMerlinHome_DropdownValueNine_S);
		    		clickElementWithoutReport(deviceCheckMerlinHome_DropdownValueNine_OR, deviceCheckMerlinHome_DropdownValueNine_S);
		    		extentReport.reportScreenShot("Selected "+deviceCheckMerlinHome_DropdownValueNine_S);
		    		break;
		    	case batteryAdvisoryPatientTransmitterStatus:
		    		//elementToBeClickable(batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_OR, batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_S);
			    	clickElementWithoutReport(batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_OR, batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_S);
			    	extentReport.reportScreenShot("Selected "+batteryAdvisoryPatientTransmitterStatus_DropdownValueTen_S);
		    		break;
		    		
		    	}	    	
		    	
	    	} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	      }
	    //Author: Shafiya Sunkesala
	    public void saveAndAcceptAlert() throws Exception{	
	    	clickSaveButton();
	    	isAlertPresent();
	    	acceptAlert();
	    	isAlertPresent();
	    	acceptAlert();
	    	isAlertPresent();
	    	acceptAlert();
	      }
	    //Author: Shafiya Sunkesala
	    public void cancelAndAcceptAlert() throws Exception{	
	    	clickCancelButton();
		    isAlertPresent();
		    acceptAlert();
		    invisibilityOfElementLocated(pageLoading);
		    
	      }
	 	 //Author: Shafiya Sunkesala
	    public void clickCheckBox(String checkBoxName) throws Exception {      
	       try {
	    	   switch(checkBoxName) {
	    	   case "mobileAppPatientTransmitterStatus":
	        	   if(isEnabled(mobileAppTransCheckBox_OR))
	        		   isElementPresentwithoutException(mobileAppTransCheckBox_OR,mobileAppTransCheckBox_S );
	        		   clickOnElementUsingJs(mobileAppTransCheckBox_OR,mobileAppTransCheckBox_S); 
	        		   extentReport.reportScreenShot("Clicked on " +checkBoxName +" checkbox");
	        	   break;
	    	   case "mobileAppNODC":
	        	   if(isEnabled(mobileAppNODCCheckBox_OR))
	        		   isElementPresentwithoutException(mobileAppNODCCheckBox_OR,mobileAppNODCCheckBox_S );
	        		   clickOnElementUsingJs(mobileAppNODCCheckBox_OR,mobileAppNODCCheckBox_S);  
	        		   extentReport.reportScreenShot("Clicked on " +checkBoxName +" checkbox");
	        	   break;
	    	   case merlinHomePatientTransmitterStatus:
	        	   if(isEnabled(monitorPatientTransmitterStatusMerlinHome_Checkbox_OR))
	        		   isElementPresentwithoutException(monitorPatientTransmitterStatusMerlinHome_Checkbox_OR,monitorPatientTransmitterStatusMerlinHome_Checkbox_S );
	        		   clickOnElementUsingJs(monitorPatientTransmitterStatusMerlinHome_Checkbox_OR, monitorPatientTransmitterStatusMerlinHome_Checkbox_S); 
	        		   extentReport.reportScreenShot("Clicked on " +checkBoxName +" checkbox");
	        	   break;
	           case merlinHomeDeviceCheck:
	        	   if(isEnabled(monitorDirectAlertStatusMerlinHome_Checkbox_OR))
	        		   isElementPresentwithoutException(monitorDirectAlertStatusMerlinHome_Checkbox_OR,monitorDirectAlertStatusMerlinHome_Checkbox_S );
	        		   clickOnElementUsingJs(monitorDirectAlertStatusMerlinHome_Checkbox_OR, monitorDirectAlertStatusMerlinHome_Checkbox_S); 
	        		   extentReport.reportScreenShot("Clicked on  " +checkBoxName +" checkbox");
	        	   break;
	           case batteryAdvisoryPatientTransmitterStatus:
	        	   if(isEnabled(batteryAdvisoryPatientTransmitterStatus_Checkbox_OR))
	        		   isElementPresentwithoutException(batteryAdvisoryPatientTransmitterStatus_Checkbox_OR,batteryAdvisoryPatientTransmitterStatus_Checkbox_S );
	        		   clickOnElementUsingJs(batteryAdvisoryPatientTransmitterStatus_Checkbox_OR, batteryAdvisoryPatientTransmitterStatus_Checkbox_S); 
	        		   extentReport.reportScreenShot("Clicked on " +checkBoxName +"  checkbox");
	        	   break;
	           case batteryAdvisoryDeviceCheck:
	        	   if(isEnabled(batteryAdvisoryDeviceCheck_Checkbox_OR))
	        		   isElementPresentwithoutException(batteryAdvisoryDeviceCheck_Checkbox_OR,batteryAdvisoryDeviceCheck_Checkbox_S );
	        		   clickOnElementUsingJs(batteryAdvisoryDeviceCheck_Checkbox_OR, batteryAdvisoryDeviceCheck_Checkbox_S);
	        		   extentReport.reportScreenShot("Clicked on " +checkBoxName +"  checkbox");
	        	   break;
	           case batteryAdvisoryDailyMIST:
	        	   if(isEnabled(batteryAdvisoryDailyMIST_Checkbox_OR))
	        		   isElementPresentwithoutException(batteryAdvisoryDailyMIST_Checkbox_OR,batteryAdvisoryDailyMIST_Checkbox_S );
	        		   clickOnElementUsingJs(batteryAdvisoryDailyMIST_Checkbox_OR, batteryAdvisoryDailyMIST_Checkbox_S); 
	        		   extentReport.reportScreenShot("Clicked on " +checkBoxName +" checkbox");
	        	   break;
	           }
	       }catch (Exception e) {
				e.printStackTrace();
				throw e;
			}     
	    }
	  //Author: Shafiya Sunkesala
	    public boolean verifyBatteryAdvisorySection() throws Exception{
	        Boolean displayOfSection = false;
	        if(isElementPresent(batteryAdvisory_Heading_OR) && isDisplayed(batteryAdvisory_Heading_OR)) {
		        if(isElementPresent(batteryAdvisoryPatientStatusField) && isDisplayed(batteryAdvisoryPatientStatusField) 
		        		&& isElementPresent(batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_OR) && isDisplayed(batteryAdvisoryPatientTransmitterStatus_ViewMode_NoofDaysText_OR)
		        		&& isElementPresent(batteryAdvisoryDailyMISTField) && isDisplayed(batteryAdvisoryDailyMISTField)
		        		&& isElementPresent(batteryAdvisoryDeviceCheckField) && isDisplayed(batteryAdvisoryDeviceCheckField)
		        		&& isElementPresent(batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_OR) && isDisplayed(batteryAdvisoryDeviceCheckStatus_ViewMode_NoofDaysText_OR)) {
		        	displayOfSection = true;
		        	extentReport.reportScreenShot("Battery Advisory Section is displayed");
		        } 
		        else      	
		        	extentReport.reportScreenShot("Battery Advisory Section is not displayed"); 
		        }
	        else
	        	extentReport.reportScreenShot("Battery Advisory Section is not displayed"); 
	        return displayOfSection;
	    }
	  //Author: Shafiya Sunkesala
	    public void resetValues() throws Exception{
//	    	clickElementWithoutReport(transmitterStatusMerlinHome_Dropdown_Arrow_OR, transmitterStatusMerlinHome_Dropdown_Arrow_S);
//	    	clickElementWithoutReport(transmitterStatusMerlinHome_DropdownValueEight_OR, transmitterStatusMerlinHome_DropdownValueEight_S);
	    	scrollToView(deviceCheckMerlinHome_Dropdown_Arrow_OR);
	    	clickElementWithoutReport(deviceCheckMerlinHome_Dropdown_Arrow_OR, deviceCheckMerlinHome_Dropdown_Arrow_S);
	    	clickElementWithoutReport(deviceCheckMerlinHome_DropdownValueEight_OR, deviceCheckMerlinHome_DropdownValueEight_S);
	    	clickElementWithoutReport(batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_OR, batteryAdvisoryPatientTransmitterStatus_Dropdown_Arrow_S);
	    	clickElementWithoutReport(batteryAdvisoryPatientTransmitterStatus_DropdownValueEight_OR, batteryAdvisoryPatientTransmitterStatus_DropdownValueEight_S);
	    	saveAndAcceptAlert();
	    }

	  //Author: Shafiya Sunkesala
	    public boolean isDisplayedDropdownBox(String dropboxName) throws Exception{
	        Boolean displayOfDropdown = true;
	        switch(dropboxName) {
	        case merlinHomePatientTransmitterStatus:
	        	visibilityOfElementLocated(monitorPatientTransmitterStatusMerlinHome_Checkbox_OR);
	        	if(isElementNotPresentWithoutReport(transmitterStatusMerlinHome_Dropdown_OR, transmitterStatusMerlinHome_Dropdown_S)) {
	        		displayOfDropdown = false;
	        		extentReport.reportScreenShot("Drop down box "+dropboxName+"  is not displayed ");
	        	}
	        	break;
	        	
	        case merlinHomeDeviceCheck:
	        	visibilityOfElementLocated(monitorDirectAlertStatusMerlinHome_Checkbox_OR);
	        	if(isElementNotPresentWithoutReport(deviceCheckMerlinHome_Dropdown_OR, deviceCheckMerlinHome_Dropdown_S))
	        		displayOfDropdown = false;
	        		extentReport.reportScreenShot("Drop down box "+dropboxName+"  is not displayed ");	
	        	break;
	        }
	        return displayOfDropdown;
	    }
	  //Author: Shafiya Sunkesala
	    public boolean verifyDailyMISTSection() throws Exception{
	        Boolean dailyMIST = false;
	        if(isElementPresentwithoutException(batteryAdvisory_DailyMIST_Section_OR, batteryAdvisory_DailyMIST_Section_S)) {
	        	dailyMIST = true;
	        	extentReport.reportScreenShot(batteryAdvisory_DailyMIST_Section_S+ " is displayed");
	        }
	        else
	        	extentReport.reportScreenShot(batteryAdvisory_DailyMIST_Section_S+ " is not displayed");
	        return dailyMIST;
	    }
	    //Author: Shafiya Sunkesala
	    public boolean verifyPatientTransmitter_DeviceCheck_DropdownValues(String checkBoxName) throws InterruptedException{
	    	Boolean verifyDropdownValues = false;
	    	List<String> patientTransmitterStatusDropDownOptions = new ArrayList<String>();
	    	List<String> patientDirectAlertCheckDropDownOptions = new ArrayList<String>();
	    	Collections.addAll(patientTransmitterStatusDropDownOptions,"7 days","8 days","9 days","10 days","11 days","12 days","13 days","14 days", "15 days");
			Collections.addAll(patientDirectAlertCheckDropDownOptions,"1 days","2 days","3 days","4 days","5 days","6 days","7 days", "8 days","9 days","10 days","11 days","12 days","13 days","14 days","15 days");
	    	try {
	    		switch(checkBoxName) {
	    		case merlinHomePatientTransmitterStatus:
	    			if(patientTransmitterStatusDropDownOptions.equals(patientTransmitter_DeviceCheck_TargetDropdownValues(merlinHomePatientTransmitterStatus)))
	    				verifyDropdownValues = true;
	    			extentReport.reportScreenShot(merlinHomePatientTransmitterStatus+": Actual Dropdown values are "
	    				+patientTransmitter_DeviceCheck_TargetDropdownValues(merlinHomePatientTransmitterStatus)+  " Expected: "
	    					+patientTransmitterStatusDropDownOptions+" with days as units");
	    			break;
	    		case merlinHomeDeviceCheck:
	    			if(patientDirectAlertCheckDropDownOptions.equals(patientTransmitter_DeviceCheck_TargetDropdownValues(merlinHomeDeviceCheck)))
	    				verifyDropdownValues = true;
	    			extentReport.reportScreenShot(merlinHomeDeviceCheck+": Actual Dropdown values are "
		    				+patientTransmitter_DeviceCheck_TargetDropdownValues(merlinHomeDeviceCheck)+  " Expected: "
		    						+ ""+patientDirectAlertCheckDropDownOptions+" with days as units");
	    			break;
	    		case batteryAdvisoryPatientTransmitterStatus:
	    			if(patientTransmitterStatusDropDownOptions.equals(patientTransmitter_DeviceCheck_TargetDropdownValues(batteryAdvisoryPatientTransmitterStatus)))
	    				verifyDropdownValues = true;
	    			extentReport.reportScreenShot(batteryAdvisoryPatientTransmitterStatus+": Actual Dropdown values are "
	    				+patientTransmitter_DeviceCheck_TargetDropdownValues(batteryAdvisoryPatientTransmitterStatus)+  " Expected: "
	    					+patientTransmitterStatusDropDownOptions+" with days as units");
	         	   break;
	            case batteryAdvisoryDeviceCheck:
	            	if(patientDirectAlertCheckDropDownOptions.equals(patientTransmitter_DeviceCheck_TargetDropdownValues(batteryAdvisoryDeviceCheck)))
	    				verifyDropdownValues = true;
	    			extentReport.reportScreenShot(batteryAdvisoryDeviceCheck+": Actual Dropdown values are "
		    				+patientTransmitter_DeviceCheck_TargetDropdownValues(batteryAdvisoryDeviceCheck)+  " Expected: "
		    						+ ""+patientDirectAlertCheckDropDownOptions+" with days as units");
	            	break;
	    		}
	    		
	    		return verifyDropdownValues;
	    	}catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	    }
	    //Author: Poojitha
		private final By mobileAppTransCheckBox_OR = By.xpath("//mat-checkbox[@id='monitorTransmitter']");
		private final String mobileAppTransCheckBox_S = "Mobile app transmitter check box";
		private final By mobileAppNODCCheckBox_OR = By.xpath("//mat-checkbox[@id='directAlert']");
		private final String mobileAppNODCCheckBox_S = "Mobile app NODC check box";
		
		    
		 public void editAndSaveMIST()
		 {	    
		 try {
			clickEditButton();
			 assertion.assertEqualsWithReporting(true,verifyLandingPage(),extentReport,"Scheduling and Messaging Page is loaded");
			 clickCheckBox("mobileAppPatientTransmitterStatus");
			 clickCheckBox("mobileAppNODC");
			 clickCheckBox("merlinHomePatientTransmitterStatus");
			 clickCheckBox("merlinHomeDeviceCheck");
			 clickCheckBox("batteryAdvisoryPatientTransmitterStatus");
			 clickCheckBox("batteryAdvisoryDeviceCheck");
			 clickCheckBox("batteryAdvisoryDailyMIST");
			 clicksavebutton();	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 	    }
		 
	public void mistAndNodcValidation()
	{
		
	}
//Ends here



}