
package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.util.ArrayList;
import java.util.List;

import org.checkerframework.checker.optional.qual.Present;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

/**
 * Clinic Administration page for regular user. Default navigation goes to
 * Clinic Profile in sidebar.
 */
public class CA_ClinicProfilePage extends BasePage {

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;

	private final By clinicProfileHeader_OR = By
			.xpath("//div[@id='clinic-profile-wrapper']/div[@class='row']/div[@class='col-md-2']/header");
	private final String clinicProfileHeader_S = "Clinic Profile Page Header";
	private final By pacemakerCRTP_Navigation = By
			.xpath("//div[@id='direct-alert-settings']/ul[@class='nav']/li[@class='nav-item ng-star-inserted'][2]");
	private final By recentTransmissionsNavigation = By.xpath(
			"li[@class='list-item ng-star-inserted'][1]/a[@class='mat-focus-indicator mat-ripple mat-button mat-button-base ng-star-inserted']");

	private final By editButton = By.xpath(
			"//button[@class='mat-focus-indicator mat-raised-button mat-button-base mat-primary ng-star-inserted']");
	private final By saveButton = By.xpath(
			"//button[@class='mat-focus-indicator mat-raised-button mat-button-base mat-primary ng-star-inserted']");

	private final By countryDropdownArrow = By.xpath(
			"//div[@class='col-xs-4 col-xs-offset-1 ng-star-inserted']/div[@class='box']/div[contains(@class,'')][2]/mat-form-field[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/div[contains(@class,'')]/mat-select[contains(@id,'')]/div[contains(@class,'')]/div[contains(@class,'mat-select-arrow-wrapper')]");
	private final By countryDropdownSearch = By
			.xpath("//ngx-mat-select-search[contains(@class,'')]/div[contains(@class,'')]/input[contains(@class,'')]");

	private final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");

	private final By clinicName_OR = By.xpath("//input[@id='merlin_textbox_name']");
	private final String clinicName_S = "Clinic Name";

	private final By DirectAlert_OR = By.xpath("//mat-checkbox[@id='clinicDirectAlert']/label/div");
	private final String DirectAlert_S = "Direct Alert";

	public static Log logger = new Log();

	public CA_ClinicProfilePage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	/*
	 * ---------------- Helper functions ----------------
	 */

	private boolean elementVisibleOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			if (!verifyLandingPage()) {
				extentReport.reportFail(reportFailMsg);
				return false;
			}

			invisibilityOfElementLocated(pageLoading);
			waitForPageLoad();

			if (visibilityOfElementLocated(element)) {
				extentReport.reportPass(reportPassMsg);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		extentReport.reportFail(reportFailMsg);
		return false;
	}

	private void clickElementOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			if (!elementVisibleOnPage(element, "Element found on page", "Element not found on page")) {
				extentReport.reportFail(reportFailMsg);
				return;
			}

			waitForElementToBeClickable(element);
			// invisibilityOfElementLocated(pageLoading);
			clickElement(element);
			extentReport.reportPass(reportPassMsg);
			waitForLoading();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/*
	 * ---------------- Public functions ----------------
	 */

	/*
	 * Click functions
	 */

	public void clickEditButton() throws Exception {
		waitForElementToBeClickable(editButton);
		clickElementOnPage(editButton, "Edit button is clicked from Clinic Profile Page",
				"Edit Button could not be clicked from Clinic Profile Page");
	}

	public void clickSaveButton() throws Exception {
		waitForElementToBeClickable(saveButton);
		clickElementOnPage(saveButton, "Edit button is clicked from Clinic Profile Page",
				"Edit Button could not be clicked from Clinic Profile Page");
	}

//------------ Jeetendra Start --------------------------------------------------------	
	public void clickCancelButton() throws Exception {
		By cancelButton = By.xpath(".//button[@id='cancel']");
		clickElementOnPage(cancelButton, "Cancel button is clicked from Clinic Profile Page",
				"Cancel Button could not be clicked from Clinic Profile Page");
	}

	private final By Clinic_Regional_Setting_header_OR = By.xpath("(.//div[@id='clinicProfileForm']//h3)[3]");
	private final String Clinic_Regional_Setting_header_S = "Clinic Regional Settings";

	private final By ClinicTimeZone_dropdown_OR = By.xpath(".//mat-select[@id='clinicTimeZoneCd']");
	private final String ClinicTimeZone_dropdown_S = "Clinic Regional Settings";

	private final By Language_dropdown_OR = By.xpath(".//mat-select[@id='clinicLocaleCd']");
	private final String Language_dropdown_S = "Language";

	private final By Date_Format_dropdown_OR = By.xpath(".//mat-select[@id='clinicDateFormatCd']/div");
	private final String Date_Format_dropdown_S = "Date Format";

	private final By Time_Format_dropdown_OR = By.xpath(".//mat-select[@id='clinicTimeFormatCd']/div");
	private final String Time_Format_dropdown_S = "Time Format";

	private final By Number_Format_dropdown_OR = By.xpath(".//mat-select[@id='clinicNumberFormatCd']/div");
	private final String Number_Format_dropdown_S = "Number Format";

	private final By Weigth_unit_dropdown_OR = By.xpath(".//mat-select[@id='clinicWeightUnitCd']/div");
	private final String Weigth_unit_dropdown_S = "Weight Unit";
	private final By ClinicTimeZone_Search_OR = By
			.xpath(".//mat-option[@id='mat-option-60']//input[@placeholder='Search...']");

	private final By Timeformat_list_OR = By.xpath(".//div[@id='clinicTimeFormatCd-panel']/mat-option/span");
	private final By Numberformat_list_OR = By.xpath(".//div[@id='clinicNumberFormatCd-panel']/mat-option/span");
	private final By Weightunit_list_OR = By.xpath(".//div[@id='clinicWeightUnitCd-panel']/mat-option/span");
	private final By dateformat_list_OR = By.xpath(".//div[@id='clinicDateFormatCd-panel']/mat-option/span");
	private final By langugage_search_OR = By
			.xpath(".//mat-option[@id='mat-option-61']//input[@placeholder='Search...']");

	public boolean verifyfieldsInClinicRegionalSetting() {
		presenceOfElementLocatedWithReport(Clinic_Regional_Setting_header_OR, Clinic_Regional_Setting_header_S);
		presenceOfElementLocatedWithReport(ClinicTimeZone_dropdown_OR, ClinicTimeZone_dropdown_S);
		presenceOfElementLocatedWithReport(Language_dropdown_OR, Language_dropdown_S);
		presenceOfElementLocatedWithReport(Date_Format_dropdown_OR, Date_Format_dropdown_S);
		presenceOfElementLocatedWithReport(Weigth_unit_dropdown_OR, Weigth_unit_dropdown_S);
		presenceOfElementLocatedWithReport(Time_Format_dropdown_OR, Time_Format_dropdown_S);
		return true;
	}

	// vrushali -- start //blank xpath
	private final By transmitterWithMODCapability_OR = By.xpath("");
	private final String transmitterWithMODCapability_S = "Transmitter with MerlinOnDemand™ capability Section";
	private final By transmitterSrNum_OR = By.xpath("");
	private final String transmitterSrNum_S = "Transmitter Sirial Number";
	private final By emailRecepientList_OR = By.xpath("");
	private final String emailRecepientList_S = "Email Recepient List";
	private final By recepientAuthCheckbox_OR = By.xpath("");
	private final String recepientAuthCheckbox_S = "Require recipient authentication to view Unpaired transmitter emails";
	private final By latestVTVFEpisode_OR = By.xpath("");
	private final String latestVTVFEpisode_S = "Standard limited reports with latest VT/VF episode only";
	private final By clinicPrintPref_OR = By.xpath("");
	private final String clinicPrintPref_S = "Reports specified in Clinic Print Preferences";

	private final By reportWithLatestVPVFRadio_OR = By.xpath("");
	private final String reportWithLatestVPVFRadio_S = "Standard limited reports with latest VT/VF episode only radio button";

	private final By reportWithClinicPrintPreferencesRadio_OR = By.xpath("");
	private final String reportWithClinicPrintPreferencesRadio_S = "Reports specified in Clinic Print Preferences";

	public boolean verifyTransmitterWithMODCapabilityFields() {
		presenceOfElementLocatedWithReport(transmitterWithMODCapability_OR, transmitterWithMODCapability_S);
		presenceOfElementLocatedWithReport(transmitterSrNum_OR, transmitterSrNum_S);
		presenceOfElementLocatedWithReport(emailRecepientList_OR, emailRecepientList_S);
		presenceOfElementLocatedWithReport(recepientAuthCheckbox_OR, recepientAuthCheckbox_S);
		presenceOfElementLocatedWithReport(latestVTVFEpisode_OR, latestVTVFEpisode_S);
		presenceOfElementLocatedWithReport(clinicPrintPref_OR, clinicPrintPref_S);
		return true;
	}

	public void selectreportWithLatestVPVF() {
		clickElement(reportWithLatestVPVFRadio_OR, reportWithLatestVPVFRadio_S);
	}

	public boolean verifyEmailFaxContent4TransmissionsFromUnpairedTransmitters(String radioCaption) {
		boolean isSelected = false;
		if (radioCaption.equalsIgnoreCase("Standard limited reports with latest VT/VF episode only")) {
			isSelectedWithoutReport(reportWithLatestVPVFRadio_OR, reportWithLatestVPVFRadio_S);
			isSelected = true;
		} else if (radioCaption.equalsIgnoreCase("Reports specified in Clinic Print Preferences")) {
			isSelectedWithoutReport(reportWithClinicPrintPreferencesRadio_OR, reportWithClinicPrintPreferencesRadio_S);
			isSelected = true;
		}
		return isSelected;
	}

	// vrushali -- end

	public boolean selectClinicTimezonedropdown(String ClinicTimeZonevalue) {
		presenceOfElementLocatedWithReport(ClinicTimeZone_dropdown_OR, ClinicTimeZone_dropdown_S);
		elementToBeClickable(ClinicTimeZone_dropdown_OR);
		clickElement(ClinicTimeZone_dropdown_OR);
		sendKeys(ClinicTimeZone_Search_OR, ClinicTimeZonevalue);
		sendspecialKeysOnPage("Tab");
		return true;
	}

	public boolean selectClinicLanguage(String Language) {
		presenceOfElementLocatedWithReport(Language_dropdown_OR, Language_dropdown_S);
//		String Language = "English(United States)";
		String clinicLanguageValue = null;
		if (Language.matches("English(United States)")) {
			clinicLanguageValue = "State";
		} else {
			clinicLanguageValue = Language;
		}

		elementToBeClickable(Language_dropdown_OR);
		clickElement(Language_dropdown_OR);
		sendKeys(langugage_search_OR, clinicLanguageValue);
		sendspecialKeysOnPage("Tab");
		return true;
	}

	public boolean selectDateformat(String dateformatvalue) throws InterruptedException {
		presenceOfElementLocatedWithReport(Date_Format_dropdown_OR, Date_Format_dropdown_S);
		elementToBeClickable(Date_Format_dropdown_OR);
		clickElement(Date_Format_dropdown_OR);
		List<WebElement> dateformatlist = findElements(dateformat_list_OR);
		System.out.println(getSizeOfElements(dateformat_list_OR));
		clickOnMatchingValue(dateformatlist, dateformatvalue);
		return true;
	}

	public boolean selectWeightunit(String Weightunitvalue) throws InterruptedException {
		presenceOfElementLocatedWithReport(Weigth_unit_dropdown_OR, Weigth_unit_dropdown_S);
		elementToBeClickable(Weigth_unit_dropdown_OR);
		clickElement(Weigth_unit_dropdown_OR);
		List<WebElement> Weigthunitlist = findElements(Weightunit_list_OR);
		System.out.println(getSizeOfElements(Weightunit_list_OR));
		clickOnMatchingValue(Weigthunitlist, Weightunitvalue);
		return true;
	}

	public boolean selectNumberformat(String numberformatvalue) throws InterruptedException {
		presenceOfElementLocatedWithReport(Number_Format_dropdown_OR, Number_Format_dropdown_S);
		elementToBeClickable(Number_Format_dropdown_OR);
		clickElement(Number_Format_dropdown_OR);
		List<WebElement> numberformatlist = findElements(Numberformat_list_OR);
		System.out.println(getSizeOfElements(Numberformat_list_OR));
		clickOnMatchingValue(numberformatlist, numberformatvalue);
		return true;
	}

	public boolean selectTimeformat(String timeformatvalue) throws InterruptedException {
		presenceOfElementLocatedWithReport(Time_Format_dropdown_OR, Time_Format_dropdown_S);
		elementToBeClickable(Time_Format_dropdown_OR);
		clickElement(Time_Format_dropdown_OR);
		List<WebElement> timeformatlist = findElements(Timeformat_list_OR);
		System.out.println(getSizeOfElements(Weightunit_list_OR));
		clickOnMatchingValue(timeformatlist, timeformatvalue);
		return true;
	}

	public boolean checklangugagevalue() {

		return false;
	}

	public boolean checktimezonemandatorylabel() {
		boolean flag = false;
		By label = By.xpath(".//label[@id='mat-form-field-label-51']//span");
		String temp = getText(label, "Clicnic Time Zone Label mandatory symbol");
		if (temp.trim().matches("*")) {
			flag = true;
		}

		return flag;
	}

	public boolean verifylangugagedropdownvalue() {
		return false;
	}

	public boolean verifynumberformat() {

		return false;
	}

	public boolean verifymessage(String message) {
		boolean flag = false;

		if (isAlertPresent()) {
			String text = getAlertText();
			if (text.contains(message)) {
				acceptAlert();
				flag = true;
			}
		}

		return flag;
	}
	public boolean verifyCM810_message(String message) {
		boolean flag = false;

		if (isAlertPresent()) {
			String text = getAlertText();
			if (text.contains(message)) {
				acceptAlert();
				flag = true;
			}
		}

		return flag;
	}
	public boolean checkvalueinClinicTimelist(String timezonevalue) {
		return false;

	}

	public boolean verifychangesnotsaved() {
		return false;
	}

	public boolean alertclickCancelButton() {

		boolean flag = false;
		if (isAlertPresent()) {
			acceptAlert();
			flag = true;
		}
		return flag;

	}

	public boolean verifyTimeformatvalue(String input) throws InterruptedException {
		boolean flag = false;
		clickElement(Time_Format_dropdown_OR, Time_Format_dropdown_S);
		By TimeFormatdropdownvalue = By.xpath(".//mat-select[@id='clinicTimeFormatCd']/div/parent::mat-select");
		String output = getAttribute(TimeFormatdropdownvalue, "aria-owns");
		if (input.matches(output)) {
			flag = true;
			extentReport.pass(output);
		}

		return flag;
	}

	public boolean verifysavechanges() {
		return false;
	}

	public boolean verifyWeightunit(String input) throws InterruptedException {
		boolean flag = false;
		clickElement(Weigth_unit_dropdown_OR, Weigth_unit_dropdown_S);
		By Weigth_unit_dropdownvalue = By.xpath(".//mat-select[@id='clinicWeightUnitCd']/div/parent::mat-select");
		String output = getAttribute(Weigth_unit_dropdownvalue, "aria-owns");
		if (input.matches(output)) {
			flag = true;
			extentReport.pass(output);
		}
		return flag;
	}

	public boolean verifyDateformat(String input) throws InterruptedException {
		boolean flag = false;
		By dateformatdropdownvalue = By.xpath(".//div[@id='clinicDateFormatCd-panel']/mat-option//span");
		ArrayList output = DropdowngetOptions(Date_Format_dropdown_OR, dateformatdropdownvalue);
		String[] value = input.trim().split(",");
		ArrayList<String> inputvalue = new ArrayList<>();
		for (String element : value) {
			inputvalue.add(element);
		}
		if (inputvalue.contains(output)) {
			flag = true;
		}
		return flag;
	}

	public boolean checknewdateformatatcliniclevel() {
		return false;
	}
//---------------------------- Jeetendra End ------------------------------------------	
	/*
	 * Field fill functions
	 */

	public void fillCountryFromDropdown(String countryName) throws Exception {
		try {
			clickElementOnPage(countryDropdownArrow, "Country Dropdown Arrow is clicked from Clinic Profile Page",
					"Country Dropdown Arrow could not be clicked from Clinic Profile Page");
			sendKeys(countryDropdownSearch, countryName);
			sendKeys(countryDropdownSearch, "" + Keys.ENTER);
			extentReport.reportPass("Country " + countryName + " is filled from dropdown");
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail("Country " + countryName + " could not be filled from dropdown");
			throw e;
		}
	}

	/*
	 * Page navigation functions
	 */

	public void goToDirectAlertPacemakerCRTP_Page() throws Exception {
		clickElementOnPage(pacemakerCRTP_Navigation,
				"Pacemaker / CRT-P sidebar is clicked from Clinic Administration Profile Page",
				"Pacemaker / CRT-P sidebar could not be found");
	}

	public void goToRecentTransmissionsPage() throws Exception {
		scrollToView(recentTransmissionsNavigation);
		clickElementOnPage(recentTransmissionsNavigation,
				"Recent Transmissions primary navigation is clicked from Clinic Administration Profile Page",
				"Recent Transmissions primary navigation could not be clicked from Clinic Administration Profile Page");
	}

	// Verify Clinic Name:
	public boolean verifyClinicName(String expectedClinicName) {
		boolean returnClinicName = false;
		System.out.println(getText(clinicName_OR, clinicName_S));
		try {
			if (expectedClinicName.equals(getText(clinicName_OR))) {
				extentReport.reportPass("ClinicName is same as expected");
				returnClinicName = true;
			}

			else
				extentReport.reportFail("ClinicName is same as expected");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;

		}
		return returnClinicName;

	}

	// Each page class should have this overridden method of Verify Landing page
	@Override
	public boolean verifyLandingPage() {
		Boolean verifyClinicProfilePage = false;

		if (isElementPresentwithoutException(clinicProfileHeader_OR, clinicProfileHeader_S)) {
			verifyClinicProfilePage = true;

		}
		return verifyClinicProfilePage;
	}

	public Boolean VerifyCheckBox() throws Exception {
		Boolean value = false;
		if (isSelectedWithReport(clinicProfileHeader_OR, clinicProfileHeader_S)) {
			value = true;

		}
		return value;
	}

	// -----------------------------------------Alok--------------------------------//

	public void clickOnCheckBox() throws Exception {
		try {
			scrollToView(DirectAlert_OR);
			presenceOfElementLocated(DirectAlert_OR);
			clickElement(DirectAlert_OR);
			extentReport.reportScreenShot("User clicked on Direct Alert check box on Clinic Profile Page");

		} catch (Exception e) {
			extentReport.fail("User not able to click on edit button ");
		}

	}

	public boolean verifyConfirmation() {
		return false;
	}

	public boolean verifyDialogBox() {
		return false;
	}

	public boolean clickOnContinue() {
		return false;
	}
	
	
	
	private final By clinicZipCode_OR = By.xpath("//input[@name='clinicZipCode_zipCode']");
	private final String clinicZipCode_S = "Clinic Zipcode detail";
	private final By UnencryptedPatientInformationCheckBox_OR = By.xpath("//mat-checkbox[@id='clinicDirectAlert']/label/div");
	private final String UnencryptedPatientInformationCheckBox_S = "Clinic Zipcode detail";
	
	
	public boolean verifyUnencryptedPatientInformationCheckBoxPresence() {
		boolean flag=false;
		scrollToViewWithReport(clinicZipCode_OR,clinicZipCode_S);
		if(isElementPresent(UnencryptedPatientInformationCheckBox_OR,UnencryptedPatientInformationCheckBox_S)==true) {
			
			extentReport.reportScreenShot("Include unencrypted patient info in direct alert emails and text messages checkbox is not displayed");
			flag=true;
			return flag;
		}
		else {
			extentReport.reportScreenShot("Include unencrypted patient info in direct alert emails and text messages checkbox is displayed");
			flag=false;
			return flag;
		}
		
	
}
}