package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;

public class CA_ClinicUsers extends BasePage {

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	Assertions assertion;
	public static Log logger = new Log();
	ExtentTest extentTest, child1;

	private final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");
	private final By editButton_OR = By.xpath("//button[@id='edit']");
	private static String editButton_S = "Edit Button";
	private final By saveButton_OR = By.xpath("//button[@id='save']");
	private static String saveButton_S = "Save Button";
	private final By cancelButton_OR = By.xpath("//button[@id='cancel']");
	//shafiya modified name of string 21/02/2022
	private static String cancelButton_S = "Cancel Button";
	private final By clinicUsersHeader_OR = By.xpath(
			"//div[@id='app-container']/app-clinic-admin-layout-cmp/div/div/div/div/app-clinic-users/div[1]/div[1]");
	private final String clinicUsersHeader_S = "Clinic User Header";
	private final By searchUserField_OR = By.xpath("//input[@id='search']");
	private final String searchUserField_S = "Search Field on User page";
	private final By searchedUser_OR = By.xpath("//div[@id='homeTable']/table/tbody/tr/td[1]/span");
	private final String searchedUser_S = "Search User field";
	private final By deleteUserRadioButton_OR = By
			.xpath("//mat-radio-button[@id='mat-radio-280']//div[@class='mat-radio-inner-circle']");
	private final String deleteUserRadioButton_S = "Delete Button for User";
	private final By buttonMoreActions_OR = By.xpath("//button[@aria-label='More Action']");
	private final String buttonMoreActions_S = "More Action";
	private final By buttonDeleteUser_OR = By.xpath("//button[@mattooltip='Delete']");
	private final String buttonDeleteUser_S = "Delete Button";
	private final By spanUserSearch_OR = By.xpath("//div[@class='userSelectionInfo ng-star-inserted']//span");
	private final String spanUserSearch_S = "User Search";
	private final By successMessage_OR = By.xpath("//div[@aria-label='Success']");
	private final String successMessage_S = "Success message";
	
	private final By radioButtonInGrid_OR = By.xpath("//div[@id='homeTable']/table/tbody/tr/td[5]/mat-radio-button");
	private final String radioButtonInGrid_S = "Radio button";
	
	private final By searchedUserType_OR = By.xpath("//div[@id='homeTable']/table/tbody/tr/td[2]");
	private final String searchedUserType_S = "Searched User type";
	
	//Poojitha
	private final By addUser_OR = By.xpath("//div[@class='action-buttons']/a");
	private final String addUser_S = "Add User button";
	private final By firstName_OR = By.xpath("//input[@id='firstName_firstName']");
	private final String firstName_S = "First name text box";
	private final By lastName_OR = By.xpath("//input[@id='lastName_lastName']");
	private final String lastName_S = "Last name text box";
	private final By userId_OR = By.xpath("//input[@id='userId_userId']");
	private final String userId_S = "User Id text box";
	private final By password_OR = By.xpath("//input[@id='password_password']");
	private final String password_S = "Password text box";
	private final By confirmPassword_OR = By.xpath("//input[@id='confirmPassword_confirmPassword']");
	private final String confirmPassword_S = "Confirm Password text box";
	private final By userTypeDropdown_OR = By.xpath("//mat-select[@id='individualType']");
	private final String userTypeDropdown_S = "User type dropdown";
	private final By userTypePhysician_OR = By.xpath("//div[@id='individualType-panel']/mat-option[1]");
	private final String userTypePhysician_S = "User type dropdown panel";
	private final By userTypeAllied_OR = By.xpath("//div[@id='individualType-panel']/mat-option[2]");
	private final String userTypeAllied_S = "User type dropdown panel";
	private final By userTypeAssistant_OR = By.xpath("//div[@id='individualType-panel']/mat-option[3]");
	private final String userTypeAssistant_S = "User type dropdown panel";		
	private final By adminCheckbox_OR = By.xpath("//mat-checkbox[@id='administrator']");
	private final String adminCheckbox_S = "Administrator checkbox";
	private final By patientDataEntryCheckbox_OR = By.xpath("//mat-checkbox[@id='canEnrollPatient']");
	private final String patientDataEntryCheckbox_S = "Patient data entry checkbox";
	private final By areaCode_OR = By.xpath("//input[@id='mainAreaCode_areaCode']");
	private final String areaCode_S = "Area code text box";
	private final By mainPhone_OR = By.xpath("//input[@id='mainPhoneNum_phoneNum']");
	private final String mainPhone_S = "Main phone number text box";
	private final By securityStamp_OR = By.xpath("//input[@id='securityStamp_securityStamp']");
	private final String securityStamp_S = "Security stamp text box";
	private final By emailAddress_OR = By.xpath("//input[@id='email_email']");
	private final String emailAddress_S = "Email address text box";
	private final By pageLoading_OR = By.xpath("//div[@class='spinnerWrapper show']");
	private final String pageLoading_S = "Page loading symbol";
	private final By messagePopup_OR = By.xpath("//div[@id='toast-container']/div/div[2]");
	private final String messagePopup_S = "message popup";
	// Ends here
	//shafiya added xpaths on 21/02/2021
	private final By userNameInTable_OR = By.xpath("//div[@id='homeTable']/table/tbody/tr/td[contains(@class,'user_name')]");
	private final String userNameInTable_S = "User Name in Table";
	private final By locs_VisibleToUser_LeftSelectBox_OR = By.xpath("//select[@id='sample_2mmc-leftSelectBox']/option");
	private final String locs_VisibleToUser_LeftSelectBox_S = "Locations Visible To This User Left Select Box";
	private final By locs_VisibleToUser_RightSelectBox_OR = By.xpath("//select[@id='sample_2mmc-rightSelectBox']/option");
	private final String locs_VisibleToUser_RightSelectBox_S = "Locations Visible To This User Right Select Box";
	private final By addBtn_OR = By.xpath("//button[@id='mmc-customizeHomepage-addButton']");
	private final String addBtn_S = "Add button under Locations Visible To This User";
	private final By clinicUsers_SuccessMessage_OR = By.xpath("//div[text()=' Success ']");
	private final String clinicUsers_SuccessMessage_S = "Clinic Users add success message";	
	//Ends here
	public CA_ClinicUsers(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		}

	public boolean elementVisibleOnPage(By element, String reportPassMsg, String reportFailMsg) throws Exception {
		try {
			/*
			 * if (!verifyLandingPage()) { extentReport.reportFail(reportFailMsg); return
			 * false; }
			 */

			invisibilityOfElementLocated(pageLoading);
			waitForPageLoad();

			if (visibilityOfElementLocated(element)) {
				extentReport.reportPass(reportPassMsg);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		extentReport.reportFail(reportFailMsg);
		return false;
	}

	@Override
	public boolean verifyLandingPage() {
		Boolean clinicUser = false;
		if (isElementPresentwithoutException(clinicUsersHeader_OR, clinicUsersHeader_S)) {
			invisibilityOfElementLocated(pageLoading_OR);
			clinicUser = true;
			extentReport.reportScreenShot("Clinic User page is displayed");
		}
		return clinicUser;
	}

	public boolean verifyUserCreated(String expectedUserID) {
		boolean checkUserCreated = false;
		try {
			visibilityOfElementLocatedWithoutReport(searchUserField_OR, searchUserField_S);
			sendKeys(searchUserField_OR, searchUserField_S, expectedUserID);
			if (visibilityOfElementLocatedWithoutReport(searchedUser_OR, searchedUser_S)) {
				if (expectedUserID.contains(getText(searchedUser_OR))) {
					extentReport.reportPass("User able to find and exist in Clinic");
					checkUserCreated = true;
				} else
					extentReport.reportPass("User able to find and exist in Clinic");

			}

			else
				extentReport.reportFail("No Data found, User doesn't exist");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return checkUserCreated;
	}

	public boolean deleteUser(String expectedUserID) {
		// TODO Auto-generated method stub
		boolean checkDeleteUser = false;
		try {
			extentReport.reportScreenShot("Searching for User to be deleted");
			clickElement(searchUserField_OR, searchUserField_S);
			sendKeys(searchUserField_OR, searchUserField_S, expectedUserID);
			extentReport.reportScreenShot("Clicking on radio button to delete searched user");
			/*
			 * if (!isSelectedWithReport(deleteUserRadioButton_OR, deleteUserRadioButton_S))
			 * clickElement(deleteUserRadioButton_OR, deleteUserRadioButton_S);
			 * 
			 * clickElement(buttonMoreActions_OR, buttonMoreActions_S);
			 * clickElement(buttonDeleteUser_OR, buttonDeleteUser_S);
			 * 
			 * if (isDisplayedWithReport(successMessage_OR, successMessage_S)) {
			 * extentReport.reportScreenShot("Deleted User Successfully"); checkDeleteUser =
			 * true; } else
			 * extentReport.reportScreenShot("User is not deleted successfully");
			 */

			checkDeleteUser = true;
		} catch (Exception e) {
			e.getStackTrace();
			throw e;

		}
		return checkDeleteUser;
	}

	public boolean verifyUserType(String expectedUserID, String userType) {
		boolean isUserPresent=false;
		try {
			visibilityOfElementLocatedWithoutReport(searchUserField_OR, searchUserField_S);
			sendKeys(searchUserField_OR, expectedUserID);
			if (visibilityOfElementLocatedWithoutReport(searchedUser_OR, searchedUser_S))
			{
				if (expectedUserID.equals(getText(searchedUser_OR)))
				{
					clickElement(radioButtonInGrid_OR);
					loading();
					if(getText(searchedUserType_OR).equals(userType)) {
						isUserPresent=true;	
					}
										
				}
				}else {
					extentReport.reportFail("No Data found, User doesn't exist");					
				}
		}catch (Exception e) {
			e.getStackTrace();
			throw e;

		}
		return isUserPresent;
	}
	
//Poojitha
	
	
	public void createUser(String customerType, boolean adminRights,String userType)
	{
		clickElement(addUser_OR,addUser_S);
		//assertion.assertEqualsWithReporting(true,verifyLandingPage(),extentReport,"Clinic Users Page is loaded");
		loading();
		String value = CommonUtils.randomUserNameWithDate();
		sendKeys(firstName_OR,firstName_S,value);
		sendKeys(lastName_OR,lastName_S,value);
		sendKeys(userId_OR,userId_S,value);
		sendKeys(password_OR,password_S,value);
		sendKeys(confirmPassword_OR,confirmPassword_S,value);
		if(adminRights == true)
		{
		clickElement(adminCheckbox_OR,adminCheckbox_S);
		}
		if(customerType.equalsIgnoreCase("SP2"))
		{
		clickElement(patientDataEntryCheckbox_OR,patientDataEntryCheckbox_S);
		}
		if(userType.equalsIgnoreCase("AlliedProfessional"))
		{
		clickElement(userTypeDropdown_OR,userTypeDropdown_S);
		clickElement(userTypeAllied_OR,userTypeAllied_S);
		}
		else if (userType.equalsIgnoreCase("Assistant"))
		{
			clickElement(userTypeDropdown_OR,userTypeDropdown_S);
			clickElement(userTypeAssistant_OR,userTypeAssistant_S);
		}
		sendKeys(areaCode_OR,areaCode_S,CommonUtils.randomareaCode());
		sendKeys(mainPhone_OR,mainPhone_S,CommonUtils.randomMainPhone());
		sendKeys(securityStamp_OR,securityStamp_S,value);
		sendKeys(emailAddress_OR,emailAddress_S,value+"@abbott.com");
		scrollToViewWithoutReport(saveButton_OR,saveButton_S);
		clickElement(saveButton_OR,saveButton_S);
		loading();
		if(getText(messagePopup_OR,messagePopup_S).trim().equalsIgnoreCase("Thanks. Your user has been added."))
		extentReport.reportScreenShot(userType + " user has been added successfully for "+ customerType + " clinic.");
		else
		extentReport.fail("Unable to add "+ userType +" user for "+customerType +" clinic.");
	}
	//shafiya added method on 21/02/2021
	//This method clicks on save location
	public void clickSaveBtn() throws Exception {
		try {
			if (visibilityOfElementLocatedWithoutReport(saveButton_OR,saveButton_S )) {
				elementToBeClickable(saveButton_OR,saveButton_S);				
				clickElement(saveButton_OR,saveButton_S);
				presenceOfElementLocatedWithReport(clinicUsers_SuccessMessage_OR, clinicUsers_SuccessMessage_S);
				clickElement(clinicUsers_SuccessMessage_OR, clinicUsers_SuccessMessage_S);
				//invisibilityOfElementLocatedWithoutReport(ClinicLocations_toastSuccessMessage_OR,ClinicLocations_toastSuccessMessage_S);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	//shafiya added method on 21/02/2021
	//This method  clicks on Edit button
	public void clickEditButton() throws Exception {
		try {
			if (visibilityOfElementLocatedWithoutReport(editButton_OR, editButton_S)) {
				
				elementToBeClickable(editButton_OR, editButton_S);				
				clickElement(editButton_OR, editButton_S);
				presenceOfElementLocatedWithoutReport(cancelButton_OR, cancelButton_S);
				extentReport.reportScreenShot("User click on Edit Button");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	//shafiya added method on 21/02/2021
	//This method  clicks on radio button in table based on User Name
	public void clickRadioBtn_InTable(String expectedUserName) throws Exception {
		List<WebElement> radioBtns = findElementslist(radioButtonInGrid_OR,radioButtonInGrid_S);
		for (int i = 0; i < radioBtns.size(); i++) {
			String columnUserName=getText(userNameInTable_OR, userNameInTable_S);
			if(columnUserName.equals(expectedUserName)) {
				elementToBeClickable(radioButtonInGrid_OR,radioButtonInGrid_S);
				clickElement(radioButtonInGrid_OR,radioButtonInGrid_S);
				break;
			}
		}

	}
	//shafiya added method on 21/02/2021
	//This method  adds location from left table to right table
	public boolean addLocation_RightSlectBox(String expectedLocation) throws Exception {
		Boolean isLocationAdded_Right = false;
		List<WebElement> locationsList_LeftTable = findElementslist(locs_VisibleToUser_LeftSelectBox_OR,locs_VisibleToUser_LeftSelectBox_S);
		List<WebElement> locationsList_RightTable = findElementslist(locs_VisibleToUser_RightSelectBox_OR,locs_VisibleToUser_RightSelectBox_S);
		for (int i = 0; i < locationsList_LeftTable.size(); i++) {
			String locValue = getText(locs_VisibleToUser_LeftSelectBox_OR,locs_VisibleToUser_LeftSelectBox_S);
			if(locValue.equals(expectedLocation)) {
				elementToBeClickable(locs_VisibleToUser_LeftSelectBox_OR,locs_VisibleToUser_LeftSelectBox_S);
				clickElement(locs_VisibleToUser_LeftSelectBox_OR,locs_VisibleToUser_LeftSelectBox_S);
				
				elementToBeClickable(addBtn_OR,addBtn_S);
				clickElement(addBtn_OR,addBtn_S);				
				break;
			}
		}
		for (int i = 0; i < locationsList_RightTable.size(); i++) {
			String locValue_Right = getText(locs_VisibleToUser_RightSelectBox_OR,locs_VisibleToUser_RightSelectBox_S);
			if(locValue_Right.equals(expectedLocation)) {
				isLocationAdded_Right = true;
				break;
			}
		}
		return isLocationAdded_Right;

	}
	//shafiya added method on 21/02/2021
	//This method associates clinic location to Clinic
	public void associateClinicLocation() throws Exception{
		String expectedUserName = "Clinic, Sp2";
		clickRadioBtn_InTable(expectedUserName);
		addLocation_RightSlectBox("Hyderabad");
		//entermandatory info
		clickSaveBtn();	
		
	}
	
}
