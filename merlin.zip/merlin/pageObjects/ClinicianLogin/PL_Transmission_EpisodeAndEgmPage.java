package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.test.qa.assertions.Assertions;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.utilities.CommonUtils;

public class PL_Transmission_EpisodeAndEgmPage extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	Assertions assertion;
	
	public PL_Transmission_EpisodeAndEgmPage(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	
	//Poojitha
	private final By pageLoading_OR = By.xpath("//div[@class='spinnerWrapper']");
	private final String pageLoading_S = "Page loading symbol";
	private final By episodeTypeSpan_OR = By.xpath("//span[@id='lbl_episode-egm-icm_show_episode_type']");
	private final String episodeTypeSpan_S = "Show Episode Type Span";
	private final By episodeTable_OR = By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr");
	private final String episodeTable_S = "Episodes table";
	private final By egmGainViewerButton_OR = By.xpath("//button[@id='label_egm_gain_viewer']");
	private final String egmGainViewerButton_S = "EGM Gain Viewer button";
	private final By episodeAndEgmCloseButton_OR = By.xpath("//button[@id='btn_popup-pdf_close']");
	private final String episodeAndEgmCloseButton_S ="Episode and EGM Pdf close button";
	private final By gainValue_OR = By.xpath("//div[@id='gainTextWrapper']/h5");
	private final String gainValue_S = "Gain value";
	private final By gainViewerCloseButton_OR = By.xpath("//*[@id='mat-dialog-1']/app-egm-viewer-popup/div/header/div/button[2]");
	private final String gainViewerCloseButton_S = "Gain viewer close button";
	private final By episodesAndEGMLink_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']");
	private final String episodesAndEGMLink_S = "Episodes and EGM Hyperlink";
	private final By incrementButton_OR = By.xpath("//span[text()=' add ']//..//..");
	private final String incrementButton_S =  "Gain increment button";
	private final By decrementButton_OR = By.xpath("//span[text()=' remove ']//..//..");
	private final String decrementButton_S =  "Gain decrement button";
	private final By resetButton_OR = By.xpath("//span[text()=' restart_alt ']//..//..");
	private final String resetButton_S = "Reset button";
	private final By transmission_OR = By.partialLinkText("Transmission");
	private final String transmission_S = "Transmission";
	private final By selectEpisodeCheckbox_OR = By.xpath("//tr[@id='mnu_episode-egm-icm__1']/td[12]/mat-checkbox");
	private final String selectEpisodeCheckbox_S = "selecting episode checkbox";
	private final By appropriateAssessmentType_OR = By.xpath("//mat-chip[@id='chb_episode-egm-icm_assesment2600']");
	private final String appropriateAssessmentType_S = "Appropriate assessment type";
	private final By inappropriateAssessmentType_OR = By.xpath("//mat-chip[@id='chb_episode-egm-icm_assesment2601']");
	private final String inappropriateAssessmentType_S = "Appropriate assessment type";
	private final By notSureAssessmentType_OR = By.xpath("//mat-chip[@id='chb_episode-egm-icm_assesment2602']");
	private final String notSureAssessmentType_S = "Appropriate assessment type";
	private final By notAssessedAssessmentType_OR = By.xpath("//mat-chip[@id='chb_episode-egm-icm_assesment2603']");
	private final String notAssessedAssessmentType_S = "Appropriate assessment type";
	private final By downloadSpreadSheet_OR = By.xpath("//button[@id='btn_episode-egm-icm-more_action-list-item_Download Spreadsheet']");
	private final String downloadSpreadSheet_S = "Download spreadsheet button";
	private final By cancelButton_OR = By.xpath("//button[@id='btn_popup-pdf_close2']"); //defect
	private final String cancelButton_S = "Cancel button";
	private final By  assessmentDropdown_OR = By.xpath("//mat-select[@id='dd_popup-pdf-other_assesmentTypes']");
	private final String assessmentDropdown_S = "Set assessment dropdown";
	private final By printButton_OR = By.xpath("//button[@id='btn_popup-pdf_print']");
	private final String printButton_S = "Print button";
	private final By markForPrintingCheckbox_OR = By.xpath("//mat-checkbox[@id='ICMEGMPopupOtherContentPrintCheck']");
	private final String markForPrintingCheckbox_S = "Mark for printing checkbox";	
	//Ends here
	
	//Meenakshi
		private final By episodeAndEgmGain_OR = By.xpath("//div[@id='gainTextWrapper']/h5");
	private final String episodeAndEgmGain_S ="Episode and EGM Gain Value";
	private final By episodeAndEgmSweepSpeed_OR = By.xpath("//*[@id=\"mat-dialog-1\"]/app-egm-viewer-popup/div/div[1]/div[2]/p");
	private final String episodeAndEgmSweepSpeed_S ="Episode and EGM Sweep Speed";
	private final By egmGainViewerCloseButton_OR = By.xpath("//*[@id=\"mat-dialog-1\"]/app-egm-viewer-popup/div/header/div/button[2]");
	private final String egmGainViewerCloseButton_S ="Episode and EGM Pdf close button";
	private final By transmissionLink_OR = By.xpath("//*[@id=\"lbl_transmission-list_td-transmission1\"]/div");
	private final String transmissionLink_S ="transmission link";
	private final By episodeEPGLink_OR =  By.xpath("//*[@id=\"btn_transmission_summary_left_menu_1_0\"]");
	private final String episodeEPGLink_S ="Episode and EGM link";
	private final By egmGainViewer_OR =  By.xpath("//*[@id=\"popup-wrapper\"]/div[1]/div[2]/div[1]/div[3]");
	private final String egmGainViewer_S ="EGM Gain Viewer";
	private final By episodeTypeList_OR =  By.xpath("//*[@id=\"mat-chip-list-1\"]");
	private final String episodeTypeList_S ="Episode Type List";
	private final By recentTrnsToTab_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinician']/span");
	private final String recentTrnsToTab_S ="RecentTransmision Top Tab";
	private final By episodeSearch_OR =By.xpath("//*[@id=\"txt_episode-egm-icm_search\"]");
	private final String episodeSearch_S ="RecentTransmision Top Tab";
	
	//shafiya added below xpaths: 17/02/2022 Need to change once Id are given
	private final By episode_DateOrTime_Label_OR =By.xpath("//table[@id='episode-egm-non-icm-grid']//button[contains(text(),'Date/Time')]");
	private final String episode_DateOrTime_Label_S ="Date/Time Label";
	private final By episode_ZoneOrType_Label_OR =By.xpath("//table[@id='episode-egm-non-icm-grid']//th[contains(text(),'Zone/Type')]");
	private final String episode_ZoneOrType_Label_S ="Zone/Type Label";
	private final By episode_Duration_Label_OR =By.xpath("//table[@id='episode-egm-non-icm-grid']//button[contains(text(),'Duration')]");
	private final String episode_Duration_Label_S ="Duration Label";
	private final By episode_EGM_Label_OR =By.xpath("//table[@id='episode-egm-non-icm-grid']//button[contains(text(),'Duration')]");
	private final String episode_EGM_Label_S ="EGM Label";
	private final By episode_PrimaryFilter_drpdwn_Arrow_OR =By.xpath("//mat-select[@id='dd_egm-non-icm-device-data_primary-filter']/div/div[2]/div[contains(@class,'mat-select-arrow')]");
	private final String episode_PrimaryFilter_drpdwn_Arrow_S ="Episode Primary Filter dropdown Arrow";
	private final By episode_PrimaryFilter_drpdwn_ListValues_OR =By.xpath("//div[@id='dd_egm-non-icm-device-data_primary-filter-panel']/mat-option");
	private final String episode_PrimaryFilter_drpdwn_ListValues_S ="Episode Primary Filter dropdown Values";
	private final By episode_SecondaryFilter_drpdwn_ListValues_OR =By.xpath("//div[@id='dd_egm-non-icm-device-data_primary-filter-panel']/mat-option");
	private final String episode_SecondaryFilter_drpdwn_ListValues_S ="Episode Secondary Filter dropdown Values";
	private final By episode_EGM_Search_OR =By.xpath("//div[@id='dd_egm-non-icm-device-data_primary-filter-panel']/mat-option");
	private final String episode_EGM_Search_S ="Episode and EGM Search Input Box";
	//shafiya added below xpaths: 23/02/2022 
	private final By egmGainViewerWindow_OR = By.xpath("//mat-dialog-container[contains(@class,'mat-dialog-container')]");
	private final String egmGainViewerWindow_S = "EGM Gain Viewer Modal Window";
	private final By egmGainViewer_Date_OR = By.xpath("(//div[@class='viewer-detail']/div[contains(@class,'row')])[1]/div[2]/div");
	private final String egmGainViewer_Date_S = "Date in EGM Gain Viewer Modal Window";
	private final By egmGainViewer_Duration_OR = By.xpath("(//div[@class='viewer-detail']/div[contains(@class,'row')])[2]/div[2]/div");
	private final String egmGainViewer_Duration_S = "Duration in EGM Gain Viewer Modal Window";
	private final By egmGainViewer_EpisodeType_OR = By.xpath("//div[@class='viewer-detail']/p");
	private final String egmGainViewer_EpisodeType_S = "Episode Type in EGM Gain Viewer Modal Window";
	private final By egmGainViewer_Wave_OR = By.xpath("//div[contains(@id,'highcharts')]");
	private final String egmGainViewer_Wave_S = "EGM Wave form in EGM Gain Viewer Modal Window";
	
	// Alok
	
	private final By episodeType_AT_OR =By.xpath("//mat-chip[@id='chb_episode-egm-icm_episode1']");
	private final String episodeType_AT_S ="Episode Type AT/AF";
	private final By episodeType_Brady_OR =By.xpath("//mat-chip[@id='chb_episode-egm-icm_episode2']");
	private final String episodeType_Brady_S ="Episode Type Brady";
	private final By episodeType_Pause_OR =By.xpath("//mat-chip[@id='chb_episode-egm-icm_episode3']");
	private final String episodeType_Pause_S ="Episode Type Pause";
	private final By episodeType_Symtom_OR =By.xpath("//mat-chip[@id='chb_episode-egm-icm_episode3']");
	private final String episodeType_Symtom_S ="Episode Type Symtom";
	private final By episodeType_Tachy_OR =By.xpath("//mat-chip[@id='chb_episode-egm-icm_episode4']");
	private final String episodeType_Tachy_S ="Episode Type Tachy";
	
	// Alok-End
	//Kundan
	private final By selectpt_Checkbox_EpisodeEGM_Page_OR = By.xpath("//*[@id=\"mat-checkbox-521\"]/label/div");
	private final String selectpt_Checkbox_Transmission_Page_S = "Episode EGM page select patient check box";
	
	private final By moreAction_OR = By.xpath("//button[@id='btn_episode-egm-icm_selectMoreAction']");
	private final String moreAction_S = "More Action Button";
	
	private final By moreAction_ViewEpisode_OR = By.xpath("//button[@id=\"btn_episode-egm-icm-more_action-list-item_View Episodes\"]");
	private final String moreAction_ViewEpisode_S = "More Action view episode option";
	
	private final By episodeand_EGM_Window_OR = By.xpath("//h5[@id=\"title_popup-pdf_main_title\"]");
	private final String episodeand_EGM_Window_S = "Episode and EGM window";
	
	private final By episodeandegm_Selfassesment_DropDown_OR = By.xpath("//mat-select[@id=\"dd_popup-pdf-other_assesmentTypes\"]/div/div[2]");
	private final String episodeandegm_Selfassesment_DropDown_S = "Episode and EGM window self assesment drop down";
	
	private final By selfassesment_DropDown_Inappropiate_Option_OR = By.xpath("//mat-option[@id=\"mat-option-40\"]");
	private final String selfassesment_DropDown_Inappropiate_Option_S = "Episode and EGM window self assesment drop down Inappropiate_Option";
	
	private final By selfassesment_DropDown_Appropiate_Option_OR = By.xpath("//mat-option[@id=\"mat-option-41\"]");
	private final String selfassesment_DropDown_Appropiate_Option_S = "Episode and EGM window self assesment drop down Appropiate_Option";
	
	private final By selfassesment_DropDown_Notsure_Option_OR = By.xpath("//mat-option[@id=\"mat-option-42\"]");
	private final String selfassesment_DropDown_Notsure_Option_S = "Episode and EGM window self assesment drop down Notsure_Option";
	
	private final By episodeandegm_window_Save_Button_OR = By.xpath("//button[@id=\"btn_popup-pdf_save\"]");
	private final String episodeandegm_window_Save_Button_S = "Episode and EGM window self assesment drop down Notsure_Option";
//Ends here

	
	//Vrushali - block start
	
		private final By tier1FilterDrpdown_OR = By.xpath("//mat-select[@id='dd_episode-egm-icm_RT_T1_Filter']");
		private final String tier1FilterDrpdown_S = "Show Episode Filter DropDown";
		
		private final String tier1FilterDrpdownOptions_OR = "(//div[@id='dd_episode-egm-icm_RT_T1_Filter-panel']/mat-option)[{0}]";
		private final String tier1FilterDrpdownOptions_S = "List of Episodes Options";
		
		private final String moreActionsOptions_OR = "//button[contains(@id, '{0}')]";
		private final String moreActionsOptions_S = "More Actions dropdown options";
		
		private final By moreActions_OR = By.xpath("//button[@id='btn_episode-egm-icm_selectMoreAction']");
		private final String moreActions_S = "Show Episode Filter DropDown";
		
		private final By assessmentTypeList_OR = By.xpath("//mat-select[@id='dd_popup-pdf-other_assesmentTypes']");
		private final String assessmentTypeList_S = "Set Assessment List";
		
		private final By assessmentNotes_OR = By.xpath("//textarea[@id='txt_popup-pdf_notes']");
		private final String assessmentNotes_S = "Type Assessment notes";
		
		private final By assessmentSaveBtn_OR = By.xpath("//button[@id='btn_popup-pdf_save']");
		private final String assessmentSaveBtn_S = " Assessment and notes Save Button";
		
		private final By assessmentCloseBtn_OR = By.xpath("//button[@id='btn_popup-pdf_close']");
		private final String assessmentCloseBtn_S = " Assessment and notes Close Button";
		
		public void clickAssessmentDialogCloseBtn() {
			clickElement(assessmentCloseBtn_OR, assessmentCloseBtn_S);
		}
		
		//This method Select assessment from the list
		public void selectAssessmentFromList(String assessmentType) {
			clickElement(assessmentTypeList_OR, assessmentTypeList_S);
			List<WebElement> assessment = driver.findElements(By.tagName("mat-option"));
			int rowsSize = assessment.size();
			if (!(rowsSize == 0)) {
				for (int i = 1; i <= assessment.size() - 1; i++) {
					String assessmentname = driver.findElement(By.xpath("//mat-option[" + i + "]")).getText();
					if(assessmentname.contains(assessmentType)) {
						clickElement(By.xpath("//mat-option[" + i + "]"), "Click on Assessment from the List");
					}
				}
			}
		}
		
		 //Below method assign the assessment and enter notes and validates if it is getting saved successfully.
		public boolean assignAssessmentAndNotesAndSave(String notes, String assessmentType) {
			boolean flag = false;
			selectAssessmentFromList(assessmentType);
			sendKeys(assessmentNotes_OR, assessmentNotes_S, notes);
			clickElement(assessmentSaveBtn_OR, assessmentSaveBtn_S);
			//need to add validation for assessment is successfully saved. Open Bug - PCN00031392
				
			return flag;
		}
		
		//Below Method traverse through the Episodes table and find the episode and click on its timestamp
		public void clickonEpisodeTimestamp(String timestamp) {
			List<WebElement> rows = driver.findElements(episodeTable_OR); //table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr
			int rowsSize = rows.size();
			if (!(rowsSize == 0)) {
				for (int i = 1; i <= rows.size() - 1; i++) {
					String episodeTimestamp = driver.findElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[5]/div/span")).getText();
					if(timestamp.equalsIgnoreCase(episodeTimestamp)) {
						clickElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[\" + i + \"]/td[5]/div/span"), "Click on Episode and EGM timestamp");
						break;
					}
				}
			}
		}
		
		//Below Method traverse through the Episodes table and find the episode and click on its checkbox
		public void selectEpisodeAndEGMChBx(String episodeTimestamp) {
			
			List<WebElement> rows = driver.findElements(episodeTable_OR); //table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr
			int rowsSize = rows.size();
			if (!(rowsSize == 0)) {
				for (int i = 1; i <= rows.size() - 1; i++) {
					String episodeTimestamp1 = driver.findElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[5]/div/span")).getText();
					if(episodeTimestamp.equalsIgnoreCase(episodeTimestamp1)) {
						clickElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[12]/mat-checkbox"), "Click on Episode and EGM checkbox");
						break;
					}
				}
			}
		}
		
		//This method will select from More Actions dropdown after selecting Episode and EGM
		public void selectFromMoreActions(String option) {
			clickElement(moreActions_OR, moreActions_S);
			clickElement(By.xpath(moreActionsOptions_OR.replace("{0}", option)), moreActionsOptions_S);
		}
		
		public boolean validateTransDateAndTime(String timestamp) {
			boolean flag = false;
			
			return flag;
		}
		//select option from tier 1 filter
		public void selectTierOneFilterOption(String option) {

			elementToBeClickable(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
			clickOnElementUsingJs(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
			switch (option) {
			case "Current":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "1")),
						tier1FilterDrpdownOptions_S);
				clickOnElementUsingJs(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "1")), tier1FilterDrpdownOptions_S);
				break;
			case "1 Week":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "2")),
						tier1FilterDrpdownOptions_S);
				clickOnElementUsingJs(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "2")), tier1FilterDrpdownOptions_S);
				break;
			case "2 Weeks":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "3")),
						tier1FilterDrpdownOptions_S);
				clickElement(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "3")), tier1FilterDrpdownOptions_S);
				break;
			case "30 days":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "4")),
						tier1FilterDrpdownOptions_S);
				clickElement(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "4")), tier1FilterDrpdownOptions_S);
				break;
			case "60 days":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "5")),
						tier1FilterDrpdownOptions_S);
				clickElement(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "5")), tier1FilterDrpdownOptions_S);
				break;
			case "90 days":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "6")),
						tier1FilterDrpdownOptions_S);
				clickElement(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "6")), tier1FilterDrpdownOptions_S);
				break;
			case "120 days":
				elementToBeClickable(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "7")),
						tier1FilterDrpdownOptions_S);
				clickElement(By.xpath(tier1FilterDrpdownOptions_OR.replace("{0}", "7")), tier1FilterDrpdownOptions_S);
				break;
			default:
				System.out.println("Not able to find the optionin dropdown");
			}

		}
		//Vrushali - block ends
	//Poojitha
	public void egmGainViewerValidation(String gainValue) throws Exception
	{
		List<WebElement> rows = findElements(episodeTable_OR);
		for (int i = 1; i <= rows.size(); i++) {
			String attributeValue = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
			if (attributeValue.equalsIgnoreCase("EGM")) {
			clickElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"),"EGM button");
			defaultGainViewerValidation(gainValue);
			navigateToTransmissionPage();
			loading();
			navigateToEpisodesAndEGMs();
			loading();
		}
			else
			extentReport.info("This episode does not contain any EGM report");
		}
	}
	
	public void gainChangeValidation(String operation, String gainValue) throws Exception
	{
		List<WebElement> rows = findElements(episodeTable_OR);
		for (int i = 1; i <= rows.size(); i++) {
			String attributeValue = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
			if (attributeValue.equalsIgnoreCase("EGM")) {
			clickElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"),"EGM button");
			gainIncrementValidation(operation,gainValue);
			navigateToTransmissionPage();
			loading();
			navigateToEpisodesAndEGMs();
			loading();
			}
			else
			extentReport.info("This episode does not contain any EGM report");
		}
	}
	
	public void gainIncrementValidation(String operation, String defaultGain) throws InterruptedException
	{
		if(!isDisplayed(egmGainViewerButton_OR))
		clickEpisodeAndEgmPdfCloseButton();
		else
		{
			clickElement(egmGainViewerButton_OR,egmGainViewerButton_S);
			gainValueValidation("5.0");
			if(operation.equalsIgnoreCase("Increment"))
			{
				switch(defaultGain)
				{
				case "5.0":
					visibilityOfElementLocatedWithoutReport(incrementButton_OR, incrementButton_S);
					clickIncrementButton();
					gainValueValidation("15.0");
					clickIncrementButton();
					gainValueValidation("25.0");
					clickIncrementButton();
					gainValueValidation("50.0");
					clickIncrementButton();
					gainValueValidation("100.0");
					clickIncrementButton();
					gainValueValidation("200.0");
					assertion.assertEqualsWithReporting(true,verifyIncrementButtonDisabled(),extentReport,"Increment button is disabled");
					break;
				case "100.0":
					visibilityOfElementLocatedWithoutReport(incrementButton_OR, incrementButton_S);
					clickIncrementButton();
					gainValueValidation("200.0");
					clickResetButton();
					gainValueValidation("100.0");
				break;
				}		
			}
			else if(operation.equalsIgnoreCase("Decrement"))
			{
				switch(defaultGain)
				{
				case "5.0":
					visibilityOfElementLocatedWithoutReport(incrementButton_OR, incrementButton_S);
					clickDecrementButton();
					gainValueValidation("15.0");
					clickDecrementButton();
					gainValueValidation("25.0");
					clickDecrementButton();
					gainValueValidation("50.0");
					clickDecrementButton();
					gainValueValidation("100.0");
					clickDecrementButton();
					gainValueValidation("200.0");
					break;
				}	
				assertion.assertEqualsWithReporting(true,verifyDecrementButtonDisabled(),extentReport,"Decrement button is disabled");
				}
			clickGainViewerCloseButton();
			clickEpisodeAndEgmPdfCloseButton();
		}
	}
	
	public boolean checkIfButtonDisabled(By element, String strElement) throws InterruptedException {
		boolean isDisabled = false;
		String value = getAttributeWithoutReport(element, "disabled", strElement);
		if (value.equalsIgnoreCase("true")) {
			isDisabled = true;
			extentReport.reportScreenShot(strElement + " is not Enabled");
		} else {
			extentReport.reportScreenShot(strElement + " is Enabled");
		}
		return isDisabled;
	}
	
	public boolean verifyIncrementButtonDisabled() throws InterruptedException {
		scrollToViewWithoutReport(incrementButton_OR,
				incrementButton_S);
		boolean disabled = checkIfButtonDisabled(incrementButton_OR,incrementButton_S);
		return disabled;
	}
	
	public boolean verifyDecrementButtonDisabled() throws InterruptedException {
		scrollToViewWithoutReport(decrementButton_OR,
				decrementButton_S);
		boolean disabled = checkIfButtonDisabled(decrementButton_OR,decrementButton_S);
		return disabled;
	}
	
	public void defaultGainViewerValidation(String value) throws InterruptedException
	{
		if(!isDisplayed(egmGainViewerButton_OR))
		clickEpisodeAndEgmPdfCloseButton();
		else
		{
			clickElement(egmGainViewerButton_OR,egmGainViewerButton_S);
			gainValueValidation(value);
			clickGainViewerCloseButton();
			clickEpisodeAndEgmPdfCloseButton();
		}
	}
	
	public void gainValueValidation(String value)
	{
		if(value.equalsIgnoreCase(getText(gainValue_OR)))
		extentReport.reportScreenShot("Gain Value is displayed as "+ value );
	}
	
	public void navigateToEpisodesAndEGMs()
	{
		clickElement(episodesAndEGMLink_OR,episodesAndEGMLink_S);
	}
	
	//Shafiya 24/02/2022. changed the xpath inside clickElement
	public void navigateToTransmissionPage() throws Exception {
		clickElement(transmissionLink_OR,transmissionLink_S);
	}
	//need to check and remove this method once we receive the test data
	public void verifyGainViewerButton()
	{
		try {
		if(visibilityOfElementLocatedWithoutReport(egmGainViewerButton_OR,egmGainViewerButton_S))
		{
			clickElement(egmGainViewerButton_OR,egmGainViewerButton_S);
		}
		}
		catch(Exception e)
		{
			if(isElementNotPresentWithReport(egmGainViewerButton_OR,egmGainViewerButton_S))
			{
				clickEpisodeAndEgmPdfCloseButton();
			}
		}
	}
	
	public void clickEpisodeAndEgmPdfCloseButton()
	{
		clickElement(episodeAndEgmCloseButton_OR,episodeAndEgmCloseButton_S);
	}
	
	//shafiya 24/02/2022 removed second method to close the pdf as there is separate method
	public void clickGainViewerCloseButton()
	{
		clickElement(gainViewerCloseButton_OR,gainViewerCloseButton_S);
		//clickEpisodeAndEgmPdfCloseButton();
	}
	
	public void clickIncrementButton()
	{
		clickElement(incrementButton_OR,incrementButton_S);
	}
	
	public void clickDecrementButton()
	{
		clickElement(decrementButton_OR,decrementButton_S);	
	}
	public void clickResetButton()
	{
		clickElement(resetButton_OR,resetButton_S);
	}
	public void deselectAssessmentType() throws InterruptedException
	{
		if(getAttributeWithoutReport(appropriateAssessmentType_OR,"color",appropriateAssessmentType_S).equals("accent"))
			clickElement(appropriateAssessmentType_OR,appropriateAssessmentType_S);
		if(getAttributeWithoutReport(inappropriateAssessmentType_OR,"color",inappropriateAssessmentType_S).equals("accent"))
			clickElement(inappropriateAssessmentType_OR,inappropriateAssessmentType_S);
		if(getAttributeWithoutReport(notSureAssessmentType_OR,"color",notSureAssessmentType_S).equals("accent"))
			clickElement(notSureAssessmentType_OR,notSureAssessmentType_S);
		if(getAttributeWithoutReport(notAssessedAssessmentType_OR,"color",notAssessedAssessmentType_S).equals("accent"))
			clickElement(notAssessedAssessmentType_OR,notAssessedAssessmentType_S);
	}
	
	public void selectAssessmentType(String value)
	{
		switch(value)
		{
		case "Appropriate":
			clickElement(appropriateAssessmentType_OR,appropriateAssessmentType_S);
			break;
		case "Inappropriate":
			clickElement(inappropriateAssessmentType_OR,inappropriateAssessmentType_S);
			break;
		case "NotSure":
			clickElement(notSureAssessmentType_OR,notSureAssessmentType_S);
			break;
		case "NotAssessed":
			clickElement(notAssessedAssessmentType_OR,notAssessedAssessmentType_S);
			break;
		}
	}
	public void selectEgmEpisodeCheckBox(String column) throws Exception
	{
		List<WebElement> rows = findElements(episodeTable_OR);
		for (int i = 1; i <= rows.size(); i++) {
			String attributeValue = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
			if (attributeValue.equalsIgnoreCase("EGM")) {
			switch(column)
			{
			case "Checkbox":
			clickElement(By.xpath("//tr[@id='mnu_episode-egm-icm__"+i+"']/td[12]/mat-checkbox"),selectEpisodeCheckbox_S);
			break;
			case "TransmissionDate":
			clickElement(By.xpath("//tr[@id='mnu_episode-egm-icm__"+i+"']/td[5]"),selectEpisodeCheckbox_S);
			break;
			case "EGM":
			clickElement(By.xpath("//tr[@id='mnu_episode-egm-icm__"+i+"']/td[9]"),selectEpisodeCheckbox_S);
			break;
			}
			break;
		}
			else
			extentReport.info("This patient does not contain episode with EGM report");
		}	
	}
	
	public void addAssessmentNotes(int length)
	{
		sendKeys(assessmentNotes_OR,assessmentNotes_S,CommonUtils.randomText(length));
	}
	
	public String validateAssessmentNotes()
	{
		String notes = getText(assessmentNotes_OR,assessmentNotes_S);
		return notes;
		
	}
	
	public void clickEpisodeViewerSaveButton()
	{
		clickElement(episodeandegm_window_Save_Button_OR,episodeandegm_window_Save_Button_S);
	}
	
	public void clickOnDownloadSpreadSheet()
	{
		clickElement(downloadSpreadSheet_OR,downloadSpreadSheet_S);
	}
	
	public String mouseHoverAssessmentType() throws InterruptedException
	{
		List<WebElement> rows = findElements(episodeTable_OR);
		String notes = null;
		for (int i = 1; i <= rows.size(); i++) {
			String attributeValue = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
			if (attributeValue.equalsIgnoreCase("EGM")) {
				mouseHover(By.xpath("//tr[@id='mnu_episode-egm-icm__"+i+"']/td[1]/mat-icon"));
				notes = getText(By.xpath("//tr[@id='mnu_episode-egm-icm__"+i+"']/td[4]"));
		}
			else
			extentReport.info("This patient does not contain episode with EGM report to perform mouse hover action");
		}	
		return notes;
	}
	
	public boolean ValidateEpisodeViewerWindowInViewMode()
	{
	boolean viewMode = false;
	if(!isEnabled(assessmentNotes_OR) && !isEnabled(episodeandegm_window_Save_Button_OR)
			&& !isEnabled(cancelButton_OR) && !isEnabled(assessmentDropdown_OR) && !isEnabled(printButton_OR)
			&& !isEnabled(markForPrintingCheckbox_OR) && !isEnabled(egmGainViewerButton_OR))
		viewMode = true;
	return viewMode;
	}
//Ends here
	
	@Override
	public boolean verifyLandingPage() {
		Boolean episodeAndEgmPageCheck = false;
		if(visibilityOfElementLocatedWithoutReport(episodeTypeSpan_OR, episodeTypeSpan_S)) {
			invisibilityOfElementLocated(pageLoading_OR);
			episodeAndEgmPageCheck =true;
			extentReport.reportScreenShot("Episodes and EGM Page is displayed");
		}
		return episodeAndEgmPageCheck;
	}
	
	
	//Meenakshi
	
	//Method to Loop all EGMs in Table and navigate to EGMGainViewer and validate sweepspeed
	public boolean episodesValidation() throws InterruptedException
		{
		boolean flag=false;
		try {
		List<WebElement> rows = findElements(episodeTable_OR);
		int rowsSize=rows.size();
    	if(!(rowsSize==0)) {
		for (int i = 0; i <= rows.size()-1; i++) {
			String columnEGM=driver.findElement(By.xpath("//*[@id=\"mnu_episode-egm-icm__"+i+"\"]/td[9]")).getAttribute("data-csv");
			if (columnEGM.contains("EGM")) {
				scrollToView(By.xpath("//*[@id=\"mnu_episode-egm-icm__"+i+"\"]/td[9]"));

				clickElement(By.xpath("//*[@id=\"mnu_episode-egm-icm__"+i+"\"]/td[9]"));
				loading();
				verifySweepSpeedGain();
				clickElement(transmissionLink_OR,transmissionLink_S);
				loading();
				clickElement(episodeEPGLink_OR,episodeEPGLink_S);
				flag=true;
				}
			else {}}}
			else {
			System.out.println("EGM was not available");}
			extentReport.reportScreenShot(" Episode type data is not available");
			}
		
			catch (Exception e) {
			e.printStackTrace();
			}
		return flag;
		}
	
	//Method to select each Episode Type and navigate to EGMGainViewer and validate sweep speed as 25mm/second for different lengths
	public boolean episodeTypeValidation() throws InterruptedException
	{
		boolean flag= false;
	try {
	for (int j=1;j<6;j++) {
	
	    	String episode=driver.findElement(By.xpath("//*[@id=\"chb_episode-egm-icm_episode"+j+"\"]")).getText().replace("done", "");
			scrollToView(episodeSearch_OR);
	    	sendKeys(episodeSearch_OR, episode);
	    	List<WebElement> rows = findElements(episodeTable_OR);
	    	int rowsSize=rows.size();
	    	if(!(rowsSize==0)) {
			for (int i = 0; i <= rows.size()-1; i++) {
				String columnEGM=driver.findElement(By.xpath("//*[@id=\"mnu_episode-egm-icm__"+i+"\"]/td[9]")).getAttribute("data-csv");
				if (columnEGM.contains("EGM")) {
					scrollToView(By.xpath("//*[@id=\"mnu_episode-egm-icm__"+i+"\"]/td[9]"));
					clickElement(By.xpath("//*[@id=\"mnu_episode-egm-icm__"+i+"\"]/td[9]"));
					verifySweepSpeedGain();
					extentReport.reportScreenShot("SEGM sweep speed is displayed as 25mm/second for"+episode);
			    	clear(episodeSearch_OR);
			    	sendKeys(episodeSearch_OR, episode);
					flag=true;
				}
	    	else {	}
			}	
	    	}
			else {
				extentReport.reportScreenShot(" Episode type data is not aviailable"+episode);
			}
			}} catch (Exception e) {
			e.printStackTrace();
			;}
	return flag;
		}
      
	
	//Method to verify sweep speed displayed as 25mm/s and Gain
	public void verifySweepSpeedGain() throws InterruptedException
	{	if (!(isDisplayed(egmGainViewer_OR))) {
			clickEpisodeAndEgmPdfCloseButton();}
		else
		{
			clickElement(egmGainViewerButton_OR,egmGainViewerButton_S);
			String sweepSpeed=driver.findElement(episodeAndEgmSweepSpeed_OR).getText();
			if (sweepSpeed.equals("Sweep speed 25mm/s:")) {
				extentReport.reportScreenShot("SEGM sweep speed is displayed as "+sweepSpeed);
				extentReport.reportScreenShot("SEGM 25mm/second sweep speed is displayed with Gain"+getText(episodeAndEgmGain_OR));
				clickGainViewerCloseButton();
				clickEpisodeAndEgmPdfCloseButton();
								
			}
			else {
				extentReport.reportScreenShot("SEGM sweep speed is  not displayed as 25mm/second");
				clickGainViewerCloseButton();
				clickEpisodeAndEgmPdfCloseButton();
				}
			
			
			}
	}
	
	//shafiya added below method: 17/02/2022
	//This method verifies if the labels in the Episodes and EGM page is present and displayed or not
	public boolean isEpisodeColumnsPresent(String columnName) throws Exception{
		Boolean isLabelPresent = false;
		switch(columnName) {
		case "Date/Time":
			if(isElementPresent(episode_DateOrTime_Label_OR, episode_DateOrTime_Label_S) 
					&& isDisplayedWithoutReport(episode_DateOrTime_Label_OR, episode_DateOrTime_Label_S))
				isLabelPresent = true;
			break;
		case "Duration":
			if(isElementPresent(episode_Duration_Label_OR, episode_Duration_Label_S)
					&& isDisplayedWithoutReport(episode_Duration_Label_OR, episode_Duration_Label_S))
				isLabelPresent = true;
			break;
		case "Zone/Type":
			if(isElementPresent(episode_ZoneOrType_Label_OR, episode_ZoneOrType_Label_S)
					&& isDisplayedWithoutReport(episode_ZoneOrType_Label_OR, episode_ZoneOrType_Label_S))
				isLabelPresent = true;
			break;			
		case "EGM":
			if(isElementPresent(episode_EGM_Label_OR, episode_EGM_Label_S)
					&& isDisplayedWithoutReport(episode_EGM_Label_OR, episode_EGM_Label_S))
				isLabelPresent = true;
		break;		
		}
		return isLabelPresent;			
	}
	//shafiya added below method: 17/02/2022
	//This method clicks on Arrow of primary filter dropdown present in Episodes and EGM page
	public void expandSearchFilterDrpdwn() throws Exception{
		if(isElementPresent(episode_PrimaryFilter_drpdwn_Arrow_OR, episode_PrimaryFilter_drpdwn_Arrow_S))
			clickElement(episode_PrimaryFilter_drpdwn_Arrow_OR, episode_PrimaryFilter_drpdwn_Arrow_S);
	}
	//shafiya added below method: 17/02/2022
	//This method returns true if the primary filter dropdown values has the value which we are expecting for else false
	public boolean verifySearchFilterDrpdwnValues(String value) throws Exception{
		Boolean isValueAvailable = false;
  		List<WebElement> dropdownValues = findElementslist(episode_PrimaryFilter_drpdwn_ListValues_OR, episode_PrimaryFilter_drpdwn_ListValues_S);  		
  		for (int i = 0; i < dropdownValues.size(); i++) {
  			if (dropdownValues.get(i).getText().contains(value)) {
  				isValueAvailable = true;
  				break;
  			}	
  		}
  		return isValueAvailable;
	}
	//shafiya added below method: 17/02/2022
	//This method clicks on the dropdown value present in primary filter dropdown
	public void selectValue_PrimaryFilter_Drpdwn(String value) throws Exception{
  		List<WebElement> primaryDrpdwnVals = findElementslist(episode_PrimaryFilter_drpdwn_ListValues_OR, episode_PrimaryFilter_drpdwn_ListValues_S);  		
  		for (int i = 0; i < primaryDrpdwnVals.size(); i++) {
  			if (primaryDrpdwnVals.get(i).getText().contains(value)) {
  				primaryDrpdwnVals.get(i).click();
  				break;
  			}	
  		}
	}
	//shafiya added below method: 17/02/2022
	//This method clicks on the dropdown value present in Secondary filter dropdown
	public void selectValue_SecondaryFilter_Drpdwn(String value) throws Exception{
  		List<WebElement> secondaryDrpdwnVals = findElementslist(episode_SecondaryFilter_drpdwn_ListValues_OR, episode_SecondaryFilter_drpdwn_ListValues_S);  		
  		for (int i = 0; i < secondaryDrpdwnVals.size(); i++) {
  			if (secondaryDrpdwnVals.get(i).getText().contains(value)) {
  				secondaryDrpdwnVals.get(i).click();
  				break;
  			}	
  		}
	}
	//shafiya added below method: 18/02/2022
	//This method enters value in Search box of Episodes and EGMs page
	public void enterValue_SearchBox(String value) throws Exception{
  		sendKeys(episode_EGM_Search_OR, episode_EGM_Search_S, value);
	}
	public boolean validateRecords_EpisodesTable(String dropdownType, String secondFilterVal) throws Exception
	{
		Boolean isDisplayed = false;
		List<WebElement> rows = findElements(episodeTable_OR);
		for (int i = 1; i <= rows.size(); i++) {
			switch(dropdownType) {
			case "Zone/Type":
				//need to change this xpath once data comes
				String zoneVal = getText(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "Zone/Type");
				if (zoneVal.equalsIgnoreCase(secondFilterVal))
					isDisplayed = true;				
				else
				extentReport.info("The displayed information contains rows other than:"+secondFilterVal);
				break;
			case "Duration":
				//need to change this xpath once data comes
				String durationVal = getText(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "Duration");
				if (durationVal.equalsIgnoreCase(secondFilterVal))
					isDisplayed = true;				
				else
					extentReport.info("The displayed information contains rows other than:"+secondFilterVal);
				break;
			case "Only EGMs":
				//need to change this xpath once data comes
				String EGMVal = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
				if (EGMVal.equalsIgnoreCase("EGM"))
					isDisplayed = true;				
				else
					extentReport.info("The displayed information contains rows other than 'Only EGMs'");
				break;
			}
		}
		return isDisplayed;
	}
	//Dhaval
	public void egmPdfViewerValidation() throws Exception
	{
		List<WebElement> rows = findElements(episodeTable_OR);
		for (int i = 1; i <= rows.size(); i++) {
			String attributeValue = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
			if (attributeValue.equalsIgnoreCase("EGM")) {
			clickElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"),"EGM button");
			break;
		}
			else
			extentReport.info("This episode does not contain any EGM report");
		}
	}
	
	//Alok
	public void selectEpisodeTypeOption(String option) {

		switch (option)
		{
		case "AT/AF":
			elementToBeClickable(episodeType_AT_OR,episodeType_AT_S);
			clickElement(episodeType_AT_OR, episodeType_AT_S);
			break;
		case "Brady":
			elementToBeClickable(episodeType_Brady_OR,episodeType_Brady_S);
			clickOnElementUsingJs(episodeType_Brady_OR, episodeType_Brady_S);
			break;
		case "Pause":
			elementToBeClickable(episodeType_Pause_OR,episodeType_Pause_S);
			clickElement(episodeType_Pause_OR, episodeType_Pause_S);
			break;
		case "Symptom":
			elementToBeClickable(episodeType_Symtom_OR,episodeType_Symtom_S);
			clickElement(episodeType_Symtom_OR,episodeType_Symtom_S);
			break;
		case "Tachy":
			elementToBeClickable(episodeType_Tachy_OR,episodeType_Tachy_S);
			clickElement(episodeType_Tachy_OR,episodeType_Tachy_S);
			break;
		case "All":
			elementToBeClickable(episodeType_AT_OR,episodeType_AT_S);
			clickElement(episodeType_AT_OR, episodeType_AT_S);
			loading();
			elementToBeClickable(episodeType_Brady_OR,episodeType_Brady_S);
			clickOnElementUsingJs(episodeType_Brady_OR, episodeType_Brady_S);
			loading();
			elementToBeClickable(episodeType_Pause_OR,episodeType_Pause_S);
			clickElement(episodeType_Pause_OR, episodeType_Pause_S);
			loading();
			elementToBeClickable(episodeType_Symtom_OR,episodeType_Symtom_S);
			clickElement(episodeType_Symtom_OR,episodeType_Symtom_S);
			loading();
			elementToBeClickable(episodeType_Tachy_OR,episodeType_Tachy_S);
			clickElement(episodeType_Tachy_OR,episodeType_Tachy_S);
			loading();
			break;
		
		default:
			System.out.println("Not able to find the option ");
		}

	}
	
	public void verifyEpisodeTypeInTable()
	{
		List<WebElement> rowCount = driver.findElements(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']//tbody/tr"));
		System.out.println("Num rows: " + rowCount .size());
	}
	//Shafiya added below method on 23/02/2022
	//This method loops through the episodes, if EGM there then clicks on it, clicks on EGM Gain Viewer button, 
	//Verifies the waveform data. If wave form is found then it breaks
	public boolean validateEpisodeData() throws Exception
		{
		Boolean flag = false;
		try {
		List<WebElement> rows = findElements(episodeTable_OR);
		int updatedCount =0;;
		int rowsSize=rows.size();
    	if(!(rowsSize==0)) {
   				for (int i = 1; i <= rows.size(); i++) {
					if (updatedCount < 1){
						String attributeValue = getAttributeWithoutReport(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"), "data-csv", "EGM Button");
						if (attributeValue.equalsIgnoreCase("EGM")) {				
							clickElement(By.xpath("//table[@id='dtl_episode-egm-icm_icm-device']/tbody/tr[" + i + "]/td[9]"),"EGM button");
							loading();
							clickEGMGainViewerButton();
							updatedCount = validateWaveFormData_EGMGainViewerPage();
							if(updatedCount!=1) {
								navigateToTransmissionPage();
								loading();
								navigateToEpisodesAndEGMs();
								loading();
							}
							flag=true;
							}
						if(updatedCount==1) 
							break;
						
						}
					}
    			}
			else
			extentReport.reportScreenShot(" Episode type data is not available");
			}catch (Exception e) {
				e.printStackTrace();
			}
		return flag;
		}	
	
	//Shafiya added below method on 23/02/2022
	//This method clicks on EGM GAIN VIEWER button in Episode & EGM Details page
	public void clickEGMGainViewerButton() throws Exception{
		if (isDisplayed(egmGainViewer_OR)) {
			clickElement(egmGainViewerButton_OR,egmGainViewerButton_S);
			if(isElementPresent(egmGainViewerWindow_OR, egmGainViewerWindow_S) && isElementPresent(episodeAndEgmCloseButton_OR, episodeAndEgmCloseButton_S))
				extentReport.pass("EGM Gain Viewer is displayed in a modal window");
			else
				extentReport.fail("EGM Gain Viewer is not displayed in a modal window");
		}		
		else {
			extentReport.info("EGM GAIN VIEWER button is not displayed");
			clickEpisodeAndEgmPdfCloseButton();
		}
			
	}
	//Shafiya added below method on 23/02/2022
	//This method prints the waveform data if is available
	public int validateWaveFormData_EGMGainViewerPage() throws Exception{	
				int count = 0;
		if(isElementPresent(egmGainViewer_Wave_OR, egmGainViewer_Wave_S) && isDisplayedWithoutReport(egmGainViewer_Wave_OR, egmGainViewer_Wave_S))	{
			extentReport.pass("SEGM waveform data associated with the selected episode is displayed");
			extentReport.reportScreenShot("SEGM sweep speed is displayed as "+getText(episodeAndEgmSweepSpeed_OR));
			extentReport.reportScreenShot("SEGM sweep speed is displayed with Gain"+getText(episodeAndEgmGain_OR));
			count = count+1;
			clickGainViewerCloseButton();
			clickEpisodeAndEgmPdfCloseButton();
							
		}
		else {
			extentReport.fail("SEGM waveform data associated with the selected episode is not displayed");
			clickGainViewerCloseButton();
			clickEpisodeAndEgmPdfCloseButton();
		}
		return count;
	}
	//Kundan
		public void selectEpisodeCbxEpisodeEGMPage()
		{
			clickElement(selectpt_Checkbox_EpisodeEGM_Page_OR, selectpt_Checkbox_Transmission_Page_S);
		}
		
		public void clickOnMoreActions() {
			
			clickElement(moreAction_OR, moreAction_S);
			waitForPageLoad();
		}
		
		public void navigateToViewEpisodeOption()
		{
			clickElement(moreAction_ViewEpisode_OR, moreAction_ViewEpisode_S);
		}
	    
		public void verifyEpisodeandEgmWindow()
		{
		Boolean episodeegmwindow=isElementPresent(episodeand_EGM_Window_OR, episodeand_EGM_Window_S);
		extentReport.pass("Episode and EGM window displayed "+episodeegmwindow);
			
		}
	//Ends here

}
