package com.test.qa.ui.pageObjects.ClinicianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class ClinicianHomeTopNavPage extends BasePage {

	/*
	 * AUTHOR: Vinay Babu
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public ClinicianHomeTopNavPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	private final By recentTransmissions_link_OR = By.xpath("//div[@id=\"shell-wrapper\"]/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[1]/a");
	private final String recentTransmissions_link_S = "Recent Transmissions Link";
	
	private final By patientList_link_OR = By.xpath("//div[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[2]/a");
	private final String patientList_link_S = "Patient List Link";
	
	private final By clinicAdministration_link_OR = By.xpath("//div[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[4]/a");
	private final String clinicAdministration_link_S = "ClinicAdministration Link";
	
	
	
	private final By signOut_link_OR = By.xpath("//div[@id=\"shell-wrapper\"]/mat-toolbar/mat-toolbar-row/div[2]/div/div[1]/a/span/span[3]");
	private final String signOut_link_S = "Sign Out Link";
	
	private final By clinicAdministration_HomePage_OR = By.xpath("//div[text()=' Administration ']");
	private final String clinicAdministration_HomePage_S = "Administration Header in Clinic administration page";
	
	
	private final By tools_link_OR=By.xpath("//div[@id=\"shell-wrapper\"]/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[3]/a");
    private final String tools_link_S="Tools Link";

    private final By communicationCenter_OR = By.xpath("//div[@id=\"shell-wrapper\"]/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[5]/a");
    private final String communicationCenter_S = "Communication Center Link";
	
	//Author: Abhishek kumar
	public Boolean verifyTopNavPageTab(String tab) throws Exception{
		boolean flag=false;
	   if(tab.equals("Patient List")) {
		  flag=isDisplayedWithReport(patientList_link_OR, patientList_link_S);
		  flag=true;
		   return flag;
	   }
	   else if(tab.equals("Clinic Administration")) {
		   flag=isDisplayedWithReport(clinicAdministration_link_OR, clinicAdministration_link_S);
		   flag=true;
		   return flag;
	   }
	   else if(tab.equals("Recent Transmission")) {
		   flag=isDisplayedWithReport(recentTransmissions_link_OR, recentTransmissions_link_S);
		   flag=true;
		   return flag;
	   }
	   else if(tab.equals("Tools")) {
		   flag=isDisplayedWithReport(tools_link_OR, tools_link_S);
		   flag=true;
		   return flag;
	   }
	   extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
	return flag;

	}

	public void clickClinicAdministrationLink() throws InterruptedException
	{
		waitForPageLoadingWithReport();
		elementToBeClickable(clinicAdministration_link_OR, clinicAdministration_link_S);
		//clickElement(clinicAdministration_link_OR, clinicAdministration_link_S);
		clickOnElementUsingJs(clinicAdministration_link_OR);
		loadingWithoutReport();
		extentReport.reportScreenShot("Clicked Clinic Administration Link");
	}
	//*[@id="icd-crt-d"]/ul/li[1]/a/span
	
	private final By Melinathome_link_OR = By.xpath("//*[@id=\"icd-crt-d\"]/ul/li[1]/a/span");
	private final String Melinathome_link_S = "Melin @ home Link";
	
	public void clickMelinathomeLink() throws InterruptedException
	{
		clickElement(Melinathome_link_OR, Melinathome_link_S);
		loadingWithoutReport();
	}
	//Gowshalya
	public void clickPatientListLink() throws InterruptedException
	{
		clickElement(patientList_link_OR, patientList_link_S);
		loadingWithoutReport();
	}
	
	public void clickToolsLink() throws InterruptedException
	{
		clickElement(tools_link_OR, tools_link_S);
		loadingWithoutReport();
	}
	
	//carmel
		public  void navigateToClinicAdministrationPage() throws Exception
		{ 
			
			clickOnElementUsingJs(clinicAdministration_link_OR, clinicAdministration_link_S);
			loadingWithoutReport();
			//presenceOfElementLocatedWithReport(clinicAdministration_HomePage_OR,clinicAdministration_HomePage_S);
		}
	
	public void clickSignOutLink() throws InterruptedException
	{
		presenceOfElementLocated(signOut_link_OR);
		waitForLoading();
		//extentReport.reportScreenShot("Clicking Clinic Administration Link");
		clickElement(signOut_link_OR);
		waitForLoading();
		waitForLoading();
		waitForLoading();
		
	}
	//Added by jais
	public Boolean isClinicAdministrationMenuPresent() throws InterruptedException
	{
		waitForLoading();
		return isElementPresent(clinicAdministration_link_OR);
	}
	
	
	
		//Kundan
		public void navigateToClinicAdministrationLink() throws InterruptedException
		{
			presenceOfElementLocated(clinicAdministration_link_OR);
			clickElement(clinicAdministration_link_OR);
			extentReport.reportScreenShot("Clicked Clinic Administration Link");
			waitForPageLoad();
		}
		//Ends here
		
		//Shanmugapriya
		public void navigateToPatientListPage() {
			clickOnElementUsingJs(patientList_link_OR, patientList_link_S);

		}
		
		
	/*
	 * Author Salin Gambhir
	 * for test case WA_96_QuickLinks_02
	 */
		public void navigateToRecentTransmissionLink() throws InterruptedException {
			waitForLoading();
			clickElement(recentTransmissions_link_OR, recentTransmissions_link_S);
			
		}
		
		public void clickSignOut() throws InterruptedException
		{
			clickOnElementUsingJs(signOut_link_OR, signOut_link_S);

		}
		
	//End
	// Each page class should have this overridden method of Verify Landing page

	@Override
	public boolean verifyLandingPage() {
		Boolean clinicianHomePageCheck = false;
		
		return clinicianHomePageCheck;
	}
	
	private final By clinicAdministrationActivatercln_link_OR = By.xpath("//div[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[2]/a");
	private final String clinicAdministrationActivatercln_link_S = "ClinicAdministration Link without Admin";
	
	private final By patientList_linkActivatercln_OR = By.xpath("//div[@id='shell-wrapper']/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[1]/a");
	private final String patientList_linkActivatercln_S = "Patient List Link";
	
	//Author: Abhishek kumar
	public Boolean verifyTopNavPageTabForActivaterClc(String tab) throws Exception{
		boolean flag=false;
	   if(tab.equals("Patient List")) {
		  flag=isDisplayedWithReport(patientList_link_OR, patientList_link_S);
		  flag=true;
		   return flag;
	   }
	   else if(tab.equals("Clinic Administration")) {
		   flag=isDisplayedWithReport(clinicAdministrationActivatercln_link_OR, clinicAdministrationActivatercln_link_S);
		   flag=true;
		   return flag;
	   }
	   else if(tab.equals("Recent Transmission")) {
		   flag=isDisplayedWithReport(recentTransmissions_link_OR, recentTransmissions_link_S);
		   flag=true;
		   return flag;
	   }
	   else if(tab.equals("Tools")) {
		   flag=isDisplayedWithReport(tools_link_OR, tools_link_S);
		   flag=true;
		   return flag;
	   }
	return flag;
	
	}
	
	public Boolean verifyPatientTabActivatorWithoutAdmin(String tab) throws Exception{
		boolean flag=false;
		if(tab.equals("Patient List")) {
		flag=isDisplayedWithReport(patientList_linkActivatercln_OR, patientList_linkActivatercln_S);
		flag=true;
		return flag;
		}
		else {
			extentReport.reportInfo("Patient tab is not getting reflected");
		}
		return flag;
		
	}
	
	
	public  void navigateToClinicAdministrationForActivatorPage() throws Exception
	{ 
		clickOnElementUsingJs(clinicAdministrationActivatercln_link_OR, clinicAdministrationActivatercln_link_S);
		//presenceOfElementLocatedWithReport(clinicAdministration_HomePage_OR,clinicAdministration_HomePage_S);
	}
	
	/*
	 * Author Salin Gambhir
	 * for test case : NV-PA001-PatLst-01
	 */
	public void navigateToCommunicationCenter() {
			elementToBeClickable(communicationCenter_OR, communicationCenter_S);
			clickElement(communicationCenter_OR, communicationCenter_S);
			extentReport.reportScreenShot("Clicked Communication Center Link");
		
	}
	
	/*
	 *  end test case: NV-PA001-PatLst-01
	 */
	//Poojitha
	public  void navigateToPatientListForActivatorClinic() throws Exception
	{ 
		clickOnElementUsingJs(patientList_linkActivatercln_OR, patientList_linkActivatercln_S);
		}
}
