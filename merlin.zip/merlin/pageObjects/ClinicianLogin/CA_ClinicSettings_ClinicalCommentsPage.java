package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class CA_ClinicSettings_ClinicalCommentsPage extends BasePage {
	
	//Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	public static Log logger = new Log();
	ExtentTest extentTest, child1;


public CA_ClinicSettings_ClinicalCommentsPage(WebDriver driver, ExtentReport extentReport) {
    super(driver, extentReport);
    this.extentReport = extentReport;
    this.driver = driver;
}


public final By clinicAdminLink = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin']/..");
private final By clinicalCommentsLink_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinic-admin/clinic-settings/clinical-comments']/..");
private final String clinicalCommentsLink_S = "clinical Comments Link";
public final By clinicalCommentsHeader_OR = By.xpath("//div[@id='clinic-comments-wrapper']//header/div[@class='simple-text']");
private final String clinicalCommentsHeader_S = "Clinical Comments Header";
public final By clinicalCommentsInfo = By.xpath("//div[@id='clinicalCommentsForm']/div/p[@class='info']");
public final By AllowFreeFormText_checkbox = By.xpath("//section[@class='checkbox-section']/mat-checkbox[1]");
public final By AllowPreSetComments_checkbox = By.xpath("//section[@class='checkbox-section']/mat-checkbox[2]");
public final By checkPreference = By.xpath("//section[@class='checkbox-section']");
//dummy xpath
private final By preSetCommentsBox_OR = By.xpath("//mat-selection-list[@class='mat-selection-list mat-list-base']");
private final String preSetCommentsBox_S = "Pre Set Comments Box";
private final By preSetCommentsOption_OR = By.xpath("//mat-selection-list[@class='mat-selection-list mat-list-base']/mat-list-option/div/div/span");
private final String preSetCommentsOption_S = "Pre Set Comments";
private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper show']");
private final String pageLoading_S = "Page Loading";
private final By allowPreSetCommChkBox_OR = By.xpath("//section[@class='checkbox-section']/mat-checkbox[2]//input");
private final String allowPreSetCommChkBox_S = "Check Box for Allow Pre Set Comments";
private final By freeFormTextChkBox_OR = By.xpath("//section[@class='checkbox-section']/mat-checkbox[2]//input");
private final String freeFormTextChkBox_S = "Check Box for Free form text";


// Each page class should have this overridden method of Verify Landing page

@Override
public boolean verifyLandingPage() {
      Boolean clinicalCommentsPageCheck = false;
        if (visibilityOfElementLocatedWithoutReport(clinicalCommentsHeader_OR, clinicalCommentsHeader_S)) {
        	clinicalCommentsPageCheck = true;
            extentReport.reportScreenShot("Clinical Comments page is displayed");	           
        }else {
        	extentReport.reportScreenShot("Clinical Comments page is not displayed");
        }
        return clinicalCommentsPageCheck;
    }

public void clickClinicalCommentsLink() throws InterruptedException
{	invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
	clickElement(clinicalCommentsLink_OR, clinicalCommentsLink_S);

}

public boolean checkPreferenceAvailable() throws InterruptedException {
	Boolean isAvailable = false;
	loading();
	if(visibilityOfElementLocated(AllowFreeFormText_checkbox) && visibilityOfElementLocated(AllowPreSetComments_checkbox)) {
		isAvailable = true;
		extentReport.reportScreenShot("Preferences-Allow Free Form Text and Pre-Set Comments are available in Clinical Comments page");
		
	} else {
        extentReport.reportScreenShot("Preferences are not available in Clinical Comments page");
    }
	   return isAvailable;	
}

public boolean verifyPreSetComments() {
	Boolean flag = false;
	if(visibilityOfElementLocatedWithReport(preSetCommentsOption_OR, preSetCommentsOption_S)) {
		flag = true;
		extentReport.reportScreenShot("Pre set comments are displayed");
	}
	else {
		extentReport.reportScreenShot("Pre set comments are not displayed");
	}
		 return flag;
}

public List<String> preSetComments() {
	//this will return all the pre-set comments
	List<WebElement> appData = driver.findElements(preSetCommentsOption_OR);
	ArrayList<String>  presetComments = new ArrayList<String>();
	for(int i=0; i<appData.size(); i++) {
		String option = appData.get(i).getText().trim().toString();
		System.out.println(option);
		presetComments.add(option);		
	}
	extentReport.reportScreenShot("All default Pre-set comments are present");
	return 	presetComments;	
}

public boolean verifyAllowPreSetCommentsChkBoxSelected() {
	Boolean flag = false;
	loading();
		if(visibilityOfElementLocatedWithoutReport(allowPreSetCommChkBox_OR, allowPreSetCommChkBox_S)) {
				if(isSelected(allowPreSetCommChkBox_OR)) {	
				extentReport.pass(allowPreSetCommChkBox_S + " is selected");
				flag = true;
			}
			
		}

		return flag;
}

public boolean validatePreSetCommentsOrder() throws IOException {
	boolean flag = true;	
	ArrayList<String> excelPreSetComments = TestDataProvider.readClinicalCommentsFromExcel("ClinicalComments");
	List<WebElement> appPreSetComments = driver.findElements(preSetCommentsOption_OR);
	
	//to check order of comments
	for(int i=1; i<=appPreSetComments.size(); i++) {
		
		String preSetCommentsOption = (driver.findElement(By.xpath("//mat-selection-list[@class='mat-selection-list mat-list-base']/mat-list-option["+i+"]//span"))).getText().trim();
		
		if(!excelPreSetComments.get(i-1).equalsIgnoreCase(preSetCommentsOption)) {
			flag = false;
			break;
		}
	}
	
	return flag;
}


public boolean verifyDefaultPreSetComments() throws IOException {
	boolean flag = true;	
	ArrayList<String> excelData = TestDataProvider.readClinicalCommentsFromExcel("ClinicalComments");
	List<WebElement> appPreSetComments = driver.findElements(preSetCommentsOption_OR);
	List<String> appData = new ArrayList<String>();
	ArrayList<String> missedValue = new ArrayList<>();

	for(int i=1; i<=appPreSetComments.size(); i++) {
		
		String preSetCommentsOption = (driver.findElement(By.xpath("//mat-selection-list[@class='mat-selection-list mat-list-base']/mat-list-option["+i+"]//span"))).getText().trim();
		appData.add(preSetCommentsOption);
	}
		
	for (String value : appData) {
		if (!excelData.contains(value))
			missedValue.add(value);
	}
	
	if (missedValue.isEmpty()) {
		extentReport.pass("All default preset comments are present");
		flag = true;
	}
	else {
		for(int i=0; i<missedValue.size(); i++) {
			String missingVal = missedValue.get(i);
			System.out.println(missingVal + " is not present");
		}
		extentReport.fail("All default preset comments are not present");
	}
	
	
	return flag;
}


public void pageLoad() {
	WebDriverWait wait = new WebDriverWait(driver, WAIT);
	wait.until(ExpectedConditions.or(ExpectedConditions.elementToBeSelected(allowPreSetCommChkBox_OR), ExpectedConditions.elementToBeSelected(freeFormTextChkBox_OR)));
	
}

}



