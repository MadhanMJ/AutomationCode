
package com.test.qa.ui.pageObjects.ClinicianLogin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.test.qa.dataBase.DataBaseConnector;
import com.azure.cosmos.implementation.apachecommons.lang.StringUtils;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

import com.test.qa.utilities.CommonLibraries;

import com.test.qa.utilities.CommonUtils;

/**
 * RecentTransmissionsPage for non-admin clinician user.
 * This is the default page displayed on clinician login.
 */
public class CA_RecentTransmissionsPage extends BasePage {

	public WebDriver driver;
	public ExtentReport extentReport;
	CommonLibraries commonLibraries;

	public CA_RecentTransmissionsPage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		commonLibraries = new CommonLibraries(driver, extentReport);
	}


	String uiListItems = StringUtils.EMPTY;
	private final By quickLinksVerticalSplit = By.xpath("//div[@class='quicklink mt-15']/button[@class='mat-focus-indicator merlin-button mat-button mat-button-base mat-primary ng-star-inserted']/span[@class='mat-button-wrapper']/span[@class='material-icons ml-30']");

	//Author :Bhupendra
	private final By recentTrnsToTab_OR = By.xpath("//a[@href='/dist/merlin-cloud/clinician']/span");
	private final String recentTrnsToTab_S ="RecentTransmision Top Tab";

	private final By quickLinks_OR=By.xpath("//button[@id='btn_recent-transmission_quickLinks-toggle']");
	private final String quickLinks_S="Quick Link button";
	
	private final By transmission_OR = By.xpath("//th[@id='lbl_transmission-list_th-transmission']");

	private final By tier1FilterDrpdown_OR= By.xpath("//mat-select[@id='dd_transmission-list_RT_T1_Filter']");
	private final String tier1FilterDrpdown_S ="Patient Filter DropDown";

	private final By tier1FilterDrpdownMyPatientOptn_OR= By.xpath("(//div[@id='dd_transmission-list_RT_T1_Filter-panel']/mat-option)[1]");
	private final String tier1FilterDrpdownMyPatientOptn_S ="My Patient Option";

	private final By tier1FilterDrpdownClinicPatientOptn_OR= By.xpath("(//div[@id='dd_transmission-list_RT_T1_Filter-panel']/mat-option)[2]");
	private final String tier1FilterDrpdownClinicPatientOptn_S ="Clinic Patient Option";

	private final By tier2FilterDrpdown_OR= By.xpath("//mat-select[@id='dd_transmission-list_activePatientsFilter']//span");
	private final String tier2FilterDrpdown_S ="Type Of Patient Filter DropDown";

	private final String tier2FilterDrpdownOptions_OR= "(//div[@id='dd_transmission-list_activePatientsFilter-panel']/mat-optgroup/mat-option)[{0}]";
	private final String tier2FilterDrpdownOptions_S ="Type Of Patient Filter Options";	

	private final By tier3FilterDrpdown_OR= By.xpath("//input[@id='txt_transmission-list_search']");
	private final String tier3FilterDrpdown_S ="Type Of Patient Filter DropDown";

	private final By archiveBtn_OR= By.xpath("//button[@id='btn_transmission-list_archive']/span");
	private final String archiveBtn_S ="Archive Button";

	private final By moreActionBtn_OR= By.xpath("//button[@id='btn_transmission-list_selectMoreAction']/span");
	private final String moreActionBtn_S ="More Actions Button";

	private final By moreActionMrkAsVwdOptn_OR= By.xpath("//button[@id='btn_transmission-list_markUnViewed']//span");
	private final String moreActionMrkAsVwdOptn_S ="More Actions Button";

	private final By moreActionAddOrRmovColOptn_OR= By.xpath("//button[@id='btn_transmission-list_addOrRemoveColumns']//span");
	private final String moreActionAddOrRmovColOptn_S ="More Actions Button";

	private final By deviceChckBxAddOrRemCol_OR= By.xpath("//input[@id='chb_column_name_preference_2-input']");
	private final String deviceChckBxAddOrRemCol_S ="Device check box add remove popup";

	private final By addRemColDoneBtn_OR= By.xpath("//button[@id='btn_column_name_done']/span");
	private final String addRemColDoneBtn_S ="Add Remove Columns Popup Done Button";

	private final By addRemColCancelBtn_OR= By.xpath("//button[@id='btn_column_name_done']/span");
	private final String addRemColCancelBtn_S ="Add Remove Columns Popup Cancel Button";

	private final By deviceColmnHeader_OR= By.xpath("//button[@id='btn_column_name_done']/span");
	private final String deviceColmnHeader_S ="Add Remove Columns Popup Cancel Button";


	private final By enrollPatientBtn_OR= By.xpath("//button[@id='btn_quick-links_enroll-new-patient']/span");
	private final String enrollPatientBtn_S ="Enroll Patient Button Recent Transmission Page";

	private final String unviewedTrnsLinkWithPatientName_OR ="(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/preceding-sibling::td//mat-icon[contains(@class,'blue unviewed material-icons')]/parent::td/following-sibling::td[2]//span)[{1}]";
	private final String unviewedTrnsLinkWithPatientName_S = "Unviewed ransmission Link With Patient List";
	
	private final String unviewedTrnsLinkWithPatientNameNDt_OR ="(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/preceding-sibling::td//mat-icon[contains(@class,'blue unviewed material-icons')]/parent::td/following-sibling::td[2]//span[contains(text(),'{1}')])";
	private final String unviewedTrnsLinkWithPatientNameNDt_S = "Unviewed Transmission Link With Patient Name and Transmission Date and Time";	
	
	private final String viewedTrnsLinkWithPatientNameNDt_OR ="(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/preceding-sibling::td//mat-icon[contains(@class,'blue viewed material-icons')]/parent::td/following-sibling::td[2]//span[contains(text(),'{1}')])";
	private final String viewedTrnsLinkWithPatientNameNDt_S = "Viewed Transmission Link With Patient Name and Transmission Date and Time";

	private final String viewedTrnsWithPatientName_OR = "(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/preceding-sibling::td//mat-icon[contains(@class,'blue viewed material-icons')])[{1}]";
	private final String viewedTrnsWithPatientName_S = "Unviewed Transaction With Patient List";

	//blow xpath will only work when tier 3 search filter is used
	private final String patientNameFrmList_OR = "//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']";
	private final String patientNameFrmList_S = "Patient Name Transmission List";
	
	private final By patientNameInList_OR = By.xpath("//a[@id='btn_transmission-list_cell-row0']/div");
	private final String patientNameInList_S = "Patient Name from Transmission List";
	
	private final String unviewedTrnsWithPatientName_OR = "(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/parent::td/preceding-sibling::td//mat-icon[contains(@class,'blue unviewed material-icons')])[{1}]";
	private final String unviewedTrnsWithPatientName_S = "Unviewed Transaction With Patient List";

	private final String patientTrnsFrmListChkBx_OR = "(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/following-sibling::td//input[@type='checkbox'])[{1}]";
	private final String patientTrnsFrmListChkBx_S = "Patient Transmission List CheckBox ";

	private final String unviewedPatientTrnsFrmTbltChkBx_OR = "(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/preceding-sibling::td/mat-icon[contains(@class,'blue unviewed material-icons')]/parent::td/following-sibling::td//input[@type='checkbox'])[{1}]";
	private final String unviewedPatientTrnsFrmTbltChkBx_S = "Unviewed Patient Transmission List CheckBox ";

	private final String viewedPatientTrnsFrmTbltChkBx_OR = "(//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/preceding-sibling::td//mat-icon[contains(@class,'blue viewed material-icons')]/ancestor::td/following-sibling::td//input[@type='checkbox'])[{1}]";
	private final String viewedPatientTrnsFrmTbltChkBx_S = "Viewed Patient Transmission List CheckBox ";

	private final By unviewedTrnsCountQuickLink_OR= By.xpath("//div[@id='lbl_quick-links_titleqlData']/following-sibling::span");
	private final String unviewedTrnsCountQuickLink_S ="Unviewed Transmission Count";

	private final By unviewedTrnsDispalyedIntTblList_OR= By.xpath("//td[contains(@id,'lbl_transmission-list_action')]/mat-icon[contains(@class,'blue unviewed material-icons')]");
	private final String unviewedTrnsDispalyedIntTblList_S ="Unviewed Transmission Count in Table";

	private final By viewedTrnsDispalyedIntTblList_OR= By.xpath("//td[contains(@id,'lbl_transmission-list_action')]/mat-icon[contains(@class,'blue viewed material-icons')]");
	private final String viewedTrnsDispalyedIntTblList_S ="Unviewed Transmission Count in Table";

	private final By unviewedTrnsQuickLink_OR=By.xpath("//div[@id='lbl_quick-links_titleqlData' and contains(text(),'Unviewed Transmissions')]");
	private final String unviewedTrnsQuickLink_S ="Unviewed Transmission Link";

	private final By trnsDtLbl_OR=By.xpath("//div[@id='lbl_transmission_summary_transmission_date']");
	private final String trnsDtLbl_S ="Archive Popup Caancel Button";

	private final By transmissionFromTrnsList_OR=By.xpath("//tr[@id='mnu_transmission_list__0']");
	private final String transmissionFromTrnsList_S ="Transmission Availability From Transmission List";

	private final By firstTrans_OR=By.xpath("//td[@id='lbl_transmission-list_td-transmission0']/div");
	private final String firstTrans_S ="First Transmission From Transmission List";

	private final By signnedInAsLink_OR=By.xpath("//div[@class='helperLinks']//span/span");
	private final String signnedInAsLink_S ="Signedin As Link";

	private final By myAccountHeader_OR=By.xpath("//div[@id='my-account']/preceding-sibling::div/div");
	private final String myAccountHeader_S ="My Account Header";

	private final By myAccountEditBtn_OR=By.xpath("//button[@id='myAccountEdit']/span");
	private final String myAccountEditBtn_S ="My Account Header";

	private final By clinicLocRadioBtn_OR=By.xpath("//div[@id='recentTxPreferences']//mat-radio-button[@id='CL']//div/div");
	private final String clinicLocRadioBtn_S ="Clinic Location Radio Button";

	private final By saveBtnMyAcntPg_OR=By.xpath("//button[@id='myAccountSave']/span");
	private final String saveBtnMyAcntPg_S ="Clinic Location Radio Button";

	private final By archivePopupMsg_OR=By.xpath("//div[@id='title_archive-popup_data_content']");
	private final String archivePopupMsg_S ="Archive Popup Message";

	private final By archiveSlctdTrnsBtn_OR=By.xpath("//button[@id='btn_archive-popup_selectedTransmission']/span");
	private final String archiveSlctdTrnsBtn_S ="Archive Popup Archive Selected Transmission Button";

	private final By archiveViwdTrnsBtn_OR=By.xpath("//button[@id='btn_archive-popup_viewedTransmission']/span");
	private final String archiveViwdTrnsBtn_S ="Archive Popup Archive Viewed Transmission Button";

	private final By archivePopuCancelBtn_OR=By.xpath("//button[@id='btn_archive-popup_selectedCancel']/span");
	private final String archivePopuCancelBtn_S ="Archive Popup Caancel Button";

	private final By TrnswithAlertQuickLink_OR=By.xpath("//div[@id='lbl_quick-links_titleqlData' and contains(text(),'Transmissions with')]");
	private final String TrnswithAlertQuickLink_S="Transmissions with Alert link";

	private final By TrnswithAlertCountQuickLink_OR=By.xpath("(//div[@id='lbl_quick-links_titleqlData']/following-sibling::span)[2]");
	private final String TrnswithAlertCountQuickLink_S="Transmissions with Alert count";

	private final By ptnWithNoFutureScheduleLink_OR=By.xpath("//div[@id='lbl_quick-links_titleqlData' and contains(text(),'Patients with no future schedule')]");
	private final String ptnWithNoFutureScheduleLink_S="Patient with no Future schedule";

	private final By ptnWithNoFutureScheduleCountLink_OR=By.xpath("(//div[@id='lbl_quick-links_titleqlData']/following-sibling::span)[4]");
	private final String ptnWithNoFutureScheduleCountLink_S="Patient with no future schedule count";

	public final By tier1FilterActivePatient_OR=By.xpath("//mat-select[@id='dd_patient-list_t1filterList']//div/span/span");
	public final String tier1FilterActivePatient_S="My Active patient";

	private final By tier2FilterDrpdownOptionsPatientwith_OR= By.xpath("//mat-select[@id='dd_patient-list_t2filterList']//span");
	private final String tier2FilterDrpdownOptionsPatientwith_S ="Patient dropdown for active and released";

	private final String tier2FilterDrpdownOptionsPatientwithfuture_OR= "(//div[@id='dd_patient-list_t2filterList-panel']/mat-optgroup/mat-option)[{0}]";
	private final String tier2FilterDrpdownOptionsPatientwithfuture_S ="Patient Filter with future Options";

	private final By ptnWithOverdueQuickLinkFollowUp_OR=By.xpath("//div[@id='lbl_quick-links_titleqlData' and contains(text(),'Patients with overdue follow-up')]");
	private final String ptnWithOverdueQuickLinkFollowUp_S="patient with overdue follow up";

	private final By ptnWithOverdueCountQuickLink_OR=By.xpath("(//div[@id='lbl_quick-links_titleqlData']/following-sibling::span)[3]");
	private final String ptnWithOverdueCountQuickLink_S="patient with overdue followup count";

	private final By editPenIcon_OR=By.xpath("//td[contains(@id,'lbl_transmission-list_td-latestComments')]/span");
	private final String editPenIcon_S="patient with overdue followup count";

	private final By clinicCommentPoupHeader_OR=By.xpath("//h6[@id='title_clinical-comment_clinical_comment']");
	//private final By clinicCommentPoupHeader_OR=By.xpath("//form[@id='commentPopUpForm']");
	private final String clinicCommentPoupHeader_S="patient with overdue followup count";

	
	private final By clinicCommentPoupCloseBtn_OR=By.xpath("//button[@id='btn_clinical-comment_cancel2']");
	//private final By clinicCommentPoupCloseBtn_OR=By.xpath("//div[@id='popupDiv']/preceding-sibling::div/a/span");
	private final String clinicCommentPoupCloseBtn_S="Clinic comment Popup CLose Button";


	private final String directAlertFlag_OR="//td[contains(@id,'lbl_transmission-list_td-patient')]//span[text()='{0}']/ancestor::td/following-sibling::td[6]/mat-icon";
	private final String directAlertFlag_S="Clinic comment Popup CLose Button";
	
	private final By enrollNewPatientBtn_OR = By.xpath("//button[@id='btn_quick-links_enroll-new-patient']");
	private final String enrollNewPatientBtn_S = "Enroll A New Patient Button";
	
	private final By enrollTranferredPatientCount_OR = By.xpath("//div[@id='lbl_quick-links_qldata-title8']/following-sibling::span");
	private final String enrollTranferredPatientCount_S = "Enroll Transferred Patients Count";
	
	public final By enrollTranferredPatientLink_OR = By.xpath("//button[@id='btn_quick-links_notify-count8']");
	public final String enrollTranferredPatientLink_S = "Enroll Transferred Patients Link";
	
	private final By releaseRequestSentAnotherClinicCount_OR = By.xpath("//div[@id='lbl_quick-links_qldata-title9']/following-sibling::span");
	private final String releaseRequestSentAnotherClinicCount_S = "Release Requests sent by another clinic Count";
	
	public final By releaseRequestSentAnotherClinicLink_OR = By.xpath("//button[@id='btn_quick-links_notify-count9']");
	public final String releaseRequestSentAnotherClinicLink_S = "Release Requests sent by another clinic Link";
	
	private final By pageLoading = By.xpath("//div[@class='spinnerWrapper show']");
	
	private final By enrollPatientPg_OR=By.xpath("//merlin-textbox[@controlName='enrollPatientByMerlinByNumber']");
	private final String enrollPatientPg_S="Clinic comment Popup CLose Button";
	
	

	//Victor
		private final By rtTable_OR=By.xpath("//table[@id='dtl_transmission-list_table']/tbody/tr/td[1]");
		private final String rtTable__S ="Archive Popup Caancel Button";
		
		private final String rtTable_device_OR="//table[@id='lbl_transmission-list_td-device{1}']";
		private final String rtTable_device_S ="cardiac Device the name";

		private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper show']");
		private final String pageLoading_S = "Page loading symbol";

	
	//author:snehal
	private final String tier3FilterDrpdownOptions_OR= "(//mat-option/span[contains(normalize-space(text()),'{value}')]";
	private final String tier3FilterDrpdownOptions_S ="Options present in tier3 filter";	

	private final By archivePopup_1unviwdtrans_OR = By.xpath("//div[@id='lbl_archive-popup_content']");
	private final String archivePopup_1unviwdtrans_S = "Pop up after archiving one unviewed transmission";
	
	private final By archivePopuOKBtn_OR = By.xpath("//button[@id='btn_archive-popup_ok']");
	private final String archivePopuOKBtn_S = "Archive Popup OK button";
	
	private final By patientTrnsLocationsTbl_OR=By.xpath("//td[contains(@id,'lbl_transmission-list_td-locations')]");
	private final String patientTrnsLocationsTbl_S="Locations Of Transmission in Table";
	
	//Author:Dhaval
	private final By firstAlertList_OR=By.xpath("//td[@id='lbl_transmission-list_td-alertsList0']");
	private final String firstAlertList_S="First Alert List value in Table";
	
	private final By patientNameCommentPopup_OR=By.xpath("//h5[@id='title_clinical-comment_patientName']");
	private final String patientNameCommentPopup_S="Patient Name on Comment popup";	
	
	private final By schedulePopUpHeader_OR=By.xpath("//div[@class='header-title']");
	private final String schedulePopUpHeader_S="Schedule pop up header";
	
	private final By cancelButtonSchedulePopUp_OR=By.xpath("//button[@class='mat-focus-indicator btn-styl mat-raised-button mat-button-base mat-accent']");
	private final String cancelButtonSchedulePopUp_S="Cancel Button Schedule Popup";
	
	private final By patientNameSchedulePopup_OR=By.xpath("//mat-card[@class='mat-card mat-focus-indicator flat ng-star-inserted']//h1");
	private final String patientNameSchedulePopup_S="Patient Name on Schedule popup";
	
	private final By firstSchedule_OR=By.xpath("//td[@id='lbl_transmission-list_td-schedule0']");
	private final String firstSchedule_S="First Schedule in Table";
	
	private final By firstTranmissionId_OR=By.xpath("//td[@id='lbl_transmission-list_td-transmission0']");
	private final String firstTranmissionId_S="First Transmission in Table";
	
	private final By deviceNameFirstTransmission_OR=By.xpath("//td[@id='lbl_transmission-list_td-device0']");
	private final String deviceNameFirstTransmission_S="Device Name of Transmission in Table";
	
	private final By columnDeviceInGrid_OR = By.xpath("//td[contains(@id,'lbl_transmission-list_td-device')][1]");
	private final String columnDeviceInGrid_S = "Device column";
	
	private final By firstLocationFilter_OR = By.xpath("(//div[@id='dd_transmission-list_RT_T2_advance_filter-panel']/mat-option)[1]");
	private final String firstLocationFilter_S = "First Location in Location filter";
	
	private final By columnLocationInGrid_OR = By.xpath("//td[contains(@id,'lbl_transmission-list_td-locations')]");
	private final String columnLocationInGrid_S = "Location Column";
	
	private final By columnPatientInGrid_OR = By.xpath("//td[contains(@id,'lbl_transmission-list_td-patient')]/a/div");
	private final String columnPatientInGrid_S = "Patient column";
	
	private final By searchBoxInRecentTrans_OR = By.xpath("//input[@id='txt_transmission-list_advancedSearch']");
	private final String searchBoxInRecentTrans_S = "Search Box";
	
	private final By filterForDeviceTypeRecentTrans_OR = By.xpath("//mat-select[@id='dd_transmission-list_RT_T2_advance_filter']");
	private final String filterForDeviceTypeRecentTrans_S = "Device Type Filter";
	
	private final By filterForLocationRecentTrans_OR = By.xpath("//mat-select[@id='dd_transmission-list_RT_T2_advance_filter']//div/span/span");
	private final String filterForLocationRecentTrans_S = "Location Filter";
	
	//victor
	private final By alertListGrid_OR = By.xpath("//table[@id='dtl_transmission-list_table']//td[9]");
	private final String alertListInGrid_S = "alert list column";
	
	
	private final By patientName_OR = By.xpath("//table[@id='dtl_transmission-list_table']//td[2]");
	private final String patientName_S = "Patient list column";
	
	private final By patientLocation_OR = By.xpath("//table[@id='dtl_transmission-list_table']//td[5]");
	private final String patientLocation_S = "Patient list column";
	
	
	
	private final By columnAlertListInGrid_OR = By.xpath("//td[contains(@id,'lbl_transmission-list_td-alertsList')]");
	private final String columnAlertListInGrid_S = "Patient column";
	
	private final By deviceTypeDropDown_OR = By.xpath("//input[@id='txt_transmission-list_advancedSearch']");
	private final String deviceTypeDropDown_S = "Advanced Filter for DeviceType";
	
	private final String deviceTypeDropDownOptions_OR= "(//div[@id='dd_transmission-list_RT_T2_advance_filter-panel']/mat-option/span)[{0}]";
	private final String deviceTypeDropDownOptions_S ="Device Type Filter Options";

	public static Log logger = new Log();
	
	
	//Author :Bhupendra
	public boolean verifyLocationOfTrnsInAscendingOrderInTable() {
		List<WebElement> listOfDispLocation = driver.findElements(patientTrnsLocationsTbl_OR);
		List<String> llist = new LinkedList<String> ();
		for (WebElement loc : listOfDispLocation) {
			llist.add(loc.getText());
		}
		List<String> Duplist = llist;
		Collections.sort(Duplist);
		return llist.equals(Duplist);	
	}	

	
	//Author :Bhupendra
	public boolean verifyEnrollPatientPg()
	{
		return visibilityOfElementLocatedWithReport(enrollPatientPg_OR, enrollPatientPg_S);
	}


	//Author :Bhupendra
	public String ValidateColorOfDirectAlertFlag(String patientName) {
		visibilityOfElementLocatedWithoutReport(By.xpath(directAlertFlag_OR.replaceAll("{0}", patientName)), directAlertFlag_S);
		return driver.findElement(By.xpath(directAlertFlag_OR.replaceAll("{0}", patientName))).getAttribute("Color").toString();		
	}	

	//Author :Bhupendra
	public void validateClinicCommentPoupCloseBtn() {
		elementToBeClickable(clinicCommentPoupCloseBtn_OR, clinicCommentPoupCloseBtn_S);
		clickElement(clinicCommentPoupCloseBtn_OR, clinicCommentPoupCloseBtn_S);
	}

	
	//Author :Bhupendra
	public boolean verifyClinicCommentPoup() {
		return visibilityOfElementLocatedWithReport(clinicCommentPoupHeader_OR, clinicCommentPoupHeader_S);
	}


	//Author :Bhupendra
	public void validatePencilIcon() {
		elementToBeClickable(editPenIcon_OR, editPenIcon_S);
		clickElement(editPenIcon_OR, editPenIcon_S);
	}
	
	//Author :Bhupendra
	public boolean verifyPencilIcon() {
		scrollToViewWebElementWithoutReport(driver.findElement(editPenIcon_OR), editPenIcon_S);
		return isEnabledWithoutReport(editPenIcon_OR, editPenIcon_S);
	}



	//Author :Bhupendra
	public void validateEnrollPatientBtn() {
		elementToBeClickable(enrollPatientBtn_OR, enrollPatientBtn_S);
		clickElement(enrollPatientBtn_OR, enrollPatientBtn_S);
	}

	//Author :Bhupendra
	public boolean verifyEnrollPatientBtn() {
		return visibilityOfElementLocatedWithReport(enrollPatientBtn_OR, enrollPatientBtn_S);
	}

	//Author :Bhupendra
	public boolean verifyDeviceColumn() {
		return visibilityOfElementLocatedWithReport(deviceColmnHeader_OR, deviceColmnHeader_S);
	}	

	//Author :Bhupendra
	public void validateAddRemPopupDoneBtn() {
		elementToBeClickable(addRemColDoneBtn_OR, addRemColDoneBtn_S);
		clickElement(addRemColDoneBtn_OR, addRemColDoneBtn_S);
	}	


	//Author :Bhupendra
	public void validateAddRemPopupCancelBtn() {
		elementToBeClickable(addRemColCancelBtn_OR, addRemColCancelBtn_S);
		clickElement(addRemColCancelBtn_OR, addRemColCancelBtn_S);
	}	


	//Author :Bhupendra
	public void validateSelectAddRemoveDeviceChckBx() {
		elementToBeClickable(deviceChckBxAddOrRemCol_OR, deviceChckBxAddOrRemCol_S);
		if(!isSelectedWithReport(deviceChckBxAddOrRemCol_OR, deviceChckBxAddOrRemCol_S))
			clickElement(deviceChckBxAddOrRemCol_OR, deviceChckBxAddOrRemCol_S);
	}	

	//Author :Bhupendra
	public void validateAddRemoveCol() {
		elementToBeClickable(moreActionAddOrRmovColOptn_OR, moreActionAddOrRmovColOptn_S);
		clickElement(moreActionAddOrRmovColOptn_OR, moreActionAddOrRmovColOptn_S);
	}			


	//Author :Bhupendra
	public void validateMrkAsUnvwdOption() {
		elementToBeClickable(moreActionMrkAsVwdOptn_OR, moreActionMrkAsVwdOptn_S);
		clickElement(moreActionMrkAsVwdOptn_OR, moreActionMrkAsVwdOptn_S);
	}

	//
	//Author :Bhupendra
	public void validateMoreActionBtn() {
		elementToBeClickable(moreActionBtn_OR, moreActionBtn_S);
		clickElement(moreActionBtn_OR, moreActionBtn_S);
	}



	//Author :Bhupendra
	public boolean verifyTransmissionReportPage() {
		if(visibilityOfElementLocatedWithoutReport(trnsDtLbl_OR, trnsDtLbl_S)) {
			return true;
		}else{
			return false;
		}
	}


	//Author :Bhupendra
	public void validateUnviewedTransLinkWithPatientName(String Pname,String index) {
		elementToBeClickable(By.xpath(unviewedTrnsLinkWithPatientName_OR.replace("{0}", Pname).replace("{1}", index)), unviewedTrnsLinkWithPatientName_S);
		scrollToViewWebElementWithReport(driver.findElement(By.xpath(unviewedTrnsLinkWithPatientName_OR.replace("{0}", Pname).replace("{1}", index))), unviewedTrnsLinkWithPatientName_S);
		clickElement(By.xpath(unviewedTrnsLinkWithPatientName_OR.replace("{0}", Pname).replace("{1}", index)), unviewedTrnsLinkWithPatientName_S);
	}


	//Author :Bhupendra
	public String  dtTimeValueUnviewedTrns(String Pname,String index) {
			
		return getText((By.xpath(unviewedTrnsLinkWithPatientName_OR.replace("{0}", Pname).replace("{1}", index))), unviewedTrnsLinkWithPatientName_S);
	}
	
	//Author :Bhupendra
		public String  dtTimeValueViewedTrns(String Pname,String index) {
				
			return getText((By.xpath(viewedTrnsWithPatientName_OR.replace("{0}", Pname).replace("{1}", index))), viewedTrnsWithPatientName_S);
		}

	
	//Author :Bhupendra
	public boolean verifyViewedTrnsWithPatientNameNTrnsDtTime(String Pname,String trnsDtNTime) {		
		scrollToViewWebElementWithReport(driver.findElement(By.xpath(viewedTrnsLinkWithPatientNameNDt_OR.replace("{0}", Pname).replace("{1}", trnsDtNTime))), viewedTrnsLinkWithPatientNameNDt_S);
		return visibilityOfElementLocatedWithReport(By.xpath(viewedTrnsLinkWithPatientNameNDt_OR.replace("{0}", Pname).replace("{1}", trnsDtNTime)), viewedTrnsLinkWithPatientNameNDt_S);
	}
	
	//Author :Bhupendra
		public boolean verifyUnViewedTrnsWithPatientNameNTrnsDtTime(String Pname,String trnsDtNTime) {		
			scrollToViewWebElementWithReport(driver.findElement(By.xpath(unviewedTrnsLinkWithPatientNameNDt_OR.replace("{0}", Pname).replace("{1}", trnsDtNTime))), unviewedTrnsLinkWithPatientNameNDt_S);
			return visibilityOfElementLocatedWithReport(By.xpath(unviewedTrnsLinkWithPatientNameNDt_OR.replace("{0}", Pname).replace("{1}", trnsDtNTime)), unviewedTrnsLinkWithPatientNameNDt_S);
		}

	//Author :Bhupendra
	public void valArchiveViwdTrnsBtn() {
		elementToBeClickable(archiveViwdTrnsBtn_OR, archiveViwdTrnsBtn_S);
		clickElement(archiveViwdTrnsBtn_OR, archiveViwdTrnsBtn_S);
	}		


	//Author :Bhupendra
	public boolean verifyViewedPatientInTable(String patientName,String index) {
		elementToBeClickable(By.xpath(viewedTrnsWithPatientName_OR.replace("{0}", patientName).replace("{1}", index)), viewedTrnsWithPatientName_S);
		if(isElementPresent(By.xpath(viewedTrnsWithPatientName_OR.replace("{0}", patientName).replace("{1}", index)), viewedTrnsWithPatientName_S))
		{
			return true;
		}
		else {
			return false;
		}
	}	



	//Author :Bhupendra
	public void valArchivePopupCancelBtn() {
		elementToBeClickable(archivePopuCancelBtn_OR, archivePopuCancelBtn_S);
		clickElement(archivePopuCancelBtn_OR, archivePopuCancelBtn_S);
	}	


	//Author :Bhupendra
	public boolean verifyArchiveViwdTrnsBtn() {
		if(visibilityOfElementLocatedWithReport(archiveViwdTrnsBtn_OR, archiveViwdTrnsBtn_S)) {
			return true;
		}else {
			return false;
		}
	}


	//Author :Bhupendra
	public void valArchiveSlctdTrnsBtn() {
		elementToBeClickable(archiveSlctdTrnsBtn_OR, archiveSlctdTrnsBtn_S);
		clickElement(archiveSlctdTrnsBtn_OR, archiveSlctdTrnsBtn_S);
	}		


	//Author :Bhupendra
	public boolean verifyArchiveSlctdTrnsBtn() {
		if(visibilityOfElementLocatedWithReport(archiveSlctdTrnsBtn_OR, archiveSlctdTrnsBtn_S)) {
			return true;
		}else {
			return false;
		}
	}


	//Author :Bhupendra
	public String verifyArchivePopupMsg() {		
		visibilityOfElementLocatedWithReport(archivePopupMsg_OR, archivePopupMsg_S);
		String DispMsg = getText(archivePopupMsg_OR, archivePopupMsg_S);
		return DispMsg;
	}


	//Author :Bhupendra
	public void validateArchiveBtn() {
		elementToBeClickable(archiveBtn_OR, archiveBtn_S);
		scrollToViewWebElementWithReport(driver.findElement(archiveBtn_OR), archiveBtn_S);
		clickElement(archiveBtn_OR, archiveBtn_S);
	}
	
	//Author :Bhupendra
		public boolean verifyArchiveBtn() {
			scrollToViewWebElementWithReport(driver.findElement(archiveBtn_OR), archiveBtn_S);
			return isEnabledWithoutReport(archiveBtn_OR, archiveBtn_S);		
		}



	//Author :Bhupendra
	public void slctPatientChkBx(String Pname,String index) {
		elementToBeClickable(By.xpath(patientTrnsFrmListChkBx_OR.replace("{0}", Pname).replace("{1}", index)), patientTrnsFrmListChkBx_S);
		scrollToViewWebElementWithReport(driver.findElement(By.xpath(patientTrnsFrmListChkBx_OR.replace("{0}", Pname).replace("{1}", index))), patientTrnsFrmListChkBx_S);
		clickElement(By.xpath(patientTrnsFrmListChkBx_OR.replace("{0}", Pname).replace("{1}", index)), patientTrnsFrmListChkBx_S);
	}

	//Author :Bhupendra
	public void slctUnvwdPatientChkBx(String Pname,String index) {
		elementToBeClickable(By.xpath(unviewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index)), unviewedPatientTrnsFrmTbltChkBx_S);
		scrollToViewWebElementWithReport(driver.findElement(By.xpath(unviewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index))), unviewedPatientTrnsFrmTbltChkBx_S);
		clickElement(By.xpath(unviewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index)), unviewedPatientTrnsFrmTbltChkBx_S);
	}

	//Author :Bhupendra
	public void slctVwdPatientChkBx(String Pname,String index) {
		elementToBeClickable(By.xpath(viewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index)), viewedPatientTrnsFrmTbltChkBx_S);
		scrollToViewWebElementWithReport(driver.findElement(By.xpath(viewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index))), viewedPatientTrnsFrmTbltChkBx_S);
		clickElement(By.xpath(viewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index)), viewedPatientTrnsFrmTbltChkBx_S);
	} 

	//Author :Bhupendra
	public boolean verifyPatientInTable(String patientName) {
		elementToBeClickable(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S);
		if(isElementPresent(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S))
		{
			return true;
		}
		else {
			return false;
		}

	}

	//Author :Bhupendra
	public boolean verifyUnViewedPatientInTable(String patientName,String index) {
		elementToBeClickable(By.xpath(unviewedTrnsWithPatientName_OR.replace("{0}", patientName).replace("{1}", index)), unviewedTrnsWithPatientName_S);
		if(isElementPresent(By.xpath(unviewedTrnsWithPatientName_OR.replace("{0}", patientName).replace("{1}", index)), unviewedTrnsWithPatientName_S))
		{
			return true;
		}
		else {
			return false;
		}
	}


	//Author :Bhupendra
	public void navigateToRecentTransmissionPage() throws Exception {
		clickElement(recentTrnsToTab_OR, recentTrnsToTab_S);
	}

	public String captureUnviewedTnsnCount() {
		String count=getText(unviewedTrnsCountQuickLink_OR,unviewedTrnsCountQuickLink_S);		
		return count;
	}

	//Author:Bhupendra Dhore
	//send the option parameter as : my patients,clinic patients
	public void selectTireOneFilterOption(String option) {
		try {
			waitForLoading();
			option=option.trim();
			elementToBeClickable(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
			clickElement(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
			if(option.equalsIgnoreCase("my patients")) {
				elementToBeClickable(tier1FilterDrpdownMyPatientOptn_OR, tier1FilterDrpdownMyPatientOptn_S);
				clickElement(tier1FilterDrpdownMyPatientOptn_OR, tier1FilterDrpdownMyPatientOptn_S);
			}
			else if(option.equalsIgnoreCase("clinic patients")) {
				elementToBeClickable(tier1FilterDrpdownClinicPatientOptn_OR, tier1FilterDrpdownClinicPatientOptn_S);
				clickElement(tier1FilterDrpdownClinicPatientOptn_OR, tier1FilterDrpdownClinicPatientOptn_S);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}

	//Author:Bhupendra Dhore
	//please send option as :all,cardiac monitor,icd/pacemaker, unviewed transmissions,transmissions with alerts,patient,patient id,physician name/id,device,device type,patient’s clinic location
	public void selectTireOTwoFilterOption(String option) {
		invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
		option=option.trim();
		elementToBeClickable(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);
		loadingWithoutReport();
		clickElement(tier2FilterDrpdown_OR, tier2FilterDrpdown_S);	
		switch (option) {
		case "all":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "1")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "1")), tier2FilterDrpdownOptions_S);	
			break;
		case "cardiac monitor":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "2")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "2")), tier2FilterDrpdownOptions_S);	
			break;
		case "icd/pacemaker":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "3")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "3")), tier2FilterDrpdownOptions_S);
			break;
		case "unviewed transmissions":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "4")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "4")), tier2FilterDrpdownOptions_S);
			break;
		case "transmissions with alerts":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "5")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "5")), tier2FilterDrpdownOptions_S);
			break;
		case "patient":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "6")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "6")), tier2FilterDrpdownOptions_S);
			break;
		case "patient id":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "7")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "7")), tier2FilterDrpdownOptions_S);
			break;
		case "physician name/id":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "8")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "8")), tier2FilterDrpdownOptions_S);
			break;
		case "device":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "9")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "9")), tier2FilterDrpdownOptions_S);
			break;
		case "device type":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "10")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "10")), tier2FilterDrpdownOptions_S);
			break;
		case "patient’s clinic location":
			elementToBeClickable(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "11")), tier2FilterDrpdownOptions_S);
			clickElement(By.xpath(tier2FilterDrpdownOptions_OR.replace("{0}", "11")), tier2FilterDrpdownOptions_S);
			break;
		default:
			System.out.println("Not able to find the optionin dropdown");
		}

	}

	//Author:Bhupendra Dhore
	public void enterTier3FilterInputBx(String text) {
		elementToBeClickable(tier3FilterDrpdown_OR, tier3FilterDrpdown_S);
		driver.findElement(tier3FilterDrpdown_OR).clear();
		sendKeys(tier3FilterDrpdown_OR, text);
	}

	//Author:Bhupendra Dhore
	public void navigateToMyAccountPg() {
		elementToBeClickable(signnedInAsLink_OR, signnedInAsLink_S);
		clickElement(signnedInAsLink_OR, signnedInAsLink_S);
		visibilityOfElementLocatedWithReport(myAccountHeader_OR, myAccountHeader_S);
	}


	//Author:Bhupendra Dhore
	public void validateEditBtnMyAcnt() {
		elementToBeClickable(myAccountEditBtn_OR, myAccountEditBtn_S);
		clickElement(myAccountEditBtn_OR, myAccountEditBtn_S);
	}

	//Author:Bhupendra Dhore
	public void validateSelectClinicLocRdBtn() {
		scrollToViewWebElementWithReport(driver.findElement(clinicLocRadioBtn_OR), clinicLocRadioBtn_S);
		elementToBeClickable(clinicLocRadioBtn_OR, clinicLocRadioBtn_S);
		if(!isSelectedWithoutReport(clinicLocRadioBtn_OR,clinicLocRadioBtn_S))
			clickElement(clinicLocRadioBtn_OR,clinicLocRadioBtn_S);

		isSelectedWithReport(clinicLocRadioBtn_OR,clinicLocRadioBtn_S);
	}
	//Author:Bhupendra Dhore
	public void validateDeSelectClinicLocRdBtn() {
		scrollToViewWebElementWithReport(driver.findElement(clinicLocRadioBtn_OR), clinicLocRadioBtn_S);
		elementToBeClickable(clinicLocRadioBtn_OR, clinicLocRadioBtn_S);
		if(isSelectedWithoutReport(clinicLocRadioBtn_OR,clinicLocRadioBtn_S))
			clickElement(clinicLocRadioBtn_OR,clinicLocRadioBtn_S);		
	}

	//Author:Bhupendra Dhore
	public boolean verifyClinicLocRdBtn() {
		return isSelectedWithoutReport(clinicLocRadioBtn_OR,clinicLocRadioBtn_S);
	}

	//Author:Dhaval Kothari
	public void navigateToPatientProfilePage(String patientName) {
		elementToBeClickable(By.xpath(patientNameFrmList_OR.replace("{0}",patientName )), patientNameFrmList_S);
		clickElement(By.xpath(patientNameFrmList_OR.replace("{0}", patientName)), patientNameFrmList_S);
	}

	//Author:Bhupendra Dhore
	public void validateSaveBtn() {
		scrollToViewWebElementWithReport(driver.findElement(saveBtnMyAcntPg_OR), saveBtnMyAcntPg_S);
		elementToBeClickable(saveBtnMyAcntPg_OR, saveBtnMyAcntPg_S);
		clickElement(saveBtnMyAcntPg_OR,saveBtnMyAcntPg_S);
	}

	//Author:Bhupendra Dhore
	public int viewedTrnsmissionDipInTable() {
		int count = driver.findElements(viewedTrnsDispalyedIntTblList_OR).size();		
		return count;
	}

	//Author:Bhupendra Dhore
	public int unviewedTrnsmissionDipInTable() {
		int count = driver.findElements(unviewedTrnsDispalyedIntTblList_OR).size();		
		return count;
	}

	//Author:Abhishek kumar
	public void verifyQuickLinkModule() {

		verifyElementWithReport(quickLinks_OR,quickLinks_S);

	}

	//Author:Bhupendra Dhore
	//this will validate the unviewed quicklink 
	public void verifyUnviewedTransmissionLink() {

		verifyElementWithReport(unviewedTrnsQuickLink_OR, unviewedTrnsQuickLink_S);

	}

	//Author:Bhupendra Dhore
	//this will click on unviewed quick link 
	public void navigateToUnviewedTransmissionPage() {
		clickElementWithoutReport(unviewedTrnsQuickLink_OR, unviewedTrnsQuickLink_S);
	}
	//Author:Abhishek kumar
	public void validateTrnsWithAlertQuickLink() {
		verifyElementWithReport(TrnswithAlertQuickLink_OR, TrnswithAlertQuickLink_S);
	}

	//Author:Abhishek kumar
	public String captureTrnswithAlertCount() {
		String count=getText(TrnswithAlertCountQuickLink_OR,TrnswithAlertCountQuickLink_S);		
		return count;
	}

	public void navigateTrnsWithAlertQuickLink() {
		clickElementWithoutReport(TrnswithAlertQuickLink_OR, TrnswithAlertQuickLink_S);
	}

	// Each page class should have this overridden method of Verify Landing page 	
	
	/*
	 * Author: Rajesh Singaraj
	 * Test case ID: 1244058
	 */
	
	private final By transmissionColumn_OR = By.xpath("//th[@id='lbl_transmission-list_th-transmission']");
	private final String transmissionColumn_S = "Transmission Column";
	private final By firstTransmissionInTable_OR = By.xpath("//table[@id='dtl_transmission-list_table']/tbody/tr[1]/td[3]/div[1]");
	private final String firstTransmissionInTable_S = "First Transmission";
	private final By secondTransmissionInTable_OR = By.xpath("//table[@id='dtl_transmission-list_table']/tbody/tr[2]/td[3]/div[1]/span[1]");
	private final String secondTransmissionInTable_S = "Second Transmission";
	private final By episodesAndEGMs_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']");
	private final String episodesAndEGMs_S = "Episodes And EGMs";
	private final By markUnread_OR = By.xpath("(//mat-icon[text()='markunread'])[1]");
	private final String markUnread_S = "Mark Unread Button";
	private final By markRead_OR = By.xpath("(//mat-icon[text()='markunread'])[1]");
	private final String markRead_S = "Mark Read Button";
	private final By transmissonPrint_OR = By.xpath("//button[@id='btn_transmission-list_print']");
	private final String transmissonPrint_S = "Transmisson Print Button";
	private final By transmissonPrintPage_OR = By.xpath("//h6[@id='title_print-transmission_pt']");
	private final String transmissonPrintPage_S = "Transmisson Print page";
	private final By transmissonPrintPageCanCelBtn_OR = By.xpath("//button[@id='btn_print-transmission_availableReportsCancel']/span");
	private final String transmissonPrintPageCanCelBtn_S = "Transmisson Print page cancel button";
	private final By signOutBtn_OR = By.xpath("//span[text()='Sign Out']");
	private final String signOutBtn_S = "Signout button";
	private final By recentTransmissionSearch_OR = By.xpath("//input[@id='txt_transmission-list_search']");
	private final String recentTransmissionSearch_S= "Recent Transmission Search Button";
	private final By recentTransmissionReports_OR = By.xpath("//div[@class='mat-list-text']");
	private final String recentTransmissionReports_S= "Recent Transmission Reports";
	private final By recentTransmEpisAndEGMReports_OR = By.xpath("//a[@id='btn_transmission_summary_left_menu_1_0']");
	private final String recentTransmEpisAndEGMReports_S= "Episodes and EGMs";
	private final By recentTransMergedReports_OR = By.xpath("btn_transmission_summary_left_menu_6_0");
	private final String recentTransMergedReports_S= " View Merged Report ";
	private final By patientsDrpdown_OR= By.xpath("//mat-select[@id='dd_transmission-list_RT_T1_Filter']/div[1]/div[2]");
	private final String patientsDrpdown_S ="Patient Filter DropDown";
	private final By archiveButton_OR= By.xpath("//a[@id='btn_transmission-list_archive']/span[1]");
	private final String archiveButton_S ="Archive Button";
	private final By clinicPatientsDDValue_OR = By.xpath("//div[@id='dd_transmission-list_RT_T1_Filter-panel']/mat-option[2]");
	private final String clinicPatientsDDValue_S ="Clinic patients dropdown value";
	
	private DataBaseConnector dataBase = new DataBaseConnector();
	SoftAssert assertion =  new SoftAssert();
	
	public void clickOnElement(String type) throws InterruptedException {
		switch (type){
			case "TransmissionColumn":
				clickElement(transmissionColumn_OR, transmissionColumn_S);
				break;
			case "FirstTransmission":
				clickElement(firstTransmissionInTable_OR, firstTransmissionInTable_S);
				break;
			case "EpisodesAndEGM":
				clickElement(episodesAndEGMs_OR, episodesAndEGMs_S);
				break;
			case "RecentTrnsTab":
				clickElement(recentTrnsToTab_OR, recentTrnsToTab_S);
				break;
			case "SecondTransmission":
				clickElement(secondTransmissionInTable_OR, secondTransmissionInTable_S);
				break;
			case "TransmissonPrint":
				clickElement(transmissonPrint_OR, transmissonPrint_S);
				break;
			case "TransmissonCancel":
				clickElement(transmissonPrintPageCanCelBtn_OR, transmissonPrintPageCanCelBtn_S);
				break;
			case "SignOut":
				clickElement(signOutBtn_OR, signOutBtn_S);
				break;
			case "Archive":
				clickElement(archiveButton_OR, archiveButton_S);
				break;
			default: break;
			
		}
		
		
	}	
	public void searchPatient(String patientname, int sequenceNo) 
	{
		String[] patientNo=patientname.split(";");
		String[] PatientFirstName= patientNo[sequenceNo-1].split(",");
		sendKeys(recentTransmissionSearch_OR, recentTransmissionSearch_S,PatientFirstName[1]);
		extentReport.reportScreenShot("Patient search with name - "+PatientFirstName[1]);
	}

	public void selectTier1FilterValueFromDropdown() {
		
		clickElement(patientsDrpdown_OR, patientsDrpdown_S);
		clickElement(clinicPatientsDDValue_OR, clinicPatientsDDValue_S);
		invisibilityOfElementLocated(pageLoading_OR);
		extentReport.reportScreenShot("Clinic patients is selected in tier 1 filter dropdown ");
	}
	
	public void verifyElement(String type) throws InterruptedException {
		switch (type){
			case "AllTransmissionReports":
				verifyElementWithReport(recentTransmEpisAndEGMReports_OR, recentTransmEpisAndEGMReports_S);
				verifyElementWithReport(recentTransMergedReports_OR, recentTransMergedReports_S);
				extentReport.reportScreenShot("Transmission page is displayed showing applicable transmission reports");
				break;
			case "PrintTransmission":
				verifyElementWithReport(transmissonPrintPage_OR,transmissonPrintPage_S);
				extentReport.reportScreenShot("Print dialog page for the transmission is displayed");
				break;
			case "MarkUnread":
				verifyElementWithReport(markUnread_OR,markUnread_S);
				extentReport.reportScreenShot("selected transmission is not marked as viewed");
				break;
			case "MarkRead":
				verifyElementWithReport(markRead_OR,markRead_S);
				extentReport.reportScreenShot("selected transmission is marked as viewed");
				break;
			default: break;
		}
	}

	public void verifyStatusCodeAndLastViewForRecentTransmission(int sessionDateRank, boolean isLastViewedRequired, int status) throws SQLException, InterruptedException {
		dataBase.getConnection();
		ResultSet customerRecord = dataBase.executeQuery("select status_cd, last_viewed_by from transmissions.rt_cache rc where rc.customer_application_id=146225 and session_date_and_time in(\r\n"
				+ "select session_date_and_time from(\r\n"
				+ "select rank() over(order by session_date_and_time desc) rnum,session_date_and_time from transmissions.rt_cache rc\r\n"
				+ "where rc.customer_application_id=146225 and rc.device_category_cd=2200)t where rnum="+sessionDateRank+");");
		while (customerRecord.next()) {
			String statusCode = customerRecord.getString("status_cd");
			if(statusCode.equals(status)) {
				assertion.assertTrue(true);
				
			}else {
				assertion.assertTrue(false);			
			}
			if(isLastViewedRequired)
			{
				String lastView = customerRecord.getString("last_viewed_by");
				if(lastView.equals(" ")) {
					assertion.assertTrue(true);
				}else {
					assertion.assertTrue(false);
			}
			}
		}
	}
		//Rajesh code ends here 

	

	/*
	 * Author Salin Gambhir
	 * Test case name quicklinks_02
	 */

	private final By disconnectedTransmitterLink_OR = By.xpath("//app-transmission//div[2]/div[2]/div/app-quick-links/div/mat-action-list/button[5]/div/div[3]/div");
	private final String disconnectedTransmitterLink_S = "Disconnected Transmitter Links";
	private final By disconnectedTransmitterLinkCount_OR = By.xpath("//app-transmission/div[2]/div[2]/div/app-quick-links/div/mat-action-list/button[5]/div/div[3]/span");
	private final String disconnectedTransmitterLinkCount_S = "Disconnect Transmitter Link Count";  
	private final By messageLink_OR = By.xpath("//app-transmission/div[2]/div[2]/div/app-quick-links/div/mat-action-list/button[6]/div/div[3]/div");
	private final String messageLink_S = "Message Link page";

	public boolean verifyDisconnectedTransmitterLink() {

		return visibilityOfElementLocatedWithReport(disconnectedTransmitterLink_OR, disconnectedTransmitterLink_S);

	}

	public boolean verifyDisconnectedTransmitterLinkCount(int expectedValue) {
		boolean countCheck= false;
		try {
			int countValue = Integer.parseInt(getText(disconnectedTransmitterLinkCount_OR, disconnectedTransmitterLinkCount_S).trim());
			System.out.println("disconneceted transmitter linl count " + countValue);
			if (countValue == expectedValue)
			{
				extentReport.reportPass("Disconnected Transmitter link has same value as Patient List");
				countCheck = true;
			}
			else
				extentReport.reportFail("Disconnected Transmitter link has different value as Patient List");

		}
		catch(Exception e)
		{
			e.getStackTrace();
			throw e;
		}
		return countCheck;

	}

	public void goToDisconnectedTransmitterLink()
	{
		clickElement(disconnectedTransmitterLink_OR, disconnectedTransmitterLink_S);
	}
	
	public void goToMessageQuickLink()
	{
		clickElement(messageLink_OR, messageLink_S);
	}
	// Salin Test case end here

	public void validateptnWithNoFutureScheduleLink() {
		verifyElementWithReport(ptnWithNoFutureScheduleLink_OR, ptnWithNoFutureScheduleLink_S);
	}

	public String captureptnWithNoFutureScheduleCount() {
		String count=getText(ptnWithNoFutureScheduleCountLink_OR,ptnWithNoFutureScheduleCountLink_S);
		return count;
	}

	public void navigateptnWithNoFutureScheduleLink() {
		clickElementWithoutReport(ptnWithNoFutureScheduleLink_OR, ptnWithNoFutureScheduleLink_S);
	}

	public void validateActivePatientDropdown() {
		isDisplayedWithReport(tier1FilterActivePatient_OR, tier1FilterActivePatient_S); 
	}
	
	//Victor
	public void verifyMyPatientIsdisplayedTier1() {
		isDisplayedWithReport(tier1FilterDrpdownMyPatientOptn_OR, tier1FilterDrpdownMyPatientOptn_S); 
	}
	
	public void verifyALLIsdisplayedTier2() {
		isDisplayedWithReport(tier2FilterDrpdown_OR, tier2FilterDrpdown_S); 
	}

	//Autheor:Abhishek kumar
	public boolean validateTier2filterPatientwithfuture(String quicklinkValue) {
		//quicklinkValue=quicklinkValue.trim();
		elementToBeClickable(tier2FilterDrpdownOptionsPatientwith_OR, tier2FilterDrpdownOptionsPatientwith_S);
		clickElement(tier2FilterDrpdownOptionsPatientwith_OR, tier2FilterDrpdownOptionsPatientwith_S);
		boolean flag=false;
		if(quicklinkValue.equalsIgnoreCase("Patients with no future schedule")) {
			flag=isDisplayedWithReport(By.xpath(tier2FilterDrpdownOptionsPatientwithfuture_OR.replaceAll("{0}", "4")), tier2FilterDrpdownOptionsPatientwithfuture_S); 
			return flag;
		}
		else if(quicklinkValue.equalsIgnoreCase("Patients with overdue follow-up")) {
			flag=isDisplayedWithReport(By.xpath(tier2FilterDrpdownOptionsPatientwithfuture_OR.replaceAll("{0}", "5")), tier2FilterDrpdownOptionsPatientwithfuture_S);
			return flag;
		}

		else {
			System.out.println("Not able to find the optionin dropdown");

		}
		return flag;


	}
	
	public int totalpatientWithOverdurCountInTable() {
		List<WebElement> li=driver.findElements(By.xpath("//td[contains(@id,'lbl_patient-list_td-patientName')"));
		int listOfPatientInTable=li.size();
		return listOfPatientInTable;
		
	}
	
	//Gowshalya
	public void clickEnrollANewPatientButton() {
		clickElement(enrollNewPatientBtn_OR, enrollNewPatientBtn_S);
	}
	
	public String getEnrollTransferredPatientCount() {
		String count=getText(enrollTranferredPatientCount_OR,enrollTranferredPatientCount_S);		
		return count;
	}
	
	public void clickOnEnrollTransferredPatient() {
		clickElement(enrollTranferredPatientLink_OR, enrollTranferredPatientLink_S);
	}
	
	public String getReleaseRequestSentByAnotherClinicCount() {
		String count=getText(releaseRequestSentAnotherClinicCount_OR,releaseRequestSentAnotherClinicCount_S);		
		return count;
	}
	
	public void clickOnReleaseRequestSentByAnotherClinic() {
		clickElement(releaseRequestSentAnotherClinicLink_OR, releaseRequestSentAnotherClinicLink_S);
	}

	public void clickOnPatientNameFromTrnmsnList() {
		clickElement(patientNameInList_OR, patientNameInList_S);
		loadingWithoutReport();
	}
	
	public void clickOnTransmissionFromTrnmsnList() {
		if(isElementPresentwithoutException(transmissionFromTrnsList_OR, transmissionFromTrnsList_S)) {
			clickOnElementUsingJs(firstTrans_OR,firstTrans_S);
			loadingWithoutReport();
			extentReport.reportScreenShot("Clicked on Transmission in Transmission List");
		}
		else {
			extentReport.reportScreenShot("No transmission available in Transmission List");
		}
	}

	public void overDueFollowUp() {
		elementToBeClickable(ptnWithOverdueQuickLinkFollowUp_OR, ptnWithOverdueQuickLinkFollowUp_S);
		clickElement(ptnWithOverdueQuickLinkFollowUp_OR, ptnWithOverdueQuickLinkFollowUp_S);
	}

	public void validateptnWithOverdueFollowUp() {
		verifyElementWithReport(ptnWithOverdueQuickLinkFollowUp_OR,ptnWithOverdueQuickLinkFollowUp_S);
	}

	public String captureptnWithOverdueFollowUpCount() {
		String count=getText(ptnWithOverdueCountQuickLink_OR, ptnWithOverdueCountQuickLink_S);
		return count;
	}
	
	//Author:Snehal Mane
		public void validateTier3FilterOptions(String option) {
			elementToBeClickable(tier3FilterDrpdown_OR, tier3FilterDrpdown_S);
			clickElement(tier3FilterDrpdown_OR, tier3FilterDrpdown_S);
			verifyElementWithReport(By.xpath(tier3FilterDrpdownOptions_OR.replace("{value}", option)),tier3FilterDrpdownOptions_S);
		}
		
		public String verifyArchivePopupMsgUnviewdTrans() {		
			visibilityOfElementLocatedWithReport(archivePopup_1unviwdtrans_OR, archivePopup_1unviwdtrans_S);
			extentReport.reportScreenShot("Popup displayed after clicking on archive button");
			String DispMsg = getText(archivePopup_1unviwdtrans_OR, archivePopup_1unviwdtrans_S);
			return DispMsg;
		}
		
		public void ClickOnArchivePopupOKBtn() {
			elementToBeClickable(archivePopuOKBtn_OR, archivePopuOKBtn_S);
			clickElement(archivePopuOKBtn_OR, archivePopuOKBtn_S);
			extentReport.reportScreenShot("Clicked on OK button and Popup disappears");
		}
		
		public void validateArchivedTransNotPresent(String Pname,String index) {
			enterTier3FilterInputBx(Pname);
			loading();
			invisibilityOfElementLocatedWithReport(By.xpath(unviewedPatientTrnsFrmTbltChkBx_OR.replace("{0}", Pname).replace("{1}", index)), unviewedPatientTrnsFrmTbltChkBx_S);
			}
		
		public void navigateOverDueFollowUp() {
			elementToBeClickable(ptnWithOverdueQuickLinkFollowUp_OR, ptnWithOverdueQuickLinkFollowUp_S);
			clickElement(ptnWithOverdueQuickLinkFollowUp_OR, ptnWithOverdueQuickLinkFollowUp_S);
		}

		/*
		 * Author Salin Gambhir
		 * TC Name: 
		 */
		private final By printTranmissionButton_OR = By.xpath("//button[@id='btn_transmission-list_print']");
		private final String printTranmissionButton_S = "Print Button"; 
		private final By printTransmission_OR = By.xpath("//h6[@id='title_print-transmission_pt']");
		private final String printTransmission_S = "Print Transmission" ;
		private final By printAllCheckbox_OR = By.xpath("//input[@id='chb_print-transmission_printSelect-input']");
		private final String printAllCheckbox_S = "Print All";
		private final By VT_VF_Episode_OR = By.xpath("//mat-checkbox[@formcontrolname='allowVtfEpisode']//input[@id='chb_print-transmission_last-input']");
		private final String VT_VF_Episode_S = "VT/VF Episode";
		private final By SVT_Episode_OR = By.xpath("//mat-checkbox[@formcontrolname='allowSvtEpisode']//input[@id='chb_print-transmission_last-input']");
		private final String SVT_Episode_S = "SVT Episodes";
		private final By AT_AF_Episode_OR = By.xpath("//input[@id='chb_print-transmission_allowAtfEpisode-input']");
		private final String AT_AF_Episode_S = "AT/AF Episodes";
		private final By nonSustainedEvents_OR = By.xpath("//input[@id='chb_print-transmission_allowNsvtEpisode-input']");
		private final String nonSustainedEvents_S = "Non-sustained Events";
		private final By otherEpisode_OR = By.xpath("//input[@id='chb_print-transmission_allowOthEpisode-input']");
		private final String otherEpisode_S = "Other Episodes";
		private final By printButton_OR = By.xpath("//button[@id='btn_print-transmission_availableReportsPrint']");
		private final String printButton_S = "Print Button";
		private final By dropdownVTVFEpisode_OR = By.xpath("//mat-select[@id='dd_print-transmission_vtfEpisodeNumCd']//span//span");
		private final String dropdownVTVFEpisode_S = "VT/VF Episode dropdown";
		private final By dropdownSVTEpisode_OR = By.xpath("//mat-select[@id='dd_print-transmission_svtEpisodeNumCd']//span//span");
		private final String dropdownSVTEpisode_S = "SVT Episode dropdown";
		private final By dropdownAFATEpisode_OR = By.xpath("//mat-select[@id='dd_print-transmission_atfEpisodeNumCd']//span//span");
		private final String dropdownAFATEpisode_S = "AT/AF Episode dropdown";
		private final By dropdownNonSustaintableEpisode_OR = By.xpath("//mat-select[@id='dd_print-transmission_nsvtEpisodeNumCd']//span//span");
		private final String dropdownNonSustaintableEpisode_S = "Non Sustainable Episode dropdown";
		private final By dropdownOtherEpisode_OR = By.xpath("//mat-select[@id='dd_print-transmission_othEpisodeNumCd']//span//span");
		private final String dropdownOtherEpisode_S = "Other Episode dropdown";
		private final By printPatientRecordButton_OR = By.xpath("//button[@id='btn_popup-pdf_print']");
		private final String printPatientRecordButton_S = "Print PDF Viewer button";
		private final By closeButton_OR = By.xpath("//button[@id='btn_popup-pdf_close']");
		private final String closeButton_S = "Close Button";
		
		
		public void clickOnPrintButton() {
			// TODO Auto-generated method stub
			
			try {
				if (!isDisplayedWithReport(printTranmissionButton_OR, printTranmissionButton_S))
				{
					elementToBeClickable(printTranmissionButton_OR, printTranmissionButton_S);
					clickElement(printTranmissionButton_OR, printTranmissionButton_S);
				}
				
			}
			catch(Exception e)
			{
				e.getStackTrace();
				throw e;
			}
		}
		
		public boolean verifyPrintTransmission() {
			// TODO Auto-generated method stub
			boolean checkPrintTransmissionPage = false;
		try {
			if(visibilityOfElementLocatedWithoutReport(printTransmission_OR, printTransmission_S))
			{
				extentReport.reportPass("Print Transmission page is opened");
				checkPrintTransmissionPage = true;
			}
			else
				extentReport.reportFail("Print Transmission page is opened");
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
			return checkPrintTransmissionPage;

		}


		public void allPrintSummaryCheckboxStatus(String status) {
			
			try {
				
				switch (status.toLowerCase())
				{
				case "uncheckall":
					if (isSelectedWithReport(printAllCheckbox_OR, printAllCheckbox_S))
					{
						extentReport.reportInfo("Print All checkbox is selected, so unchecking it all");
						waitForElementToBeClickable(printAllCheckbox_OR, printAllCheckbox_S);
						elementToBeClickable(printAllCheckbox_OR, printAllCheckbox_S);
						clickElement(printAllCheckbox_OR, printAllCheckbox_S);
						
					}
					else
					{
						elementToBeClickable(printAllCheckbox_OR, printAllCheckbox_S);
						clickElement(printAllCheckbox_OR, printAllCheckbox_S);
						extentReport.reportInfo("Print All checkbox is selected again already");
						elementToBeClickable(printAllCheckbox_OR, printAllCheckbox_S);
						clickElement(printAllCheckbox_OR, printAllCheckbox_S);
						extentReport.reportInfo("Print All checkbox is selected again already");
					}
					break;
				case "checkall":
					if(!isSelectedWithReport(printAllCheckbox_OR, printAllCheckbox_S))
					{
						extentReport.reportInfo("Print All checkbox is selected, so unchecking it all");
						waitForElementToBeClickable(printAllCheckbox_OR, printAllCheckbox_S);
						elementToBeClickable(printAllCheckbox_OR, printAllCheckbox_S);
						clickElement(printAllCheckbox_OR, printAllCheckbox_S);
					}
					else
						extentReport.reportInfo("Print All checkbox is already selected.");
					
					break;
				case "vt/vf episodes":
					if (!isSelectedWithReport(printButton_OR, printButton_S))
					{
						extentReport.reportInfo("Selecting VT/VF Episode Checkbox");
						elementToBeClickable(VT_VF_Episode_OR, VT_VF_Episode_S);
						clickElement(VT_VF_Episode_OR, VT_VF_Episode_S);
						
					}
					else
						extentReport.reportInfo("Selecting VT/VF Episode Checkbox is already selected");
					break;
				case "svt episodes":
					if (!isSelectedWithReport(printButton_OR, printButton_S))
					{
						extentReport.reportInfo("Selecting SVT Episode Checkbox");
						elementToBeClickable(SVT_Episode_OR, SVT_Episode_S);
						clickElement(SVT_Episode_OR, SVT_Episode_S);
						
					}
					else
						extentReport.reportInfo("Selecting SVT Episode Checkbox is already selected");
					break;
				case "at/af episodes":
					if (!isSelectedWithReport(printButton_OR, printButton_S))
					{
						extentReport.reportInfo("Selecting AT/AF Episode Checkbox");
						elementToBeClickable(AT_AF_Episode_OR, AT_AF_Episode_S);
						clickElement(AT_AF_Episode_OR, AT_AF_Episode_S);
						
					}
					else
						extentReport.reportInfo("Selecting AT/AF Episode Checkbox is already selected");
					break;
				case "non-sustained episodes":
					if (!isSelectedWithReport(printButton_OR, printButton_S))
					{
						extentReport.reportInfo("Selecting Non-Sustainable Episode Checkbox");
						elementToBeClickable(nonSustainedEvents_OR, nonSustainedEvents_S);
						clickElement(nonSustainedEvents_OR, nonSustainedEvents_S);
						
					}
					else
						extentReport.reportInfo("Selecting Non-Sustainable Episode Checkbox is already selected");
					break;
				case "other episode":
					if (!isSelectedWithReport(printButton_OR, printButton_S))
					{
						extentReport.reportInfo("Selecting VT/VF Episode Checkbox");
						elementToBeClickable(otherEpisode_OR, otherEpisode_S);
						clickElement(otherEpisode_OR, otherEpisode_S);
						
					}
					else
						extentReport.reportInfo("Selecting Other Episode Checkbox is already selected");
					break;
					
				}
					
				
			}
			catch (Exception e)
			{
				e.getStackTrace();
				throw e;
			}
			
		}


		public void selectDropdownForEpisode(String episode, String value) {
			// TODO Auto-generated method stub
			try {
				
				switch (episode.toLowerCase())
				{
				case "vt/vf episodes":
				
					elementToBeClickable(dropdownVTVFEpisode_OR, dropdownVTVFEpisode_S);
					clickElement(dropdownVTVFEpisode_OR, dropdownVTVFEpisode_S);
					sendKeys(dropdownVTVFEpisode_OR, dropdownVTVFEpisode_S, value);
					
					break;
				
				case "svt episodes":
				
					elementToBeClickable(dropdownSVTEpisode_OR, dropdownSVTEpisode_S);
					clickElement(dropdownSVTEpisode_OR, dropdownSVTEpisode_S);
					sendKeys(dropdownSVTEpisode_OR, dropdownSVTEpisode_S, value);
				
				break;
				
				case "at/af episodes":
					
					elementToBeClickable(dropdownAFATEpisode_OR, dropdownAFATEpisode_S);
					clickElement(dropdownVTVFEpisode_OR, dropdownVTVFEpisode_S);
					sendKeys(dropdownVTVFEpisode_OR, dropdownVTVFEpisode_S, value);
				
				break;
				
				case "non-sustainable episodes":
					
					elementToBeClickable(dropdownNonSustaintableEpisode_OR, dropdownNonSustaintableEpisode_S);
					clickElement(dropdownNonSustaintableEpisode_OR, dropdownNonSustaintableEpisode_S);
					sendKeys(dropdownNonSustaintableEpisode_OR, dropdownNonSustaintableEpisode_S, value);
				
				break;
				
				case "other episodes":
					
					elementToBeClickable(dropdownOtherEpisode_OR, dropdownOtherEpisode_S);
					clickElement(dropdownOtherEpisode_OR, dropdownOtherEpisode_S);
					sendKeys(dropdownOtherEpisode_OR, dropdownOtherEpisode_S, value);
				
				break;
			}
				
			}
			catch (Exception e )
			{
				e.printStackTrace();
				throw e;
			}
			
			
		}


		public void clickPrintButton() {
			
			try {
				elementToBeClickable(printButton_OR, printButton_S);
				clickElement(printButton_OR, printButton_S);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw e;
			}
			
		}


		public void clickPrintOnPatientRecord() {
			// TODO Auto-generated method stub
			
			try {
				elementToBeClickable(printPatientRecordButton_OR, printPatientRecordButton_S);
				clickElement(printPatientRecordButton_OR, printPatientRecordButton_S);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw e;
			}
			
		}
		

		public void clickCloseButton() {
			// TODO Auto-generated method stub
			try {
				elementToBeClickable(closeButton_OR, closeButton_S);
				clickElement(closeButton_OR, closeButton_S);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw e;
			}
		}
		
		//Author :Dhaval
		
		public String verifyPatientNameSchedulePopupMsg() {		
			visibilityOfElementLocatedWithReport(patientNameSchedulePopup_OR, patientNameSchedulePopup_S);
			return getText(patientNameSchedulePopup_OR, patientNameSchedulePopup_S);
			
		}


		public void clickCancelByOnSchedulePopup() {
			elementToBeClickable(cancelButtonSchedulePopUp_OR, cancelButtonSchedulePopUp_S);
			clickElement(cancelButtonSchedulePopUp_OR, cancelButtonSchedulePopUp_S);
		}
		
		
		public String verifyHeaderSchedulePopupMsg() {		
			visibilityOfElementLocatedWithReport(schedulePopUpHeader_OR, schedulePopUpHeader_S);
			return getText(schedulePopUpHeader_OR, schedulePopUpHeader_S);
			
		}
		
		public String verifyPatientNameCommentPopupMsg() {		
			visibilityOfElementLocatedWithReport(patientNameCommentPopup_OR, patientNameCommentPopup_S);
			return getText(patientNameCommentPopup_OR, patientNameCommentPopup_S);
			
		}
		
		public String verifyFirstTranmissionDtTimeOnRT() {		
			visibilityOfElementLocatedWithReport(firstTranmissionId_OR, firstTranmissionId_S);
			return getText(firstTranmissionId_OR, firstTranmissionId_S);
		}
		
		public void clickFirstTranmissionOnRT() {
			elementToBeClickable(firstTranmissionId_OR, firstTranmissionId_S);
			clickElement(firstTranmissionId_OR, firstTranmissionId_S);
		} 

		public String verifyDeviceNameOnRT() {		
			visibilityOfElementLocatedWithReport(deviceNameFirstTransmission_OR, deviceNameFirstTransmission_S);
			return getText(deviceNameFirstTransmission_OR, deviceNameFirstTransmission_S);
		}
		
		public void clickFirstScheduleOnRT() {
			elementToBeClickable(firstSchedule_OR, firstSchedule_S);
			clickElement(firstSchedule_OR, firstSchedule_S);
		}
		
		public void clickFirstAlertListOnRT() {
			elementToBeClickable(firstAlertList_OR, firstAlertList_S);
			clickElement(firstAlertList_OR, firstAlertList_S);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//Author:Abhishek kumar
		
		
		public int totalPatientInsidePatientListPage() {
			List<WebElement> li=driver.findElements(By.xpath("//td[contains(@id,'lbl_patient-list_td-patientName')"));
			int listOfPatientInTable=li.size();
			return listOfPatientInTable;
			
		}
		
		
		public int totalPatientInsideRecentTransmissionPage() {
			List<WebElement> li=driver.findElements(By.xpath("//td[contains(@id,'//td[contains(@id,'lbl_transmission-list_td-patient')]')"));
			int listOfPatientInTable=li.size();
			return listOfPatientInTable;
		}
		
		public void verifyListedDeviceDisplayed(String device) throws Exception {		
			
			//sendKeys(searchTextBox_OR, text);
			List<WebElement> rows = findElements(rtTable_OR);
			System.out.println("No.of rows are:"+ rows.size());
			String deviceName;
			String patientname;
			for (int i = 1; i <= rows.size(); i++) {
						
			deviceName = getText(By.xpath("//table[@id='lbl_transmission-list_td-device"+i+"']"));
			if (deviceName.contains(device)) {
			extentReport.reportPass(device + " are present");
			} else {
			extentReport.reportFail(device+" are not present");
			}
			}
		
	}
		
		public boolean patientsWithICM(By element, String strElement, String deviceName) throws Exception {
			Boolean isPatientHavingDevice = false;
			try {
				List<WebElement> deviceList = findElementslist(element, strElement);
				int devicesize = deviceList.size();
				if (devicesize > 0) {
					for (int i = 0; i <devicesize; i++) {
						if (deviceList.get(i).getText().contains(deviceName)) {
							System.out.println(deviceList.get(i).getText());
							isPatientHavingDevice = true;
						} else {
							extentReport.fail(deviceName + " is not found in  " + strElement);
						}
					}
				} else {
					extentReport.reportFail("Device size is :" + devicesize);
				}
			} catch (AssertionError e) {

				extentReport.reportFail("\"" + deviceName + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));

				throw e;
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + deviceName + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));
				throw new Exception(e.getMessage());
			}
			return isPatientHavingDevice;
		}
		//victor
		public boolean verifyPatientLocationisdisplayed(By element, String strElement, String location) throws Exception {
			Boolean isPatientLocationAvailable = false;
			try {
				List<WebElement> locationList = findElementslist(element, strElement);
				int locationListsize = locationList.size();
				if (locationListsize > 0) {
					for (int i = 0; i <locationListsize; i++) {
						if (locationList.get(i).getText().contains(location)) {
							System.out.println(locationList.get(i).getText());
							isPatientLocationAvailable = true;
						} else {
							extentReport.fail(location + " is not found in  " + strElement);
						}
					}
				} else {
					//extentReport.reportFail("Device size is :" + location);
				}
			} catch (AssertionError e) {

				extentReport.reportFail("\"" + location + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));

				throw e;
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + location + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));
				throw new Exception(e.getMessage());
			}
			return isPatientLocationAvailable;
		}
		
		public boolean VerifyParticularTextinWebElementList (By element, String strElement, String strExpValue)
		{
			boolean bFound = false;
			try {
				Thread.sleep(500);
				loading();
				visibilityOfElementLocatedWithoutReport(element, strElement);
				elementToBeClickable(element, strElement);
				List<WebElement> options = driver.findElements(element);
				int iListSize =  options.size();
				//String[] uiListItems = new String [iListSize];
				for (int i = 0; i< iListSize; i++) {
					uiListItems = options.get(i).getText().toString().trim();
					
					if (uiListItems.contains(strExpValue)) {
						bFound = true;
						break;
					}
					if (bFound == true) 
						extentReport.pass("Success - \"" + strExpValue + "\" is found in the value \"" +uiListItems + "\" in " + strElement);
					
				}
			
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + strExpValue + "\" is not found in the value \"" +uiListItems + "\" in "+ strElement, CommonUtils.convertStackTraceToString(e));
				throw new WebDriverException(e.getMessage());
			}
			return bFound;
		}

		
		public boolean patientsWithICD(By element, String strElement, String deviceName) throws Exception {
			Boolean isPatientHavingDevice = false;
			try {
				List<WebElement> deviceList = findElementslist(element, strElement);
				int devicesize = deviceList.size();
				if (devicesize > 0) {
					for (int i = 0; i <devicesize; i++) {
//						String text = deviceList.get(i).getText();
//						if(!(text.contains(deviceName)))
						if (!deviceList.get(i).getText().contains(deviceName)) {
							System.out.println(deviceList.get(i).getText());
							isPatientHavingDevice = true;
						} else {
							extentReport.fail( "ICD is not found in  " + strElement);
						}
					}
				} else {
					extentReport.reportFail("Device size is :" + devicesize);
				}
			} catch (AssertionError e) {

				extentReport.reportFail("\"" + deviceName + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));

				throw e;
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + deviceName + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));
				throw new Exception(e.getMessage());
			}
			return isPatientHavingDevice;
		}
		
		//victor
		public boolean alertwithTransmissionIsDisplayed(By element, String strElement) throws Exception {
			Boolean isAlertwithTransmissionsDisplayed = false;
			try {
				List<WebElement> alertList = findElementslist(element, strElement);
				int alertsList = alertList.size();
				if (alertsList > 0) {
					for (int i = 0; i <alertsList; i++) {
//						String text = deviceList.get(i).getText();
//						if(!(text.contains(deviceName)))
						if (!alertList.get(i).getText().contains(" ")) {
							System.out.println(alertList.get(i).getText());
							isAlertwithTransmissionsDisplayed = true;
						} else {
							extentReport.fail( "Alert with Transmission not found in  " + strElement);
						}
					}
				} else {
					//extentReport.reportFail("Device size is :" + devicesize);
				}
			} catch (AssertionError e) {

				extentReport.reportFail("\"" + "alerts" + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));

				throw e;
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + "alerts" + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));
				throw new Exception(e.getMessage());
			}
			return isAlertwithTransmissionsDisplayed;
		}
		
		
		public boolean verifySearchpatientisdisplayed(By element, String strElement, String patientname) throws Exception {
			
			Boolean isPatientNameDisplayed = false;
			try {
				List<WebElement> patientList = findElementslist(element, strElement);
				int patientsList = patientList.size();
				if (patientsList > 0) {
					for (int i = 0; i <patientsList; i++) {
//						String text = deviceList.get(i).getText();
//						if(!(text.contains(deviceName)))
						if (patientList.get(i).getText().contains(patientname)) {
							System.out.println(patientList.get(i).getText());
							isPatientNameDisplayed = true;
						} else {
							extentReport.fail( "Patient name is not found in  " + strElement);
						}
					}
				} else {
					//extentReport.reportFail("Device size is :" + patientname);
				}
			} catch (AssertionError e) {

				extentReport.reportFail("\"" + patientname + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));

				throw e;
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + patientname + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));
				throw new Exception(e.getMessage());
			}
			return isPatientNameDisplayed;
		}
		
		public boolean verifySearchDeviceisdisplayed(By element, String strElement, String Devicename) throws Exception {
			
			Boolean isDevicenameDisplayed = false;
			try {
				List<WebElement> deviceList = findElementslist(element, strElement);
				int devicesList = deviceList.size();
				if (devicesList > 0) {
					for (int i = 0; i <devicesList; i++) {
//						String text = deviceList.get(i).getText();
//						if(!(text.contains(deviceName)))
						if (deviceList.get(i).getText().contains(Devicename)) {
							System.out.println(deviceList.get(i).getText());
							isDevicenameDisplayed = true;
						} else {
							extentReport.fail( "Patient name is not found in  " + strElement);
						}
					}
				} else {
					//extentReport.reportFail("Device size is :" + patientname);
				}
			} catch (AssertionError e) {

				extentReport.reportFail("\"" + Devicename + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));

				throw e;
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + Devicename + "\" is not found in " + strElement,
						CommonUtils.convertStackTraceToString(e));
				throw new Exception(e.getMessage());
			}
			return isDevicenameDisplayed;
		}
		
		
		
		
		public boolean verifyFieldIsNotEmpty (By element, String strElement)
		{
			boolean bFound = false;
			try {
				loading();
				visibilityOfElementLocatedWithoutReport(element, strElement);
				elementToBeClickable(element, strElement);
				List<WebElement> options = driver.findElements(element);
				int iListSize =  options.size();
				//String[] uiListItems = new String [iListSize];
				for (int i = 0; i< iListSize; i++) {
					uiListItems = options.get(i).getText().toString().trim();
					if(!(uiListItems.isEmpty())){
						bFound = true;
						break;
					}
					if (bFound == true) 
						extentReport.pass("Success -Patients Having alerts");
				}
			
			} catch (Exception e) {
				extentReport.reportFail("Failure - Patients not having alerts", CommonUtils.convertStackTraceToString(e));
				throw new WebDriverException(e.getMessage());
			}
			return bFound;
		}
		
		public void selectDropdownForDeviceType(String option) {
			option=option.trim();
			elementToBeClickable(deviceTypeDropDown_OR, deviceTypeDropDown_S);
			loadingWithoutReport();
			clickElement(deviceTypeDropDown_OR, deviceTypeDropDown_S);	
			switch (option) {
			case "CRT-P":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "1")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "1")), deviceTypeDropDownOptions_S);	
				break;
			case "Cardiac Monitor(ICM)":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "2")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "2")), deviceTypeDropDownOptions_S);	
				break;
			case "DC":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "3")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "3")), deviceTypeDropDownOptions_S);
				break;
			case "DR":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "4")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "4")), deviceTypeDropDownOptions_S);
				break;
			case "HF":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "5")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "5")), deviceTypeDropDownOptions_S);
				break;
			case "PPD":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "6")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "6")), deviceTypeDropDownOptions_S);
				break;
			case "SC":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "7")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "7")), deviceTypeDropDownOptions_S);
				break;
			case "SR":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "8")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "8")), deviceTypeDropDownOptions_S);
				break;
			case "VR":
				elementToBeClickable(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "9")), deviceTypeDropDownOptions_S);
				clickElement(By.xpath(deviceTypeDropDownOptions_OR.replace("{0}", "9")), deviceTypeDropDownOptions_S);
				break;
			default:
				System.out.println("Not able to find the optionin dropdown");
			}

		}
		public boolean verifyPatientHavingICM(String deviceName) throws Exception {
			boolean patientsWithDevice = patientsWithICM(columnDeviceInGrid_OR,
					columnDeviceInGrid_S,deviceName );
			return patientsWithDevice;
		}
		
		public boolean verifyPatientsHavingICDPaceMaker(String deviceName) throws Exception {
			return patientsWithICD(columnDeviceInGrid_OR,
					columnDeviceInGrid_S,deviceName);
		}
		
		//victor
		public boolean verifyAlertwithTransmission() throws Exception {
			return alertwithTransmissionIsDisplayed(alertListGrid_OR,
					alertListInGrid_S);
		}
		
		public boolean verifyPatientNameisDisplayed(String patientname) throws Exception {
			
			return verifySearchpatientisdisplayed(patientName_OR,
					patientName_S,patientname);
		}
		public boolean verifyDeviceNameisDisplayed(String patientname) throws Exception {
			
			return verifySearchpatientisdisplayed(columnDeviceInGrid_OR,
					columnDeviceInGrid_S,patientname);
		}
		public boolean verifyPatientsHavingAlerts() {
			return verifyFieldIsNotEmpty(columnAlertListInGrid_OR,columnAlertListInGrid_S);

		}
		
		public boolean verifyDeviceName(String name) {
			return VerifyParticularTextinWebElementList(columnDeviceInGrid_OR, columnDeviceInGrid_S, name);

		}
		
		public boolean verifyDeviceType(String name) {
			return VerifyParticularTextinWebElementList(columnDeviceInGrid_OR, columnDeviceInGrid_S, name);

		}
		
		public boolean verifyLocation(String name) {
			return VerifyParticularTextinWebElementList(columnLocationInGrid_OR, columnLocationInGrid_S, name);

		}
		
		public boolean verifyPatientLocation(String location) throws Exception {
			return verifyPatientLocationisdisplayed(patientLocation_OR, patientLocation_S, location);

		}
		
		
			

		
		
		
		
		
		
		
		public void enterInputInSearchBox(String text) {
			elementToBeClickable(searchBoxInRecentTrans_OR, searchBoxInRecentTrans_S);
			driver.findElement(searchBoxInRecentTrans_OR).clear();
			sendKeys(searchBoxInRecentTrans_OR, text);
		}
		public boolean verifyPatientsName(String name) {
//			enterInputInSearchBox(name);
//			columnPatientInGrid_OR,, VerifyTextinWebElementList
			return VerifyParticularTextinWebElementList(columnPatientInGrid_OR, columnPatientInGrid_S, name);	
		}
		
		
		public boolean verifyPatientsNameOrID(String name) {
//			enterInputInSearchBox(name);
//			columnPatientInGrid_OR,, VerifyTextinWebElementList
			return VerifyParticularTextinWebElementList(columnPatientInGrid_OR, columnPatientInGrid_S, name);	
		}
		public boolean verifyTextInSearchBox(String name) {
			Boolean verifysearchvalue=false;
			String searchValue = driver.findElement(searchBoxInRecentTrans_OR).getText();
			System.out.println(searchValue);
			if(searchValue.equals(name)) {
				verifysearchvalue=true;
				extentReport.pass("Success - the previous searched word is displayed in the search box");
			} else {
				extentReport.fail("Failure - the previous searched word is not displayed in the search box");
			}
			return verifysearchvalue;

		}
		
		public boolean verifyTextInDeviceTypeFilter(String name) {
			Boolean verifysearchvalue=false;
			String searchValue = driver.findElement(filterForDeviceTypeRecentTrans_OR).getText();
			System.out.println(searchValue);
			if(searchValue.equals(name)) {
				verifysearchvalue=true;
				extentReport.pass("Success - the previous searched word is displayed in the search box");
			} else {
				extentReport.fail("Failure - the previous searched word is not displayed in the search box");
			}
			return verifysearchvalue;

		}
		
		public void selectLocationInLocationFilter() {
			clickElement(firstLocationFilter_OR, firstLocationFilter_S);

		}
		
		public String locationValue() {
			String searchValue = driver.findElement(filterForLocationRecentTrans_OR).getText();
			return searchValue;

		}
		public boolean verifyTextInLocationFilter(String name) {
			Boolean verifysearchvalue=false;
			String searchValue = driver.findElement(filterForLocationRecentTrans_OR).getText();
			System.out.println(searchValue);
			if(searchValue.equals(name)) {
				verifysearchvalue=true;
				extentReport.pass("Success - the previous searched word is displayed in the search box");
			} else {
				extentReport.fail("Failure - the previous searched word is not displayed in the search box");
			}
			return verifysearchvalue;

		}
		
		
		@Override
		public boolean verifyLandingPage() {
			Boolean verifyRecentTransmissionsPage = false;
			invisibilityOfElementLocatedWithoutReport(pageLoading_OR,pageLoading_S);
			if(isElementPresentwithoutException(quickLinks_OR,quickLinks_S) && isElementPresentwithoutException(moreActionBtn_OR,moreActionBtn_S)) {
				verifyRecentTransmissionsPage = true;
				extentReport.reportScreenShot("Recent Transmissions Page is displayed");
			} else {
				extentReport.reportScreenShot("Recent Transmissions Page is not displayed");
			}
			return verifyRecentTransmissionsPage;


		}
		
		//Author:Abhishek kumar
				private final String patientNameFrmRecentTrnmList_OR ="//td[contains(@id,'lbl_transmission-list_td-patient0')]/a/div/span[text()='{0}']";
				private final String patientNameFrmRecentTrnmList_S = "Patient Name in the List";
		
				private final By namefFirstPatientInTable_OR=By.xpath("//td[@id='lbl_transmission-list_td-patient0']/a");
				private final String namefFirstPatientInTable_S="FirstPatientName";
		
				
				
				//xpath for validating patient is belonging to medical team
				private final By medicalTeamMember_OR=By.xpath("(//div[@id='app-container']//div//p)[3]");
				private final String medicalTeamMember_S="Physcian notification";
		
		//Author:Abhishek kumar
				//This method is for validating whether a patient is active or released from the clinic
				public boolean verifyActiveAndReleasedPatientInRecentTransmissionPage(String patientName,String index){
					boolean flag=false;
					enterTier3FilterInputBx(patientName);
					if(isElementPresent(By.xpath(patientNameFrmRecentTrnmList_OR.replace("{0}",patientName).replace("{1}",index)),patientNameFrmRecentTrnmList_S)==true)
					{
					if(driver.findElement(By.xpath("//td[@id='lbl_transmission-list_td-alertsList1']")).getText()=="system'||'episodal")
						{
						extentReport.info("Patient enrolled is an active patient");
							return flag;
			        }
					else if(isElementPresent(By.xpath(patientNameFrmRecentTrnmList_OR.replace("{0}",patientName).replace("{1}",index)),patientNameFrmRecentTrnmList_S)==false)
					{
						extentReport.info("Patient enrolled is an Released patient");
						return flag;  
					}
						
						}
					return flag;
					}
				
				
				public boolean ValidateMedicalTeamMemberForPatient(String patientName) {
					boolean flag=false;
					enterTier3FilterInputBx(patientName);
					elementToBeClickable(By.xpath(patientNameFrmRecentTrnmList_OR.replace("{0}", patientName)), patientNameFrmList_S);
					clickElement(namefFirstPatientInTable_OR, namefFirstPatientInTable_S);
					if(getText(medicalTeamMember_OR).contains("The medical team is listed in order of notification. Implanting physicians are marked in blue.")==true) {
						return flag;
					}
							
					return flag;
					
					
				}
				
				
				
				
				
				
			
				//snehal
				private final By moreActionPrintOptn_OR= By.xpath("//button[@id='btn_transmission-list_markUnViewed']//span");
				private final String moreActionPrintOptn_S ="More Actions - Print Button";
				
				private final By printWindowHeader_OR = By.xpath("//app-print-table/div[@id='header']");
				private final String printWindowHeader_S = "Print Window header";
				
				private final By printWindowPrintBtn_OR = By.xpath("//app-print-table/div[@id='header']");
				private final String printWindowPrintBtn_S = "Print button on Print Window";
				
				
				//snehal
				public void clickOnMoreActionPrintBtn() {
					clickElement(moreActionPrintOptn_OR, moreActionPrintOptn_S);
					extentReport.reportScreenShot("Print window is opened");
				}
				
				public boolean verifyPrintWindow() {
					Boolean flag = false;
					
					if(visibilityOfElementLocatedWithReport(printWindowHeader_OR, printWindowHeader_S)) {
						flag = true;
					}
					
					return flag;
				}
				
				public void clickOnPrintBtnOnPrintWnndow() {
					clickElement(printWindowPrintBtn_OR, printWindowPrintBtn_S);
					extentReport.reportScreenShot("Clicked on Print button");
				}
				
				//snehal
				
			private final String patientNameInPrintReport_OR = "//div[@class='pdfViewer']//div/span[contains(text(),'$patientName')]";
			private final String patientNameInPrintReport_S = "Patient Name in Print Report";
			
			private final By countRowInPrintListReport_OR = By.xpath("//div[@id='print-section']//tbody/tr");
			private final String countRowInPrintListReport_S = "Count Rows in Print List Report";
			
			private final By printPdfWindow_OR = By.xpath("//pdf-viewer-pp[@id='viewer']");
			private final String printPdfWindow_S = "Print PDF window";
				
			public boolean verifyPatientNameInPrintReport(String patientName) {
				Boolean flag = false;
				switchToFrameViaNameOrId("ng2-pdfjs-viewer");
				if(visibilityOfElementLocatedWithReport(By.xpath(patientNameInPrintReport_OR.replace("$patientName", patientName)), patientNameInPrintReport_S)) {
					extentReport.reportScreenShot("Patient Name in print pdf report is verified");
				}
				
				return flag;
			}
			
			public boolean validatePatientDetailsOnPrintReport() {
				Boolean flag = false;
				int count = Integer.parseInt(captureTrnswithAlertCount());
				if((driver.findElements(countRowInPrintListReport_OR).size())==count) {
					flag = true;
					extentReport.reportScreenShot("Patient Details Window verified");
				}
								
				return flag;
			}
				
			public boolean verifyPrintPdfWindow() {
				Boolean flag = false;
				
				if(visibilityOfElementLocatedWithReport(printPdfWindow_OR, printPdfWindow_S)) {
					flag = true;
				}
				return flag;
			}
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				//Author:Kundan start here
				private final By  more_Action_Dowloadspreasheet_OR=By.xpath("//button[@id=\"btn_transmission-list_downloadSpreadsheet\"]/span");
				private final String more_action_Dowloadspreasheet_S="Recent Transmission more action button download spreadsheet option";
				
				private final By  more_Action_AddorRemovecolumn_OR=By.xpath("//button[@id=\"btn_transmission-list_addOrRemoveColumns\"]/span");
				private final String  more_action_addorRemovecolumn_S="Recent Transmission more action button Add or Remove column option";
				
				private final By  more_Action_Print_OR=By.xpath("//*[@id=\"btn_transmission-list_print\"]");
				private final String more_Action_Print_S="Recent Transmission more action button Print option";
				
				private final By more_Action_Export_Transmission_OR=By.xpath("//button[@id=\"btn_transmission-list_exportTransmission\"]");
				private final String more_Action_Export_Transmission_S="Recent Transmission more action button Export Transmission option";
				
				private final By  AddorRemovecolumn_Scehdule_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_0\"]/label/span");
				private final String AddorRemovecolumn_Scehdule_Checkbox_S="more action button AddorRemovecolumn Scehdule Checkbox";
				
				private final By  AddorRemovecolumn_Location_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_1\"]/label/span");
				private final String AddorRemovecolumn_Location_Checkbox_S="more action button AddorRemovecolumn Location Checkbox";
				
				private final By  AddorRemovecolumn_Device_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_2\"]/label/span");
				private final String AddorRemovecolumn_Device_Checkbox_S="more action button AddorRemovecolumn Device Checkbox";
				
				private final By  AddorRemovecolumn_Advsiory_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_3\"]/label/span");
				private final String AddorRemovecolumn_Advsiory_Checkbox_S="more action button AddorRemovecolumn Advsiory Checkbox";
			    
				private final By  AddorRemovecolumn_Alertslist_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_4\"]/label/span");
				private final String AddorRemovecolumn_Alertslist_Checkbox_S="more action button AddorRemovecolumn Alertslist Checkbox";
				
				private final By  AddorRemovecolumn_Latestcomments_Checkbox_OR=By.xpath("//mat-checkbox[@id=\"chb_column_name_preference_5\"]/label/span");
				private final String AddorRemovecolumn_Latestcomments_Checkbox_S="more action button AddorRemovecolumn Latest comments Checkbox";
				
				private final By  AddorRemovecolumn_Window_Done_OR=By.xpath("//button[@id=\"btn_column_name_done\"]/span");
				private final String AddorRemovecolumn_Window_Done_S="more action button AddorRemovecolumn window done";
				
				private final By Verify_Scehdule_Tablecolumn_OR=By.xpath("//th[@id=\"lbl_transmission-list_th-schedule\"]");
				private final String Verify_Scehdule_Tablecolumn_S="Scehdule table header column";
				
				private final By Verify_Location_Tablecolumn_OR=By.xpath("//th[@id=\"lbl_transmission-list_th-locations\"]");
				private final String Verify_Location_Tablecolumn_S="Location table header column";
				
				private final By Verify_Device_Tablecolumn_OR=By.xpath("//th[@id=\"lbl_transmission-list_th-device\"]");
				private final String Verify_Device_Tablecolumn_S="Device table header column";
				
				public final By advisoryTablecolumn_OR=By.xpath("//th[@id='lbl_transmission-list_th-deviceUnderAdvisory']");
				public final String advisoryTablecolumn_S="Device Under Advisory table header column";
				
				private final By Verify_Alertlist_Tablecolumn_OR=By.xpath("//th[@id=\"lbl_transmission-list_th-alertsList\"]");
				private final String Verify_Alertlist_Tablecolumn_S="Alertlist table header column";
				
				private final By Print_Window_Close_OR=By.xpath("//button[@id=\"btn_print-table_cancel\"]");
				private final String Print_Window_Close_S="Print window close button";
				
				private final By Export_Window_Cancel_OR=By.xpath("//div[@id=\"printable\"]/mat-dialog-actions/div/button[1]");
				private final String Export_Window_Cancel_S="Export window cancel button";
				
				
				private final By Export_Tranmission_window_OR=By.xpath("//div[@id=\"printable\"]/div[2]/h4");
				private final String Export_Tranmission_window_S="More action export transmission window";
				
				private final By direct_Call_window_OR=By.xpath("//h6[@id=\"lbl_send-direct-call_send_a_directcall\"]");
				private final String direct_Call_window_S="More action direct call window";
				
				private final By select_Patient_Checkbox_OR=By.xpath("//div[@id=\"mat-checkbox-54\"]/label/div");
				private final String select_Patient_Checkbox_S="Select patinet check box"; 
				
				private final By more_Action_Direct_Call_OR=By.xpath("//button[@id=\"btn_transmission-list_sendDirectCall\"]");
				private final String more_Action_Direct_Call_S="More action Direct call option"; 
				
				private final By directCall_CallClinic_Radio_Button_OR=By.xpath("//mat-radio-button[@id=\"dtl_send-direct-call_callClinic0\"]/label/div[1]/div[1]");
				private final String directCall_CallClinic_Radio_Button_S="Direct call call clinic radio button"; 
				
				private final By directCall_SendAgain_Radio_Button_OR=By.xpath("//mat-radio-button[@id=\"dtl_send-direct-call_sendAgain0\"]/label/div[1]/div[1]");
				private final String directCall_SendAgain_Radio_Button_S="Direct call Send Again radio button"; 
				
				private final By directCall_KeepNextAppointment_Radio_Button_OR=By.xpath("//mat-radio-button[@id=\"dtl_send-direct-call_keep-nsex-appointment0\"]/label/div[1]/div[1]");
				private final String directCall_KeepNextAppointment_Radio_Button_S="Direct call Keep Next Appointment radio button";
				
				private final By directCall_Nomessage_Radio_Button_OR=By.xpath("//mat-radio-button[@id=\"dtl_send-direct-call_noMessage0\"]/label/div[1]/div[1]");
				private final String directCall_Nomessage_Radio_Button_S="Direct call No Message radio button";
				
				private final By directCall_Cancel_Button_OR=By.xpath("//button[@id=\"dtl_send-direct-call_cancel\"]");
				private final String directCall_Cancel_Radio_Button_S="Direct call window cancel button";
				
				private final By directCall_Send_Button_OR=By.xpath("//button[@id=\"dtl_send-direct-call_send\"]");
				private final String directCall_Send_Radio_Button_S="Direct call window Send button";
				
				private final String downloadpath_S="C:\\Users\\kumarkx127\\Downloads";
			
				//Kundan
				public void navigatetoMoreActionsOption() throws Exception
				{
					waitForPageLoad();
					clickElement(moreActionBtn_OR, moreActionBtn_S);
					
				}
				
				public void verifySpreadhsheetDownloaded() throws Exception
				{
					//Assert.assertTrue(isFileDownloaded(downloadpath_S, "mailmerge.xls"), "Failed to download Expected document");
					
				}
				
				public void navigatetoDownloadSpreadhsheetOption() throws Exception
				{
					clickElement(more_Action_Dowloadspreasheet_OR, more_action_Dowloadspreasheet_S);
					waitForPageLoad();
				}
				
				public void navigatetoAddorRemovecoloumnoption() throws Exception
				{
					
					clickElement(more_Action_AddorRemovecolumn_OR, more_action_addorRemovecolumn_S);
				}
				
				public void selectandunselectcolumnoptions() throws Exception
				{

					/*boolean schdulecheckbox=isSelected(AddorRemovecolumn_Scehdule_Checkbox_OR);
					if(schdulecheckbox==true)
					{
						clickElement(AddorRemovecolumn_Scehdule_Checkbox_OR, AddorRemovecolumn_Scehdule_Checkbox_S);
					}
					else
					{
						System.out.println("Schdule check box should be unchecked");
					}*/
					clickElement(AddorRemovecolumn_Scehdule_Checkbox_OR, AddorRemovecolumn_Scehdule_Checkbox_S);
					clickElement(AddorRemovecolumn_Alertslist_Checkbox_OR, AddorRemovecolumn_Alertslist_Checkbox_S);
					clickElement(AddorRemovecolumn_Window_Done_OR, AddorRemovecolumn_Window_Done_S);
				}
				
				public void validateAddedorRemoveColumnHeader() throws Exception
				{
					
					
					 Boolean alertlist=isElementPresent(Verify_Alertlist_Tablecolumn_OR, Verify_Alertlist_Tablecolumn_S);
					 System.out.println("Alert list is present "+ alertlist);
					 Boolean scehdule=isElementPresent(Verify_Scehdule_Tablecolumn_OR);
					 System.out.println("Scehdule is present"+ scehdule);
					 waitForPageLoad();
					
				}
				
				public void navigatetoPrintOption() throws Exception
				{
					clickElement(more_Action_Print_OR);
					waitForPageLoad();
				}
				
				public void closePrintWindow() throws Exception
				{
					clickElement(Print_Window_Close_OR);
				}
				
				public void navigatetoExportTransMissionWindow() throws Exception
				{
					clickElement(more_Action_Export_Transmission_OR, more_Action_Export_Transmission_S);
					waitForPageLoad();
					
					
				}
				
				public void validateExportTransmissionWindow() throws Exception
				{
					Boolean exportwindow=isElementPresent(Export_Tranmission_window_OR,Export_Tranmission_window_S);
			        System.out.println(exportwindow);
			       clickElement(Export_Window_Cancel_OR);
					
				}
				
				public void selectpatientcheckbox() throws Exception
				{
					
					getAttribute(select_Patient_Checkbox_OR, select_Patient_Checkbox_S);
					//scrollToView(select_Patient_Checkbox_OR);
					clickElement(select_Patient_Checkbox_OR, select_Patient_Checkbox_S);
				}
				
				public void navigatetoDirectCallOption() throws Exception
				{
					clickElement(more_Action_Direct_Call_OR, more_Action_Direct_Call_S);
				}
				
				public void validateDirectCallWindow() throws Exception
				{
					Boolean directcallwindow=isElementPresent(direct_Call_window_OR, direct_Call_window_S);
					System.out.println(directcallwindow);	
				}
				
				public void verifyDirectcallRadioButtonNotEnabled() throws Exception
				{
					Boolean callclinic=isEnabled(directCall_CallClinic_Radio_Button_OR);
					System.out.println("Call clinic radio button is enabled" +callclinic);
					Boolean sendagain=isEnabled(directCall_SendAgain_Radio_Button_OR);
					System.out.println("Send again radion button is enabled" +sendagain);
					Boolean keepnxtappnt=isEnabled(directCall_KeepNextAppointment_Radio_Button_OR);
					System.out.println("Keep Next appointment is enabled "+keepnxtappnt);
					Boolean nomessage= isEnabled(directCall_Nomessage_Radio_Button_OR);
					System.out.println("No message radio button is enabled "+nomessage);
					clickElement(directCall_Cancel_Button_OR);
					
				}
				
				public void directcallEnableRadioButton() throws Exception
				{
					clickElement(directCall_CallClinic_Radio_Button_OR);
					clickElement(directCall_Send_Button_OR);
					
				}
				
				//Kundan End
				
		//shafiya added below method 21/02/2022
		//This method returns the filter options All, Clinic Patients for SP2 customer Type
		private final By tier1FilterDrpdownAllOptn_OR= By.xpath("(//div[@id='dd_transmission-list_RT_T1_Filter-panel']/mat-option)[2]");
		private final String tier1FilterDrpdownAllOptn_S ="All Option";
		public List<String> verifyDefaultTier1FilterOptions_Sp2() throws Exception{
			elementToBeClickable(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
			clickElement(tier1FilterDrpdown_OR, tier1FilterDrpdown_S);
			String option1 = getText(tier1FilterDrpdownAllOptn_OR, tier1FilterDrpdownAllOptn_S);
			String option2 = getText(tier1FilterDrpdownClinicPatientOptn_OR, tier1FilterDrpdownClinicPatientOptn_S);
			List<String> options_Sp2 = new ArrayList<String>();
			options_Sp2.add(option1);
			options_Sp2.add(option2);
			return options_Sp2;			
		}

}

