package com.test.qa.ui.pageObjects.ClinicianLogin;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;


public class PL_PatientEnrollment extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	Customer customer;

	public PL_PatientEnrollment(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}
	
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "Page loading symbol";
	private final By headerEnrollAPatient_OR = By.xpath("//div[@id='app-container']//app-patient-finder/header[1]/div");
	private final String headerEnrollAPatient_S = "Enroll A Patient header";
	private final By enrollNewPatientButton_OR = By.xpath("//app-patient-list[@id='btn_patient-list_navigateToNew']");
	private final String enrollNewPatientButton_S = "Enroll a New Patient button";
	private final By manualEnrollButton_OR = By.xpath("//p[contains(text(),'manual enrollment')]/../div/button");
	private final String manualEnrollButton_S = "Enroll patient manually button";
	private final By merlinNumberEnrollButton_OR = By.xpath("//*[@id='app-container']/app-patient-finder/mat-card[2]/div[2]/div/button/span");
	private final String merlinNumberEnrollButton_S = "Enroll patient by Merlin Number button";
	private final By merlinNumberTextBox_OR = By.xpath("//input[@id='merlin_textbox_enrollPatientByMerlinByNumber']");
	private final String merlinNumberTextBox_S = "Merlin Number TextBox";
	
	public void clickEnrollNewPatientButton() throws InterruptedException
	{
		presenceOfElementLocatedWithReport(enrollNewPatientButton_OR, enrollNewPatientButton_S);
		waitForLoading();
		//extentReport.reportScreenShot("Clicking Merlin Home Transmitter Link");
		clickElement(enrollNewPatientButton_OR);
		
	}
	
	public void clickManualEnrollButton() throws InterruptedException
	{
		presenceOfElementLocatedWithReport(manualEnrollButton_OR, manualEnrollButton_S);
		//extentReport.reportScreenShot("Clicking Merlin Home Transmitter Link");
		clickElement(manualEnrollButton_OR, manualEnrollButton_S);
		
	}
	
	public boolean verifyLandingPage() {
		Boolean patientEnrollPageCheck = false;
		if(visibilityOfElementLocatedWithoutReport(headerEnrollAPatient_OR,headerEnrollAPatient_S)) {
			patientEnrollPageCheck =true;
			invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
			extentReport.reportScreenShot("Patient Enrollment page is displayed");
		}
		return patientEnrollPageCheck;
	}
	
	public void enrollPatientByMerlinNetNumber(String merlinNumber) {
		sendKeys(merlinNumberTextBox_OR, merlinNumberTextBox_S, merlinNumber);
		clickElement(merlinNumberEnrollButton_OR, merlinNumberEnrollButton_S);
	}
	
	
	
}
