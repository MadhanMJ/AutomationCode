package com.test.qa.ui.pageObjects.ClinicianLogin;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;

import org.testng.Assert;

import java.sql.ResultSet;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static com.test.qa.utilities.CommonUtils.extentTest;

public class PL_PatientProfilePage extends BasePage {
	
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	DataBaseConnector dbConnector;
	
	/*
	 * Author: Dhaval Kothari
	 */
	public PL_PatientProfilePage(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
		testDataProvider = new TestDataProvider();
	}
	
	private final By pageLoading_OR = By.xpath("//*[@class='spinnerWrapper']");
	private final String pageLoading_S = "page loading symbol";
	private final By firstName_OR = By.xpath("//input[@id='merlin_textbox_firstName']");
	private final String firstName_S = "First Name Textbox";
	private final By lastName_OR = By.xpath("//input[@id='merlin_textbox_lastName']");
	private final String lastName_S = "Last Name Textbox";
	private final By middleName_OR = By.xpath("//input[@id='merlin_textbox_middleName']");
	private final String middleName_S = "Middle Name Textbox";
	private final By patientId_OR = By.xpath("//input[@id='merlin_textbox_patientNum']");
	private final String patientId_S = "Patient Id Textbox";
	private final By locationDropdown_OR = By.xpath("//span[@class='mat-select-placeholder ng-tns-c149-38 ng-star-inserted']");
	private final String locationDropdown_S = "Location Textbox";
	private final By editButton_OR = By.xpath("//button[@id='profileEditButton']");
	private final String editButton_S = "Edit Button";
	private final By saveButton_OR = By.xpath("//button[@id='profileSaveButton']");
	private final String saveButton_S = "Save Button";
	private final By cancelButton_OR = By.xpath("//button[@id='profileCancelButton']");
	private final String cancelButton_S = "Cancel Button";
	private final By pageTitle_OR = By.xpath("//div[@class='pageTitle']");
	private final String pageTitle_S = "Page Title";
	private final By deviceNameDropdown_OR = By.xpath("//span[text()='Search']");
	private final String deviceNameDropdown_S = "Device Name Dropdown";
	private final By patientProfileName_OR = By.xpath("//div[@class='headerName']");
	private final String patientProfileName_S = "Patient Name Header";
	
	//dummy xpath as d2 is not working
	private final String locationDrpdownOptions_OR= "";
	private final String locationDrpdownOptions_S ="Location Dropdown Options";
	private final String deviceDrpdownOptions_OR= "";
	private final String deviceDrpdownOptions_S ="Device Dropdown Options";
	private final String changeDeviceReasonRadio_OR= "//span[@class='device_change_span' and contains(text(),'{0}')]/preceding-sibling::input";
	private final String changeDeviceReasonRadio_S ="change device reason radio button";
	private final By locationValue_OR= By.xpath("//input[@id='clinicLocation']");
	private final String locationValue_S ="Location Value";
	private final By deviceValue_OR= By.xpath("//input[@id='deviceProductId']");
	private final String deviceValue_S ="Device Value";	
	private final By continueDeviceChangePopup_OR= By.xpath("//a[@id='continue']");
	private final String continueDeviceChangePopup_S ="Continue on device change popup";
	private final By cancleDeviceChangePopup_OR= By.xpath("//a[@id='cancle']");
	private final String cancleDeviceChangePopup_S ="Cancle on device change popup";
	
	
	
	@Override
	public boolean verifyLandingPage() {
		Boolean patientProfilePageCheck = false;
		if(isElementPresentwithoutException(pageTitle_OR,pageTitle_S)) {
			if(getText(pageTitle_OR, pageTitle_S).equals("Patient & Device Data"))
			{
			patientProfilePageCheck =true;
//			//Shafiya added this to wait for page loading
//			invisibilityOfElementLocatedWithoutReport(pageLoading_OR, pageLoading_S);
//			extentReport.reportScreenShot("Patient Profile page is displayed");
			}
		}
		return patientProfilePageCheck;
	}
	
	
	//Author :Dhaval
	public void clickEditButton() {
		elementToBeClickable(editButton_OR, editButton_S);
		clickElement(editButton_OR, editButton_S);
	}
	
	//Author :Dhaval
		public void enterFirstNameInputBx(String text) {
			elementToBeClickable(firstName_OR, firstName_S);
			sendKeys(firstName_OR, text);
		}
		
	//Author :Dhaval
		public void enterLastNameInputBx(String text) {
			elementToBeClickable(lastName_OR, lastName_S);
			sendKeys(lastName_OR, text);
		}
	//Author :Dhaval
	public void enterMiddleNameInputBx(String text) {
		elementToBeClickable(middleName_OR, middleName_S);
		sendKeys(middleName_OR, text);
	}	
	
	//Author :Dhaval
		public void enterPatientIdInputBx(String text) {
			elementToBeClickable(patientId_OR, patientId_S);
			sendKeys(patientId_OR, text);
		}
		
	//Author:Dhaval
		public void selectLocationFromDropdownOption(String option) {
		option=option.trim();
		elementToBeClickable(locationDropdown_OR, locationDropdown_S);
		clickElement(locationDropdown_OR, locationDropdown_S);
			elementToBeClickable(By.xpath(locationDrpdownOptions_OR.replace("{0}", option)), locationDrpdownOptions_S);
			clickElement(By.xpath(locationDrpdownOptions_OR.replace("{0}", option)), locationDrpdownOptions_S);
		}
		
	//Author :Dhaval
	public void clickSaveButton() {
		elementToBeClickable(saveButton_OR, saveButton_S);
		clickElement(saveButton_OR, saveButton_S);
	}	
	
	//Author :Dhaval
		public String verifyFirstName() {		
			visibilityOfElementLocatedWithReport(firstName_OR, firstName_S);
			return getText(firstName_OR, firstName_S);
		}
		
     //Author :Dhaval
		public String verifyMiddleName() {		
			visibilityOfElementLocatedWithReport(middleName_OR, middleName_S);
			return getText(middleName_OR, middleName_S);
		}
		
		 //Author :Dhaval
		public String verifyLastName() {		
			visibilityOfElementLocatedWithReport(lastName_OR, lastName_S);
			return getText(lastName_OR, lastName_S);
		}
		
		 //Author :Dhaval
		public String verifyPatientId() {		
			visibilityOfElementLocatedWithReport(patientId_OR, patientId_S);
			return getText(patientId_OR, patientId_S);
		}
		
		 //Author :Dhaval
		public String verifyLocation() {		
			visibilityOfElementLocatedWithReport(locationValue_OR, locationValue_S);
			return getText(locationValue_OR, locationValue_S);
		}
		
		//Author:Dhaval
			public void selectDeviceFromDropdownOption(String option) {
			option=option.trim();
			elementToBeClickable(deviceNameDropdown_OR, deviceNameDropdown_S);
			clickElement(deviceNameDropdown_OR, deviceNameDropdown_S);
				elementToBeClickable(By.xpath(deviceDrpdownOptions_OR.replace("{0}", option)), deviceDrpdownOptions_S);
				clickElement(By.xpath(deviceDrpdownOptions_OR.replace("{0}", option)), deviceDrpdownOptions_S);
			}
			
			 //Author :Dhaval
			public String verifyDevice() {		
				visibilityOfElementLocatedWithReport(deviceValue_OR, deviceValue_S);
				return getText(deviceValue_OR, deviceValue_S);
			}
			
			//Author:Dhaval
			public void selectRadioButtonDeviceChangePopup(String option) {
			option=option.trim();
				elementToBeClickable(By.xpath(changeDeviceReasonRadio_OR.replace("{0}", option)), changeDeviceReasonRadio_S);
				clickElement(By.xpath(changeDeviceReasonRadio_OR.replace("{0}", option)), changeDeviceReasonRadio_S);
			}
			
			//Author :Dhaval
			public void clickContinueButton() {
				elementToBeClickable(continueDeviceChangePopup_OR, continueDeviceChangePopup_S);
				clickElement(continueDeviceChangePopup_OR, continueDeviceChangePopup_S);
			}
			
			//Author :Dhaval
			public void clickCancleButton() {
				elementToBeClickable(cancleDeviceChangePopup_OR, cancleDeviceChangePopup_S);
				clickElement(cancleDeviceChangePopup_OR, cancleDeviceChangePopup_S);
			}
			
			//Author :Dhaval
			public boolean verifyDeviceChangePopupRdBtn(String option) {
				option=option.trim();
				return isSelectedWithoutReport(By.xpath(changeDeviceReasonRadio_OR.replace("{0}", option)), changeDeviceReasonRadio_S);
			}
			
			//Author :Dhaval
			public String verifyPatientName() {		
				visibilityOfElementLocatedWithReport(patientProfileName_OR, patientProfileName_S);
				return getText(patientProfileName_OR, patientProfileName_S);
			}


			// salin Gambhir
			private final By leftTransmitterLink_OR = By.xpath("//div[@id='app-container']/app-view-edit-patient-profile/div[2]/div[1]/div[3]");
			private final String leftTransmitterLink_S = "Transmitter Link from Patient Profile page";
			
			private final By leftFollowUpScheduleLink_OR = By.xpath("//div[@id='app-container']/app-view-edit-patient-profile/div[2]/div[1]/div[4]");
			private final String leftFollowUpScheduleLink_S = "Follow up Link";
			
			private final By disconnectedTransmitterMISTCheckBox_OR = By.xpath("//mat-checkbox[@formControlName='mistFlg']/label/div");
			private final String disconnectedTransmitterMISTCheckBox_S = "Disconnected Transmitter MIST check box";
			private final By disconnectedTransmitterMISTValue_OR = By.xpath("//mat-select[@formcontrolname='mistThreshold']//div/span"); // need to fix this once application is running fine
			private final String disconnectedTransmitterMISTValue_S = "Default value of MIST condition";
			private final By disconnectedTransmitterNODCCheckBox_OR = By.xpath("//mat-checkbox[@formControlName='nodcFlg']/label/div");
			private final String disconnectedTransmitterNODCCheckBox_S = "Disconnected Transmitter NODC check box";
			private final By disconnectedTransmitterNODCValue_OR = By.xpath("//xpath/of/number/of/days"); // need to fix this once application is running fine
			private final String disconnectedTransmitterNODCValue_S = "Default value of NODC condition";
			private final By episodesDiagnosticsCheckBox_OR = By.xpath("//mat-checkbox[@id='episodealDiagnosticsCheckbox']");
			private final String episodesDiagnosticsCheckBox_S = "Episodes Checkbox";
			private final By episodesDiagnostics_OR = By.xpath("//mat-checkbox[@id='episodealDiagnosticsCheckbox']/label/span");
			private final String episodesDiagnostics_S = "Episode Value";
			private final By diagnosticsCheckBox_OR = By.xpath("//mat-checkbox[@id='diagnoticsCheckbox'");
			private final String diagnosticsCheckBox_S = "Diagnostics Checkbox";
			private final By diagnostics_OR = By.xpath("//mat-checkbox[@id='diagnoticsCheckbox']/label/span");
			private final String diagnostics_S = "Diagnostics Value";
			private final By cardiacMonitorCheckBox_OR = By.xpath("xpath//for//checkbox");
			private final String cardiacMonitorCheckBox_S = "Cardiac Monitor checkbox";
			private final By topPatientProfileLink_OR = By.xpath("//div[@id='app-container']//mat-toolbar-row[@id='sub-header']/div/a[1]/span");
			private final String topPatientProfileLink_S = "Patient Profile Link";
			private final By topTransmissionsLink_OR = By.xpath("//div[@id='app-container']//mat-toolbar-row[@id='sub-header']/div/a[2]/span");
			private final String topTransmissionsLink_S = "Top Transmissions Link";
			private final By topAllTransmissionsLink_OR = By.xpath("//div[@id='app-container']//mat-toolbar-row[@id='sub-header']/div/a[3]/span");
			private final String topAllTransmissionsLink_S = "Tops All Transmission Link";
			private final By topClinincalCommentsLink_OR = By.xpath("//div[@id='app-container']//mat-toolbar-row[@id='sub-header']/div/a[5]/span");
			private final String topClinincalCommentsLink_S = "Top Clinical Comment Link";
			private final By topDirectTrendViewerLink_OR = By.xpath("//div[@id='app-container']//mat-toolbar-row[@id='sub-header']/div/a[4]/span");
			private final String topDirectTrendViewerLink_S = "Top Direct Trend Viewer";			

			public boolean verifyDisconnectedTransmitterThreshold(String deviceType, String expectedMISTDaysValue, String expectedNODCDaysValue) {
				// TODO Auto-generated method stub
				boolean checkDisconnectedTransmitterValue = false;
				
				String actualMISTDays = "";
				String actualNODCDays = "";
				
				try {
					switch (deviceType.toUpperCase()){
					case "NGQ":
						if (isSelectedWithReport(disconnectedTransmitterMISTCheckBox_OR, disconnectedTransmitterMISTCheckBox_S) && 
								isSelectedWithReport(disconnectedTransmitterNODCCheckBox_OR, disconnectedTransmitterNODCCheckBox_S))
						{
								actualMISTDays = getText(disconnectedTransmitterMISTValue_OR, disconnectedTransmitterMISTValue_S);
								actualNODCDays = getText(disconnectedTransmitterNODCValue_OR, disconnectedTransmitterNODCValue_S);
								if (actualMISTDays.equals(expectedMISTDaysValue) && (actualNODCDays.equalsIgnoreCase(expectedNODCDaysValue)))
									{
										extentReport.reportPass("MIST and NODC values matches correctly");
										checkDisconnectedTransmitterValue = true;
									}
								else
									extentReport.reportFail("Expected NODC and MIST values are not matching correctly");
							
						}
						else
							extentReport.reportFail("MIST and NODC checkbox is not selected");
						break;
					case "ICM":
						if (isSelectedWithReport(disconnectedTransmitterMISTCheckBox_OR, disconnectedTransmitterMISTCheckBox_S) && 
								isSelectedWithReport(disconnectedTransmitterNODCCheckBox_OR, disconnectedTransmitterNODCCheckBox_S))
						{
								actualMISTDays = getText(disconnectedTransmitterMISTValue_OR, disconnectedTransmitterMISTValue_S);
								actualNODCDays = getText(disconnectedTransmitterMISTValue_OR, disconnectedTransmitterMISTValue_S);
								if (actualMISTDays.equals(expectedMISTDaysValue) && (actualNODCDays.equalsIgnoreCase(expectedNODCDaysValue)))
									{
										extentReport.reportPass("MIST and NODC values matches correctly");
										checkDisconnectedTransmitterValue = true;
									}
								else
									extentReport.reportFail("Expected NODC and MIST values are not matching correctly");
							
						}
						else
							extentReport.reportFail("MIST and NODC checkbox is not selected");
						break;
						
						
					
					}
				}
				catch (Exception e)
				{
					e.printStackTrace();
					throw e;
				}
				
				
				return checkDisconnectedTransmitterValue;
			}

			public boolean verifyPatientDisconnectedTransmitterDBValues(int patient_id, int expectedMISTValue, int expectedNODCValue) throws Exception {
				// TODO Auto-generated method stub
				boolean checkDBVAlue = false;
				int actualMISTValue = 0, actualNODCValue = 0;
				
				try {
					dbConnector.getConnection();
					
					String query = "select bluetooth_mist_threshold, bluetooth_nodc_threshold from  patients.customer_application_patient cap where patient_id =" + patient_id + ";" ;
					
					ResultSet disconnectedTransmitterValue = dbConnector.executeQuery(query);
					
					while (disconnectedTransmitterValue.next()) {
						actualMISTValue = disconnectedTransmitterValue.getInt("bluetooth_mist_threshold");
						actualNODCValue = disconnectedTransmitterValue.getInt("bluetooth_nodc_threshold");
					}
					
					if (actualMISTValue == expectedMISTValue &&  actualNODCValue == expectedNODCValue)
					{
						extentReport.reportPass("DB values matches perfectly");
						checkDBVAlue = true;
					}
					else
						extentReport.reportPass("DB values dont match");
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
					throw e;
				}
				return checkDBVAlue;
			}

			public int getPatientID(String firstName) throws Exception {
				// TODO Auto-generated method stub
				int patient_id = 0;
				
				try {
					
				dbConnector.getConnection();
				
				String query = "select patient_id from  patients.patient cap where first_name = '" + firstName + "';" ;
				
				ResultSet patientRecord = dbConnector.executeQuery(query);
				
				while (patientRecord.next()) 
					patient_id = patientRecord.getInt("patient_id");
				}
				catch(Exception e)
				{
					e.printStackTrace();
					throw e;
				}
			
				return patient_id;
			}
			
			public void clickOnLeftPatientLink(String linkTobeClicked) {
				// TODO Auto-generated method stub
				switch(linkTobeClicked) {
				case "Transmitter" :
					elementToBeClickable(leftTransmitterLink_OR, leftTransmitterLink_S);
					clickElement(leftTransmitterLink_OR, leftTransmitterLink_S);
					break;
				case "Follow-Up Schedule":
					elementToBeClickable(leftFollowUpScheduleLink_OR, leftFollowUpScheduleLink_S);
					clickElement(leftFollowUpScheduleLink_OR, leftFollowUpScheduleLink_S);
					break;
				}
			}

			public boolean verifyFollowUPClear(String deviceSection) {
				// TODO Auto-generated method stub
				boolean checkFollowUp = false;
				
				try {
					switch (deviceSection.toUpperCase())
					{
					case "NGQ":
						boolean checkEpisode = false, checkDiagnostic = false;
						if (isSelectedWithReport(episodesDiagnosticsCheckBox_OR, episodesDiagnosticsCheckBox_S))
							checkEpisode = true;
						if (isSelectedWithReport(diagnosticsCheckBox_OR, diagnosticsCheckBox_S))
							checkDiagnostic= true;
						if (checkEpisode && checkDiagnostic)
							{
								extentReport.reportPass("Episode and Diagnostis checkbox are selected");
								checkFollowUp = true;
							}
						else 
							if(checkEpisode && checkDiagnostic== false) {
								extentReport.reportFail("Only Episode  checkbox is selected");
								}
						else if (checkEpisode == false && checkDiagnostic)
							extentReport.reportFail("Only Diagnostics Checkbox is selected");
						else 
							extentReport.reportFail("Niether episode nor Diagnostics is selected");
						
						break;
					case "ICM":
						if (isSelectedWithReport(cardiacMonitorCheckBox_OR, cardiacMonitorCheckBox_S))
						{
							extentReport.reportPass("Cardiac Monitor Check is avialable and selected");
							checkFollowUp = true;
						}
						break;
					}
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
					throw e;
				}
				return checkFollowUp;
			}
			public void changeDisconnectedThreshold(String changeValue) {
				// TODO Auto-generated method stub
				sendKeys(disconnectedTransmitterMISTValue_OR, disconnectedTransmitterMISTValue_S, changeValue);
												
					
				
			}


			public boolean verifyNavigationPageLinks() {
				// TODO Auto-generated method stub
				boolean checkNavigationLink = false;
				boolean patientProfileLink=false, transmissionLink=false, allTransmissionLink=false, directTrendViewer=false, clinicalComments = false;
				try {
					if (visibilityOfElementLocatedWithReport(topPatientProfileLink_OR, topPatientProfileLink_S))
						patientProfileLink = true;
							
					if (visibilityOfElementLocatedWithReport(topTransmissionsLink_OR, topTransmissionsLink_S))
						transmissionLink = true;
				
					if (visibilityOfElementLocatedWithReport(topAllTransmissionsLink_OR, topAllTransmissionsLink_S))
						allTransmissionLink = true;
					
					if (visibilityOfElementLocatedWithReport(topDirectTrendViewerLink_OR, topDirectTrendViewerLink_S))
						directTrendViewer = true; 
					
					if (visibilityOfElementLocatedWithReport(topDirectTrendViewerLink_OR, topDirectTrendViewerLink_S))
						clinicalComments = true;  
					
					if (patientProfileLink && transmissionLink && allTransmissionLink && directTrendViewer && clinicalComments)
					{
						checkNavigationLink = true;
						extentReport.reportPass("All Links are present");
					}
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				return checkNavigationLink;
			}
}
