package com.test.qa.ui.pageObjects.AlliedndPhyscianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class Weekly_Glance_Page extends BasePage
{
	/*
	 * AUTHOR: Kundan Kumar
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public Weekly_Glance_Page (WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	
	
	private final By weekly_Glance_Page_OR=By.xpath("//div[@id=\"TEST_IDENTIFICATION\"]/div/div/div/app-tools-weekly-glance/div[1]/div[1]");
	private final String weekly_Glance_Page_S="Weekly glance page";
	
	private final By weekly_Glance_default_Option_OR=By.xpath("//mat-select[@id=\"mat-select-6\"]/div/div[1]/span/span");
	private final String weekly_Glance_default_Option_S="Weekly glance current weeke default option";
	
	private final By weekly_Glance_drop_down_OR=By.xpath("//mat-select[@id=\"mat-select-6\"]/div/div[2]/div");
	private final String weekly_Glance_drop_down_S="Weekly glance drop down";
	
	private final By weekly_Glance_1st_week_Option_OR=By.xpath("//mat-option[@id=\"mat-option-26\"]");
	private final String weekly_Glance_1st_week_Option_S="Weekly glance 1st week past the current week option";
	
	private final By weekly_Glance_2nd_week_Option_OR=By.xpath("//mat-option[@id=\"mat-option-27\"]/span");
	private final String weekly_Glance_2nd_week_Option_S="Weekly glance 2nd week past the current week option";
	
	private final By weekly_Glance_3rd_week_Option_OR=By.xpath("//mat-option[@id=\"mat-option-28\"]/span");
	private final String weekly_Glance_3rd_week_Option_S="Weekly glance 3rd week past the current week option";
	
	
	
	public void verifyWeeklyGlancepagedisplayed() throws Exception
	{
		Boolean weeklyglancepage=isElementPresent(weekly_Glance_Page_OR);
		System.out.println("Weekly glance page is displayed "+weeklyglancepage);
	}
	
	public void verifyWeeklyGlanceDefaultOption() throws Exception
	{
		
		Boolean weekglancedeafult=isElementPresent(weekly_Glance_default_Option_OR, weekly_Glance_default_Option_S);
		System.out.println("Weekly glance default option is Current week "+weekglancedeafult);
	}
	
	public void verifyCurrentweekReport() throws Exception
	{
		//Need to write logic for how to verify report section
	}
	
	public void navigateToFirstWeekOption() throws Exception
	{
		clickElement(weekly_Glance_drop_down_OR, weekly_Glance_drop_down_S);
		clickElement(weekly_Glance_1st_week_Option_OR, weekly_Glance_1st_week_Option_S);
	}
	
	public void naviagteTo2WeekOption() throws Exception
	{
		clickElement(weekly_Glance_drop_down_OR, weekly_Glance_drop_down_S);
		clickElement(weekly_Glance_2nd_week_Option_OR, weekly_Glance_2nd_week_Option_S);
	}
	
	public void naviagteTo3WeekOption() throws Exception
	{
		clickElement(weekly_Glance_drop_down_OR, weekly_Glance_drop_down_S);
		clickElement(weekly_Glance_3rd_week_Option_OR, weekly_Glance_3rd_week_Option_S);
	}
	
	public void verify1stWeekReport() throws Exception
	{
		//Need to write code/logic for verify report
	}
	
	public void verify2ndWeeksReport() throws Exception
	{
		//Need to write code/logic for verify report
	}
	
	public void verify3rdWeeksReport() throws Exception
	{
		//Need to write code/logic for verify report
	}
	
	
	
	@Override
	public boolean verifyLandingPage() {
	Boolean clinicLocationsPageCheck = false;

	//if(isElementPresentwithoutException(tool_link_OR, tool_link_S)) {
	clinicLocationsPageCheck = true;

	

	return clinicLocationsPageCheck;
	}


}

