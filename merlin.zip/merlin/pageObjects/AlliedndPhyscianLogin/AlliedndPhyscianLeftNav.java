package com.test.qa.ui.pageObjects.AlliedndPhyscianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class AlliedndPhyscianLeftNav extends BasePage
{
	
	/*
	 * AUTHOR: Kundan Kumar
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public AlliedndPhyscianLeftNav (WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	
	//xpath changed
	private final By weekly_Glance_link_OR = By.xpath("//div[@id=\"TEST_IDENTIFICATION\"]/app-tools-sidebar-cmp/div/div[3]/ul/li[1]");
	private final String weekly_Glance_link_S = "Weekly Glance link";
	
	 
	
	public void navigateToWeeklyGlancePage() throws InterruptedException
	{
		presenceOfElementLocated(weekly_Glance_link_OR);
		clickElement(weekly_Glance_link_OR);
		//waitForLoading();
		extentReport.reportScreenShot("Clicked on weekly Glance page");
	}
	
	

	

	@Override
	public boolean verifyLandingPage() {
	Boolean clinicLocationsPageCheck = false;

	if(isElementPresentwithoutException(weekly_Glance_link_OR, weekly_Glance_link_S)) {
	clinicLocationsPageCheck = true;

	}

	return clinicLocationsPageCheck;
	}


}
