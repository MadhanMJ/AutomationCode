package com.test.qa.ui.pageObjects.AlliedndPhyscianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class My_Account_Page extends BasePage
{
	/*
	 * AUTHOR: Kundan Kumar
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;
	
	public My_Account_Page(WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	
	private final By manage_Account_Edit_Button_OR = By.xpath("//button[@id=\\\"myAccountEdit\\\"]/span");
	private final String manage_Account_Edit_Button_S = "Manage account edit button";

	private final By manage_Account_Edit_SaveButton_OR = By.xpath("//button[@id=\\\"myAccountSave\\\"]/span");
	private final String manage_Account_Edit_SaveButton_S = "Manage account edit save button";
	
	private final By manage_Account_Edit_CancelButton_OR = By.xpath("//button[@id=\\\"myAccountCancel\\\"]/span");
	private final String manage_Account_Edit_CancelButton_S = "Manage account edit Cancel button";
	
	private final By recentTrasmission_Prefrence_Column_OR = By.xpath("//div[@id=\"my-account\"]/div[3]/div[1]/div/div/h3");
	private final String RecentTrasmission_Prefrence_Column_S = "Manage account recent transmisson perefrence column";
	
	private final By application_Prefrence_Column_OR = By.xpath("//div[@id=\"my-account\"]/div[3]/div[2]/div/div/h3");
	private final String application_Prefrence_Column_S = "Manage account application perefrence column";
	
	private final By recTras_Pref_DirectAlert_Label_OR = By.xpath("//mat-radio-button[@id=\"AL\"]/label/div[2]");
	private final String recTras_Pref_DirectAlert_Label_S = "Recent transmisson perefrence column Direct Alert label";
	
	private final By recTras_Pref_DirectAlert_Checkbox_OR = By.xpath("//mat-radio-button[@id=\"AL\"]/label/div[1]/div[2]");
	private final String recTras_Pref_DirectAlert_Checkbox_S = "Recent transmisson perefrence column Direct Alert check box";
	
	private final By recTras_Pref_ClinicLocation_Label_OR = By.xpath("//mat-radio-button[@id=\"CL\"]/label/div[2]");
	private final String recTras_Pref_ClinicLocation_Label_S  = "Recent transmisson perefrence column Clinic Location label";
	
	private final By recTras_Pref_ClinicLocation_Checkbox_OR = By.xpath("//mat-radio-button[@id=\"CL\"]/label/div[1]/div[1]");
	private final String recTras_Pref_ClinicLocation_Checkbox_S  = "Recent transmisson perefrence column Clinic Location Checkbox";
	
	private final By recTras_Pref_PtName_Label_OR = By.xpath("//mat-radio-button[@id=\"PN\"]/label/div[2]");
	private final String recTras_Pref_PtName_Label_S  = "Recent transmisson perefrence column patient name label";
	
	private final By recTras_Pref_PtName_Checkboxl_OR = By.xpath("//mat-radio-button[@id=\"PN\"]/label/div[1]/div[1]");
	private final String recTras_Pref_PtName_Checkbox_S  = "Recent transmisson perefrence column patient name Checkbox";
	
	private final By recTras_Pref_TransDatendTime_Label_OR = By.xpath("//mat-radio-button[@id=\"TD\"]/label/div[2]");
	private final String recTras_Pref_TransDatendTime_Label_S  = "Recent transmisson perefrence column transmission date and time label";
	
	private final By recTras_Pref_TransDatendTime_Checkbox__OR = By.xpath("//mat-radio-button[@id=\"TD\"]/label/div[1]/div[2]");
	private final String recTras_Pref_TransDatendTime_Checkbox__S  = "Recent transmisson perefrence column transmission date and time Checkbox";
	
	private final By save_Success_Message_OR=By.xpath("//div[contains(@aria-label,'Success')]");
	private final String save_Success_Message_S="Manage account save action success message prompt";
	
	private final By app_Prefrence_HF_Checkbox_OR=By.xpath("//mat-radio-button[@id=\"HF\"]/label/div[1]/div[1]");
	private final String app_Prefrence_HF_Checkbox_S="APPLICATION PREFERENCES heart failure check box option";
	
	private final By app_Prefrence_EP_Checkbox_OR=By.xpath("//mat-radio-button[@id=\"EP\"]/label/div[1]/div[1]");
	private final String app_Prefrence_EP_Checkbox_S="APPLICATION PREFERENCES Electrophysiology check box option";
	
	private final By changePassword_link_OR=By.xpath("//button[@id='btn_my-account_change-password']");
	private final String   changePassword_link_S = "Change-password";
	
	private final By changePassword_Header_OR=By.xpath("//div[@id='page-title2']");
	private final String   changePassword_Header_S = "Change-Password header";
	
	private final By changePassword_CurrentPassword_OR=By.xpath("//input[@id=\"oldPassword\"]");
	private final String   changePassword_CurrentPassword_S = "Current Password input box";
	
	private final By changePassword_NewPassword_OR=By.xpath("//input[@id=\"newPassword\"]");
	private final String   changePassword_NewPassword_S = "New Password input box";
	
	private final By changePassword_ReConfirmPassword_OR=By.xpath("//input[@id=\"reenterPassword\"]");
	private final String   changePassword_ReConfirmPassword_S = "Confirm Password input box";
	
	private final By Success_Message_OR = By.xpath("//div[contains(text(),' Main phone number' )]");
	private final String   Success_Message_S = "Updated My Account!!";
	
	public void verifyMyAccountPageinDisplayMode()
	{
	Boolean editbutton=isElementPresent(manage_Account_Edit_Button_OR, manage_Account_Edit_Button_S);
	System.out.println(editbutton);
	}
	
	public void navigateToEditManageAccount()
	{
		clickElement(manage_Account_Edit_Button_OR, manage_Account_Edit_Button_S);
	}
	
	public void verifyRecentTrasmissionPrefrenceColumn()
	{
		Boolean recenttranscolumnheader=isElementPresent(recentTrasmission_Prefrence_Column_OR, RecentTrasmission_Prefrence_Column_S);
		System.out.println(recenttranscolumnheader);
	}
	
	public void verifyApplicationPrefrenceColumn()
	{
		Boolean applicationprefrence=isElementPresent(application_Prefrence_Column_OR, application_Prefrence_Column_S);
		System.out.println(applicationprefrence);
	}
	
	public void verifyDirectAlertCheckBoxIsselctedDefualt()
	{
	    Boolean directalertlabel=isElementPresent(recTras_Pref_DirectAlert_Label_OR, recTras_Pref_DirectAlert_Label_S);
	    System.out.println("Direct alert label is present"+ directalertlabel);
		Boolean defaultdirectalert=isSelected(recTras_Pref_DirectAlert_Checkbox_OR);
		System.out.println("Default alert check box is selected default"+ defaultdirectalert);
	}
	
	public void selectPatientListCheckBox()
	{
		Boolean ptnamelabel=isElementPresent(recTras_Pref_PtName_Label_OR, recTras_Pref_PtName_Label_S);
		System.out.println("Patient name label is present "+ptnamelabel);
		clickElement(recTras_Pref_PtName_Checkboxl_OR, recTras_Pref_PtName_Checkbox_S);
		clickElement(manage_Account_Edit_SaveButton_OR, manage_Account_Edit_SaveButton_S);
		waitForPageLoad();
	}
	
	public  void VerifySuccessMessage() 
	{ 
		try 
		{
		
		String actual;
		actual = getText(Success_Message_OR);
		System.out.print(actual);
		if(actual.equals(Success_Message_S))
		{
			extentReport.pass(" Successful message displayed");
			extentReport.reportScreenShot("Successful message displayed");
		}
		else {
			extentReport.fail(" Successful message displayed ");
			extentReport.reportScreenShot( " Successful message not displayed ");
		}
		}
		catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}
	
	public void selectClinicLocationCheckBox()
	{
		Boolean cliniclocation=isElementPresent(recTras_Pref_ClinicLocation_Label_OR, recTras_Pref_ClinicLocation_Label_S);
		System.out.println("Patient name label is present "+cliniclocation);
		clickElement(recTras_Pref_ClinicLocation_Checkbox_OR, recTras_Pref_ClinicLocation_Checkbox_S);
		clickElement(manage_Account_Edit_SaveButton_OR, manage_Account_Edit_SaveButton_S);
		waitForPageLoad();
	}
	
	public void selectTransmissionDataCheckBox()
	{
		Boolean transdateandtime=isElementPresent(recTras_Pref_TransDatendTime_Label_OR, recTras_Pref_TransDatendTime_Label_S);
		System.out.println("Patient name label is present "+transdateandtime);
		clickElement(recTras_Pref_TransDatendTime_Checkbox__OR, recTras_Pref_TransDatendTime_Checkbox__S);
		clickElement(manage_Account_Edit_SaveButton_OR, manage_Account_Edit_SaveButton_S);
		waitForPageLoad();
	}
	
	public void selectHeartFailureCheckBox()
	{
		clickElement(app_Prefrence_HF_Checkbox_OR, app_Prefrence_HF_Checkbox_S);
		clickElement(manage_Account_Edit_SaveButton_OR, manage_Account_Edit_SaveButton_S);
		waitForPageLoad();
	}
	
	public void selectElectrophysiologyCheckBox()
	{
		clickElement(app_Prefrence_EP_Checkbox_OR, app_Prefrence_EP_Checkbox_S);
		clickElement(manage_Account_Edit_SaveButton_OR, manage_Account_Edit_SaveButton_S);
		waitForPageLoad();
	}
	
	public  void clickOnChangePassword() throws Exception
	{ 
		try 
		{
			scrollToView(changePassword_link_OR);
			presenceOfElementLocated(changePassword_link_OR);
			clickElement(changePassword_link_OR);
			extentReport.reportScreenShot( "User clicked on change password in customer profile Page");
			
			
		}
		catch(Exception e)
		{
			extentReport.fail( "User not able to click on change password in customer profile Page ");
		}
		
	}
	
	public  void changePassword(String currPassword,String password, String confirmPassword) throws Exception
	{ 
		try 
		{                                                                                                      
			scrollToView(changePassword_CurrentPassword_OR);
			deleteContent(changePassword_CurrentPassword_OR);
			sendKeys(changePassword_CurrentPassword_OR,currPassword);
			sendKeys(changePassword_NewPassword_OR,password);
			sendKeys(changePassword_ReConfirmPassword_OR,confirmPassword);
			driver.findElement(changePassword_ReConfirmPassword_OR).sendKeys(Keys.ENTER);
			extentReport.pass( " User able to change password ");
			extentReport.pass( " User able to change password ");
		}
		catch(Exception e)
		{
			extentReport.fail( " User not able to change password ");
		}
		return ;
	}
	
	public void verifyChangePassword_Page()
	{
		Boolean changepasswordpage=isElementPresent(changePassword_Header_OR, changePassword_Header_S);
		extentReport.pass("Change password loaded "+ changepasswordpage);
		
	}
	@Override
	public boolean verifyLandingPage() {
	Boolean clinicLocationsPageCheck = false;

	//if(isElementPresentwithoutException(weekly_Glance_link_OR, weekly_Glance_link_S)) 
	{
	clinicLocationsPageCheck = true;

	}

	return clinicLocationsPageCheck;
	}


}

