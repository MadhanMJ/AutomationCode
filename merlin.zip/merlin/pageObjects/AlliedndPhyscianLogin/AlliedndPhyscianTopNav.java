package com.test.qa.ui.pageObjects.AlliedndPhyscianLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.BasePage;

public class AlliedndPhyscianTopNav extends BasePage
{
	/*
	 * AUTHOR: Kundan Kumar
	 */

	// Below three references needs to be there and webelements as per pages
	public WebDriver driver;
	public ExtentReport extentReport;
	ExtentTest extentTest;

	public AlliedndPhyscianTopNav (WebDriver driver, ExtentReport extentReport) {
		super(driver,extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}
	
	private final By tool_link_OR = By.xpath("//div[@id=\"shell-wrapper\"]/merlin-menu/mat-toolbar/mat-toolbar-row/div/ul/li[3]/a/span");
	private final String tool_link_S = "Tool Link";
	
	private final By signed_In_User_Link_OR=By.xpath("//div[@id=\"shell-wrapper\"]/mat-toolbar/mat-toolbar-row/div[2]/div/div[1]/a/span/span[1]");
	private final String signed_In_User_Link_S="Signed in as user link";
	
	private final By signed_Out_Link_OR=By.xpath("//div[@id=\"shell-wrapper\"]/mat-toolbar/mat-toolbar-row/div[2]/div/div[1]/a/span/span[3]");
	private final String signed_Out_Link_S="Signed out link";
	
	
	
	public void navigateToToolPage() throws InterruptedException
	{
		presenceOfElementLocated(tool_link_OR);
		clickElement(tool_link_OR);
		//waitForLoading();
		extentReport.reportScreenShot("Clicked tool Link");
	}
	
	public void navigateToManageAccountPage()
	{
		clickElement(signed_In_User_Link_OR, signed_In_User_Link_S);
		waitForPageLoad();
	}
	
	public void clickSignoutLink()
	{
		clickElement(signed_Out_Link_OR, signed_Out_Link_S);
		waitForPageLoad();
	}
	
	

	@Override
	public boolean verifyLandingPage() {
	Boolean clinicLocationsPageCheck = false;

	if(isElementPresentwithoutException(tool_link_OR, tool_link_S)) {
	clinicLocationsPageCheck = true;

	}

	return clinicLocationsPageCheck;
	}


}
