package com.test.qa.extentReport;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
 
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import org.openqa.selenium.WebDriver;
import org.testng.asserts.IAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.test.qa.logger.Log;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;

public class ExtentReport  {

	public ExtentReport(WebDriver driver, ExtentReport extentReport) { 
		//super(driver,extentReport);
	}

	public static ExtentReports extent = new ExtentReports();
	public static ExtentTest test, node;
	public static String timestamp = "";
	public static Path currentRelativePath = Paths.get("");
	private static Map<Object, String> map = new HashMap<Object, String>();
	private static String ipAddress = null;
	private static Map<Object, String> sysprop;
	private static String browserType = CommonUtils.loadFromPropertyFile().getProperty("BROWSER");
	private static String environmentInfo = CommonUtils.loadFromPropertyFile().getProperty("URL");
	private static String buildInfo = CommonUtils.loadFromPropertyFile().getProperty("BUILDINFO");
	public final static String reportPath = CommonUtils.loadFromPropertyFile().getProperty("REPORT_PATH");
	public static String ExtentReportFolder = reportPath;
	public static Log logger = new Log();
	private String screenshotName=null;

	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
		System.setProperty("timestamp", dateFormat.format(new Date()));
	}
	public String path(String path)
	{
		int size=path.length();
		if(size>50)
		{
			path=path.substring(0, 50);
		}
		
		return path;
		
	}
	public static void startReport() {
		String ReportName = "AutomationReport";
		sysprop = getSystemProperties();
		timestamp = CommonUtils.timestamp();
		File file = new File(ExtentReportFolder+File.separator + CommonUtils.currentTimeStamp);
		
		file.mkdir();
		extent.setSystemInfo("OS : ", sysprop.get("os.name"));
		extent.setSystemInfo("Java Version : ", sysprop.get("java.version"));
		extent.setSystemInfo("User Name : ", sysprop.get("user.name"));
		extent.setSystemInfo("Machine : ", sysprop.get("machine.name"));
		extent.setSystemInfo("IP Address : ", sysprop.get("machine.address"));
		extent.setSystemInfo("Browser : ", browserType);
		extent.setSystemInfo("Build Info : ", buildInfo);
		extent.setSystemInfo("Environment   : ", environmentInfo);
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(file+ File.separator + ReportName + "_" + timestamp + ".html");
		htmlReporter.config().setDocumentTitle("Merlin Automation Report");
		htmlReporter.config().setReportName("Automation Report");
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
		htmlReporter.config().setEncoding("utf-8");
		String css = ".r-img {width: 100px;}";
		htmlReporter.config().setCSS(css);
		extent.attachReporter(htmlReporter);
	}

	public static Map<Object, String> getSystemProperties() {
		Properties properties = System.getProperties();

		Set sysPropertiesKeys = properties.keySet();
		for (Object key : sysPropertiesKeys) {
			map.put(key, properties.getProperty((String) key));
		}

		try {
			ipAddress = InetAddress.getLocalHost().toString();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		map.put("machine.name", ipAddress.split("/")[0]);
		map.put("machine.address", ipAddress.split("/")[1]);

		return map;
	}

	public ExtentTest initiateTest(String testName) {
		test = ExtentReport.extent.createTest(testName);
		return test;
	}

	
	public String screenshotwithdateandtime(String path) {
		
        try {
        	Robot robotClassObject = new Robot();
			Rectangle screenSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			BufferedImage tmp = robotClassObject.createScreenCapture(screenSize); 
            ImageIO.write(tmp, "jpg",new File(path)); 
           }  catch(Exception e) {
        	   logger.error(CommonUtils.convertStackTraceToString(e));
        	e.printStackTrace();
        }
        return path;
    }
	
	public ExtentTest reportInfo(String msg) {
		
		 String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "")+"_"+CommonUtils.timestampss();
		 String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
		 String folderCreate=ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName ;
			File folder = new File(folderCreate );
			if(!folder.exists())
			{
				folder.mkdir();
			}
		try {
			String path1 = screenshotwithdateandtime(path);
			//CommonUtils.takeSnapShot(driver, path);

			String path2 = path1.replace(ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+ File.separator, "./");

			//node = test.createNode(msg);
			node.info(msg, MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
			logger.info(msg);
			
		} catch (Exception e) {
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
		}
		return node;
	}
	public ExtentTest reportPass(String msg) {
		
		String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "")+"_"+CommonUtils.timestampss();
		 String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
		 String folderCreate=ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName ;
			File folder = new File(folderCreate );
			if(!folder.exists())
			{
				folder.mkdir();
			}
		try {

			String path1 = screenshotwithdateandtime(path);
        	//CommonUtils.takeSnapShot(driver, path);
			String path2 = path1.replace(ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+ File.separator, "./");
			//node = test.createNode(msg);
			node.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
			logger.info(msg);
		} catch (Exception e) {
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
		}
		return node;
	}
	
	public ExtentTest reportFail(String msg) {
		
		 String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "")+"_"+CommonUtils.timestampss();
		 String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
		 String folderCreate=ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName ;
			File folder = new File(folderCreate );
			if(!folder.exists())
			{
				folder.mkdir();
			}
		try {
			String path1 = screenshotwithdateandtime(path);
			//CommonUtils.takeSnapShot(driver, path);
           String path2 = path1.replace(ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+ File.separator, "./");
           //node = test.createNode(msg);
           
		   node= node.fail(msg, MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
			logger.error(msg);
			
		} catch (Exception e) {
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
		}
		return node;
	}
	
	
	
	    public  void takeFullSnapShot(WebDriver webdriver, String Message) throws Exception {
	    	try {
	    	
	    	//String path = ExtentReportFolder+File.separator + message +".jpg";
	    	 String message = path(Message).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "")+"_"+CommonUtils.timestampss();
			 String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
			 String folderCreate=ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName ;
				File folder = new File(folderCreate );
				if(!folder.exists())
				{
					folder.mkdir();
				}
	    	//String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
				String path1 = screenshotwithdateandtime(path);
	    	Screenshot fpScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(webdriver);
	    	ImageIO.write(fpScreenshot.getImage(),"jpg",new File(path));
	    	String path2 = path1.replace(ExtentReportFolder+ File.separator+CommonUtils.currentTimeStamp+ File.separator ,"./");
	    	   node.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
				logger.info(message);
	    	}
	    	
              catch(Exception e) {
            	  logger.error(CommonUtils.convertStackTraceToString(e));
            	  e.printStackTrace();
	        }
	    }
	    
	
	  

	
	
	//carmel
		public ExtentTest reportFail(String msg, String strException) {
			
			 String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "")+"_"+CommonUtils.timestampss();
			 String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
			 String folderCreate=ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName ;
				File folder = new File(folderCreate );
				if(!folder.exists())
				{
					folder.mkdir();
				}
			try {
				String path1 = screenshotwithdateandtime(path);
				//CommonUtils.takeSnapShot(driver, path);
				String path2 =path1.replace(ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+ File.separator, "./");
				//node = test.createNode(msg);
			    node.fail(msg, MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
				logger.error(msg);
				logger.error(strException);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(CommonUtils.convertStackTraceToString(e));
			}
			return node;
		}
	
	public void reportScreenShot(String msg) {
		
		 String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]", "")+"_"+CommonUtils.timestampss();
		 String path = ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName  + File.separator + message + ".jpg";
		 String folderCreate=ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName ;
		logger.info("path:"+path);	
		 File folder = new File(folderCreate );
			if(!folder.exists())
			{
				folder.mkdir();
			}
		try {
			String path1 = screenshotwithdateandtime(path);
			logger.info("path1:"+path1);	
			//CommonUtils.takeSnapShot(driver, path);
            String path2 = path1.replace(ExtentReportFolder +File.separator+ CommonUtils.currentTimeStamp+ File.separator, "./");
			logger.info("path2:"+path2);	
			node.info(msg, MediaEntityBuilder.createScreenCaptureFromPath(path2).build());

			logger.info(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ExtentTest info(String msg, String[]... requirementIDs) {
		try {
			node = test.createNode(msg);
			for(String[] requirementID:requirementIDs) {
				node.assignCategory(requirementID);
			}
			logger.info(msg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return node;
	}
	
	public ExtentTest pass(String msg) {
		try {
		//	node = test.createNode(msg);
			
			node.pass(msg);
			logger.info(msg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return node;
	}

	public ExtentTest fail(String msg) {
		try {
			//node = test.createNode(msg);
			
			node.fail(msg);
			logger.info(msg);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return node;
	}

	public void generateTestReport() {
		extent.flush();
		
	}
	
	/*
	 * //mohan public ExtentTest reportFail1(String msg) {
	 * 
	 * String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]",
	 * "")+"_"+CommonUtils.timestampss(); String path = ExtentReportFolder
	 * +File.separator+ CommonUtils.currentTimeStamp+File.separator
	 * +CommonUtils.currentTestCaseName + File.separator + message + ".jpg"; String
	 * folderCreate=ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName
	 * ; File folder = new File(folderCreate ); if(!folder.exists()) {
	 * folder.mkdir(); } try { String path1 = screenshotwithdateandtime(path);
	 * //CommonUtils.takeSnapShot(driver, path);
	 * 
	 * String path2 = path1.replace(ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+ File.separator, "./");
	 * 
	 * node = test.createNode(msg); node.fail(msg,
	 * MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
	 * logger.error(msg);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } return node; } public void
	 * reporttakeSnapShot(WebDriver webdriver, String Message) throws Exception {
	 * try {
	 * 
	 * //String path = ExtentReportFolder+File.separator + message +".jpg"; String
	 * message = path(Message).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]",
	 * "")+"_"+CommonUtils.timestampss(); String path = ExtentReportFolder
	 * +File.separator+ CommonUtils.currentTimeStamp+File.separator
	 * +CommonUtils.currentTestCaseName + File.separator + message + ".jpg"; String
	 * folderCreate=ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName
	 * ; File folder = new File(folderCreate ); if(!folder.exists()) {
	 * folder.mkdir(); } //String path = ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName
	 * + File.separator + message + ".jpg";
	 * 
	 * Screenshot fpScreenshot = new
	 * AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).
	 * takeScreenshot(webdriver);
	 * 
	 * ImageIO.write(fpScreenshot.getImage(),"jpg",new File(path)); path =
	 * path.replace(ExtentReportFolder+ File.separator+CommonUtils.currentTimeStamp+
	 * File.separator, "./");
	 * 
	 * //path = path.replace(ExtentReportFolder+ File.separator, "./"); // node =
	 * test.createNode(Message); node.pass(message,
	 * MediaEntityBuilder.createScreenCaptureFromPath(path).build());
	 * logger.info(message); }
	 * 
	 * catch(Exception e) { e.printStackTrace(); } } public String
	 * takeScreenShot(String Message) { //String path ="";
	 * 
	 * String message = path(Message).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]",
	 * "")+"_"+CommonUtils.timestampss(); String path = ExtentReportFolder
	 * +File.separator+ CommonUtils.currentTimeStamp+File.separator
	 * +CommonUtils.currentTestCaseName + File.separator + message + ".jpg"; String
	 * folderCreate=ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName
	 * ; File folder = new File(folderCreate ); if(!folder.exists()) {
	 * folder.mkdir(); } try { Robot robotClassObject = new Robot(); Rectangle
	 * screenSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
	 * BufferedImage tmp = robotClassObject.createScreenCapture(screenSize);
	 * ImageIO.write(tmp, "jpg",new File(path));
	 * 
	 * 
	 * path = path.replace(ExtentReportFolder+ File.separator, "./"); //node =
	 * test.createNode(Message); // node = test.createNode(Message);
	 * node.pass(Message,
	 * MediaEntityBuilder.createScreenCaptureFromPath(path).build());
	 * logger.info(Message);
	 * 
	 * }
	 * 
	 * catch(Exception e) { e.printStackTrace(); } return path; }
	 * 
	 * public String takeScreenShotWithDateTime(String Message) { //String path ="";
	 * 
	 * String message = path(Message).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]",
	 * "")+"_"+CommonUtils.timestampss(); String path = ExtentReportFolder
	 * +File.separator+ CommonUtils.currentTimeStamp+File.separator
	 * +CommonUtils.currentTestCaseName + File.separator + message + ".jpg"; String
	 * folderCreate=ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName
	 * ; File folder = new File(folderCreate ); if(!folder.exists()) {
	 * folder.mkdir(); } try { Robot robotClassObject = new Robot(); Rectangle
	 * screenSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
	 * BufferedImage tmp = robotClassObject.createScreenCapture(screenSize);
	 * ImageIO.write(tmp, "jpg",new File(path)); path =
	 * path.replace(ExtentReportFolder+ File.separator+CommonUtils.currentTimeStamp+
	 * File.separator ,"./");
	 * 
	 * //path = path.replace(ExtentReportFolder+ File.separator, "./"); //node =
	 * test.createNode(Message); node = test.createNode(Message); node.pass(Message,
	 * MediaEntityBuilder.createScreenCaptureFromPath(path).build());
	 * logger.info(Message);
	 * 
	 * }
	 * 
	 * catch(Exception e) { e.printStackTrace(); } return path; }
	 * 
	 * //sub-node print for Pass public ExtentTest extentTestPass(String msg,String
	 * strException) {
	 * 
	 * String message = path(msg).replace(" ", "_").replaceAll("[^a-zA-Z0-9_]",
	 * "")+"_"+CommonUtils.timestampss(); String path = ExtentReportFolder
	 * +File.separator+ CommonUtils.currentTimeStamp+File.separator
	 * +CommonUtils.currentTestCaseName + File.separator + message + ".jpg"; String
	 * folderCreate=ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+File.separator +CommonUtils.currentTestCaseName
	 * ; File folder = new File(folderCreate ); if(!folder.exists()) {
	 * folder.mkdir(); } try {
	 * 
	 * String path1 = screenshotwithdateandtime(path);
	 * 
	 * //CommonUtils.takeSnapShot(driver, path); String path2 =
	 * path1.replace(ExtentReportFolder +File.separator+
	 * CommonUtils.currentTimeStamp+ File.separator, "./"); //node =
	 * test.createNode(msg); node.pass(msg,
	 * MediaEntityBuilder.createScreenCaptureFromPath(path2).build());
	 * logger.info(msg); logger.error(strException); } catch (Exception e) {
	 * e.printStackTrace(); } return node; }
	 */
}
