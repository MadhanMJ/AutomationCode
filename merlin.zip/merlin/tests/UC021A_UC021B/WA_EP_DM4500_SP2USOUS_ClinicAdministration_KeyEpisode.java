package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.List;
import java.util.stream.Collectors;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_EP_DM4500_SP2USOUS_ClinicAdministration_KeyEpisode extends CommonUtils {

	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage leftNavPage;
	CA_ClinicSettings_ReportSettingsPage reportSettings;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion;
	DataBaseConnector dataBaseConnector;
	private Log logger = new Log();
	CustomerListPage customerListPage;
	ClinicianHomePage clinicianHomePg;

	@BeforeClass
	public void initialize() {

		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		reportSettings = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		leftNavPage = new CA_LeftNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		dataBaseConnector = new DataBaseConnector();
		customerListPage = new CustomerListPage(driver, extentReport);
		clinicianHomePg = new ClinicianHomePage(driver, extentReport);

	}

	@Test
	public void sp2USOUS_ClinicAdministration_KeyEpisode() throws Exception {

		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		extentTest.assignAuthor("Dhaval Kothari");
		try {
			login = testDataProvider.getLoginData("AP_CLINIC_A");
			assertion = new Assertions(extentTest);

			
			//Scenario 1: User 1 - Clinic with only ICM4500 device							
			extentTest = extentReport.info("100S Login to EP Clinic A with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	



			extentTest = extentReport.info("200V Verify default setting i.e. ON is selected for Identify Key Episodes <ClncMgt33508>");
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is checked.");


			extentTest = extentReport.info("300S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();		
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");


			extentTest = extentReport.info("400V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference <ClncMgt33508>");
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("unchecked"), extentReport, "Identify Key Episodes check box is not Selected");


			extentTest = extentReport.info("500V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage ", new String[] {"ClncMgt33508"});
			// Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");





			extentTest = extentReport.info("600S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. . Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();		
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");




			extentTest = extentReport.info("700V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference < ClncMgt33508>");
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is Checked");


			extentReport.info("800V Verify in the database whether Identify Key Episodes value is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");

			clinicianHomeTopNavPage.clickSignOutLink();








			//scenario 2
			login = testDataProvider.getLoginData("PH_CLINIC_B");
			extentTest = extentReport.info("900S Login to EP Clinic B with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	



			extentTest = extentReport.info("1000V Verify default setting i.e. ON is selected for Identify Key Episodes", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is checked.");


			extentTest = extentReport.info("1100S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");		





			extentTest = extentReport.info("1200V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("unchecked"), extentReport, "Identify Key Episodes check box is not Selected");


			extentTest = extentReport.info("1300V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage ",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");



			extentTest = extentReport.info("1400S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. . Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");		

			extentTest = extentReport.info("1500V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is Checked");




			extentReport.info("1600V Verify in the database whether Identify Key Episodes value is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			
			clinicianHomeTopNavPage.clickSignOutLink();








			//scenario 3
			login = testDataProvider.getLoginData("AP_CLINIC_C");
			extentTest = extentReport.info("1700S Login to EP Clinic C with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	



			extentTest = extentReport.info("1800V Verify default setting i.e. ON is selected for Identify Key Episodes", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is checked.");


			extentTest = extentReport.info("1900S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");	


			extentTest = extentReport.info("2000V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("unchecked"), extentReport, "Identify Key Episodes check box is not Selected");


			extentTest = extentReport.info("2100V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");



			extentTest = extentReport.info("2200S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert_KeyEpisodes();

			extentTest = extentReport.info("2300V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference ",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is Checked");




			extentReport.info("2400V Verify in the database whether Identify Key Episodes value is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();










			//scenario 4
			login = testDataProvider.getLoginData("PH_CLINIC_D");
			extentTest = extentReport.info("2500S Login to EP Clinic D with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	


			extentTest = extentReport.info("2600V Verify default setting i.e. ON is selected for Identify Key Episodes", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is checked.");


			extentTest = extentReport.info("2700S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");	


			extentTest = extentReport.info("2800V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("unchecked"), extentReport, "Identify Key Episodes check box is not Selected");


			extentTest = extentReport.info("2900V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");



			extentTest = extentReport.info("3000S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");	


			extentTest = extentReport.info("3100V Verify that the changes are saved that means that the user is able to select Identify Key Episodes Preference ",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is Checked");



			extentReport.info("3200V Verify in the database whether Identify Key Episodes value is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();












			//scenario 5
			login = testDataProvider.getLoginData("AP_CLINIC_E");
			extentTest = extentReport.info("3300S Login to EP Clinic E with Allied Professional User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	


			extentTest = extentReport.info("3400V Verify default setting i.e. ON is selected for Identify Key Episodes", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is checked.");


			extentTest = extentReport.info("3500S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");	


			extentTest = extentReport.info("3600V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("unchecked"), extentReport, "Identify Key Episodes check box is not Selected");


			extentTest = extentReport.info("3700V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");



			extentTest = extentReport.info("3800S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key episode check box");
			reportSettings.saveReportSettings();	
			extentReport.reportScreenShot("Clicked on save button");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted alert popup");	


			extentTest = extentReport.info("3900V Verify that the changes are saved that means that the user is able to select Identify Key Episodes Preference ",new String [] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is Checked");


			extentReport.info("4000V Verify in the database whether Identify Key Episodes value is as per selection on Webpage",new String [] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();





			//scenario 6
			login = testDataProvider.getLoginData("AP_CLINIC_F");
			extentTest = extentReport.info("4100S Logout and Login to EP Clinic F with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	


			extentTest = extentReport.info("4200V Verify Identify Key Episodes Checkbox is not displayed", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(false,reportSettings.isIdentifyKeyEpisodesPresent(), extentReport, "Identify Key Episodes check box is not present");			


			extentReport.info("4300V Verify in the database Key Episodes data for this clinic is not available", new String[] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			//create new data and check in database
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();





			//scenario 7
			login = testDataProvider.getLoginData("PH_CLINIC_G");
			extentTest = extentReport.info("4400S Logout and Login to EP Clinic G with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	


			extentTest = extentReport.info("4500V Verify Identify Key Episodes Checkbox is not displayed", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(false,reportSettings.isIdentifyKeyEpisodesPresent(), extentReport, "Identify Key Episodes check box is not present");			


			extentReport.info("4600V Verify in the database Key Episodes data for this clinic is not available", new String[] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();






			//scenario 8
			login = testDataProvider.getLoginData("AP_CLINIC_H");
			extentTest = extentReport.info("4700S Logout and Login to EP Clinic H with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	


			extentTest = extentReport.info("4800V Verify Identify Key Episodes Checkbox is not displayed", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(false,reportSettings.isIdentifyKeyEpisodesPresent(), extentReport, "Identify Key Episodes check box is not present");			


			extentReport.info("4900V Verify in the database Key Episodes data for this clinic is not available", new String[] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();






			//scenario 9
			login = testDataProvider.getLoginData("PH_CLINIC_I");
			extentTest = extentReport.info("5000S Logout and Login to EP Clinic I with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Validated Clinic Administration tab");
			leftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,reportSettings.verifyLandingPage(), extentReport, "Report Settings Page is displayed");	


			extentTest = extentReport.info("5100V Verify Identify Key Episodes Checkbox is not displayed", new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(false,reportSettings.isIdentifyKeyEpisodesPresent(), extentReport, "Identify Key Episodes check box is not present");			


			extentReport.info("5200V Verify in the database Key Episodes data for this clinic is not available", new String[] {"ClncMgt33508"});
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("0"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			clinicianHomeTopNavPage.clickSignOutLink();



			//scenario 10
			login = testDataProvider.getLoginData("AS_CLINIC_A");
			extentTest = extentReport.info("5300S Logout and Login to EP Clinic A with Assistant User");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");


			extentTest = extentReport.info("5400V Verify that the user is not able to set/unset Identify Key Episodes as Clinic Administration page is not displayed ",new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(false,clinicianHomeTopNavPage.isClinicAdministrationMenuPresent(), extentReport,"Clinic Administration menu not displayed");

			clinicianHomeTopNavPage.clickSignOutLink();



			//scenario 11
			login = testDataProvider.getLoginData("AP_W_CLINIC_A");
			extentTest = extentReport.info("5500S Logout and Login to EP Clinic A with Allied Professional User without Administration rights");
			loginPage.login(login,"externaluser");;
			assertion.assertEqualsWithReporting(true,clinicianHomePg.verifyLandingPage(), extentReport, "Login Successful");	


			extentTest = extentReport.info("5600V Verify that the user is not able to set/unset Identify Key Episodes as Clinic Administration page is not displayed ",new String[] {"ClncMgt33508"});
			assertion.assertEqualsWithReporting(false,clinicianHomeTopNavPage.isClinicAdministrationMenuPresent(), extentReport, "Clinic Administration menu not displayed");	




			//DMR user flow
			extentReport.info("5700S Logout and login to Allied Professional (with Admin rights) of Clinic A with DMR tech support user and navigate to Clinic Administration page -> Report Settings tab and select Edit button.");
			clinicianHomeTopNavPage.clickSignOutLink();	
			extentReport.reportScreenShot("Signed out of the logged in user");
			login = testDataProvider.getLoginData("AP_A_11");
			loginPage.login(login,"externaluser");;
			extentReport.reportScreenShot("Logged in as an Allied Professional of Clinic F with DMR tech support user");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Clicked on Clinic administration link");
			leftNavPage.clickReportSettingsLink();
			extentReport.reportScreenShot("Clicked on Report settings link");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");





			extentReport.info("5800S Select the Identify Key Episodes Checkbox under Other Features section and Select Save-> Ok button-> Ok button on the pop up displayed.");
			extentReport.reportScreenShot("Present status of identify key checkbox ");
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			extentReport.reportScreenShot("Clicked on identify key checkbox");
			reportSettings.saveReportSettings();			
			extentReport.reportScreenShot("Saved current settings and alert popup is disaplyed");
			reportSettings.acceptAlert_KeyEpisodes();
			extentReport.reportScreenShot("Accepted popup.");
			extentReport.reportScreenShot("Verified Identify Key Episodes Preference is not available");


			extentReport.info("5900V Verify that the user is able to select Identify Key Episodes Preference. < ClncMgt33508>");
			assertion.assertEqualsWithReporting(true,reportSettings.verifyidentkeyepisodesCheckbox().equalsIgnoreCase("checked"), extentReport, "Identify Key Episodes check box is Checked");
			extentReport.reportScreenShot("Verified that the user is able to select Identify Key Episodes Preference.");




			extentReport.info("6000V Verify in the database whether Identify Key Episodes value is as per selection on Webpage. <ClncMgt33508>");
			// Need to uncomment once merlin.net  access granted
			query = "select ca.customer_id,ca.identify_key_episode_flg,ca.application_cd,ur.logon_user_name,cac.individual_type_cd"
					+ "			from users.user_record ur,users.customer_account cac,customers.customer_application ca"
					+ "			where ur.logon_user_name ='"+login.getUserName()+"' and cac.user_record_id = ur.user_record_id"
					+ "			and ca.customer_id= cac.customer_id and ca.application_cd=946";				
			keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			keyEpisodeDBValue  = keyEpisodeSettings.getString("identify_key_episode_flg");
			assertion.assertEqualsWithReporting(true,keyEpisodeDBValue.equalsIgnoreCase("1"), extentReport, "Verified in the database whether Identify Key Episodes value is as per selection on Webpage.");
			
			

			extentReport.info("6100S Logout and login to Allied Professional of Clinic F with DMR tech support user and navigate to Clinic Administration page -> Report Settings tab and select Edit button.");
			clinicianHomeTopNavPage.clickSignOutLink();	
			extentReport.reportScreenShot("Signed out of the logged in user");
			login = testDataProvider.getLoginData("AP_A_11");
			loginPage.login(login,"externaluser");;
			extentReport.reportScreenShot("Logged in as an Allied Professional of Clinic F with DMR tech support user");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();	
			extentReport.reportScreenShot("Clicked on Clinic administration link");
			leftNavPage.clickReportSettingsLink();
			extentReport.reportScreenShot("Clicked on Report settings link");
			reportSettings.clickEditButton();
			extentReport.reportScreenShot("Clicked on edit button");


			extentReport.info("6200V Verify Identify Key Episodes Preference is not available <ClncMgt33508>");
			assertion.assertEqualsWithReporting(false,reportSettings.isIdentifyKeyEpisodesPresent(), extentReport, "Identify Key Episodes check box is not present");
			extentReport.reportScreenShot("Verified Identify Key Episodes Preference is not available");



			clinicianHomeTopNavPage.clickSignOutLink();	

		} catch (AssertionError e) {
			extentReport.fail("sp2USOUS_ClinicAdministration_KeyEpisode is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail("sp2USOUS_ClinicAdministration_KeyEpisode is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
		// extentReport.info("end");
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
