package com.test.qa.ui.tests.UC021A_UC021B;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vinay Babu
 * Test Case: R9.7_ClinicAdmin_OtherFeatures
 */

public class R9$7_ClinicAdmin_OtherFeatures extends CommonUtils {

	
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_ClinicSettings_ReportSettingsPage ca_ClinicSettings_ReportSettingsPage;
	AppHomeTopNavPage appHomeTopNavPage;
	
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withoutICDDevice;
	Login loginAdminUser;
	Login loginClinicUser_withICDDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		
		ca_ClinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		
		
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withoutICDDevice = new Login();
		loginClinicUser_withICDDevice = new Login();
		loginAdminUser = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void TC_R9$7_ClinicAdmin_OtherFeatures() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);

		loginAdminUser = testDataProvider.getLoginData("SJMAdmin3");
		loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("SJMClinic2");
		loginClinicUser_withICDDevice = testDataProvider.getLoginData("SJMClinic3");
		
		extentTest.assignAuthor("Author: Vinay Babu");
		try {
			
			extentReport.info("100S Login into the ClinicB");
			
			loginPage.login(loginClinicUser_withoutICDDevice);			
			Assert.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			
			
			extentReport.info("200V Verify that the Other Feature Section is not present in the Clinic Administration-> Report Settings Page.",new String[] {"ClncMgt32176","ClncMgt32174","ClncMgt32177","Auto5229"});
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			Assert.assertTrue(clinicAdminLeftNavPage.verifyLandingPage(), "Clinic Administration Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			Assert.assertTrue(ca_ClinicSettings_ReportSettingsPage.verifyLandingPage(), "Clinic Admin -> Report Settings page is NOT Displayed.");
			
			
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
}