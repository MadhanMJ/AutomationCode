package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;

public class WA_EP_ClinicAdmin_DirectAlerts_NGQ_SP2 extends CommonUtils {
	LoginPageWithPOJO loginPage;

	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CommonUtils commonUtils;
	CA_LeftNavPage clncAdnLftNav;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	CA_ClinicAdminMobAppTransPage clncAdnMobAppTnsPg;
	@BeforeClass
	public void initialize() {

		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clncAdnLftNav=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		clncAdnMobAppTnsPg = new CA_ClinicAdminMobAppTransPage(driver, extentReport);
	}

	//Author: Bhupendra Dhore
	@Test
	public void UC021AUC021B_WA_EP_ClinicAdmin_DirectAlerts_NGQ_SP2() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);


		login = testDataProvider.getLoginData("DirectAll");
		extentTest.assignAuthor("Bhupendra Dhore");

		try {
			Assertions assertion =  new Assertions(extentTest);

			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login);
			//assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();



			extentTest=extentReport.info( "200 V Verify that under Direct Alerts Settings, Patient App Transmitter tab is available and to navigate Direct Alerts Settings for BLE ICD devices page.",new String[] {"ClncMgt33110"});
			assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyLandingPage(), extentReport, "Clinic Administration Page is displayed");
			assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyMobileAppTransmitterTab() , extentReport, "MobileAppTransmitter tab is present");
			clncAdnLftNav.clickMobileAppTransmitterLink();


			extentTest=extentReport.info("300 V Verify list of alert groups is displayed for BLE ICD devices for which the clinic is authorized for and respective Clinic's Jurisdiction",new String[] {"ClncMgt33110"});
			assertion.assertEqualsWithReporting(true, clncAdnMobAppTnsPg.validateMobileAppAlertValueInTable(), extentReport, "Verified list of alert groups is displayed for BLE ICD devices for which the clinic is authorized for and respective Clinic's Jurisdiction");





			extentTest=extentReport.info( "400 S Click on edit button and verify page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifyEditButton(), extentReport, "MobileAppTransmitter edit button  is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifySaveButton(), extentReport, "MobileAppTransmitter save button  is displayed");
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifyCancelButton(), extentReport, "MobileAppTransmitter cancel button is displayed");



			extentTest=extentReport.info( "500 V Verify Alerts Categories (Urgent, standard or Off) for the BLE ICD devices are editable & changes are saved.",new String[] {"ClncMgt33110"});
			//write code to capture alert value from excel
			clncAdnMobAppTnsPg.editAndVerifyAlertCategory();



			//Test Setup 2
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("automati_ngq_us_dna1");

			extentReport.info("600 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();


			extentTest=extentReport.info( "700 V Verify that under Direct Alerts Settings, Patient App Transmitter tab is available and to navigate Direct Alerts Settings for BLE ICD/ CRT-D devices page.",new String[] {"ClncMgt33110"});
			assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyLandingPage(), extentReport, "Clinic Administration Page is displayed");
			assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyMobileAppTransmitterTab() , extentReport, "MobileAppTransmitter tab is present");
			clncAdnLftNav.clickMobileAppTransmitterLink();

			
			
			
			extentTest=extentReport.info("800 V Verify list of alert groups is displayed for BLE ICD devices for which the clinic is authorized for and respective Clinic's Jurisdiction.",new String[] {"ClncMgt33110"});
			assertion.assertEqualsWithReporting(true, clncAdnMobAppTnsPg.validateMobileAppAlertValueInTable() , extentReport, "Verified list of alert groups is displayed for BLE ICD devices for which the clinic is authorized for and respective Clinic's Jurisdiction");




			extentTest=extentReport.info( "900 S Click on edit button and verify page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifyEditButton(), extentReport, "MobileAppTransmitter edit button  is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifySaveButton(), extentReport, "MobileAppTransmitter save button  is displayed");
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifyCancelButton(), extentReport, "MobileAppTransmitter cancel button is displayed");
			
			
			
			extentTest=extentReport.info( "1000 V Verify Alerts Categories (Urgent, standard or Off) for the BLE ICD devices are editable & changes are saved.",new String[] {"ClncMgt33110"});
			clncAdnMobAppTnsPg.editAndVerifyAlertCategory();




			//Test Setup 3
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("automatio_ngq_us_nda");

			extentReport.info("1100 S Login with Test setup 3 and navigate to Clinic Administration tab >Direct Alerts Settings. (Negative Scenario)");		
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();


			extentTest=extentReport.info( "V Verify that under Direct Alerts Settings, Patient App Transmitter tab is available and navigate to BLE Device page.",new String[] {"ClncMgt33110"});
			assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyLandingPage(), extentReport, "Clinic Administration Page is displayed");
			assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyMobileAppTransmitterTab() , extentReport, "MobileAppTransmitter tab is present");
			//write steps to navigate to  BLE Device page.




			//Test Setup 4
			//			appHomeTopNavPage.clickSignOutLink();
			//			login = testDataProvider.getLoginData("PH_ADM_NGQ");
			//	
			//			extentReport.info("1400 S Login with Test setup 4 and navigate to Clinic Administration tab >Direct Alerts Settings. (Negative Scenario)");		
			//			loginPage.login(login);
			//			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(), extentTest, "User is logged in successfullt.");
			//			Assert.assertTrue(loginCheck);
			//			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			//			
			//			
			//			extentTest=extentReport.info( "1500 V Verify that under Direct Alerts Settings, Patient App Transmitter tab is not displayed.",new String[] {"ClncMgt33110"});
			//			assertion.assertEqualsWithReporting(false, clncAdnLftNav.verifyMobileAppTransmitterTab() , extentTest, "MobileAppTransmitter tab is not present");
			//			
			//			

			//Test Setup 5
			//			appHomeTopNavPage.clickSignOutLink();
			//			login = testDataProvider.getLoginData("AP_NGQ_ADMIN");
			//	
			//			extentReport.info("1800 S Login with Test setup 6 and navigate to Clinic Administration tab >Direct Alerts Settings. (Negative Scenario)");		
			//			loginPage.login(login);
			//			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(), extentTest, "User is logged in successfullt.");
			//			Assert.assertTrue(loginCheck);
			//			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			//			
			//			
			//			extentTest=extentReport.info( "1900 V Verify that under Direct Alerts Settings, Patient App Transmitter tab is not displayed.",new String[] {"ClncMgt33107"});
			//			assertion.assertEqualsWithReporting(false, clncAdnLftNav.verifyMobileAppTransmitterTab() , extentTest, "MobileAppTransmitter tab is not present");
			//			
			//			
			//			



		} 
		catch (AssertionError e) {
			extentTest = extentReport.fail( "UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed due to assertion failure");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed due to some exception");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}






	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
