package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;


/*
 * Author: Victor
 * Test Case: R11_5_WA_ICM_ClinicAdmin_PatientSummaryReportSetting_02
 * Report: Good
 */

public class R11_5_WA_ICM_ClinicAdmin_PatientSummaryReportSetting_02 extends CommonUtils {

	
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	AppHomeTopNavPage appHomeTopNavPage;
	CA_DirectAlert_CardiacMonitorPage directAlerts_CardiacMonitorPage;
	Assertions assertion,softAssert ;
	
	
	
	
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withICMDevice;
	Login loginAdminUser;
	Login loginClinicUser_onlyICMDevice;
	Login loginClinicUser_ICMandNGQDevice;
	Login loginClinicUser_Allied;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	List billingInterval;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		
		
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		directAlerts_CardiacMonitorPage = new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withICMDevice = new Login();
		loginClinicUser_onlyICMDevice = new Login();
		loginClinicUser_ICMandNGQDevice = new Login();
		loginClinicUser_Allied = new Login();
		loginAdminUser = new Login();
		
		testDataProvider = new TestDataProvider();
		
	}

	@Test
	public void R11_5_WA_ICM_ClinicAdmin_PatientSummaryReportSetting_02() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		loginAdminUser = testDataProvider.getLoginData("SJMAdmin");
		loginClinicUser_withICMDevice = testDataProvider.getLoginData("SJMClinic2");//clinic A
		loginClinicUser_onlyICMDevice = testDataProvider.getLoginData("SJMClinic7");//clinic B
		loginClinicUser_ICMandNGQDevice = testDataProvider.getLoginData("SJMClinic4");
		loginClinicUser_Allied = testDataProvider.getLoginData("SJMAllied");
		
		
		
		
		extentTest.assignAuthor("Author: Victor");
		try {
			assertion =  new Assertions(extentTest);
			softAssert = new Assertions(extentTest);
			extentReport.info("100S Login to Clinic A as Allied professional user.");
			loginPage.login(loginClinicUser_Allied);			
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is NOT Displayed.");
			
			extentReport.info("200S Navigate to clinic administration page.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is NOT Displayed.");
			extentReport.reportScreenShot("User is able to view on clinic administration page ");
			extentReport.info("300S Verify that the Cardiac Monitor navigation link is not displayed.",new String[] {"<ClncMgt27028>"});
			Assert.assertTrue(clinicAdminLeftNavPage.verifyCardiacMonitorlink(),"CardiacMonitorpage is not visble");
			
			extentReport.info("400S Click on Report settings link from the left navigation panel on the page.");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyLandingPage(), extentReport, "Clinic Admin -> Report Settings Page is NOT Displayed.");
			
			
			
			extentReport.info("500V Verify that the report setting page is displayed in view mode.", new String[] {"<ClncMgt33263>"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyLandingPage(), extentReport, "Clinic Admin -> Report Settings Page is NOT Displayed.");
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), "Report Setting page is not in view mode.");
			extentReport.reportScreenShot("User is able to view on report setting page is displayed in view mode.");
			// This Step need to validate once the defect rectified 
			//extentReport.info("600V Verify that the Patient Summary Report Section is not displayed on the page", new String[] {"<ClncMgt33263>"});
			
			
			//extentReport.info("600V Verify that the Patient Summary Report Section is not displayed on the page.",new String[] {"<ClncMgt33263>"});
			//Assert.assertTrue(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report is not displayed");
			
			extentReport.info("700S Logout and login as SJM admin. Edit Clinic A and add ICM device to the RHS.");
			clinicianHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginAdminUser);
			assertion.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Customers List Page is NOT Displayed.");
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_withICMDevice.getUserName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport, "Customers Profile Page is NOT Displayed.");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(), extentReport,"Change Customers Profile Page is NOT Displayed.");			
			List<String> list = new ArrayList<String>();
			list.add("Confirm Rx ICM, DM3500 ");
		    list.add("Jot Dx ICM, DM4500 ");
			changeCustomerProfilePage.addDevicesToAllowedListAndSave(list);
			appHomeTopNavPage.clickSignOutLink();
			extentReport.info("800S Login to same clinic and navigate to Clinic Admin page. Click on Cardiac Monitor navigation link and navigate to Direct Alerts� Settings for Cardiac Monitor.");
			loginPage.login(loginClinicUser_withICMDevice);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is NOT Displayed.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport, "Clinic Administration Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickCardiacMonitorLink();
			assertion.assertEqualsWithReporting(true,directAlerts_CardiacMonitorPage.verifyLandingPage(),extentReport, "Cardiac monitor Page is NOT Displayed.");
			extentReport.info("900S Click on Show Devices hyper link and verify that the Confirm Rx� ICM, DM3500 device is available in the Device list.");
			directAlerts_CardiacMonitorPage.clickShowDevicesLink();
			directAlerts_CardiacMonitorPage.verifyDeviceListPopup();
			
			List<WebElement> deviceList = directAlerts_CardiacMonitorPage.getDeviceList();
			boolean flag = false;
			for (int i = 0; i < deviceList.size(); i++) {
			if(deviceList.get(i).getText().contains("ICM, DM3500")) {
			flag = true;
			}
			}
			assertion.assertTrue(flag, "Device list should contain ICL DM3500 device");
			//Need to validate the devices list, Open Bug -
			
		
			extentReport.info("1000S Click on Close button on the pop-up box.");
			directAlerts_CardiacMonitorPage.clickDeviceListPopupCloseBtn();
			
			extentReport.info("1100S Click on Report settings link from the left navigation panel on the page");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport, "Clinic Admin -> Report Settings Page is NOT Displayed.");
			
			extentReport.info("1200V Verify that the report setting page is displayed in view mode.", new String[] {"<ClncMgt33263>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), "Report Setting page is not in view mode.");
			
			extentReport.info("1300V Verify that the Patient Summary Report section is displayed on the report setting page",new String[] {"<ClncMgt33263>", "<ClncMgt33264>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report is not displayed");
			
			extentReport.info("1400S Click on Edit button, verify that the page is displayed in Edit mode.", new String[] {"<ClncMgt27021>"});
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(), "Settings in Edit Mode");
			
			extentReport.info("1800V Verify that the value of dropdown field of billing interval is 31 by default.", new String[] {"<Config23472>"});
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "31");
			
			extentReport.info("1900V Verify that the page displays the Drop-down value for the print every report (Patient Summary Report billing interval).", new String[] {"<Config23472>","<Config23472>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(), "Billing interval Dropdown should displayed in Patient Report Symmary");
			
			extentReport.info("2000V Verify that on Patient Summary Report billing interval, the selectable values associated with the Show Dropdown Filter Field displayed are 31,91.", new String[] {"<Config23472>","<Config23472>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(), "Billing interval Dropdown should displayed in Patient Report Symmary");
			billingInterval = clinicSettings_ReportSettingsPage.getBillingIntervalsListValues();
			softAssert.assertTrue(billingInterval.contains("31"), "Billing interval value -  31 is not find. ");
			softAssert.assertTrue(billingInterval.contains("91"), "Billing interval value -  91 is not find. ");
			
			extentReport.info("2100S Select 91 value and Click on save button.");
			clinicSettings_ReportSettingsPage.selectBillingInterval91_andSave();
		
			extentReport.info("2200V Verify that a pop-up box is getting displayed click ok on the pop-up box. Verify that the System save the Changes.", new String[] {"<CommUI9024>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verify_Alert_Is_Present_Patient_SummaryReport(),"popup box is displayed");
			extentReport.reportScreenShot("User is able to view pop-up box is getting displayed");
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "91","selected billing interval value - 91 is not saved successfully");
			
			extentReport.info("2300S Logout from clinic A and login to another clinic B.");
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginClinicUser_onlyICMDevice);			
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(),extentReport, "Clinician Home Page is NOT Displayed.");
			
			extentReport.info("2400S Navigate to clinic administration page.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport, "Clinic Administration Page is NOT Displayed.");
			
			extentReport.info("2500S Verify that the Cardiac Monitor navigation link is displayed.", new String[] {"<ClncMgt27028>"});
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyCardiacMonitorlink(),extentReport,"CardiacMonitorpage is not visble");
	
			extentReport.info("2600S Click on Cardiac Monitor navigation link and navigate to Direct Alerts� Settings for Cardiac Monitor.");
			clinicAdminLeftNavPage.clickCardiacMonitorLink();
			assertion.assertEqualsWithReporting(true,directAlerts_CardiacMonitorPage.verifyLandingPage(),extentReport,"Cardiac monitor Page is NOT Displayed.");
			
			extentReport.info("2700S Click on Show Devices hyper link and verify that the Confirm Rx� ICM, DM3500 device is available in the Device list.");
			directAlerts_CardiacMonitorPage.clickShowDevicesLink();
			directAlerts_CardiacMonitorPage.verifyDeviceListPopup();
			//Need to validate the devices list, Open Bug - 127
			
			
			extentReport.info("2800S Click on Close button on the pop-up box.");
			directAlerts_CardiacMonitorPage.clickDeviceListPopupCloseBtn();
			
			extentReport.info("2900S Click on Report settings link from the left navigation panel on the page");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport, "Clinic Admin -> Report Settings Page is NOT Displayed.");
			
			extentReport.info("3000V Verify that the report setting page is displayed in view mode.", new String[] {"<ClncMgt33263>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), "Report Setting page is not in view mode.");
			
			extentReport.info("3100V  Verify that the Patient Summary Report section is displayed on the report setting page",new String[] {"<ClncMgt33263>", "<ClncMgt33264>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report is not displayed");
			
			extentReport.info("3200S  Click on Edit button, verify that the page is displayed in Edit mode.", new String[] {"<ClncMgt27021>"});
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(), "Settings in Edit Mode");
			
			extentReport.info("3300V  Verify that the value of dropdown field of billing interval is 31 by default.", new String[] {"<Config23472>"});
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "31");
			
			extentReport.info("3400V Verify that the page displays the Drop-down value for the print every report (Patient Summary Report billing interval).", new String[] {"<Config23472>","<Config23472>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(), "Billing interval Dropdown should displayed in Patient Report Symmary");
			
			extentReport.info("3500V Verify that on Patient Summary Report billing interval, the selectable values associated with the Show Dropdown Filter Field displayed are 31,91.", new String[] {"<Config23472>","<Config23472>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(), "Billing interval Dropdown should displayed in Patient Report Symmary");
			billingInterval = clinicSettings_ReportSettingsPage.getBillingIntervalsListValues();
			softAssert.assertTrue(billingInterval.contains("31"), "Billing interval value -  31 is not find. ");
			softAssert.assertTrue(billingInterval.contains("91"), "Billing interval value -  91 is not find. ");
			
			extentReport.info("3600S Select 31 value and Click on save button.");
			clinicSettings_ReportSettingsPage.selectBillingInterval31_andSave();
			
			extentReport.info("3700V Verify that a pop-up box is getting displayed click ok on the pop-up box. Verify that the System save the Changes.", new String[] {"<CommUI9024>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verify_Alert_Is_Present_Patient_SummaryReport(),"popup box is displayed");
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "31","selected billing interval value - 91 is not saved successfully");
			
			extentReport.info("3800S Logout and Login to SJM Admin. Edit Clinic B and add all NGQ devices also and save");
			clinicianHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginAdminUser);
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(), extentReport, "Customers List Page is NOT Displayed.");
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_ICMandNGQDevice.getUserName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport, "Customers Profile Page is NOT Displayed.");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport, "Change Customers Profile Page is NOT Displayed.");			
			List<String> list2 = new ArrayList<String>();
	        list2.add("Gallant� VR, CDVRA700Q");
	        list2.add("Gallant� VR, CDVRA701Q");
	        list2.add("Gallant� DR, CDDRA700Q");
	        list2.add("Gallant� HF, CDHFA700Q");
	        list2.add("Avant� VR, CDVRA500Q");
	        list2.add("Avant� DR, CDDRA500Q");
	        list2.add("Avant � HF, CDHFA500Q");
	        list2.add("Entrant� VR, CDVRA300Q");
	        list2.add("Entrant� DR, CDDRA300Q");
	        list2.add("Entrant� HF, CDHFA300Q");
	        list2.add("Neutrino� NxT VR, CDVRA800Q");
	        list2.add("Neutrino� NxT DR, CDDRA800Q");
			changeCustomerProfilePage.addDevicesToAllowedListAndSave(list2);
			appHomeTopNavPage.clickSignOutLink();
			
			extentReport.info("4000S Logout and login to Clinic B. Navigate to Clinic Administration page.");
			loginPage.login(loginClinicUser_ICMandNGQDevice);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(), extentReport,"Clinician Home Page is NOT Displayed.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport, "Clinic Administration Page is NOT Displayed.");

			extentReport.info("4100S Verify that the Cardiac Monitor navigation link is displayed. <ClncMgt27028>");
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyCardiacMonitorlink(),extentReport,"CardiacMonitorpage is not visble");
			
			extentReport.info("4200S Click on Cardiac Monitor navigation link and navigate to Direct Alerts� Settings for Cardiac Monitor.");
			clinicAdminLeftNavPage.clickCardiacMonitorLink();
			assertion.assertEqualsWithReporting(true,directAlerts_CardiacMonitorPage.verifyLandingPage(), extentReport,"Cardiac monitor Page is NOT Displayed.");
			extentReport.info("4300S  Click on Show Devices hyper link and verify that the Confirm Rx� ICM, DM3500 device is available in the Device list.");
			directAlerts_CardiacMonitorPage.clickShowDevicesLink();
			directAlerts_CardiacMonitorPage.verifyDeviceListPopup();
			//Need to validate the devices list, Open Bug -
			
			
			extentReport.info("4400S Click on Close button on the pop-up box.");
			directAlerts_CardiacMonitorPage.clickDeviceListPopupCloseBtn();
			
			extentReport.info("4500S Click on Report settings link from the left navigation panel on the page");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport, "Clinic Admin -> Report Settings Page is NOT Displayed.");
			
			extentReport.info("4600V Verify that the report setting page is displayed in view mode.", new String[] {"<ClncMgt33263>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), "Report Setting page is not in view mode.");
			
			extentReport.info("4700V Verify that the Patient Summary Report section is displayed on the report setting page",new String[] {"<ClncMgt33263>", "<ClncMgt33264>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report is not displayed");
			
			extentReport.info("4800S Click on Edit button, verify that the page is displayed in Edit mode.", new String[] {"<ClncMgt27021>"});
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(), "Settings in Edit Mode");
			
			extentReport.info("4900V Verify that the value of dropdown field of billing interval is 31 by default.", new String[] {"<Config23472>"});
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "31");
			
			extentReport.info("5000V Verify that the page displays the Drop-down value for the print every report (Patient Summary Report billing interval).", new String[] {"<Config23472>","<Config23472>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(), "Billing interval Dropdown should displayed in Patient Report Symmary");
			
			extentReport.info("5100V Verify that on Patient Summary Report billing interval, the selectable values associated with the Show Dropdown Filter Field displayed are 31,91.", new String[] {"<Config23472>","<Config23472>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(), "Billing interval Dropdown should displayed in Patient Report Symmary");
			billingInterval = clinicSettings_ReportSettingsPage.getBillingIntervalsListValues();
			softAssert.assertTrue(billingInterval.contains("31"), "Billing interval value -  31 is not find. ");
			softAssert.assertTrue(billingInterval.contains("91"), "Billing interval value -  91 is not find. ");
			
			extentReport.info("5200S Select 91 value and Click on save button.");
			clinicSettings_ReportSettingsPage.selectBillingInterval91_andSave();
			
			extentReport.info("5300V Verify that a pop-up box is getting displayed click ok on the pop-up box. Verify that the System save the Changes.", new String[] {"<CommUI9024>"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verify_Alert_Is_Present_Patient_SummaryReport(),"popup box is displayed");
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			softAssert.assertEquals(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "91","selected billing interval value - 91 is not saved successfully");
		
			
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
	@AfterMethod
	public void cleanup() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		loginAdminUser = testDataProvider.getLoginData("SJMAdmin");
		loginClinicUser_withICMDevice = testDataProvider.getLoginData("SJMClinic2");
		loginClinicUser_onlyICMDevice = testDataProvider.getLoginData("SJMClinic3");
		loginClinicUser_ICMandNGQDevice = testDataProvider.getLoginData("SJMClinic4");
		loginClinicUser_Allied = testDataProvider.getLoginData("SJMAllied");	
		
		extentTest.assignAuthor("Author: Vinay Babu");
		try {
			
			List<String> list = new ArrayList<String>();
	        list.add("Atlas�+ /HF /V-340");
	        list.add("Atlas�+ /VR C /V-193C");
			
	        List<String> list2 = new ArrayList<String>();
	        list2.add("Atlas�+ /HF /V-340");
	        list2.add("Atlas�+ /VR C /V-193C");
			/////////////////////////////////////////////////////////////////////////////////////////////Clean up/////////////////////////
			
			loginPage.login(loginAdminUser);
			Assert.assertTrue(customerListPage.verifyLandingPage(), "Customers List Page is NOT Displayed.");
			
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_withICMDevice.getCustomer());
			Assert.assertTrue(customerProfilePage.verifyLandingPage(), "Customers Profile Page is NOT Displayed.");
			
			customerProfilePage.clickChangeButton();
			Assert.assertTrue(changeCustomerProfilePage.verifyLandingPage(), "Change Customers Profile Page is NOT Displayed.");
			
			changeCustomerProfilePage.removeDevicesFromAllowedListAndSave(list);
			
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_onlyICMDevice.getCustomer());
			Assert.assertTrue(customerProfilePage.verifyLandingPage(), "Customers Profile Page is NOT Displayed.");
			
			customerProfilePage.clickChangeButton();
			Assert.assertTrue(changeCustomerProfilePage.verifyLandingPage(), "Change Customers Profile Page is NOT Displayed.");
			
			changeCustomerProfilePage.addDevicesToAllowedListAndSave(list2);
			
			appHomeTopNavPage.clickSignOutLink();
			
			
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
		@AfterMethod (dependsOnMethods = "cleanup")
		public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
		status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		status = "Success";
		}



		writeInTextFile(testMethodName, status);
		}
	
}

