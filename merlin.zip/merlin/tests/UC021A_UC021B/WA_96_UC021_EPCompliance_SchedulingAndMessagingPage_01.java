package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

// Author - Alok Kumar
// TC ID - WA_96_UC021_EPCompliance_SchedulingAndMessagingPage_01


public class WA_96_UC021_EPCompliance_SchedulingAndMessagingPage_01 extends CommonUtils {

	ViewCustomerPage viewCustomerPage;
	AddCustomerPage addCustomerPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	CA_SchedulingAndMessagingPage SchedulingAndMessagingPage;
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withICMDevice;
	Login loginAdminUser;
	Login loginClinicUser_withICDDevice;
	Login loginClinicUser_with_ICD_And_ICMDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;


	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		clinicianHomePage = new ClinicianHomePage(driver,extentReport);
		addCustomerPage = new AddCustomerPage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withICMDevice = new Login();
		loginClinicUser_withICDDevice = new Login();
		loginClinicUser_with_ICD_And_ICMDevice = new Login();
		loginAdminUser = new Login();
		testDataProvider = new TestDataProvider();
		customerListPage = new CustomerListPage(driver, extentReport);
	}

	@Test(groups= {"Regression"})
	public void WA_96_UC021_EPCompliance_SchedulingAndMessagingPage() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		loginClinicUser_withICDDevice = testDataProvider.getLoginData("EP_Clinic_B");
		loginClinicUser_withICMDevice = testDataProvider.getLoginData("EP_Clinic_A");
		loginClinicUser_with_ICD_And_ICMDevice = testDataProvider.getLoginData("EP_Clinic_C");
		loginAdminUser = testDataProvider.getLoginData("SJMAdmin3");
		extentTest.assignAuthor("Author: Alok Kumar");
		
		try {
			Assertions assertion =  new Assertions(extentTest);	
			extentReport.info("100 S Login with Sjm admin and Click on Add customer button ");
			loginPage.login(loginAdminUser, "externaluser");
			addCustomerPage.addcustomerclick();
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,addCustomerPage.verifyLandingPage(),extentReport,"Add Customer Page is displayed");
			
			extentReport.info("200 V - Verify the direct check compliance day check box is not displayed.");
			addCustomerPage.VerifyDirectCheckComplianceDay();
			assertion.assertEqualsWithReporting(true,addCustomerPage.verifyLandingPage(),extentReport,"Direct check compliance day check box is not displayed");
			
			extentReport.info("300 S Select customer from list and Navigates to change customer page");
			viewCustomerPage.cancel();
			assertion.assertEqualsWithReporting(true,viewCustomerPage.verifyLandingPage(),extentReport,"Clicked on cancel button to come back on  Customer search page ");
			Thread.sleep(3000);
			viewCustomerPage.customerProfileselect("EnhancedSPclinic1");
			assertion.assertEqualsWithReporting(true,viewCustomerPage.verifyLandingPage(),extentReport,"Customer Profile page is displayed with customer's details ");
			Thread.sleep(3000);
			viewCustomerPage.change();
			Thread.sleep(3000);
			extentReport.reportScreenShot("Navigates to change customer page is displayed");
			
			extentReport.info("400 V Verify the \"direct check compliance day\" check box is not displayed.",new String[] {"ClncMgt33106"});
			viewCustomerPage.VerifyDirectCheckComplianceDay();
			assertion.assertEqualsWithReporting(true,viewCustomerPage.verifyLandingPage(),extentReport,"Direct check compliance day check box is not displayed");
			extentReport.reportScreenShot("Direct check compliance day check box is not displayed");
			
			extentReport.info("500 S Login with Clinic \"EP_Clinic_A\" and navigates to Clinic Administration Page by clicking on Clinic Administration tab." );
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginClinicUser_withICDDevice, "externaluser");
			Thread.sleep(3000);
		//	assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyLandingPage(),extentReport,"Logged in with Clinic EP_Clinic_A");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			extentReport.reportScreenShot("Clinic Administration Page is displayed");
			
			extentReport.info("600 S Actor clicks on Scheduling and Messaging on Clinic Administration Page.");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot("Scheduling and Messaging Page is displayed"); 
			
			extentReport.info("700 V Verify the Compliance monitoring sections (ICD/Pacemaker (Merlin@home) transmitter connectivity threshold,ICD/Pacemaker (Merlin@home) Device check threshold compliance) for ICD is displayed on Scheduling and Messaging page.",new String[] {"ClncAcct6816","ClncAcct6587","ClncAcct6665",});
			SchedulingAndMessagingPage.VerifyField("disconnectedTransmitterThresholds");
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" DISCONNECTED TRANSMITTER THRESHOLDS is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("PatientswithMobileApptransmitters");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Patients with Mobile App transmitters is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("Monitorpatientstransmittercommunicationstatus");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patients transmitter communication status");
			
			SchedulingAndMessagingPage.VerifyField("MonitorpatientDirectAlertCheckstatus");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patient Direct Alert Check status"); 
			
			/*
			 * SchedulingAndMessagingPage.VerifyField(
			 * "Monitorpatientstransmittercommunicationstatusnoofdays"); //
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patients transmitter communication status no of days is displayed"
			 * );
			 * 
			 * SchedulingAndMessagingPage.VerifyField(
			 * "MonitorpatientDirectAlertCheckstatusnoofdays"); //
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patient Direct Alert Check status no of days is displayed"
			 * );
			 */
			SchedulingAndMessagingPage.VerifyField("PatientswithMerlinhometransmitters");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Patients with Merlin home transmitters is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("Monitorpatientstransmittercommunicationstatusmerlinhome");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patients transmitter communication status merlinhome is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("MonitorpatientDirectAlertCheckstatusmerlinhome");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patient Direct Alert Check status merlinhome is displayed"); 
			
			/*
			 * SchedulingAndMessagingPage.VerifyField(
			 * "Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome"); //
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patients transmitter communication status no of day smerlinhome is displayed"
			 * );
			 * 
			 * SchedulingAndMessagingPage.VerifyField(
			 * "MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome"); //
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patient Direct Alert Check status no of days merlinhome is displayed"
			 * );
			 * 
			 */
			extentReport.info("900 S Login with Clinic \"EP_Clinic_B\" and navigates to Clinic Administration Page by clicking on Clinic Administration tab." );
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginClinicUser_withICMDevice, "externaluser");
			Thread.sleep(3000);
		//	assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyLandingPage(),extentReport,"Logged in with Clinic EP_Clinic_A");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			extentReport.reportScreenShot("Clinic Administration Page is displayed");
			
			extentReport.info("1000 S Actor clicks on Scheduling and Messaging on Clinic Administration Page.");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot("Scheduling and Messaging Page is displayed"); 
			
			extentReport.info("1100 V Verify the Compliance monitoring sections (Patient App transmitter connectivity threshold,Patient App Device check threshold compliance) for ICM is displayed on Scheduling and Messaging page",new String[] {"ClncMgt33078","ClncAcct6816"});
			SchedulingAndMessagingPage.VerifyField("disconnectedTransmitterThresholds");
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" DISCONNECTED TRANSMITTER THRESHOLDS is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("PatientswithMobileApptransmitters");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Patients with Mobile App transmitters is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("Monitorpatientstransmittercommunicationstatus");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patients transmitter communication status");
			
			SchedulingAndMessagingPage.VerifyField("MonitorpatientDirectAlertCheckstatus");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patient Direct Alert Check status"); 
			
			/*
			 * SchedulingAndMessagingPage.VerifyField(
			 * "Monitorpatientstransmittercommunicationstatusnoofdays");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patients transmitter communication status no of days is displayed"
			 * );
			 * 
			 * SchedulingAndMessagingPage.VerifyField(
			 * "MonitorpatientDirectAlertCheckstatusnoofdays");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patient Direct Alert Check status no of days is displayed"
			 * );
			 */
			SchedulingAndMessagingPage.VerifyField("PatientswithMerlinhometransmitters");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Patients with Merlin home transmitters is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("Monitorpatientstransmittercommunicationstatusmerlinhome");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patients transmitter communication status merlinhome is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("MonitorpatientDirectAlertCheckstatusmerlinhome");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patient Direct Alert Check status merlinhome is displayed"); 
			/*
			 * SchedulingAndMessagingPage.VerifyField(
			 * "Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patients transmitter communication status no of day smerlinhome is displayed"
			 * );
			 * 
			 * SchedulingAndMessagingPage.VerifyField(
			 * "MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patient Direct Alert Check status no of days merlinhome is displayed"
			 * );
			 */
			extentReport.info("1300 S Login with Clinic \"EP_Clinic_C\" and navigates to Clinic Administration Page by clicking on Clinic Administration tab. " );
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginClinicUser_with_ICD_And_ICMDevice, "externaluser");
		//	assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyLandingPage(),extentReport,"Logged in with Clinic EP_Clinic_A");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			extentReport.reportScreenShot("Clinic Administration Page is displayed");
			
			extentReport.info("1400 S Actor clicks on Scheduling and Messaging on Clinic Administration Page.");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot("Scheduling and Messaging Page is displayed"); 
			
			extentReport.info("1500 V Verify the Compliance monitoring sections (Patient App transmitter connectivity threshold,Patient App Device check threshold compliance,ICD/Pacemaker (Merlin@home) transmitter connectivity threshold,ICD/Pacemaker (Merlin@home) Device check threshold compliance) for ICM is displayed on Scheduling and Messaging page.",new String[] {"ClncMgt32071","ClncAcct6816"});
			SchedulingAndMessagingPage.VerifyField("disconnectedTransmitterThresholds");
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" DISCONNECTED TRANSMITTER THRESHOLDS is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("PatientswithMobileApptransmitters");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Patients with Mobile App transmitters is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("Monitorpatientstransmittercommunicationstatus");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patients transmitter communication status");
			
			SchedulingAndMessagingPage.VerifyField("MonitorpatientDirectAlertCheckstatus");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patient Direct Alert Check status"); 
			
			/*
			 * SchedulingAndMessagingPage.VerifyField(
			 * "Monitorpatientstransmittercommunicationstatusnoofdays");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patients transmitter communication status no of days is displayed"
			 * );
			 * 
			 * SchedulingAndMessagingPage.VerifyField(
			 * "MonitorpatientDirectAlertCheckstatusnoofdays");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patient Direct Alert Check status no of days is displayed"
			 * );
			 */
			SchedulingAndMessagingPage.VerifyField("PatientswithMerlinhometransmitters");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Patients with Merlin home transmitters is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("Monitorpatientstransmittercommunicationstatusmerlinhome");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patients transmitter communication status merlinhome is displayed"); 
			
			SchedulingAndMessagingPage.VerifyField("MonitorpatientDirectAlertCheckstatusmerlinhome");
			assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			extentReport.reportScreenShot(" Monitor patient Direct Alert Check status merlinhome is displayed"); 
			
			/*
			 * SchedulingAndMessagingPage.VerifyField(
			 * "Monitorpatientstransmittercommunicationstatusnoofdaysmerlinhome");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patients transmitter communication status no of day smerlinhome is displayed"
			 * );
			 * 
			 * SchedulingAndMessagingPage.VerifyField(
			 * "MonitorpatientDirectAlertCheckstatusnoofdaysmerlinhome");
			 * assertion.assertEqualsWithReporting(true,SchedulingAndMessagingPage.
			 * verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed"
			 * ); extentReport.
			 * reportScreenShot(" Monitor patient Direct Alert Check status no of days merlinhome is displayed"
			 * );
			 */
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
	
}