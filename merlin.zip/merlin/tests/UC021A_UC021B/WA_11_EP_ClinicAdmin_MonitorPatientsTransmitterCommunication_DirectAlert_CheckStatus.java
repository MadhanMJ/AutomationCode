package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_11_EP_ClinicAdmin_MonitorPatientsTransmitterCommunication_DirectAlert_CheckStatus extends CommonUtils {
	LoginPageWithPOJO loginPage;
	Login login;
	Login loginClinicUser_withoutICDDevice;
	CA_SchedulingAndMessagingPage scmePage;
	ClinicianHomeTopNavPage appHomeTopNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage MerlinAtHomePage;
	CA_LeftNavPage LeftNavPage;
	private String testName;
	TestDataProvider testDataProvider;
	CustomerListPage customerListPage;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		scmePage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		appHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		LeftNavPage = new CA_LeftNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
	}

	@Test(groups = {"Regression"})
	public void MonitorPatientsTransmitterCommunication() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("TC1227874_Clinic");
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Jeetendra Gupta");// comments
		try {
			Assertions assertion = new Assertions(extentTest);
			
			/**************************************************************************************************************/
			extentReport.info(
					"100 S Login with Test setup 1 and navigate to Clinic Administration tab > Scheduling & Messaging page.");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			LeftNavPage.clickSchedMessagingLink();			
			assertion.assertEqualsWithReporting(true, scmePage.verifyLandingPage(), extentReport,
					"Scheduling & Messaging page is displayed");
			
			/**************************************************************************************************************/
			extentReport.info(
					"200 V Verify that under Disconnected Transmitter Thresholds section > Patient with Mobile App Transmitter displayed in view mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyAppUnderSection("DISCONNECTED TRANSMITTER THRESHOLDS",
							"Patients with Mobile App transmitters:"),
					extentReport, "Patient with Mobile App Transmitter displayed in view mode");

			/**************************************************************************************************************/
			extentReport.info(
					"300 V Verify Monitor patient�s transmitter communication status checkbox is displayed and default drop down default value 7 days in view mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyPatientwithMobileAppcheckboxanddefaultvalue("7 days"),
					extentReport, "Default drop down default value 7 days in view mode");

			/**************************************************************************************************************/
			extentReport.info(
					"400 V Verify Monitor Patient�s Direct Alert� Check status checkbox is displayed and default drop down default value 7days in view mode. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(true,
					scmePage.MonitorPatientsDirectAlertCheckanddefaultvalue("7 days"),
					extentReport, "Default drop down default value 7 days in view mode.");

			/**************************************************************************************************************/
			extentReport
					.info("400 S Click on the edit button and Verify the page is opened in edit mode.");

			assertion.assertEqualsWithReporting(true, scmePage.ClickEditButton(), extentReport,
					"Page is opened in edit mode.");

			/**************************************************************************************************************/
			extentReport.info(
					"500 V Verify Checkbox 'monitor patient�s transmitter communication status� can be check or uncheck in edit mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyMoniterPatientTranComm_Status_Checkbox("check"),
					extentReport, "Checkbox 'monitor patient�s transmitter communication status� is checked");

			/**************************************************************************************************************/
			extentReport.info(
					"600 V Verify application provides the capability for the clinic to check/enable Monitor patient�s DirectAlert� Check status checkbox when checkbox 'monitor patient�s transmitter communication status is checked. <ClncMgt33079>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyUserCapabilityDirectAlertCheckbox("check", "Enabled"),
					extentReport, "Enable Monitor patient�s DirectAlert� Check status checkbox");

			/**************************************************************************************************************/
			extentReport.info(
					"700 V Verify application does not provides the capability for the clinic to check/enable Monitor patient�s DirectAlert� Check status checkbox when checkbox 'monitor patient�s transmitter communication status is un-checked. <ClncMgt33079>");
			assertion.assertTrue(
					scmePage.MoniterPatientTranComm_Status_Checkbox_action("Uncheck"));
			assertion
					.assertEqualsWithReporting(true,
							scmePage.verifyUserCapabilityDirectAlertCheckbox("Uncheck","Disabled"),
							extentReport, "Disable Monitor patient�s DirectAlert� Check status checkbox");

			/**************************************************************************************************************/
			extentReport.info(
					"800 V Verify default dropdown value provided = {Off, 3, 4, 5, 6, 7} is possible to selected & get saved on Scheduling messaging page and save the changes. <ClncMgt33077> <ClncMgt33078>");
			scmePage.MoniterPatientTranComm_Status_Checkbox_action("check");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyMoniterPatientTranComm_Status_dropdownvalues("3 days, 4 days, 5 days, 6 days, 7 days"),
					extentReport, "Default dropdown value provided = {3 days, 4 days, 5 days, 6 days, 7 days} is displayed");
			scmePage.selectMoniterPatientTranComm_Status_dropdownvalues("7 days");
			scmePage.clicksavebutton();

			/**************************************************************************************************************/
			extentReport.info(
					"900 V Verify Checkbox Verify Monitor Patient�s Direct Alert� Check status� can be check or uncheck in edit mode. <ClncMgt33080>");
			scmePage.ClickEditButton();
//			assertion.assertEqualsWithReporting(true,
//					scmePage.verifyMonitorPatientDirect_Alert_Checkbox("Uncheck"),--need to fix 
//					extentReport, "Monitor Patient�s Direct Alert� Check status� is uncheck in edit mode is displayed");

			/**************************************************************************************************************/
			extentReport.info(
					"1000 V Verify The default dropdown value provided = {Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} is possible to selected & save on Scheduling messaging page. <ClncMgt33080>");
//need to fix--			assertion.assertEqualsWithReporting(true,
//					scmePage.verifyMonitorPatientDirect_Alert_dropdownvalues("Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14"),
//					extentReport,
//					"default dropdown value provided = {Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} is displayed");
//need to fix--			assertion.assertTrue(scmePage.selectMonitorPatientDirect_Alert_dropdownvalues("7"));
			assertion.assertTrue(scmePage.clicksavebutton());

			/**************************************************************************************************************/

			appHomeTopNavPage.clickSignOutLink();

			

			/**************************************************************************************************************/
			extentReport.info(
					"1100 S Login with Test setup 2 and navigate to Clinic Administration tab > Scheduling & Messaging page.");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			LeftNavPage.navigateToSchedMessagingPage();			
			assertion.assertEqualsWithReporting(true, scmePage.verifyLandingPage(), extentReport,
					"Scheduling & Messaging page is displayed");

			/**************************************************************************************************************/
			extentReport.info(
					"1200 V Verify that under Disconnected Transmitter Thresholds section > Patient with Mobile App Transmitter displayed in view mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyAppUnderSection("Patients with Mobile App transmitters:",
							"DISCONNECTED TRANSMITTER THRESHOLDS"),
					extentReport, "Patient with Mobile App Transmitter displayed in view mode is displayed");

			/**************************************************************************************************************/
			extentReport.info(
					"1300 V Verify Monitor patient�s transmitter communication status checkbox is displayed and default drop down default value 7days in view mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifycheckboxanddefaultvalue("Monitor patient�s transmitter communication status:", "7"),
					extentReport, "default drop down default value 7 days in view mode is displayed");

			/**************************************************************************************************************/
			extentReport.info(
					"1400 V Verify Monitor Patient�s Direct Alert� Check status checkbox is displayed and default drop down default value 7days in view mode. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifycheckboxanddefaultvalue("Monitor patient�s DirectAlert� Check status:", "7"),
					extentReport, "default drop down default value 7 days in view mode is displayed");

			/**************************************************************************************************************/
			extentReport
					.reportInfo("1500 S Click on the edit button and Verify the page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true, scmePage.ClickEditButton(), extentReport,
					"Verify the page is opened in edit mode is displayed");

			/**************************************************************************************************************/
			extentReport.info(
					"1600 V Verify Checkbox 'monitor patient�s transmitter communication status� can be check or uncheck in edit mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyMoniterPatientTranComm_Status_Checkbox("check"),
					extentReport, "monitor patient�s transmitter communication status� can be check");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyMoniterPatientTranComm_Status_Checkbox("Uncheck"),
					extentReport, "monitor patient�s transmitter communication status� can be Uncheck");

			/**************************************************************************************************************/
			extentReport.info(
					"1700 V Verify default dropdown value provided = {Off, 3, 4, 5, 6, 7} is possible to selected & get saved on Scheduling messaging page and save the changes. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true,
					scmePage.verifyMoniterPatientTranComm_Status_dropdownvalues("Off, 3, 4, 5, 6, 7"),
					extentReport, "default dropdown value provided = {Off, 3, 4, 5, 6, 7} is displayed");
			assertion.assertTrue(
					scmePage.selectMoniterPatientTranComm_Status_dropdownvalues("7"));

			/**************************************************************************************************************/
			extentReport.info(
					"1800 V Verify Checkbox Verify Monitor Patient�s Direct Alert� Check status� can be check or uncheck in edit mode. <ClncMgt33080>");

			assertion.assertEqualsWithReporting(true,
					scmePage.verifyUserCapabilityDirectAlertCheckbox("check", "Enabled"),
					extentReport, "Monitor Patient�s Direct Alert� Check status� can be check in edit mode");

			assertion.assertEqualsWithReporting(true,
					scmePage.verifyUserCapabilityDirectAlertCheckbox("Uncheck","Disabled"),
					extentReport, "Monitor Patient�s Direct Alert� Check status� can be Uncheck in edit mode");
			/**************************************************************************************************************/
			extentReport.info(
					"1900 V Verify The default dropdown value provided = {Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} is possible to selected & save on Scheduling messaging page. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(true, scmePage.verifyMonitorPatientDirect_Alert_dropdownvalues("Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14"), extentReport,
					"default dropdown value provided = {Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} is displayed");
			
			assertion.assertTrue(scmePage.selectMonitorPatientDirect_Alert_dropdownvalues("7"));
			assertion.assertTrue(scmePage.clicksavebutton());

			/**************************************************************************************************************/

			appHomeTopNavPage.clickSignOutLink();
			
			/**************************************************************************************************************/

			extentReport.info(
					"2000 S Login with Test setup 3 and navigate to Clinic Administration tab > Scheduling & Messaging page.");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			LeftNavPage.navigateToSchedMessagingPage();			
			assertion.assertEqualsWithReporting(true, scmePage.verifyLandingPage(), extentReport,
					"Scheduling & Messaging page is displayed");
			/**************************************************************************************************************/
			extentReport.info(
					"2100 V Verify that under Disconnected Transmitter Thresholds section > Patient with Mobile App Transmitter displayed in view mode <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true, scmePage.verifyAppUnderSection("Patients with Mobile App transmitters:",
					"DISCONNECTED TRANSMITTER THRESHOLDS"), extentReport,
					"Under Disconnected Transmitter Thresholds section > Patient with Mobile App Transmitter displayed in view mode is displayed");
			
			/**************************************************************************************************************/
			extentReport.info(
					"2200 V Verify Monitor patient�s transmitter communication status checkbox is displayed and default drop down default value 7days in view mode. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true, scmePage.verifycheckboxanddefaultvalue("Monitor patient�s transmitter communication status:", "7"), extentReport,
					"Default drop down default value 7days in view mode is displayed");
			
			/**************************************************************************************************************/
			extentReport.info(
					"2300 V Verify Monitor Patient�s Direct Alert� Check status checkbox is displayed and default drop down default value 7days in view mode. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(true, scmePage.verifycheckboxanddefaultvalue("Monitor patient�s DirectAlert� Check status:", "7"), extentReport,
					"Default drop down default value 7days in view mode is displayed");
			
			/**************************************************************************************************************/
			extentReport
					.reportInfo("2400 S Click on the edit button and Verify the page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true, scmePage.ClickEditButton(), extentReport,
					"The page is opened in edit mode.");
			
			/**************************************************************************************************************/
			extentReport.info(
					"2500 V Verify Checkbox 'monitor patient�s transmitter communication status� can be check or uncheck in edit mode. <ClncMgt33077>, <ClncMgt33078>");

			assertion.assertEqualsWithReporting(true, scmePage.verifyMoniterPatientTranComm_Status_Checkbox("check"), extentReport,
					"Monitor patient�s transmitter communication status� can be check is displayed");
assertion.assertEqualsWithReporting(true, scmePage.verifyMoniterPatientTranComm_Status_Checkbox("Uncheck"), extentReport,
					"Monitor patient�s transmitter communication status� can be Uncheck is displayed");
			
			/**************************************************************************************************************/
			extentReport.info(
					"2600 V Verify default dropdown value provided = {Off, 3, 4, 5, 6, 7} is possible to selected & get saved on Scheduling messaging page and save the changes. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(true, scmePage.verifyMoniterPatientTranComm_Status_dropdownvalues("Off, 3, 4, 5, 6, 7"), extentReport,
					"default dropdown value provided = {Off, 3, 4, 5, 6, 7} is displayed");
			
			Assert.assertTrue(scmePage.selectMoniterPatientTranComm_Status_dropdownvalues("7"));
			/**************************************************************************************************************/
			extentReport.info(
					"2700 V Verify Checkbox Verify Monitor Patient�s Direct Alert� Check status� can be check or uncheck in edit mode. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(true, scmePage.verifyUserCapabilityDirectAlertCheckbox("check", "Enabled"), extentReport,
					"Monitor Patient�s Direct Alert� Check status� check is displayed");
			

assertion.assertEqualsWithReporting(true, scmePage.verifyUserCapabilityDirectAlertCheckbox("Uncheck", "Disabled"), extentReport,
					"Monitor Patient�s Direct Alert� Check status� Uncheck is displayed");
			
			/**************************************************************************************************************/
			extentReport.info(
					"2800 V Verify The default dropdown value provided = {Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} is possible to selected & save on Scheduling messaging page. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(true, scmePage.verifyMonitorPatientDirect_Alert_dropdownvalues("Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14"), extentReport,
					"default dropdown value provided = {Off, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14} is displayed");
			assertion.assertTrue(scmePage.selectMonitorPatientDirect_Alert_dropdownvalues("7"));
			assertion.assertTrue(scmePage.clicksavebutton());

			/**************************************************************************************************************/

			appHomeTopNavPage.clickSignOutLink();

			/**************************************************************************************************************/

			extentReport.info(
					"2900 S Login with Test setup 5 and navigate to Clinic Administration tab > Scheduling & Messaging page. <Negative Scenario>");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			LeftNavPage.navigateToSchedMessagingPage();			
			assertion.assertEqualsWithReporting(true, scmePage.verifyLandingPage(), extentReport,
					"Scheduling & Messaging page is displayed");
			/**************************************************************************************************************/
			extentReport.info(
					"3000 V Verify that under Disconnected Transmitter Thresholds section > Patient with Mobile App Transmitter is not displayed. <ClncMgt33077>, <ClncMgt33078>");
			assertion.assertEqualsWithReporting(false, scmePage.verifyAppUnderSection("Patients with Mobile App transmitters:",
					"DISCONNECTED TRANSMITTER THRESHOLDS"), extentReport,
					"Disconnected Transmitter Thresholds section > Patient with Mobile App Transmitter is not displayed");
			
			/**************************************************************************************************************/
			extentReport.info(
					"3100 V Verify that under Disconnected Transmitter Thresholds section > Monitor Patient�s Direct Alert� Check status is not displayed. <ClncMgt33080>");
			assertion.assertEqualsWithReporting(false, scmePage.verifyAppUnderSection("Monitor Patient�s Direct Alert� Check status",
					"DISCONNECTED TRANSMITTER THRESHOLDS"), extentReport,
					"Disconnected Transmitter Thresholds section > Monitor Patient�s Direct Alert� Check status is not displayed");
			
			/**************************************************************************************************************/
			extentReport.takeFullSnapShot(driver,
					"3100 V Verify that under Disconnected Transmitter Thresholds section > Monitor Patient�s Direct Alert� Check status is not displayed. <ClncMgt33080>");
			extentReport.info("Test case ends");

		} catch (AssertionError e) {
			extentReport
					.reportFail("Monitor_Patients_Transmitter_Communication Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail(
					"WA_11_EP_ClinicAdmin_MonitorPatientsTransmitterCommunication_DirectAlert_CheckStatus Validation not  successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}