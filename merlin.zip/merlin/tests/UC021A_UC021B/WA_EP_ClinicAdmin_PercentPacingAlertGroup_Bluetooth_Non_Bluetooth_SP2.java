package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class WA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth_Non_Bluetooth_SP2 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_ClinicProfilePage ca_clinicProfilePage;
	CA_LeftNavPage ca_leftNavPage;
	Customer customer;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	TestDataProvider testDataProvider;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage ca_MerlinAtHome_Transmit_Page;
	CA_ClinicAdminMobAppTransPage ca_ClinicAdminMobAppTransPage;
	CA_SchedulingAndMessagingPage ca_SchedulingAndMessagingPage;

	
    @BeforeClass
	public void initialize() {
    	driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		ca_leftNavPage = new CA_LeftNavPage(driver, extentReport);
		ca_MerlinAtHome_Transmit_Page =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		ca_ClinicAdminMobAppTransPage= new CA_ClinicAdminMobAppTransPage(driver,extentReport);
		ca_SchedulingAndMessagingPage=new CA_SchedulingAndMessagingPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		commonUtils=new CommonUtils();
		
	}
 // Testcase id: 1227888, Author- Shanmugapriya
//  Testcase name: 11.0_WA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth&Non-Bluetooth_SP2
    
	@Test
	public void UC021AUC021B_WA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth_Non_Bluetooth_SP2() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("Priyam");
		extentTest.assignAuthor("Author - Shanmugapriya");
	
		try {
			Assertions assertions=new Assertions(extentTest);
			
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >SP2 Alerts Settings");		
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is displayed");
			
			extentReport.info( "200 V Verify that under SP2 Alerts Settings, Merlin@home Transmitter tab is available and navigate to SP2 Alerts� Settings for Non-Bluetooth ICD/ CRT-D devices page.", new String[] {"ClncMgt33113"});
			ca_leftNavPage.navigateToMerlinHomeTransmitterPage();
			assertions.assertEqualsWithReporting(true, ca_MerlinAtHome_Transmit_Page.verifyLandingPage(), extentReport, "Merlin@home tab is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to MerlinAtHome Transmitter page");
			
			extentReport.info("300 S Click on edit button, and check the page is opened in edit mode");
			ca_MerlinAtHome_Transmit_Page.verifyEditMode();
			extentReport.reportScreenShot("MerlinAtHome Transmitter page is opened in edit mode");
			
			extentReport.info( "400 S Change few Alerts Categories (Urgent, standard or Off) for percent pacing alert group and click on save button.");
			String changeAlertClassification = ca_MerlinAtHome_Transmit_Page.changeAlertClassification("Tachy Therapy Disabled");
//			ca_MerlinAtHome_Transmit_Page.clickSave();
			extentReport.reportScreenShot("Alert categories- for percent pacing have been changed and clicked save button");
			
			//need to change
			extentReport.info( "500 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved. <ClncMgt33113>");
			assertions.assertEqualsWithReporting(true, ca_MerlinAtHome_Transmit_Page.verifyAlertClassification("Tachy Therapy Disabled",changeAlertClassification), extentReport, "Percent pacing alerts get saved");
			extentReport.reportScreenShot("Alert categories- for percent pacing alert are editable and changes get saved");
			
			//need to change
			extentReport.info( "600 V Verify pop up is displayed by webpage for confirmation Click on OK.", new String[] {"ClncMgt33113"});
			assertions.assertEqualsWithReporting(true, ca_MerlinAtHome_Transmit_Page.VerifySavepopupandclick(), extentReport, "Pop up is displayed by webpage for confirmation Click on OK");
			extentReport.reportScreenShot("User is able to see pop up in webpage for confirmation");
			ca_MerlinAtHome_Transmit_Page.clickOkButton();
			extentReport.reportScreenShot("User is able to click Ok button");
			
			//need to change
			extentReport.info( "700 V Verify the changes are saved.", new String[] {"ClncMgt33113"});
			assertions.assertEqualsWithReporting(true, ca_MerlinAtHome_Transmit_Page.verifyAlertClassification("Tachy Therapy Disabled",changeAlertClassification), extentReport, "Percent pacing alerts get saved");
			extentReport.reportScreenShot("User is able to see the changes are saved");
			
			extentReport.info( "800 V Enhanced diagnostics collection feature has been Disabled on Scheduling & Messaging page for the clinic.");
			ca_leftNavPage.navigateToSchedulingMessagingPage();
			assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "SchedulingAndMessagingPage is displayed");
			ca_SchedulingAndMessagingPage.verifyEnhancedDiagnosticsCollection();
			assertions.assertEqualsWithReporting(false, ca_SchedulingAndMessagingPage.verifyEnhancedDiagnosticsCollection(), extentReport, "Enhanced collection feature is Disabled");
			extentReport.reportScreenShot("Enhanced diagnostics collection feature has been disabled");
			
			extentReport.info( "900 V  Verify Alerts Categories (Urgent, standard or Off) are NOT editable for percent pacing alert group", new String[]{"ClncMgt33112"});
			//need to change
			clinicianHomeTopNavPage.clickSignOutLink();
			
			extentReport.info( "800 S Login with Test setup 1 and navigate to Clinic Administration tab >SP2 Alerts Settings.");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is displayed");
			
			extentTest=extentReport.info( "900 V Verify that under SP2 Alerts Settings, Mobile App Transmitter tab is available and navigate to SP2 Alerts� Settings for Bluetooth ICD/ CRT-D devices page. <ClncMgt33113> ");
			ca_leftNavPage.navigateToMobileAppTransmitterPage();
			assertions.assertEqualsWithReporting(true, ca_ClinicAdminMobAppTransPage.verifyLandingPage(), extentReport, "MobileAppTransmistter tab is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to MobileApp Transmitter page");
			
			extentTest=extentReport.info( "1000 S Click on edit button, and check the page is opened in edit mode.");
			ca_ClinicAdminMobAppTransPage.clickClinicEditButton();
			extentReport.reportScreenShot("Mobileapp Transmitter page is opened in edit mode");
			
			//need to change
			extentReport.info( "1100 S Change few Alerts Categories (Urgent, standard or Off) for percent pacing alert group and click on save button. ");
			String alertClassification = ca_ClinicAdminMobAppTransPage.changeAlertClassification("Tachy Therapy Disabled");
//			ca_MerlinAtHome_Transmit_Page.clickSave();
			extentReport.reportScreenShot("Alert categories- for percent pacing have been changed and clicked save button");
			
			//need to change
			extentReport.info( "1200 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved. <ClncMgt33113>");
			assertions.assertEqualsWithReporting(true, ca_ClinicAdminMobAppTransPage.verifyAlertClassification("Tachy Therapy Disabled",changeAlertClassification), extentReport, "Percent pacing alerts get saved");
			extentReport.reportScreenShot("Alert categories- for percent pacing alert are editable and changes get saved");
			
			//need to change
			extentReport.info( "1300 V Verify pop up is displayed by webpage for confirmation Click on OK.", new String[] {"ClncMgt33113"});
			assertions.assertEqualsWithReporting(true, ca_ClinicAdminMobAppTransPage.VerifySavepopupandclick(), extentReport, "Pop up is displayed by webpage for confirmation Click on OK");
			extentReport.reportScreenShot("User is able to see pop up in webpage for confirmation");
			ca_ClinicAdminMobAppTransPage.clickOkButton();
			extentReport.reportScreenShot("User is able to click Ok button");
			
			//need to change
			extentReport.info( "1400 V Verify the changes are saved.", new String[] {"ClncMgt33113"});
			assertions.assertEqualsWithReporting(true, ca_ClinicAdminMobAppTransPage.verifyAlertClassification("Tachy Therapy Disabled",changeAlertClassification), extentReport, "Percent pacing alerts get saved");
			extentReport.reportScreenShot("User is able to see the changes are saved");
		
			assertion.assertAll();
		}
		
		catch (AssertionError e) {
			 extentReport.reportFail( "WA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth_Non_Bluetooth_SP2 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "WA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth_Non_Bluetooth_SP2 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}

}
