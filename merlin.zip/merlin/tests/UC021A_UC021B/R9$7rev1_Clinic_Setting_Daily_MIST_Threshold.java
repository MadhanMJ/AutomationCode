package com.test.qa.ui.tests.UC021A_UC021B;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_Transmitter;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

/*
 * Author: Poojitha Gangiri
 * Test case name: R9.7rev1_Clinic_Setting_Daily_MIST_Threshold
 */
public class R9$7rev1_Clinic_Setting_Daily_MIST_Threshold extends CommonUtils {
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	PatientListPage patientListPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	CA_SchedulingAndMessagingPage ca_SchedulingAndMessagingPage;
	PL_PatientProfile_LeftNavPage pl_PatientProfile_LeftNavPage;
	PL_PatientProfile_Transmitter pl_PatientProfile_transmitter;
	LoginPageWithPOJO loginPage;
	Login mist_User;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	CommonUtils utils;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	
	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);	
		ca_SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);		
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);		
		pl_PatientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_PatientProfile_LeftNavPage = new PL_PatientProfile_LeftNavPage(driver,extentReport);
		pl_PatientProfile_transmitter = new PL_PatientProfile_Transmitter(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		mist_User = new Login();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
	}

	@Test
	public void TC_R9$7rev1_Clinic_Setting_Daily_MIST_Threshold() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		mist_User = testDataProvider.getLoginData("DailyMistThreshold_User1");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		try {
			assertion =  new Assertions(extentTest);
			//Login with Clinic user as per test data scenario1
			extentReport.info("100 S Login to a clinic with test data setup as per scenario 1");			
			loginPage.login(mist_User);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			//Navigate to Scheduling and Messaging Page		
			extentReport.info("200 S Navigate to Scheduling and Messaging page");			
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			
			extentReport.info("300 V Verify the Disconnected Transmitter Thresholds settings are available for all three sections\r\n"
					+ " Cardiac monitor(if ICM pacemakes patients are available in the clinic)\r\n"
					+ " ICD/Pacemaker\r\n"
					+ " Battery Advisory patients",new String[] {"ClncMgt32093"});
			//softAssert.assertEquals(ca_SchedulingAndMessagingPage.verifyAppUnderSection("Disconnected Transmitter Thresholds","Patients with Mobile App transmitters:"), true);
			//softAssert.assertEquals(ca_SchedulingAndMessagingPage.verifyAppUnderSection("Disconnected Transmitter Thresholds","Patients with Merlin@home transmitters:"), true);
			//softAssert.assertEquals(ca_SchedulingAndMessagingPage.verifyAppUnderSection("Disconnected Transmitter Thresholds","Battery Advisory Patients:"), true);			
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyAppUnderSection("Disconnected Transmitter Thresholds","Patients with Mobile App transmitters:"),extentReport,"Patients with Mobile App transmitters section is displayed");
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyAppUnderSection("Disconnected Transmitter Thresholds","Patients with Merlin@home transmitters:"),extentReport,"Patients with Merlin@home transmitters section is displayed");
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyAppUnderSection("Disconnected Transmitter Thresholds","Battery Advisory Patients:"),extentReport,"Battery Advisory Patients section is displayed");
			
			extentReport.info("400 V Verify User is able to edit and save the MIST settings for all the sections",new String[] {"ClncMgt32093"});
			ca_SchedulingAndMessagingPage.editAndSaveMIST();
			extentReport.reportScreenShot("User us able to edit and save the data successfully");
			
			extentReport.info("500 V Verify Daily MIST when transmitting daily (Battery) Checkbox is not displayed",new String[] {"ClncMgt32277"});
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Daily MIST"),extentReport,"Daily MIST checkbox is unselected");
			extentReport.reportScreenShot("Daily MIST checkbox is unselected under Battery advisory section is disabled");
			
			//Signing out from the application		
			appHomeTopNavPage.clickSignOutLink();
			
			//Login with Clinic user as per test data scenario3					
			extentReport.info("600 S Login to a clinic with test data set-up as per scenario 3");
			mist_User = testDataProvider.getLoginData("DailyMistThreshold_User3");
			loginPage.login(mist_User);		
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			//Navigate to Scheduling and Messaging Page
			extentReport.info("700 S Navigate to Scheduling and Messaging page");	
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging  Page is displayed");
			
			extentReport.info("800 S Verify Daily MIST when transmitting daily (Battery) Checkbox is  displayed and Off by default", new String[] {"ClncMgt32277"});	
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Daily MIST"),extentReport,"Scheduling and Messaging  Page is displayed");
			extentReport.reportScreenShot("Daily MIST when transmitting daily (Battery) Checkbox is  displayed and Off by default");
			
			extentReport.info("900 S Verify the user is able to check/uncheck 'Daily MIST when transmitting daily (Battery)' check box", new String[] {"ClncMgt32277"});	
			ca_SchedulingAndMessagingPage.clickEditButton();
			ca_SchedulingAndMessagingPage.clickCheckBox("Battery Advisory Daily MIST");
			extentReport.reportScreenShot("User is able to edit daily MIST when transmitting daily (Battery) Checkbox");
			
			extentReport.info("1000 V Turn Off monitoring for MIST threshold settings for BA ' Monitor patient’s transmitter communication status checkbox");	
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Patient Status"),extentReport,"Scheduling and Messaging  Page is displayed");
			ca_SchedulingAndMessagingPage.clickCheckBox("Battery Advisory Patient Status");
			ca_SchedulingAndMessagingPage.clickSaveButton();
			extentReport.reportScreenShot("MIST threshold settings for BA ' Monitor patient’s transmitter communication status checkbox is unselected");
			
			extentReport.info("1100 V Verify all the Check boxes in the Section are unchecked");
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is loaded after saving the details");
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Patient Status"),extentReport,"Transmitter communication section checkbox under Battery advisory section is unselected");
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Daily MIST"),extentReport,"Daily MIST checkbox under Battery advisory section is unselected");
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Device Check"),extentReport,"NODC checkbox under Battery advisory section is unselected");
									
			//Signing out from the application
			
			appHomeTopNavPage.clickSignOutLink();
			
			//Login with Clinic user as per test data scenario 5
			extentReport.info("1200 S Login to a clinic with test data set-up as per scenario 5");		
			mist_User = testDataProvider.getLoginData("DailyMistThreshold_User5");
			loginPage.login(mist_User);		
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			//Navigate to Scheduling and Messaging Page
			extentReport.info("1300 S Navigate to Scheduling and Messaging page");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging  Page is displayed");
			
			extentReport.info("1400 V Verify Daily MIST when transmitting daily (Battery) Checkbox is  displayed and Off by default", new String[] {"ClncMgt32277"});
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Daily MIST"),extentReport,"Scheduling and Messaging  Page is displayed");
			extentReport.reportScreenShot("Daily MIST when transmitting daily (Battery) Checkbox is  displayed and Off by default");
			
			extentReport.info("1500 V Verify the user is able to check/uncheck 'Daily MIST when transmitting daily (Battery)' check box", new String[] {"ClncMgt32277"});
			ca_SchedulingAndMessagingPage.clickEditButton();
			ca_SchedulingAndMessagingPage.clickCheckBox("Battery Advisory Daily MIST"); //need to check with Shafiya
			extentReport.reportScreenShot("User is able to edit daily MIST when transmitting daily (Battery) Checkbox");
			
			extentReport.info("1600 V Check 'Daily MIST when transmitting daily (Battery)' check box");
			ca_SchedulingAndMessagingPage.clickSaveButton();
			extentReport.reportScreenShot("User is able to select and save Daily MIST checkbox");
			
			extentReport.info("1700 V Verify MIST threshold settings for BA ' Monitor patient’s transmitter communication status' is retained and\r\n"
					+ "  dropdown values are displayed and user is able to edit the threshold settings", new String[] {"ClncMgt32093"});
			assertion.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("10 days","Battery Advisory Patient Status", "View Mode"), true, "Merlin Home - Device check status default value is 10");
			ca_SchedulingAndMessagingPage.clickEditButton();
			ca_SchedulingAndMessagingPage.clickPatientTransmitter_DeviceCheck_DropdownBox("Battery Advisory Patient Status");
			ca_SchedulingAndMessagingPage.selectValueFromDropdown("Battery Advisory Patient Status");// This method need to be edited to be generic
			ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			   
			
			extentReport.info("1800 V Verify for Patients with conditions as per the data section of scenario 5 ,\r\n"
					+ "-  The MIST threshold setting for the Patient is set to 1 day\r\n"
					+ "-  The current MIST threshold is not saved to the DB", new String[] {"Clnc32278","CommFn921"});
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToTransmitter();
			assertion.assertEqualsWithReporting(pl_PatientProfile_transmitter.getDailyMISTValue(), "1 day",extentReport, " Daily MIST value is displayed as 1day");
			
			
			//Signing out from the application
			
			appHomeTopNavPage.clickSignOutLink();
			
			//Login with Clinic user as per test data scenario 7
			
			extentReport.info("1900 S Login to a clinic with test data set-up as per scenario 7");		
			mist_User = testDataProvider.getLoginData("DailyMistThreshold_User7");
			loginPage.login(mist_User);		
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			//Navigate to Scheduling and Messaging Page
			
			extentReport.info("2000 S Navigate to Scheduling and Messaging page");	
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			
			extentReport.info("2100 V Uncheck Daily MIST when transmitting daily (Battery) Checkbox for BA patients section", new String[] {"ClncMgt32277"});
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Daily MIST"),extentReport,"Scheduling and Messaging Page is displayed");
			ca_SchedulingAndMessagingPage.clickEditButton();
			ca_SchedulingAndMessagingPage.clickCheckBox("Battery Advisory Daily MIST"); 
			ca_SchedulingAndMessagingPage.clickSaveButton();
			extentReport.reportScreenShot("User is able to uncheck and save Daily MIST checkbox");
			
			extentReport.info("2200 V Verify MIST threshold settings for BA ' Monitor patient’s transmitter communication status' is retained and\r\n"
					+ "  dropdown values are displayed and user is able to edit the threshold settings", new String[] {"ClncMgt32093"});
			assertion.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("10 days","Battery Advisory Patient Status","View Mode"), true, "Merlin Home - Device check status default value is 10");
			ca_SchedulingAndMessagingPage.clickEditButton();
			ca_SchedulingAndMessagingPage.clickPatientTransmitter_DeviceCheck_DropdownBox("Battery Advisory Patient Status");
			ca_SchedulingAndMessagingPage.selectValueFromDropdown("Battery Advisory Patient Status");// This method need to be edited to be generic
			ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			
			extentReport.info("2300 V Verify for Patients with conditions as per the data section of scenario 7 ,\r\n"
					+ "-  Patient threshold defaults to saved MIST Threshold settings from DB\r\n"
					+ "-  The current MIST threshold is not saved to the DB", new String[] {"Clnc32278","CommFn921","CommFn918"});
			String query = "select patient_ba_mist_threshold, patient_ba_nodc_threshold,clinic_pbd_mist_threshold, clinic_pbd_nodc_threshold from patients.v_patient_with_disconn_transmtr vpwdt where first_name  = 'Radhya';";
			databaseResults = queryResults.patientTable_TC1238688(query);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToTransmitter();
			assertion.assertEqualsWithReporting(pl_PatientProfile_transmitter.getDailyMISTValue(), "1 day",extentReport, " Daily MIST value is displayed as 1day");
			assertion.assertEquals(databaseResults.get("patient_ba_mist_threshold"),pl_PatientProfile_transmitter.getDailyMISTValue(),"Clinic name field is verified");
			
			
			//Signing out from the application
			
			appHomeTopNavPage.clickSignOutLink();
			
			//Login with Clinic user as per test data scenario 22
			
			extentReport.info("2400 S Login to a clinic with test data set-up as per scenario 22");	
			mist_User = testDataProvider.getLoginData("DailyMistThreshold_User22");
			loginPage.login(mist_User);		
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			//Navigate to Scheduling and Messaging Page		
			extentReport.info("2500 S Navigate to Scheduling and Messaging page");	
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			
			extentReport.info("2600 S Add the clinic's country or Jurisdiction to the Suppressed list in the Webapp server property file");
			// Have to check with Rajesh on this step
			
			extentReport.info("2700 V Verify 'Daily MIST when transmitting daily (Battery)' check box  is not displayed", new String[] {"CommFn918"});
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Daily MIST"),extentReport,"Scheduling and Messaging  Page is displayed");
			extentReport.reportScreenShot("Daily MIST when transmitting daily (Battery) Checkbox is  displayed and Off by default");
			
			extentReport.info("2800 V Verify for patients with 1 day Mist , defaults to Current Clinic level BA MIST settings if no previous MIST settings are saved for the Patient", new String[] {"ClncMgt32283"});
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToTransmitter();
			assertion.assertEqualsWithReporting(pl_PatientProfile_transmitter.getDailyMISTValue(), "1 day",extentReport, " Daily MIST value is displayed as 1day");
			
			extentReport.info("2900 V Verify for Patients with previous MIST threshold saved set the threshold is set to Saved value in DB", new String[] {"ClncMgt32283"});
			query = "select patient_ba_mist_threshold, patient_ba_nodc_threshold,clinic_pbd_mist_threshold, clinic_pbd_nodc_threshold from patients.v_patient_with_disconn_transmtr vpwdt where first_name  = 'Radhya';";
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToTransmitter();
			assertion.assertEqualsWithReporting(pl_PatientProfile_transmitter.getDailyMISTValue(), "1 day",extentReport, " Daily MIST value is displayed as 1day");
						
			assertion.assertAll();
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}

}
