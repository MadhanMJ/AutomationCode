package com.test.qa.ui.tests.UC021A_UC021B;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import com.test.qa.assertions.Assertions;

import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
public class WA_11_EP_ClinicAdmin_Patient_Notification_for_Direct_Alerts_01 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	Login login;
	Login loginClinicUser_withoutICDDevice;
	CA_SchedulingAndMessagingPage scmePage;
	ClinicianHomeTopNavPage appHomeTopNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page Pacemaker_CRTP_Page;
	CA_DirectAlert_CardiacMonitorPage CardiacMonitorPage;
	CA_ClinicAdminMobAppTransPage MobAppTransPage;
	CA_LeftNavPage LeftNavPage;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		scmePage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		appHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		Pacemaker_CRTP_Page = new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		CardiacMonitorPage = new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		LeftNavPage = new CA_LeftNavPage(driver, extentReport);
	}

	@Test
	public void ClinicAdmin_Patient_Notification_for_Direct_Alerts_01_TS1() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("JitClinic");
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Jeetendra Gupta");// comments
		try {
			Assertions softassert = new Assertions(extentTest);

//			Thread.sleep(3000);
			loginPage.login(loginClinicUser_withoutICDDevice);

//			*********Test Setup 1****for 1) Non- Bluetooth Device ********
			extentReport.info(
					"100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			LeftNavPage.clickMerlinHomeTransmitterLink();
			LeftNavPage.verifyMerlinHomeTransmitterTab();
//			scmePage.leftpaneTabNavigation("Merlin@home Transmitter");

			extentReport.info(
					"200 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and navigate to Direct Alerts� Settings for Non-Bluetooth ICD/ CRT-D devices page. <ClncMgt33041>");
			LeftNavPage.verifyMerlinHomeTransmitterTab();

			extentReport.info(
					"300 V Verify Patient Notification/Inform Patient check box for direct alert are displayed & default value is OFF <ClncMgt33041> ><Config289>");
			MerlinAtHomePage.verifyPatientNotificationcheckboxState("DirectAlerts� Settings", "OFF");
//			Alert Classification of values,
//
//			"Urgent" <data.Code.Severity_Cd.Code_Desc.URG>
//
//			"Standard" <data.Code.Severity_Cd.Code_Desc.STD>
//
//			"Don't Select" <data.Code.Severity_Cd.Code_Desc.DSL>
//
//			default setting is = "Urgent"
			MerlinAtHomePage.verifyAlertTypeDefaultState("DirectAlerts� Settings", "RED");
//			2. Inform Patient checkbox,
//
//			"on" <data.Code.On_Off_Values_Cd.Code_Desc.ON>
//
//			"off" <data.Code.On_Off_Values_Cd.Code_Desc.OFF>
//
//			default = "off" 
			MerlinAtHomePage.verifyPatientNotificationcheckboxState("DirectAlerts� Settings", "OFF");
			extentReport.info("400 S Click on edit button, and check the page is opened in edit mode.");

			MerlinAtHomePage.ClickEditButton();
			extentReport.info(
					"500 V Verify Patient Notification/Inform Patient check box for direct alert are editable. <ClncMgt33041>");
			MerlinAtHomePage.verifyPatientNotificationcheckboxState("DirectAlerts� Settings", "Editable");

			extentReport.info(
					"600 S Select Patient Notification/Inform Patient (ON or Off) for alerts and click on save button. <ClncMgt33041>");
			MerlinAtHomePage.SelectPatientNotificationcheckbox("DirectAlerts� Settings", "ON");
			MerlinAtHomePage.clickSave();

			extentReport
					.info("700 V Verify pop up is displayed by webpage for confirmation Click on OK. <ClncMgt33041>");
			MerlinAtHomePage.verifyandclickAlert();

			extentReport.info("800 V Verify changes are saved pop up is displayed and click on OK. <ClncMgt33041>");
			MerlinAtHomePage.VerifySavepopupandclick();

			extentReport.info("900 V Verify the changes are saved. <ClncMgt33041>");
			MerlinAtHomePage.verifychangesonPage();

			/***************************************************************/

//			2) Pacemaker Device

			extentReport.info(
					"1000 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available and navigate to Direct Alerts� Settings for Pacemaker/ CRT-P devices page. <ClncMgt33041>");
			LeftNavPage.verifypacemaker_CRTPLink();
			LeftNavPage.clickpacemaker_CRTPLink();
//			scmePage.verifyleftpanesubtab("DirectAlerts� Settings","Pacemaker/ CRT-P");
//			scmePage.clicklink("Pacemaker / CRT-P");
			extentReport.info(
					"1100 V Verify Patient Notification/Inform Patient check box for direct alert are displayed default value is OFF. <ClncMgt33041><Config21469>");
			Pacemaker_CRTP_Page.verifyPatientNotificationcheckboxState("Pacemaker / CRT-P", "OFF");
//			 Alert Classification of values,
//
//			"Urgent" <data.Code.Severity_Cd.Code_Desc.URG>
//
//			"Standard" <data.Code.Severity_Cd.Code_Desc.STD>
//
//			"Don't Select" <data.Code.Severity_Cd.Code_Desc.DSL>
//
//			defaults (Pacemaker/CRT-P)' in the Alerts Software Configuration Specification.
			Pacemaker_CRTP_Page.pacemaker_default_Alert_Config();
//			 2. Inform Patient checkbox,
//
//			"on" <data.Code.On_Off_Values_Cd.Code_Desc.ON>
//
//			"off" <data.Code.On_Off_Values_Cd.Code_Desc.OFF>
//
//			default = "off"   
			Pacemaker_CRTP_Page.verifyPatientNotificationcheckboxState("Pacemaker / CRT-P", "OFF");
			extentReport
					.info("1200 S Click on edit button, and check the page is opened in edit mode. < ClncMgt33041>");
			Pacemaker_CRTP_Page.clickEditButton();
			extentReport.info(
					"1300 V Verify Patient Notification/Inform Patient (ON or Off) check box for percent pacing alert are editable and changes gets saved. < ClncMgt33041>");
			Pacemaker_CRTP_Page.verifyPatientNotificationcheckboxState("Pacemaker / CRT-P", "Editable");
			extentReport.info(
					"1400 S Select Patient Notification/Inform Patient (ON or Off) for percent pacing alert group and click on save button. <ClncMgt33041>");
			Pacemaker_CRTP_Page.SelectPatientNotificationcheckbox("Pacemaker / CRT-P", "ON");
			Pacemaker_CRTP_Page.clickSaveButton();
			extentReport
					.info("1500 V Verify pop up is displayed by webpage for confirmation Click on OK. < ClncMgt33041>");

			Pacemaker_CRTP_Page.verifyandclickAlert();

			extentReport.info("1600 V Verify changes are saved pop up is displayed. <ClncMgt33041>");
			Pacemaker_CRTP_Page.VerifySavepopupandclick();
			extentReport.info("1700 V Verify the changes are saved. <ClncMgt33041>");
			Pacemaker_CRTP_Page.verifychangesonPage();
			appHomeTopNavPage.clickSignOutLink();

//*********Test Setup 2********

			loginPage.login(loginClinicUser_withoutICDDevice);

			extentReport.info(
					"1800 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			LeftNavPage.clickMerlinHomeTransmitterLink();
			LeftNavPage.verifyDirectAlertsICD_CRTDLink();

			extentReport.info(
					"1900 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and navigate to Direct Alerts� Settings for Non-Bluetooth ICD/ CRT-D devices page. <ClncMgt33041>");
//scmePage.verifyleftpanesubtab("DirectAlerts� Settings","Merlin@Home Transmitter");
			LeftNavPage.verifyMerlinHomeTransmitterTab();

			extentReport.info(
					"2000 V Verify Patient Notification/Inform Patient check box for direct alert are displayed & default value is OFF. <ClncMgt33041><Config289>");
			MerlinAtHomePage.verifyPatientNotificationcheckboxState("DirectAlerts� Settings", "OFF");
//Alert Classification of values,
//
//"Urgent" <data.Code.Severity_Cd.Code_Desc.URG>
//
//"Standard" <data.Code.Severity_Cd.Code_Desc.STD>
//
//"Don't Select" <data.Code.Severity_Cd.Code_Desc.DSL>
//
//default setting is = "Urgent"
			MerlinAtHomePage.verifyAlertTypeDefaultState("DirectAlerts� Settings", "RED");
			MerlinAtHomePage.verifyPatientNotificationcheckboxState("DirectAlerts� Settings", "OFF");

//2. Inform Patient checkbox,
//
//"on" <data.Code.On_Off_Values_Cd.Code_Desc.ON>
//
//"off" <data.Code.On_Off_Values_Cd.Code_Desc.OFF>
//
//default = "off" 

			extentReport.info("2100 S Click on edit button, and check the page is opened in edit mode.");
			MerlinAtHomePage.ClickEditButton();

			extentReport.info(
					"2200 V Verify Patient Notification/Inform Patient check box for direct alert are editable. <ClncMgt33041>");
			MerlinAtHomePage.verifyPatientNotificationcheckboxState("DirectAlerts� Settings", "Editable");

			extentReport.info(
					"2300 S Select Patient Notification/Inform Patient (ON or Off) for alerts and click on save button. <ClncMgt33041>");
			MerlinAtHomePage.SelectPatientNotificationcheckbox("DirectAlerts� Settings", "ON");
			MerlinAtHomePage.clickSave();
			extentReport
					.info("2400 V Verify pop up is displayed by webpage for confirmation Click on OK. <ClncMgt33041>");
			MerlinAtHomePage.verifyandclickAlert();

			extentReport.info("2500 V Verify changes are saved pop up is displayed and click on OK. <ClncMgt33041>");
			MerlinAtHomePage.VerifySavepopupandclick();

			extentReport.info("2600 V Verify the changes are saved. <ClncMgt33041>");
			MerlinAtHomePage.verifychangesonPage();

			extentReport.info(
					"2700 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P devices tab is available and navigate to Direct Alerts� Settings for Pacemaker/ CRT-P devices page. <ClncMgt33041>");
			
			LeftNavPage.verifypacemaker_CRTPLink();
			LeftNavPage.clickpacemaker_CRTPLink();

			extentReport.info("2800 S Click on edit button, and check the page is opened in edit mode.");

			Pacemaker_CRTP_Page.clickEditButton();
			Pacemaker_CRTP_Page.verifyPatientNotificationcheckboxState("Pacemaker / CRT-P", "Editable");

			extentReport.info(
					"2900 V Verify Patient Notification/Inform Patient check box for direct alert are displayed default value is OFF. <ClncMgt33041><Config21469>");
			Pacemaker_CRTP_Page.verifyPatientNotificationcheckboxState("Pacemaker / CRT-P", "OFF");

//Alert Classification of values,
//
//"Urgent" <data.Code.Severity_Cd.Code_Desc.URG>
//
//"Standard" <data.Code.Severity_Cd.Code_Desc.STD>
//
//"Don't Select" <data.Code.Severity_Cd.Code_Desc.DSL>
//
//defaults (Pacemaker/CRT-P)' in the Alerts Software Configuration Specification.
//
//2. Inform Patient checkbox,
//
//"on" <data.Code.On_Off_Values_Cd.Code_Desc.ON>
//
//"off" <data.Code.On_Off_Values_Cd.Code_Desc.OFF>
//
//default = "off"   
			Pacemaker_CRTP_Page.pacemaker_default_Alert_Config();
			Pacemaker_CRTP_Page.verifyPatientNotificationcheckboxState("Pacemaker / CRT-P", "OFF");

			extentReport.info(
					"3000 S Select Patient Notification/Inform Patient (ON or Off) for alerts and click on save button. <ClncMgt33041>");
			Pacemaker_CRTP_Page.SelectPatientNotificationcheckbox("Pacemaker / CRT-P", "ON");
			Pacemaker_CRTP_Page.clickSaveButton();

			extentReport.info("3100 V Verify changes are saved pop up is displayed and click on OK. <ClncMgt33041>");
			Pacemaker_CRTP_Page.verifyandclickAlert();
			Pacemaker_CRTP_Page.VerifySavepopupandclick();

			extentReport.info("3200 V Verify the changes are saved. <ClncMgt33041>");
			Pacemaker_CRTP_Page.verifychangesonPage();

			extentReport.info(
					"3300 Verify the alerts classification for which setting is OFF inform patient checkbox is disabled for those specific alerts (negative)  Common for both");
			LeftNavPage.clickMerlinHomeTransmitterLink();
			MerlinAtHomePage.checkPatientcheckbox_with_alertsetting("Merlin@home Transmitter", "OFF", "Disable");
			LeftNavPage.clickpacemaker_CRTPLink();
			Pacemaker_CRTP_Page.checkPatientcheckbox_with_alertsetting("Pacemaker / CRT-P", "OFF", "Disable");

			extentReport.info(
					"3400 S Navigate that under Direct Alerts Settings, Cardiac Monitor tab is available and navigate to Direct Alerts� Settings for ICM devices page AND Verify Patient notification (Inform patient checkbox) is not displayed. <ClncMgt33041> (Negative Scenario)");
			LeftNavPage.verifyCardiacMonitorlink();
			LeftNavPage.clickCardiacMonitor_Link();

			CardiacMonitorPage.checkPatient_notification("Cardiac Monitor", "OFF");
			extentReport.info("3500 V Verify the same for Mobile App Transmitter tab.");
			LeftNavPage.verifyMobileAppTransmitterTab();
			LeftNavPage.clickMobileAppTransmitterLink();

			MobAppTransPage.checkPatient_notification("Mobile App Transmitter", "OFF");
			appHomeTopNavPage.clickSignOutLink();
			extentReport.info("Test Case Ends");
		} catch (AssertionError e) {
			extentReport.reportFail(
					"11.0_WA_EP_ClinicAdmin_Patient_Notification_for_Direct Alerts _01 Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail(
					"11.0_WA_EP_ClinicAdmin_Patient_Notification_for_Direct Alerts _01 Validation not  successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
