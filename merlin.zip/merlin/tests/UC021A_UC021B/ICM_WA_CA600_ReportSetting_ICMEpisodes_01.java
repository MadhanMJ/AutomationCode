package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vinay Babu
 * Test Case: ICM_WA_CA600_ReportSetting_ICMEpisodes_01
 * Report: Good
 */

public class ICM_WA_CA600_ReportSetting_ICMEpisodes_01 extends CommonUtils {

	
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	AppHomeTopNavPage appHomeTopNavPage;
	Log logger;
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withoutICMDevice;
	Login loginAdminUser;
	Login loginClinicUser_withICMDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		
		
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withoutICMDevice = new Login();
		loginClinicUser_withICMDevice = new Login();
		loginAdminUser = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void TC_ICM_WA_CA600_ReportSetting_ICMEpisodes_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		loginAdminUser = testDataProvider.getLoginData("SJMAdmin3");
		loginClinicUser_withoutICMDevice = testDataProvider.getLoginData("SJMClinic2");
		loginClinicUser_withICMDevice = testDataProvider.getLoginData("SJMClinic3");
		extentTest.assignAuthor("Author: Vinay Babu");
		try {
			System.out.println("Login object is:"+ loginClinicUser_withoutICMDevice);	
			extentReport.info("100 S Login to a EP clinic Clinic_1 not having any ICM Device assigned and navigate to Report Settings page in Clinic Admin and Click on Edit.");		
			loginPage.login(loginClinicUser_withoutICMDevice);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToReportSettingsPage();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport,"Report settings Page is displayed");
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(),extentReport,"ReportSettings page is in Edit Mode");
			
			extentReport.info("200 V Verify that on Report Settings page, in All Alerts and Episodes section, option to select Cardiac Monitor Episode is not available",new String[] {"ClncMgt32006"});
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifycardiacMonitorOptionsAvailability(),extentReport,"Cardiac Monitor Options are NOT Available");
			extentReport.reportScreenShot("Cardiac Monitor Options are NOT Available");
			//Assert.assertEquals(clinicSettings_ReportSettingsPage.verifyAllAlertEpisodes_cardiacMonitorOptionsAvailability(), "Cardiac Monitor Options NOT Available");
			//temp to avoid bug. once bug resolved uncomment above and comment below.
			//Assert.assertEquals(clinicSettings_ReportSettingsPage.verifyAllAlertEpisodes_cardiacMonitorOptionsAvailability(), "Cardiac Monitor Options Available");
			
			extentReport.info("300 V Verify that user is able to select other episodes (VT/VF, SVT, AT/AF, Other, NSVT) is available and also able to set number of episodes to be printed for each type.",new String[] {"ClncMgt32013"});
			//assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyAbletoCheckICD_PM_EpisodesWithNumber(),extentReport,"Checking ICD/Pacemaker Episodes is successful");
			clinicianHomeTopNavPage.clickSignOutLink();
			
			extentReport.info("400 S Login to SJM Admin and select clinic Clinic_1 (not having any ICM Device), select to change the clinic and add atleast one ICM Device to the clinic. Save the clinic.");
			loginPage.login(loginAdminUser);
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(),extentReport,"Customers List Page is displayed.");
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_withoutICMDevice.getCustomer());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customers Profile Page is displayed.");			
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer Page is displayed.");
			//List<String> list = new ArrayList<String>();
	        //list.add("Atlas+ /HF /V-340");
	        //list.add("Atlas+ /VR C /V-193C"); //Confirm Rx ICM, DM3500 Jot Dx ICM, DM4500
			//changeCustomerProfilePage.addDevicesToAllowedListAndSave(list);
			changeCustomerProfilePage.addDevicesToAllowedListAndSave(new String[] {"Confirm Rx ICM, DM3500","DM3500 Jot Dx ICM, DM4500"});
			
			appHomeTopNavPage.clickSignOutLink();
			
			////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			extentReport.info("500 S Login to a EP clinic Clinic_1 (now having ICM Device assigned) and navigate to Report Settings page in Clinic Admin");
			
			
			loginPage.login(loginClinicUser_withoutICMDevice);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToReportSettingsPage();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport,"Report settings Page is displayed");
			
			extentReport.info("600 V Verify that on Report Settings page, in All Alerts and Episodes section, option to select Cardiac Monitor Episode is available and is enabled",new String[] {"ClncMgt32006"});
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyAllAlertEpisodes_cardiacMonitorOptionsAvailability(),extentReport,"Cardiac Monitor Options are NOT Available");
			
			extentReport.info("700 S Click on Edit and Select Cardiac Monitor Episode checkbox.");
			clinicSettings_ReportSettingsPage.selectCardiacMonitor_checkbox();
			//Assert.assertEquals(clinicSettings_ReportSettingsPage.selectCardiacMonitor_checkbox(), "Selecting Cardiac Monitor Episodes is successful");
			
			extentReport.info("800 V Verify that user is able to select number of episodes to print for Cardiac Monitor Episode",new String[] {"ClncMgt32013"});
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.clickCardiacMonitorNbrEpisodes_select(),extentReport,"User is able select the episodes");
			
//			Assert.assertEquals(clinicSettings_ReportSettingsPage.clickCardiacMonitorNbrEpisodes_select(), "Clicking Cardiac Monitor Episodes Select Box is successful");
			
			extentReport.info("900 S Select  number of episodes to print from the dropdown and save the changes.");
			clinicSettings_ReportSettingsPage.selectCardiacMonitorNbrEpisodes_andSave();
			//Assert.assertEquals(clinicSettings_ReportSettingsPage.selectCardiacMonitorNbrEpisodes_andSave(), "Checking and Save Cardiac Monitor Episodes is successful");
			
			clinicianHomeTopNavPage.clickSignOutLink();
			
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			extentReport.info("1000 S Login to a EP clinic Clinic_2 having ICM Device assigned and navigate to Report Settings page in Clinic Admin and click on Edit");
			
			loginPage.login(loginClinicUser_withICMDevice);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToReportSettingsPage();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport,"Report settings Page is displayed");
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(),extentReport,"ReportSettings page is in Edit Mode");
			
			extentReport.info("1100 V Verify that on Report Settings page, in All Alerts and Episodes section, option to select Cardiac Monitor Episode is available and is enabled", new String[] {"ClncMgt32006"});
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyAllAlertEpisodes_cardiacMonitorOptionsAvailability(),extentReport,"Cardiac monitor checkbox is available");
			
			extentReport.info("1200 S Select Cardiac Monitor Episode checkbox.");
			clinicSettings_ReportSettingsPage.selectCardiacMonitor_checkbox();
			
			extentReport.info("1300 V Verify that user is able to select number of episodes to print for Cardiac Monitor Episode",new String[] {"ClncMgt32013"});
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.clickCardiacMonitorNbrEpisodes_select(),extentReport,"User is able select the episodes");
			
			extentReport.info("1400 S Select  number of episodes to print from the dropdown and save the changes.");
			clinicSettings_ReportSettingsPage.selectCardiacMonitorNbrEpisodes_andSave();
			
			//Assert.assertEquals(clinicSettings_ReportSettingsPage.selectCardiacMonitorNbrEpisodes_andSave(), "Checking and Save Cardiac Monitor Episodes is successful");
			
			
			appHomeTopNavPage.clickSignOutLink();
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			extentReport.info("1500 S Login to SJM Admin and select clinic Clinic_2 (having ICM Device assigned), select to change the clinic and remove all ICM Devices assigned to the clinic. Save the clinic.");
			
			loginPage.login(loginAdminUser);
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(),extentReport,"Customers List Page is displayed.");
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_withoutICMDevice.getCustomer());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customers Profile Page is displayed.");			
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer Page is displayed.");
			
			//changeCustomerProfilePage.removeDevicesFromAllowedListAndSave(list);
			
			appHomeTopNavPage.clickSignOutLink();
			
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			extentReport.info("1600 S Login to a EP clinic Clinic_2 (now not having any ICM Device assigned) and navigate to Report Settings page in Clinic Admin and click on edit button");
			
			loginPage.login(loginClinicUser_withICMDevice);
			
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToReportSettingsPage();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport,"Report settings Page is displayed");
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(),extentReport,"ReportSettings page is in Edit Mode");
			
			extentReport.info("1700 V Verify that on Report Settings page, in All Alerts and Episodes section, option to select Cardiac Monitor Episode is not available",new String[] {"ClncMgt32006"});
			assertion.assertEqualsWithReporting(false,clinicSettings_ReportSettingsPage.verifyAllAlertEpisodes_cardiacMonitorOptionsAvailability(),extentReport,"Cardiac Monitor Options are NOT Available");
			
			clinicianHomeTopNavPage.clickSignOutLink();
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
		
}

