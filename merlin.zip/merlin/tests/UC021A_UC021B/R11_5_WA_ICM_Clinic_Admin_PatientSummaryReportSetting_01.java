package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vrushali Hitendra Barhate
 * Test Case: R11.5_WA_ICM_Clinic Admin_PatientSummaryReportSetting_01
 * Report: Good
 */

public class R11_5_WA_ICM_Clinic_Admin_PatientSummaryReportSetting_01 extends CommonUtils {

	
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	CA_DirectAlert_CardiacMonitorPage directAlert_CardiacMonitorPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	AppHomeTopNavPage appHomeTopNavPage;
	Assertions assetions;
	
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withOnlyICMDevice;
	Login loginAlliedProffessional;
	Login loginPhysician;
	Login loginSJMAdmin;
	Login loginClinicUser_withAllDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		
		directAlert_CardiacMonitorPage = new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withOnlyICMDevice = new Login();
		loginClinicUser_withAllDevice = new Login();
		loginAlliedProffessional = new Login();
		loginPhysician = new Login();
		loginSJMAdmin = new Login();
		
		
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void R11_5_WA_ICM_Clinic_Admin_PatientSummaryReportSetting_01() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		List billingInterval;

		extentTest = extentReport.initiateTest(testName);
		
		loginAlliedProffessional = testDataProvider.getLoginData("AlliedProf1");
		loginClinicUser_withOnlyICMDevice = testDataProvider.getLoginData("ClinicalUserB"); //clinic B
		loginClinicUser_withAllDevice = testDataProvider.getLoginData("ClinicalUserA"); //Clinic A
		loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
		
		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			assertion = new Assertions(extentTest);
			extentReport.info("100S Login to Clinic A as Allied professional user.");
			loginPage.login(loginAlliedProffessional, "externaluser");	
		
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Landing page is NOT displayed");
			
			extentReport.info("200S Navigate to clinic administration page.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Left Navigation page is NOT displayed");
			
			extentReport.info("400S Click on Cardiac Monitor navigation link and navigate to Direct Alerts™ Settings for Cardiac Monitor.");
			clinicAdminLeftNavPage.clickCardiacMonitorLink();
			assertion.assertEqualsWithReporting(true, directAlert_CardiacMonitorPage.verifyLandingPage(), extentReport, "Direct Alert Cardiac Monitor page is NOT displayed");
			
			extentReport.info("500S Click on Show Devices hyper link and verify that the Confirm Rx™ ICM, DM3500 device is available in the Device list.");
			directAlert_CardiacMonitorPage.clickShowDevicesLink();
			assertion.assertEqualsWithReporting(true, directAlert_CardiacMonitorPage.validateDeviceInShowDeviceDialogBox("Confirm Rx™ ICM, DM3500"), extentReport, "Clinic Admin -> Cardiac Monitor -> Show Devices Popup is NOT Displayed.");
			
			
			
			extentReport.info("600S Click on Close button on the pop-up box.");
			//directAlert_CardiaMonitorPage.clickDeviceListPopupCloseBtn();
			//assertion.assertEqualsWithReporting(true, directAlert_CardiaMonitorPage.verifyLandingPage(), extentReport, "Direct Alert Cardiac Monitor page is NOT displayed");
			
			extentReport.info("700S Click on Report settings link from the left navigation panel on the page.");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyLandingPage(), extentReport, "Report Setting page is NOT displayed");
			
			extentReport.info("800V Verify that the report setting page is displayed in view mode." , new String[] {"ClncMgt33263"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), extentReport, "Report Setting page is NOT in view mode.");
			extentReport.reportScreenShot("Report Setting page is loaded in view mode");
			
			extentReport.info("900V Verify that the Patient Summary Report section is displayed on the report setting page.", new String[] {"ClncMgt33263 ClncMgt33264"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report is not displayed");
			extentReport.reportScreenShot("Patient Summary Report is displayed");
			
			extentReport.info("1000S Click on Edit button, verify that the page is displayed in Edit mode.", new String[] {"ClncMgt27021"});
			assertion.assertEqualsWithReporting("Settings in Edit Mode", clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(), extentReport, "Report Settings page is not in Edit Mode after clicking Edit button");
			
			extentReport.info("2000V Verify that the value of dropdown field of billing interval is 31 by default.", new String[] {"Config23472"});
			assertion.assertEqualsWithReporting(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "31",extentReport,  "The value of dropdown field of billing interval is NOT 31 by default.");
			
			extentReport.info("2100V Verify that the page displays the Drop-down value for the print every report (Patient Summary Report billing interval).", new String[] {"ClncMgt33264 Config23472"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(),extentReport,  "Billing interval Dropdown is NOT displayed in Patient Report Symmary");
			
			extentReport.info("2200V Verify that on Patient Summary Report billing interval, the selectable values associated with the Show Dropdown Filter Field displayed are 31 and 91", new String[] {"ClncMgt33264 Config23472"});
			billingInterval = clinicSettings_ReportSettingsPage.getBillingIntervalsListValues();
			softAssert.assertTrue(billingInterval.contains("31"), "Billing interval value -  31 is not find. ");
			softAssert.assertTrue(billingInterval.contains("91"), "Billing interval value -  91 is not find. ");
			
			extentReport.info("2300S Select 91 value and Click on save button.");
			clinicSettings_ReportSettingsPage.selectBillingInterval91_andSave();
			
			extentReport.info("2400V Verify that a pop-up box is getting displayed click ok on the pop-up box. Verify that the System save the Changes.", new String[] {"CommUI9024"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verify_Alert_Is_Present_Patient_SummaryReport(), extentReport, "popup box is displayed after saving Report Setting page");
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			assertion.assertEqualsWithReporting(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "91", extentReport, "selected billing interval value - 91 is NOT saved successfully");
			extentReport.reportScreenShot("selected billing interval value - 91 is saved successfully");
			
			extentReport.info("2600S Logout and login as SJM admin. Edit Clinic A and remove ICM device from the RHS and save.");
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginSJMAdmin, "internaluser");
			assertion.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Customer List page is NOT displayed");
			
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_withAllDevice.getUserName());
			assertion.assertEqualsWithReporting(true, customerProfilePage.verifyLandingPage(), extentReport, "Customer Profile page is NOT displayed");
			
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.verifyLandingPage(), extentReport, "Change Customers Profile Page is NOT Displayed.");
			
			List<String> list = new ArrayList<String>();
	        list.add("Confirm Rx ICM, DM3500 ");
	        list.add("Jot Dx ICM, DM4500 ");
			changeCustomerProfilePage.removeDevicesFromAllowedListAndSave(list);
			
			extentReport.info("2700S Logout and Login to the same clinic A. Navigate to clinic administration page.");
			appHomeTopNavPage.clickSignOutLink();
			
			loginPage.login(loginClinicUser_withAllDevice, "externaluser");
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician A Home Landing page is NOT displayed");
			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is NOT Displayed.");
			
			extentReport.info("2800S Verify that the Cardiac Monitor navigation link is not displayed.", new String[] {"ClncMgt27028"});
			softAssert.assertFalse(clinicAdminLeftNavPage.verifyCardiacMonitorlink(), "Cardiac Monitor Link should not display.");
			extentReport.reportScreenShot("Cardiac Monitor Link is not displayed.");
					
			extentReport.info("2900S Click on Report settings link from the left navigation panel on the page.");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyLandingPage(), extentReport, "Report Setting page is NOT displayed");
			
			extentReport.info("3000V Verify that the report setting page is displayed in view mode.", new String[] {"ClncMgt33263"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), "Report Setting page is not in view mode.");
			extentReport.reportScreenShot("Report Setting page is displayed in view mode.");
			
			extentReport.info("3100V Verify that the Patient Summary Report Section is not displayed on the page.", new String[] {"ClncMgt33263"});
			softAssert.assertFalse(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report should not displayed");
			
			extentReport.info("3200S Logout and Login to the clinic B.");
			appHomeTopNavPage.clickSignOutLink();
			
			loginPage.login(loginClinicUser_withOnlyICMDevice, "externaluser");
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician B Home Landing page is NOT displayed");
			
			extentReport.info("3300S Navigate to clinic administration page.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Left Navigation page is NOT displayed");
			
			extentReport.info("3400S Click on Cardiac Monitor navigation link and navigate to Direct Alerts™ Settings for Cardiac Monitor.");
			clinicAdminLeftNavPage.clickCardiacMonitorLink();
			assertion.assertEqualsWithReporting(true, directAlert_CardiacMonitorPage.verifyLandingPage(), extentReport, "Direct Alert Cardiac Monitor page is NOT displayed");
			
			extentReport.info("3500S Click on Show Devices hyper link and verify that the Confirm Rx™ ICM, DM3500 device is available in the Device list.");
			directAlert_CardiacMonitorPage.clickShowDevicesLink();
			assertion.assertEqualsWithReporting(true, directAlert_CardiacMonitorPage.validateDeviceInShowDeviceDialogBox("Confirm Rx™ ICM, DM3500"), extentReport, "Clinic Admin -> Cardiac Monitor -> Show Devices Popup is NOT Displayed.");
			
			
			extentReport.info("3600S Click on Close button on the pop-up box.");
			directAlert_CardiacMonitorPage.clickDeviceListPopupCloseBtn();
			assertion.assertEqualsWithReporting(true, directAlert_CardiacMonitorPage.verifyLandingPage(), extentReport, "Direct Alert Cardiac Monitor page is NOT displayed");
			
			extentReport.info("3700S Click on Report settings link from the left navigation panel on the page");
			clinicAdminLeftNavPage.clickReportSettingsLink();
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyLandingPage(), extentReport, "Report Setting page is NOT displayed");
			
			extentReport.info("3800V Verify that the report setting page is displayed in view mode.", new String[] {"ClncMgt33263"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyReportsSettingsEditButton(), extentReport, "Report Setting page is NOT in view mode.");
			extentReport.reportScreenShot("Report Setting page is in view mode.");	
			
			extentReport.info("3900V Verify that the Patient Summary Report section is displayed on the report setting page.", new String[] {"ClncMgt33263 ClncMgt33264"});
			softAssert.assertTrue(clinicSettings_ReportSettingsPage.verifyPatientSummaryReport(), "Patient Summary Report should be displayed");
			extentReport.reportScreenShot("Patient Summary Report is displayed");
			
			extentReport.info("4000S Click on Edit button, verify that the page is displayed in Edit mode.", new String[] {"ClncMgt27021"} );
			assertion.assertEqualsWithReporting("Settings in Edit Mode", clinicSettings_ReportSettingsPage.clickEditButtonAndVerify(), extentReport, "Report Settings page is not in Edit Mode after clicking Edit button");
			
			extentReport.info("4100V Verify that the value of dropdown field of billing interval is 31 by default.", new String[] {"Config23472"} );
			assertion.assertEqualsWithReporting(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "31",extentReport,  "The value of dropdown field of billing interval is NOT 31 by default.");
			extentReport.reportScreenShot("The value of dropdown field of billing interval is 31 by default.");
			
			extentReport.info("4200V Verify that the page displays the Drop-down value for the print every report (Patient Summary Report billing switch).", new String[] {"ClncMgt33264 Config23472"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verifyBillingIntervalDropdown(),extentReport,  "Billing interval Dropdown is NOT displayed in Patient Report Symmary");
			extentReport.reportScreenShot("Billing interval Dropdown is displayed in Patient Report Symmary");
			
			extentReport.info("4300V Verify that on Patient Summary Report billing interval, the selectable values associated with the Show Dropdown Filter Field displayed are: 31 and 91", new String[] {"ClncMgt33264 Config23472"});
			billingInterval = clinicSettings_ReportSettingsPage.getBillingIntervalsListValues();
			softAssert.assertTrue(billingInterval.contains("31"), "Billing interval value -  31 is not find. ");
			softAssert.assertTrue(billingInterval.contains("91"), "Billing interval value -  91 is not find. ");
			
			extentReport.info("4400S Select 91 value and Click on save button.");
			clinicSettings_ReportSettingsPage.selectBillingInterval91_andSave();
			
			extentReport.info("4500V Verify that a pop-up box is getting displayed click ok on the pop-up box. Verify that the System save the Changes.", new String[] {"CommUI9024"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ReportSettingsPage.verify_Alert_Is_Present_Patient_SummaryReport(), extentReport, "popup box is displayed after saving Report Setting page");
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			clinicSettings_ReportSettingsPage.acceptAlertIsPresent_Patient_SummaryReport();
			assertion.assertEqualsWithReporting(clinicSettings_ReportSettingsPage.verifyDefaultBillingInterval(), "91", extentReport, "selected billing interval value - 91 is NOT saved successfully");
			extentReport.reportScreenShot("selected billing interval value - 91 is saved successfully");
			
			softAssert.assertAll();
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
	@AfterMethod
	public void cleanup() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		loginClinicUser_withAllDevice = testDataProvider.getLoginData("SJMClinic6"); //Clinic A
		loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");		
		
		extentTest.assignAuthor("Author: Vrushali Hitendra Barhate");
		try {
			
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginSJMAdmin, "internaluser");
			Assert.assertTrue(customerListPage.verifyLandingPage(), "Customer List page is not displayed");
			customerListPage.goTo_CustomerProfilePage(loginClinicUser_withAllDevice.getUserName());
			Assert.assertTrue(customerProfilePage.verifyLandingPage(), "Customer List page is not displayed");
			customerProfilePage.clickChangeButton();
			Assert.assertTrue(changeCustomerProfilePage.verifyLandingPage(), "Change Customers Profile Page is NOT Displayed.");
			
			List<String> list = new ArrayList<String>();
	        list.add("Confirm Rx ICM, DM3500 ");
	        list.add("Jot Dx ICM, DM4500 ");
	        changeCustomerProfilePage.addDevicesToAllowedListAndSave(list);
			
			appHomeTopNavPage.clickSignOutLink();
			
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
	@AfterMethod (dependsOnMethods = "cleanup")
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
	String status = null;
	String testMethodName = result.getMethod().getMethodName();
	if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
	status = "Failure";
	} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
	status = "Success";
	}

	writeInTextFile(testMethodName, status);
	}
	
}

