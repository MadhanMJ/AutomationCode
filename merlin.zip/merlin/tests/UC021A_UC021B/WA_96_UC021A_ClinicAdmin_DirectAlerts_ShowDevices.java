package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.utilities.CommonUtils;

/*
 * BLOCKED - Show Devices functionality not currently in development.
 */

public class WA_96_UC021A_ClinicAdmin_DirectAlerts_ShowDevices extends CommonUtils{
	//Below references are required for UI test scripts
	// LoginPage loginPage; // Update with your required page class
	// LoginPageWithPOJO loginPage1;
	// CustomerListPage1 customerListPage;
	ExtentTest extentTest;
//	TestDataProvider testDataProvider;
//	ExtentTest child1,child2,child3,child4;
//	private UserRecord userRecord;
//	AddCustomerPage addCustomerPage;
	private String testName;
//	private String signOutMessage;
//	private Assertions softAssert;
//	Login login;
//	Customer customer;
	
	//Below references are required for API test scripts
//	AddSecLocationHelper addSecLocationHelper;/* API helper class declaration and update as per Testcase requirement*/
//	Map<String, String> headers = new HashMap<String, String>(); /* API header declaration*/

	@BeforeClass
	public void initialize() {
		//Initialize driver and extentReport initialization should be available for each test script
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
//		loginPage = new LoginPage(driver, extentReport);
//		customerListPage = new CustomerListPage1(driver, extentReport);
//		headers= CommonUtils.createHeaders();
//		userRecord= new UserRecord();
//		login = new Login();
//		customer  =  new Customer();
//		testDataProvider = new TestDataProvider();
	}
	
	@Test
	public void MyTest() throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		try {
			// loginPage.login(username, password);
			// Boolean loginCheck = customerListPage.verifyLandingPage();
			Boolean testCheck = true; // true gets replaced with test conditional
			Assert.assertTrue(testCheck);
			//customerListPage.verifyLogout();
			extentTest.log(Status.PASS, "My test passed");
		} catch (AssertionError e) {
			extentReport.reportFail("My test failed");
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("My test failed");
			throw e;
		}
	}

	//If your test method is having more than 5 to 10 Parameters, go with POJO implementation
//	@Test
//	public void loginOfPCSAdminWithPojo() throws Exception {
//		testName = CommonUtils.getTestName();
//		CommonUtils.currentTestCaseName = testName;
//		
//		// To fetch test data, implemented methods in Testdataprovider class needs to be used
//		login = testDataProvider.getLoginData("SJMAdmin");
//		customer = testDataProvider.getCustomerData("AddCustomer");
//		
//		//For each test scripts, extent test method need to be created to append in extent report
//		extentTest = extentReport.initiateTest(testName);
//
//		//Each test class needs to have try/catch block
//		try {
//			loginPage1.login(login);
//			Boolean loginCheck = customerListPage.verifyLandingPage();
//			Assert.assertTrue(loginCheck);
//			customerListPage.verifyLogout();
//			extentTest.log(Status.PASS, "Login functionality is verified");
//			
//		// Catch Assertion error while using Hard Assert to capture the assertion error
//		} catch (AssertionError e) {
//			extentReport.reportFail("Login functionality not successfully verified for PCS Admin ");
//			throw e;
//		} catch (Exception e) {
//			extentReport.reportFail( "Login functionality not successfully verified for PCS Admin ");
//			throw e;
//		}
//	}

	//If your test method is having less than 5 Parameters, go with Data Provider implementation
	
//	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
//	public void loginOfPCSAdminWithDataProvider(String username, String password) throws Exception {
//		testName = CommonUtils.getTestName();
//		CommonUtils.currentTestCaseName = testName;
//		extentTest = extentReport.initiateTest(testName);
//		CommonUtils.extentTest = extentTest;
//
//		try {
//			softAssert = new Assertions(extentTest);
//			loginPage.login(username, password);// Write your relevant Test method in page class and call here.
//			signOutMessage = customerListPage.verifyLogout();
//			Assert.assertEquals(signOutMessage, loginPage.signOutMessage,"Signout Message is verified");
//		} catch (Exception e) {
//			extentReport.reportFail( "Login functionality not successfully verified for PCS Admin ");
//			throw e;
//		}
//	}
	
//	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
//	public void addSecLocationWithExistingLoc(String iteration, String customerId) throws IOException {
//		extentTest = extentReport.initiateTest(CommonUtils.getTestName()+ "_Iteration_" + iteration);
//		String message = "This Location name is already in use. Please specify a different Location name";
//		ExtentTest test = extentTest.createNode("Response field verification");
//		softAssert = new Assertions(test);
//		try {
//			CommonUtils.currentTestCaseName=CommonUtils.getTestName();
//			CommonUtils.iteration=iteration;
//			String locationName = "Location " + CommonUtils.randomGenerator();
//			Response putResponse = addSecLocationHelper.addSecLocationWithExistingLoc(customerId, locationName, extentTest, headers);
//			
//			Assert.assertEquals(putResponse.statusCode(), HTTP_BADREQUEST,"Response code is Verified");
//			test.log(Status.PASS, "Response code verification");
//			JsonObject putRes = loadJsonFromResponse(putResponse);
//			String putMessage = formatString(putRes.get("message").toString());
//			softAssert.assertEquals(message, putMessage, "Error Message is verified");
//			
//			extentReport.pass("Adding secondary Location for Existing customer flow verified successfully");
//		} catch (AssertionError e) {
//			e.printStackTrace();
//			test.log(Status.FAIL, e.getMessage());
//			extentReport.fail("Assertion Error");
//			throw e;
//		} catch (Exception e) {
//			e.printStackTrace();
//			extentReport.fail("Adding secondary Location for Existing customer flow not verified successfully");
//		}
//	}
	
	
	/******Database Validation
	 * @throws SQLException *******/
	//User record table
//	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
//	public void addSecLocationWithExistingLoc(String parameters) throws SQLException {
//	child1 = extentTest.createNode("User Record table Validation");
//	softAssert = new Assertions(child1);
//	userRecord.readUserRecordTable(addCustomerPage.userIdValue);
//	String userRecordId = userRecord.getUserRecordId();
//	}
//	
	
	// After method should be available in each test script
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		copySaintsEvidences(currentMethod);

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
	
}