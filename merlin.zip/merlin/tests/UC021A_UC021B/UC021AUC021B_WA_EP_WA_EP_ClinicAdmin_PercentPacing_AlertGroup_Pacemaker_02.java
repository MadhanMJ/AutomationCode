package com.test.qa.ui.tests.UC021A_UC021B;


import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;

public class UC021AUC021B_WA_EP_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
    CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
    ClinicianHomeTopNavPage clinicianHomeTopNavPage;
    CommonUtils commonUtils;
    CA_LeftNavPage clinicAdminLeftNavPage;
    AppHomeTopNavPage appHomeTopNavPage;
    CustomerListPage customerListPage;
    
	@BeforeClass
	public void initialize() {
		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicAdminLeftNavPage=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
	}
	
	@Test
	public void UC021AUC021B_WA_EP_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
			
		login = testDataProvider.getLoginData("ApAdmSp2Us");
		extentTest.assignAuthor("Dhaval kothari");

		try {
			Assertions assertion =  new Assertions(extentTest);
			
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			extentReport.reportScreenShot("Clicked Clinic Administration Link");
			
			extentReport.info( "200 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available and navigate to Direct Alerts Settings for Pacemaker/ CRT-P devices page.", new String[] {"ClncMgt33113"});
			clinicAdminLeftNavPage.verifyDirectAlertTab_new();
			clinicAdminLeftNavPage.verifypacemaker_CRTPTab_new();
			extentReport.reportScreenShot("Pacemakers/CRT-P devices tab is present");
			clinicAdminLeftNavPage.navigatePacemaker_CRTPLink();
			extentReport.reportScreenShot("Clicked pcaemaker crtp tab");
			pacemaker.verifyLandingPage_new();
			extentReport.reportScreenShot("Navigated to crtp page");
			
			extentReport.info("300 S Click on edit button, and check the page is opened in edit mode.");
			pacemaker.validateEditModePacemaker();
			extentReport.reportScreenShot("Edit Button is dispalyed on pacemaker page");
			
			
			extentReport.info("400 S Change few Alerts Categories (Urgent, standard or Off) for percent pacing alert group and click on save button.");
//			⦁ RV Percent Pacing Greater than Limit (Display Group 208) (Pacemaker/CRT-P devices),
//			⦁ BiV Percent Pacing Less than Limit (Display Group 209) (Pacemaker/CRT-P devices),			
			String RvAlertSTatusUpdatedRv = pacemaker.changeAlertClassification("*RV Percent Pacing Greater Than Limit");
			String RvAlertSTatusAfterUpdatedRv = pacemaker.verifyAlertClassificationStatus("*RV Percent Pacing Greater Than Limit");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");
			String RvAlertSTatusUpdatedBiv = pacemaker.changeAlertClassification("*BiV Percent Pacing Less Than Limit");
			String RvAlertSTatusAfterUpdatedBiv = pacemaker.verifyAlertClassificationStatus("*BiV Percent Pacing Less Than Limit");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");
			
				
			
			extentReport.info("500 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved.", new String[] {"ClncMgt33113"});
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");	
			pacemaker.clickSaveButton();
			
			
			extentReport.info("600 V Verify pop up is displayed by webpage for confirmation Click on OK.", new String[] {"ClncMgt33113"});
			String alertTextActual = pacemaker.VerifyTextSaveALertPOpup();
			extentReport.reportScreenShot("Save alert popup is dispalyed");
			String alertTextExpected ="";
			assertion.assertEqualsWithReporting(true,alertTextActual.toLowerCase().equalsIgnoreCase(alertTextExpected), extentReport, "Verified pop up is displayed by webpage for confirmation Click on OK.");	
			pacemaker.acceptSaveAlertPOpup();
			
			
			extentReport.info("700 V Verify the changes are saved.", new String[] {"ClncMgt33113"});
			RvAlertSTatusAfterUpdatedRv = pacemaker.verifyAlertClassificationStatus("*RV Percent Pacing Greater Than Limit");
			RvAlertSTatusAfterUpdatedBiv = pacemaker.verifyAlertClassificationStatus("*BiV Percent Pacing Less Than Limit");
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");	
			
			//Test Setup 2
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("PhAdmSp2Ous");
			
			
			extentReport.info("800 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Login Successful");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			
			extentReport.info( "900 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available and navigate to Direct Alerts Settings for Pacemaker/ CRT-P devices page.", new String[] {"ClncMgt33113"});
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration page displayed");
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifypacemaker_CRTPTab(), extentReport, "Pacemakers/CRT-P devices tab is present");
			clinicAdminLeftNavPage.navigatePacemaker_CRTPLink();
			assertion.assertEqualsWithReporting(true,pacemaker.verifyLandingPage(),extentReport,"Pacemaker landing page is displayed");
			
			extentReport.info("1000 S Click on edit button, and check the page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true,pacemaker.verifyEditButton(),extentReport,"pacemaker edit button is displayed");
			pacemaker.ValidatePacemakerEditButton();
			assertion.assertEqualsWithReporting(true, pacemaker.verifySaveButton(), extentReport, "Save button is present on pacemaker edit page after clicking edit button");
			assertion.assertEqualsWithReporting(true, pacemaker.verifyCancelButton(), extentReport, "Cancel button is present on pacemaker edit page after clicking edit button");
			
			extentReport.info("1200 S Change few Alerts Categories (Urgent, standard or Off) for percent pacing alert group and click on save button.");
			
			//⦁ RV Percent Pacing Greater than Limit (Display Group 208) (Pacemaker/CRT-P devices),
			//⦁ BiV Percent Pacing Less than Limit (Display Group 209) (Pacemaker/CRT-P devices),
			 RvAlertSTatusUpdatedRv = pacemaker.changeAlertClassification("*RV Percent Pacing Greater Than Limit");
			 RvAlertSTatusAfterUpdatedRv = pacemaker.verifyAlertClassificationStatus("*RV Percent Pacing Greater Than Limit");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");
			 RvAlertSTatusUpdatedBiv = pacemaker.changeAlertClassification("*BiV Percent Pacing Less Than Limit");
			 RvAlertSTatusAfterUpdatedBiv = pacemaker.verifyAlertClassificationStatus("*BiV Percent Pacing Less Than Limit");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");
			
				
			extentReport.info("1300 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved.", new String[] {"ClncMgt33113"});
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");	
			pacemaker.clickSaveButton();
			
			
			extentReport.info("1400 V Verify pop up is displayed by webpage for confirmation Click on OK.", new String[] {"ClncMgt33113"});
			 alertTextActual = pacemaker.VerifyTextSaveALertPOpup();
			extentReport.reportScreenShot("Save alert popup is dispalyed");
			 alertTextExpected ="";
			assertion.assertEqualsWithReporting(true,alertTextActual.toLowerCase().equalsIgnoreCase(alertTextExpected), extentReport, "Verified pop up is displayed by webpage for confirmation Click on OK.");	
			pacemaker.acceptSaveAlertPOpup();
			
			extentReport.info("1500 V Verify the changes are saved.", new String[] {"ClncMgt33113"});
	
		} 
		catch (AssertionError e) {
			extentTest = extentReport.fail( "UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 is failed due to assertion failure");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}
			
		catch (Exception e) {
			extentTest = extentReport.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 is failed due to some exception");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
			
		}
	}
	
	/*
	 * @Test public void
	 * EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_02_TestDataSet2() throws
	 * Exception { testName = CommonUtils.getTestName();
	 * CommonUtils.currentTestCaseName = testName;
	 * 
	 * extentTest = extentReport.initiateTest(testName);
	 * 
	 * 
	 * login = testDataProvider.getLoginData("SJMClinic1");
	 * extentTest.assignAuthor("Dhaval kothari");
	 * 
	 * try { Assertions assertion = new Assertions(extentTest);
	 * 
	 * extentReport.
	 * info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings."
	 * ); loginPage.login(login); Boolean loginCheck =
	 * customerListPage.verifyLandingPage(); Assert.assertTrue(loginCheck);
	 * 
	 * clinicianHomeTopNavPage.clickClinicAdministrationLink();
	 * 
	 * extentTest=extentReport.info(
	 * "200 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available and navigate to Direct Alerts Settings for Pacemaker/ CRT-P devices page. <ClncMgt33113>"
	 * );
	 * 
	 * 
	 * assertion.assertEqualsWithReporting(true,
	 * directAlert_MerlinAtHomePage.isElementPresent(directAlert_MerlinAtHomePage.
	 * lblDirectAlertsSettings), extentTest, "Direct Alerts Settings is present");
	 * assertion.assertEqualsWithReporting(true,
	 * pacemaker.isElementPresent(pacemaker.lblPaceMakerCRTP), extentTest,
	 * "Pacemakers/CRT-P devices tab is present");
	 * 
	 * directAlert_MerlinAtHomePage.clickElement(pacemaker.lblPaceMakerCRTP);
	 * Assert.assertTrue(pacemaker.verifyLandingPage()); extentReport.
	 * reportScreenShot("Direct Alerts Settings,Pacemaker/ CRT-P is displayed");
	 * 
	 * 
	 * extentReport.
	 * info("300 V Verify a list of alert groups is displayed for which the clinic is authorized for Non-Bluetooth ICD/ CRT-D devices and respective Clinic's Jurisdiction (Ref. the Non-BLE Device Alerts tab in Alerts.xlsx sheet). <ClncMgt33106>"
	 * );
	 * 
	 * extentReport.reportScreenShot("Edit button is displayed");
	 * assertion.assertEqualsWithReporting(true, pacemaker.verifyEditButton(),
	 * extentTest,
	 * "Edit button is present on pacemaker edit page after clicking edit button");
	 * 
	 * pacemaker.clickEditButton();
	 * extentReport.reportScreenShot("Save button is displayed");
	 * 
	 * 
	 * assertion.assertEqualsWithReporting(true, pacemaker.verifySaveButton(),
	 * extentTest,
	 * "Save button is present on pacemaker edit page after clicking edit button");
	 * 
	 * extentReport.reportScreenShot("Cancel button is displayed");
	 * 
	 * assertion.assertEqualsWithReporting(true, pacemaker.verifyCancelButton(),
	 * extentTest,
	 * "Cancel button is present on pacemaker edit page after clicking edit button"
	 * );
	 * 
	 * 
	 * 
	 * 
	 * 
	 * } catch (AssertionError e) { extentTest = extentReport.fail(
	 * "WA_AD015_Change_Customer_PageValidation_01 is failed due to assertion failure"
	 * );
	 * extentTest.fail("WA_AD015_Change_Customer_PageValidation_01 is failed"+"<br>"
	 * +e.getMessage()); e.printStackTrace(); throw e; }
	 * 
	 * catch (Exception e) { extentTest = extentReport.fail(
	 * "UC013B_E01_01 is failed due to some exception");
	 * extentTest.fail("UC013B_E01_01 is failed"+"<br>"+e.getMessage());
	 * e.printStackTrace(); throw e;
	 * 
	 * } }
	 */
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
