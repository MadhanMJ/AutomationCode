package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * BLOCKED - Show Devices functionality not currently in development.
 */

/***********************************************************************************/
//Saints Id :  1227874
//Test Case :  WA_11_EP_ClinicAdmin_Collection_of_Enhanced_Diagnostics_Data
//Author    : Jeetendra Gupta
/***********************************************************************************/

public class WA_11_EP_ClinicAdmin_Collection_of_Enhanced_Diagnostics_Data extends CommonUtils {
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withoutICDDevice;
	CA_SchedulingAndMessagingPage scmePage;
	ClinicianHomeTopNavPage appHomeTopNavPage;
	CA_LeftNavPage LeftNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage MerlinAtHomePage;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	CustomerListPage customerListPage;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		scmePage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		appHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		LeftNavPage = new CA_LeftNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
	}

	@Test(groups = {"Regression"})
	public void Collection_of_Enhanced_Diagnostics_Data() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("JitClinic1");
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Jeetendra Gupta");// comments
		try {
			Assertions assertion = new Assertions(extentTest);
			
			/************************************************************************************/
			extentReport.info(
					"100 S Login with Test setup 1 and navigate to Clinic Administration tab > Scheduling & Messaging page.");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			LeftNavPage.clickSchedMessagingLink();
			assertion.assertEqualsWithReporting(true, scmePage.verifyLandingPage(), extentReport,
					"Scheduling & Messaging page is displayed");

			/************************************************************************************/
			extentReport.info(
					"200 V Verify that under Transmitter setting Enhanced diagnostics collection feature (Collect Direct Trend� Viewer Diagnostics) available and displayed in view mode. <ClncMgt33111>");
			assertion.assertEqualsWithReporting(true, scmePage.presenceof_Enhanced_diagnostics_collection_feature(),
					extentReport, "Collect Direct Trend� Viewer Diagnostics) available and displayed in view mode");

			/************************************************************************************/
			extentReport
					.reportInfo("300 V Verify that the by default value is enabled for the feature. <ClncMgt33111>");
			assertion.assertEqualsWithReporting(true, scmePage.verifydefaultValue(), extentReport,
					"By default value is enabled for the feature");

			/************************************************************************************/
			extentReport.info(
					"400 V Verify All the percent pacing alert groups are set to OFF on direct alerts settings page before changing the Collect Direct Trend� Viewer Diagnostics feature on Scheduling and messaging page. <ClncMgt33111>");
			LeftNavPage.clickMerlinHomeTransmitterLink();
//		need to fix this--	assertion.assertEqualsWithReporting(true, MerlinAtHomePage.verify_percent_pacing_alert(), extentReport,
//					"All the percent pacing alert groups are set to OFF on direct alerts settings page");

			/************************************************************************************/
			extentReport.info("500 S Click on edit button, and check the page is opened in edit mode.");
			LeftNavPage.navigateToSchedMessagingPage();
// need to fix --			assertion.assertEqualsWithReporting(true, scmePage.ClickEditButton(), extentReport,
//					"Page is opened in edit mode.");

			/************************************************************************************/
			extentReport.info(
					"600 V Verify Collect Direct Trend� Viewer Diagnostics feature is editable and changes gets saved. <ClncMgt33111>");
			assertion.assertEqualsWithReporting(true, scmePage.EditValue_and_Save_Changes(), extentReport,
					"Collect Direct Trend� Viewer Diagnostics feature is editable and changes gets saved");

			/************************************************************************************/
			appHomeTopNavPage.clickSignOutLink();

			/************************************************************************************/

			extentReport.info(
					"1900 S Login with Test setup 4 and navigate to Clinic Administration tab > Scheduling & Messaging page.");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			LeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true, scmePage.verifyLandingPage(), extentReport,
					"Scheduling & Messaging page is displayed");

			/************************************************************************************/
			extentReport.info(
					"2000 V Verify that under Transmitter setting Enhanced diagnostics collection feature (Collect Direct Trend� Viewer Diagnostics) available and displayed in view mode. <ClncMgt33111>");
			assertion.assertEqualsWithReporting(true, scmePage.presenceof_Enhanced_diagnostics_collection_feature(),
					extentReport, "Collect Direct Trend� Viewer Diagnostics) available and displayed in view mode");

			/************************************************************************************/
			extentReport
					.reportInfo("2100 V Verify that the by default value is enabled for the feature. <ClncMgt33111>");
			assertion.assertEqualsWithReporting(true, scmePage.verifydefaultValue(), extentReport,
					"By default value is enabled for the feature");

			/************************************************************************************/
			extentReport.info(
					"2200 V Verify All the percent pacing alert groups are set to OFF on direct alerts settings page before changing the Collect Direct Trend� Viewer Diagnostics feature on Scheduling and messaging page. <ClncMgt33111>");
			LeftNavPage.clickMerlinHomeTransmitterLink();
			assertion.assertEqualsWithReporting(true, MerlinAtHomePage.verify_percent_pacing_alert(), extentReport,
					"All the percent pacing alert groups are set to OFF on direct alerts settings page");

			/************************************************************************************/
			extentReport.info("2300 S Click on edit button, and check the page is opened in edit mode.");
			LeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true, scmePage.ClickEditButton(), extentReport,
					"Page is opened in edit mode.");

			/************************************************************************************/
			extentReport.info(
					"2400 V Verify Collect Direct Trend� Viewer Diagnostics feature is editable and changes gets saved. <ClncMgt33111>");
			assertion.assertEqualsWithReporting(true, scmePage.EditValue_and_Save_Changes(), extentReport,
					"Collect Direct Trend� Viewer Diagnostics feature is editable and changes gets saved");

			/************************************************************************************/
			extentReport.takeFullSnapShot(driver,
					"2400V Verify Collect Direct Trend� Viewer Diagnostics feature is editable and changes gets saved. <ClncMgt33111>");
			extentReport.info("Test case ends");
			assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.reportFail(
					"WA_11_EP_ClinicAdmin_Collection_of_Enhanced_Diagnostics_Data Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail(
					"WA_11_EP_ClinicAdmin_Collection_of_Enhanced_Diagnostics_Data Validation not  successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}