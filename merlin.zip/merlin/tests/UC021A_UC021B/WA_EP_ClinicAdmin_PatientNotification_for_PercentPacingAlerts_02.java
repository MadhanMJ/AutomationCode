package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;


public class WA_EP_ClinicAdmin_PatientNotification_for_PercentPacingAlerts_02 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login,login_scenario_2;	
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage cA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page cA_DirectAlert_Pacemaker_CRTP_Page;
	Assertions assertions;
	ExtentTest extentTest;
	String testName,enabledObject,alertType;
	TestDataProvider testDataProvider;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		cA_DirectAlert_ICD_CRTD_MerlinAtHomePage= new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		cA_DirectAlert_Pacemaker_CRTP_Page=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		assertions=new Assertions(extentTest);
		login = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test(groups= {"Regression"})
	public void wA_EP_ClinicAdmin_PatientNotification_for_PercentPacingAlerts_02() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);

		login = testDataProvider.getLoginData("PercentAlert");
		System.out.println(login.getUserName()+", "+login.getPassword());

		extentTest.assignAuthor("Author: ChandraMohan.Singaram");
		try {
			
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			loginPage.login(login,"externaluser");
			/*Temp comment for dryrun Starts
			assertions.assertEqualsWithReporting(clinicianHomePage.verifyLandingPage(), true, extentReport, "ClinicianHomePage Landing");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertions.assertEqualsWithReporting(clinicAdminLeftNavPage.verifyLandingPage(), true,extentReport, "Clinic Administration Page is Displayed with >Direct Alerts Settings.");

			extentReport.info("200 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and navigate to Direct Alerts™ Settings for Non-Bluetooth ICD/ CRT-D devices page.",new String[] {"ClncMgt33114"});
			assertions.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyLandingPage(), true,extentReport, "Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available");

			extentReport.info("300 S Click on edit button, and check the page is opened in edit mode.");
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.openEditAdditonalNotificationSectioon();

			extentReport.info("500 S Select Alert classification as OFF and verify the inform checkbox is disabled for that alert(negative).");
			//Temp comment as Click Method is NOT working ... Need to fix.
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.selectAlertClassification("Device Reset", "Off");
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification("Device Reset", "InformPatient") ;

			extentReport.info("600 S Select Patient Notification/Inform Patient (ON or Off) for percent pacing alert group and click on save button.",new String[] { "ClncMgt33113"}  );
			//Temp comment as Click Method is NOT working ... Need to fix.
			//cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.selectAlertClassification("Percent RV Pacing above Threshold", "Off");
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave();

			extentReport.info("600 V Verify pop up is displayed by webpage for confirmation Click on OK.",new String[] { "ClncMgt33114"});
			//assertions.assertEqualsWithReporting(true, cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave(), extentReport, "Type of user is displayed");

			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickOkButton();
			extentReport.info("700 V Verify changes are saved pop up is displayed. ",new String[] { "ClncMgt33114"});
			/* Need clarification why the below ?
			.Percent RV Pacing above Threshold (Display Group 270) (non-BLE ICD/CRT-D devices),  
			.Percent BiV Pacing below Threshold (Display Group 271) (non-BLE ICD/CRT-D devices),      
			
			extentReport.info("800 V Verify the changes are saved.",new String[] { "ClncMgt33114"});
			
			clinicianHomeTopNavPage.clickSignOutLink();
			Temp comment for dryrun Starts ***/
			
			extentReport.info("900 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");			
			login_scenario_2=testDataProvider.getLoginData("AlliedAdmin");
			loginPage.login(login_scenario_2,"externaluser");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertions.assertEqualsWithReporting(clinicAdminLeftNavPage.verifyLandingPage(), true,extentReport, "Clinic Administration Page is Displayed with >Direct Alerts Settings.");

			extentReport.info("1000 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available and navigate to Direct Alerts™ Settings for Pacemaker/ CRT-P devices page.",new String[] {"ClncMgt33114"});
			clinicAdminLeftNavPage.navigatePacemaker_CRTPLink();
			assertions.assertEqualsWithReporting(cA_DirectAlert_Pacemaker_CRTP_Page.verifyLandingPage(), true,extentReport, "Verify that under  Direct Alerts™ Settings for Pacemaker/ CRT-P devices page is Displayed");

			extentReport.info("1100 S Click on edit button, and check the page is opened in edit mode",new String[] {"ClncMgt33114"});
			cA_DirectAlert_Pacemaker_CRTP_Page.clickEditButton();

/*			extentReport.info("1200 S Select Alert classification as OFF and verify the inform checkbox is disabled for that alert(negative).");
			String alertType ="Device Reset";
			cA_DirectAlert_Pacemaker_CRTP_Page.selectAlertClassification(alertType, "Off");
			softAssert.assertEquals(cA_DirectAlert_Pacemaker_CRTP_Page.verifyEditModeOfAlertClassification(alertType, "OFF"), true,"Inform checkbox is disabled ");
			*/
			
			extentReport.info("1200 V Verify Patient Notification/Inform Patient check box for percent pacing alert are editable",new String[] {"ClncMgt33114"});
			alertType ="*RV Percent Pacing Greater Than Limit";
			assertions.assertEquals(cA_DirectAlert_Pacemaker_CRTP_Page.verifyEditModeOfAlertClassification(alertType, "OFF"), true, "Patient Notification/Inform Patient check box for percent pacing alert are editable");
			
			//? RV Percent Pacing Greater than Limit (Display Group 208) (non-BLE ICD/CRT-D devices), 
			//? BiV Percent Pacing Less than Limit (Display Group 209) (non-BLE ICD/CRT-D)
			
			extentReport.info("1300 S Select Patient Notification/Inform Patient (ON or Off) for percent pacing alert group and click on save button",new String[] {"ClncMgt33114"});
			cA_DirectAlert_Pacemaker_CRTP_Page.selectAlertClassification("data.Alert_Group.Description.208", "Off");
			cA_DirectAlert_Pacemaker_CRTP_Page.clickSaveButton();
			
			extentReport.info("1400 V Verify pop up is displayed by webpage for confirmation Click on OK.",new String[] {"ClncMgt33114"});
			cA_DirectAlert_Pacemaker_CRTP_Page.acceptSaveAlertPOpup();
			
			
			extentReport.info("1500 V Verify changes are saved pop up is displayed",new String[] {"ClncMgt33114"});
			
			extentReport.info("1600 V Verify the changes are saved.",new String[] {"ClncMgt33114"});
			
			assertion.assertAll();


		}catch (AssertionError e) {
			extentReport.reportFail( testName+" is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail(  testName+" is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		//		customerListPage.verifyLogout();
		if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			status = "Success";
		} 

		writeInTextFile(testMethodName, status);
	}


}


