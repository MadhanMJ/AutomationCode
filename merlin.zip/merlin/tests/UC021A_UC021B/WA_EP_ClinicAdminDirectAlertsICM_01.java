package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

/* Testcase id: 1227876
Testcase name: WA_EP_ClinicAdminDirectAlertsICM_01
Author- Shanmugapriya */

public class WA_EP_ClinicAdminDirectAlertsICM_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_ClinicProfilePage ca_clinicProfilePage;
	CA_LeftNavPage ca_leftNavPage;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	CA_DirectAlert_CardiacMonitorPage cardiacMonitorPage;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		ca_leftNavPage = new CA_LeftNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		commonUtils=new CommonUtils();
		cardiacMonitorPage= new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
		ca_ClinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		
	}
	
	@Test
	public void wA_EP_ClinicAdminDirectAlertsICM_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("SJMClinic1");
		extentTest.assignAuthor("Shanmugapriya");
		try {
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is loaded");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic Administration page");
			
			extentReport.info("200 V Verify that under Direct Alerts Settings, cardiac monitor tab is available and to navigate DirectAlerts™ Settings for Cardiac Monitor page.", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(true, ca_leftNavPage.verifyCardiacMonitorlink(), extentReport, "Cardiac Monitor link is available");
			ca_leftNavPage.navigateToCardiacMonitorLink();
			extentReport.reportScreenShot("User is able to successfully navigate to Cardiac Monitor page");
			
			extentReport.info("300 V Verify a list of alert groups is displayed for which the clinic is authorized for Cardiac Monitor Devices(ICM) and respective Clinic's Jurisdiction (Ref. the ICM Alerts tab in Alerts.xlsx sheet).", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifydevices_ICM(), extentReport, "Cardiac Monitor device are available");
			extentReport.reportScreenShot("User is able to see list of alert groups and ICM devices in list");
			
			extentReport.info("400 S Click on edit button and verify page is opened in edit mode.");
			cardiacMonitorPage.clickEditButton();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifySaveButton(), extentReport, "Page is opened in edit mode");
			extentReport.reportScreenShot("User is able to successfully click on edit button and verified in edit mode");
			
			extentReport.info("500 V Verify Alerts Categories (Urgent, standard or Off) for the Cardiac Monitor (ICM) are editable & changes are saved.", new String[] {"ClncMgt33109"});
//			cardiacMonitorPage.selectICMDeviceClassification();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.selectICMDeviceClassification(), extentReport, "Alert Categories are editable");
			cardiacMonitorPage.clickSaveButton();
			clinicianHomeTopNavPage.clickSignOut();
			extentReport.reportScreenShot("User is able to change alert categories and save the changes");
			
			extentReport.info("600 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			loginPage.login(login);//need to change
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is loaded");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic Administration page");
			
			extentReport.info("700 V Verify that under Direct Alerts Settings, cardiac monitor tab is available and to navigate DirectAlerts™ Settings for Cardiac Monitor page.", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(true, ca_leftNavPage.verifyCardiacMonitorlink(), extentReport, "Cardiac Monitor link is available");
			ca_leftNavPage.navigateToCardiacMonitorLink();
			extentReport.reportScreenShot("User is able to successfully navigate to Cardiac Monitor page");
			
			extentReport.info("800 V Verify a list of alert groups is displayed for which the clinic is authorized for Cardiac Monitor Devices(ICM) and respective Clinic's Jurisdiction (Ref. the ICM Alerts tab in Alerts.xlsx sheet).", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifydevices_ICM(), extentReport, "Cardiac Monitor device are available");
			extentReport.reportScreenShot("User is able to see list of alert groups and ICM devices in list");
			
			extentReport.info("900 S Click on edit button and verify page is opened in edit mode.");
			cardiacMonitorPage.clickClinicEditButton();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifySaveButton(), extentReport, "Page is opened in edit mode");
			extentReport.reportScreenShot("User is able to successfully click on edit button and verified in edit mode");
			
			extentReport.info("1000 V Verify Alerts Categories (Urgent, standard or Off) for the Cardiac Monitor (ICM) are editable & changes are saved.", new String[] {"ClncMgt33109"});
//			cardiacMonitorPage.selectICMDeviceClassification();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.selectICMDeviceClassification(), extentReport, "Alert Categories are editable");
			cardiacMonitorPage.clickSaveButton();
			clinicianHomeTopNavPage.clickSignOut();
			extentReport.reportScreenShot("User is able to change alert categories and save the changes");
			
			extentReport.info("1100 S Login with Test setup 5 (Negative Test)");
			loginPage.login(login);//need to change
			
			extentReport.info("1200 V Verify Clinic Administration tab is not displayed.", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(false, clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), extentReport, "Clinic Administration page is not displayed");
			clinicianHomeTopNavPage.clickSignOut();
			extentReport.reportScreenShot("User is not able to Clinic Administration tab");
			
			extentReport.info("1300 S Login with Test setup 6 and navigate to Clinic Administration tab >Direct Alerts Settings. (Negative Test)");
			loginPage.login(login);//need to change
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is loaded");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic Administration page");
			
			extentReport.info("1400 V Verify that under Direct Alerts Settings, cardiac monitor tab is not displayed.", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(false, ca_leftNavPage.verifyCardiacMonitorlink(), extentReport, "Cardiac Monitor link is not available");
			extentReport.reportScreenShot("User is able to Cardiac monitor is not displayed");
			
			extentReport.info("1500 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.(Negative Test)");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is loaded");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic Administration page");
			
			extentReport.info("1600 V Verify that under Direct Alerts Settings, cardiac monitor tab is available and to navigate DirectAlerts™ Settings for Cardiac Monitor page.", new String[] {"ClncMgt33107"});
			assertions.assertEqualsWithReporting(true, ca_leftNavPage.verifyCardiacMonitorlink(), extentReport, "Cardiac Monitor link is available");
			ca_leftNavPage.navigateToCardiacMonitorLink();
			extentReport.reportScreenShot("User is able to successfully navigate to Cardiac Monitor page");
			
			extentReport.info("1700 S Click on edit button and verify page is opened in edit mode.");
			cardiacMonitorPage.clickEditButton();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifySaveButton(), extentReport, "Page is opened in edit mode");
			extentReport.reportScreenShot("User is able to successfully click on edit button and verified in edit mode");
			
			extentReport.info("1800 V Verify Alerts Categories (Urgent, standard or Off) for the Cardiac Monitor (ICM) are editable click on cancel button.", new String[] {"ClncMgt33109"});
//			cardiacMonitorPage.selectICMDeviceAlertClassification();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.selectICMDeviceAlertClassification(), extentReport, "Alert Categories are editable");
			cardiacMonitorPage.clickCancelButton();
			extentReport.reportScreenShot("User is able to edit Alert categories and click on Cancel button");
			
			extentReport.info("1900 V Verify changes made on page is not saved & page is again opened in view mode.", new String[] {"ClncMgt33109"});
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifyICMDeviceClassification(), extentReport, "Changes made on page is not saved");
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifyEditButton(), extentReport, "Page is again opened in view mode");
			extentReport.reportScreenShot("User is able to see changes made on page is not saved & page is again opened in view mode. ");
			
			extentReport.info("2000 S Click on edit button and verify page is opened in edit mode.");
			cardiacMonitorPage.clickEditButton();
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifySaveButton(), extentReport, "Page is opened in edit mode");
			extentReport.reportScreenShot("User is able to successfully click on edit button and verified in edit mode");
			
			extentReport.info("2100 V Verify Alerts Categories (Urgent, standard or Off) for the Cardiac Monitor (ICM) are editable and navigate to different page.", new String[] {"ClncMgt33109"});
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.selectICMDeviceAlertClassification(), extentReport, "Alert Categories are editable");
			ca_leftNavPage.navigateToClinicLocationsPage();
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyLandingPage(), extentReport, "Clinic Location page is displayed");
			extentReport.reportScreenShot("User is able to edit Alert Categories and navigate to different page");
			
			extentReport.info("2200 V Verify the warning pop-up is displayed before navigating to some different page & changes are not saved on page.");
			assertions.assertEqualsWithReporting(true, cardiacMonitorPage.verifyICMDeviceClassification(), extentReport, "Changes made on page is not saved");
			extentReport.reportScreenShot("User is able to see the warning pop-up is displayed before navigating to some different page & changes made on page is not saved");
			
		}catch (AssertionError e) {
			 extentReport.reportFail( "WA_EP_ClinicAdminDirectAlertsICM_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "WA_EP_ClinicAdminDirectAlertsICM_01 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}

