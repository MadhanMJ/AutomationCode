package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;


public class $11_0_WA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth_Non_Bluetooth_01 extends CommonUtils {
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage cA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page	cA_DirectAlert_Pacemaker_CRTP_Page;
	CA_SchedulingAndMessagingPage cA_SchedulingAndMessagingPage;
	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	String testName,alertType;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		cA_DirectAlert_ICD_CRTD_MerlinAtHomePage= new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		cA_DirectAlert_Pacemaker_CRTP_Page= new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void $11_0_wA_EP_ClinicAdmin_PercentPacingAlertGroup_Bluetooth_Non_Bluetooth_01() throws Exception {
		testName = CommonUtils.getTestName();
		softAssert = new Assertions(extentTest);
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		customer = testDataProvider.getCustomerData(testName);
		login = testDataProvider.getLoginData("SJMClinic_NOTICMDevice");
		extentTest.assignAuthor("Author: ChandraMohan.Singaram");
		try {
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			loginPage.login(login);
			softAssert.assertEqualsWithReporting(clinicianHomePage.verifyLandingPage(), true,extentTest, "ClinicianHomePage Landing");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			softAssert.assertEqualsWithReporting(clinicAdminLeftNavPage.verifyLandingPage(), true,extentTest,"Clinic Administration Page is Displayed with >Direct Alerts Settings.");

			extentReport.info("200 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and navigate to Direct Alerts� Settings for Non-Bluetooth ICD/ CRT-D devices page.",new String[] {"ClncMgt33113"});
			clinicAdminLeftNavPage.clickMerlinHomeTransmitterLink();
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyLandingPage(), true,extentTest,"Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available");

			extentReport.info("300 S Click on edit button, and check the page is opened in edit mode.");
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.openEditAdditonalNotificationSectioon();
			
			extentReport.info("400 S Change few Alerts Categories(Urgent, standard or Off) for percent pacing alert group and click on save button.");
			//⦁ Percent RV Pacing above Threshold (Display Group 270) (non-BLE ICD/CRT-D devices), 
			
			alertType="Percent RV pacing greater than";
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Red"), true,extentTest,"Red radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Yellow"), true,extentTest,"Yellow radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Off"), true,extentTest,"OFF radio button is opened in edit mode");

			//⦁ Percent BiV Pacing below Threshold (Display Group 271) (non-BLE ICD/CRT-D devices)
			alertType="Percent BiV pacing less than";
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Red"), true,extentTest,"Red radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Yellow"), true,extentTest,"Yellow radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Off"), true,extentTest,"OFF radio button is opened in edit mode");
/*
			alertType="*RV Percent Pacing Greater Than Limit";
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"Red"), true,extentTest,"Red radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"Yellow"), true,extentTest,"Yellow radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"Off"), true,extentTest,"OFF radio button is opened in edit mode");

			
			alertType="*BiV Percent Pacing Less Than Limit";
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"Red"), true,extentTest,"Red radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"Yellow"), true,extentTest,"Yellow radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"Off"), true,extentTest,"OFF radio button is opened in edit mode");
			
			extentReport.info("400 V Verify Patient Notification/Inform Patient check box for percent pacing alert are editable.",new String[] {"ClncMgt33114"});
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationEditModeVerify(alertType,"InformPatient"), true,extentTest,"InformPatient CheckBox is opened in edit mode");

			extentReport.info("500 S Select Alert classification as OFF and verify the inform checkbox is disabled for that alert(negative).");
			softAssert(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyOFFAndCheckBox(),true, "Verification of AlertCheckbox for OFF AlertType ");
			
			extentReport.info("600 S Select Patient Notification/Inform Patient (ON or Off) for percent pacing alert group and click on save button",new String[] {"ClncMgt33114"});
			//.Percent RV Pacing above Threshold (Display Group 270) (non-BLE ICD/CRT-D devices),  
			//.Percent BiV Pacing below Threshold (Display Group 271) (non-BLE ICD/CRT-D devices),             
			*/
			extentReport.info("500 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved. <ClncMgt33113>");
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave();
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.closeMandateAlertMsg();
			
			extentReport.info("600 V Verify pop up is displayed by webpage for confirmation Click on OK. <ClncMgt33113>");
			//Blocked.
			
			extentReport.info("700 V Verify the changes are saved. <ClncMgt33113>");
			// Need clarity 
			
			extentReport.info("800 V Enhanced diagnostics collection feature has been Disabled on Scheduling & Messaging page for the clinic.");
			// In progress 
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			softAssert.assertEqualsWithReporting(cA_SchedulingAndMessagingPage.verifyCollectDirectTrendDiagnosticsCheckbox(),false,extentTest,"CollectDirectTrendDiagnosticsCheckbox is NOT Enabled");
			
			extentReport.info("900 V  Verify Alerts Categories (Urgent, standard or Off) are NOT editable for percent pacing alert group<ClncMgt33112>");
			alertType="Percent RV pacing greater than";
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Red"), true,extentTest,"Red radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Yellow"), true,extentTest,"Yellow radio button is opened in edit mode");
			softAssert.assertEqualsWithReporting(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyEditModeOfAlertClassification(alertType,"Off"), true,extentTest,"OFF radio button is opened in edit mode");

			
			/*	
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationVerification(alertType,"Red","Enabled");
 
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationVerification(alertType,"Yellow","Enabled");

			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationVerification(alertType,"Off","Enabled");

			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.alertNotificationVerification(alertType,"InformPatient","Enabled");
		*/		
			clinicianHomeTopNavPage.clickSignOutLink();
			
			extentReport.info("900 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			loginPage.login(login);
			softAssert.assertEqualsWithReporting(clinicianHomePage.verifyLandingPage(), true,extentTest, "ClinicianHomePage Landing");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			softAssert.assertEqualsWithReporting(clinicAdminLeftNavPage.verifyLandingPage(), true,extentTest,"Clinic Administration Page is Displayed with >Direct Alerts Settings.");
			
			extentReport.info("1000 V Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available and navigate to Direct Alerts� Settings for Pacemaker/ CRT-P devices page.",new String[] {"ClncMgt33114"});
			clinicAdminLeftNavPage.clickPacemaker_CRT_PLink ();
			softAssert.assertEqualsWithReporting(cA_DirectAlert_Pacemaker_CRTP_Page.verifyLandingPage(), true,extentTest,"Verify that under Direct Alerts Settings, Pacemaker/ CRT-P tab is available");

			extentReport.info("1100 S Click on edit button, and check the page is opened in edit mode",new String[] {"ClncMgt33114"});
			cA_DirectAlert_Pacemaker_CRTP_Page.clickEditButton();
			Thread.sleep(3000);
			boolean ed =cA_DirectAlert_Pacemaker_CRTP_Page.isEditable_findEmailField();
			//boolean ed =cA_DirectAlert_Pacemaker_CRTP_Page.isEditable_findEmailField();
			System.out.println("Email editable --> "+ed);
		
			extentReport.info("1200 S Select Alert classification as OFF and verify the inform checkbox is disabled for that alert(negative).");
			//softAssert(cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyOFFAndCheckBox(),true, "Verification of AlertCheckbox for OFF AlertType ");
			
			extentReport.info("1300 S Select Patient Notification/Inform Patient (ON or Off) for percent pacing alert group and click on save button.",new String[] {"ClncMgt33114"});
			cA_DirectAlert_Pacemaker_CRTP_Page.clickSaveButton() ;
			Thread.sleep(3000);
			clinicianHomeTopNavPage.clickSignOutLink();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			e.printStackTrace();
			throw e;

		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			e.printStackTrace();
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}


