package com.test.qa.ui.tests.UC021A_UC021B;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_DirectAlertsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_FollowUpSchedule;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_Transmitter;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_BaselineClinicalData;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_Complete;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_DirectAlertNotification;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_Transmitter;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_FollowUpSchedule;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_PatientDeviceData;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Poojitha Gangiri
 * Test case name: ICM_WA_9X_DBVerification
 */
public class ICM_WA_9X_DBVerification extends CommonUtils {
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CA_SchedulingAndMessagingPage ca_SchedulingAndMessagingPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	PL_PatientProfile_FollowUpSchedule pl_PatientProfile_FollowUpSchedulePage;
	PL_PatientProfile_DirectAlertsPage pl_PatientProfile_DirectAlertsPage;
	PL_PatientProfile_LeftNavPage pl_PatientProfile_LeftNavPage;
	CA_DirectAlert_CardiacMonitorPage ca_DirectAlert_CardiacMonitorPage;
	PatientListPage patientListPage;
	LoginPageWithPOJO loginPage;
	Login clinicUser_ICM;
	Login clinicUser_ICD_ICM;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	PL_PatientEnrollment patientEnrollment;
	PL_PatientEnrollment_FollowUpSchedule pl_PatientEnroll_FollowUp_Schedule;
	PL_PatientEnrollment_Transmitter pl_PatientEnrollment_Transmitter;
	PL_PatientProfile_Transmitter pl_PatientProfile_Transmitter;
	PL_PatientEnrollment_PatientDeviceData patientDeviceDataPage;	
	PL_PatientEnrollment_DirectAlertNotification pl_PatientEnrollment_DirectAlertNotification;
	PL_PatientEnrollment_BaselineClinicalData pl_PatientEnrollment_BaselineClinicalData;
	PL_PatientEnrollment_Complete pl_PatientEnrollment_Complete;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);	
		ca_SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);		
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);	
		patientListPage = new PatientListPage(driver,extentReport);
		pl_PatientProfile_LeftNavPage = new PL_PatientProfile_LeftNavPage(driver,extentReport);
		pl_PatientProfile_FollowUpSchedulePage = new PL_PatientProfile_FollowUpSchedule(driver,extentReport);
		pl_PatientProfile_DirectAlertsPage = new PL_PatientProfile_DirectAlertsPage(driver,extentReport);
		ca_DirectAlert_CardiacMonitorPage = new CA_DirectAlert_CardiacMonitorPage(driver,extentReport);	
		pl_PatientEnrollment_Transmitter = new PL_PatientEnrollment_Transmitter(driver,extentReport);
		pl_PatientProfile_Transmitter = new PL_PatientProfile_Transmitter(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicUser_ICM = new Login();
		clinicUser_ICD_ICM = new Login();
		testDataProvider = new TestDataProvider();
		patientEnrollment = new PL_PatientEnrollment(driver,extentReport);
		pl_PatientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		pl_PatientEnroll_FollowUp_Schedule = new PL_PatientEnrollment_FollowUpSchedule(driver,extentReport);
		patientDeviceDataPage = new PL_PatientEnrollment_PatientDeviceData(driver,extentReport);
		pl_PatientEnrollment_DirectAlertNotification = new PL_PatientEnrollment_DirectAlertNotification(driver,extentReport);
		pl_PatientEnrollment_BaselineClinicalData = new PL_PatientEnrollment_BaselineClinicalData(driver,extentReport);
		pl_PatientEnrollment_Complete = new PL_PatientEnrollment_Complete(driver,extentReport);
	}

	@Test
	public void TC_ICM_WA_9X_DBVerification() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		clinicUser_ICM = testDataProvider.getLoginData("SJMClinicUser_ICM");
		//clinicUser_ICD_ICM = testDataProvider.getLoginData("SJMClinicUser_ICM_ICD");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		List<String> list_icm = new ArrayList<String>();
        list_icm.add("ICM, DM3500");
		
		try {
			
			//Login with Clinic user as per test data scenario1
			
			extentReport.info("100 S Log in to Merlin.net with the clinic having ICM patient enrolled.");			
			loginPage.login(clinicUser_ICM,"externaluser");		
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			
		/*	extentReport.info("200 S On the EP application Navigate to clinic Administration tab and click to Scheduling and Messaging on the left navigational panel .");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();

			Assert.assertTrue(clinicAdminLeftNavPage.verifyLandingPage(), "Clinic Administration Page is NOT Displayed.");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			Assert.assertTrue(ca_SchedulingAndMessagingPage.verifyLandingPage(), "Scheduling & Messaging is NOT Displayed.");
			
			extentReport.info("300 V Verify that the default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as checked under the clear section in the application.");
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor check box is selected.");
			extentReport.reportScreenShot("Diagnostics and Episodes (including stored EGM's) checkbox under Cardiac monitor is checked ");
			
			extentReport.info("400 S Navigate to Patient list tab and Actor enrolls new ICM patient. On the enrollment page move on to follow up schedule page."); */
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickEnrollAPatientButton();
			assertion.assertEqualsWithReporting(true,patientEnrollment.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			patientEnrollment.clickManualEnrollButton();
			assertion.assertEqualsWithReporting(true,patientDeviceDataPage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			patientDeviceDataPage.enrollNewPatientManually_DynamicData("ICM",list_icm);
			patientDeviceDataPage.clickContinueButton();
			assertion.assertEqualsWithReporting(true,pl_PatientEnrollment_Transmitter.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			pl_PatientEnrollment_Transmitter.clickContinueButton();
			assertion.assertEqualsWithReporting(true,pl_PatientEnroll_FollowUp_Schedule.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			pl_PatientEnroll_FollowUp_Schedule.enterSmartScheduleStartDate();
			pl_PatientEnroll_FollowUp_Schedule.clickContinueButton();
			assertion.assertEqualsWithReporting(true,pl_PatientEnrollment_DirectAlertNotification.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");		
			pl_PatientEnrollment_DirectAlertNotification.clickContinueButton();
			assertion.assertEqualsWithReporting(true,pl_PatientEnrollment_BaselineClinicalData.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");		
			pl_PatientEnrollment_BaselineClinicalData.clickContinueButton();
			assertion.assertEqualsWithReporting(true,pl_PatientEnrollment_Complete.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");		
			pl_PatientEnrollment_Complete.clickFinishButton();
			
			
			// method for enrolling the patient would be provided by Gowshalya/Salin
			
			extentReport.info("500 V Verify that the default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as checked in the application.");
			assertion.assertEqualsWithReporting(true, pl_PatientEnroll_FollowUp_Schedule.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor check box is selected by default");
			extentReport.reportScreenShot("Default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as checked");
			
			extentReport.info("600 S After patient enrolled successfully Click on to Follow up schedule under patient profile page.");
			//Enrollment methods related to other pages should be added here
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToFollowUpSchedule();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyLandingPage(),extentReport,"FollowUp schedule Page is displayed");
			
			extentReport.info("700 V Verify that the default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as checked in the application.");
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor checkbox is selected");
			
			extentReport.info("800 V Verify the value in the database table.");
			//Need to check with Malar regarding db query
			
			extentReport.info("900 S Uncheck the Cardiac Monitor - Diagnostics, Episodes and EGMs flag on patient profile page and click to save .");
			pl_PatientProfile_FollowUpSchedulePage.clickEditButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyLandingPage(),extentReport,"FollowUp schedule Page is displayed");
			pl_PatientProfile_FollowUpSchedulePage.selectCardiacCheckBox();
			pl_PatientProfile_FollowUpSchedulePage.clickSaveButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyLandingPage(),extentReport,"FollowUp schedule Page is displayed");
			
			extentReport.info("1000 V Verify the page is saved successfully");
			assertion.assertEqualsWithReporting(false,pl_PatientProfile_FollowUpSchedulePage.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor checkbox is selected");
			extentReport.reportScreenShot("Cardiac monitor checkbox is unchecked successfully");
			
			extentReport.info("1100 V Verify that same is updated in the database table.");
			//need to check with Malar
			
			extentReport.info("1200 S Navigate to clinic Administration tab and uncheck the Cardiac Monitor - Diagnostics, Episodes and EGMs checkbox. Actor clicks to save button.");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			ca_SchedulingAndMessagingPage.ClickEditButton();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			ca_SchedulingAndMessagingPage.selectCardiacMonitorCheckbox();
			ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			
			extentReport.info("1300 V Verify that the flag unchecked is saved correctly in the Merlin.net application.");
			assertion.assertEqualsWithReporting(false,ca_SchedulingAndMessagingPage.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor checkbox is unchecked successfully");

			extentReport.info("1400 S Navigate to patient list tab and enroll new ICM patient . On the enrollment page move on to follow up schedule page .");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientEnrollment.clickEnrollNewPatientButton();
			patientEnrollment.clickManualEnrollButton();
			// method for enrolling the patient would be provided by Gowshalya/Salin
			
			extentReport.info("1500 V Verify that the default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as unchecked in the application.");
			assertion.assertEqualsWithReporting(false,pl_PatientEnroll_FollowUp_Schedule.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor check box is selected by default");
			extentReport.reportScreenShot("Default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as unchecked");
			
			extentReport.info("1600 S After patient enrolled successfully Click on to Follow up schedule under patient profile page");
			// remaining methods of patient enrollment
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToFollowUpSchedule();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyLandingPage(),extentReport,"FollowUp schedule Page is displayed");
			
			
			extentReport.info("1700 V Verify the default flag for Cardiac Monitor - Diagnostics, Episodes and EGMs is displayed as unchecked.");
			assertion.assertEqualsWithReporting(false,pl_PatientProfile_FollowUpSchedulePage.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor checkbox is unchecked");
			
			
			extentReport.info("1800 V Verify the value in the database table.");
			//Need to get the details from Malar
			
			extentReport.info("1900 S Set the Cardiac Monitor - Diagnostics, Episodes and EGMs flag as checked on patient profile page and click to save.");
			pl_PatientProfile_FollowUpSchedulePage.clickEditButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyLandingPage(),extentReport,"FollowUp schedule Page is displayed");
			pl_PatientProfile_FollowUpSchedulePage.selectCardiacCheckBox();
			pl_PatientProfile_FollowUpSchedulePage.clickSaveButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_FollowUpSchedulePage.verifyLandingPage(),extentReport,"FollowUp schedule Page is displayed");
			
			
			extentReport.info("2000 V Verify the page is saved successfully.");
			assertion.assertEqualsWithReporting(false,pl_PatientProfile_FollowUpSchedulePage.verifyCardiacMonitorCheckbox(),extentReport,"Cardiac monitor checkbox is selected");
			extentReport.reportScreenShot("Cardiac monitor checkbox is unchecked successfully");
			
			
			extentReport.info("2100 V Verify that same is updated in the database table.");
			// need to get db query from Malar
			
			extentReport.info("2200 S  Navigate to Patient list tab and select any ICM patient enrolled in the clinic. On the Patient profile tab the Actor selects the Direct Alert Notification page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToDirectAlertsNotifications();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_DirectAlertsPage.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			
			extentReport.info("2300 V Verify that the Symptom Episode flag is checked/enabled by default on patient level");
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_DirectAlertsPage.validateSymptomEpisodeFlag(),extentReport,"Symptom episode flag is checked by default");
			
			extentReport.info("2400 V Verify that same is updated in the database table.");
			//need to check with Malar
			
			extentReport.info("2500 S On the Patient profile- Direct Alerts page Actor clicks on to Edit button and unchecks the Symptom Episode checkbox. Actor clicks to save button.");
			pl_PatientProfile_DirectAlertsPage.clickEditButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_DirectAlertsPage.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			pl_PatientProfile_DirectAlertsPage.selectAlert("Symptom episode");
			pl_PatientProfile_DirectAlertsPage.clickSaveButton();
			
			extentReport.info("2600 V Verify that the  Symptom episode flag unchecked is saved successfully in the application.");
			assertion.assertEqualsWithReporting(false,pl_PatientProfile_DirectAlertsPage.validateSymptomEpisodeFlag(),extentReport,"Symptom episode flag is unchecked");
			
			extentReport.info("2700 V Verify that same is updated in the database table.");
			//Need to check with Malar
			
			extentReport.info("2800 S Navigate to clinic Administration tab and click to Cardiac Monitor-Direct Alert settings.");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.clickCardiacMonitor_Link();
			assertion.assertEqualsWithReporting(true,ca_DirectAlert_CardiacMonitorPage.verifyLandingPage(),extentReport,"Cardiac monitor Page is displayed");
			
			extentReport.info("2900 V Verify that the Symptom Episode flag is checked/enabled by default on clinic level.");
			assertion.assertEqualsWithReporting(true,ca_DirectAlert_CardiacMonitorPage.validateSymptomEpisodeFlag(),extentReport,"Symptom episode flag is checked by default");
			

			extentReport.info("3000 S Navigate to Patient list tab and select ICM patient");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToDirectAlertsNotifications();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_DirectAlertsPage.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			
			extentReport.info("3100 V Verify that the Symptom Episodes flag is checked on the Patient profile – Direct Alerts page");
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_DirectAlertsPage.validateSymptomEpisodeFlag(),extentReport,"Symptom episode flag is checked by default");
			
			extentReport.info("3200 V Verify that same is updated in the database table.");
			//Need to check with Malar
			
			extentReport.info("3300 S On the clinic Admin page- Cardiac Monitor- Direct Alert settings the Actor unchecks the Symptom episode flag and clicks to save button.");
			ca_DirectAlert_CardiacMonitorPage.clickEditButton();
			assertion.assertEqualsWithReporting(true,ca_DirectAlert_CardiacMonitorPage.verifyLandingPage(),extentReport,"Cardiac monitor Page is displayed");
			ca_DirectAlert_CardiacMonitorPage.selectAlert("Symptom episode");
			ca_DirectAlert_CardiacMonitorPage.clickSaveButton();
			
			
			extentReport.info("3400 V Verify that the Symptom episode flag unchecked is saved successfully in the application.");
			assertion.assertEqualsWithReporting(false,ca_DirectAlert_CardiacMonitorPage.validateSymptomEpisodeFlag(),extentReport,"Symptom episode flag is unchecked");
			
			extentReport.info("3500 V Verify the Symptom episode flag is set to unchecked on Patient profile – Direct Alerts page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToDirectAlertsNotifications();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_DirectAlertsPage.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			assertion.assertEqualsWithReporting(false,pl_PatientProfile_DirectAlertsPage.validateSymptomEpisodeFlag(),extentReport,"Symptom episode flag is unchecked");
			
			extentReport.info("3600 V Verify that same is updated in the database table.");
			//Need to check with Malar
		
			extentReport.info("3700 V For the new EP clinic , navigate to Clinic Administration tab -> Scheduling & Messaging page, verify the default settings at clinic level and patient level(patient newly enrolled) for ‘No communication from patient’s transmitter for’ and ‘No DirectAlerts™ Checks for’ parameters.");
			loginPage.login(clinicUser_ICD_ICM);		
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			ca_SchedulingAndMessagingPage.verifyDefaultValueForPatientAppTransmitter("8 days"); // Need to check whether all three sections to be validated
			
			
			
			extentReport.info("3800 V Verify the corresponding DB table for the above parameters.");
			//Need to check with Malar regarding the db queries
			
			extentReport.info("3900 S Change the default value of the clinic for parameters under ‘Patient Communication Messages Thresholds’ for ICM (No communication from patient’s transmitter for & No DirectAlerts™ Checks for)\r\n"
					+ "For example : \r\n"
					+ "No communication from patient’s transmitter for : 5\r\n"
					+ "No DirectAlerts™ Checks for : 14");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			ca_SchedulingAndMessagingPage.ClickEditButton();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			//need to write the generic method
			
			extentReport.info("4000 S Save the clinic level settings.");
			ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			
			extentReport.info("4100 V Verify the changes are saved at clinic level without any error. Verify the corresponding DB table is updated for the parameters change at clinic level.");
			// need to write the method and check with Malar for queries
			
			extentReport.info("4200 V Verify at the patient level while enrollment of ICM patient, the same clinic level values for ‘NODC’ & ‘No communication from patient’s transmitter’ under ‘Patient Communication Messages Thresholds’ are displayed.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientEnrollment.clickEnrollNewPatientButton();
			patientEnrollment.clickManualEnrollButton();
			//Need to add Patient enrollment method
			pl_PatientEnrollment_Transmitter.validateDefaultThresholdValues("5 days", "14 days");
			
			extentReport.info("4300 S For the same existing ICM patient, change the parameters under ‘Patient Communication Messages Thresholds’ for ICM other than clinic level values and observe the availability of Override features in edit mode.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToTransmitter();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_Transmitter.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			
			extentReport.info("4400 V Verify that Override button is displayed at patient level on Transmitter Page if values are different than clinic level settings.");
			pl_PatientProfile_Transmitter.clickEditButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_Transmitter.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			pl_PatientProfile_Transmitter.editMISTAndNODCValues("3 days","3 days");
			pl_PatientProfile_Transmitter.validateOverrideFeature();
			pl_PatientProfile_Transmitter.clickSaveButton();
			
			extentReport.info("4500 V Verify that the Override symbol is displayed ahead of the parameter having different values than clinic level.");
			pl_PatientProfile_Transmitter.validateMIST_NODCOverrideFeature();
			
			extentReport.info("4600 V Verify the corresponding DB table for the correct value at patient level.");
			//check with Malar
			
			extentReport.info("4700 S Navigate to Clinic Administration tab -> Scheduling & Messaging page, change the value of the clinic for parameters under ‘Patient Communication Messages Thresholds’ for ICM (No communication from patient’s transmitter for & No DirectAlerts™ Checks for) to different values i.e. No communication from patient’s transmitter for '7' & No DirectAlerts™ Checks for '12'");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			ca_SchedulingAndMessagingPage.ClickEditButton();
			assertion.assertEqualsWithReporting(true,ca_SchedulingAndMessagingPage.verifyLandingPage(),extentReport,"Scheduling and Messaging Page is displayed");
			//Need to use the generic method written in step 3900S
			
			extentReport.info("4800 S Save the clinic level settings.");
			ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			
			
			extentReport.info("4900 V Verify the changes are saved at clinic level without any error. 500 V Verify the corresponding DB table is updated for the parameters change at clinic level.");
			
			//check with Malar for DB queries
			
			extentReport.info("5000 S Navigate Patient List page, select any existing ICM patient. On Transmitter page, change the NODC & MIST threshold parameter values to some other than clinic level settings and save the changes.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("postmantest");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_PatientProfile_LeftNavPage.navigateToTransmitter();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_Transmitter.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			pl_PatientProfile_Transmitter.clickEditButton();
			assertion.assertEqualsWithReporting(true,pl_PatientProfile_Transmitter.verifyLandingPage(),extentReport,"Direct Alerts notifications page is displayed");
			pl_PatientProfile_Transmitter.editMISTAndNODCValues("3 days","3 days");
			pl_PatientProfile_Transmitter.clickSaveButton();
			
			extentReport.info("5100 V Verify that Override button is displayed at patient level on Transmitter Page if values are different than clinic level settings");
			pl_PatientProfile_Transmitter.validateMIST_NODCOverrideFeature();
			
			extentReport.info("5200 V Verify the corresponding DB table is updated for the parameters change at patient level.");
			// check with Malar
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}

}
