package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;


public class WA_EP_ClinicAdmin_DirectAlerts_ICM_02 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CommonUtils commonUtils;
	CA_LeftNavPage clncAdnLftNav;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	CA_ClinicAdminMobAppTransPage clncAdnMobAppTnsPg;
	CA_DirectAlert_CardiacMonitorPage cardiacMonitorPage;


	@BeforeClass
	public void initialize() {

		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clncAdnLftNav=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		clncAdnMobAppTnsPg = new CA_ClinicAdminMobAppTransPage(driver, extentReport);
		cardiacMonitorPage=new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
	}

	@Test
	public void UC021AUC021B_WA_EP_ClinicAdmin_DirectAlerts_ICM_02() throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);


		login = testDataProvider.getLoginData("DirectAll");
		extentTest.assignAuthor("Abhishek kumar");

		try {
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login,  "externaluser");
			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();

			extentTest=extentReport.info( "200 V Verify that under Direct Alerts Settings, cardiac monitor tab is available and to navigate DirectAlerts Settings for Cardiac Monitor page.", new String[] {"ClncMgt33113"});			
			assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyLandingPage(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			clncAdnLftNav.clickCardiacMonitor_Link();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyLandingPage(),extentReport,"Cardiac Monitor landing page is displayed");




			extentTest=extentReport.info( "300 V Verify a list of alert groups is displayed for which the"
					+ " clinic is authorized for Cardiac Monitor Devices(ICM) and respective Clinic's"
					+ " Jurisdiction (Ref. the ICM Alerts tab in Alerts.xlsx sheet).", new String[] {"ClncMgt33107"});			


			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.validateCardiacMonitorAlertValueInTable("US"),extentReport,"All Alerts is displayed inside Cardiac Monitor");


			extentTest=extentReport.info("400 S Click on edit button and verify page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyEditButton(), extentReport, "CardiacMonitorPage edit button is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifySaveButton(), extentReport, "CardiacMonitorPage save button  is displayed");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyCancelButton(), extentReport, "CardiacMonitorPage cancel button is displayed");


			extentTest=extentReport.info("500 V Verify Alerts Categories (Urgent, standard or Off) for the Cardiac Monitor (ICM) are editable & changes are saved.");





			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("DirectAll");
			loginPage.login(login,  "externaluser");
			extentReport.info("600 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");	


			clinicianHomeTopNavPage.clickClinicAdministrationLink();


			extentTest=extentReport.info("700 V Verify that under Direct Alerts Settings, cardiac monitor tab is available and to navigate DirectAlerts Settings for Cardiac Monitor page.", new String[] {"ClncMgt33113"});			
			assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyLandingPage(), extentReport, "Direct Alerts Settings is present");
			clncAdnLftNav.verifyDirectAlertTab_new();
			clncAdnLftNav.clickCardiacMonitor_Link();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyLandingPage(),extentReport,"Cardiac Monitor landing page is displayed");


			extentTest=extentReport.info("900 S Click on edit button and verify page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyEditButton(), extentReport, "CardiacMonitorPage edit button is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifySaveButton(), extentReport, "CardiacMonitorPage save button  is displayed");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyCancelButton(), extentReport, "CardiacMonitorPage cancel button is displayed");

			extentTest=extentReport.info("800 V Verify a list of alert groups is"
					+ " displayed for which the clinic is authorized for Cardiac "
					+ "Monitor Devices(ICM) and respective Clinic's Jurisdiction "
					+ "(Ref. the ICM Alerts tab in Alerts.xlsx sheet).", new String[] {"ClncMgt33107"});			

			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.validateCardiacMonitorAlertValueInTable("OUS"),extentReport,"All Alerts is displayed inside Cardiac Monitor");



			extentTest=extentReport.info("900 S Click on edit button and verify page is opened in edit mode.");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyEditButton(), extentReport, "CardiacMonitorPage edit button is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifySaveButton(), extentReport, "CardiacMonitorPage save button  is displayed");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyCancelButton(), extentReport, "CardiacMonitorPage cancel button is displayed");


			extentTest=extentReport.info("1000 V Verify Alerts Categories (Urgent, standard or Off) "
					+ "for the Cardiac Monitor (ICM) are editable & changes are saved",new String[] {"ClncMgt33109"});
			cardiacMonitorPage.editAndVerifyAlertCategory("OUS");



			extentTest=extentReport.info("1300 S Click on edit button and verify page is opened in edit mode. ");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyEditButton(), extentReport, "CardiacMonitorPage edit button is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifySaveButton(), extentReport, "CardiacMonitorPage save button  is displayed");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyCancelButton(), extentReport, "CardiacMonitorPage cancel button is displayed");


			extentTest=extentReport.info("1400 V Verify Alerts Categories (Urgent, standard or Off)"
					+ " for the Cardiac Monitor (ICM) are editable click on cancel button.  ", new String[] {"ClncMgt33109"});
			cardiacMonitorPage.editAndVerifyAlertCategoryAfterCancellation("OUS");



			extentTest=extentReport.info("1500 V Verify changes made on page is not saved & "
					+ "page is again opened in view mode.",new String[] {"ClncMgt33109"});
			//pending implementation
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyEditButton(), extentReport, "CardiacMonitorPage edit button is displayed");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyDisableOREnableStatus("US"),extentReport,"Radio button is in disable state");

			extentTest=extentReport.info("1600 S Click on edit button and verify page is opened in edit mode. ");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyEditButton(), extentReport, "CardiacMonitorPage edit button is displayed");
			clncAdnMobAppTnsPg.clickClinicEditButton();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifySaveButton(), extentReport, "CardiacMonitorPage save button  is displayed");
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyCancelButton(), extentReport, "CardiacMonitorPage cancel button is displayed");


			extentTest=extentReport.info("1700 V Verify Alerts Categories (Urgent, standard or Off)"
					+ " for the Cardiac Monitor (ICM) are editable and navigate to different page.", new String[] {"ClncMgt33109"});	
			cardiacMonitorPage.editAndVerifyAlertCategoryAfterCancellation("OUS");
			clncAdnLftNav.navigateToMerlinAtHomeTransmitterPage();
			
			driverScript.sendspecialKeysOnPage("Enter");
			
			
		   assertion.assertEqualsWithReporting(true,directAlert_MerlinAtHomePage.verifyLandingPage(),extentReport, "MerlinHome Page is displayed");
			clncAdnLftNav.navigateToMobileAppTransmitterPage();
			
			assertion.assertEqualsWithReporting(true,clncAdnMobAppTnsPg.verifyLandingPage(),extentReport, "Mobile Application Page is displayed");
			clncAdnLftNav.navigatePacemaker_CRTPLink();
			
			assertion.assertEqualsWithReporting(true,pacemaker.verifyLandingPage(),extentReport, "Pacemaker Page  is displayed");
			clncAdnLftNav.navigateToCardiacMonitorLink();
			assertion.assertEqualsWithReporting(true,cardiacMonitorPage.verifyLandingPage(),extentReport, "Cardiac Monitor Page is displayed");
			//pending for implementation

			extentTest=extentReport.info("1800 V Verify the warning pop-up is displayed "
					+ "before navigating to some different page & changes are not saved on page", new String[] {"CommUI4400"});

			clncAdnLftNav.navigatePacemaker_CRTPLink();
			assertion.assertEqualsWithReporting(true,driverScript.isAlertPresent(),extentReport,"Alert pop up is displayed on navigation to different page");
			clncAdnLftNav.navigateToCardiacMonitorLink();
			//pending for implementation



			extentTest=extentReport.info("1900 S Click on leave this page"
					+ " and verify chages are not saved on exiting page");
			
			
		}

		catch (AssertionError e) {
			extentTest = extentReport.fail( "UC021A UC021B 11.0_WA_EP_ClinicAdmin_DirectAlerts_ICM_02 is failed due to assertion failure");
			extentTest.fail("UC021A UC021B 11.0_WA_EP_ClinicAdmin_DirectAlerts_ICM_02 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("UC021A UC021B 11.0_WA_EP_ClinicAdmin_DirectAlerts_ICM_02 is failed due to some exception");
			extentTest.fail("UC021A UC021B 11.0_WA_EP_ClinicAdmin_DirectAlerts_ICM_02 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}


