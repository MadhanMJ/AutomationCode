package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_PatientDeviceData;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.utilities.CommonUtils;


public class ICM_WA_Clinic_Administrator_Scheduling_and_Messaging_01 extends CommonUtils {
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_SchedulingAndMessagingPage ca_ScheduleMessagingPage;
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withOnlyICDDevice;
	Login loginAlliedProfessional;
	Login loginPhysician;
	Login loginSJMAdmin;
	Login loginClinicUser_withICMDevice;
	ExtentTest extentTest;
	String testName;
	TestDataProvider testDataProvider;
	Customer customer;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	AppHomeTopNavPage appHomeTopNavPage; 
	PatientListPage patientListPage;
	PL_PatientEnrollment patientEnrollPage;
	PL_PatientEnrollment_PatientDeviceData patientDeviceDataPage;
	PL_TransmissionPage patientTransmissionPage;
	PL_PatientProfilePage patientProfilePage;
	Patient patient;
	

	@BeforeClass
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withOnlyICDDevice = new Login();
		loginClinicUser_withICMDevice = new Login();
		loginAlliedProfessional = new Login();
		loginPhysician = new Login();
		loginSJMAdmin = new Login();
		customer =  new Customer();
		testDataProvider = new TestDataProvider();
		ca_ScheduleMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver,extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver, extentReport);		
		patientEnrollPage = new PL_PatientEnrollment(driver, extentReport);
		patientProfilePage = new PL_PatientProfilePage(driver, extentReport);
		patientTransmissionPage = new PL_TransmissionPage(driver, extentReport);
		patientDeviceDataPage = new PL_PatientEnrollment_PatientDeviceData(driver, extentReport);
		patient = new Patient();
	}

	@Test
	public void TestCase_ICM_WA_Clinic_Administrator_Scheduling_and_Messaging_01() throws Exception {
		testName = CommonUtils.getTestName();
		Assertions assertion =  new Assertions(extentTest);
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		customer = testDataProvider.getCustomerData(testName);
		loginAlliedProfessional = testDataProvider.getLoginData("AlliedProf1");
		loginClinicUser_withOnlyICDDevice = testDataProvider.getLoginData("clinic_1_ICD"); //clinic 2
		loginClinicUser_withICMDevice = testDataProvider.getLoginData("clinic_2_ICM"); //Clinic 1
		loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
		extentTest.assignAuthor("Author: Salin.gambhir");
		String[] expectedSections = {"Automatically Clear", "compliance for Patient Application transmitter connectivity"};
		String[] followUpSections = {""};
		try {
			
			List<String> list_icm = new ArrayList<String>();
	        list_icm.add("Jot Dx ICM, DM4500");
						
	        extentTest = extentReport.info("100 S Login to Clinic1, select Clinic Administration tab. Navigate to ‘Scheduling & Messaging’ page and observe “Automatically Clear” & \" compliance for Patient Application transmitter connectivity\" sections.");
			loginPage.login(loginClinicUser_withOnlyICDDevice);	
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			assertion.assertEqualsWithReporting(true, ca_ScheduleMessagingPage.verifyLandingPage(),extentReport, "Clinican Scheduling and MEssaging page is NOT displayed");
		
			boolean checkSection = false;
			boolean checkCheckBoxCardiac, checkParameters, checkCancelButton = false;
			String stateCardicMonitorCheckBox = "";
			
			for(String section: expectedSections)
			{
				assertion.assertTrue(ca_ScheduleMessagingPage.verifySections(section));
				extentTest = extentReport.reportPass(section + " exist on Scheduling and messaging page");
			}
			
			extentTest = extentReport.info("200 V Verify that a checkbox “Cardiac Monitor->Diagnostics, Episodes and EGMs” is not displayed.", new String[] {"<ClncMgt31960>"});
			assertion.assertFalse(ca_ScheduleMessagingPage.verifyCardiacMonitor());
			
			extentTest = extentReport.info("300 V Verify that following parameters are not displayed for the clinic under ‘Patient Application transmitter connectivity’ section:", new String[] {" <ClncMgt33077>"});
			assertion.assertFalse(ca_ScheduleMessagingPage.verifyPartition());
			
			clinicianHomeTopNavPage.clickSignOutLink();
			
			
			extentTest = extentReport.reportPass("400 S Login to Clinic2, select Clinic Administration tab. Navigate to ‘Scheduling & Messaging’ page and observe “Automatically Clear” & \" compliance for Patient Application transmitter connectivity\" sections.");
			loginPage.login(loginClinicUser_withICMDevice);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			assertion.assertTrue(ca_ScheduleMessagingPage.verifyLandingPage(), "Clinican Scheduling and MEssaging page is NOT displayed");
			
			for(String section: expectedSections)
			{
				assertion.assertTrue(ca_ScheduleMessagingPage.verifySections(section));
				extentTest = extentReport.reportInfo(section + " exist on Scheduling and messaging page");
			}
			
			extentTest = extentReport.info("500 V Verify that a checkbox “Cardiac Monitor->Diagnostics, Episodes and EGMs” is displayed and checked by default.", new String[] {"<ClncMgt31960> <ClncMgt31963> <Config22969>"});
			assertion.assertTrue(ca_ScheduleMessagingPage.verifyCardiacMonitor());
			
			extentTest = extentReport.info("600 V Verify capability is provide for the clinic to monitor ‘Patient Application transmitter connectivity’ section and ‘ICD/Pacemaker Transmitter connectivity’:", new String[] {"<ClncMgt33077>, <ClncMgt32071>"});
			assertion.assertFalse(ca_ScheduleMessagingPage.verifyPartition());
			
			extentTest = extentReport.info("700 S On ‘Scheduling & Messaging’ page, change the check state of Diagnostics checkbox by clicking edit button.");
			ca_ScheduleMessagingPage.clickEditButton();
			assertion.assertEqualsWithReporting(true, ca_ScheduleMessagingPage.checkPageInEditMode(), extentReport, "Page is in Edit mode");
			ca_ScheduleMessagingPage.changeStateOfDiagnosticsCheckBox();
			stateCardicMonitorCheckBox = ca_ScheduleMessagingPage.getCardiacCheckBoxStatus();
			
			extentTest = extentReport.info("800 V Verify that Cancel button is displayed on Scheduling & messaging page.", new String[] {"<ClncMgt26837>"});
			assertion.assertEqualsWithReporting(true, ca_ScheduleMessagingPage.verifyCancelButton(), extentReport, "Cancel Button is located on page");
			
			extentTest = extentReport.reportInfo("900 S Click on Cancel button.");
			ca_ScheduleMessagingPage.clickCancelButton();
						
			extentTest = extentReport.info("1000 V Verify that the changes made in the state of Diagnostic checkbox is not saved and old state of the checkbox is retained.", new String[] {"<ClncMgt26837>"} );
			assertion.assertFalse(stateCardicMonitorCheckBox.equals(ca_ScheduleMessagingPage.getCardiacCheckBoxStatus()));
			
			extentTest = extentReport.reportInfo("1100 S Change the check state of Diagnostics checkbox by clicking edit button and Save the changes.");
			ca_ScheduleMessagingPage.clickEditButton();
			ca_ScheduleMessagingPage.changeStateOfDiagnosticsCheckBox();
			stateCardicMonitorCheckBox = ca_ScheduleMessagingPage.getCardiacCheckBoxStatus();
			ca_ScheduleMessagingPage.clickSaveButton();
			
			extentTest = extentReport.info("1200 V Verify that the changes are saved properly and displayed on Scheduling and Messaging page.", new String[] {"<ClncMgt26840>"});
			assertion.assertEqualsWithReporting(true, stateCardicMonitorCheckBox.equals(ca_ScheduleMessagingPage.getCardiacCheckBoxStatus()), extentReport, "Cardiac monitor CheckBox status matches correctly");
			
			extentTest = extentReport.reportInfo("1300 S Logout from Clinic 2.");
			clinicianHomeTopNavPage.clickSignOutLink();
			
			customer = testDataProvider.getCustomerData("testName_newclinic");
			extentTest = extentReport.reportInfo("1400 S Login to SJM Admin, search and select Clinic2. Edit the clinic to remove ICM device from it and save the changes.");
			loginPage.login(loginSJMAdmin);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.removeDevicesFromAllowedListAndSave(list_icm);
			
			extentReport.reportInfo("1500 S Logout from SJM Admin.");
			//sjm logout need to be checked
			appHomeTopNavPage.clickSignOutLink(); 
			
			extentTest = extentReport.reportInfo("1600 S Login to Clinic 2. Select Clinic Administration Tab. Navigate to ‘Scheduling & Messaging’ page and observe “Automatically Clear” section.");
			loginPage.login(loginClinicUser_withICMDevice);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			assertion.assertTrue(ca_ScheduleMessagingPage.verifyLandingPage(), "Clinican Scheduling and MEssaging page is NOT displayed");

			for(String section: expectedSections)
			{
				
				assertion.assertTrue(ca_ScheduleMessagingPage.verifySections(section));
				extentReport.reportInfo(section + " exist on Scheduling and messaging page");
			}
			
			extentTest = extentReport.info("1700 V Verify that a checkbox “Cardiac Monitor->Diagnostics, Episodes and EGMs” is not displayed.", new String[] {"<ClncMgmt31960>"});
			assertion.assertEqualsWithReporting(false,ca_ScheduleMessagingPage.verifyCardiacMonitor(), extentReport, "Cardiac Monitor Status matches correctly");
			
			extentTest = extentReport.info("1800 V Verify that the scheduling method is set to None for a new clinic.", new String[] {"<ClncMgt30989>, <Config23024>"});
			assertion.assertEqualsWithReporting(false, ca_ScheduleMessagingPage.verifyMobileAPPTransmitterSection(), extentReport, "APP Transmitter Section");
			
			
			extentTest = extentReport.reportInfo("1900 S Logout from Clinic 2.");
			clinicianHomeTopNavPage.clickSignOutLink();
			
			extentTest = extentReport.reportInfo("2000 S Login to SJM Admin, search and select Clinic2. Edit the clinic to add ICM device and save the changes.");
			// code for customer page to add ICM device
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.addDevicesToAllowedListAndSave(list_icm);
			
			
			extentTest = extentReport.reportInfo("2100 S Logout from SJM Admin.");
			//sjm logout need to be checked
			customerListPage.verifyLogout(); 
			
			extentTest = extentReport.reportInfo("2200 S Login to Clinic 2. Select Clinic Administration Tab. Navigate to ‘Scheduling & Messaging’ page and observe 'Patient Communication Message Thresholds' section.");
			loginPage.login(loginClinicUser_withICMDevice);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			Assert.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyLandingPage(), "Clinican Scheduling and MEssaging page is NOT displayed");
			
			Assert.assertFalse(ca_ScheduleMessagingPage.verifyMobileAPPTransmitterSection());
			
			extentTest = extentReport.reportInfo("2300 V Verify the following fields under ‘Patients with Mobile App transmitters’ sections are displayed: <ClncMgt33077>");
			Assert.assertTrue(ca_ScheduleMessagingPage.verifypatientAPPTransmitter());
			
			extentTest = extentReport.reportInfo("2400 V Verify the following field under ‘ICD/Pacemaker Transmitter connectivity, sections is displayed: <ClncMgt32071>");
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyICDPatient());
			
			clinicianHomeTopNavPage.clickSignOutLink();

			/// setup 1
			
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Scheduling and Messaging page.");
			loginPage.login(loginClinicUser_withOnlyICDDevice);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			Assert.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyLandingPage(), "Clinican Scheduling and MEssaging page is NOT displayed");

			extentReport.info("200 V Verify that under Automatically clear section, Mobile App Transmitter is available."); 
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyMobileAPPTransmitterSection());
			
			 
			extentReport.info("300 V Verify under Mobile APP Transmitter section ->ICD/ CRT-D sub-section is displayed.");
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyICDCRTPsection()); 
			extentReport.info("300 V Verify on the same page under Disconnected Transmitter Thresholds section -> Patients with Mobile App transmitters sub section is displayed with the default dropdown values as 7.");
			Assert.assertTrue(ca_ScheduleMessagingPage.verifypatientAPPTransmitter());
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyDefaultValueForPatientAppTransmitter("7"));
			 
			extentReport.info("400 Verify the same in database for clinic level setting.");
			// add code to verify in db
			
			extentTest = extentReport.reportInfo("500S Navigate to Patient List Page and Click on Enroll a new patient -> Enroll Manually");
			clinicianHomeTopNavPage.clickPatientListLink();
			patientListPage.clickEnrollAPatientButton();
			assertion.assertEqualsWithReporting(true, patientEnrollPage.verifyLandingPage(), extentTest, "Enrolling a Patient page is successful");
			patientEnrollPage.clickManualEnrollButton();
			
			 
			extentTest = extentReport.reportInfo("600S Search for ConfirmRx (ICM Device) in the Device Name dropdown and Enroll the patient");
			patientDeviceDataPage.searchDeviceInEnrollDeviceDropDown(list_icm);
			
			
			extentTest = extentReport.reportInfo("700V Verify that the Device is not displayed");
			assertion.assertEqualsWithReporting(true, patientDeviceDataPage.verifyDeviceInDropDown(list_icm, "not available"), extentReport, "Device not listed");
			
			extentTest = extentReport.reportInfo("800S Click on Enroll a Patient -> Search for NGQ Device in the Device Name dropdown and Enroll the patient");
			patientDeviceDataPage.searchDeviceInEnrollDeviceDropDown(list_icm);
			assertion.assertEqualsWithReporting(true, patientDeviceDataPage.verifyDeviceInDropDown(list_icm, "available"), extentReport, "Device not listed");
			
			extentTest = extentReport.reportInfo("900S Enter all the mandatory details and click on Save and Close. Select the patient from patient list");
			patientDeviceDataPage.enrollNewPatientManually("NGQ",list_icm, patient);
			patientDeviceDataPage.clickOnSaveAndCloseButton();
			
			extentTest = extentReport.reportInfo("1000V Verify that on the Transmitter Page the Disconnected Transmitter Thresholds values for NGQ is set as per clinic defaults (7days)");
			clinicianHomeTopNavPage.clickPatientListLink();
			patientListPage.clickOnPatientNameFrmList("patient name created in 900");
			patientProfilePage.clickOnLeftPatientLink("Transmitter");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyDisconnectedTransmitterThreshold("NGQ", "7 Days", "7 Days"), extentReport, "Disconnected Transmitter Threshold value is set to default as 7 days");
			
			extentTest = extentReport.reportInfo("1100V Verify in the DB for the Patient Disconnected Transmitter Thresholds values are set to 7 days as seen on the webapp");
			int MISTValue = 7, NODCValue = 7;
			int patient_id = patientProfilePage.getPatientID("patient firstName");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyPatientDisconnectedTransmitterDBValues(patient_id, MISTValue, NODCValue), extentReport, "DB entries should be expecyed");
			
			extentTest = extentReport.reportInfo("1200V Verify on Follow-up Schedule -> Clear section is displayed as per that applicable to ICM device and is set as per clinic level defaults");
			patientProfilePage.clickOnLeftPatientLink("Follow-Up Schedule");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyFollowUPClear("NGQ"), extentReport, "Follow up clear section has ");
			
			
			extentTest = extentReport.reportInfo("1300V Verify in the DB for the Patient Clear section is set as per clinic level defaults");
			
			
			extentTest = extentReport.reportInfo("1400S Navigate back to Transmitter tab and Click on Edit");
			patientProfilePage.clickOnLeftPatientLink("Transmitter");
			patientProfilePage.clickEditButton();
			 
			extentTest = extentReport.reportInfo("1500S Change the Disconnected Transmitter Thresholds values for NGQ other than the default values (Override) and click on Save option");
			String changeValue = "8 days";
			patientProfilePage.changeDisconnectedThreshold(changeValue);
			patientProfilePage.clickSaveButton();
			
			extentTest = extentReport.reportInfo("1600V Verify the overriden values have been updated on the webapp as well as in the database");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyDisconnectedTransmitterThreshold("NGQ", changeValue, "7 days"), extentReport, "Disconnected Threshold values are as expected");
			
			extentTest = extentReport.reportInfo("1700S Verify that the history table shows the previous values for thresholds");
			
			
			//Setup 2
			extentReport.info("100 S Login with Test setup 2 and navigate to Clinic Administration tab >Scheduling and Messaging page.");
			loginPage.login(loginClinicUser_withOnlyICDDevice);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			Assert.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyLandingPage(), "Clinican Scheduling and MEssaging page is NOT displayed");
			 
			extentReport.info("200 V Verify that under Automatically clear section, Mobile App Transmitter is available."); 
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyMobileAPPTransmitterSection()); 
			extentReport.info("300 V Verify under Mobile APP Transmitter section ->Cardiac monitor sub-section is displayed.");
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyCardiacMonitor()); 
			 
			extentReport.info("300 V Verify on the same page under Disconnected Transmitter Thresholds section -> Patients with Mobile App transmitters sub section is displayed with the default dropdown values as 7.");
			Assert.assertTrue(ca_ScheduleMessagingPage.verifyDefaultValueForPatientAppTransmitter("7"));
			
			extentReport.info("400 Verify the same in database for clinic level setting.");
			
			extentTest = extentReport.reportInfo("500S Navigate to Patient List Page and Click on Enroll a new patient -> Enroll Manually");
			clinicianHomeTopNavPage.clickPatientListLink();
			patientListPage.clickEnrollAPatientButton();
			assertion.assertEqualsWithReporting(true, patientEnrollPage.verifyLandingPage(), extentTest, "Enrolling a Patient page is successful");
			patientEnrollPage.clickManualEnrollButton();
			
			 
			extentTest = extentReport.reportInfo("600S Search for ConfirmRx (ICM Device) in the Device Name dropdown and Enroll the patient");
			patientDeviceDataPage.searchDeviceInEnrollDeviceDropDown(list_icm);
						
			extentTest = extentReport.reportInfo("700S Enter all the mandatory details and click on Save and Close. Select the patient from patient list");
			patientDeviceDataPage.enrollNewPatientManually("ICM", list_icm, patient);
			patientDeviceDataPage.clickOnSaveAndCloseButton();
			
			extentTest = extentReport.reportInfo("800V Verify that on the Transmitter Page the Disconnected Transmitter Thresholds values for ICM is set as per clinic defaults (7days)");
			clinicianHomeTopNavPage.clickPatientListLink();
			patientListPage.clickOnPatientNameFrmList("patient name created in 900");
			patientProfilePage.clickOnLeftPatientLink("Transmitter");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyDisconnectedTransmitterThreshold("NGQ", "7 Days", "7 Days"), extentReport, "Disconnected Transmitter Threshold value is set to default as 7 days");
			
			extentTest = extentReport.reportInfo("900V Verify in the DB for the Patient Disconnected Transmitter Thresholds values are set to 7 days as seen on the webapp");
			MISTValue = 7; NODCValue = 7;
			patient_id = patientProfilePage.getPatientID("patient firstName");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyPatientDisconnectedTransmitterDBValues(patient_id, MISTValue, NODCValue), extentReport, "DB entries should be expecyed");
			
			extentTest = extentReport.reportInfo("1000V Verify on Follow-up Schedule -> Clear section is displayed as per that applicable to ICM device and is set as per clinic level defaults");
			patientProfilePage.clickOnLeftPatientLink("Follow-Up Schedule");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyFollowUPClear("ICM"), extentReport, "Follow up clear section has ");
			
			
			extentTest = extentReport.reportInfo("1100V Verify in the DB for the Patient Clear section is set as per clinic level defaults");
			 
			extentTest = extentReport.reportInfo("1200S Navigate back to Transmitter tab and Click on Edit");
			patientProfilePage.clickOnLeftPatientLink("Transmitter");
			patientProfilePage.clickEditButton();
			 
			extentTest = extentReport.reportInfo("1300S Change the Disconnected Transmitter Thresholds values for ICM other than the default values (Override) and click on Save option");
			changeValue = "8 days";
			patientProfilePage.changeDisconnectedThreshold(changeValue);
			patientProfilePage.clickSaveButton();
			
			 
			extentTest = extentReport.reportInfo("1400V Verify the overriden values have been updated on the webapp as well as in the database");
			assertion.assertEqualsWithReporting(true, patientProfilePage.verifyDisconnectedTransmitterThreshold("NGQ", changeValue, "7 days"), extentReport, "Disconnected Threshold values are as expected");
			 
			extentTest = extentReport.reportInfo("1500S Verify that the history table shows the previous values for thresholds");
			
			extentTest = extentReport.reportInfo("1600S Click on Enroll a Patient -> Search for NGQ Device in the Device Name");
			assertion.assertEqualsWithReporting(true, patientDeviceDataPage.verifyDeviceInDropDown(list_icm, "not available"), extentReport, "Device not listed");
			
			extentTest = extentReport.reportInfo("1700V Verify that the Device is not displayed");
			patientDeviceDataPage.searchDeviceInEnrollDeviceDropDown(list_icm);
			assertion.assertEqualsWithReporting(true, patientDeviceDataPage.verifyDeviceInDropDown(list_icm, "available"), extentReport, "Device not listed");

			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			e.printStackTrace();
			throw e;

		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			e.printStackTrace();
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}

}


