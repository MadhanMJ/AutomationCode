package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;


public class WA_CA500_DirectAlerts_EditDirectAlerts extends CommonUtils {
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage cA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page	cA_DirectAlert_Pacemaker_CRTP_Page;
	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	String testName,alertType,component;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		cA_DirectAlert_ICD_CRTD_MerlinAtHomePage= new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		cA_DirectAlert_Pacemaker_CRTP_Page= new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void wA_CA500_DirectAlerts_EditDirectAlerts() throws Exception {
		testName = CommonUtils.getTestName();
		softAssert = new Assertions(extentTest);
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		customer = testDataProvider.getCustomerData(testName);
		login = testDataProvider.getLoginData("SJMClinic");
		extentTest.assignAuthor("Author: ChandraMohan.Singaram");
		try {
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			loginPage.login(login);
			hardAssert(clinicianHomePage.verifyLandingPage(), true,extentTest, "ClinicianHomePage Landing");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			hardAssert(clinicAdminLeftNavPage.verifyLandingPage(), true,extentTest,"Clinic Administration Page is Displayed with >Direct Alerts Settings.");

			extentReport.info("TBD-200-V- Verify that on footer of page,  there is note regarding software version of transmitter",new String[] {"CommUI8634"});

			clinicAdminLeftNavPage.clickPacemaker_CRT_PLink ();
			hardAssert(cA_DirectAlert_Pacemaker_CRTP_Page.verifyLandingPage(), true,extentTest,"Verify that Pacemaker_CRTP_Page is available");

			extentReport.info("300-S- Click on the Edit button");
			cA_DirectAlert_Pacemaker_CRTP_Page.clickEditButton();

			extentReport.info("400-V- Verify that the Direct Alerts settings for Pacemaker/CRT-D page is displayed in the Edit mode.",new String[] {"ClncMgt30312"});
			softAssert.assertEqualsWithReporting(true, cA_DirectAlert_Pacemaker_CRTP_Page.findCancelButton(), extentTest, "Found cancel button in Edit mode");
			softAssert.assertEqualsWithReporting(true, cA_DirectAlert_Pacemaker_CRTP_Page.findSaveButton(), extentTest, "Found save button in Edit mode");

			extentTest = extentReport.info("TBD- 500 V Verify that the following fields are displayed: 1. Urgent Alerts section: Send urgent Alerts During/ After Office Hours dropdown,2.Standard Alerts section: Send urgent Alerts During/ After Office Hours dropdown,");
			extentTest = extentReport.info("TBD- 500 V Verify that the following fields are displayed: "
					+ "1. Urgent Alerts section: Send urgent Alerts During/ After Office Hours dropdown,"
					+ "2.Standard Alerts section: Send urgent Alerts During/ After Office Hours dropdown,"
					+ "");
			extentTest = extentReport.info("TBD- 500 V Verify that the following fields are displayed: 3. Medical Team section: a. Send Alerts After hours dropdown,b. On-call physician contact type dropdown,");
			extentTest = extentReport.info("TBD- 500 V Verify that the following fields are displayed: 3. c. On-call contact method",new String[] {"ClncMgt30914","ClncMgt30316","ClncMgt30910","ClncMgt30911","ClncMgt30912"});

			extentTest = extentReport.info("600 V Verify that the Clinic Information section consists of the following contact methods:1.Text message,2. Phone,3. Email,4. Fax <ClncMgt29701> <CommUI8609>",new String[] {"ClncMgt29701","CommUI8609"});
			component="TextMessage";
			softAssertO(cA_DirectAlert_Pacemaker_CRTP_Page.findTextMessageField(),true,component +" is displayed");

			component="FindPhoneNumber";
			softAssertO(cA_DirectAlert_Pacemaker_CRTP_Page.findPhoneNumberField(),true,component +" is displayed");

			component="FindEmail";
			softAssertO(cA_DirectAlert_Pacemaker_CRTP_Page.findEmailField(),true,component +" is displayed");

			component="FindFax";
			//softAssertO(cA_DirectAlert_Pacemaker_CRTP_Page.findFaxField(),true,component +" is displayed");

			extentReport.info("700 V Verify that an instructional text about the Alert transmissions to indicate that all alerts will be displayed in the list of transmissions is displayed in the footer ",new String[] {"CommUI8629"});
			component="ALL alerts can always be seen in Recent Transmissions.";
			softAssertO(cA_DirectAlert_Pacemaker_CRTP_Page.instructionalTextOfAlertTransmissions(),component,component +" is displayed");

			extentReport.info("800 V Verify that an instructional text about the On Call Physician to indicate that the On-call physician is always a member of the Medical team",new String[] {"CommUI8630"});
			component="findPhysicianInfoMessage()";
			softAssertO(cA_DirectAlert_Pacemaker_CRTP_Page.findPhysicianInfoMessage(),true,component +" is displayed");

			/*********FAX**********/
			extentReport.info("TBD-900-S- Select Fax as the Contact method for Urgent Alerts notification during office hours.");

			extentReport.info("TBD-1000-S- Click on Save button leaving the Fax field in the Clinic Contact information section blank.");

			extentReport.info("TBD-1100-S- Click OK on the confirmation dialog that appears.");

			extentReport.info("TBD-1200-V- Verify that the page does not get saved with the changes and a message CS 818 stating that the Fax field requires to filled in is displayed.",new String[] {"ClncMgt269","ClncMgt30317","ClncMgt30319","CommUI8090","ClncMgt30321"});

			extentReport.info("TBD-1300-S- Select SMS as the Contact method for Urgent Alerts notification during office hours.");

			extentReport.info("TBD-1400-S- Click on Save button leaving the SMS field in the Clinic Contact information section blank.");

			extentReport.info("TBD-1500-S- Click OK on the confirmation dialog that appears.");

			extentReport.info("1600-V- Verify that the page does not get saved with the changes and a message CS 818 stating that the Text Message field requires to filled in is displayed.",new String[] {"ClncMgt269","ClncMgt30317","ClncMgt30319","CommUI8090","ClncMgt30321"});

			/*********Phone**********/

			extentReport.info("1700-S- The actor submits an incomplete Phone Number Complex. Enter 1 (empty area city code) 1234567 (Ensure that the clinic is a US Clinic)");
			// commenting below line as the page has got updated ....
			//cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneNumberWithCodes("1", "", "1234567");

			extentReport.info("TBD-1800-V- The system displays message CS 816",new String[] {"ClncMgt30317","ClncMgt30319","ClncMgt30323","ClncMgt30321"});


			/*****************Phone Number Country Code Validation*****************/

			extentReport.info("TBD-1900-S The actor enters an invalid Country Code which uses alphabetic characters, which has less than 3 or more than 1 digits, then clicks Save button.");
			/*	
			Test each following invalid inputs:
			1. enter (empty Country Code) 123 1234567
			2. enter 1a3 123 1234567
			 */
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneCountryCode", "");
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneCountryCode", "1a3 123 1234567");

			extentReport.info("TBD-2000-V-Verify that the system displays message CS 816.",new String[] {"ClncMgt30317","ClncMgt30319","ClncMgt30323","ClncMgt30321"});

			/*****************Phone Number Area-City Code Validation*********************/
			extentReport.info("2100-S- The actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button.");

			/*Test each following invalid inputs:
			1. enter 1 12 1234567
			2. enter 1 1234 1234567
			3. enter 1 A12 1234567 */
			
			//Commenting the below section as application went through some changes ///
			/*cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneAreaCode", "12");
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneAreaCode", "1234");
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneAreaCode", "A12");
			 */
			extentReport.info("TBD-2200-V-Verify that the system displays message CS 816.",new String[] {"ClncMgt30317","ClncMgt30319","ClncMgt30323","ClncMgt30321"});

			/********************Phone Number Validation************************/
			extentReport.info("2300-S- The actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks Save button.");
			/*Test each following invalid inputs:
			1. enter 1 123 123456
			2. enter 1 123 12345678
			3. enter 1 123 12A4567 */ 
			 
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneNumber", "123456");
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneNumber", "12345678");
			cA_DirectAlert_Pacemaker_CRTP_Page.fillPhoneData("PhoneNumber", "12A4567");

			extentReport.info("TBD-2400-V-Verify that the system displays message CS 816.",new String[] {"ClncMgt30317","ClncMgt30319","ClncMgt30323"});

/****Exhaustive and huge test step***** Need accepted Approach before Implementation****/
			extentReport.info("2500-S-The actor enters a valid Phone Number Complex, which has 1 numerical digit for country code,"
					+ "3 numerical digits for Area City Code and 7 numerical digits for Phone Number;"
					+ "then clicks corresponding button (see parent test case) to submit the form to the system for validation."
					+ "Include a Phone number complex which uses space, - , or ( and ) "
					+ "for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567\r\n"
					+ "	(Note: "
					+ "	1. Phone Number Country Code should be 1 to 3 numeric digits. '('- open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - space should be accepted as additional entry values but should be removed upon save and not re-displayed. "
					+ "(single byte entry only)"
					+ "	2. The Phone Number Area-City Code should be 3 numeric digits if the associated phone number country code corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed."
					+ "	Canada has same country code and will be validated the same as the US. Note: Some European countries consider the area/city code to be optional."
					+ "	3. The Phone Number should be 7 numeric digits if the associated phone number country code corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed. Note, Canada has same country code and will be validated the same as the US. (single byte entry only)"); 
			
			extentReport.info("TBD-2600-V-Verify that the system saves the value and message CP 803 is displayed.",new String[] {"ClncMgt30317","ClncMgt30319","ClncMgt30323"});
			


			clinicianHomeTopNavPage.clickSignOutLink();

		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			e.printStackTrace();
			throw e;

		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}


