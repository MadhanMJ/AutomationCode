package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vinay Babu, Shafiya Sunkesala
 * Test Case: 11.0_WA_EP_Alert_Sub-Categories
 */

public class $_11_0_WA_EP_Alert_Sub_Categories extends CommonUtils {

	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage ca_DirectAlert_ICD_CRTD_MerlinAtHomePage;
	//AppHomeTopNavPage appHomeTopNavPage;
	
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withoutICDDevice;
	Login loginAdminUser;
	Login loginClinicUser_withNonBluetooth_ICDDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		
		ca_DirectAlert_ICD_CRTD_MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		
		
//		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
//		
//		loginPage = new LoginPageWithPOJO(driver, extentReport);
		//loginClinicUser_withoutICDDevice = new Login();
		loginClinicUser_withNonBluetooth_ICDDevice = new Login();
		//loginAdminUser = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void TC_11_0_WA_EP_Alert_Sub_Categories()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);

		//loginAdminUser = testDataProvider.getLoginData("SJMAdmin3");
		//loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("SJMClinic2");
		loginClinicUser_withNonBluetooth_ICDDevice = testDataProvider.getLoginData("SJMClinic3");
		
		extentTest.assignAuthor("Author: Shafiya Sunkesala");
		try {
			
			assertions = new Assertions(extentTest);
			
			extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings>Merlin@Home Transmitter tab.");
			
			loginPage.login(loginClinicUser_withNonBluetooth_ICDDevice);	
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			extentReport.reportScreenShot("Login with Clinician user is successful");
			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
			extentReport.reportScreenShot("Navigation to Clinic Administration Page is successful");
			
			clinicAdminLeftNavPage.clickDirectAlertsICD_CRTD_MerlinHomeLink();
			assertions.assertEqualsWithReporting(true, ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyLandingPage(), extentReport, "Merlin Home Transmitter page is displayed T");
			extentReport.reportScreenShot("Navigation to Clinic Admin -> ICD/CRTD -> Merlin@Home Transmitter Page is successful");
			
			//This code is added to reset alert classification of primary and subcategories under LeadAssurance™ Alert to "Red"
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("LeadAssurance™ Alert","Red");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("RV Pacing Lead Impedance Out of Range","Red");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("High Voltage Lead Impedance Out of Range","Red");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("Possible High Voltage Lead Issue","Red");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("*SecureSense™ Sustained RV lead noise detected","Red");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("*SecureSense™ Non-sustained RV oversensing detected","Red");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("V. Noise Reversion","Red");
			
			
			extentReport.info("200 V Verify alerts with designated sub-category (Lead Assurance Alert Group), the system shall display these sub-categorized alerts and their sub-category header label as a group within the alert set of the parent alert category. ", new String[] {"CommUI10482", "CommUI10528", "CommUI10529"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifySubCategories_AsGroup(), true, "Lead Assurance Alert Group and it's subcategories are displayed as group");
			
			
			extentReport.info("300 V Verify Primary alert category/Sub-category headers are displayed with the same indentation (alignment) level as alerts which do not have any sub-category."
					+ " For example:\r\n"
					+ "			Alert Category 1\r\n"
					+ "			        ⦁ Alert 1\r\n"
					+ "			        ⦁ Alert 2", new String[] {"CommUI10524"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlignment_SubCategories_NoParent(), true, "Sub Categories without Parent are aligned properly");

			extentReport.info("400 V Verify Alerts associated with a sub-category header is displayed with an indentation level one level deeper than the sub-category header. " 
					+ "Alert Category 1\r\n"
					+ "        ⦁ Alert 1\r\n"
					+ "        ⦁ Alert 2", new String[] {"CommUI10526"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlignment_SubCategories_HavingParent(), true, "Sub Categories with Parent are aligned One level deeper");
			
			extentReport.info("500 S Click on edit button select alert classification for sub category alerts (Alert Classification - Urgent, Standard, OFF)");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickEditButton();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			
			
			extentReport.info("600 V Verify Alert sub-categories under Direct Alert settings. alert classification (Urgent, standard, OFF) is editable and saved. ", new String[] {"CommUI10522"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("RV Pacing Lead Impedance Out of Range","Yellow"), "Yellow button is clicked", "Alert Type: RV Pacing Lead Impedance Out of Range, Standard Button is enabled and clickede ");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("RV Pacing Lead Impedance Out of Range", "Yellow"), true, "Alert Type: RV Pacing Lead Impedance Out of Range, Saved with Standard Alert Classification");						
			
			//ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickEditButton();
			
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("High Voltage Lead Impedance Out of Range", "OFF"), "OFF button is clicked", "Alert Type: High Voltage Lead Impedance Out of Range, OFF Button is enabled and clicked");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("High Voltage Lead Impedance Out of Range", "OFF"), true, "Alert Type: High Voltage Lead Impedance Out of Range, Saved with OFF Alert Classification");						
						
			//ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickEditButton();
			
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("RV Pacing Lead Impedance Out of Range","Red"), "Red button is clicked", "Alert Type: RV Pacing Lead Impedance Out of Range, Urgent Button is clicked");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("RV Pacing Lead Impedance Out of Range", "Red"), true, "Alert Type: RV Pacing Lead Impedance Out of Range, Saved with Urgent Alert Classification");			
			
			//ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickEditButton();
			
			extentReport.info("700 Check/uncheck patient notification control (i.e. Inform Patient) for selected Alert sub-category. <", new String[] {"CommUI10523"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.selectOrUnSelectInformPatient("V. Noise Reversion"), true, "Inform Patient is selected for Alert Type: V. Noise Reversion");
			
			extentReport.info("800 V Verify Inform Patient checkbox for alert sub-category is selectable & saved for alert ", new String[] {"CommUI10523"});
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickSave();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("V. Noise Reversion"), true, "Inform Patient checkbox is selected for Alert Type: V. Noise Reversion and saved");
			
			//ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickEditButton();
			
			extentReport.info("900 Change default Alert classification for Alert sub-category. < CommUI7586>");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("Possible High Voltage Lead Issue", "Yellow");
			
			extentReport.info("1000 V Verify the last selected values of alert classification is displayed when the sub-category has been collapsed by the user. < CommUI7586>");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryCollapseIcon();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryCollapseIcon();
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("Possible High Voltage Lead Issue", "Yellow"), true, "Alert Type: Possible High Voltage Lead Issue, Saved with Yellow Alert Classification after the sub category is collapsed by user");

			extentReport.info("1100 S Change the Alert Classification for primary alert. < CommUI7587>");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("LeadAssurance™ Alert", "Yellow");
			
			extentReport.info("1200 V Verify Alert Classification or patient notification is changed for all corresponding alert sub-category, if one Sub-Alert settings are changed. < CommUI7587>");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("RV Pacing Lead Impedance Out of Range", "Yellow"), true, "Alert Type: RV Pacing Lead Impedance Out of Range, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("High Voltage Lead Impedance Out of Range", "Yellow"), true, "Alert Type: High Voltage Lead Impedance Out of Range, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("Possible High Voltage Lead Issue", "Yellow"), true, "Alert Type: Possible High Voltage Lead Issue, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("*SecureSense™ Sustained RV lead noise detected", "Yellow"), true, "Alert Type: *SecureSense™ Sustained RV lead noise detected, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("*SecureSense™ Non-sustained RV oversensing detected", "Yellow"), true, "Alert Type: *SecureSense™ Non-sustained RV oversensing detected, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("V. Noise Reversion", "Yellow"), true, "Alert Type: V. Noise Reversion, Saved with Yellow Alert Classification which is same as primary Alert");
			//Need to check vinay regarding below code to add or not
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.selectOrUnSelectInformPatient("LeadAssurance™ Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("RV Pacing Lead Impedance Out of Range"), true, "Alert Type: RV Pacing Lead Impedance Out of Range, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("High Voltage Lead Impedance Out of Range"), true, "Alert Type: High Voltage Lead Impedance Out of Range, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("Possible High Voltage Lead Issue"), true, "Alert Type: Possible High Voltage Lead Issue, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("*SecureSense™ Sustained RV lead noise detected"), true, "Alert Type: *SecureSense™ Sustained RV lead noise detected, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("*SecureSense™ Non-sustained RV oversensing detected"), true, "Alert Type: *SecureSense™ Non-sustained RV oversensing detected, Saved with Yellow Alert Classification which is same as primary Alert");
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyInformPatient("V. Noise Reversion"), true, "Alert Type: V. Noise Reversion, Saved with Yellow Alert Classification which is same as primary Alert");
			
			extentReport.info("1300 S Select highest priority of patient notification value of sub category and observe alert priority of primary alert.", new String[] {"CommUI7587"});
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("RV Pacing Lead Impedance Out of Range", "Red");
			
			extentReport.info("1400 V Verify the selectable alert sub-category header notification priority shall maintain a priority value which is equal to that of its highest priority sub category-alert. ", new String[] {"CommUI7588"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyAlertClassification("LeadAssurance™ Alert", "Red"), true, "Alert Type: LeadAssurance™ Alert, Red Alert Classification is selected which is equal to that of its highest priority sub category-alert");
			
			extentReport.info("1500 S Select alert classification as OFF for all the sub-category except one alert and observe patient notification check box of primary alert. ", new String[] {"CommUI7590"});
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("High Voltage Lead Impedance Out of Range", "OFF");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("Possible High Voltage Lead Issue", "OFF");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("*SecureSense™ Sustained RV lead noise detected", "OFF");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("*SecureSense™ Non-sustained RV oversensing detected", "OFF");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("V. Noise Reversion", "OFF");
			
			extentReport.info("1600 V Verify patient notification checkbox is active for primary alert if one of the Alert classification in sub-category is set to ON. i.e. (Set to Urgent or Standard). ", new String[] {"CommUI7590"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.isPatientNotificationEnabled("LeadAssurance™ Alert"), true, "Primary Alert Type: LeadAssurance™ Alert, Patient Notification checkbox is enabled");
			
			extentReport.info("1700 S Select alert classification as OFF for all sub-category alert and observe patient notification check box of primary alert. ", new String[] {"CommUI7590"});
			//Added only this as previously all sub categories under primary group are selected to off
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.changeAlertClassification("RV Pacing Lead Impedance Out of Range", "OFF");
			
			extentReport.info("1800 V Verify patient notification checkbox is in-active when Alert classification is set to OFF. ", new String[] {"CommUI7590"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.isPatientNotificationEnabled("LeadAssurance™ Alert"), false, "Primary Alert Type: LeadAssurance™ Alert, Patient Notification checkbox is in-active or disbaled");
			
			extentReport.info("1900 S Click on (+) icon on the sub category header (Lead Assurance Alert Group)");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryCollapseIcon();
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryExpandIcon();
			
			extentReport.info("2000 V Verify alerts with the sub-category provides the capability to expand and collapse the alert list associated and displayed with the sub-category ", new String[] {"CommUI7585"});
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.isSubCategoriesExpanded(), true, "Primary Alert Type: LeadAssurance™ Alert, is expanded and sub categories are displayed");
			ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickParentCategoryCollapseIcon();
			assertions.assertEquals(ca_DirectAlert_ICD_CRTD_MerlinAtHomePage.isSubCategoriesExpanded(), false, "Primary Alert Type: LeadAssurance™ Alert, is collapsed and sub categories are not displayed");
			
			
			assertions.assertAll();
			
			
		} catch (AssertionError e) {
			extentReport.reportFail( "$_11_0_WA_EP_Alert_Sub_Categories is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "$_11_0_WA_EP_Alert_Sub_Categories is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;		
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}
}