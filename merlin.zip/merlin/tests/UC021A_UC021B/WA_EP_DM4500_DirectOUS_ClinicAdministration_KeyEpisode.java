package com.test.qa.ui.tests.UC021A_UC021B;

//Owner Jais
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.List;
import java.util.stream.Collectors;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_EP_DM4500_DirectOUS_ClinicAdministration_KeyEpisode extends CommonUtils {

	LoginPageWithPOJO loginPage;	
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage leftNavPage;
	CA_ClinicSettings_ReportSettingsPage reportSettings;
	ExtentTest extentTest;
	Login login;	
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;	
	private Log logger = new Log();
	
	@BeforeClass
	public void initialize() {
		
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		reportSettings = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		leftNavPage = new  CA_LeftNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();		
		dataBaseConnector = new DataBaseConnector();
	}
	@Test
	public void directOUS_ClinicAdministration_KeyEpisode() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		extentTest.assignAuthor("Author - Jaison TP");
		try 
		{		
		
			//load all the clinic users where in we need to verify 
			List<Login> clinicUsers = testDataProvider.getClinicUserData("WA_EP_1336718");
			
			
			//Select the login details as per the scenario
			
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario1User")).collect(Collectors.toList()).get(0);			
			
			extentReport.info("Scenario 1: User 1 - Clinic with only ICM4500 device");		
			assertion =  new Assertions(extentTest);	
			
			extentReport.info("100S Login to EP Clinic A with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login);	
			extentReport.info("Login with User Type - " + login.getUserType());
			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			CA_LeftNavPage leftNavPage = new  CA_LeftNavPage(driver, extentReport);
			leftNavPage.clickReportSettingsLink();
			CA_ClinicSettings_ReportSettingsPage reportSettings = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
			reportSettings.verifyLandingPage();	
			
			extentReport.info("200V Verify default setting i.e. ON is selected for Identify Key Episodes <ClncMgt33508>");
			String episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is Selected");
			
			extentReport.info("300S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("400V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"UnChecked","Identify Key Episodes check box is not Selected");	
			
			extentReport.info("500V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage <ClncMgt33508>");
				/* Need to uncomment once merlin.net  access granted
				dataBaseConnector.getConnection();			
				String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
						+ "where logon_user_name ='"+login.getUserName()+"'";
				
				ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
				keyEpisodeSettings.next();
				String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
				*/
			extentReport.info("600S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. . Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("700V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference < ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is  Selected");	
			
			extentReport.info("800V Verify in the database whether Identify Key Episodes value is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("****************************Logging off user - "+ login.getUserName());
			extentReport.info("****************************Scenario 1: Completed");
			clinicianHomeTopNavPage.clickSignOutLink();
			
			//reset the reused values			
			episodeChkBoxStatus = "";
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario2User")).collect(Collectors.toList()).get(0);
				
			extentReport.info("Scenario 2: Clinic with ICM4500 device and ICM3500 device");
				
			
			extentReport.info("900S Login to EP Clinic B with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("1000V Verify default setting i.e. ON is selected for Identify Key Episodes <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is Selected");
			
			extentReport.info("1100S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("z1200V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"UnChecked","Identify Key Episodes check box is not Selected");	
			
			extentReport.info("1300V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
				*/
			extentReport.info("1400S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("1500V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference < ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is  Selected");	
			
			extentReport.info("1600V Verify in the database whether Identify Key Episodes value is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("****************************Logging off user - "+ login.getUserName());
			extentReport.info("****************************Scenario 2: Completed");
			clinicianHomeTopNavPage.clickSignOutLink();	
				
			episodeChkBoxStatus = "";
			extentReport.info("Scenario 3: Clinic with all devices including ICM4500");
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario3User")).collect(Collectors.toList()).get(0);
			
			extentReport.info("1700S Login to EP Clinic C with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("1800V Verify default setting i.e. ON is selected for Identify Key Episodes <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is Selected");
			
			extentReport.info("1900S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("2000V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"UnChecked","Identify Key Episodes check box is not Selected");	
			
			extentReport.info("2100V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("2200S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("2300V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference < ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is  Selected");	
			
			extentReport.info("2400V Verify in the database whether Identify Key Episodes value is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("*******************Logging off user - "+ login.getUserName());
			extentReport.info("*******************Scenario 3: Completed");
			clinicianHomeTopNavPage.clickSignOutLink();	
				
			episodeChkBoxStatus = "";
			
			extentReport.info("Scenario 4: Clinic with all devices except ICM3500");
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario4User")).collect(Collectors.toList()).get(0);
			
			extentReport.info("2500S Login to EP Clinic D with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("2600V Verify default setting i.e. ON is selected for Identify Key Episodes <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is Selected");
			
			extentReport.info("2700S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("2800V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"UnChecked","Identify Key Episodes check box is not Selected");	
			
			extentReport.info("2900V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("3000S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("3100V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference < ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is  Selected");	
			
			extentReport.info("3200V Verify in the database whether Identify Key Episodes value is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("*********************Logging off user - "+ login.getUserName());
			extentReport.info("*********************Scenario 4: Completed");
			clinicianHomeTopNavPage.clickSignOutLink();	
				
			episodeChkBoxStatus = "";
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario5User")).collect(Collectors.toList()).get(0);		
			
			extentReport.info("Scenario 5: Clinic with only ICM4500 and NGQ devices");			
			extentReport.info("3300S Login to EP Clinic E with Allied Professional User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("3400V Verify default setting i.e. ON is selected for Identify Key Episodes <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is Selected");
			
			extentReport.info("3500S Select Edit button and followed by unchecking the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("3600V Verify that the changes are saved that means user is able to unselect Identify Key Episodes Preference <ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"UnChecked","Identify Key Episodes check box is not Selected");	
			
			extentReport.info("3700V Verify in the database whether Identify Key Episodes flag is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("3800S Click on Edit and select the Identify Key Episodes Checkbox under Other Features section. Select Save-> Ok button-> Ok button on the pop up displayed.");
			reportSettings.clickEditButton();
			reportSettings.clickIdentifyKeyEpisodeChkBox();
			reportSettings.saveReportSettings();			
			reportSettings.acceptAlert();
			
			extentReport.info("3900V Verify that the changes are saved that means that the user is able to unselect Identify Key Episodes Preference < ClncMgt33508>");
			episodeChkBoxStatus  = reportSettings.verifyidentkeyepisodesCheckbox();
			assertion.assertEquals(episodeChkBoxStatus,"Checked","Identify Key Episodes check box is  Selected");	
			
			extentReport.info("4000V Verify in the database whether Identify Key Episodes value is as per selection on Webpage <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("********************Logging off user - "+ login.getUserName());
			extentReport.info("********************Scenario 5: Completed");
			
			
			
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario6User")).collect(Collectors.toList()).get(0);				
			
			extentReport.info("Scenario 6: Clinic with all devices except ICM4500");			
			extentReport.info("4100S Logout and Login to EP Clinic F with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			clinicianHomeTopNavPage.clickSignOutLink();	
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("4200V Verify Identify Key Episodes Checkbox is not displayed <ClncMgt33508>");			
			assertion.assertEquals(reportSettings.isIdentifyKeyEpisodesPresent(),false,"Identify Key Episodes check box is not present");
			
			extentReport.info("4300V Verify in the database Key Episodes data for this clinic is not available <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("****************Logging off user - "+ login.getUserName());
			extentReport.info("*****************Scenario 6: Completed");
			
			episodeChkBoxStatus = "";
			
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario7User")).collect(Collectors.toList()).get(0);				
			
			extentReport.info("Scenario 7: Clinic with only ICM3500 device");			
			extentReport.info("4400S Logout and Login to EP Clinic G with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			clinicianHomeTopNavPage.clickSignOutLink();
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("4500V Verify Identify Key Episodes Checkbox is not displayed <ClncMgt33508>");			
			assertion.assertEquals(reportSettings.isIdentifyKeyEpisodesPresent(),false,"Identify Key Episodes check box is not present");
			
			extentReport.info("4600V Verify in the database Key Episodes data for this clinic is not available <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("*****************Logging off user - "+ login.getUserName());
			extentReport.info("*****************Scenario 7: Completed");	
			
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario8User")).collect(Collectors.toList()).get(0);			
		
			extentReport.info("Scenario 8: Clinic with ICD + Pacemaker+ NGQ device");			
			extentReport.info("4700S Logout and Login to EP Clinic H with Allied Professional and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			clinicianHomeTopNavPage.clickSignOutLink();	
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();			
			leftNavPage.clickReportSettingsLink();			
			reportSettings.verifyLandingPage();	
			
			extentReport.info("4800V Verify Identify Key Episodes Checkbox is not displayed <ClncMgt33508>");			
			assertion.assertEquals(reportSettings.isIdentifyKeyEpisodesPresent(),false,"Identify Key Episodes check box is not present");
			
			extentReport.info("4900V Verify in the database Key Episodes data for this clinic is not available <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("Logging off user - "+ login.getUserName());
			extentReport.info("Scenario 8: Completed");				
				
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario9User")).collect(Collectors.toList()).get(0);		
			
			extentReport.info("Scenario 9: Clinic with only NGQ device");			
			extentReport.info("5000S Logout and Login to EP Clinic I with Physician User and navigate to Clinic Administration page -> Report Settings tab from the left Pane under Clinic Settings");
			
			clinicianHomeTopNavPage.clickSignOutLink();	
			loginPage.login(login);			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();				
			leftNavPage.clickReportSettingsLink();				
			reportSettings.verifyLandingPage();	
			
			extentReport.info("5100V Verify Identify Key Episodes Checkbox is not displayed <ClncMgt33508>");
			assertion.assertEquals(reportSettings.isIdentifyKeyEpisodesPresent(),false,"Identify Key Episodes check box is not present");
			
			extentReport.info("5200V Verify in the database Key Episodes data for this clinic is not available <ClncMgt33508>");
			/* Need to uncomment once merlin.net  access granted
			dataBaseConnector.getConnection();			
			String query = "select Identify_Key_Episode_Flg from Customer_application with(nolock) "
					+ "where logon_user_name ='"+login.getUserName()+"'";
			
			ResultSet keyEpisodeSettings = dataBaseConnector.executeQuery(query);
			keyEpisodeSettings.next();
			String keyEpisodeDBValue  = keyEpisodeSettings.getString("Identify_Key_Episode_Flg");
			*/
			extentReport.info("*****************Logging off user - "+ login.getUserName());
			extentReport.info("*****************Scenario 9: Completed");
			
				
			
			login =  clinicUsers.stream().filter(login -> login.getUserType().equals("Scenario10User")).collect(Collectors.toList()).get(0);		
			
			extentReport.info("Scenario 10: Clinic with ICM4500 device but Assistant User");			
			extentReport.info("5300S Logout and Login to EP Clinic A with Assistant User");
			clinicianHomeTopNavPage.clickSignOutLink();	
			loginPage.login(login);
			
			extentReport.info("5400V Verify that the user is not able to set/unset Identify Key Episodes as Clinic Administration page is not displayed < ClncMgt33508>");
			
			assertion.assertEquals(clinicianHomeTopNavPage.isClinicAdministrationMenuPresent(),false,"Clinic Administration menu not displayed");
			extentReport.info("*****************Logging off user - "+ login.getUserName());
			extentReport.info("*****************Scenario 10: Completed");
			
			
			extentReport.info("Scenario 11(9): Clinic with ICM4500 device but Allied Professional User without Administration rights");
			
			extentReport.info("5500S Logout and Login to EP Clinic A with Allied Professional User without Administration rights");
			clinicianHomeTopNavPage.clickSignOutLink();	
			loginPage.login(login);
			
			extentReport.info("5600V Verify that the user is not able to set/unset Identify Key Episodes as Clinic Administration page is not displayed < ClncMgt33508>");
			assertion.assertEquals(clinicianHomeTopNavPage.isClinicAdministrationMenuPresent(),false,"Clinic Administration menu not displayed");
			clinicianHomeTopNavPage.clickSignOutLink();	
			extentReport.info("**********************Scenario 11(9): Completed");
		
		} catch (AssertionError e) {
			extentReport.fail( "directOUS_ClinicAdministration_KeyEpisode is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "directOUS_ClinicAdministration_KeyEpisode is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
		//extentReport.info("end");
	}

	

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
