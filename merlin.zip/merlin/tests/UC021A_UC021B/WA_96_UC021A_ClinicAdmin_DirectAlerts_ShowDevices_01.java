package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_96_UC021A_ClinicAdmin_DirectAlerts_ShowDevices_01 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Login loginClinicUser_withoutICDDevice;
	TestDataProvider testDataProvider;
	//private String testName;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage cA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
	CA_ClinicAdminMobAppTransPage ClinicAdminMobAppTransPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	private Log logger = new Log();
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;
	CA_DirectAlert_CardiacMonitorPage cardiacMonitor;
	Customer customer, changingCustomer;
	String testName,customerName,fieldValue,merlinAtHomeDevice,cardiacMonitorDevice,pacemakerDevice;
	CustomerProfilePage customerProfilePage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	
	@BeforeClass
	public void initialize() {
		
		//driver = CommonUtils.initializeDriver();
	//	extentReport = new ExtentReport(driver, null);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withoutICDDevice = new Login();
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		cA_DirectAlert_ICD_CRTD_MerlinAtHomePage= new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		ClinicAdminMobAppTransPage = new CA_ClinicAdminMobAppTransPage(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		cardiacMonitor = new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		
		merlinAtHomeDevice = "Atlas® /DR /V-240";
		cardiacMonitorDevice = "Confirm Rx ICM, DM3500";
		pacemakerDevice = "Accent® DR RF, 2210";
	}
	
	@Test	
	public void ClinicAdmin_DirectAlerts_ShowDevices_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;	
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);				
		extentTest.assignAuthor("Snehal Mane");		

		try {
			Assertions assertion =  new Assertions(extentTest);
			login = testDataProvider.getLoginData("SJMClinic7");
			customer = testDataProvider.getCustomerData("WA_96_UC021A_ClinicAdmin_DirectAlerts_ShowDevices_01");
			changingCustomer = customer;
			
			extentTest =  extentReport.info("100 S Login with Regular clinic \"Clc_A\" and move to EP Application. Click on Clinic Administration page.");	
			
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");

			extentReport.info("200 V Verify that on left side navigation \"DirectAlerts™ settings\" heading display and Under this heading \"ICD/CRT-D\", \"Pacemaker/CRT-P\" and \"Cardiac Monitor\" links are present.");
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			//assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertsICD_CRTDLink(), extentReport, "ICD/CRT-D link is present under Direct Alerts Settings header");
			//assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifypacemaker_CRTPLink(), extentReport, "Pacemaker/CRT-P link  is present under Direct Alerts Settings header");
			//assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyCardiacMonitorLink(), extentReport, "Cardiac Monitor link is present under Direct Alerts Settings header");
			clinicAdminLeftNavPage.verifyDirectAlertsICD_CRTDLink();
			clinicAdminLeftNavPage.verifypacemaker_CRTPLink();
			clinicAdminLeftNavPage.verifyCardiacMonitorLink();
			
			
			//Merlin@home
			extentReport.info("300 S Actor click on \"ICD/CRT-D\"(  Merlin@home Transmitter) link.");
			clinicAdminLeftNavPage.clickDirectAlertsICD_CRTD_MerlinHomeLink();
			
			extentReport.info("400 V Verify that \"DirectAlerts™ Settings for ICD/CRT-D devices\"  page is displayed with \"Show Devices\" link.", new String[] {"ClncMgt32030", "ClncMgt30400"});
			assertion.assertEqualsWithReporting(true, cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyLandingPage(), extentReport, "Merlin@home Transmitter page is displayed");
			assertion.assertEqualsWithReporting(true, cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.verifyShowDevicesLink(), extentReport, "Show Devices link is present on ICD/CRT-D Merlin@Home Transmitter page");
			
			extentReport.info("500 S Actor click on Show Devices link.");
			cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.clickShowDevicesLink();
			
			//Blocker
			extentReport.info("600 V Verify that selected \"ICD/CRT-D\" device from SJM admin is displayed under the \"Show Devices\" list.", new String[] {"ClncMgt30400"});
			assertion.assertEqualsWithReporting(true, cA_DirectAlert_ICD_CRTD_MerlinAtHomePage.validateDeviceInShowDeviceDialogBox(merlinAtHomeDevice), extentReport, merlinAtHomeDevice+" device is displayed under show devices list");
			
			//Pacemaker
			extentReport.info("700 S Actor click on \"Pacemaker/CRT-P\" link.");
			clinicAdminLeftNavPage.clickpacemaker_CRTPLink();
			
			extentReport.info("800 V Verify that \"DirectAlerts™ Settings for Pacemaker/CRT-P devices\" page is displayed with \"Show Devices\" link.", new String[] {"ClncMgt32030", "ClncMgt30400"});
			assertion.assertEqualsWithReporting(true, pacemaker.verifyLandingPage(), extentReport, "Pacemaker/CRT-P  page is displayed");		
			pacemaker.verifyShowDevicesLink();
			
			extentReport.info("900 S Actor click on Show Devices link");
			pacemaker.clickShowDevicesLink();
			
			//Blocker
			extentReport.info("1000 V Verify that selected \"Pacemaker/CRT-P\" device from SJM admin is displayed under the \"Show Devices\" list.", new String[] {"ClncMgt30400"});
			assertion.assertEqualsWithReporting(true, pacemaker.validateDeviceInShowDeviceDialogBox(pacemakerDevice), extentReport, pacemakerDevice+" device is displayed under show devices list");
			
			
			//Cardiac Monitor
			extentReport.info("1100 S Actor click on \"Cardiac Monitor\" link");
			clinicAdminLeftNavPage.clickCardiacMonitorLink();
			
			extentReport.info("1200 V Verify that \"DirectAlerts™ Settings for Cardiac Monitor\" page is displayed with \"Show Devices\" link");
			assertion.assertEqualsWithReporting(true, cardiacMonitor.verifyLandingPage(), extentReport, "Cardiac Monitor page is displayed");
		//	assertion.assertEqualsWithReporting(true, pacemaker.verifyShowDevicesLink(), extentReport, "Show Devices link is present on ICD/CRT-D Merlin@Home Transmitter page");
			cardiacMonitor.verifyShowDevicesLink();
			
			extentReport.info("1300 S Actor click on Show Devices link.");
			cardiacMonitor.clickShowDevicesLink();
			
			//Blocker
			extentReport.info("1400 V Verify that selected \"Cardiac Monitor\" device from SJM admin is displayed under the \"Show Devices\" list.", new String[] {"ClncMgt30400"});
			assertion.assertEqualsWithReporting(true, cardiacMonitor.validateDeviceInShowDeviceDialogBox(cardiacMonitorDevice), extentReport, cardiacMonitorDevice+" device is displayed under show devices list");
			
			
			extentReport.info("1500 S Actor Logout the current clinic and re-login to SJM admin through I4_pcsadmin and search the clinic \"Clc_A\" from customer list and move to its edit Customer page.");
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("SJMAdmin");
			customer = testDataProvider.getCustomerData("WA_96_UC021A_ClinicAdmin_DirectAlerts_ShowDevices_01");
			changingCustomer = customer;
			loginPage.login(login);
			
			customerName=customerListPage.searchCustomer(customer.getCustomerName());
			customerListPage.clickCustomer(customerName);
			customerProfilePage.clickChangeButton();
			
			extentReport.info("1600 S Actor remove  the ICM device  from Allowed Device list using Remove button on Edit Customer page and click on Save button.");			
			List<String> list = new ArrayList<String>();
	        list.add(cardiacMonitorDevice);
	        
			changeCustomerProfilePage.removeDevicesFromAllowedListAndSave(list);
			

			extentReport.info("1700 S Actor Logout the current clinic and re-login to clinic \"Clc_A\" and move to EP Application. Click on Clinic Administration page.");
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("SJMClinic7");
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			extentReport.info("1800 V Verify that on \"Cardiac Monitor\" link is not displayed under the \"DirectAlerts™ settings\" heading on Clinic Administration page (negative test).", new String[] {"ClncMgt32030"});
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyCardiacMonitorLinkNotPresent(),extentReport,"'Cardiac Monitor' link is not displayed under the 'DirectAlerts™ settings' heading on Clinic Administration page");
			
			
			//Pre-requisite data steps for TC
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("SJMAdmin");
			loginPage.login(login);
			
			customerName=customerListPage.searchCustomer(customer.getCustomerName());
			customerListPage.clickCustomer(customerName);
			customerProfilePage.clickChangeButton();
			
			changeCustomerProfilePage.addDevicesToAllowedListAndSave(list);
			

		}
		catch (AssertionError e) {
			
			extentTest = extentReport.fail("WA_96_UC021A_ClinicAdmin_DirectAlerts_ShowDevices_01 to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			extentTest.fail("ClinicAdmin_DirectAlerts_ShowDevices_01 due to assertion failure"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("WA_96_UC021A_ClinicAdmin_DirectAlerts_ShowDevices_01 due to some exception");
			extentTest.fail("ClinicAdmin_DirectAlerts_ShowDevices_01 due to some exception"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}				
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {

		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}



