package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;

public class WA_11_EP_ClinicAdmin_DirectAlerts_Bluetooth_NonBluetooth_ICD_Pacemaker extends CommonUtils {
	LoginPageWithPOJO loginPage;
	
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
    CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
    ClinicianHomeTopNavPage clinicianHomeTopNavPage;
    CommonUtils commonUtils;
    CA_LeftNavPage clinicAdminLeftNavPage;
    AppHomeTopNavPage appHomeTopNavPage;
    CustomerListPage customerListPage;
    CA_ClinicAdminMobAppTransPage clinicAdminMobAppTransPage;
   
    
	@BeforeClass
	public void initialize() {
		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicAdminLeftNavPage=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		clinicAdminMobAppTransPage=new CA_ClinicAdminMobAppTransPage(driver, extentReport);
		
	}
	//extentReport.reportScreenShot("Deleted the data entered in Email address field")-will do later
	@Test
	public void ClinicAdmin_DirectAlerts_Bluetooth_NonBluetooth_ICD_Pacemaker() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("DirectAll");
		extentTest.assignAuthor("Abhishek-kumar");

		try {
			Assertions assertion =  new Assertions(extentTest);

			extentTest =  extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");	
			loginPage.login(login);
			Boolean loginCheck = customerListPage.verifyLandingPage();
			//Assert.assertTrue(loginCheck);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			//assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			


			extentTest=extentReport.info("200 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and to navigate Direct Alerts Settings for Non-Bluetooth ICD/ CRT-D devices page.",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
		    clinicAdminLeftNavPage.navigateToMerlinAtHomeTransmitterPage();
			assertion.assertEqualsWithReporting(true,  clinicAdminLeftNavPage.verifyMerlinHomeTransmitterTab(), extentReport, "Merlin@home Transmitter tab is present");
			extentReport.reportScreenShot("Direct Alerts Settings,Merlin@home Transmitter is displayed");
			

			
			extentReport.info("300 V Verify a list of alert groups"
					+ " is displayed for which the clinic is authorized"
					+ " for Non-Bluetooth ICD/ CRT-D devices and "
					+ "respective Clinic's Jurisdiction "
					+ "(Ref. the Non-BLE Device Alerts tab in Alerts.xlsx sheet).",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true,directAlert_MerlinAtHomePage.validateMerlinHomeAlertValueInTable(),extentReport,"Merlin@Home Transmitter Alert group is displayed correctly");
            
			//Step is repetitive so need to be removed after checking with Rajesh
			extentReport.info("400 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			

			extentTest=extentReport.info( "500 V Verify that under Direct Alerts Settings, Mobile App Transmitter tab is available and to navigate Direct Alerts Settings for Bluetooth ICD/ CRT-D devices page.",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyMobileAppTransmitterTab(), extentReport, "MobileAppTransmitter tab is present");
			clinicAdminLeftNavPage.clickMobileAppTransmitterLink();
			extentReport.reportScreenShot("Direct Alerts Settings and MobileAppTransmitter is displayed");
			
			
			extentTest=extentReport.info("600 V Verify a list of alert groups is"
					+ " displayed for which the clinic is authorized for Bluetooth"
					+ " ICD/ CRT-D devices and respective Clinic's Jurisdiction "
					+ "(Ref. the NGQ Alerts tab in Alerts.xlsx sheet).", new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true,clinicAdminMobAppTransPage.validateMobileAppAlertValueInTable(),extentReport,"Mobile App alerts is reflecting correctly");

            
			
			extentTest=extentReport.info("700 S Login with Test setup 1 "
					+ "and navigate to Clinic Administration tab >Direct Alerts Settings.");
			
			
			
			extentTest=extentReport.info( "800 V Verify that under Direct Alerts Settings, Pacemakers/CRT-P devices tab is available and navigate to Direct Alerts� Settings for Pacemaker/ CRT-P devices page.",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifypacemaker_CRTPTab(), extentReport, "Pacemakers/CRT-P devices tab is present");
			clinicAdminLeftNavPage.navigatePacemaker_CRTPLink();
			assertion.assertEqualsWithReporting(true,pacemaker.verifyLandingPage(),extentReport,"Pacemaker landing page is displayed");//this need to be ask
			
			
			extentTest=extentReport.info("900 V Verify a list of alert groups"
					+ " is displayed for which the clinic is authorized for"
					+ " Pacemakers/CRT-P devices and respective Clinic's Jurisdiction"
					+ " (Ref. the Non-BLE Device Alerts tab Alerts.xlsx sheet).",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true,pacemaker.validatePacemakerAlertValueInTable(),extentReport,"pacemaker alert is correctly reflected in page");

		    
			
			//Test Setup 2
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("SJMClinic2");
			extentTest=extentReport.info("1000 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login);
			loginCheck = customerListPage.verifyLandingPage();
			Assert.assertTrue(loginCheck);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			
			

			extentTest=extentReport.info("1100 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and to navigate Direct Alerts Settings for Non-Bluetooth ICD/ CRT-D devices page.",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true,  clinicAdminLeftNavPage.verifyMerlinHomeTransmitterTab(), extentReport, "Merlin@home Transmitter tab is present");
			extentReport.reportScreenShot("Direct Alerts Settings,Merlin@home Transmitter is displayed");
			clinicAdminLeftNavPage.navigateToMerlinAtHomeTransmitterPage();
			assertion.assertEqualsWithReporting(true,  clinicAdminLeftNavPage.verifyMerlinHomeTransmitterTab(), extentReport, "Merlin@home Transmitter tab is present");
			extentReport.reportScreenShot("Merlin@home Transmitter Page is displayed");
			
			extentTest=extentReport.info("1200 V Verify a list of alert groups is displayed for which the clinic is authorized for Non-Bluetooth ICD/ CRT-D devices and respective Clinic's Jurisdiction (Ref. the Non-BLE Device Alerts tab in Alerts.xlsx sheet).",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true,directAlert_MerlinAtHomePage.validateMerlinHomeAlertValueInTable(),extentReport,"Merlin@Home Transmitter Alert group is displayed correctly");
			

			extentTest=extentReport.info("1400 V Verify that under Direct Alerts Settings, Mobile App Transmitter tab is available and to navigate Direct Alerts Settings for Bluetooth ICD/ CRT-D devices page.",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyMobileAppTransmitterTab(), extentReport, "MobileAppTransmitter tab is present");
			clinicAdminLeftNavPage.clickMobileAppTransmitterLink();
			extentReport.reportScreenShot("Direct Alerts Settings and MobileAppTransmitter is displayed");
			
			
			
			extentTest=extentReport.info("1500 V Verify a list of alert groups is "
					+ "displayed for which the clinic is authorized for Bluetooth "
					+ "ICD/ CRT-D devices and respective Clinic's Jurisdiction "
					+ "(Ref. the NGQ Alerts tab in Alerts.xlsx sheet).",new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true,clinicAdminMobAppTransPage.validateMobileAppAlertValueInTable(),extentReport,"Mobile App alerts is reflecting correctly");

			
			
			extentTest=extentReport.info("1600 S Login with Test setup 2 and navigate to Clinic Administration tab >Direct Alerts Settings.");
			
			
			
			extentTest=extentReport.info( "1700 V Verify that under Direct Alerts Settings, Pacemakers/CRT-P devices tab is available and navigate to Direct Alerts Settings for Pacemaker/ CRT-P devices page.",new String[] {"ClncMgt33106"});
            assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifypacemaker_CRTPTab(), extentReport, "Pacemakers/CRT-P devices tab is present");
			clinicAdminLeftNavPage.navigatePacemaker_CRTPLink();
			assertion.assertEqualsWithReporting(true,pacemaker.verifyLandingPage(),extentReport,"Pacemaker landing page is displayed");//this need to be ask
			
			extentTest=extentReport.info("1800 V Verify a list of alert groups is displayed for which the clinic is authorized for Pacemakers/CRT-P devices and respective Clinic's Jurisdiction (Ref. the Non-BLE Device Alerts tab in Alerts.xlsx sheet).", new String[] {"ClncMgt33106"});
			assertion.assertEqualsWithReporting(true,pacemaker.validatePacemakerAlertValueInTable(),extentReport,"pacemaker alert is correctly reflected in page");
			
			
		} 
		catch (AssertionError e) {

			
			extentTest = extentReport.fail("WA_UC021A_UC021B_ClinicAdmin_DirectAlerts_Bluetooth_NonBluetooth_ICD_Pacemaker to assertion failure");
			extentTest.fail("WA_UC021A_UC021B_ClinicAdmin_DirectAlerts_Bluetooth_NonBluetooth_ICD_Pacemaker to assertion failure"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("WA_UC021A_UC021B_ClinicAdmin_DirectAlerts_Bluetooth_NonBluetooth_ICD_Pacemaker due to some exception");
			extentTest.fail("WA_UC021A_UC021B_ClinicAdmin_DirectAlerts_Bluetooth_NonBluetooth_ICD_Pacemaker due to some exception"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}

	



	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {

		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}