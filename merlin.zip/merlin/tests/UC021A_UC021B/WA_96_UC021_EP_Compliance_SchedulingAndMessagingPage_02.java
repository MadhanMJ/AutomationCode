package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_Transmitter;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vinay Babu, Shafiya Sunkesala
 * Test Case Name: WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_02
 * Test case Id:1244379
 */

public class WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_02 extends CommonUtils {

	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
    ClinicianHomeTopNavPage clinicianHomeTopNavPage;
    PatientListPage patientListPage;
    PL_PatientProfilePage patientList_patientProfilePage;
    CA_LeftNavPage clinicAdminLeftNavPage;
    PL_PatientProfile_LeftNavPage pl_PatientProfile_LeftNavPage;
    PL_PatientProfile_Transmitter pl_PatientProfile_Transmitter;
    CA_SchedulingAndMessagingPage ca_SchedulingAndMessagingPage;
    LoginPageWithPOJO loginPage;
    Login loginClinicUser_withICDDevice;
    ExtentTest extentTest;
    private String testName;
    TestDataProvider testDataProvider;


	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);		
		ca_SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);		      
        patientListPage = new PatientListPage(driver,extentReport);
        patientList_patientProfilePage= new PL_PatientProfilePage(driver,extentReport);
        pl_PatientProfile_LeftNavPage = new PL_PatientProfile_LeftNavPage(driver,extentReport);
        pl_PatientProfile_Transmitter = new PL_PatientProfile_Transmitter(driver,extentReport);
        loginPage = new LoginPageWithPOJO(driver, extentReport);
        loginClinicUser_withICDDevice = new Login();
        testDataProvider = new TestDataProvider();
	}

	@Test
	public void TC_WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_02() throws Exception{

		testName = CommonUtils.getTestName();
        CommonUtils.currentTestCaseName = testName;
        extentTest = extentReport.initiateTest(testName);
        loginClinicUser_withICDDevice = testDataProvider.getLoginData("ICD_BatteryAdvisory_User");
        extentTest.assignAuthor("Author - Shafiya Sunkesala");

		try {
			
			assertions = new Assertions(extentTest);
						
			extentReport.info("100 S Login with Clinic\"EP_Clinic\"and Click on clinic administration tab.");			
			loginPage.login(loginClinicUser_withICDDevice);		
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			extentReport.reportScreenShot("Login with Clinician user is successful");
			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
			extentReport.reportScreenShot("Navigation to Clinic Administration Page is successful");
			
			extentReport.info("200 S Select scheduling and messaging tab the page is displayed in view mode.");			
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "Scheduling & Messaging page is displayed.");
			assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.checkPageInViewMode(), extentReport, "Scheduling and Messaging Page is in view mode");
        
            extentReport.info("300 V Verify In the ICD threshold section "
                       + "\"Patient transmitter Status\"check box it is displayed as checked and the default value is displayed as “8”.", new String[] {"ClncMgt32072"});        
            assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyCheckBox("Merlin Home patient transmitter status"), true, "Merlin Home Patient trasmitter status checkbox is checked by default");      
            assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days","Merlin Home patient transmitter status", "View Mode"), true, "Merlin Home Patient trasmitter status no of days default value is 8");
            
            extentReport.info("400 S Click on Edit button");
            ca_SchedulingAndMessagingPage.clickEditButton();                                                          
           
           extentReport.info("500 S Click on “Patient transmitter Status” Dropdown box");
           ca_SchedulingAndMessagingPage.clickPatientTransmitter_DeviceCheck_DropdownBox("Merlin Home patient transmitter status");        

           extentReport.info("600 V Verify dropdown box shows default value as 8 with the dropdown values 7,8,9,10,11,12,13,14,15 with days as units.", new String[] {"ClncMgt32072"});
           assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days", "Merlin Home patient transmitter status","Edit Mode"), true, "Patient trasmitter status no of days default value is 8");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyPatientTransmitter_DeviceCheck_DropdownValues("Merlin Home patient transmitter status"), true, "Patient Transmitter Status Dropdown values 7,8,9,10,11,12,13,14,15 with days as units is displayed");
		   
		   extentReport.info("700 S Try to enter or copy paste threshold value other than the allowed one and click on save.");	
		   extentReport.info("800 V Verify that Application not allows entering values other than one which are available in dropdown.<Negative>", new String[] {"ClncMgt32072"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifySelectBox("Merlin Home patient transmitter status"), true, "Patient transmitter status dropdown does not allow any value other than existing dropdown values"); 
		  
		   extentReport.info("900 S Select the value other than the default one and click on save button.");
		   ca_SchedulingAndMessagingPage.selectValueFromDropdown("Merlin Home patient transmitter status");
		   ca_SchedulingAndMessagingPage.saveAndAcceptAlert();

		   extentReport.info("1000 V Verify the “patient transmitter Status \" check box is displayed as checked with the set value. ", new String[] {"ClncMgt32072"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyCheckBox("Merlin Home patient transmitter status"), true, "Patient transmitter status checkbox is displayed as checked");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("10 days","Merlin Home patient transmitter status", "View Mode"), true, "Patient transmitter status no of days value is saved with 10");		   
		   
           extentReport.info("1100 S Click on edit button and uncheck the \"patient transmitter Status\" check box.");
           ca_SchedulingAndMessagingPage.clickEditButton();
           ca_SchedulingAndMessagingPage.clickCheckBox("Merlin Home patient transmitter status");
           extentReport.reportScreenShot("Merlin Home Patient Transmitter Satus check box is Unchecked");

           extentReport.info("1200 V Verify that the dropdown box is not displayed. ", new String[] {"ClncMgt32073"});
           assertions.assertEquals(ca_SchedulingAndMessagingPage.isDisplayedDropdownBox("Merlin Home patient transmitter status"),false,"Patient trasmitter status dropdown is not displayed");         
           ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
            
           extentReport.info("1210 S Click on edit button. Check \"patient transmitter Status\" and \" Device check \"check boxes and Save it");
           ca_SchedulingAndMessagingPage.clickEditButton();
           ca_SchedulingAndMessagingPage.clickCheckBox("Merlin Home patient transmitter status");
           extentReport.reportScreenShot("Merlin Home Patient Transmitter Satus checkbox is checked");
           
           ca_SchedulingAndMessagingPage.clickCheckBox("Merlin Home Device Check");
           extentReport.reportScreenShot("Merlin Home Device check checkbox is checked");
           
           ca_SchedulingAndMessagingPage.saveAndAcceptAlert();

           extentReport.info("1300 V Verify In the ICD threshold section \" Device check \" check box it is displayed as checked and the default value is displayed as “8”.", new String[] {"ClncMgt32073"});
           assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyCheckBox("Merlin Home Device Check"), true, "Merlin Home Device Check status checkbox is displayed as checked");
           assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days", "Merlin Home Device Check", "View Mode"), true, "Merlin Home - Device check status default value is 8");

           extentReport.info("1400 S Click on Edit button");
           ca_SchedulingAndMessagingPage.clickEditButton();

           extentReport.info("1500 S Click on “Device check” Dropdown box");
           assertions.assertEquals(ca_SchedulingAndMessagingPage.clickPatientTransmitter_DeviceCheck_DropdownBox("Merlin Home Device Check"), true, "Merlin@home transmitters section-Device Check status drop down box is clicked");

           extentReport.info("1600 V Verify dropdown box shows default value as 8 with the dropdown values as 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 values with days as units.", new String[] {"ClncMgt32073"});
           assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days", "Merlin Home Device Check","Edit Mode"), true, "Merlin Home - Device check status default value is 8");
           assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyPatientTransmitter_DeviceCheck_DropdownValues("Merlin Home Device Check"), true, "Merlin Home - Device Check Dropdown values 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 with days as units is displayed");          
           
           extentReport.info("1700 S Try to enter or copy paste threshold value other than the allowed one and click on save.");	
 		   extentReport.info("1800 V Verify that Application not allows entering values other than one which are available in dropdown.<Negative> ", new String[] {"ClncMgt32073"});
 		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifySelectBox("Merlin Home Device Check"), true, "Device Check status dropdown does not allow any value other than existing dropdown values");
           
 		   extentReport.info("1900 S Select the value other than the default one and click on save button.");
 		   ca_SchedulingAndMessagingPage.selectValueFromDropdown("Merlin Home Device Check");
 		   ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
		    
		   extentReport.info("2000 V Verify the “Device Check \"check box is displayed as checked with the set value.", new String[] {"ClncMgt32073"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyCheckBox("Merlin Home Device Check"), true, "Device Check checkbox is displayed as checked");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("9 days","Merlin Home Device Check", "View Mode"), true, "Device Check drop down is saved and set with value 9");

		   extentReport.info("2100 S Click on edit button and unchecked the \"patient transmitter Status\" check box.");
		   ca_SchedulingAndMessagingPage.clickEditButton();
		   ca_SchedulingAndMessagingPage.clickCheckBox("Merlin Home patient transmitter status");

		   extentReport.info("2200 V Verify that the drop down box is not displayed.", new String[] {"ClncMgt32073"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.isDisplayedDropdownBox("Merlin Home Device Check"),false,"Device Check dropdown is not displayed");
		  
		   ca_SchedulingAndMessagingPage.cancelAndAcceptAlert();
          	
		   extentReport.info("2300 V Verify the battery advisory section is displayed with “patient transmitter status” and “Daily device Check “ checkboxes as checked with default value displayed as “8” ", new String[] {"ClncMgt32093"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Patient Status"), true, "Battery Advisory - Patient Transmitter Check status checkbox is displayed as checked");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days", "Battery Advisory Patient Status","View Mode"), true, "Battery Advisory - Patient Transmitter Check status default value is 8");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyCheckBox("Battery Advisory Device Check"), true, "Battery Advisory - Device Check status checkbox is displayed as checked");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days", "Battery Advisory Device Check","View Mode"), true, "Battery Advisory - Device Check status default value is 8");
           
		   extentReport.info("2400 S Click on Edit button. Click on “Patient transmitter Status ”Dropdown box.");
		   ca_SchedulingAndMessagingPage.clickEditButton();
		   ca_SchedulingAndMessagingPage.clickPatientTransmitter_DeviceCheck_DropdownBox("Battery Advisory Patient Status");
			
		   extentReport.info("2500 V Verify the “Patient transmitter status” dropdown box shows default value as 8 with the dropdown values as 7,8,9,10,11,12,13,14,15 values with days as units", new String[] {"ClncMgt32093"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days","Battery Advisory Patient Status","Edit Mode"), true, "Battery Advisory - Patient trasmitter status no of days default value is 8");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyPatientTransmitter_DeviceCheck_DropdownValues("Battery Advisory Patient Status"), true, "Battery Advisory -Patient Transmitter Dropdown values 7,8,9,10,11,12,13,14,15 with days as units is displayed");
		   extentReport.reportScreenShot("Battery Advisory Section Patient Transmitter Satus- Default value is 8 and Dropdown values are 7,8,9,10,11,12,13,14,15 with days as units");
		   //Added this to close the drop down 
		   ca_SchedulingAndMessagingPage.sendspecialKeysOnPage("escape");
		   ca_SchedulingAndMessagingPage.cancelAndAcceptAlert();
			
		   extentReport.info("2600 S Click on Edit button. Click on “Daily device Check” Dropdown box.");
		   ca_SchedulingAndMessagingPage.clickEditButton();
		  // assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "Page loaded properly");
		   ca_SchedulingAndMessagingPage.clickPatientTransmitter_DeviceCheck_DropdownBox("Battery Advisory Device Check");
			 
		   extentReport.info("2700 V Verify the “Daily device Check” dropdown box shows default value as 8 with the dropdown values as 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 values with days as units.", new String[] {"ClncMgt32093"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyMerlinHome_BatteryAdvisory_DropdownNoOfDaysValue("8 days","Battery Advisory Device Check", "Edit Mode"), true, "Battery Advisory - Daily Device Check drop down default value is 8");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyPatientTransmitter_DeviceCheck_DropdownValues("Battery Advisory Device Check"), true, "Battery Advisory -Daily Device Check Dropdown values 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 with days as units is displayed");
		   extentReport.reportScreenShot("Battery Advisory Section Device check - Default value is 8 and Dropdown values are 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 with days as units");
		   //Added this to close the drop down 
		   ca_SchedulingAndMessagingPage.sendspecialKeysOnPage("escape");
			
		   extentReport.info("2800 V Verify that “Daily MIST when transmitting daily “Section is displayed ", new String[] {"ClncMgt32277"});
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyDailyMISTSection(), true, "Battery Advisory - Daily MIST when transmitting daily section is displayed");
		   
		   extentReport.info("2900 S Check the “Daily MIST when transmitting daily option” and click on save button.");
		   ca_SchedulingAndMessagingPage.clickCheckBox("Battery Advisory Daily MIST");
		   extentReport.reportScreenShot("Battery Advisory Section: Daily MIST checkbox is checked");
		   
		   ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			
		   extentReport.info("3000 S Navigate to patient list. Select an advisory patient and navigates to transmitter page.");
		   clinicianHomeTopNavPage.clickPatientListLink();
		   patientListPage.selectTierOneFilterOption("Active Clinic Patients");
		   assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Active Clinic patients");
		   
		   patientListPage.selectTierTwoFilterOption("All");
		   assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with All Active Clinic patients");
		   patientListPage.searchPatients("1022 EnrollbackICM_FVR");
		   //extentReport.reportScreenShot("Advisory Patient is displayed in Patient List");		   
		   patientListPage.clickOnPatientNameFrmList("1022 EnrollbackICM_FVR");
		   assertions.assertEqualsWithReporting(true, patientList_patientProfilePage.verifyLandingPage(), extentReport, "Patient List - Patient Profile page loaded properly");
		   
		   pl_PatientProfile_LeftNavPage.navigateToTransmitter();
		   assertions.assertEqualsWithReporting(true,pl_PatientProfile_Transmitter.verifyLandingPage() , extentReport, "Patient Profile Tranmistter Page is diplayed");
			
		   extentReport.info("3100 V Verify the ““Daily MIST” value is displayed as “1” ", new String[] {"ClncMgt32277"});
		   assertions.assertEquals( pl_PatientProfile_Transmitter.verifyDailyMISTValue("1 day"),true, " ““Daily MIST” value is displayed as “1”");
			
		   extentReport.info("3200 S Navigate to clinic admin scheduling and messaging tab “Battery Advisory Patients”section.");
		   clinicianHomeTopNavPage.clickClinicAdministrationLink();
		   assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
		   clinicAdminLeftNavPage.navigateToSchedMessagingPage();
		   assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "Scheduling & Messaging page is displayed.");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyBatteryAdvisorySection(), true, "Navigated to Battery Advisory section");
			
		   extentReport.info("3300 S Uncheck the “Daily MIST when transmitting daily option” and click on save button.");
		   ca_SchedulingAndMessagingPage.clickEditButton();
		   ca_SchedulingAndMessagingPage.clickCheckBox("Battery Advisory Daily MIST");
		   ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
			
		   extentReport.info("3400 S Navigate to patient list. Select an advisory patient and navigates to transmitter page.");
		   clinicianHomeTopNavPage.clickPatientListLink();
		   //patientListPage.selectTireOneFilterOption("Active Clinic Patients");
		   //patientListPage.selectTireOTwoFilterOption("All");
		   patientListPage.searchPatients("1022 EnrollbackICM_FVR");
		   extentReport.reportScreenShot("ICD User with Advisory Patient is listed");
		   patientListPage.clickOnPatientNameFrmList("1022 EnrollbackICM_FVR");
		   assertions.assertEqualsWithReporting(true, patientList_patientProfilePage.verifyLandingPage(), extentReport, "Patient List - Patient Profile page loaded properly");
		  
		   pl_PatientProfile_LeftNavPage.navigateToTransmitter();
		   assertions.assertEqualsWithReporting(true, pl_PatientProfile_Transmitter.verifyLandingPage(), extentReport, "Patient Profile Tranmistter Page is diplayed");
		   
		   extentReport.info("3500 V Verify the ““Daily MIST” value is displayed as “8” ", new String[] {"ClncMgt32278"});
		   assertions.assertEquals(pl_PatientProfile_Transmitter.verifyDailyMISTValue("8 days"), true, " ““Daily MIST” value is displayed as “8”");
			
		   extentReport.info("3600 S Navigate to clinic admin scheduling and messaging tab “Battery Advisory Patients”section.");
		   clinicianHomeTopNavPage.clickClinicAdministrationLink();
		   assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
		   clinicAdminLeftNavPage.navigateToSchedMessagingPage();
		   assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "Scheduling & Messaging page is displayed.");
		   assertions.assertEquals(ca_SchedulingAndMessagingPage.verifyBatteryAdvisorySection(), true, "Navigated to Battery Advisory section");
			
		   extentReport.info("3700 S Click on edit .Select the value other than the default one and click on save button.");
		   ca_SchedulingAndMessagingPage.clickEditButton();
		   ca_SchedulingAndMessagingPage. clickPatientTransmitter_DeviceCheck_DropdownBox("Battery Advisory Patient Status");
		   ca_SchedulingAndMessagingPage.selectValueFromDropdown("Battery Advisory Patient Status");
		   ca_SchedulingAndMessagingPage.saveAndAcceptAlert();
		   
		   extentReport.info("3800 S Navigate to patient list. Select an advisory patient and navigates to transmitter page.");
		   clinicianHomeTopNavPage.clickPatientListLink();
		   //patientListPage.selectTireOneFilterOption("Active Clinic Patients");
		   //patientListPage.selectTireOTwoFilterOption("All");
		   patientListPage.searchPatients("1022 EnrollbackICM_FVR");
		   patientListPage.clickOnPatientNameFrmList("1022 EnrollbackICM_FVR");
		   assertions.assertEqualsWithReporting(true, patientList_patientProfilePage.verifyLandingPage(), extentReport, "Patient List - Patient Profile page loaded properly");
		   
		   pl_PatientProfile_LeftNavPage.navigateToTransmitter();
		   assertions.assertEqualsWithReporting(true, pl_PatientProfile_Transmitter.verifyLandingPage(), extentReport, "Patient Profile Tranmistter Page is diplayed");
		   
		   extentReport.info("3900 V Verify the set value at clinic level is displayed on patient transmitter page for “Daily MIST” ", new String[] {"ClncMgt32277"});
		   assertions.assertEquals(pl_PatientProfile_Transmitter.verifyDailyMISTValue("10 days"), true, " ““Daily MIST” value is displayed as “10”");
		   
		   //This code is added to reset the values in scheduling and messaging page
		   clinicianHomeTopNavPage.clickClinicAdministrationLink();
		   assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
		   clinicAdminLeftNavPage.navigateToSchedMessagingPage();
		   assertions.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "Scheduling & Messaging page is displayed.");
		   ca_SchedulingAndMessagingPage.clickEditButton();
		   ca_SchedulingAndMessagingPage.resetValues();
		   
		   assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_02 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_02 is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}
	
}