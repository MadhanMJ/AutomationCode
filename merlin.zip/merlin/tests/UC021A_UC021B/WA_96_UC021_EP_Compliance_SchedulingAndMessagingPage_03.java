package com.test.qa.ui.tests.UC021A_UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_03 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_SchedulingAndMessagingPage clinicAdminSchedulingAndMessagingPage;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;
	private Log logger = new Log();
	List<String> patientTransmitterStatusDropDownOptions = new ArrayList<String>();
	List<String> patientDirectAlertCheckDropDownOptions = new ArrayList<String>();

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminSchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		Collections.addAll(patientTransmitterStatusDropDownOptions,"3 days","4 days","5 days","6 days","7 days");
		Collections.addAll(patientDirectAlertCheckDropDownOptions,"1 day","2 days","3 days","4 days","5 days","6 days","7 days", "8 days","9 days","10 days","11 days","12 days","13 days","14 days");
		
	}

	@Test
	public void wa_96_UC021_EP_Compliance_SchedulingAndMessagingPage_03() throws Exception {
		//TC Name - WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_03
		//TC Id - 1244380
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMClinic_ICMDevice");
		customer = testDataProvider.getCustomerData("WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_03");
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");

		try {
			softAssert = new Assertions(extentTest);
			
			extentReport.info("100 S Login with Clinic 'EP_Clinic' and Click on clinic administration tab");
			loginPage.login(login);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			
			extentReport.info("200 S Select scheduling and messaging tab the page is displayed in view mode");
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			
			extentReport.info("300 V Verify In the ICM threshold section 'Patient transmitter Status' check box it is displayed as checked and the default value is displayed as '7'",new String[]{"ClncMgt33078"});
			clinicAdminSchedulingAndMessagingPage.invisibilityOfElementLocated(clinicAdminSchedulingAndMessagingPage.pageLoading);
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttribute(clinicAdminSchedulingAndMessagingPage.patientTransmitterCommStatus,"aria-checked"),"true","'Patient transmitter Status' check box is displayed as checked");
			
			String patientTransmitterStatusDefaultValue = clinicAdminSchedulingAndMessagingPage.getText(clinicAdminSchedulingAndMessagingPage.patientTransmitterCommStatusDropDown);
			softAssert.assertEquals(patientTransmitterStatusDefaultValue,"7","'Patient transmitter Status'  default value is displayed as '7'");
			extentReport.reportScreenShot("'Patient transmitter Status' check box");
			
			extentReport.info("400 S Click on Edit button");
			clinicAdminSchedulingAndMessagingPage.clickEditButton();
			
			extentReport.info("500 S Click on 'Patient transmitter Status' Dropdown box");
			clinicAdminSchedulingAndMessagingPage.clickPatientTransmitterStatusDropDown();
			
			extentReport.info("600 V Verify dropdown box shows default value as 7 with the dropdown values 3,4,5,6,7 with days as units", new String[] {"ClncMgt33078"});
			softAssert.assertEquals(patientTransmitterStatusDefaultValue,"7","'Patient transmitter Status'  default value is displayed as '7'");
			extentReport.reportScreenShot("'Patient transmitter Status' dropdown values");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getPatientTransmitterCommStatusDropDownOptions(), patientTransmitterStatusDropDownOptions,"'Patient transmitter Status' dropdown shows 3,4,5,6,7 with days as units");
			clinicAdminSchedulingAndMessagingPage.sendspecialKeysOnPage("escape");
			
			extentReport.info("700 S Select the value other than the default one and click on save button");
			clinicAdminSchedulingAndMessagingPage.selectValueInPatientTransmitterStatusDropDown(customer.getPatientTransmitterStatus());
			extentReport.reportScreenShot("Select the value other than the default one");
			clinicAdminSchedulingAndMessagingPage.clickSaveButton();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			
			extentReport.info("800 V Verify the patient transmitter Status check box is displayed as checked with the set value", new String[] {"ClncMgt33078"});
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttribute(clinicAdminSchedulingAndMessagingPage.patientTransmitterCommStatus,"aria-checked"),"true","'Patient transmitter Status' check box is displayed as checked");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getText(clinicAdminSchedulingAndMessagingPage.patientTransmitterCommStatusDropDown),customer.getPatientTransmitterStatus(),"'Patient transmitter Status' displayed with set value");
			extentReport.reportScreenShot("'Patient transmitter Status' check box");
			
			extentReport.info("900 S Click on edit button and uncheck the \"patient transmitter Status\" check box");
			clinicAdminSchedulingAndMessagingPage.clickEditButton();
			clinicAdminSchedulingAndMessagingPage.clickElement(clinicAdminSchedulingAndMessagingPage.patientTransmitterCommStatusCheckBox);
			extentReport.reportScreenShot("Unchecked Patient transmitter Status check box");
			
			extentReport.info("1000 V Verify that the dropdown box is not displayed",new String[] {"ClncMgt33076"});
			extentReport.reportScreenShot("Patient transmitter Status dropdown is not displayed");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementNotPresent(clinicAdminSchedulingAndMessagingPage.patientTransmitterStatusDropDown), true,"Patient transmitter Status dropdown is not displayed");
			
			clinicAdminSchedulingAndMessagingPage.clickElement(clinicAdminSchedulingAndMessagingPage.patientTransmitterCommStatusCheckBox);
			clinicAdminSchedulingAndMessagingPage.clickSaveButton();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			
			extentReport.info("1100 V Verify In the ICM threshold section 'Device check' check box it is displayed as checked and the default value is displayed as '7'",new String[] {"ClncMgt33080"});
			clinicAdminSchedulingAndMessagingPage.invisibilityOfElementLocated(clinicAdminSchedulingAndMessagingPage.pageLoading);
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttribute(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckStatus,"aria-checked"),"true","'Device Check' check box is displayed as checked");
			
			String deviceCheckDefaultValue = clinicAdminSchedulingAndMessagingPage.getText(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckStatusDropDown);
			softAssert.assertEquals(deviceCheckDefaultValue,"7","'Device check'  default value is displayed as '7'");
			extentReport.reportScreenShot("'Device check' check box");
			
			extentReport.info("1200 S Click on Edit button");
			clinicAdminSchedulingAndMessagingPage.clickEditButton();
			
			extentReport.info("1300 S Click on 'Device check' Dropdown box");
			clinicAdminSchedulingAndMessagingPage.clickDeviceCheckDropDown();
			
			extentReport.info("1400 V Verify dropdown box shows default value as 7 with the dropdown  values as 1,2,3,4,5,6,7,8,9,10,11,12,13,14 values with days as units",new String[] {"ClncMgt33080", "Config23219"});
			softAssert.assertEquals(deviceCheckDefaultValue,"7","'Device check'  default value is displayed as '7'");
			extentReport.reportScreenShot("'Device check' dropdown values");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getDeviceCheckDropDownOptions(), patientDirectAlertCheckDropDownOptions,"'Device Check' dropdown shows values as 1,2,3,4,5,6,7,8,9,10,11,12,13,14 with days as units");
			clinicAdminSchedulingAndMessagingPage.sendspecialKeysOnPage("escape");
			
			extentReport.info("1500 S Select the value other than the default one and click on save button");
			clinicAdminSchedulingAndMessagingPage.selectValueInPatientDeviceCheckDropDown(customer.getPatientDeviceCheck());
			extentReport.reportScreenShot("Select the value other than the default one");
			clinicAdminSchedulingAndMessagingPage.clickSaveButton();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			
			extentReport.info("1600 V Verify the 'Device Check' check box is displayed as checked with the set value", new String[] {"ClncMgt33080", "Config23219"});
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttribute(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckStatus,"aria-checked"),"true","'Device Check' check box is displayed as checked");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getText(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckStatusDropDown),customer.getPatientDeviceCheck(),"'Device Check' displayed with set value");
			extentReport.reportScreenShot("'Device Check' check box");
			
			extentReport.info("1700 S Click on edit button and uncheck the 'Device Check Status' check box");
			clinicAdminSchedulingAndMessagingPage.clickEditButton();
			clinicAdminSchedulingAndMessagingPage.clickElement(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckCheckBox);
			extentReport.reportScreenShot("Unchecked Device Check Status check box");
			
			extentReport.info("1800 V Verify that the dropdown box is not displayed",new String[] {"ClncMgt33080"});
			extentReport.reportScreenShot("Device check Status dropdown is not displayed");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementNotPresent(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckDropDown), true,"Device check Status dropdown is not displayed");
			
			
			clinicAdminSchedulingAndMessagingPage.clickElement(clinicAdminSchedulingAndMessagingPage.patientDirectAlertCheckCheckBox);
			//clinicAdminSchedulingAndMessagingPage.selectValueInPatientTransmitterStatusDropDown("7");
			//clinicAdminSchedulingAndMessagingPage.selectValueInPatientDeviceCheckDropDown("7");
			clinicAdminSchedulingAndMessagingPage.clickSaveButton();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			clinicAdminSchedulingAndMessagingPage.acceptAlertPopUp();
			
			
			softAssert.assertAll();
		} catch (AssertionError e) {
			extentReport.fail( "WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_03 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_96_UC021_EP_Compliance_SchedulingAndMessagingPage_03 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}
