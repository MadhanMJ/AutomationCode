package com.test.qa.ui.tests.UC021A_UC021B;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class ICM_WA_ClinicAdmin_ICMAlerts extends CommonUtils {
	
	
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CA_DirectAlert_CardiacMonitorPage ClinicCardiacMonitorPage;
	CA_ClinicSettings_ReportSettingsPage clinicreportsettingpage;
	
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withoutICMDevice;
	Login loginAdminUser;
	Login loginClinicUser_withICMDeviceNoAlerts;
	Login loginClinicUser_withICMDeviceFewAlerts;
	Login loginClinicUser_withICMDeviceAllAlerts;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	
	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		ClinicCardiacMonitorPage=new CA_DirectAlert_CardiacMonitorPage(driver, extentReport);
		clinicreportsettingpage=new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withoutICMDevice = new Login();
		loginClinicUser_withICMDeviceNoAlerts = new Login();
		loginClinicUser_withICMDeviceFewAlerts=new Login();
		loginClinicUser_withICMDeviceAllAlerts=new Login();
		loginAdminUser = new Login();
		
		testDataProvider = new TestDataProvider();
	}
	
	@Test
	public void TC_ICM_WA_ClinicAdmin_ICMAlerts() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
	
		loginClinicUser_withoutICMDevice = testDataProvider.getLoginData("SJMClinic2");
		loginClinicUser_withICMDeviceNoAlerts = testDataProvider.getLoginData("SJMClinic3");
		loginClinicUser_withICMDeviceFewAlerts=testDataProvider.getLoginData("SJMClinic3");
		loginClinicUser_withICMDeviceAllAlerts=testDataProvider.getLoginData("SJMClinic3");

		extentTest.assignAuthor("Author: Kundan Kumar");
		//Clinic Management - UC021A UC021B ICM_WA_ClinicAdmin_ICMAlertsPage
		try {
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100 S Login with the Mnet clinic which does not have ICM device added and navigate to clinic administration tab.");
			loginPage.login(loginClinicUser_withoutICMDevice);
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			
			extentReport.info("200 V Verify ICM tab is not displayed under clinic administration tab",new String[] {"ClncMgt32030"});
			clinicAdminLeftNavPage.verifyCardiacMonitorlink();
			clinicianHomeTopNavPage.clickSignOutLink();
			
			extentReport.info("300 S Login with the MNet clinic having ICM device added and no ICM alerts are added. Navigate to clinic administration tab.");
			loginPage.login(loginClinicUser_withICMDeviceNoAlerts);
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
		
		    extentReport.info("400 V Verify ICM tab is displayed under clinic administration tab", new String[] {"ClncMgt32030"});
		    clinicAdminLeftNavPage.verifyCardiacMonitorlink();
		    
		    extentReport.info("500 S Click on clinic administration_ICM tab.");
		    clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
		    clinicAdminLeftNavPage.clickCardiacMonitor_Link();
		    
		    extentReport.info("600 V Verify ICM alerts classification list is not displayed",new String[] {"ClncMgt31939"});
		    ClinicCardiacMonitorPage.verifyCardiacAlertIsnotPresent();
		    clinicianHomeTopNavPage.clickSignOutLink();
		   
		    extentReport.info("700 S Login with a MNet clinic having ICM device and few alerts added. Navigate to clinic admin_ICM tab.");
		    loginPage.login(loginClinicUser_withICMDeviceFewAlerts);
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			clinicAdminLeftNavPage.clickCardiacMonitor_Link();
			
            extentReport.info("800 V Verify that only added alerts by SJM admin are displayed.",new String[] {"ClncAcct6518"});
            ClinicCardiacMonitorPage.verifyFewCardiacAlertIspresent();
            
           extentReport.info("810 V Verify Alert category classification is displayed as per the requirement.",new String[] {"ClncMgt32025"});    
           ClinicCardiacMonitorPage.verifyAlertDisplayedwithClassification();
           
           extentReport.info("900 S Edit the clinic on SJM admin and add all the remaining alerts to the same clinic.");
           loginPage.login(loginClinicUser_withICMDeviceAllAlerts); 
                     
           extentReport.info("1000 S Login with the edited clinic and navigate to clinic admin_ICM tab.");
           clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
           
           extentReport.info("1100 V Verify that all alerts added while the time of clinic creation and after editing the clinics on SJM admin pages are displayed.",new String[] {"ClncAcct6518,CommUI10034"});     
           ClinicCardiacMonitorPage.verifyAllCardiacAlertIsPresent();
           
           extentReport.info("1200 V Verify the default values for the drop down boxes under Red(Urgent), Yellow alerts(Standard), Medical Team and On-call Physician Contact Sections displayed as per the requirement",new String[] {"clncmgt30990","ClncMgt30914","ClncMgt30912","CommUI8609"});
           ClinicCardiacMonitorPage.verifyPatientAlertDropDown();
           
           extentReport.info("1210 V Symptom Episode alert is displayed and the default value is enabled.",new String[] {"ClncMgt31964","Config22970"});
           ClinicCardiacMonitorPage.validateSymptomEpisodeFlag();
           
           extentReport.info("1220 S Click on Edit button.");
           ClinicCardiacMonitorPage.clickClinicEditButton();

           extentReport.info("1230 V Verify that Symptom episode alerts check box is displayed as enabled and selected.",new String[] {"ClncMgt31962"});
           ClinicCardiacMonitorPage.validateSymptomEpisodeFlag();
           
           extentReport.info("1240 S Check/uncheck the Symptom episode alerts check box and click on save button.");
           ClinicCardiacMonitorPage.clickSaveButton();
           
           extentReport.info("1250 V Verify the system displays alerts message about the user that disabling the Record Symptom transmission disables the patient's ability to record a Symptom episode",new String[] {"ClncMgt31991"});
           ClinicCardiacMonitorPage.verifySymptomEpisodeAlertMessage();
           
           extentReport.info("1260S Click on OK button and verify the changes are saved.",new String[] {"ClncMgt31962"});      
		   ClinicCardiacMonitorPage.verifySymptomEpisodeChange();
		   
		   extentReport.info("1300 S Click on Edit button.Select the values from the drop down boxes for fields under Urgent and Standard Alerts notification during and after clinic hours Sections.");
		   ClinicCardiacMonitorPage.clickClinicEditButton();
		   ClinicCardiacMonitorPage.selectUrgentAndStandardValueforAlerts();
		   
           extentReport.info("1400 V Verify the selected filed boxes are displayed as mandatory.",new String[] {"ClncMgt30316","ClncMgt30910"});
          ClinicCardiacMonitorPage.verifySelectedFieldAsMandatatory();
          
           extentReport.info("1500 V Verify the fields Email,phone are displayed as mandatory with the prepopulated values saved during clinic creation under clinic contact information section on ClinicAdmin_ICM page <>",new String[] {"ClncMgt29701"});
           ClinicCardiacMonitorPage.verifyClinicContactInformation();
           
           extentReport.info("1600 S Select and save fax and Sms options under urgent,standard,medical team Sections.");
           ClinicCardiacMonitorPage.selectUrgentAndStandardValueforAlerts();
           ClinicCardiacMonitorPage.clickSaveButton();
           
          extentReport.info("1700 V Verify fax and text messages editable fields are displayed as mandatory under Clinic contact information section on ClinicAdmin_ICM page",new String[] {"ClncMgt29701"});
          ClinicCardiacMonitorPage.verifyClinicContactInformation();
          
         extentReport.info("1800 S Edit and make some changes to drop down filed for Red (Urgent), Yellow alerts(Standard), Medical Team and On-call Physician Contact Sections,Clinic contact info section and click on save button on ClinicAdmin_ICM page");
         ClinicCardiacMonitorPage.clickClinicEditButton();
         ClinicCardiacMonitorPage.editUrgentAndStandardValueforAlerts();
         ClinicCardiacMonitorPage.clickCancelButton();
         
          extentReport.info("1900 V Verify that the changes made are saved successfully.",new String[] {"ClncMgt30317","ClncMgt30911"});
          ClinicCardiacMonitorPage.verifyEditedUrgentAndStandardValueforAlerts();
          
         extentReport.info("2000 S Edit and make some changes to drop down field for Red (Urgent),Yellow alerts(Standard), Medical Team and On-call Physician Contact Sections ,Clinic contact info section and click on cancel button on ClinicAdmin_ICM page");
         ClinicCardiacMonitorPage.clickClinicEditButton();
         ClinicCardiacMonitorPage.selectUrgentAndStandardValueforAlerts();
         ClinicCardiacMonitorPage.clickCancelButton();
         
         extentReport.info("2100 V Verify that the changes made are not saved successfully.",new String[] {"ClncMgt30318"});
         ClinicCardiacMonitorPage.verifyEditedUrgentAndStandardValueforAlerts();
         
         extentReport.info("2200 S Change alerts classification from urgent to standard or to off and click on save button on ClinicAdmin_ICM page");
         ClinicCardiacMonitorPage.editAlertClassification();
         ClinicCardiacMonitorPage.clickSaveButton();
         
         extentReport.info("2300 V Verify that changes are saved successful",new String[] {"ClncMgt30317"});
         ClinicCardiacMonitorPage.verifyEditedAlertClassification();
         
         extentReport.info("2400 S Change alerts classification from urgent to standard or to off and click on cancel button on ClinicAdmin_ICM page");
         ClinicCardiacMonitorPage.editAlertClassification();
         ClinicCardiacMonitorPage.clickCancelButton();
         
         extentReport.info("2500 V Verify that changes are not saved successful",new String[] {"ClncMgt30318"});
         ClinicCardiacMonitorPage.verifyEditedAlertClassification();
         
        extentReport.info("2600 S Click on edit button change some values and try to navigate to any of the primary or secondary tab by clicking on them.");
        ClinicCardiacMonitorPage.clickClinicEditButton();
        ClinicCardiacMonitorPage.editAlertClassification();
        clinicAdminLeftNavPage.clickReportSettingsLink();
        
        
         extentReport.info("2700 V Application will throw the message indicating the data will not be saved.",new String[] {"ClncMgt30397"});
         ClinicCardiacMonitorPage.verifyDataIsNotSavedPopup();
         
         extentReport.info("2800 S Click on any of the primary and secondary tabs from ICM page.");
         clinicAdminLeftNavPage.clickCardiacMonitorLink();
         clinicAdminLeftNavPage.clickReportSettingsLink();
         
        extentReport.info("2900 V Verify the navigation is successful to the selected pages",new String[] {"ClncMgt31907"});
        clinicreportsettingpage.verifycardiacMonitorOptionsAvailability();
        
        extentReport.info("3000 S Click on show device link.");
        ClinicCardiacMonitorPage.clickShowDevicesLink();
        
        extentReport.info("3100 V Verify that only ICM Device models are displayed in alphabetical order",new String[] {"ClncMgt30400"});
        ClinicCardiacMonitorPage.verifydevices_ICM();
       
        extentReport.info("3200 S Enter invalid data while editing on ICM page. Click on save button.");
        ClinicCardiacMonitorPage.clickClinicEditButton();
        //ClinicCardiacMonitorPage.sendInvalidDataInClinicContactInfo();
        ClinicCardiacMonitorPage.clickSaveButton();
           
        
        extentReport.info("3300 V Verify that validation error message is displayed  highlighting the invalid fields.",new String[] {"ClncMgt30319","ClncMgt30323"});
        
        ClinicCardiacMonitorPage.clickCancelButton();
        
        extentReport.info("3400 S Login as an DMR user and navigate to ClinicAdministarion_ICM Tab.Edit some values and save it.");


       extentReport.info("3500 V Verify that DMR user is able to make and save the changes.",new String[] {"DMR1660"});

       extentReport.info("3600 S Navigate to clinic user page.Click on any of the item in the left nav panel(For eg. Clinic Profile page).");

       extentReport.info("3700 V Verify that the item clicked in the left nav pane ( Clinic Profile page) is displayed",new String[] {"ClncnMgt15461"});

     //******************************ICD/PM patient info column **********************************************

         extentReport.info("3800 S Navigate to ICD/PM tab.");
 
         extentReport.info("3900 V Verify the inform patient column is displayed with unchecked check boxes for all the alerts ",new String[] {"ClncMgt32029","CommUI10034"});
 
         extentReport.info("4000 S Navigate to clinic admin ICD/Pm alerts page and Check the patient column for few alerts. Click on Save.");
 
         extentReport.info("4100 S Navigate to ICD/PM patient alert page.");

        extentReport.info("4200 V Verify that the inform patient checkbox checked on clinic alerts are displayed as checked on patient alerts page.",new String[] {"ClncMgt32029"});
 
        extentReport.info("4300 S Navigate to ICM patient alerts tab.");

        extentReport.info("4400 V Verify that the inform patient check box is not displayed on patient alerts page",new String[] {"ClncMgt32029","ClncMgt33041"});


       

		
		} 
		
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*	@AfterMethod
		public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
			String status = null;
			String testMethodName = result.getMethod().getMethodName();
			 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
				 status = "Failure";
			    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			    	status = "Success";
			    } 
			
			writeInTextFile(testMethodName, status);
		}*/
		
		
	
	}
}
