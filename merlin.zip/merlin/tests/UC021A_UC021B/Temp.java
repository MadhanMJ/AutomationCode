package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
//import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class Temp extends CommonUtils {
	CommonUtils utils;
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	AddSecondarylocationPage addSecondarylocationPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ViewCustomerPage viewCustomerPage;	
	ExtentTest extentTest;
	ExtentReport extentReportTest;

	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	String testName,customerName,fieldValue, first_name, last_name, temp_pwd, location, area_code, main_phone, language, legal_jurisdiction, time_zone, customer_type, country,existingLocation,sql ;

	Assertions assertions ;
	Assertions softAssert;
	DataBaseConnector dataBaseConnector;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() throws SQLException, InterruptedException {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		addCustomerPage= new AddCustomerPage (driver, extentReport);
		addSecondarylocationPage= new AddSecondarylocationPage (driver, extentReport);		
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		utils= new CommonUtils();
		/*
		 * dataBaseConnector = new DataBaseConnector(); sql
		 * ="select count(*) cnt from customers.customer_location cl inner join users.customer_account ca on cl.customer_id = ca.customer_id inner join users.user_record ur on ur.user_record_id = ca.user_record_id where ur.logon_user_name ='stmayoclinichospital' and cl.name = 'ClinicLoc_qRUdf'"
		 * ; dataBaseConnector.getConnection(); int count =
		 * dataBaseConnector.executeScalar(sql);
		 */ 
	}

	/*
	 * AUTHOR: ChandraMohan.Singaram 
	 * TC ID : 1243615
	 */

	@Test(groups= {"Regression"})
	public void uC013D_E01_01() throws Exception { 
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		softAssert = new Assertions(extentTest);
		assertions =  new Assertions(extentTest);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData(testName);

		extentTest.assignAuthor("Author: ChandraMohanSingaram");		

		try {
			String userId = CommonUtils.randomUserId();
			customer.setUserid(userId);
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page.");
			loginPage.login(login,"externaluser");
			customerListPage.verifyLandingPage();
			//customerName=customerListPage.searchCustomerAndClick(customer.getCustomerName());
			//customerName=customerListPage.getAndclickOnFirstCustomerLink();

			extentReport.info("200-V-Verify that the system displays page AD005 (Customer Profile) with the customer's details pre-populated.");
			fieldValue= "CustomerName";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+" detail is Prepopulated");

			fieldValue= "CustomerType";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "ClinicLocation";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "CountryCode";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "AreaCode";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "MainPhone";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "Country";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "Email";
			softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "ClinicTimeZone";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "LegalJurisdiction";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "ClinicLanguage";
			//softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "UserID";
			softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "FirstName";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true,fieldValue+"detail is pre-populated. ");

			fieldValue= "LastName";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "MainContactEmail";
			softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			existingLocation= customerProfilePage.readCustomerDataInViewMode("ClinicLocation");

			extentReport.info("300-S-The actor clicks ‘Add a secondary location’ button");
			customerProfilePage.goToAddSecondaryLocationPage();
			extentReport.info("400-V-Verify that the system displays page Add Secondary location ",new String[] {"ClncAcct2345"});
			addSecondarylocationPage.verifyAddSecLocPage();

			/**--------------- Missing Clinic location name -------------------------**/
			extentTest=	extentReport.info("500-S-The actor leaves the Clinic location name field blank or enters a couple of space, then clicks the 'Save' button.");

			addSecondarylocationPage.clickSaveButton();

			extentTest=	extentReport.info("600-V-Verify that the system displays alert message CS 818 and verify that the blank Clinic location is not stored in DB location table",new String[] {"ClncAcct310"},new String[] {"ClncAcct5973"},new String[] {"ClncAcct5974"},new String[] {"ClncAcct5977"});
			//assertions.assertEquals(true, addSecondarylocationPage.verifyWarningMsg(),"600-V-Verify that the system displays alert message CS 818 ");
			assertions.assertEqualsWithReporting(true, addSecondarylocationPage.verifyWarningMsg(),extentReport,"displays Secondary location alert MIssing message **********CS 818 ");
			
/*---------------Database Validation for Adding Secondary location-----	*/	
/*---------------Database Validation for Adding Secondary location-----*/		

			dataBaseConnector.getConnection();
			//dataBaseConnector.executeQuery("select count(*) cnt from customers.customer_location");
			String sql="select cl.name from customers.customer_location cl inner join users.customer_account ca on cl.customer_id = ca.customer_id "+
					"inner join users.user_record ur on ur.user_record_id = ca.user_record_id " +
					"where ur.logon_user_name ='stmayoclinichospital' and cl.name = 'ClinicLoc_qRUdf'";
			System.out.println("Generated Sql Query is   "+sql);
			ResultSet emptySecLocCount = dataBaseConnector.executeQuery(sql);
			int count = 0;
			while (emptySecLocCount.next()) {
				 count= emptySecLocCount.getInt("cnt");
			}
			extentReport.info("600-V-Verify that the system displays alert message CS 818 and verify that the blank Clinic location is not stored in DB location table.");
			softAssert.assertEquals(count,0,"Blank Clinic location is not stored in DB location table.");
			
			/*----------------- Clinic location name morethan 30 characters-----------------------*/
			extentTest=	extentReport.info("900 S The actor tries to enter a location name greater than 30 characters");
			addSecondarylocationPage.addSecondaryLocationValue("clinicSecondaryLocationValueMorethan30Characters", false);
			String enterdSecLocVal=addSecondarylocationPage.readEnteredSecondaryLocationValue() ;

			extentReport.info("1000 V - Verify that the System allows to enter only 30 characters.",new String[] {"CommUI4622"});
			softAssert.assertEquals(enterdSecLocVal.length(), 30,"Verify that the System allows to enter only 30 characters");

			/*-------------------- Existing Clinic location name -------------*/
			extentTest=	extentReport.info("1100 S The actor enters an valid Clinic Location name which already exists as a Clinic location for this clinic , then clicks the 'Save' button");
			addSecondarylocationPage.addSecondaryLocationValue(existingLocation, false);
			addSecondarylocationPage.clickSaveButton();
			

			
			extentTest=	extentReport.info("1200 V - Verify that the System shall validate Customer Location data entered by the Actor and displays message CM 806  and verify that the duplicate Clinic location is not stored in DB(location table) again.",new String[] {"ClncAcct310"},new String[] {"ClncAcct299"},new String[] {"CommFn722"},new String[] {"ClncAcct5973"},new String[] {"ClncAcct5974"});
			softAssert.assertEqualsWithReporting(true, addSecondarylocationPage.existingsecLocErrorMsg(),extentReport,"verify that the duplicate Clinic location is not stored ");
			

			dataBaseConnector.getConnection();
			sql="select count(*) cnt from customers.customer_location cl inner join users.customer_account ca on cl.customer_id = ca.customer_id "+ 
					"inner join users.user_record ur on ur.user_record_id = ca.user_record_id "+ "where ur.logon_user_name ='" + userId + "' and cl.name = '" + existingLocation + "'";
			System.out.println("Generated Sql Query for adding Existing Location '"+ existingLocation + "'is   "+sql);
			
			ResultSet existingSecLocCount = dataBaseConnector.executeQuery(sql);
			count = 0;
			while (existingSecLocCount.next()) {
				 count= existingSecLocCount.getInt("cnt");
			}
			
			System.out.println("Existing Location REcord count is "+count);
			softAssert.assertEquals(count,1,"Existing Clinic location is not stored in DB location table again.");


			extentTest=	extentReport.info("1200 V - Verify that the System shall validate Customer Location data entered by the Actor and displays message CM 806  and verify that the duplicate Clinic location is not stored in DB(location table) again.",new String[] {"ClncAcct310"},new String[] {"ClncAcct299"},new String[] {"CommFn722"},new String[] {"ClncAcct5973"},new String[] {"ClncAcct5974"});
			softAssert.assertEqualsWithReporting(true, addSecondarylocationPage.existingsecLocErrorMsg(),extentReport,"verify that the duplicate Clinic location is not stored ");

			extentTest=	extentReport.info("1100 S The actor enters an valid Clinic Location name which already exists as a Clinic location for this clinic , then clicks the 'Save' button");
			addSecondarylocationPage.addSecondaryLocationValue("clinicSecondaryLocationValueMorethan30Characters", false);
			addSecondarylocationPage.clickSaveButton();

			extentTest=	extentReport.info("1200 V - Verify that the System shall validate Customer Location data entered by the Actor and displays message CM 806  and verify that the duplicate Clinic location is not stored in DB(location table) again.",new String[] {"ClncAcct310"},new String[] {"ClncAcct299"},new String[] {"CommFn722"},new String[] {"ClncAcct5973"},new String[] {"ClncAcct5974"});
			softAssert.assertEqualsWithReporting(true, addSecondarylocationPage.existingsecLocErrorMsg(),extentReport,"verify that the duplicate Clinic location is not stored ");

			extentReport.info("1500-S-End Test Case.");
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
