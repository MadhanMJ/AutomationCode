package com.test.qa.ui.tests.UC021A_UC021B;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_EP_ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	TestDataProvider testDataProvider;
	private String testName;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage merlinAtHomePage;
	CA_ClinicAdminMobAppTransPage ClinicAdminMobAppTransPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CA_SchedulingAndMessagingPage ca_SchedulingAndMessagingPage;
	private Log logger = new Log();
	
	@BeforeClass
	public void initialize() {
		
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		merlinAtHomePage= new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		ClinicAdminMobAppTransPage = new CA_ClinicAdminMobAppTransPage(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		ca_SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);
	}
	
	/*
	 * TC Name: 11.0_WA_EP_ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01ication_feature_for_PercentPacingAlerts_01
	 * TC ID: 1227883
	 */
	
	@Test	
	public void ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		login = testDataProvider.getLoginData("PhAdmDirUs");
		
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
				
		extentTest.assignAuthor("Snehal Mane");		

		try {
			Assertions assertion =  new Assertions(extentTest);

			extentTest =  extentReport.info("100 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");	
			
			loginPage.login(login, "externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");

			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");

			extentReport.info("200 V Verify that under Direct Alerts Settings, Merlin@home Transmitter tab is available and navigate to Direct Alerts Settings for Non-Bluetooth ICD/ CRT-D devices page.", new String[] {"ClncMgt33113"});

			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyMerlinHomeTransmitterTab(), extentReport, "Merlin@home Transmitter tab is present");
			
			clinicAdminLeftNavPage.navigateToMerlinAtHomeTransmitterPage();
			assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyLandingPage(), extentReport, "Merlin@home Transmitter page is displayed");
			
			extentReport.info("300 S Click on edit button, and check the page is opened in edit mode.");
		//	assertion.assertEqualsWithReporting(true,merlinAtHomePage.verifyEditButton(),extentReport,"Merlin@Home edit button is displayed");
		//	merlinAtHomePage.verifyEditMode();
		//	assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifySaveButton(), extentReport, "Save button is present on Merlin@Home edit page after clicking edit button");
		//	assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyCancelButton(), extentReport, "Cancel button is present on Merlin@Home edit page after clicking edit button");
			merlinAtHomePage.validateEditMode();
			extentReport.reportScreenShot("Page is opened in edit mode");
			
			//alert name is different, verified with group ID: 270, 271
			extentReport.info("400 S Change few Alerts Categories (Urgent, standard or Off) for percent pacing alert group and click on save button");
//			⦁ Percent RV Pacing above Threshold (Display Group 270) (non-BLE ICD/CRT-D devices), 
//			⦁ Percent BiV Pacing below Threshold (Display Group 271) (non-BLE ICD/CRT-D devices)
			
//			assertion.assertEqualsWithReporting(true,merlinAtHomePage.selectAlert("Percent RV pacing greater than"),extentReport,"Change Alert Category for the AlertType - Percent RV pacing greater than");
//			assertion.assertEqualsWithReporting(true,merlinAtHomePage.selectAlert("Percent BiV pacing less than"),extentReport,"Change Alert Category for the AlertType - Percent BiV pacing less than");
//			assertion.assertEqualsWithReporting(true,merlinAtHomePage.selectAlert("*RV Percent Pacing Greater Than Limit"),extentReport,"Change Alert Category for the AlertType - *RV Percent Pacing Greater Than Limit");
//			assertion.assertEqualsWithReporting(true,merlinAtHomePage.selectAlert("*BiV Percent Pacing Less Than Limit"),extentReport,"Change Alert Category for the AlertType - *BiV Percent Pacing Less Than Limit");
//16			
			String RvAlertSTatusUpdatedRv = merlinAtHomePage.changeAlertClassification("Percent RV pacing greater than {{0}}% over {{1}} days");
			String RvAlertSTatusAfterUpdatedRv = merlinAtHomePage.verifyAlertClassificationStatus("Percent RV pacing greater than {{0}}% over {{1}} days");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"Percent RV pacing greater than {0}% over {1} days\"");
			String RvAlertSTatusUpdatedBiv = merlinAtHomePage.changeAlertClassification("Percent BiV pacing less than {{0}}% over {{1}} days");
			String RvAlertSTatusAfterUpdatedBiv = merlinAtHomePage.verifyAlertClassificationStatus("Percent BiV pacing less than {{0}}% over {{1}} days");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"Percent BiV pacing less than {0}% over {1} days\"");
			
			
			extentReport.info("500 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved.", new String[] {"ClncMgt33113"});
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"Percent RV pacing greater than {0}% over {1} days\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"Percent BiV pacing less than {0}% over {1} days\"");	
			merlinAtHomePage.clickSave();
			
			//Blocker
			extentReport.info("600 V Verify pop up is displayed by webpage for confirmation Click on OK.", new String[] {"ClncMgt33113"});
			String alertTextActual = merlinAtHomePage.VerifySavePopup();
			extentReport.reportScreenShot("Save alert popup is dispalyed");
			assertion.assertEqualsWithReporting(true,alertTextActual.contains("Success"), extentReport, "Verified Success message pop-up is displayed on webpage");	
			merlinAtHomePage.clickSavePopup();
			assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyAfterclickSavePopup(), extentReport, "Click on Save popup is successful");
			
			//Blocker
			extentReport.info("700 V Verify the changes are saved.", new String[] {"ClncMgt33113"});
			RvAlertSTatusAfterUpdatedRv = merlinAtHomePage.verifyAlertClassificationStatus("Percent RV pacing greater than {{0}}% over {{1}} days");
			RvAlertSTatusAfterUpdatedBiv = merlinAtHomePage.verifyAlertClassificationStatus("Percent BiV pacing less than {{0}}% over {{1}} days");
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");	
			
			
			//Blocker
			//Functionality not cleared...Added blocker - pending with praveen
			extentReport.info("800 V Enhanced diagnostics collection feature has been Disabled on Scheduling & Messaging page for the clinic.");
			clinicAdminLeftNavPage.navigateToSchedulingMessagingPage();
			assertion.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "SchedulingAndMessagingPage is displayed");
			ca_SchedulingAndMessagingPage.verifyEnhancedDiagnosticsCollection();
			assertion.assertEqualsWithReporting(false, ca_SchedulingAndMessagingPage.verifyEnhancedDiagnosticsCollection(), extentReport, "Enhanced collection feature is Disabled");
			extentReport.reportScreenShot("Enhanced diagnostics collection feature has been disabled");
					
			//Blocker
			extentReport.info("900 V Verify Alerts Categories (Urgent, standard or Off) are NOT editable for percent pacing alert group", new String[] {"ClncMgt33112"});
			clinicAdminLeftNavPage.clickMerlinHomeTransmitterLink();
			assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyLandingPage(), extentReport, "Merlin@home Transmitter page is displayed");
			merlinAtHomePage.validateEditMode();
			extentReport.reportScreenShot("Page is opened in edit mode");
			//add method to check alerts are not editable
//41			
			//Test setup 2
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("DirectAll");
			
			extentReport.info("800 S Login with Test setup 1 and navigate to Clinic Administration tab >Direct Alerts Settings.");		
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");

			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");

			extentReport.info("900 V Verify that under Direct Alerts Settings, Mobile App Transmitter tab is available and navigate to Direct Alerts Settings for Bluetooth ICD/ CRT-D devices page.", new String[] {"ClncMgt33113"});

			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
			assertion.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyMobileAppTransmitterTab(), extentReport, "Mobile App Transmitter tab is present");
			
			clinicAdminLeftNavPage.clickMobileAppTransmitterLink();
			assertion.assertEqualsWithReporting(true, ClinicAdminMobAppTransPage.verifyLandingPage(), extentReport, "Mobile app Transmitter page is displayed");
			
			extentReport.info("1000 S Click on edit button, and check the page is opened in edit mode.");
//			assertion.assertEqualsWithReporting(true,ClinicAdminMobAppTransPage.verifyEditButton(),extentReport,"Edit button is displayed on Mobile App Transmitter page");
//			ClinicAdminMobAppTransPage.clickClinicEditButton();
//			assertion.assertEqualsWithReporting(true, ClinicAdminMobAppTransPage.verifySaveButton(), extentReport, "Save button is present on Mobile App Transmitter edit page after clicking edit button");
//			assertion.assertEqualsWithReporting(true, ClinicAdminMobAppTransPage.verifyCancelButton(), extentReport, "Cancel button is present on Mobile App Transmitter edit page after clicking edit button");
			ClinicAdminMobAppTransPage.validateEditMode();
			extentReport.reportScreenShot("Page is opened in edit mode");
			
			//Blocker
			extentReport.info("1100 S Change few Alerts Categories (Urgent, standard or Off) for percent pacing alert group and click on save button.");
			String RvAlertSTatusUpdatedRv1 = merlinAtHomePage.changeAlertClassification("RV percent pacing > threshold");
			String RvAlertSTatusAfterUpdatedRv1 = merlinAtHomePage.verifyAlertClassificationStatus("RV percent pacing > threshold");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"RV percent pacing > threshold\"");
			String RvAlertSTatusUpdatedBiv1 = merlinAtHomePage.changeAlertClassification("BiV percent pacing < threshold");
			String RvAlertSTatusAfterUpdatedBiv1 = merlinAtHomePage.verifyAlertClassificationStatus("BiV percent pacing < threshold");
			extentReport.reportScreenShot("Changed  Alert Categories (Urgent, standard or Off) for \"BiV percent pacing < threshold\"");
			
			//alert name is different, verified with group ID: 2108, 2109
			extentReport.info("1200 V Verify Alerts Categories (Urgent, standard or Off) for percent pacing alert are editable and changes gets saved.", new String[] {"ClncMgt33113"});
//			⦁ V/RV Percent Pacing Greater than Limit (Display Group 2108) (BLE ICD/CRT-D devices),               
//			⦁ LV/BiV Percent Pacing Less than Limit (Display Group 2109) (BLE ICD/CRT-D devices)
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv1.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv1), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv1.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv1), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");	
			merlinAtHomePage.clickSave();
			
			extentReport.info("1300 V Verify pop up is displayed by webpage for confirmation Click on OK.", new String[] {"ClncMgt33113"});
			String alertText = merlinAtHomePage.VerifySavePopup();
			extentReport.reportScreenShot("Save alert popup is dispalyed");
			assertion.assertEqualsWithReporting(true,alertText.contains("Success"), extentReport, "Verified Success message pop up is displayed on webpage");	
			merlinAtHomePage.clickSavePopup();
			assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyAfterclickSavePopup(), extentReport, "Click on Save popup is successful");
			
			extentReport.info("1400 V Verify the changes are saved.", new String[] {"ClncMgt33113"});
			RvAlertSTatusAfterUpdatedRv1 = merlinAtHomePage.verifyAlertClassificationStatus("*RV Percent Pacing Greater Than Limit");
			RvAlertSTatusAfterUpdatedBiv1 = merlinAtHomePage.verifyAlertClassificationStatus("*BiV Percent Pacing Less Than Limit");
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedRv1.equalsIgnoreCase(RvAlertSTatusAfterUpdatedRv1), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"RV Percent Pacing Greater Than Limit\"");	
			assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedBiv1.equalsIgnoreCase(RvAlertSTatusAfterUpdatedBiv1), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"*BiV Percent Pacing Less Than Limit\"");	
			
			//Test case ends
			
						
		}
		catch (AssertionError e) {
			
			extentTest = extentReport.fail("ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01 due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			extentTest.fail("ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01 due to assertion failure"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01 due to some exception");
			extentTest.fail("ClinicAdmin_PatientNotification_for_PercentPacingAlerts_01 due to some exception"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}				
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {

		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
