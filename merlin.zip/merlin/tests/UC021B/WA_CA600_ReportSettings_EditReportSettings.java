package com.test.qa.ui.tests.UC021B;

import com.test.qa.utilities.CommonUtils;

public class WA_CA600_ReportSettings_EditReportSettings extends CommonUtils {
}
