package com.test.qa.ui.tests.UC021B;

import java.lang.reflect.Method;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_CA400_CA500_DirectAlerts_EditDirectAlerts02 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
    CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
    ClinicianHomeTopNavPage clinicianHomeTopNavPage;
    CommonUtils commonUtils;
    CA_LeftNavPage clncAdnLftNav;
    AppHomeTopNavPage appHomeTopNavPage;
    CustomerListPage customerListPage;
    CA_ClinicAdminMobAppTransPage clncAdnMobAppTnsPg;
    CA_DirectAlert_CardiacMonitorPage cardiacMonitorPage;
    ClinicianHomePage clinicianHomePage;
    CA_SchedulingAndMessagingPage ca_SchedulingAndMessagingPage;
    
    @BeforeClass
   	public void initialize() {
   		
   		driver.close();
   		driver = CommonUtils.initializeDriver();
   		loginPage = new LoginPageWithPOJO(driver, extentReport);
   		login = new Login();
   		testDataProvider = new TestDataProvider();
   		customer = new Customer();
   		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
   		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
   		commonUtils=new CommonUtils();
   		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
   		clncAdnLftNav=new CA_LeftNavPage(driver, extentReport);
   		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
   		customerListPage = new CustomerListPage(driver, extentReport);
   		clncAdnMobAppTnsPg = new CA_ClinicAdminMobAppTransPage(driver, extentReport);
   		clinicianHomePage=new ClinicianHomePage(driver,extentReport);
   		ca_SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);
    }
    @Test
   	 public void CA400_CA500_DirectAlerts_EditDirectAlerts02() throws Exception{
     	testName = CommonUtils.getTestName();
 		CommonUtils.currentTestCaseName = testName;

 		extentTest = extentReport.initiateTest(testName);
 		
 		
 		login = testDataProvider.getLoginData("DirectAll");
 		extentTest.assignAuthor("Abhishek kumar");
 		
 		try {
 			Assertions assertion = new Assertions(extentTest);



 			extentTest = extentReport.info("100-S- The Actor logs into the Clinic A "
 					+ "and navigates to Direct Alerts settings for ICD/CRT-D page.");

 			loginPage.login(login,  "externaluser");
 			//assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");



 			clinicianHomeTopNavPage.clickClinicAdministrationLink();
 			//assertion.assertEqualsWithReporting(true,clncAdnLftNav.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");

 			//assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyDirectAlertTab(), extentReport, "Direct Alerts Settings is present");
 			//assertion.assertEqualsWithReporting(true, clncAdnLftNav.verifyMerlinHomeTransmitterTab(), extentReport, "Merlin@home Transmitter tab is present");

 			//clncAdnLftNav.clickMerlinHomeTransmitterLink();
 			//assertion.assertEqualsWithReporting(true, directAlert_MerlinAtHomePage.verifyLandingPage(), extentReport, "Merlin@home Transmitter page is displayed");

 			//extentTest = extentReport.info("200-S- Click on the Edit button.");
 			//directAlert_MerlinAtHomePage.clickEditButton();
 			
 			
			/*
			 * extentTest = extentReport.
			 * info("300-V- Verify that the Direct Alerts settings for ICD/CRT-D page is displayed in the Edit mode. <ClncMgt30312>"
			 * ); assertion.assertEqualsWithReporting(true,directAlert_MerlinAtHomePage.
			 * verifyEditButton(),extentReport,"Merlin@Home edit button is displayed");
			 * directAlert_MerlinAtHomePage.openEditAdditonalNotificationSectioon();
			 * assertion.assertEqualsWithReporting(true,
			 * directAlert_MerlinAtHomePage.verifySaveButton(), extentReport,
			 * "Save button is present on Merlin@Home edit page after clicking edit button"
			 * ); assertion.assertEqualsWithReporting(true,
			 * directAlert_MerlinAtHomePage.verifyCancelButton(), extentReport,
			 * "Cancel button is present on Merlin@Home edit page after clicking edit button"
			 * );
			 */
 			
 			extentTest = extentReport.info("310- V Verify that the instructional texts are present"
 					+ " for the following:"+"<\br>"+"Alert Transmissions (below alert list) "
 							+ ""+"<\br>"+"Alert Transmission Instructions:"
 									+ " To inform the user that all alerts are visible"
 									+ " on the IB001 "
 									+ "Recent"+"Transmissions page"+"<\br>"+
 									"2. On-Call Physician"+
 									"<\br>"+"3. Emergency Contact"+"<\br>"
 									+"4. AT/AF Alerts"+"<\br>"+"5. Reception of Alerts (Reception of Alerts "
 									+ "Instructions: To inform the user that the alert detection"
 									+ " is dependent on patient transmitter software version)",new String[] {"ClncMgt23907","ClncMgt24129"});
 			
 			
			/*
			 * extentTest = extentReport.
			 * info("400 V Verify that all the alerts displayed are classified as Urgent Alerts by default for ICD/Pacemaker pages."
			 * ,new String[] {"ClncMgt24127","ClncMgt24123","ClncMgt24123"});
			 * assertion.assertEqualsWithReporting(true,
			 * clncAdnLftNav.verifypacemaker_CRTPTab(), extentReport,
			 * "Pacemakers/CRT-P devices tab is present");
			 * clncAdnLftNav.navigatePacemaker_CRTPLink();
			 * assertion.assertEqualsWithReporting(true,pacemaker.verifyLandingPage(),
			 * extentReport,"Pacemaker landing page is displayed");
			 * assertion.assertEqualsWithReporting(true,pacemaker.verifyDefaultSTatusOfAlert
			 * ("Red"),extentReport,"Red Radio button is in selected by default");
			 */
			
			
			extentTest = extentReport.info("600 S Change the classification "
					+ "for an alert from urgent to Standard and for another "
					+ "alert from Urgent to None.");
			
			/*
			 * pacemaker.clickEditButton(); String RvAlertSTatusUpdatedSTEpisode =
			 * pacemaker.changeAlertCategoryToOtherAlert("*ST Episode Detected","yellow");
			 * String RvAlertSTatusAfterUpdatedSTEpisode =
			 * pacemaker.verifyAlertClassificationStatus("*ST Episode Detected");
			 * extentReport.
			 * reportScreenShot("Changed  Alert Categories for \"*ST Episode Detected\" from urgent to standard"
			 * ); String RvAlertSTatusUpdatedDeviceProgrammed = pacemaker.
			 * changeAlertCategoryToOtherAlert("Device Programmed to Emergency Pacing Values"
			 * ,"off"); String RvAlertSTatusAfterUpdatedDeviceProgrammed=pacemaker.
			 * verifyAlertClassificationStatus("Device Programmed to Emergency Pacing Values"
			 * );
			 */
			
			
			extentReport.info("700 S Click on Save button.");
			//pacemaker.clickSaveButton();
			
			
			extentReport.info("800 V Verify that the modified alert classification have been saved.", new String[] {"ClncMgt33112","ClncMgt24130"});
			//assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedSTEpisode.equalsIgnoreCase(RvAlertSTatusAfterUpdatedSTEpisode), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"Percent RV pacing greater than {0}% over {1} days\"");	
			//assertion.assertEqualsWithReporting(true,RvAlertSTatusUpdatedDeviceProgrammed.equalsIgnoreCase(RvAlertSTatusAfterUpdatedDeviceProgrammed), extentReport, "Changed  Alert Categories (Urgent, standard or Off) for \"Percent BiV pacing less than {0}% over {1} days\"");	
			
			
			
			extentReport.info("900 V Ensure that clinic preference for enhanced diagnostics collection feature has been enabled for the\r\n"
					+ "clinic.");
			//clncAdnLftNav.navigateToSchedulingMessagingPage();
			//assertion.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyLandingPage(), extentReport, "SchedulingAndMessagingPage is displayed");
			//ca_SchedulingAndMessagingPage.verifyEnhancedDiagnosticsCollection();
			//assertion.assertEqualsWithReporting(true, ca_SchedulingAndMessagingPage.verifyEnhancedDiagnosticsCollection(), extentReport, "Enhanced collection feature is Disabled");
			//extentReport.reportScreenShot("Enhanced diagnostics collection feature has been enabled");
			
			
			extentTest = extentReport.info("1000 S Navigate to Merlin@home transmitter again click on Edit button on the page.");
			clncAdnLftNav.clickMerlinHomeTransmitterLink();
 			assertion.assertEqualsWithReporting(true, directAlert_MerlinAtHomePage.verifyLandingPage(), extentReport, "Merlin@home Transmitter page is displayed");
 			assertion.assertEqualsWithReporting(true,directAlert_MerlinAtHomePage.verifyEditButton(),extentReport,"Merlin@Home edit button is displayed");
 			
 			directAlert_MerlinAtHomePage.clickEditButton();
 			
 			
 			extentTest = extentReport.info("1100 Change the alert classification for Percent pacing Alerts (Percent RV Pacing above Threshold, Percent BiV\r\n"
 					+ "\r\n"
 					+ "Pacing below Threshold, RV Percent Pacing Greater than Limit, BiV Percent Pacing Less than Limit)");
 			
 			
 			//directAlert_MerlinAtHomePage.editAndVerifyAlertCategory("MerlinHome_PercentPacingAlert");
 			List<String> Alertvaluebeforechange=directAlert_MerlinAtHomePage.getAlertValueFromExcelandCompareWithUI("PercentPacingAlert");
 			
 			
 			
 			extentReport.info("1200 V Verify that the Percent Pacing Alerts can be classified (make them disabled).",new String[] {"ClncMgt33112","ClncMgt24130","ClncMgt33113","ClncMgt30914"});
 			directAlert_MerlinAtHomePage.changeAlertClassificationToanyAlert("PercentPacingAlert", "OFF");
 			
 			
 			
 			
 			
 			
 			extentReport.info("1400 V Verify that all the alerts (except for the alert pacing Alerts) have the Inform Patient setting marked as\r\n"
 					+ "\r\n"
 					+ "OFF.", new String[] {"ClncMgt24127","ClncMgt24123","CommUI8463"});
 			directAlert_MerlinAtHomePage.DeselectAllNotifypatient();
 			directAlert_MerlinAtHomePage.selectNotifyPatient("Percent RV pacing greater than");
 			directAlert_MerlinAtHomePage.selectNotifyPatient("Percent BiV pacing less than");
 			directAlert_MerlinAtHomePage.selectNotifyPatient("*RV Percent Pacing Greater Than Limit");
 			directAlert_MerlinAtHomePage.selectNotifyPatient("*BiV Percent Pacing Less Than Limit");
 			
 			
   	}

 		catch (AssertionError e) {
 			extentTest = extentReport.fail( "UC021B WA-CA400/CA500-DirectAlerts-EditDirectAlerts02 is failed due to assertion failure");
 			extentTest.fail("UC021B WA-CA400/CA500-DirectAlerts-EditDirectAlerts02 is failed"+"<br>"+e.getMessage());
 			e.printStackTrace();
 			throw e;
 		}
 			
 		catch (Exception e) {
 			extentTest = extentReport.fail("UC021B WA-CA400/CA500-DirectAlerts-EditDirectAlerts02 is failed due to some exception");
 			extentTest.fail("UC021B WA-CA400/CA500-DirectAlerts-EditDirectAlerts02 is failed"+"<br>"+e.getMessage());
 			e.printStackTrace();
 			throw e;
 			
 		}
 	}

 	    @AfterMethod
 		public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
 			String status = null;
 			String testMethodName = result.getMethod().getMethodName();

 			if (result.getStatus() == ITestResult.SUCCESS) {
 				status = "Success";
 			} else if (result.getStatus() == ITestResult.FAILURE) {
 				status = "Failure";
 			}
 			writeInTextFile(testMethodName, status);
 		}

 	}
 	    

