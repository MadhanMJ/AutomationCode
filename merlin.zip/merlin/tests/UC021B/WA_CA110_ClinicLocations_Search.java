package com.test.qa.ui.tests.UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;

import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.*;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.*;
import com.test.qa.ui.pageObjects.*;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.CommonLibraries;

public class WA_CA110_ClinicLocations_Search extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	CA_ClinicLocationsPage CA_ClinicLocationsPage;
	ClinicianHomeTopNavPage ClinicianHomeTopNavPage;
	CA_ClinicProfilePage ca_clinicProfilePage;
	CA_LeftNavPage ca_leftNavPage;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTransmissionPage;
	CA_ClinicUsers clinicUsersPage;
	Login login_scenario_2;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;

	@BeforeMethod
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		ClinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		CA_ClinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		ca_clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		ca_leftNavPage = new CA_LeftNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		clinicUsersPage=new CA_ClinicUsers(driver, extentReport);
		recentTransmissionPage=new CA_RecentTransmissionsPage(driver, extentReport);
		login_scenario_2= new Login();
		
	}

	// Testcase id: 1244042, Testcase name: WA-CA110-ClinicLocations-Search
	
	@Test
	public void wa_CA110_ClinicLocations_Search() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("Physician_Location");
		login_scenario_2=testDataProvider.getLoginData("Allied_Location");
		customer = testDataProvider.getCustomerData("wa_CA110_ClinicLocations_Search");
		extentTest.assignAuthor("Author - Carmel Vimala");

		try {
			Assertions assertions=new Assertions(extentTest);
			//Physician
			extentReport.info("100 S The actor logs in to the application and is navigated to Clinic Locations page");
			loginPage.login(login,"externaluser");
			assertions.assertEqualsWithReporting(true, recentTransmissionPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
			
			ClinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			//softassert.assertEqualsWithReporting(softassert, softassert, extentReport, areaCode);
			assertions.assertEqualsWithReporting(true, ca_leftNavPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
			ca_leftNavPage.clickClinicUserLink();
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyLandingPage(), extentReport, "Clinic Users page is loaded");
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyUserType(login.getCustomer(),login.getTest()), extentReport, "Type of user is displayed");
			ca_leftNavPage.navigateToClinicLocationsPage();
			assertions.assertEqualsWithReporting(true, CA_ClinicLocationsPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic locations page");
			
			extentReport.info("200 S The actor enters a string in the search field"); 
			CA_ClinicLocationsPage.DeleteLocations(customer.getClinicLocation()); // Delete Locations.
			
			//Add locations
			CA_ClinicLocationsPage.AddAndSearchLocations(customer.getClinicLocation());
			extentReport.reportScreenShot("User is able to enter a string in search field successfully");
			
			extentReport.info("300 V Verify the system performs a search for the Location name column and displays clinic locations that match the partial/Complete string entered in the search field");
			//Complete text search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocation1());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocation1());
			extentReport.reportScreenShot("User is able to verify search results \"" +customer.getSearchLocation1()+ "\" successfully in locations grid");
			
			extentReport.info("400 S Repeat steps 200-300 for different search values entered. (eg: alphanumeric, special characters, numbers, alphabets)");
			//Partial  - Special character search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio2());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio2());
			extentReport.reportScreenShot("User is able to verify search results specialcharacters \"" +customer.getSearchLocatio2()+ "\" successfully in locations grid");
			
			//Partial - Number search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio3());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio3());
			extentReport.reportScreenShot("User is able to verify search results Numeric \"" +customer.getSearchLocatio3()+ "\" successfully in locations grid");
			
			//Partial - Alphabets search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio4());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio4());
			extentReport.reportScreenShot("User is able to verify search results alphabets \"" +customer.getSearchLocatio4()+ "\" successfully in locations grid");
			
			//Partial - Alphanumeric search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio5());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio5());
			extentReport.reportScreenShot("User is able to verify search results alphaNumeric \"" +customer.getSearchLocatio5()+ "\" successfully in locations grid");
			
			//Delete Locations
			CA_ClinicLocationsPage.DeleteLocations(customer.getClinicLocation());
			extentReport.reportScreenShot("Deleting location is successful");
			
			extentReport.pass("Test case ends");
			ClinicianHomeTopNavPage.clickSignOutLink();
			
			//Allied Professional
			extentReport.info("100 S The actor logs in to the application and is navigated to Clinic Locations page");
			loginPage.login(login_scenario_2,"externaluser");
			assertions.assertEqualsWithReporting(true, recentTransmissionPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
			
			ClinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			//softassert.assertEqualsWithReporting(softassert, softassert, extentReport, areaCode);
			assertions.assertEqualsWithReporting(true, ca_leftNavPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
			ca_leftNavPage.clickClinicUserLink();
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyLandingPage(), extentReport, "Clinic Users page is loaded");
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyUserType(login_scenario_2.getCustomer(),login_scenario_2.getTest()), extentReport, "Type of user is displayed");
			ca_leftNavPage.navigateToClinicLocationsPage();
			assertions.assertEqualsWithReporting(true, CA_ClinicLocationsPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic locations page");
			
			extentReport.info("200 S The actor enters a string in the search field"); 
			CA_ClinicLocationsPage.DeleteLocations(customer.getClinicLocation()); // Delete Locations.
			
			//Add locations
			CA_ClinicLocationsPage.AddAndSearchLocations(customer.getClinicLocation());
			extentReport.reportScreenShot("User is able to enter a string in search field successfully");
			
			extentReport.info("300 V Verify the system performs a search for the Location name column and displays clinic locations that match the partial/Complete string entered in the search field");
			//Complete text search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocation1());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocation1());
			extentReport.reportScreenShot("User is able to verify search results \"" +customer.getSearchLocation1()+ "\" successfully in locations grid");
			
			extentReport.info("400 S Repeat steps 200-300 for different search values entered. (eg: alphanumeric, special characters, numbers, alphabets)");
			//Partial  - Special character search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio2());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio2());
			extentReport.reportScreenShot("User is able to verify search results specialcharacters \"" +customer.getSearchLocatio2()+ "\" successfully in locations grid");
			
			//Partial - Number search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio3());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio3());
			extentReport.reportScreenShot("User is able to verify search results Numeric \"" +customer.getSearchLocatio3()+ "\" successfully in locations grid");
			
			//Partial - Alphabets search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio4());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio4());
			extentReport.reportScreenShot("User is able to verify search results alphabets \"" +customer.getSearchLocatio4()+ "\" successfully in locations grid");
			
			//Partial - Alphanumeric search
			CA_ClinicLocationsPage.SearchLocations(customer.getSearchLocatio5());
			CA_ClinicLocationsPage.VerifySearchLocationsfuction(customer.getSearchLocatio5());
			extentReport.reportScreenShot("User is able to verify search results alphaNumeric \"" +customer.getSearchLocatio5()+ "\" successfully in locations grid");
			
			//Delete Locations
			CA_ClinicLocationsPage.DeleteLocations(customer.getClinicLocation());
			extentReport.reportScreenShot("Deleting location is successful");
			
			extentReport.pass("Test case ends");
			assertion.assertAll();
		
		} catch (AssertionError e) {
			 extentReport.reportFail( "WA_CA110_ClinicLocations_Search is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			//extentTest.info("WA_CA110_ClinicLocations_Search is failed"+"<br>");
			/*e.printStackTrace();
			throw e;*/
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "WA_CA110_ClinicLocations_Search is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			//extentTest.info("WA_CA110_ClinicLocations_Search is failed"+"<br>");
			/*e.printStackTrace();
			throw e;*/
			throw e;
		}	
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}
}
