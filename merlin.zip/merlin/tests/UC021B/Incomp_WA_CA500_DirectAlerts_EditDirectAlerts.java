package com.test.qa.ui.tests.UC021B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentBDDReporter;
import com.google.gson.JsonObject;

import com.test.qa.api.helper.AddSecLocationHelper;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBaseTables.UserRecord;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.utilities.CommonUtils;

import io.restassured.response.Response;

/*
 * DirectAlerts for Pacemaker / CRT-P.
 */

public class Incomp_WA_CA500_DirectAlerts_EditDirectAlerts extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	CA_ClinicProfilePage clinicAdministrationProfilePage;
	CA_DirectAlert_Pacemaker_CRTP_Page directAlertPage;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	Login login;
	private String testName;
	private Assertions softAssert;

	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		recentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		clinicAdministrationProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		directAlertPage = new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		
		login = new Login();
		testDataProvider = new TestDataProvider();
	}
	
	private String[] parseTestData(String value) {
		String[] data = value.split("/");
		
		int index = 0;
		for(String s : data) {
			if (s == "null") {
				data[index] = "";
			}
			++index;
		}
		
		return data;
	}
		
	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
	public void wa_CA500_DirectAlerts_EditDirectAlerts(String iteration, 
			String S_1700, String S_1900, String S_2100, String S_2300, String S_2500,
			String OUS_Country, String S_2800, String S_3000, String S_3200, String S_3400, 
			String S_3600, String S_3900, String S_4100, String S_4500, String S_4800, String S_5100, 
			String S_5300, String S_9500) throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName+ "_Iteration_" + iteration);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("SJMClinic");
		
		String[] testDataValues;
		
		try {
			extentTest = extentReport.pass("100-S- The Actor logs into the system and navigates to Direct Alerts settings for Pacemaker/CRT-D page");
			
			loginPage.login(login);
			recentTransmissionsPage.verifyLandingPage();
			extentReport.reportScreenShot("Successfully logged into system");
			
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			clinicAdministrationProfilePage.verifyLandingPage();
			extentReport.reportScreenShot("Successfully navigated to Clinic Admin Profile Page");
			
			clinicAdministrationProfilePage.goToDirectAlertPacemakerCRTP_Page();
			directAlertPage.verifyLandingPage();
			extentReport.reportScreenShot("Successfully navigated to Direct Alert Pacemaker / CRT-P Page");
			
			// TODO: Functionality currently missing in WebApp
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(do verification here)
			// extentTest = extentReport.reportPass("200-V- Verify that on footer of page, there is note regarding software version of transmitter");
			
			extentTest = extentReport.pass("300-S- Click on the Edit button");
			directAlertPage.clickEditButton();
			extentReport.reportScreenShot("Actor clicked on Edit button");
			
			extentTest = extentReport.reportPass("400-V- Verify that the Direct Alerts settings for Pacemaker/CRT-D page is displayed in the Edit mode");
			softAssert = new Assertions(extentTest);
			softAssert.assertEqualsWithReporting(true, directAlertPage.findCancelButton(), extentReport, "Found cancel button in Edit mode");
			softAssert.assertEqualsWithReporting(true, directAlertPage.findSaveButton(), extentReport, "Found save button in Edit mode");
			
			// TODO: Functionality currently missing in WebApp
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(do verification here)
			// extentTest = extentReport.reportPass("500-V- Verify that the following fields are displayed:");
			
			extentTest = extentReport.reportPass("600 V Verify that the Clinic Information section consists of the following contact methods:");
			softAssert = new Assertions(extentTest);
			softAssert.assertEqualsWithReporting(true, directAlertPage.findTextMessageField(), extentReport, "1. Text message");
			softAssert.assertEqualsWithReporting(true, directAlertPage.findPhoneNumberField(), extentReport, "2. Phone");
			softAssert.assertEqualsWithReporting(true, directAlertPage.findEmailField(), extentReport, "3. Email");
			softAssert.assertEqualsWithReporting(true, directAlertPage.findFaxField(), extentReport, "4. Fax");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("700 V Verify that an instructional text about the Alert transmissions to indicate that all alerts will be displayed in the list of transmissions is displayed in the footer");
			
			// TODO: 800 V Figure out how to obtain info message
			// extentTest = extentReport.reportPass("800 V Verify that an instructional text about the On Call Physician to indicate that the On-call physician is always a member of the Medical team");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(true, directAlertPage.findPhysicianInfoMessage(), extentReport, "Found On-call Physician instructional text");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.pass("900-S- Select Fax as the Contact method for Urgent Alerts notification during office hours");
			// extentTest = extentReport.pass("1000-S- Click on Save button leaving the Fax field in the Clinic Contact information section blank");
			// extentTest = extentReport.pass("1100-S- Click OK on the confirmation dialog that appears");
			// extentTest = extentReport.reportPass("1200-V- Verify that the page does not get saved with the changes and a message CS 818 stating that the Fax field requires to filled in is displayed");
			
			// TODO: Functionality currently missing in WebApp
			//extentTest = extentReport.pass("1300-S- Select SMS as the Contact method for Urgent Alerts notification during office hours");
			//extentTest = extentReport.pass("1400-S- Click on Save button leaving the SMS field in the Clinic Contact information section blank");
			//extentTest = extentReport.pass("1500-S- Click OK on the confirmation dialog that appears");
			//extentTest = extentReport.pass("1600-V- Verify that the page does not get saved with the changes and a message CS 818 stating that the Text Message field requires to filled in is displayed");
			
			/*
			 *  Phone
			 */
			
			// set to US clinic
			
			// TODO: Clinic profile save functionality currently missing in WebApp
			extentTest = extentReport.pass("1700-S- The actor submits an incomplete Phone Number Complex. Enter 1 (empty area city code) 1234567 (Ensure that the clinic is a US Clinic)");
			
			// Navigate to profile page and set US clinic
			directAlertPage.clickCancelButton();
			directAlertPage.goToClinicProfilePage();
			clinicAdministrationProfilePage.verifyLandingPage();
			clinicAdministrationProfilePage.clickEditButton();
			clinicAdministrationProfilePage.fillCountryFromDropdown("USA");
			// clinicAdministrationProfilePage.clickSaveButton();
			extentReport.reportScreenShot("Changed clinic location to USA");
			
			testDataValues = parseTestData(S_1700);
			
			// Navigate back to Direct Alerts page and fill values in Edit mode
			clinicAdministrationProfilePage.goToDirectAlertPacemakerCRTP_Page();
			directAlertPage.verifyLandingPage();
			directAlertPage.clickEditButton();
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted test data with incomplete Phone Number Complex");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("1800-V- The system displays message CS 816");
			// validate US clinic
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 *  Phone Number Country Code
			 */
			
			testDataValues = parseTestData(S_1900);
			
			extentTest = extentReport.pass("1900-S The actor enters an invalid Country Code which uses alphabetic characters, which has less than 3 or more than 1 digits, then clicks Save button");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted test data 1 with invalid Country Code");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("2000-V- (Invalid input 1) Verify that the system displays message CS 816");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 *  Phone Number City Area Code
			 */
			
			testDataValues = parseTestData(S_2100);
			
			extentTest = extentReport.pass("2100-S- The actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted test data 1 with invalid Area-City Code");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("2200-V- (Invalid input 1) Verify that the system displays message CS 816");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 *  Phone Number for US / Canada
			 */
			
			testDataValues = parseTestData(S_2300);
			
			extentTest = extentReport.pass("2300-S- (Invalid input 1) The actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks Save button");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted test data 1 with invalid Phone Number");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("2400-V- (Invalid input 1) The system displays message CS 816");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 * Phone Number Country Code should be 1 to 3 numeric digits.
			 * Phone Number Area-City Code should be 3 numeric digits if the associated phone number country code corresponds to the US
			 * Phone Number should be 7 numeric digits if the associated phone number country code corresponds to the US
			 * Canada has same country code and will be validated the same as the US
			 * '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - space should be 
			 * accepted as additional entry values but should be removed upon save and not re-displayed
			 */
			
			testDataValues = parseTestData(S_2500);
			
			extentTest = extentReport.pass("2500-S- The actor enters a valid Phone Number Complex, which has 1 numerical digit for country code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks corresponding button (see parent test case) to submit the form to the system for validation");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted valid Phone Number");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("2600-V- Verify that the system saves the value and message CP 803 is displayed");
			// softAssert = new Assertions(extentTest);
			// perform DB validation
			// softAssert.assertEqualsWithReporting(conditions);
			
			// TODO: Clinic profile save functionality currently missing in WebApp
			extentTest = extentReport.pass("2700-S Ensure that the clinic country is a OUS country");
			
			// Navigate to profile page and set OUS clinic
			directAlertPage.clickCancelButton();
			directAlertPage.goToClinicProfilePage();
			clinicAdministrationProfilePage.verifyLandingPage();
			clinicAdministrationProfilePage.clickEditButton();
			clinicAdministrationProfilePage.fillCountryFromDropdown(OUS_Country);
			// clinicAdministrationProfilePage.clickSaveButton();
			extentReport.reportScreenShot("Changed clinic location to OUS country");
			
			testDataValues = parseTestData(S_2800);
			
			extentTest = extentReport.pass("2800-S- The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks save button");
						
			// Navigate back to Direct Alerts page
			clinicAdministrationProfilePage.goToDirectAlertPacemakerCRTP_Page();
			directAlertPage.verifyLandingPage();
			directAlertPage.clickEditButton();
			
			// Fill values in Edit mode
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted test data 1 with invalid Phone Number Complex");
			
			// TODO: Functionality currently missing in WebApp
//			extentTest = extentReport.reportPass("2900-V- (Invalid input 1) Verify that the system displays message CS 816");
//			softAssert = new Assertions(extentTest);
//			softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 *  Additonal validation
			 */
			
			testDataValues = parseTestData(S_3000);
			
			extentTest = extentReport.pass("3000-S- The Actor enters a Phone Number Complex that is not complete then clicks Save button.");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted test data 1 with incomplete Phone Number Complex");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("3100-V- (Invalid input 1) The system displays message CS 818");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 * Phone Number Country Code should be 1 to 3 numeric digits.
			 * Phone Number Area-City Code should be 0-5 digits (not mandatory field for OUS)
			 * Phone Number should be 3-12 numeric digits
			 * '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - space should be 
			 * accepted as additional entry values but should be removed upon save and not re-displayed
			 */
			
			testDataValues = parseTestData(S_3200);
			
			extentTest = extentReport.pass("3200-S- The Actor enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted valid Phone Number Complex");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.reportPass("3300-V- The system should save the value and message CP 803 is displayed");
			// softAssert = new Assertions(extentTest);
			// perform field display validation
			// softAssert.assertEqualsWithReporting(conditions);
			// perform DB validation
			// softAssert.assertEqualsWithReporting(conditions);

			testDataValues = parseTestData(S_3400);
			
			extentTest = extentReport.pass("3400-S- The Actor enters a Fax Complex that is not complete then clicks Save button.");
			
			directAlertPage.fillFaxNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted invalid Fax Number Complex");
			
			// TODO: Functionality currently missing in WebApp
			//extentTest = extentReport.reportPass("3500-V- The system displays message CS 818");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);

			testDataValues = parseTestData(S_3600);
			
			extentTest = extentReport.pass("3600-S- The Actor enters a valid Fax Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Fax; then clicks Save button");
			directAlertPage.fillFaxNumberWithCodes(testDataValues[0], testDataValues[1], testDataValues[2]);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted valid Fax Number Complex");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.pass("3700-V- The system should save the value and message CP 803 is displayed");
			// softAssert = new Assertions(extentTest);
			// perform field display validation
			// softAssert.assertEqualsWithReporting(conditions);
			// perform DB validation
			// softAssert.assertEqualsWithReporting(conditions);
			
			/*
			 * Text message
			 * 1-100 alphanumberic characters (A-Z a-z 0-9).
			 * Must contain @ and "."
			 * May also contain the following characters: " ^_%+-\$" In the following syntax: " ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$
			 */
			
			// extentTest = extentReport.pass("3800 S Click on Edit button");
			// directAlertPage.clickEditButton();
			// extentReport.reportScreenShot("Successfully clicked Edit button");
			
			// (Input 1) Test with invalid input: johns.ibm.com
			
			extentTest = extentReport.pass("3900 S Enter the following invalid values in the Text Message field and clicks on Save button");
			directAlertPage.fillTextMessage(S_3900);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted invalid Text Message");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.pass("4000 V (Input 1) Verify that message CS 816 is displayed");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			// Test with valid input: john@abc.com
			
			extentTest = extentReport.pass("4100 S Actor enters valid data in Text Message field and clicks on Save button");
			directAlertPage.fillTextMessage(S_4100);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully submitted valid Text Message");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.pass("4200 V Verify that the system saves the value and message CP 803 is displayed");
			// softAssert = new Assertions(extentTest);
			// perform field display validation
			// softAssert.assertEqualsWithReporting(conditions);
			// perform DB validation
			// softAssert.assertEqualsWithReporting(conditions);
			
			//extentTest = extentReport.pass("4300 V Verify that the page is now displayed in View mode");
			//softAssert = new Assertions(extentTest);
			//softAssert.assertEqualsWithReporting(true, directAlertPage.findEditButton(), extentReport, "Found Edit button in View mode");
			
			/*
			 * Email
			 */
			
			// extentTest = extentReport.pass("4400 S Click on Edit button");
			// directAlertPage.clickEditButton();
			// extentReport.reportScreenShot("Successfully clicked Edit Button");
			
			// (Input 1) Test with invalid input which does not contain "@": johns.ibm.com
			
			extentTest = extentReport.pass("4500-S- Enter an invalid email address in this field. Test the following invalid entries:");
			directAlertPage.fillEmail(S_4500);
			extentReport.reportScreenShot("Successfully entered invalid email address");
			
			//extentTest = extentReport.pass("4600-S- Click on the Save button and OK on the confirmation dialog that appears");
			directAlertPage.clickSaveButton();
			// confirmation dialog
			extentReport.reportScreenShot("Successfully clicked Save button");
			
			// TODO: Functionality currently missing in WebApp
			// extentTest = extentReport.pass("4700-V Verify that message CS 816 is displayed");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(conditions);
			
			//extentTest = extentReport.pass("4800 S The actor enters an invalid email with 101 characters in the Email Address field, which contains "@" and '.'");
			directAlertPage.fillEmail(S_4800);
			extentReport.reportScreenShot("Successfully entered invalid email address with 101 characters");
			
			//extentTest = extentReport.pass("4900-S- Click on the Save button and OK on the confirmation dialog that appears");
			directAlertPage.clickSaveButton();
			// confirmation dialog
			extentReport.reportScreenShot("Successfully clicked Save button");
			
			//extentTest = extentReport.pass("5000 V Verify that system is not accepting 101 chars and display 100 chars in view mode ");
			// softAssert = new Assertions(extentTest);
			// check that not saved
			// viewport validation
			// String emailFieldValue = directAlertPage.getEmailFieldValue();
			// softAssert.assertEqualsWithReporting(100, emailFieldValue.length(), extentReport, "Email field displays 100 characters in view mode");
			
			extentTest = extentReport.pass("5100 S Enter a valid email ID. Click on the Cancel button");
			directAlertPage.fillEmail(S_5100);
			directAlertPage.clickCancelButton();
			extentReport.reportScreenShot("Successfully entered valid email and clicked Cancel button");
			
			//extentTest = extentReport.reportPass("5200 V Verify that the email field contains the value entered in step 4800");
			// softAssert = new Assertions(extentTest);
			// softAssert.assertEqualsWithReporting(emailFieldValue, directAlertPage.getEmailFieldValue(), extentReport, "Email field contains value from 4800 S");
			
			extentTest = extentReport.pass("5300-S- Enter a valid email ID. Click on the Save button and OK on the confirmation dialog that appears");
			directAlertPage.clickEditButton();
			directAlertPage.fillEmail(S_5300);
			directAlertPage.clickSaveButton();
			extentReport.reportScreenShot("Successfully entered valid email and clicked Save Button");
			
			//extentTest = extentReport.pass("5400-V- Verify that a message stating that the changes have been successfully made is displayed");
			// softAssert = new Assertions(extentTest);
			// perform field display validation
			// softAssert.assertEqualsWithReporting(conditions);
			// perform DB validation
			// softAssert.assertEqualsWithReporting(conditions);
			
			// TODO: On Call Physician dropdown toggle not yet implemented in WebApp
			
			/*
			 * Phone - On Call Physician
			 */
			
			//extentTest = extentReport.pass("5500-S- Click the Edit button on the page");
			//extentTest = extentReport.pass("5600-S- Check On call Physician contact field has");
			//extentTest = extentReport.pass("5700-S- The actor submits an incomplete Phone Number Complex for on-call physician after selecting Phone from the dropdown. Enter 1 (empty area city code) 1234567 (Ensure that the clinic is a US Clinic)");
			//extentTest = extentReport.pass("5800-V- The system displays message CS 816");
			//extentTest = extentReport.pass("5900-S The Actor The actor enters an invalid Country Code which uses alphabetic characters, which has less than 3 or more than 1 digits, then clicks Save button");
			//extentTest = extentReport.pass("6000-V-Verify that the system displays message CS 816");
			//extentTest = extentReport.pass("6100-S- The actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button. Test each following invalid inputs:");
			//extentTest = extentReport.pass("6200-V-Verify that the system displays message CS 816");
			//extentTest = extentReport.pass("6300-S- The actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks Save button");
			//extentTest = extentReport.pass("6400-V- The system displays message CS 816");
			//extentTest = extentReport.pass("6500-S-The actor enters a valid Phone Number Complex; then clicks corresponding button (see parent test case) to submit the form to the system for validation");
			//extentTest = extentReport.pass("6600-V-Verify that the system saves the value and message CP 803 is displayed");
			//extentTest = extentReport.pass("6700-S Ensure that the clinic country is a OUS country");
			//extentTest = extentReport.pass("6800-S- The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks save button");
			//extentTest = extentReport.pass("6900-V-Verify that the system displays message CS 816");
			//extentTest = extentReport.pass("7000-S- The Actor enters a Phone Number Complex that is not complete then clicks Save button. Test each following invalid inputs");
			//extentTest = extentReport.pass("7200-S-The Actor enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button");
			//extentTest = extentReport.pass("7300-V- The system should save the value and message CP 803 is displayed");
			//extentTest = extentReport.pass("7400-S- The actor selects Fax from the On-Call Physician dropdown. The Actor enters a Fax Complex that is not complete then clicks Save button. Test each following invalid inputs:");
			//extentTest = extentReport.pass("7500-V- The system displays message CS 818 ");
			//extentTest = extentReport.pass("7600-S-The Actor enters a valid Fax Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Fax; then clicks Save button");
			//extentTest = extentReport.pass("7700-V- The system should save the value and message CP 803 is displayed");
			//extentTest = extentReport.pass("7800 S Click on Edit button");
			//extentTest = extentReport.pass("7900 S Select Text Message from the On-Call Physician dropdown. Enter the following invalid values in the Text Message field and clicks on Save button)");
			//extentTest = extentReport.pass("8000 V Verify that message CS 816 is displayed");
			//extentTest = extentReport.pass("8100 S Actor enters valid data in Text Message field (e.g:john@abc.com) and clicks on Save button");
			//extentTest = extentReport.pass("8200 V Verify that the system saves the value and message CP 803 is displayed");
			//extentTest = extentReport.pass("8300 V Verify that the page is now displayed in View mode");
			//extentTest = extentReport.pass("8400 S Click on Edit button");
			//extentTest = extentReport.pass("8500-S- Select E-mail from the On-Call Physician dropdown. Enter an invalid email address in this field. Test the following invalid entries:");
			//extentTest = extentReport.pass("8600-S- Click on the Save button and OK on the confirmation dialog that appears");
			//extentTest = extentReport.pass("8700-S Verify that message CS 816 is displayed");
			//extentTest = extentReport.pass("8800 S The actor enters an invalid email with 101 characters in the Email Address field, which contains "@" and '.'");
			//extentTest = extentReport.pass("8900-S- Click on the Save button and OK on the confirmation dialog that appears");
			//extentTest = extentReport.pass("9000 V Verify that system is not accepting 101 chars and display 100 chars in view mode");
			//extentTest = extentReport.pass("9100 S Enter a valid email ID. Click on the Cancel button");
			//extentTest = extentReport.pass("9200 V Verify that the email field contains the value entered in step 8800");
			//extentTest = extentReport.pass("9300-S- Enter a valid email ID. Click on the Save button and OK on the confirmation dialog that appears");
			//extentTest = extentReport.pass("9400-V- Verify that a message stating that the changes have been successfully made is displayed");
			
			// TODO: Stubs
			
			testDataValues = parseTestData(S_9500);

			String phoneNumber = testDataValues[2];
			extentTest = extentReport.pass("9500-S- Change the Phone number in the Clinic Contact Information section");
			directAlertPage.fillPhoneNumberWithCodes(testDataValues[0], testDataValues[1], phoneNumber);
			extentReport.reportScreenShot("Successfully changed Phone number in Clinic Contact Information section");
			
			// TODO: Functionality not implemented in WebApp
			// extentTest = extentReport.pass("9600-S- Click any link on the page");
			// directAlertPage.goToClinicProfilePage();
			// extentReport.reportScreenShot("Clicked on link to navigate to Clinic Profile Page without saving");
			
			// TODO: Functionality not implemented in WebApp
			//extentTest = extentReport.pass("9700-V- Verify that browser specific confirmation message is displayed");
			
			// TODO: Functionality not implemented in WebApp
			//extentTest = extentReport.pass("9800 S- Click Cancel on this dialog");
			
			extentTest = extentReport.reportPass("9900-V- Verify that the Direct Alert settings page is now displayed again with the unsaved data in the Phone number field");
			softAssert = new Assertions(extentTest);
			softAssert.assertEqualsWithReporting(true, directAlertPage.verifyLandingPage(), extentReport, "Direct Alert settings page is displayed");
			softAssert.assertEqualsWithReporting(phoneNumber, directAlertPage.getPhoneNumberFieldValue(), extentReport, "Unsaved data in Phone number field matches entered value");
			
			extentTest = extentReport.pass("10000-S- Click on the Show Devices button");
			directAlertPage.clickShowDevicesButton();
			extentReport.reportScreenShot("Successfully clicked on Show Devices button");
			
			// TODO: Show Devices functionality yet to be implemented
			//extentTest = extentReport.pass("10100-V- Verify that a modal window with the list of devices supported by the clinic is displayed");
			
			extentTest = extentReport.pass("10200-S- Click the Close button");
			directAlertPage.clickShowDevicesCloseButton();
			extentReport.reportScreenShot("Successfully clicked on Show Devices Close button");
			
			extentTest = extentReport.pass("10300 S Click on a tab on the left (secondary) nav panel");
			directAlertPage.goToClinicProfilePage();
			extentReport.reportScreenShot("Clicked Clinic Profile tab on left secondary nav panel");
			
			extentTest = extentReport.reportPass("10400 V Verify that the page that is selected is displayed");
			softAssert = new Assertions(extentTest);
			softAssert.assertEqualsWithReporting(true, clinicAdministrationProfilePage.verifyLandingPage(), extentReport, "Selected Clinic Profile page from left secondary nav panel is displayed");
			
			// TODO: Figure out how to scroll to top / why I can't find this element
//			extentTest = extentReport.pass("10500 S Click on a link on the primary nav panel");
//			clinicAdministrationProfilePage.scrollUp();
//			clinicAdministrationProfilePage.goToRecentTransmissionsPage();
//			extentReport.reportScreenShot("Clicked on Recent Transmissions primary nav panel link");
//			
//			extentTest = extentReport.pass("10600 V Verify that the page that is selected is displayed");
//			softAssert = new Assertions(extentTest);
//			softAssert.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmissions page is correctly displayed");
			
			extentTest = extentReport.pass("10700 S Navigate back to Direct Alerts settings for Pacemaker/CRT-D page");
			//recentTransmissionsPage.goToClinicAdministrationProfilePage();
			clinicAdministrationProfilePage.goToDirectAlertPacemakerCRTP_Page();
			extentReport.reportScreenShot("Successfully navigated back to Direct Alerts page for Pacemaker / CRT-D");
			
		} catch (AssertionError e) {
			extentReport.reportFail("Assertion failed for CA500 Edit Direct Alerts for Pacemaker / CRT-P");
			throw e;
		} catch (Exception e) {
			extentReport.fail("Exception thrown for CA500 Edit Direct Alerts for Pacemaker / CRT-P");
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		copySaintsEvidences(currentMethod);

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
	
}