package com.test.qa.ui.tests.CST;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfile_Transmitter;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientSummaryPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class SnapshotReport_CST extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_ClinicProfilePage ca_clinicProfilePage;
	CA_LeftNavPage ca_leftNavPage;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	CustomerListPage customerListPage;
	CA_ClinicUsers clinicUsersPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	PL_TopNavPage pl_TopNavPage;
	PL_PatientSummaryPage pl_PatientSummaryPage;
	PL_PatientProfile_Transmitter patientProfileTransmitter;
	PL_PatientProfile_LeftNavPage patientProfileLefNav;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		ca_leftNavPage = new CA_LeftNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		customerListPage = new CustomerListPage(driver, extentReport);
		clinicUsersPage=new CA_ClinicUsers(driver, extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		pl_PatientSummaryPage = new PL_PatientSummaryPage(driver,extentReport);
		patientProfileTransmitter=new PL_PatientProfile_Transmitter(driver, extentReport);
		patientProfileLefNav= new PL_PatientProfile_LeftNavPage(driver,extentReport);
		
	}
	
	@Test(groups= {"Regression"})
	public void snapshotReport_CST() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("DirectAll");
		extentTest.assignAuthor("Author - Shanmugapriya");
		try {
			Assertions assertions=new Assertions(extentTest);
            //clicking clinicLocation page in clinicAdministration tab			
			extentReport.info("100S Navigate to patient profile as per test set-up 1.");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier1 filter");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier2 filter");
			patientListPage.enterTier3FilterInputBx("Enrollbackwithdevice1");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickonPatientNameFrmList();
//			patientListPage.clickonAllTransmissionFrmList("Enrollbackwithdevice1");
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"All Transmissions Page is displayed");
			extentReport.reportScreenShot("User is able to navigate patient profile page");
			
			extentReport.info("200S Verify that the snapshot report is available on the secondary navigation tab.", new String[] {"Transmgt18763"});
			patientProfileLefNav.navigateToTransmitter();
			String appRegistrationDate = patientProfileTransmitter.patientAppRegistrationDate();
			assertion.assertEqualsWithReporting(true,pl_TopNavPage.verifyPatientSummaryTab(),extentReport,"Patient Summary tab is available");
			extentReport.reportScreenShot("User is able to navigate patient profile page");

			extentReport.info("300V Verify that the Patient summary report' title is displayed on the top of the snapshot report page work area");
			pl_TopNavPage.navigateToPatientSummary();
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyPatientSummaryTitle(),extentReport,"Patient Summary Page title is displayed");
			extentReport.reportScreenShot("Patient Summary Report title is displayed in the snapshot report page");
			
			extentReport.info("400V Verify that the from and to date selector fields are displaying the default snapshot report dates.");
			//need to check
			//get the last billed date and verify it is same as from date.
			//if last billed date is not there the date which is there in UI is default date.
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDefaultFromDate(appRegistrationDate),extentReport,"From and To date selector fields are displaying the dafulat date");
			extentReport.reportScreenShot("From and to date selector fields are displaying the default snapshot report dates");
			
			extentReport.info("500S Enter valid dates that are different from the default dates, one date via the date selector and another by typing manually within the date field.");
			//need to check
			String selectedFromDate = pl_PatientSummaryPage.selectingDateFromCalendar();
			String toDate = pl_PatientSummaryPage.enteringToDate("02/14/2022");
			extentReport.reportScreenShot("User is able to enter the from and to dates");	
			
			extentReport.info("600V Verify that the apply button is displayed and active upon changing the to dates and inactive after clicking on apply to save the changes.", new String[] {"Transmgt18767"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyApplyButton(),extentReport,"Apply button  in Patient Summary Page is Enabled");
			extentReport.reportScreenShot("Apply button  in Patient Summary Page is Enabled");
			pl_PatientSummaryPage.clickApplyButton();
			assertion.assertEqualsWithReporting(false,pl_PatientSummaryPage.verifyApplyButton(),extentReport,"Apply button  in Patient Summary Page is Disabled");
			extentReport.reportScreenShot("Apply button  in Patient Summary Page is Disabled");
			
			extentReport.info("700V Verify that the user entered dates are displayed in the date fields", new String[] {"Transmgt18744","Transmgt18640"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifySelectedFromDate(),extentReport,"User clicked From Date is displayed");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifySelectedToDate(toDate),extentReport,"User entered To Date is displayed");
			extentReport.reportScreenShot("User entered values are displayed");
			
			extentReport.info("800V Verify that the date range drop down is displayed and functional by clicking and selecting an option from the drop down arrow.", new String[] {"Transmgt18767"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.selectDateRange("1 week"),extentReport,"User is selecting the option");
			extentReport.reportScreenShot("Date range drop down is displayed and able to select the option from drop down");
			
			extentReport.info("900V Verify that the user selected period is updated in the snapshot report date fields", new String[] {"Transmgt18744"});
			// 1 week=7days
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDateRange("7"),extentReport,"Selected period is updated");
			extentReport.reportScreenShot("User selected period is updated in the snapshot report date fields");
			
			extentReport.info("1000V Verify that the print button is displayed and upon selecting the print button a PDF report is generated with the following:"
					+ "Cover page"
					+ "Snapshot report with episodes counts, AF burden Daily percentage trend, and remote transmissions list"
					+ "Episodes list"
					+ "FastPath summary report from the most recent remote transmission", new String[] {"Transmgt18851"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyPrintButton(),extentReport,"Print button is displayed");
			extentReport.reportScreenShot("Print Button is displayed");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyPDFReport(),extentReport,"PDF contains Cover page, Episodes counts, Remote transmissions list, Episodes list");
			
			extentReport.info("1100V Verify that the transmission summary section is displayed on the work area of the snapshot report with the section title - \"Transmission Summary\"", new String[] {"Transmgt18924"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyTransmissionSummary(),extentReport,"Transmission summary section is displayed");
			extentReport.reportScreenShot("Transmission summary section is displayed on the work area of the snapshot report");
			
			extentReport.info("1200V Verify that the sub sections episodes counts and remote transmissions are displayed within the transmissions summary section", new String[] {"Transmgt19135", "Transmgt19136","Transmgt19133"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyEpisodesCount(),extentReport,"Episodes counts are displayed");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyRemoteTransmissions(),extentReport,"Remote Transmissions section is displayed");
			extentReport.reportScreenShot("Sub sections episodes counts and remote transmissions are displayed");
			
			extentReport.info("1300V Verify that the episodes counts sub section lists out 6 kinds of episode names with corresponding counts for the current report period and since enrollment to merlin.net", new String[] {"Transmgt19135", "Transmgt19136"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifySubSectionEpisodesCount(),extentReport,"Episodes counts are matched");
			extentReport.reportScreenShot("Episodes counts sub section lists out 6 kinds of episode names with corresponding counts for the current report period and since enrollment to merlin.net");
			
			extentReport.info("1400V Verify that the Remote transmissions section list 3 kinds of remote transmissions with their corresponding counts", new String[] {"Transmgt19133"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyRemoteTransmissionsSection(),extentReport,"Remote Transmission sections are displayed");
			extentReport.reportScreenShot("Remote transmissions section lists 3 kinds of remote transmissions with their corresponding counts");
			
			extentReport.info("1500V Verify that the AF burden section is displayed below the transmission summary section with the section titled \"AF burden(12months)\"", new String[] {"Transmgt18751"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyAFBurden(),extentReport,"AFBurden sections is displayed");
			extentReport.reportScreenShot("AF burden section is displayed below the transmission summary section");
			
			extentReport.info("1600V Verify that the AF burden start and end dates are displayed in the sub-title section", new String[] {"Transmgt18779"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyAFFromAndToDate(),extentReport,"AF from and end dates are displayed");
			extentReport.reportScreenShot("AF burden start and end dates are displayed in the sub-title section");
			
			extentReport.info("1700V Verify that the AF burden plot x-axis is divided into 12 months,  the first tick mark corresponding to the month end of the AF burden start date and y - axis into 5 quarterly percentiles from 0 to 100.");
			//need to check
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyXAxis(),extentReport,"AF burden plot x-axis is divided into 12 months");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyYAxis(),extentReport,"y - axis into 5 quarterly percentiles from 0 to 100");
			extentReport.reportScreenShot("AF burden plot x-axis is divided into 12 months and y - axis into 5 quarterly percentiles from 0 to 100.");
			
			extentReport.info("1800V Verify that vertical lines are displayed on the plot for each day for which the patient has an AF burden percentage value.", new String[] {"Transmgt18751","Transmgt18778"});
			//need to check
			
			extentReport.info("1900V Verify that a foot note is displayed at the bottom of the AF burden section specifying that - 120 days gap in between two transmissions will result in a gap. ");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyFootNote("120 days gap in between two transmissions will result in a gap"),extentReport,"Foot note is displayed at the bottom of the AF burden section");
			extentReport.reportScreenShot("Foot note is displayed at the bottom of the AF burden section specifying that - 120 days gap in between two transmissions will result in a gap.");
			
			extentReport.info("2000V Verify that the marked for billing section is displayed at the bottom of the snapshot report page.", new String[] {"Transmgt18771"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyBillingsection(),extentReport,"Billing Section is displayed at the bottom of the snapshot report page");
			extentReport.reportScreenShot("Billing section is displayed at the bottom of the snapshot report page.");
			
			extentReport.info("2100V Verify that the check box is displayed adjacent to the \"marked as billed\" date selector.");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyMarkedAsBilledCheckbox(),extentReport,"Check box for Mark as Billed is displayed");
			extentReport.reportScreenShot("Check Box is displayed for Marked as billed date selector");
			
			extentReport.info("2200V Click on the check box and verify that the current date is displayed on the date selector", new String[] {"Transmgt18753"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyMarkedAsBilledDate(),extentReport,"Mark as Billed is displaying current system date");
			extentReport.reportScreenShot("Current date is displayed on the date selector");
			
			extentReport.info("2300V Verify that the options save and cancel are displayed at the bottom right hand corner of the page upon selecting the check box.");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifySaveAndCancelButton(),extentReport,"Save and Cancal button are displayed");
			extentReport.reportScreenShot("User is able to see save and cancel are displayed at the bottom right hand corner of the page");
			
			extentReport.info("2400V Select cancel button and verify that the current systemdate displayed in the mark as  billed date field is not saved.");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyBilledDateAfterClickingCancel(),extentReport,"Current system date displayed is not saved");
			extentReport.reportScreenShot("User is able to see current system date displayed in the mark as  billed date field is not saved.");
			
			extentReport.info("2500S Select the check box again and manually enter an invalid date in the mark as billed date field and select save.");
			pl_PatientSummaryPage.enterInvalidDateInMarkedAsBilled("14/10/2022");
			extentReport.reportScreenShot("User is able to manually enter an invalid date in the mark as billed date field and select save");
			
			extentReport.info("2600V Verify that the system displays an error message on top of the report page.");
			//defect
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyErrorMessage(),extentReport,"Error message is displayed on top of the report page.");
			extentReport.reportScreenShot("User is able to see the system displays an error message on top of the report page.");
			
			extentReport.info("2700V Verify that the mark as billed on date field is highlighted in red indicating an error.");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyMarkedAsBilledHighlighted(),extentReport,"Mark as billed on date field is highlighted in red");
			extentReport.reportScreenShot("User is able to see mark as billed on date field is highlighted in red");
			
			extentReport.info("2800S select the date selector grid and select a valid billing date for the patient. Select save.");
			pl_PatientSummaryPage.selectValidDateInBilledDate();
			extentReport.reportScreenShot("User is able to select valid billing date");
			
			extentReport.info("2900V Verify that the date selected is displayed in the last billed date field");
			//defect
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDateInLastBilledDate(),extentReport,"Date selected is displayed in the last billed date field");
			extentReport.reportScreenShot("User is able to see the date selected is displayed in the last billed date field");
			
			extentReport.info("3000S Verify that the question mark help icon is displayed and the help text is displayed on the pop up dialogue box upon hovering on the icon.");
			//defect
			extentReport.reportScreenShot("User is able to see question mark help icon is displayed");
			
			extentReport.info("3100S Verify that the next billable date field is displayed and populated with the last billed date + 31/91 days based on the clinic's report settings ", new String[] {"Transmgt18771"});
			//defect
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyNextBillableDate("31"),extentReport,"Date selected is displayed in the last billed date field");
			extentReport.reportScreenShot("User is able to see the date selected is displayed in the last billed date field");
			
			extentReport.info("3200V Verify that the Next transmission date field is highlighted in red and, a note is displayed that there is \"no next transmission date or the next transmission date is before the next billable date.\"", new String[] {"Transmgt18776","Transmgt18771"});
			//dummy xpath
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyNextTranmissionHighlighted("next transmission is before the next billable date"),extentReport,"Next transmission date field is highlighted in red and, a note is displayed");
			extentReport.reportScreenShot("User is able to see Next transmission date field is highlighted in red and, a note is displayed");
			
			extentReport.info("3300V Verify that a note with a schedule hyperlink to schedule a future follow-up transmission is displayed.");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyScheduleLink(),extentReport,"Schedule hyperlink is displayed");
			extentReport.reportScreenShot("User is able to see schedule hyperlink to schedule a future follow-up transmission is displayed");
			
			extentReport.info("3400S Click on the schedule hyperlink and pick an invalid date and save the date");
			pl_PatientSummaryPage.clickScheduleLinkAndInvalidDate();
			extentReport.reportScreenShot("User is able to click on the schedule hyperlink and pick an invalid date and save the date");
			
			extentReport.info("3500V Verify that the date is not saved.");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDataNotSaved(),extentReport,"Data is not saved");
			extentReport.reportScreenShot("User is able to see data is not saved");
			
			extentReport.info("3600S Select a date before the next billable date.");
			pl_PatientSummaryPage.selectDayBeforeNextBilledDate();
			extentReport.reportScreenShot("User is able to select a date before the next Billable date");
			
			extentReport.info("3700V Verify that the date is saved but the next transmission field is highlighted in red and, the note specifying that the next transmission is before the next billable date is displayed below the schedule hyperlink text", new String[] {"Transmgt18776"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyNextTransmission(),extentReport,"Next transmission field is highlighted in red");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyScheduleNote(),extentReport,"Note specifying that the next transmission is before the next billable date is displayed below the schedule hyperlink text");
			extentReport.reportScreenShot("User is able to see next transmission field is highlighted in red and, the note specifying that the next transmission is before the next billable date is displayed below the schedule hyperlink text");
			
			extentReport.info("3800S Select a date after the next billable date.");
			pl_PatientSummaryPage.selectDayAfterNextBilledDate();
			extentReport.reportScreenShot("User is able to select a date after the next billable date.");
			
			
			extentReport.info("3900V Verify that the date is updated in the next transmission date field, the field is no longer highlighted and the note is no longer displayed", new String[] {"Transmgt18876"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyNextTransmissionAfterNextBilledDate(),extentReport,"Date is updated in the next transmission date field");
			assertion.assertEqualsWithReporting(false,pl_PatientSummaryPage.verifyScheduleNote(),extentReport,"Note is not displayed");
			assertion.assertAll();
			
			
		}catch (AssertionError e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}

	


