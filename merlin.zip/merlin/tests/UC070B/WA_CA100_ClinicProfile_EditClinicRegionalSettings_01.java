package com.test.qa.ui.tests.UC070B;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/***********************************************************************************/
//Saints Id :  1244398
//Test Case :  WA_CA100_ClinicProfile_EditClinicRegionalSettings_01
//Author    : Jeetendra Gupta
/***********************************************************************************/

public class WA_CA100_ClinicProfile_EditClinicRegionalSettings_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withoutICDDevice;
	ClinicianHomeTopNavPage appHomeTopNavPage;
	CA_LeftNavPage LeftNavPage;
	CA_ClinicProfilePage profilepage;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		appHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		LeftNavPage = new CA_LeftNavPage(driver, extentReport);
		profilepage = new CA_ClinicProfilePage(driver, extentReport);
	}

	@Test
	public void ClinicProfile_EditClinicRegionalSettings() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("JitClinic1");		
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Jeetendra Gupta");// comments
		try {
			Assertions assertion = new Assertions(extentTest);			
			/************************************************************************************/
			extentReport.info("100-S- The Actor logs in to the system and navigates to Clinic Profile page.");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			appHomeTopNavPage.clickClinicAdministrationLink();
			/************************************************************************************/
			extentReport.info("200-S- Click the Edit button on the page.");
			profilepage.clickEditButton();
			profilepage.clickCancelButton();
			profilepage.alertclickCancelButton();
			profilepage.verifylangugagedropdownvalue();
			profilepage.verifynumberformat();
			/************************************************************************************/
			extentReport.info(
					"300-V- Verify that the page is now displayed in edit mode and the Clinic preferences are editable. <ClncMgt238><ClncMgt26380><CommUI7680>");

			profilepage.verifyLandingPage();
						
			/************************************************************************************/
			extentReport.info(
					"400-S- The Clinic Profile Page shall display the following fields associated with the Clinic's Regional Settings:<ClncMgt26295> </br> a. Clinic Time Zone </br> b. Language </br> c. Date Format </br> d. Time Format </br> e. Number Format </br> f. Weight Units");
			profilepage.verifyfieldsInClinicRegionalSetting();
			/************************************************************************************/
			extentReport.info(
					"500-S- In the Clinic Regional Settings section of the page, select a value for Clinic Time zone from the drop down.");
//			Need Rework of this method
			//profilepage.selectClinicTimezonedropdown("delhi");
			/************************************************************************************/
			extentReport.info(
					"600-S- Click on the Save button and OK on the confirmation dialog that appears. <ClncMgt26380><CommUI7681>.");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"700-V- Verify that the preference selected for Clinic Time Presentation is a value available in the list mentioned in <ClncMgt241>, <ClncMgt16893>");
			// how to verify in list ?
			profilepage.checkvalueinClinicTimelist("");
			/************************************************************************************/
			extentReport.info(
					"800-V- Verify that a message CP 803 stating that the changes made have been saved is displayed. Also verify that the time format selected is apllied across the clinic for relevant pages and/ or fields <ClncMgt247>");
			profilepage.verifymessage("CP 803 stating that the changes made have been saved is displayed");
//			"CP 803 stating that the changes made have been saved is displayed
			/************************************************************************************/
			extentReport
					.info("900-S- Edit and Check that the Clinic Time zone field is displayed as a mandatory field.");
			profilepage.clickEditButton();
			profilepage.selectClinicTimezonedropdown("");
			profilepage.checktimezonemandatorylabel();
//			selectClinintimezone(no value)

			profilepage.verifymessage("CS 818 stating that the Clinic Time zone is not provided is");
			// a message CS 818 stating that the Clinic Time zone is not provided is
			// displayed.
			/************************************************************************************/
			extentReport.info(
					"1000-S- Click the Save button without adding any information for Clinic Time zone or selecting blank from the dropdown.");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"1100-S- Verify that a message CS 818 stating that the Clinic Time zone is not provided is displayed.<ClncMgt30775>");
			profilepage.verifymessage("a message CS 818 stating that the Clinic Time zone is not provided is displayed.");
//			verifymessage 

			/************************************************************************************/
			extentReport.info(
					"1200-S- Click on cancel and again edit and In the Clinic Regional Settings section of the page, select a value for Clinic Time zone from the drop down");
			profilepage.clickCancelButton();
			profilepage.alertclickCancelButton();
			profilepage.clickEditButton();
			profilepage.selectClinicTimezonedropdown("delhi");
//			selecttimezone(value)
			/************************************************************************************/
			extentReport.info(
					"1300-S- Click on Cancel button and OK on the confirmation dialog that appears.<ClncMgt26412> Check  the changes made are not saved.");
			profilepage.clickCancelButton();
			profilepage.alertclickCancelButton();
			profilepage.verifychangesnotsaved();
			/************************************************************************************/
			extentReport.info(
					"1400-S-Edit and  In the Clinic Regional Settings section of the page, select a value for Clinic Time zone from the drop down");
			profilepage.clickEditButton();
			profilepage.selectClinicTimezonedropdown("delhi");
//			selecttimezone(value)
			/************************************************************************************/
			extentReport.info(
					"1500-S- Click on Cancel Button and cancel on the confirmation dialog that appears.Check the page is displayed in View mode.<CommUI7682>");
			profilepage.clickCancelButton();
			profilepage.verifyLandingPage();
			/************************************************************************************/
			extentReport.info("1600-S- Again click on the Edit button the page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"1700-S- Select any value from the drop down of Clinic Time zone and click on any link on the page without saving the changes made.");
			profilepage.selectClinicTimezonedropdown("delhi");
			profilepage.clickCancelButton();

			/************************************************************************************/
			extentReport.info(
					"1800-S- Verify the message CM 810 stating navigating without saving the changes is displayed.<ClncMgt30776>");
			profilepage.verifymessage("message CM 810 Canceling this operation will cause your changes to be lost. Are you sure you want to cancel?");
//			message CM 810 Canceling this operation will cause your changes to be lost. Are you sure you want to cancel?
			/************************************************************************************/
			extentReport.info("1900- S Select Cancel on the dialog");
			profilepage.alertclickCancelButton();
			/************************************************************************************/
			extentReport.info(
					"2000-S- In the Clinic Regional Settings section of the page, select a value for Clinic Language from the drop down.");
			profilepage.selectClinicLanguage("");
			/************************************************************************************/
			extentReport.info(
					"2100-S- Click on the Save button and OK on the confirmation dialog that appears. <ClncMgt26380><CommUI7681>");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"2200-V- Verify that the preference selected for Clinic Language is a value available in the list mentioned in <ClncMgt241>, <ClncMgt16893>");
			profilepage.checklangugagevalue();
			/************************************************************************************/
			extentReport.info(
					"2300-V- Verify that a message CP 803 stating that the changes made have been saved is displayed.<ClncMgt247>");
			profilepage.verifymessage("CP 803 stating that");
			/************************************************************************************/
			extentReport.info(
					"2400-S- Edit and In the Clinic Regional Settings section of the page, select a value for Clinic Language from the drop down");
			profilepage.clickEditButton();
			profilepage.selectClinicLanguage("English(United States)");
			/************************************************************************************/
			extentReport.info("2500-S- Click on Cancel button. <ClncMgt26412>");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("2600-V- Verify the changes made are not saved. <ClncMgt26746>");
			profilepage.verifylangugagedropdownvalue();
			/************************************************************************************/
			extentReport.info(
					"2700-S-Edit and In the Clinic Regional Settings section of the page, select a value for Clinic Language from the drop down");
			profilepage.clickEditButton();
			profilepage.selectClinicLanguage("English(United States)");
			/************************************************************************************/
			extentReport
					.info("2800-S- Click on Cancel Button and Check the page is displayed in View mode.<CommUI7682>");

			profilepage.clickCancelButton();
			profilepage.verifyLandingPage();
			/************************************************************************************/
			extentReport.info("2900-S- Again click the Edit button the page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"3000-S- Select any value from the drop down of Clinic Language and click on any link on the page without saving the changes made.");
			profilepage.selectClinicLanguage("English(United States)");
			profilepage.selectDateformat("Year-Month-Day");

			/************************************************************************************/
			extentReport.info(
					"3100-S- Verify the message stating navigating without saving the changes is displayed and select ok.<ClncMgt30776>");
			profilepage.verifymessage("");
//			verifymessage the message stating navigating without saving the changes is displayed and select ok.
			/************************************************************************************/
			extentReport.info("3200-S- Again click on the Edit button the clinic profile page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"3300-S- In the Clinic Regional Settings section of the page, select a preference for Date format from the drop down.");
			profilepage.selectDateformat("Year-Month-Day");
			/************************************************************************************/
			extentReport.info(
					"3400-S- Click on the Save button and OK on the confirmation dialog that appears. <ClncMgt26380><CommUI7681>");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"3500-V- Verify that the Date format selected is available in the list mentioned in <Config21363> <ClncMgt241>, <ClncMgt16893>");
			profilepage.verifyDateformat("");
			/************************************************************************************/
			extentReport.info(
					"3600-V- Verify that a message CP 803 stating that the changes made have been saved is displayed. Also verfiy that the new date format is applied across the clinic <ClncMgt247>");
			profilepage.verifymessage("");
//			verifymessage CP 803 stating that the changes made have been saved is displayed
			profilepage.checknewdateformatatcliniclevel();
			/************************************************************************************/
			extentReport.info(
					"3700-S- Edit and In the Clinic Regional Settings section of the page, select a value for Date format from the drop down");
			profilepage.clickEditButton();
			profilepage.selectDateformat("Year-Month-Day");
			/************************************************************************************/
			extentReport.info("3800-S- Click on Cancel button.");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("3900-V- Check  the changes made are not saved. <ClncMgt26746>");
			profilepage.verifyDateformat("");
			/************************************************************************************/
			extentReport.info(
					"4000-S- Edit and In the Clinic Regional Settings section of the page, select a value for Date format from the drop down");
			profilepage.clickEditButton();
			profilepage.selectDateformat("Year-Month-Day");
			/************************************************************************************/
			extentReport
					.info("4100-S- Click on Cancel Button and Check the page is displayed in View mode.<CommUI7682>");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("4200-S- Again click the Edit button the page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"4300-S- Select any value from the drop down of Date format and click on any link on the page without saving the changes made.");
			profilepage.selectDateformat("Year-Month-Day");
			profilepage.selectNumberformat("1,234.56");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info(
					"4400-S- Verify the message stating navigating without saving the changes is displayed and select ok.<ClncMgt30776>");
			profilepage.verifymessage("");
			/************************************************************************************/
			extentReport.info("4500-S- Again click the Edit button the page");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"4600-S- In the Clinic Regional Settings section of the page, select a preference for Number format from the drop down.");
			profilepage.selectNumberformat("1,234.56");
			/************************************************************************************/
			extentReport.info(
					"4700-S- Click on the Save button and OK on the confirmation dialog that appears. <ClncMgt26380><CommUI7681>");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"4800-V- Verify that the Number format selected is a value available in the list mentioned in <Config20260><ClncMgt241>, <ClncMgt16893>");
			profilepage.verifynumberformat();
			/************************************************************************************/
			extentReport.info(
					"4900-V- Verify that a message CP 803 stating that the changes made have been saved is displayed. Also verify that the new number format is applied across the clinic wherever applicable.<ClncMgt247>");
			profilepage.clickSaveButton();

			/************************************************************************************/
			extentReport.info(
					"5000-S- Edit and In the Clinic Regional Settings section of the page, select a value for Number format from the drop down");
			profilepage.clickEditButton();
			profilepage.selectNumberformat("1,234.56");
			/************************************************************************************/
			extentReport.info("5100-S- Click on Cancel button. <ClncMgt26412>");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("5200-V- Check  the changes made are not saved. <ClncMgt26746>");
			profilepage.verifynumberformat();
			/************************************************************************************/
			extentReport.info(
					"5300-S- Edit and In the Clinic Regional Settings section of the page, select a value for Number format from the drop down");
			profilepage.clickEditButton();
			profilepage.selectNumberformat("1,234.56");
			/************************************************************************************/
			extentReport
					.info("5400-S- Click on Cancel Button and Check the page is displayed in View mode.<CommUI7682>");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("5500-S- Again click the Edit button the page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"5600-S- Select any value from the drop down of Number format and click on any link on the page without saving the changes made.");
			profilepage.selectNumberformat("1,234.56");
			profilepage.selectWeightunit("Weight unit - Kilograms");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info(
					"5700-S- Verify the message stating navigating without saving the changes is displayed and select ok.<ClncMgt30776>");
			profilepage.verifymessage("");
			/************************************************************************************/
			extentReport.info("5800-S- Again click the Edit button the  Clnicl profile page");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"5900-S- In the Clinic Regional Settings section of the page, select a preference for Weight units from the drop down.");
			profilepage.selectWeightunit("Weight unit - Kilograms");
			/************************************************************************************/
			extentReport.info(
					"6000-S- Click on the Save button and OK on the confirmation dialog that appears. <ClncMgt26380><CommUI7681>.");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"6100-V- Verify that the weight unit selected is a value available in the list mentioned in <ClncMgt241>, <ClncMgt16893>");
			profilepage.verifyWeightunit("Weight unit - Kilograms Weight unit - Pounds");
			/************************************************************************************/
			extentReport.info(
					"6200-V- Verify that a message stating that the changes made have been saved is displayed.<ClncMgt247>");
			profilepage.clickSaveButton();
			profilepage.verifymessage("");
			/************************************************************************************/
			extentReport.info(
					"6300-V- Verify that all the fields in the Clinic Regional settings have been saved with the changes made. < ClncMgt246>");
			profilepage.verifysavechanges();
			/************************************************************************************/
			extentReport.info(
					"6400-S- Edit and In the Clinic Regional Settings section of the page, select a value for Weight units from the drop down");
			profilepage.clickEditButton();
			profilepage.selectWeightunit("Weight unit - Kilograms");
			/************************************************************************************/
			extentReport.info(
					"6500-S- Click on Cancel button.<ClncMgt26412> 5750-V Check  the changes made are not saved. <ClncMgt26746>");
			profilepage.clickCancelButton();
			profilepage.verifychangesnotsaved();
			/************************************************************************************/
			extentReport.info(
					"6600-S- In the Clinic Regional Settings section of the page, select a value for Weight units from the drop down");
			profilepage.selectWeightunit("Weight unit - Kilograms");
			/************************************************************************************/
			extentReport
					.info("6700-S- Click on Cancel Button and Check the page is displayed in View mode.<CommUI7682>");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("6800-S- Again click the Edit button the page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"6900-S- Select any value from the drop down of Weight Units and click on any link on the page without saving the changes made.");
			profilepage.selectWeightunit("Weight unit - Kilograms");
			profilepage.selectTimeformat("13:45");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info(
					"7000-S- Verify the message stating navigating without saving the changes is displayed and select ok.<ClncMgt30776>");
			profilepage.verifymessage("");
//					verifymessage message stating navigating without saving the changes is displayed and select ok.
			/************************************************************************************/
			extentReport.info(
					"7100-S- In the Clinic Regional Settings section of the page, select a preference for Time format from the drop down.");
			profilepage.selectTimeformat("13:45");
			/************************************************************************************/
			extentReport.info(
					"7200-S- Click on the Save button and OK on the confirmation dialog that appears. ClncMgt26380><CommUI7681>.");
			profilepage.clickSaveButton();
			/************************************************************************************/
			extentReport.info(
					"7300-V- Verify that the Time format selected is a value available in the list mentioned in <ClncMgt241>, <ClncMgt16893>");
			profilepage.verifyTimeformatvalue("1:45 pm 13:45");
			/************************************************************************************/
			extentReport.info(
					"7400-V- Verify that a message stating that the changes made have been saved is displayed.<ClncMgt247>");
			profilepage.clickSaveButton();
			profilepage.verifymessage("");
			/************************************************************************************/
			extentReport.info(
					"7500-V- Verify that all the fields in the Clinic Regional settings have been saved with the changes made. < ClncMgt246>");
			profilepage.verifyLandingPage();
			/************************************************************************************/
			extentReport.info(
					"7600-S- In the Clinic Regional Settings section of the page, select a value for  Time format from the drop down");
			profilepage.clickEditButton();
			profilepage.selectTimeformat("13:45");
			/************************************************************************************/
			extentReport
					.info("8000-S- Click on Cancel Button and Check the page is displayed in View mode.<CommUI7682>.");
			profilepage.clickCancelButton();
			/************************************************************************************/
			extentReport.info("8100-S- Again click the Edit button the page.");
			profilepage.clickEditButton();
			/************************************************************************************/
			extentReport.info(
					"8200-S- Select any value from the drop down of Time format and click on any link on the page without saving the changes made.");
			profilepage.selectTimeformat("13:45");
			LeftNavPage.clickSchedMessagingLink();
			
			/************************************************************************************/
			extentReport.takeFullSnapShot(driver,
					"8300-S- Verify the message CM 810 stating navigating without saving the changes is displayed.<ClncMgt30776>");
			profilepage.verifyCM810_message("Changes you made may not be saved");
//					verifymessage CM 810 stating navigating without saving the changes is displayed.<ClncMgt30776>"
			/************************************************************************************/
			extentReport.info("Test Case ends.");
			assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.reportFail("WA_CA100_ClinicProfile_EditClinicRegionalSettings_01 Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("WA_CA100_ClinicProfile_EditClinicRegionalSettings_01 Validation not  successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}