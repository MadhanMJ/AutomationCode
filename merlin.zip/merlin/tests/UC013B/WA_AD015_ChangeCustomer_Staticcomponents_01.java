package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataBaseTables.CustomerData;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

import junit.framework.Assert;

public class WA_AD015_ChangeCustomer_Staticcomponents_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Log logger;
	 CustomerData customerData;
	Customer customer;
	TestDataProvider testDataProvider;
	AddCustomerPage addCustomerPage;
	private String testName;
	String clinicalTrailSectionTitle;
	DataBaseConnector dataBaseConnector;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		logger =  new Log();
		customerData = new CustomerData();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void WAChangeCustomerStaticcomponents() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_ChangeCustomer_Staticcomponents_01");
		extentTest.assignAuthor("Author - Mohan Sekar");
		try {
			
			Assertions assertion =  new Assertions(extentTest);
			
			extentReport.info("100 S The actor logs into the system and clicks on customer name displayed on Customer list.");
			loginPage.login(login,"internaluser");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			//customerListPage.listclick();
			extentTest = extentReport.info("150 S Actor clicks on 'Change' button to navigate to the Change customer page.");
			customerProfilePage.clickChangeButton();
			extentTest = extentReport.info("200 V Verify that Change Customer page displays the following static components");
			String userId = changeCustomerProfilePage.getUserId();

			/*
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.customerName), extentReport,
			 * "Add Customer Page Customer Name Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.customerType), extentReport,
			 * "Add Customer Page Customer Type Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.clinicLocation_OR),
			 * extentReport, "Add Customer Page clinic Location  Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.clinicAddress_1),
			 * extentReport, "Add Customer Page Clinic Address Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.clinicCity), extentReport,
			 * "Add Customer Page City Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.stateProvinceDropDown),
			 * extentReport, "Add Customer Page State Procince Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.country_OR), extentReport,
			 * "Add Customer Page Country Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.zipPostalCode),
			 * extentReport, "Add Customer Page Zip Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.mainPhone_OR), extentReport,
			 * "Add Customer Page Main Phone Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.secPhone), extentReport,
			 * "Add Customer Page Secondary Phone Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.faxNumber), extentReport,
			 * "Add Customer Page Fax Number Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.textMessage), extentReport,
			 * "Add Customer Page Text Message Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.email_OR), extentReport,
			 * "Add Customer Page Email Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.clinicLanguage_OR),
			 * extentReport, "Add Customer Page clinic Language Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.clinicTimeZone_OR),
			 * extentReport, "Add Customer Page clinic TimeZone Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.legalJurisdiction),
			 * extentReport, "Add Customer Page legal Jurisdiction Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.testClinic), extentReport,
			 * "Add Customer Page Test Clinic Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.onDemandFeatureControl),
			 * extentReport, "Add Customer Page onDemandFeatureControl Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.userId_OR), extentReport,
			 * "Add Customer Page userId Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.firstName_OR), extentReport,
			 * "Add Customer Page firstName Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.lastName_OR), extentReport,
			 * "Add Customer Page lastName Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.middleName), extentReport,
			 * "Add Customer Page middleName Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.credentials), extentReport,
			 * "Add Customer Page credentials Validation");
			 * assertion.assertEqualsWithReporting(true,
			 * addCustomerPage.isElementPresent(addCustomerPage.emailId), extentReport,
			 * "Add Customer Page Email Id Validation");
			 */addCustomerPage.FieldVerfication("AddCustomer");
			dataBaseConnector.getConnection();
			extentTest = extentReport.info("300 S Update the value of all the fields listed in step 200 with valid value and click on save button. click 'Ok' on subsequent dialog box.");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomersaveok();
			extentTest = extentReport.info("400 V Verify that customer record in database is updated as per values updated on web application in step 300.");
			//customerAccount.readCustomerAccountTable(userRecordId);
			customerData.readCustomerTable(userId);
			assertion.assertEqualsWithReporting(customerData.getEmailId(), customer.getEmail(), extentReport, "Email Verification");
				//customerListPage.verifyLogout();

		} catch (AssertionError e) {
			extentTest = extentReport.fail( "WA_AD015_ChangeCustomer_Staticcomponents_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentTest = extentReport.fail( "WA_AD015_ChangeCustomer_Staticcomponents_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}

}
