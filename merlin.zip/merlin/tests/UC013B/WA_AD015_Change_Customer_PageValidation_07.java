package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_AD015_Change_Customer_PageValidation_07 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	public static Log logger = new Log();
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}
	
	@Test(groups= {"Regression3"})
	public void wa_AD015_Change_Customer_PageValidation_07() throws Exception {  
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_Change_Customer_PageValidation_07");
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			assertion =  new Assertions(extentTest);	
			extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
			loginPage.login(login,"internaluser");
	
			String customerName=customer.getCustomerName();
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentTest = extentReport.info("200-S-  Enter below invalid data for Clinic Name field and click on save button - Enter more than 50 characters-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxab");
			
			customer.setCustomerName("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxab");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Clinic Name field is updated with more than 50 characters");
			String newCustomerName = changeCustomerProfilePage.getAttribute(changeCustomerProfilePage.customerName,"value");
			int length = changeCustomerProfilePage.getAttribute(changeCustomerProfilePage.customerName,"value").length();
			changeCustomerProfilePage.clickSaveButton();
			
			
			extentReport.info("300-V- Verify that change Customer page shall validate if all the fields are having valid values entered",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+newCustomerName+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickPopUpCancelButton();
			changeCustomerProfilePage.clickOKButton();
			
			extentReport.info("400-V- Verify that system doesn't allow to enter more than 50 characters in clinic name field",new String[] {"ClncAcct6023"});
			assertion.assertEquals(length,50,"Clinic name field only allow 50 characters");
			
			extentTest = extentReport.info("500-S-  Enter below valid data for clinic name field one at a time and click on save button - Maharashtra_hospital, mumbai");
			customer.setCustomerName("Maharashtra_hospital, mumbai");
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Clinic Name field is updated with Maharashtra_hospital, mumbai");
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("600 -V-Verify that change Customer page shall validate if all the fields are having valid values entered"+"<br>"+"700-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4466","CommUI4467"});
			assertion.assertEqualsWithReporting("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), extentReport, "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickPopUpCancelButton();
			changeCustomerProfilePage.clickOKButton();
			
			
			
			extentTest = extentReport.info("500-S-  Enter below valid data for clinic name field one at a time and click on save button - abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwx");
			customer.setCustomerName("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwx");
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Clinic Name field is updated with abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwx");
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("600 -V-Verify that change Customer page shall validate if all the fields are having valid values entered"+"<br>"+"700-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4466","CommUI4467"});
			assertion.assertEqualsWithReporting("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), extentReport, "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickPopUpCancelButton();
			changeCustomerProfilePage.clickOKButton();
			
			
			
			extentTest = extentReport.info("500-S-  Enter below valid data for clinic name field one at a time and click on save button - abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvw");
			customer.setCustomerName("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvw");
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Clinic Name field is updated with abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvw");
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("600 -V-Verify that change Customer page shall validate if all the fields are having valid values entered"+"<br>"+"700-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4466","CommUI4467"});
			assertion.assertEqualsWithReporting("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), extentReport, "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickPopUpCancelButton();
			changeCustomerProfilePage.clickOKButton();
			
			
			
			extentTest = extentReport.info("500-S-  Enter below valid data for clinic name field one at a time and click on save button - 123abcdefgabcded");
			customer.setCustomerName("123abcdefgabcded");
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Clinic Name field is updated with 123abcdefgabcded");
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("600 -V-Verify that change Customer page shall validate if all the fields are having valid values entered"+"<br>"+"700-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4466","CommUI4467"});
			assertion.assertEqualsWithReporting("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), extentReport, "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickPopUpCancelButton();
			changeCustomerProfilePage.clickOKButton();
			
			
			
			extentTest = extentReport.info("500-S-  Enter below valid data for clinic name field one at a time and click on save button - !#@~#@@$#!!#!113`12");
			customer.setCustomerName("!#@~#@@$#!!#!113`12");
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Clinic Name field is updated with !#@~#@@$#!!#!113`12");
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("600 -V-Verify that change Customer page shall validate if all the fields are having valid values entered"+"<br>"+"700-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4466","CommUI4467"});
			assertion.assertEqualsWithReporting("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), extentReport, "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickPopUpCancelButton();
			changeCustomerProfilePage.clickOKButton();
			
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_03 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentTest = extentReport.fail( "WA_AD015_Change_Customer_PageValidation_03 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
}
