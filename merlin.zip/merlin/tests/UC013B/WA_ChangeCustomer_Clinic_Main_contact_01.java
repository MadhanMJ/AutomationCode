package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class WA_ChangeCustomer_Clinic_Main_contact_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;
	private Log logger = new Log();

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void wa_ChangeCustomer_Clinic_Main_contact_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("Rev1_WA_UC013B_B01_01");
		extentTest.assignAuthor("Author - Mohan Sekar");

		try {
			softAssert = new Assertions(extentTest);
			
			extentReport.info("100-S-The actor logs into the system and clicks on customer name displayed on Customer list.");
			loginPage.login(login,"internaluser");
			
			extentReport.info("150-S- Actor clicks on 'Change' button to navigate to the Change customer page.");
			//customerListPage.listclick();
			customerListPage.searchCustomerAndClick("addCustomer34");
			extentTest = extentReport.info("200-V- Verify that Change Customer page displays the following components:<br> User ID of Clinic's main contact person (Mandatory).<br>First name of Clinic's main contact person (Mandatory)<br> Middle name of Clinic's main contact person<br> Last name of Clinic's main contact person (Mandatory)<br>Credentials of Clinic's main contact person<br> Email Address of Clinic's main contact person(Mandatory)<br> ",new String[] {"ClncAcct6043"});
			assertion.assertEquals(true, customerListPage.isElementPresent(customerListPage.userIDText),  "Add Customer Page userId Validation");
			assertion.assertEquals(true, customerListPage.isElementPresent(customerListPage.firstNameText),  "Add Customer Page firstName Validation");
			assertion.assertEquals(true, customerListPage.isElementPresent(customerListPage.lastNameText),  "Add Customer Page lastName Validation");
			assertion.assertEquals(true, customerListPage.isElementPresent(customerListPage.middlenameText),  "Add Customer Page middleName Validation");
			assertion.assertEquals(true, customerListPage.isElementPresent(customerListPage.credentialsText),  "Add Customer Page credentials Validation");
			assertion.assertEquals(true, customerListPage.isElementPresent(customerListPage.mainEmailText),  "Add Customer Page Email Id Validation");
			String userid=customerListPage.getAttribute(customerListPage.userIDText,"value");
			System.out.println(userid);
			
			
			extentReport.info("300-V- Verify that First name, middle name, last name, credentials and email address values in that section are updated with corresponding values for selected User.");
			customerListPage.scrollToView(customerListPage.changeButton);
			customerListPage.clickElement(customerListPage.changeButton);
			customerListPage.scrollToView(customerListPage.userIDText);
			
			String firstname="Mohan"+customerListPage.timestamp();
			String lastname="Sekhar"+customerListPage.timestamp();
			String middlename="Kal"+customerListPage.timestamp();
			String emailid="mohan.s"+customerListPage.timestamp()+"@gmail.com";
			Thread.sleep(3000);
			customerListPage.loading();
			customerListPage.sendKeys(customerListPage.mainEmailText, emailid);
			//customerListPage.sendKeys(customerListPage.firstNameText,firstname);
			//customerListPage.sendKeys(customerListPage.lastNameText, lastname);
			//customerListPage.sendKeys(customerListPage.middlenameText,middlename);
			
			changeCustomerProfilePage.savePositiveChanges();
			extentTest = extentReport.info("400-S click on 'Save' button. Click 'Ok' button on subsequent dialog Box.");
			dataBaseConnector.getConnection();
			String query = "select c.\"name\" ,c.customer_type_cd ,cl.name as location,c.customer_address_id ,c.main_phone_id ,c.secondary_phone_id ,c.fax_num_id ,c.email_address ,ur.create_userid ,ur.first_name,ur.middle_name ,ur.last_name,ur.temp_pwd ,cp.area_code as area_code,c.main_phone_id ,\r\n"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.spoken_language_cd and cd.code_qualifier ='Language_Cd') as language,\r\n"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.legal_jurisdiction_cd and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction,\r\n"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.time_zone_cd and cd.code_qualifier ='Time_Zone_Cd') as time_zone,\r\n"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.customer_type_cd and cd.code_qualifier ='Customer_Type_Cd') as customer_type,\r\n"
					+ "(SELECT code_desc FROM lookup.code cd where cad.customer_address_id =c.customer_address_id and cd.code_id=cad.country_cd and cd.code_qualifier ='Country_Cd') as country\r\n"
					+ "from customers.customer c, users.user_record ur, users.customer_account ca, customers.customer_phone cp , customers.customer_address cad, customers.customer_location cl\r\n"
					+ "where cl.customer_id = c.customer_id and c.main_phone_id = cp.customer_phone_id and c.customer_address_id = cad.customer_address_id\r\n"
					+ "and c.customer_id = ca.customer_id and ca.user_record_id = ur.user_record_id and ur.logon_user_name='" + userid + "'";
			
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);
			String firstName = null, middleName = null, lastName = null,emailId = null ;
			while (customerRecord.next()) {
				// firstName = customerRecord.getString("first_name");
				// middleName = customerRecord.getString("middle_name");
				// lastName= customerRecord.getString("last_name");
				 emailId = customerRecord.getString("email_address");
				
			}
			
			extentTest = extentReport.info("500-V- Verify that customer record is updated for clinic's main contact in database.");
			//softAssert.assertEquals( firstname,firstName,"First Name field is verified");
			//softAssert.assertEquals( middlename,middleName,"Middle Name field is verified");
			//softAssert.assertEquals( lastname,lastName, "Last Namw field is verified");
			softAssert.assertEquals( emailid,emailId, "Email field is verified");
			
			
			
		} catch (AssertionError e) {
			extentReport.fail( "wa_ChangeCustomer_Clinic_Main_contact_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "wa_ChangeCustomer_Clinic_Main_contact_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
