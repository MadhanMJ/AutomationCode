package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

import junit.framework.Assert;

public class ClinicAccountManagement_TC100103 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	private Log logger = new Log();
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		
	}

	@Test(groups= {"Regression"})
	public void ClinicalTrial() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("ClinicAccountManagement_TC100103");
		extentTest.assignAuthor("Author - Mohan Sekar");
		try {
			
			Assertions assertion =  new Assertions(extentTest);
			
			extentReport.info("100 S Login to application using admin credentials and select customer from customer List");
			loginPage.login(login,"internaluser");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.loading();
			customerProfilePage.loading();
			customerProfilePage.scrollToView(customerProfilePage.allowedClinicalTrailSectionTitle_OR);
			extentTest = extentReport.info("200 V Verify that the Clinical Trial section title displays <label.gb.allwd_clinical.trials> ('Allowed Clinical Trials')",new String[] {"ClncAcct6612","ClncAcct6610"});
			customerProfilePage.loading();
			clinicalTrailSectionTitle = customerProfilePage.getText(customerProfilePage.allowedClinicalTrailSectionTitle_OR);
			extentReport.reportScreenShot("Allowed Clinical Trials tile is displayed successfully");
			assertion.assertEquals("Allowed clinical trials",clinicalTrailSectionTitle,"Allowed Clinical Trials tile is displayed successfully");
			customerProfilePage.loading();
			extentReport.info("300 S The actor clicks on Change button");
			customerProfilePage.scrollToView(customerProfilePage.changeButton_OR);
			customerProfilePage.goToChangeCustomerProfilePage();
			customerProfilePage.loading();
			extentTest = extentReport.info("400 V Verify that the allowed clinical trials section is blank and non-editable.(EP only Customer )",new String[] {"ClncAcct6612","ClncAcct6610"});
			
			int allowedClinicalTrails = changeCustomerProfilePage.getAllowedClinicalTrails().size();
			assertion.assertEquals(0,allowedClinicalTrails,"Allowed clinical trials section is blank for EP only clinic");
			assertion.assertTrue(true,"Checking");
			String checkClinincalTrailProperty = changeCustomerProfilePage.getAttribute(changeCustomerProfilePage.addClinincalTrailButton_OR, "disabled");
			extentReport.reportScreenShot("Allowed clinical trials section is non editable");
			assertion.assertEquals("true", checkClinincalTrailProperty,"Allowed clinical trials section is non editable");
			extentReport.info( "Clinical Trail Section validation is completed successfully");
			

			//customerListPage.verifyLogout();

		} catch (AssertionError e) {
			extentTest = extentReport.fail( "ClinicAccountManagement_TC100103 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		} catch (Exception e) {
			extentTest = extentReport.fail( "ClinicAccountManagement_TC100103 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		saintResult(result,extentTest);
	}

}
