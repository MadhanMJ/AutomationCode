package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;


/* Author: Poojitha Gangiri
 * TC Name: R7_SJM100000234
 */

public class R7_SJM100000234 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ViewCustomerPage viewCustomerPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	String testName,customerName,fieldValue;
	Assertions assertion,softAssert ;
	Log logger;
	CommonUtils utils;
	DataBaseConnector dataBaseConnector;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	List<String> optionsValues;
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();	
		databaseResults = new HashMap<String,String>();
		optionsValues = new ArrayList<String>();
	}

	@Test
	public void TC_R7_SJM100000234() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData(testName);
				
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		
		try {
			assertion =  new Assertions(extentTest);
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) is logged into the system and navigates to page AD001(Customer List).");
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(),extentReport,"Customer List Page is displayed");
			
			
			extentReport.info("200-V- customer list Page is displayed with a list of customers.");
			customerListPage.customerList();
			extentReport.reportScreenShot("Customer List page is displayed with all the customers associated with the it.");
			
			extentReport.info("300-S-The actor clicks a link in the Customer Name column.");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile Page is displayed");
			
			extentReport.info("400-V-The system displays page AD005 (Customer Profile) with the customer's details pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("CustomerName"), true, "CustomerName detail is Prepopulated");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("CustomerType"), true, "CustomerType detail is Prepopulated");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("ClinicLocation"), true, "ClinicLocation detail is Prepopulated");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("AreaCode"), true, "AreaCode detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("MainPhone"), true, "MainPhone detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("CountryCode"), true,  "CountryCode detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("Country"), true,"Country detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("Email"), true, "Email detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("ClinicTimeZone"), true,"ClinicTimeZone detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("ClinicLanguage"), true,"ClinicLanguage detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("LegalJurisdiction"), true, "LegalJurisdiction detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("UserID"), true, "UserID detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("FirstName"), true,"FirstName detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("LastName"), true, "LastName detail is pre-populated.");
			assertion.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode("MainContactEmail"), true, "MainContactEmail detail is pre-populated. ");

			extentReport.reportScreenShot("Customer profile is displayed with all the existing details.");
			
			extentReport.info("650-V- Verify that there is 'Add secondary Location' link present and is active.");
			customerProfilePage.validateAddSecondaryLocationButtonClickable();
			extentReport.reportScreenShot( "Add a Secondary Location Button in Customer Profile page is clickable");	
					
			extentReport.info("500-S-The actor clicks the Change button.");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change customer profile Page is displayed");
			
			
			extentReport.info("600-V-Verify that the actor is having the capacity to change customer and also that the system displays AD015 (Change Customer) with most of the input fields becoming editable (see UI Spec).");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("CustomerName"), true, "CustomerName field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("CustomerType"), true, "CustomerType field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("ClinicLocation"), true, "ClinicLocation field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("MainPhone"), true, "MainPhone field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("CountryCode"), true, "CountryCode field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("AreaCode"), true, "AreaCode field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("Address1"), true, "Address1 field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("Address2"), true, "Address2 field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("Address3"), true, "Address3 field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("City"), true, "City field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("ClinicLanguage"), true, "ClinicLanguage field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("ClinicTimeZone"), true, "ClinicTimeZone field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("ClinicEmail"), true, "ClinicEmail field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("Country"), true, "Country field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("CountryText"), true, "CountryText field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("Zip/PostalCode"), true, "Zip/PostalCode field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("LegalJurisdiction"), true, "LegalJurisdiction field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("ClinicContactEmail"), true, "ClinicContactEmail field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("StateProvinence"), true, "StateProvinence field is editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("FirstName"), false, "FirstName field is not editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("MiddleName"), false, "MiddleName field is not editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("LastName"), false, "LastName field is not editable");
			assertion.assertEquals(changeCustomerProfilePage.validateEditableFields("UserId"), false, "UserId field is not editable");
			
			extentReport.info("700-S-The actor changes customer details as desired with entering valid values in the fields, and clicks the Save button");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();
			extentReport.reportScreenShot("User is able to edit the existing customer details successfully");
			
			
			extentReport.info("900-V-The system also verify that the system displays AD 808 with text defined by <msg.ad808.text> (are you sure?) confirm box including the customer name.");
			assertion.assertEquals("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "As entered values are valid as per requirement system should accept it without any error");
			extentReport.reportScreenShot("AD 808 alert box validation is successful");
			
			extentReport.info("1000-S-The actor clicks the Okay button on the confirm box.");
			changeCustomerProfilePage.clickOKButton();
			
			extentReport.info("1100-V Step 2-the system displays AD 802 (customer changes) alert box as 'Your changes have been saved.'");
			extentReport.reportScreenShot("System displays that changes are saved successfully");
			
			
			extentReport.info("800-V-The system Verify that the system shall validate the data entered by the actor.");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile Page is displayed");
			
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("CustomerName"), extentReport, "Customer name field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("CustomerType"), extentReport, "Customer type field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ClinicLocation"), extentReport, "Clinic location field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ClinicEmail"), extentReport, "Clinic email field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("CountryCode"), extentReport, "Country code field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("AreaCode"), extentReport, "Area code field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("MainPhone"), extentReport, "Mainphone field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("Address1"), extentReport, "Address1 field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("Address2"), extentReport, "Address2 field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("Address3"), extentReport, "Address3 field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("City"), extentReport, "City field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("StateProvinence"), extentReport, "State provinence field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("Country"), extentReport, "Country field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("Zip/PostalCode"), extentReport, "Zip/Postal code field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ClinicLanguage"), extentReport, "Clinic language field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("FaxCountryCode"), extentReport, "Fax country code field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("SecondaryPhone"), extentReport, "Secondary phone field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("FaxText"), extentReport, "Fax text field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ClinicTimeZone"), extentReport, "Clinic time zone field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("LegalJurisdiction"), extentReport, "Legal jurisdiction field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ClinicMainContactEmail"), extentReport, "ClinicMainContactEmail field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("LastName"), extentReport, "Last name field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("MiddleName"), extentReport, "Middle name field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("UserId"), extentReport, "UserID field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("FirstName"), extentReport, "First name field is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("SendVoiceMessages"), extentReport, "SendVoiceMessages checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("SendTextMessages"), extentReport, "SendTextMessages checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("PatientDataCollectionConsent"), extentReport, "PatientDataCollectionConsent checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("MobileDirectAlerts"), extentReport, "MobileDirectAlerts checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("CommunicationCenter"), extentReport, "CommunicationCenter checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ComplianceReport"), extentReport, "ComplianceReport checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("ExportTransmission"), extentReport, "ExportTransmission checkbox is present on Customer Profile Page.");
			assertion.assertEqualsWithReporting(true, customerProfilePage.validatePresenceOfField("OrderTransmitter"), extentReport, "OrderTransmitter checkbox is present on Customer Profile Page.");

			
			assertion.assertEqualsWithReporting(customer.getCustomerName(),customerProfilePage.VerifyCustomerDataInViewMode("CustomerName"), extentReport, "Customer name is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getCustomerType(),customerProfilePage.VerifyCustomerDataInViewMode("CustomerType"), extentReport, "Customer Type is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getClinicLocation(),customerProfilePage.VerifyCustomerDataInViewMode("ClinicLocation"), extentReport, "Customer location is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getCountryCode(),customerProfilePage.VerifyCustomerDataInViewMode("CountryCode"), extentReport, "Country Code is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getAreaCode(),customerProfilePage.VerifyCustomerDataInViewMode("AreaCode"), extentReport, "Area code is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getMainPhone(),customerProfilePage.VerifyCustomerDataInViewMode("MainPhone"), extentReport, "Main phone number is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getCountry(),customerProfilePage.VerifyCustomerDataInViewMode("Country"), extentReport, "Country name is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getEmail(),customerProfilePage.VerifyCustomerDataInViewMode("Email"), extentReport, "Email is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getLegalJurisdiction(),customerProfilePage.VerifyCustomerDataInViewMode("LegalJurisdiction"), extentReport, "LegalJurisdiction is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getClinicLanguage(),customerProfilePage.VerifyCustomerDataInViewMode("ClinicLanguage"), extentReport, "Clinic Language is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getAddress1(),customerProfilePage.VerifyCustomerDataInViewMode("Address1"), extentReport, "AddressLine1 is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getAddress2(),customerProfilePage.VerifyCustomerDataInViewMode("Address2"), extentReport, "Address Line2 is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getStateProvince(),customerProfilePage.VerifyCustomerDataInViewMode("State/Prov"), extentReport, "State code is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getCity(),customerProfilePage.VerifyCustomerDataInViewMode("City"), extentReport, "City is matching with the updated data");
			assertion.assertEqualsWithReporting(customer.getZipPostalCode(),customerProfilePage.VerifyCustomerDataInViewMode("Zip/PostalCode"), extentReport, "zipPostal code is matching with the updated data");
			
			extentReport.info("1300-V-The System 'DirectAlerts{tm} Notification allowed for patients' Control should be displayed under clinic feature control section.");
			customerProfilePage.validationDirectAlertsForPatientsAvailability();
			assertion.assertEqualsWithReporting(true,customerProfilePage.validationDirectAlertsForPatientsAvailability(), extentReport, "Patients Direct Alerts are under Clinic feature control section");
			extentReport.reportScreenShot("Patients Direct Alerts are under Clinic feature control section");
			
			extentReport.info("860-V and 870 V -Validation of devices and alerts in read only mode");
			viewCustomerPage.jurisdictionAlertValidation("allowed_ep_Devices_S");
			viewCustomerPage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
			viewCustomerPage.jurisdictionAlertValidation("allowed_ep_directAlert_4NBLE_S");
			
			
			extentReport.info("850-V-The System EP Application Feature Controls  shall includes Export transmission data files Flag - controls whether or not clinic can export transmission archive data\n"
					+ "and Export to EMR/EHR Option (None/Manual Only/Manual and Automatic");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer Page is displayed");
			changeCustomerProfilePage.applicationFeatureControlVerification(customer);
			optionsValues = changeCustomerProfilePage.getExportToEHROptions();
			assertion.assertEquals(optionsValues.get(0),"Auto/manual","Auto/Manual option is present in ExporttoEHROptions");
			assertion.assertEquals(optionsValues.get(1),"Manual","Manual option is present in ExporttoEHROptions");
			assertion.assertEquals(optionsValues.get(2),"No Export","No Export option is present in ExporttoEHROptions");
			
			extentReport.info("860-V and 870 V -Validation of devices and alerts in edit mode");
			changeCustomerProfilePage.jurisdictionAlertValidation("availableDevices_Select_S");
			changeCustomerProfilePage.jurisdictionAlertValidation("allowedDevices_Select_S");
			changeCustomerProfilePage.jurisdictionAlertValidation("availableEPDirectAlerts_Select_S");
			changeCustomerProfilePage.jurisdictionAlertValidation("allowedEPDirectAlerts_Select_S");
			changeCustomerProfilePage.jurisdictionAlertValidation("availableDirectAlertsForPatients_Select_S");
			changeCustomerProfilePage.jurisdictionAlertValidation("allowedDirectAlertsForPatients_Select_S");
				
			extentReport.info("1100-V-The system stores the updated details in the database Table: CUSTOMER, ADDRESS, LOCATION, CUSTOMER_ACCOUNT, USER_RECORD");
			String userId = changeCustomerProfilePage.getUserId();
			String query = "select ur.logon_user_name ,c.name ,c.email_address,ca.street_address,ca.street_address2 ,"+
					"ca.city as city,(SELECT code_desc FROM lookup.code cd"+ 
							" where cd.code_id= ca.state_cd"+
							" and cd.code_qualifier ='State_Cd') as State_Code,ca.zip_code,"+ 
							" (SELECT code_desc FROM lookup.code cd"+
							" where cd.code_id=c.legal_jurisdiction_cd "+
							" and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction,"+
							" (SELECT code_desc FROM lookup.code cd where cd.code_id=c.locale_cd and cd.code_qualifier ='Language_Cd') as language,"+
							" area_code as area_code,phone_num as main_phone "+
							" FROM customers.customer c ,customers.customer_phone cp ,customers.customer_address ca, users.user_record ur," +
							" users.customer_account ca2 where c.main_phone_id = cp.customer_phone_id"+
							" and c.customer_address_id = ca.customer_address_id"+
							" and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id"+ 
							" and ur.logon_user_name ='"+userId+"'";
			/*databaseResults = queryResults.customerTable_TC1234183(query);
			assertion.assertEquals(databaseResults.get("clinicName"),customer.getCustomerName(),"Clinic name field is verified");
			assertion.assertEquals(databaseResults.get("logon_user_name"),customer.getCustomerName(),"Log in clinic user field is verified");
			assertion.assertEquals(databaseResults.get("area_code"),customer.getAreaCode(),"Area code field is verified");
			assertion.assertEquals(databaseResults.get("main_phone"),customer.getMainPhone(),"Phone Number field is verified");
			assertion.assertEquals(databaseResults.get("customerEmailAddress"),customer.getEmail(), "Email address field is verified");
			assertion.assertEquals(databaseResults.get("addressLine1"),customer.getAddress1(), "AddressLine1 field is verified");
			assertion.assertEquals(databaseResults.get("addressLine2"),customer.getAddress2(), "AddressLine2 field is verified");
			assertion.assertEquals(databaseResults.get("city"),customer.getCity(), "City field is verified");
			assertion.assertEquals(databaseResults.get("stateCode"),customer.getStateProvince(), "stateCode field is verified");
			assertion.assertEquals(databaseResults.get("zipCode"),customer.getZipPostalCode(), "zipCode field is verified");
			assertion.assertEquals(databaseResults.get("legal_jurisdiction"),customer.getLegalJurisdiction(), "Legal Jurisdiction field is verified");
			assertion.assertEquals(databaseResults.get("language"), customer.getClinicLanguage(),"Clinic Language field is verified");*/
			
			
			
			extentReport.info("1400-V-The System should prevent the actor from subsequently removing Customer access/authorization to DirectAlertsTM allowed for patient notification (via the Edit function), after the alert has been provided to the customer and the page is saved.");
			//customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer Page is displayed");
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.validationOfAccessPreventionPatientsAlerts(), extentReport, "Remove link is not displayed restricting the actor from subsequently removing existing direct alerts for Patients");
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
