package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class WA_AD015_ChangeCustomerAppFeatureControl_01 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	String show_export_session_flg,order_transmitter_flg, exportToEHR;
	List<String> expectedxportTOEHROptions = new ArrayList<String>();
	private Log logger = new Log();
	
	
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		expectedxportTOEHROptions.add("Auto/Manual");
		expectedxportTOEHROptions.add("Manual");
		expectedxportTOEHROptions.add("No export");
	}
	
	@Test(groups= {"Regression3"})
	public void wa_AD015_ChangeCustomerAppFeatureControl_01() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_ChangeCustomerAppFeatureControl_01");
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			
			assertion =  new Assertions(extentTest);
			
			extentReport.info("100 S The actor logs into the system and clicks on Customer name listed under customer list");
			loginPage.login(login,"internaluser");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			
			extentReport.info("120 S Click on 'Change' button to navigate to Change Customer page");
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentTest = extentReport.info("200 V Verify that the Change customer page contains following components related to EP Application Feature Controls",new String[] {"ClncAcct6812"});
			changeCustomerProfilePage.scrollToView(changeCustomerProfilePage.applicationControlSection_OR);
			extentReport.reportScreenShot("Application feature control section");
			
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.exportTransmissionFlag_OR, changeCustomerProfilePage.exportTransmissionFlag_S), "Export transmission data files Flag is displayed in Change Customer Page");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.orderTransmitterFlag_OR, changeCustomerProfilePage.orderTransmitterFlag_S), "Order Transmitter Flag is displayed in Change Customer Page");
			assertion.assertEquals(expectedxportTOEHROptions, changeCustomerProfilePage.getExportToEHROptions(), "Export to EMR/EHR Option (None/Manual Only/Manual and Automatic) is displayed in Change Customer Page");
			
			extentReport.info("240 S Change values of above listed EP Application Feature controls");
			changeCustomerProfilePage.applicationFeatureControlVerification(customer);
			
			String userId = changeCustomerProfilePage.getUserId();
			
			extentReport.info("345 S Click on Save button");
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.clickOKButton();
			
			
			//Database Validation
			extentTest = extentReport.info("350 V Verify in database that values changed in above steps are correctly updated in database");
			dataBaseConnector.getConnection();
			
			String query = "select (SELECT code_desc FROM lookup.code cd where cd.code_id=c.allow_emr_download_cd and cd.code_qualifier ='Allow_EMR_Download_Cd') "
					+ "as allow_emr_download,order_transmitter_flg as show_export_session_flg,order_transmitter_flg "
					+ "from customers.customer c, users.user_record ur, users.customer_account ca "
					+ "where c.customer_id = ca.customer_id and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='" + userId + "'";
			
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);
			
			while (customerRecord.next()) {
				show_export_session_flg = customerRecord.getString("show_export_session_flg");
				order_transmitter_flg = customerRecord.getString("order_transmitter_flg");
				exportToEHR = customerRecord.getString("allow_emr_download");
			}
			
			if (customer.getExportTransmissionData().equalsIgnoreCase("Yes")) {
				assertion.assertEquals("1", show_export_session_flg, "Export Transmission Data Flag is verified");
			} else if (customer.getExportTransmissionData().equalsIgnoreCase("No")) {
				assertion.assertEquals("0", show_export_session_flg, "Export Transmission Data Flag is verified");
			}
			if (customer.getOrderTransmitter().equalsIgnoreCase("Yes")) {
				assertion.assertEquals("1", order_transmitter_flg, "Order Transmitter Flag is verified");
			} else if (customer.getOrderTransmitter().equalsIgnoreCase("No")) {
				assertion.assertEquals("0", order_transmitter_flg, "Order Transmitter Flag is verified");
			}
			
			assertion.assertEquals(customer.getElecExport(), exportToEHR, "Export to EHR drop down value is verified");
			
			assertion.assertAll();
			
			extentReport.info("400-S- Test case ends");
			
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_ChangeCustomerAppFeatureControl_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_AD015_ChangeCustomerAppFeatureControl_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
	
	}

