package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class WA_AD015_Change_Customer_PageValidation_04 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	DataBaseConnector dataBaseConnector;
	String testName, invalidPostalCode, validPostalCode, updatedPostCode, expOutPostCode, customerName;

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		logger = new Log();
	}

	@Test
	public void wa_AD015_Change_Customer_PageValidation_04() throws Exception { // 1244018
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		softAssert = new Assertions(extentTest);
		assertion = new Assertions(extentTest);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData(testName);
		extentTest.assignAuthor("Author: ChandraMohan");
		try {
			extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
			loginPage.login(login,"internaluser");

			customerName= customer.getCustomerName();
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();

			extentReport.info("200 -S-  Delete the data entered in below fields -Zip/ postal code");
			changeCustomerProfilePage.clearElementInChangeCustomer("ZipPostalCode"); 

			extentReport.info("300-S- Click on save button");
			changeCustomerProfilePage.saveChanges();

			extentReport.info("400- V- Verify that the Change Customer page validates that all the required fields are entered.",new String[] {"ClncAcct6027"}); 

			extentReport.info("450-S- Update country field to USA");
			searchCustomerAndLandInChangeCustomerPage(customerName);
			changeCustomerProfilePage.changeCustomerFieldValue("Country","USA",true);

			extentReport.info("500-S- Enter below invalid data for above mentioned field one at a time. and click on save button.V3C 4X1 2,%1234");

			/*US-InValid Data-1 extentReport.
			searchCustomerAndLandInChangeCustomerPage(customerName);
			invalidPostalCode ="V3C 4X1 2";
			updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(invalidPostalCode); 
			//Comment the below line due to Defect-ChandraMohan.S
			//changeCustomerProfilePage.saveChanges();
			//Adding Temp Code due to defect
			expOutPostCode=CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are NOTvalid. System informs user that Zip code entered above is not valid",new String[] {"ClncAcct6028"});
			assertion.assertEquals(updatedPostCode,expOutPostCode,"Invalid Zip Postal Code verification");
			 */
			assertion.assertEquals(enterAndValidatePostalCode(customerName, "V3C 4X1 2", false),"3412","Invalid Zip Postal Code verification");


			//US-InValid Data-2 extentReport.
			//searchCustomerAndLandInChangeCustomerPage(customerName);
			//invalidPostalCode ="%1234";
			//updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(invalidPostalCode); 
			//changeCustomerProfilePage.saveChanges();
			//expOutPostCode=CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are NOTvalid. System informs user that Zip code entered above is not valid",new String[] {"ClncAcct6028"});

			//assertion.assertEquals(updateAndValidatePostalCode(customerName, "%1234", false),"3412","Invalid Zip Postal Code verification");
			//softAssert(updatedPostCode,expOutPostCode,"Invalid Zip Postal Code verification");
			//extentReport.info("700-S- Enter valid data for zip code (US) field one at a time and click on save button. Note- below sample Zip code are unique.12345, 123456789");
			//assertion.assertEquals(updateAndValidatePostalCode(customerName, "V3C 4X1 2", false),"3412","Invalid Zip Postal Code verification");

			/*US-Valid Data-1 extentReport.
			searchCustomerAndLandInChangeCustomerPage(customerName);
			validPostalCode ="12345";
			updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(validPostalCode); 
			expOutPostCode=CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			changeCustomerProfilePage.saveChanges();
			expOutPostCode=CommonUtils.extractIntAndChar(validPostalCode, 'e');
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] { "ClncAcct6028"});
			assertion.assertEquals(updatedPostCode,expOutPostCode,"Valid Zip Postal Code verification");*/
			/***assertion.assertEquals(updateAndValidatePostalCode(customerName, "12345", false),"12345","Invalid Zip Postal Code verification");****/
			/*US-Valid Data-2 extentReport.
			searchCustomerAndLandInChangeCustomerPage(customerName);
			validPostalCode ="123456789";
			updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(validPostalCode); 
			changeCustomerProfilePage.saveChanges();
			expOutPostCode=CommonUtils.extractIntAndChar(validPostalCode, 'e');
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] {"ClncAcct6028"});
			assertion.assertEquals(updatedPostCode,expOutPostCode,"Valid Zip Postal Code verification"); 

			extentReport.info("900-V- As entered values are valid as per requirement, system should accept it without any error.",new String[] { "CommUI4822" ,"CommUI4823"});

			/****************** NON-US **********************
			//customerName = customerListPage.getAndclickOnFirstCustomerLink();
			searchCustomerAndLandInChangeCustomerPage(customerName);
			changeCustomerProfilePage.changeCustomerFieldValue("Country", "India",false);
			changeCustomerProfilePage.saveChanges();
			changeCustomerProfilePage.selectLegalJurisdiction("Canada");

			//NON-US-Valid Data 1
			searchCustomerAndLandInChangeCustomerPage(customerName);
			validPostalCode = "1234$5";
			updatedPostCode = changeCustomerProfilePage.updateAndgetPostalCode(validPostalCode);
			changeCustomerProfilePage.saveChanges();
			expOutPostCode = CommonUtils.extractInt(validPostalCode);
			extentReport.info("1400 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] { "ClncAcct6028" });
			assertion.assertEquals(updatedPostCode, expOutPostCode, "Valid Zip Postal Code verification");

			//NON-US-Valid Data 2
			searchCustomerAndLandInChangeCustomerPage(customerName);
			validPostalCode = "12345_6789";
			updatedPostCode = changeCustomerProfilePage.updateAndgetPostalCode(validPostalCode);
			expOutPostCode = CommonUtils.extractInt(validPostalCode);
			changeCustomerProfilePage.saveChanges();
			extentReport.info("1400 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] { "ClncAcct6028" });
			assertion.assertEquals(updatedPostCode, expOutPostCode, "Valid Zip Postal Code verification");

			extentReport.info("1500-V- System should accept it without any error, as entered values are valid as per requirement ",new String[] {"CommUI4827"} ,new String[] {"CommUI4828"} );

			//NON-US-Invalid Data 1
			extentReport.info("1100-S-  Enter below invalid data for above mentioned field one at a time. and click on save button.1234567890123456789012345678901,abcdefghijklmnopqrstuvwxyzabcdef");
			//searchCustomerAndLandProfilePage(customerName);
			searchCustomerAndLandInChangeCustomerPage(customerName);
			invalidPostalCode = "12345e6789012";
			updatedPostCode = changeCustomerProfilePage.updateAndgetPostalCode(invalidPostalCode);
			//expOutPostCode = CommonUtils.extractInt(invalidPostalCode);
			expOutPostCode = CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			//expOutPostCode = "";
			//updatedPostCode = "";
			assertion.assertEquals(updatedPostCode, expOutPostCode, "Invalid Zip Postal Code verification");

			//NON-US-Invalid Data 2
			searchCustomerAndLandInChangeCustomerPage(customerName);
			invalidPostalCode = "abcdefghijklmnopqrstuvwxyzabcdef";
			updatedPostCode = changeCustomerProfilePage.updateAndgetPostalCode(invalidPostalCode);
			expOutPostCode = CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			extentReport.info("1200-V- Verify that change Customer page shall validate that all the fields entered are valid.",new String[] { "ClncAcct6028" });
			expOutPostCode = CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			assertion.assertEquals(updatedPostCode, expOutPostCode, "Invalid Zip Postal Code verification");

			extentReport.info("Signing out from the application");
			customerListPage.verifyLogout();
			 */
			extentReport.info("1600-S- Test case ends");

		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	public void searchCustomerAndLandInChangeCustomerPage(String custName) throws Exception {
		if(customerListPage.verifyLandingPage()) {
			customerListPage.searchCustomerAndClick(custName);

		}
		else {
			changeCustomerProfilePage.clickOnAllAbbottCustomers();
			customerListPage.searchCustomerAndClick(custName);
		}
		customerProfilePage.goToChangeCustomerProfilePage();
	}

	public String updateAndValidatePostalCode(String customerName, String postalCode, Boolean validData) throws Exception {
		searchCustomerAndLandInChangeCustomerPage(customerName);
		updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(postalCode); 
		if(validData) {
			changeCustomerProfilePage.savePositiveChanges();
		}else{
			changeCustomerProfilePage.saveChanges();			
		}
		return changeCustomerProfilePage.validatePostalCode(postalCode);
	}

	public void enterPostalCode(String customerName, String postalCode, Boolean validData) throws Exception {
		searchCustomerAndLandInChangeCustomerPage(customerName);
		updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(postalCode); 
		if(validData) {
			changeCustomerProfilePage.savePositiveChanges();
		}else{
			changeCustomerProfilePage.saveChanges();			
		}
	}

	public String enterAndValidatePostalCode(String customerName,String postalCode, Boolean validData) throws Exception {
		boolean expOutcome= false;
		String expStoredVal="No Warning Message Appeared";
		String validPostCode="";
		searchCustomerAndLandInChangeCustomerPage(customerName);
		updatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(postalCode); 
		changeCustomerProfilePage.clickSaveButton();
		if(validData) {
			changeCustomerProfilePage.clickOKButton();
		}else{
			if(changeCustomerProfilePage.validateMandatoryToaster()) {
				validPostCode=changeCustomerProfilePage.validatePostalCode(postalCode);
				if(validPostCode.contentEquals(updatedPostCode)) {
					expOutcome= true;
					expStoredVal =updatedPostCode;
				}else {
					expOutcome= false;
					expStoredVal =validPostCode;
				}
			}
		}
		//return expOutcome;
		return expStoredVal;
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}