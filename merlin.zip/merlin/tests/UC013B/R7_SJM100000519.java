package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class R7_SJM100000519 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	AddCustomerPage addcustomer;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;
	private Log logger = new Log();
	int deleted_flg;

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addcustomer=new AddCustomerPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test
	public void wa_ChangeCustomer_Clinic_Main_contact_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("SJMAdmin");
		//login = testDataProvider.getLoginData("Resettest");
		//login = testDataProvider.getLoginData("MFA");
		customer = testDataProvider.getCustomerData("AddCustomer");
		extentTest.assignAuthor("Author - Mohan Sekar");
            extentReport.info("Adding a Customer to check delete Customer");
			loginPage.login(login);
			addcustomer.addcustomerclick();
			addcustomer.loading();
			//String CustomerName=AddCustomerPage.randomCustomerNameWithDate();
			//customer.setCustomerName(CustomerName);
			
			addcustomer.addcustomer(customer);
			addcustomer.addcustomersave();
			addcustomer.addcustomerurl();
			
            assertion = new Assertions(extentTest);
            extentReport.info("100-S-The actor (SJM Enrollment Administrator) is logged into the system and navigates to page AD001(Customer List)");
            
			extentReport.info("200-V-The system Page AD001 is displayed with a list of customers.</br>300-S-The actor The actor clicks a link in the Customer Name column");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			extentReport.info("400-V-The system The system displays page AD005 (Customer Profile) with the customer's details pre-populated.");
			customerListPage.changecheck();
			extentReport.info("500-S-The actor The actor clicks the Change or the Change & delete customers menu item on AD005.");
			customerListPage.change();
			extentReport.info("600-V-The system The system displays page AD015 (Change Customer) with most of the input fields becoming editable (see UI Spec).");
			extentReport.info("700-S-The actor The actor clicks the Delete button on page AD015");
			changeCustomerProfilePage.validateAndDeleteCustomer();
			extentReport.info("800-V-The system The system displays the dialogue AD 800 with text defined by <msg.ad800.text> (\"I'm ready to delete {0} for you.{n}{n}Shall I go ahead?\").<ClncAcct1678>");
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD800(customer.getCustomerName());
			extentReport.info("900-S-The actor The actor clicks the OK button on the confirm box");
			changeCustomerProfilePage.AcceptDeletePopUp();
			extentReport.info("1000-V-The system The system closes dialogue AD 800, then displays dialogue AD 802 with text defined by <msg.ad802.text> (\"Okay. Your {0} will be deleted.\"). <ClncAcct1678>");
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD802();
			extentReport.info("1100-S-The actor The actor clicks the OK button on the AD802 alert box");
			changeCustomerProfilePage.AcceptDeletePopUp();
			extentReport.info("1200-V-The system -- The system marks the Customer record as deleted (Deleted_flg in the CUSTOMER table), -- The system marks all the associated User_Record records as deleted (Deleted_flg in the USER_Record table), -- The system also sets the delete_Flg = 1 for all the authorized applications for the customer in the Customer_Application table. -- The system also sets Patient_Application_Status_Cd=R for these Customer_Applications in Customer_Application_Patient for all patients/applications associated with the customer (Customer_Application_Patient.Patient_Application_Status_Cd). -- Note: Covers all patient enrollments for all applications for that Customer. <ClncAcct229>, <ClncAcct230>, <PCS734> <ClncAcct231>");
			
			
			String usrIdCust1 = customer.getUserid();
			
			dataBaseConnector.getConnection();
			String query = "select deleted_flg from\r\n"
					+ "customers.customer where customer_id= (select customer_id from users.customer_account\r\n"
					+ "where user_record_id = (select user_record_id from users.user_record where logon_user_name ='" + usrIdCust1 + "'))";
					
		
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				deleted_flg = customerRecord.getInt("deleted_flg");
				
			}
			
			softAssert.assertEquals( deleted_flg,1,"Flag value is as expected");
			extentReport.info("1400-V-The system 1. The system displays AD001; 2. the list of customers displays on page AD001 does not include the customer just marked deleted");
			
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
