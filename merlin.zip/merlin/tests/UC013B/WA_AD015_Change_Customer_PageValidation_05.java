package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

public class WA_AD015_Change_Customer_PageValidation_05 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	ViewCustomerPage viewCustomerPage;
	QueryResults queryResults;
	private Log logger = new Log();
	List<String> stateProvinceList = new ArrayList<String>();
	Map<String, String> stateProvinceValue = new HashMap<String, String>();
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		queryResults = new QueryResults();
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
	}
	
	@Test
	public void wa_AD015_Change_Customer_PageValidation_05() throws Exception {  
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_Change_Customer_PageValidation_05");
		
		Collections.addAll(stateProvinceList, customer.getStateProvince1(), customer.getStateProvince2(), customer.getStateProvince3(), customer.getStateProvince4(), customer.getStateProvince5(), customer.getStateProvince6(), customer.getStateProvince7(), customer.getStateProvince8());
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			assertion =  new Assertions(extentTest);	
			extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
			loginPage.login(login,"internaluser");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			
			String userId = customerProfilePage.getUserId();
			
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentReport.info("200-S- Update country field to any value other that USA"+"<br>"+"300-S-  Enter below valid data for state/province - "+stateProvinceList.get(0));
			
			changeCustomerProfilePage.setNonUSCountryAndJurisdiction(customer);
			customer.setStateProvince(stateProvinceList.get(0));
			changeCustomerProfilePage.changeCustomer(customer);
			
			extentReport.reportScreenShot("Country is updated and State/Province is updated as "+stateProvinceList.get(0));
			String stateProvince = changeCustomerProfilePage.getAttributeWithReport(changeCustomerProfilePage.stateProvinceTextField_OR,"value", changeCustomerProfilePage.stateProvinceTextField_S);
			int length = stateProvince.length();
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.clickOKButton();
			changeCustomerProfilePage.clickOKButton();
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.clickOKButton();
			
			String query = "select ca.state_province FROM customers.customer c ,customers.customer_address ca, users.user_record ur, users.customer_account ca2 "
					+ "where c.customer_address_id = ca.customer_address_id and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId+"'";
			
			stateProvinceValue = queryResults.readStateProvince(query);
			
			assertion.assertEquals(stateProvinceValue.get("state_province"), stateProvince, "State/ Province value verification");
			
			extentReport.info("400-V- Verify that the system does not allow entry of more than 30 characters in the State/Province field",new String[] {"ClncAcct6028"});
			assertion.assertEquals(length,30,"State/Province field only allow 30 characters");
			
			for(int i=1;i<=stateProvinceList.size()-1;i++) {
			stateProvinceValue = null;
			extentReport.info("500-S-  Enter below valid state/province data for one at a time and click on save button - "+stateProvinceList.get(i));
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.setNonUSCountryAndJurisdiction(customer);
			customer.setStateProvince(stateProvinceList.get(i));
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();
			extentTest = extentReport.info("600 -V-Verify that change Customer page validates that all the fields entered are valid"+"<br>"+"700-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4748", "CommUI4747"});
			assertion.assertEquals("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "As entered values are valid as per requirement system should accept it without any error");
			changeCustomerProfilePage.clickOKButton();
			changeCustomerProfilePage.clickOKButton();
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.clickOKButton();
			customerListPage.loadingWithoutReport();
			
			stateProvinceValue = queryResults.readStateProvince(query);			
			assertion.assertEquals(stateProvinceValue.get("state_province"), stateProvinceList.get(i), "State/ Province value verification");
			
			}
			assertion.assertAll();
			
			
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_05 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_05 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
}