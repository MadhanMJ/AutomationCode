package com.test.qa.ui.tests.UC013B;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class ClinicAccountAdmin_TC100101301033_M2_EP extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	DataBaseConnector dataBaseConnector;
	String recordPatientData , allowMobileDirectAlert;
	String show_export_session_flg,order_transmitter_flg, exportToEHR;
	String show_export_session_flgbu,order_transmitter_flgbu, exportToEHRbu;
	ArrayList<String> clinicFeatures = new ArrayList<>();
	Log logger;
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		logger =  new Log();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector =  new DataBaseConnector();
	}
	
	@Test(groups= {"Regression"})
	public void WA_AD015_Change_Customer_AppFeatureControl_M2_EP() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
        extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
        login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("ClinicAccountAdmin_TC100101301033_M2_EP");
		extentTest.assignAuthor("Author - Mohan Sekar");

		try {
			
			Assertions assertion =  new Assertions(extentTest);
			extentReport.info("100-S-The actor logs into the system and clicks on Customer name listed under customer list.");
			loginPage.login(login,"internaluser");
			System.out.println(customer);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			String defaultValue=changeCustomerProfilePage.getText(changeCustomerProfilePage.exportToEHRDropDownvalue);
			
			extentReport.info("120-S- Click on 'Change' button to navigate to Change Customer page.");			
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentTest = extentReport.info("200-V- Verify that the Change customer page contains following components related to EP Application Feature Controls</br>Export transmission data files Flag - controls whether or not clinic can export transmission archive data</b>Export to EMR/EHR Option (None/Manual Only/Manual and Automatic)</b>Set default for Order Transmitter to ON Flag - controls clinic's ability to Order Transmitter",new String[] {"ClncAcct6812", "CommUI8460"});
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.isElementPresent(changeCustomerProfilePage.exportTransmissionFlag_OR), extentReport, "Export transmission data files Flag - controls whether or not clinic can export transmission archive data");
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.isElementPresent(changeCustomerProfilePage.orderTransmitterFlag_OR), extentReport, "Set default for Order Transmitter to ON Flag - controls clinic's ability to Order Transmitter");
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.isElementPresent(changeCustomerProfilePage.exportToEHRDropDown_OR), extentReport, "export To EHR DropDown");
			
			
			List<String> EHRoption=changeCustomerProfilePage.getExportToEHROptions();
			System.out.print(EHRoption);
			 List<String> actualOptions = new ArrayList<String>();
			   actualOptions.add("No Export");
				actualOptions.add("Manual");
				actualOptions.add("Auto/manual");
				
				boolean isEqual = EHRoption.equals(actualOptions);
				assertion.assertEquals(true, isEqual,  "export To EHR DropDown Value are same as per DOORS");
				extentTest = extentReport.info("240-S- Change values of above listed EP Application Feature controls.");
				String userId = changeCustomerProfilePage.getUserId();
				
				String querybu = "select (SELECT code_desc FROM lookup.code cd where cd.code_id=c.allow_emr_download_cd and cd.code_qualifier ='Allow_EMR_Download_Cd') "
						+ "as allow_emr_download, show_export_session_flg,order_transmitter_flg "
						+ "from customers.customer c, users.user_record ur, users.customer_account ca "
						+ "where c.customer_id = ca.customer_id and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='" + userId + "'";
				dataBaseConnector.getConnection();
				ResultSet customerRecordbu = dataBaseConnector.executeQuery(querybu);
				
				while (customerRecordbu.next()) {
					 show_export_session_flgbu = customerRecordbu.getString("show_export_session_flg");
					order_transmitter_flgbu = customerRecordbu.getString("order_transmitter_flg");
					 exportToEHRbu = customerRecordbu.getString("allow_emr_download");
				}
				System.out.println("Mohan"+exportToEHRbu);
				System.out.println(userId);
				boolean  Exporttransmissiondatafiles= changeCustomerProfilePage.getCheckboxvalue(changeCustomerProfilePage.exportTransmissionCheckBoxclick,"aria-checked");
			   changeCustomerProfilePage.checkboxselect(changeCustomerProfilePage.exportTransmissionCheckBoxclick,Exporttransmissiondatafiles,changeCustomerProfilePage.exportTransmissionclick);
				
				  
				
				boolean  orderTransmitter= changeCustomerProfilePage.getCheckboxvalue(changeCustomerProfilePage.orderTransmitterCheckBoxclick,"aria-checked");
				changeCustomerProfilePage.checkboxselect(changeCustomerProfilePage.orderTransmitterCheckBoxclick,Exporttransmissiondatafiles,changeCustomerProfilePage.orderTransmitterclick);
				  
					changeCustomerProfilePage.EHRDropdownSelectoption(exportToEHRbu);
					
					extentTest = extentReport.info("260-S- Click on Save button");
					changeCustomerProfilePage.clickSaveButton();
					changeCustomerProfilePage.clickOKButton();
					
					extentTest = extentReport.info("400-V- Verify in database that values changed in above steps are correctly updated in database.",new String[] {"ClnccAcct222"});
					String query = "select (SELECT code_desc FROM lookup.code cd where cd.code_id=c.allow_emr_download_cd and cd.code_qualifier ='Allow_EMR_Download_Cd') "
							+ "as allow_emr_download, show_export_session_flg,order_transmitter_flg "
							+ "from customers.customer c, users.user_record ur, users.customer_account ca "
							+ "where c.customer_id = ca.customer_id and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='" + userId + "'";
					dataBaseConnector.getConnection();
					ResultSet customerRecord = dataBaseConnector.executeQuery(query);
					
					while (customerRecord.next()) {
						show_export_session_flg = customerRecord.getString("show_export_session_flg");
						order_transmitter_flg = customerRecord.getString("order_transmitter_flg");
						exportToEHR = customerRecord.getString("allow_emr_download");
					}
					
					
					if (!show_export_session_flgbu.equals(show_export_session_flg)) {
						extentReport.pass("Export Transmission Data Flag is verified");
					} else  {
						extentReport.fail("Export Transmission Data Flag is verified");
					}
					if (!order_transmitter_flgbu.equals(order_transmitter_flg)) {
						extentReport.pass( "Order Transmitter Flag is verified");
					} else  {
						extentReport.fail( "Order Transmitter Flag is verified");
					}
					System.out.println(defaultValue);
					System.out.println(exportToEHR);
					if (!defaultValue.equals(exportToEHR)) {
						extentReport.pass( "exportToEHR dropdown verified");
					} else  {
						extentReport.fail( "exportToEHR dropdown verified");
					}
					//assertion.assertEquals(Expected, exportToEHR, "Export to EHR drop down value is verified");
					
					extentReport.info("480-S- Test case ends");
					
		
		} catch (AssertionError e) {
			extentTest = extentReport.fail( "ClinicAccountAdmin_TC100101301033_M2_EP is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		} catch (Exception e) {
			extentTest = extentReport.fail( "ClinicAccountAdmin_TC100101301033_M2_EP is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
	//	customerListPage.verifyLogout();
		saintResult(result,extentTest);
	}
	
	

}
