package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

import junit.framework.Assert;

public class UC013B_A01_02 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	DataBaseConnector dataBaseConnector;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle,deleted_flag;
	private Log logger = new Log();
	QueryResults queryResults;
	List<String> patientStatus = new ArrayList<String>();
	List<String> clinicUserStatus = new ArrayList<String>();
	Map<String, String> userRecord = new HashMap<String,String>();

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		queryResults = new QueryResults();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test
	public void uC013B_A01_02_DeleteCustomer() throws Exception {
		//Testcase Id- 1243601
		//Testcase name - UC013B-A01-02
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("UC013B_A01_02");
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		try {
			
			Assertions softAssert =  new Assertions(extentTest);
			
			extentReport.info("100 S The actor (SJM Enrollment Administrator) logs into the system and navigates to page Customer List");
			loginPage.login(login);

			extentReport.info("200 S The actor clicks a link in the Customer Name column (Customer A) so that customer profile page is displayed with the customer's details pre-populated");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			
			String userId = changeCustomerProfilePage.getUserId();
			
			extentReport.info("300 S The actor clicks the Delete button");
			customerProfilePage.clickDeleteButton();
			
			extentReport.info("400 V Verify that the system shall provide the capacity to delete the customer", new String[] {"ClncAcct217","ClncAcct6000"});
			softAssert.assertEquals(customerProfilePage.getText(customerProfilePage.deletePopUpContent),"I'm ready to delete "+customer.getCustomerName()+" for you.\nShall I go ahead?", "System provides the capacity to delete the customer");
			customerProfilePage.clickOKButton();
			customerProfilePage.clickOKButton();
						
			extentTest = extentReport.info("500 V Verify in database that the System marks the Customer record (CustomerA) as deleted", new String[] {"ClncAcct229"});
		
			String query = "select deleted_flg from users.user_record where logon_user_name='"+userId+"'";
			
			userRecord = queryResults.deletedUserRecord(query);
			softAssert.assertEquals(userRecord.get("deleted_flg"),"1", "Verified whether the system marks Customer record as deleted");
			
			/*
			extentReport.info("600 V Verify in database that the System marks all the Customer_Accounts  and Users for the deleted Customer (UserP) as deleted", new String[] {"ClncAcct230"});
			//Since the user data is mocked in Clinician login, newly created users are not getting added for the customer. So this step cannot be verified until the mock data is removed.
			String query2 = "select deleted_flg from users.user_record ur,users.customer_account ca,customers.customer c,customers.customer_application cap,patients.customer_application_patient cap2 "
					+ "where cap2.customer_application_id = cap.customer_application_id "
					+ "and cap.customer_id = c.customer_id and c.customer_id = ca.customer_id and "
					+ "ca.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId+"'";
			
			ResultSet clinicUserRecord = dataBaseConnector.executeQuery(query2);
			while(clinicUserRecord.next()) {
				clinicUserStatus.add(clinicUserRecord.getString("deleted_flg"));
			}
			
			for (String clinicUserStatusValue: clinicUserStatus) {
				softAssert.assertEquals(clinicUserStatusValue, "1", "Clinic user status is verified");
			}			
			*/
			
			extentTest =extentReport.info("700 V Verify in database that the System shall mark all patient enrollments for that Customer as 'released'. It includes all patient enrollments for all applications for that Customer", new String[] {"ClncAcct231"});
			String query1 = "select (SELECT code_desc FROM lookup.code cd where cd.code_id=cap2.patient_application_status_cd) as patient_status "
					+ "from users.user_record ur,users.customer_account ca,customers.customer c,customers.customer_application cap,patients.customer_application_patient cap2 "
					+ "where cap2.customer_application_id = cap.customer_application_id "
					+ "and cap.customer_id = c.customer_id and c.customer_id = ca.customer_id and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId+"'";
			
			
			for (String patientStatusValue: patientStatus) {
				softAssert.assertEquals(patientStatusValue, "Released/Transfer to Another Clinic", "Patient status is verified");
			}

			extentReport.info("800 S Navigate to Customer list page");
			extentReport.reportScreenShot("Customer List page is displayed");
			softAssert.assertTrue(customerListPage.verifyLandingPage(), "Customer List page is displayed");
			
			extentReport.info("900 V Verify that list of customers does not include the customer just marked deleted", new String[] {"ClncAcct229"});
			String searchResult = customerListPage.searchCustomerAndClick(customer.getCustomerName());
			softAssert.assertTrue(searchResult.isEmpty(), "Verified that list of customers does not include the customer just marked deleted");
			softAssert.assertAll(); 
		} catch (AssertionError e) {
			extentReport.fail( "UC013B_A01_02 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "UC013B_A01_02 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		
		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}

}
