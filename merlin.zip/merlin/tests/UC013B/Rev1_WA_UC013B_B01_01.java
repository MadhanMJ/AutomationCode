package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

public class Rev1_WA_UC013B_B01_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;
	private Log logger = new Log();
	QueryResults queryResults;
	Map<String, String> customerResult = new HashMap<String,String>();

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		queryResults = new QueryResults();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression3"})
	public void rev1_WA_UC013B_B01_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("Rev1_WA_UC013B_B01_01");
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");

		try {
			softAssert = new Assertions(extentTest);
			
			extentReport.info("100 S The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page");
			loginPage.login(login,"internaluser");
			
			extentReport.info("200 S The actor searches for customer "+customer.getCustomerName()+" <br> 300 S The actor clicks a link in the Customer Name column so that system displays Customer Profile page with the customer's details pre-populated</br>");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			
			extentReport.info("400 S The actor clicks on Change button"+"<br>"+"420 V Verify that the Change Customer page shall be displayed when an Actor chooses to change a customer"+"<br>450 V Verify that the Change Customer page provides a mechanism for the user to edit customer profile details for an existing customer by 'Change' button",new String[] {"ClncAcct2788","ClncAcct6019"});
			customerProfilePage.goToChangeCustomerProfilePage();
			softAssert.assertTrue(changeCustomerProfilePage.verifyLandingPage(), "Change customer Profile page is displayed");
			
			extentReport.info("500 V Verify that the actor is having the capacity to change customer and most of the input fields becoming editable"+"<br>"+"600 S The actor changes more than one customer details as desired with entering valid values in the fields"+"<br>610 S Actor changes the value of Legal Jurisdiction</br>", new String[] {"ClncAcct217"});
			extentReport.reportScreenShot("Before entering the customer details");
			changeCustomerProfilePage.setNonUSCountryAndJurisdiction(customer);
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Customer details are entered");
			
			String userId = changeCustomerProfilePage.getUserId();
			
			extentReport.info("620 S Actor Clicks on Save button"+"<br>650 V Verify that the Change Customer page provide a mechanism for the user to save the changes through 'Save' button.</br>", new String[] {"ClncAcct6022","ClncAcct5999"});
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("700 V The system validates customer data entered by actor"+"<br>800 V Verify that system confirms to actor that changes are made to customer data by displaying AD802 alert box</br>",new String[] {"ClncAcct220","ClncAcct222"});
			softAssert.assertEquals("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "System confirms to actor that changes are made to customer data by displaying AD802 alert box");
			
			extentReport.reportInfo("900 S The actor clicks the Okay button on the confirm box.");
			changeCustomerProfilePage.clickOKButton();
			
			extentTest = extentReport.info("950 V Verify that system displays alert box AD 821 to inform the user to ensure correct settings are applied for the new jurisdiction", new String[] {"ClncAcct6113"});
			extentReport.reportScreenShot("System displays alert box AD 821");
			softAssert.assertEquals(changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.jurisdictionPopUpContent_OR, changeCustomerProfilePage.jurisdictionPopUpContent_S),true, "System displays alert box AD 821 to inform the user to ensure correct settings are applied for the new jurisdiction");
			
			extentReport.info("960 S Actor clicks Ok button on alert box.");
			changeCustomerProfilePage.clickOKButton();
			
			extentReport.info("970 S System displays Change customer page. Click on Save button.");
			changeCustomerProfilePage.clickSaveButton();
			
			extentTest = extentReport.info("980 V Verify that system confirms to actor that changes are made to customer data by displaying AD802 alert box</br>", new String[] {"ClncAcct222"});
			softAssert.assertEquals("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "System confirms to actor that changes are made to customer data by displaying AD802 alert box");
			
			extentReport.info("990 S The actor clicks the Okay button on the confirm box");
			changeCustomerProfilePage.clickOKButton();
			
			
			//Database Validation
			extentTest = extentReport.info("1000 V Verify in Database that changes made by actor are reflected in database", new String[] {"ClncAcct221"});
			String query = "select ca.city as city,"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.legal_jurisdiction_cd and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction,"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.locale_cd and cd.code_qualifier ='Locale_Cd') as language,area_code as area_code,"
					+ "phone_num as main_phone FROM customers.customer c ,customers.customer_phone cp ,customers.customer_address ca, users.user_record ur, users.customer_account ca2 "
					+ "where c.main_phone_id = cp.customer_phone_id and c.customer_address_id = ca.customer_address_id and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId+"'";
			
			customerResult = queryResults.customerTable(query);			
			
			softAssert.assertEquals( customer.getAreaCode(),customerResult.get("area_code"),"Area code field is verified");
			softAssert.assertEquals( customer.getMainPhone(),customerResult.get("main_phone"),"Phone Number field is verified");
			softAssert.assertEquals( customer.getCity(),customerResult.get("city"), "City field is verified");
			softAssert.assertEquals( customer.getLegalJurisdiction(),customerResult.get("legal_jurisdiction"), "Legal Jurisdiction field is verified");
			softAssert.assertEquals(customer.getClinicLanguage(), customerResult.get("language"), "Clinic Language field is verified");
			
			softAssert.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
}
