package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

public class WA_AD015_Change_Customer_PageValidation_06 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	AddCustomerPage addCustomerPage;
	ExtentTest extentTest;
	Login login;
	Customer customer, addCustomer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	ViewCustomerPage viewCustomerPage;
	public static Log logger = new Log();
	List<String> cityValue = new ArrayList<String>();
	List<String> clinicNameValue = new ArrayList<String>();
	Map<String, String> cityList = new HashMap<String, String>();
	QueryResults queryResults;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() throws Exception {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver,extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		queryResults = new QueryResults();
		customer = new Customer();
		addCustomer = new Customer();
		customer = testDataProvider.getCustomerData("WA_AD015_Change_Customer_PageValidation_06");
		addCustomer = testDataProvider.getCustomerData("Rev1_WA_AD001_CustomerListAndSortableColumnHeader");
		Collections.addAll(cityValue,customer.getCityValue1(), customer.getCityValue2(), customer.getCityValue3(), customer.getCityValue4(), customer.getCityValue5(), customer.getCityValue6());
		Collections.addAll(clinicNameValue,customer.getClinicNameValue1(), customer.getClinicNameValue2(), customer.getClinicNameValue3(), customer.getClinicNameValue4(), customer.getClinicNameValue5(), customer.getClinicNameValue6());
	}
	
	@Test(groups= {"Regression3"})
	public void wa_AD015_Change_Customer_PageValidation_06() throws Exception {  
		//Test case Id - 1244020
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			
				assertion =  new Assertions(extentTest);	
				extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
				loginPage.login(login, "internaluser");
				String customerName=customer.getCustomerName();

				customerListPage.searchCustomerAndClick(customerName);
				String userId = customerProfilePage.getUserId();
				
				customerProfilePage.goToChangeCustomerProfilePage();
				assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer page is displayed");
				
				extentTest = extentReport.info("200-S-  Try entering below invalid data for Clinic city field one at a time-"+cityValue.get(0));
				customer.setCity(cityValue.get(0));
				changeCustomerProfilePage.changeCustomer(customer);
				
				String city = changeCustomerProfilePage.getAttribute(changeCustomerProfilePage.city,"value");
				int length = city.length();
				extentReport.reportScreenShot("Clinic city field is updated with more than 30 characters");
				changeCustomerProfilePage.clickSaveButton();
				changeCustomerProfilePage.clickOKButton();
				
				String query = "select ca.city FROM customers.customer c ,customers.customer_address ca, users.user_record ur, users.customer_account ca2 "
						+ "where c.customer_address_id = ca.customer_address_id and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId+"'";
				
				cityList = queryResults.readCity(query);
				
				assertion.assertEquals(cityList.get("city"),city, "City value verification");
				
				extentReport.info("300-V- Verify that application doesn't accept more than 30 characters for city field",new String[] {"ClncAcct6028"});
				assertion.assertEquals(length,30,"Clinic city field only allow 30 characters");
				
				for(int i=1;i<=cityValue.size()-1;i++) {
					extentTest = extentReport.info("400-S-  Enter below valid city data for one at a time and click on save button - "+cityValue.get(i));
					cityList = null;
					customer.setCity(cityValue.get(i));
					customerListPage.searchCustomerAndClick(customerName);
					customerProfilePage.goToChangeCustomerProfilePage();
					changeCustomerProfilePage.changeCustomer(customer);
					extentReport.reportScreenShot("Clinic City field is updated with "+cityValue.get(i));
					changeCustomerProfilePage.clickSaveButton();
					
					extentTest = extentReport.info("500 -V-Verify that change Customer page validates that all the fields entered are valid."+"<br>"+"600-V- Verify that the entered values are valid as per requirement"+"<br>"+"700-V- Verify that the system should accept it without any error", new String[] {"ClncAcct6028","CommUI4461","CommUI4462"});
					assertion.assertEquals("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "Change Customer page validates if all the fields are having valid values entered");
					//changeCustomerProfilePage.clickPopUpCancelButton();
					changeCustomerProfilePage.clickOKButton();
					
					cityList = queryResults.readCity(query);
					
					assertion.assertEquals(cityList.get("city"), cityValue.get(i), "City value verification");
				}
				
				extentReport.info("800-S-From the customer list, select the same customer and navigate to the Change customer page");
				customerListPage.searchCustomerAndClick(customerName);
				customerProfilePage.goToChangeCustomerProfilePage();
				//assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer page is displayed");
				
				extentTest = extentReport.info("900-S-  Enter below invalid data for Clinic Name field and click on save button - Enter more than 50 characters - "+clinicNameValue.get(0));
				customer.setCity("");
				customer.setCustomerName(clinicNameValue.get(0));
				changeCustomerProfilePage.changeCustomer(customer);
				extentReport.reportScreenShot("Clinic Name field is updated with more than 50 characters");
				String newCustomerName = changeCustomerProfilePage.getAttribute(changeCustomerProfilePage.customerName,"value");
				int customerNameLength = changeCustomerProfilePage.getAttribute(changeCustomerProfilePage.customerName,"value").length();
				changeCustomerProfilePage.clickSaveButton();
				
				extentReport.info("1000-V- Verify that change Customer page shall validate if all the fields are having valid values entered",new String[] {"ClncAcct6028"});
				assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+newCustomerName+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
				changeCustomerProfilePage.clickPopUpCancelButton();
				changeCustomerProfilePage.clickOKButton();
				
				extentReport.info("1100-V- Verify that system doesn't allow to enter more than 50 characters in clinic name field",new String[] {"ClncAcct6023"});
				assertion.assertEquals(customerNameLength,50,"Clinic name field only allow 50 characters");
				
				customerListPage.clickOnAddCustomerButton();
				String newClinicName = addCustomerPage.addCustomerfieldupdate(addCustomer, "Text");
				addCustomerPage.addCustomerSave();
				addCustomerPage.addCustomerConfirmCancel();
				addCustomerPage.clickOkButton();

				//String newClinicName ="CustomerName_PtohK";
				for(int j=1;j<=clinicNameValue.size()-1;j++) {
					extentTest = extentReport.info("1200-S-  Enter below valid data for clinic name field one at a time and click on save button -"+clinicNameValue.get(j));
					customer.setCustomerName(clinicNameValue.get(j));
					int k=j;
					if(k>=2) {
						newClinicName =clinicNameValue.get(k-1); 
					}
					customerListPage.searchCustomerAndClick(newClinicName);
					String userId1 = customerProfilePage.getUserId();
					customerProfilePage.goToChangeCustomerProfilePage();
					changeCustomerProfilePage.changeCustomer(customer);
					extentReport.reportScreenShot("Clinic Name field is updated with "+clinicNameValue.get(j));
					changeCustomerProfilePage.clickSaveButton();
					
					extentTest = extentReport.info("1300 -V-Verify that change Customer page shall validate if all the fields are having valid values entered"+"<br>"+"1400-V- As entered values are valid as per requirement system should accept it without any error", new String[] {"ClncAcct6028","CommUI4466","CommUI4467"});
					assertion.assertEquals("I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "Change Customer page validates if all the fields are having valid values entered");
					//changeCustomerProfilePage.clickPopUpCancelButton();
					changeCustomerProfilePage.clickOKButton();
					
					String query1 = "select c.name FROM customers.customer c ,customers.customer_address ca, users.user_record ur, users.customer_account ca2 "
							+ "where c.customer_address_id = ca.customer_address_id and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId1+"'";
					
					cityList = queryResults.readCityName(query1);
					
					assertion.assertEquals(cityList.get("name"), clinicNameValue.get(j), "City Name verification");
				}
				
				assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_06 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentTest = extentReport.fail( "WA_AD015_Change_Customer_PageValidation_06 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
}