package com.test.qa.ui.tests.UC013B;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

//Author - Alok Kumar
//TC ID - WA_80Rev6_UC013_SecCommControl_02_SingleURL
public class WA_80Rev6_UC013_SecCommControl_02_SingleURL extends CommonUtils {
	

	ViewCustomerPage viewCustomerPage;
	AddCustomerPage addCustomerPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CA_SchedulingAndMessagingPage SchedulingAndMessagingPage;
	CA_ClinicProfilePage ClinicProfilePage;
	LoginPageWithPOJO loginPage;
	Login loginClinicUser_withICMDevice;
	Login loginAdminUser;
	Login loginClinicUser_withICDDevice;
	Login loginClinicUser_with_ICD_And_ICMDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {
		
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		clinicianHomePage = new ClinicianHomePage(driver,extentReport);
		addCustomerPage = new AddCustomerPage(driver,extentReport);
		ClinicProfilePage = new CA_ClinicProfilePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		SchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginClinicUser_withICMDevice = new Login();
		loginClinicUser_withICDDevice = new Login();
		loginClinicUser_with_ICD_And_ICMDevice = new Login();
		loginAdminUser = new Login();
		testDataProvider = new TestDataProvider();
	}
  @Test
  public void WA_80Rev6_UC013_SecCommControl_02_SingleURL() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		loginClinicUser_withICDDevice = testDataProvider.getLoginData("EP_Clinic_B1");
		loginClinicUser_withICMDevice = testDataProvider.getLoginData("EP_Clinic_A");
		loginClinicUser_with_ICD_And_ICMDevice = testDataProvider.getLoginData("EP_Clinic_C");
		loginAdminUser = testDataProvider.getLoginData("SJMAdmin3");
		extentTest.assignAuthor("Author: Alok Kumar");
		
		try {
			Assertions assertion =  new Assertions(extentTest);	
			extentReport.info("100 S Log into application with SJM admin account (i4_pcsadmin) and click on Add customer. ");
			loginPage.login(loginAdminUser);
			addCustomerPage.addcustomerclick();
			Thread.sleep(3000);
			assertion.assertEqualsWithReporting(true,addCustomerPage.verifyLandingPage(),extentReport,"Add Customer Page is displayed");
			
			extentReport.info("200 S Set country as any non-Safe harbor country.");
			addCustomerPage.selectCountry("USA");
			extentReport.reportScreenShot( "User able to Selct non safe harbour country");
			
			extentReport.info("300 V Verify that below checkboxes is unselected by default\n"
					+ "Secure Communication Control for all emails and messages\n"
					+ "Secure Communication control for clinic level control of Contact a Colleague emails\n"
					+ "Secure Communication control for clinic level control of Unpaired Transmitter emails");
			addCustomerPage.VerifyCheckBox("allEmailsAndMessagesCheckBox");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfContactAColleagueEmailsCheckBox");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfUnpairedTransmitterEmails");
			extentReport.reportScreenShot( "User able to Verify that checkboxes is unselected by default");
			
			extentReport.info("400 S Enter valid data in all mandatory fields and add this customer record.");
			addCustomerPage.addCustomer("Customet","007","Direct","New Jersy","1","07","12345678","USA","alok.kumar6@abbott.com","(GMT-12:00) International Date Line West","Canada","English","12345678","12345678","Test01","Tester","alok.kumar6@abbott.com","");
			extentReport.reportScreenShot( "User able to add customer");
			
			extentReport.info("500 S Logout and login application with newly created customer and navigate to EP Clinic Profile page");
			appHomeTopNavPage.clickSignOutLink();
		//	loginPage.login(loginClinicUser);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.clickUserProfile();
			assertion.assertEqualsWithReporting(true,ClinicProfilePage.verifyLandingPage(),extentReport,"Clinic Profile Page is displayed");
			
			extentReport.info("600 S Click on edit button");
			ClinicProfilePage.clickEditButton();
			assertion.assertEqualsWithReporting(true,ClinicProfilePage.verifyLandingPage(),extentReport,"Clinic Profile Page is displayed");
			extentReport.reportScreenShot( "User able to click on edit button");
			
			extentReport.info("700 V Verify that below checkbox is default active and selected\n"
					+ "‘Include patient information in Direct Alert emails and text messages’", new String[] {"ClncAcct6104"});
			ClinicProfilePage.VerifyCheckBox();
			extentReport.reportScreenShot( "checkbox is default active and selected\n"
					+ "‘Include patient information in Direct Alert emails and text messages is verified");
			
			extentReport.info("800 S Uncheck checkbox ‘Include patient information in Direct Alert emails and text messages’ and click save button");
			ClinicProfilePage.clickOnCheckBox();
			ClinicProfilePage.clickSaveButton();
			extentReport.reportScreenShot( "User able to Uncheck checkbox ‘Include patient information in Direct Alert emails and text messages’ and click save button");
			
			extentReport.info("900 V Verify that clinic profile is saved.");
			ClinicProfilePage.VerifyCheckBox();
			extentReport.reportScreenShot( "User able to save the changes");
			
			extentReport.info("1000 S Click Clinic Profile Edit button and Check checkbox ‘Include patient information in Direct Alert emails and text messages’ .");
			ClinicProfilePage.clickEditButton();
			ClinicProfilePage.clickOnCheckBox();
			extentReport.reportScreenShot( "User able to Click Clinic Profile Edit button and Check checkbox ‘Include patient information in Direct Alert emails and text messages");
			
			extentReport.info("1100 V Verify that Confirmation box is displayed.");
			ClinicProfilePage.verifyConfirmation();
			extentReport.reportScreenShot( "User able to Verify that Confirmation box is displayed");
			
			extentReport.info("1200 S Click ‘Cancel’ button");
			ClinicProfilePage.clickCancelButton();
			extentReport.reportScreenShot( "User able to Click ‘Cancel’ button");
			
			extentReport.info("1300 V Verify that dialog box is closed and checkbox '‘Include patient information in Direct Alert emails and text messages’ is unchecked.");
			ClinicProfilePage.verifyDialogBox();
			extentReport.reportScreenShot( "User able to Verify that dialog box is closed and checkbox '‘Include patient information in Direct Alert emails and text messages’ is unchecked.");
			
			extentReport.info("1400 S Check checkbox ‘Include patient information in Direct Alert emails and text messages’ ");
			ClinicProfilePage.VerifyCheckBox();
			extentReport.reportScreenShot( "User able to Check checkbox ‘Include patient information in Direct Alert emails and text messages’");
			
			extentReport.info("1500 V Verify that Confirmation box is displayed.");
			ClinicProfilePage.verifyConfirmation();
			extentReport.reportScreenShot( "User able to Verify that Confirmation box is displayed");
			
			extentReport.info("1600 S Click ‘Continue’ button");
			ClinicProfilePage.clickOnContinue();
			extentReport.reportScreenShot( "User able to Click on ‘Continue’ button");
			
			
			extentReport.info("1700 V Verify that dialog box is closed and checkbox '‘Include patient information in Direct Alert emails and text messages’ is checked.");
			ClinicProfilePage.verifyDialogBox();
			extentReport.reportScreenShot( "User able to Verify that dialog box is closed and checkbox '‘Include patient information in Direct Alert emails and text messages’ is checked.");
			
			extentReport.info("1800 S Logout and login to application with SJM admin account (i4_pcsadmin). Search above created customer and click on it.");
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginAdminUser);
			
			extentReport.info("1900 V Verify Secure communication control section contains-\n"
					+ "Secure Communication Control for all emails and messages\n"
					+ "Secure Communication control for clinic level control of Contact a Colleague emails\n"
					+ "Secure Communication control for clinic level control of Unpaired Transmitter emails",new String[] {"ClncAcct6335"});
			addCustomerPage.VerifyCheckBox("allEmailsAndMessagesCheckBox");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfContactAColleagueEmailsCheckBox");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfUnpairedTransmitterEmails");
			extentReport.reportScreenShot( "User able to Verify that checkboxes is unselected by default");
			
			extentReport.info("2000 S Check below checkboxes.\n"
					+ "Secure Communication control for clinic level control of Contact a Colleague emails\n"
					+ "Secure Communication control for clinic level control of Unpaired Transmitter emails");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfContactAColleagueEmailsCheckBox");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfUnpairedTransmitterEmails");
			extentReport.reportScreenShot( "User able to Verify that checkboxes ");
			
			extentReport.info("2100 S Select Merlin On Demand checkbox and Click on save button");
			ClinicProfilePage.clickOnCheckBox();
			ClinicProfilePage.clickSaveButton();
			extentReport.reportScreenShot( "User able to  Select Merlin On Demand checkbox and Click on save button");
			
			extentReport.info("2200 S Logout and login application with same customer and navigate to EP Clinic Profile page");
			appHomeTopNavPage.clickSignOutLink();
		//	loginPage.login(loginAdminUser);
			
			extentReport.info("2300 V Verify that below checkboxes are displayed-\n"
					+ "Require recipientauthentication to view contact a colleague email\n"
					+ "Require recipientauthentication to view unpaired transmitter email");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfContactAColleagueEmailsCheckBox");
			addCustomerPage.VerifyCheckBox("clinicLevelControlOfUnpairedTransmitterEmails");
			extentReport.reportScreenShot( "User able to Verify that checkboxes ");
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
}
