package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_AD015_Change_Customer_PageValidation_03 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	Map<String, String> customerExistingData = new HashMap<String, String>();
	Map<String, String> customerDataAfterCancel = new HashMap<String, String>();
	public static Log logger = new Log();
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}
	
	@Test
	public void wa_AD015_Change_Customer_PageValidation_03() throws Exception {  //1244017-WA-AD015-Change Customer-page validation-03
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_Change_Customer_PageValidation_03");
		
		extentTest.assignAuthor("Author - GowshalyadeviRathinam");
		
		try {
			assertion =  new Assertions(extentTest);	
			extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
			loginPage.login(login);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentReport.info("200 -S-  Delete the data entered in below fields - Main Phone");
			changeCustomerProfilePage.clearElement("MainPhone");
			extentReport.reportScreenShot("Deleted the data entered in Main Phone field");
			
			extentReport.info("300-S- Click on save button");
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("400- V- Verify that the Change Customer page validates that all the required fields are entered. System informs actor that no data is entered for above mentioned fields", new String[] {"ClncAcct6027"});
			
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("MainPhone"), "This field should not be empty..." , "Mail Phone missing error message verification");			
			extentReport.reportScreenShot("Main Phone missing error message displayed");
			
			extentReport.info("450- S- Update country to USA");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("Country updated as USA");
			
			extentReport.info("500-S-  Enter below invalid data for phone number (US) field one at a time. and click on save button - 1 (empty area city code) 1234567");
			customer.setCountryCode("1");
			customer.setMainPhone("1234567");
			customer.setCountry("");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clearElement("AreaCode");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that user ID address entered above is not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("AreaCode") ,"This field should not be empty...", "MainPhone invalid error message verification");
			extentReport.reportScreenShot("Area code invalid error message displayed");
			
			extentReport.info("500-S-  Enter below invalid data for phone number (US) field one at a time. and click on save button - (empty Country Code) 123 1234567  ");
			customer.setAreaCode("123");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clearElement("CountryCode");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest =extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that Main Phone entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("CountryCode") ,"This field should not be empty...", "MainPhone adddress invalid error message verification");
			extentReport.reportScreenShot("Country Code invalid error message displayed");
			
			extentReport.info("500-S-  Enter below invalid data for phone number (US) field one at a time. and click on save button - 1a34 123 1234567 ");
			customer.setCountryCode("1a3");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that Main Phone entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("CountryCode"), "check format", "MainPhone adddress invalid error message verification");
			extentReport.reportScreenShot("Country Code invalid error message displayed");
			
			extentTest = extentReport.info("500-S-  Enter below invalid data for phone number (US) field one at a time. and click on save button- 1 12 1234567 ");
			customer.setCountryCode("1");
			customer.setAreaCode("12");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that Main Phone entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("AreaCode") ,"enter a valid Main Phone...", "Area Code invalid error message verification");
			extentReport.reportScreenShot("Area Code invalid error message displayed");
			
			extentTest = extentReport.info("500-S-  Enter below invalid data for phone number (US) field one at a time. and click on save button- 1 1234 1234567 ");
			customer.setCountryCode("1");
			customer.setAreaCode("1234");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that Main Phone entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("AreaCode") , "enter a valid Main Phone...","Area Code invalid error message verification");
			extentReport.reportScreenShot("Area Code invalid error message displayed");
			
			extentTest = extentReport.info("500-S-  Enter below invalid data for phone number (US) field one at a time. and click on save button- 1 A12 1234567 ");
			customer.setAreaCode("A12");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that Main Phone entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("AreaCode") ,"check format", "AreaCode invalid error message verification");
			extentReport.reportScreenShot("AreaCode invalid error message displayed");
			
			extentReport.info("700-S-  Enter below valid data for phone number (US) field one at a time. and click on save button - 1 123 1234567");
			customer.setCountryCode("1");
			customer.setAreaCode("123");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();
			
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();	
			
			
			
			extentReport.info("700-S-  Enter below valid data for phone number (US) field one at a time. and click on save button - (1)1231234567");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			customer.setCountryCode("(1)");
			customer.setAreaCode("123");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();
			
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();
			
			
			extentReport.info("700-S-  Enter below valid data for phone number (US) field one at a time. and click on save button - (1)(123)1234567");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			customer.setCountryCode("(1)");
			customer.setAreaCode("(123)");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();
			
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();

			extentReport.info("700-S-  Enter below valid data for phone number (US) field one at a time. and click on save button - 1-123-1234567");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			customer.setCountryCode("(1)");
			customer.setAreaCode("-123-");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();
			
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid."+"<br>"+"900-V- As entered values are valid as per requirement, system should accept it without any error",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();
			
			extentReport.info("1000- S- Update country to value other than USA"+"<br>"+"1100-S-  Enter below invalid data for phone number (OUS) field one at a time. and click on save button -(empty Country Code) 123 1234567");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			customer.setCountry("Japan");
			customer.setAreaCode("123");
			customer.setMainPhone("1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clearElement("CountryCode");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("1200-V- Verify that change Customer page shall validate that all the fields entered are valid.System informs user that user ID address entered above is not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("CountryCode") ,"This field should not be empty...", "CountryCode invalid error message verification");
			extentReport.reportScreenShot("CountryCode invalid error message displayed");
			
			extentReport.info("1100-S-  Enter below invalid data for phone number (OUS) field one at a time. and click on save button -ABC 123 1234567");
			customer.setCountryCode("ABC");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("1200-V- Verify that change Customer page shall validate that all the fields entered are valid.System informs user that user ID address entered above is not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("CountryCode") , "check format", "CountryCode invalid error message verification");
			extentReport.reportScreenShot("CountryCode invalid error message displayed");
			
			extentReport.info("1100-S-  Enter below invalid data for phone number (OUS) field one at a time. and click on save button - 2 123 12 ");
			customer.setCountryCode("2");
			customer.setAreaCode("123");
			customer.setMainPhone("12");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("1200-V- Verify that change Customer page shall validate that all the fields entered are valid.System informs user that user ID address entered above is not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("MainPhone") , "check format", "MainPhone invalid error message verification");
			extentReport.reportScreenShot("MainPhone invalid error message displayed");
			
			extentReport.info("1100-S-  Enter below invalid data for phone number (OUS) field one at a time. and click on save button - 123 123 12A");
			customer.setCountryCode("123");
			customer.setAreaCode("123");
			customer.setMainPhone("12A");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			extentTest = extentReport.info("1200-V- Verify that change Customer page shall validate that all the fields entered are valid.System informs user that user ID address entered above is not valid", new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getErrorMessage("MainPhone") ,"check format", "MainPhone invalid error message verification");
			extentReport.reportScreenShot("MainPhone invalid error message displayed");
			
			extentReport.info("1300-S-  Enter below valid data for phone number (OUS) field one at a time. and click on save button - 3 (empty area-city code) 123 ");
			customer.setCountryCode("3");
			customer.setMainPhone("123");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clearElement("AreaCode");
			changeCustomerProfilePage.clickSaveButton();	

			extentReport.info("1400 -V-Verify that change Customer page validates that all the fields entered are valid."+"<br>"+"1500-V- As entered values are valid as per requirement  system should accept it without any error",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();
			
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentReport.info("1300-S-  Enter below valid data for phone number (OUS) field one at a time. and click on save button - 002 12345 123456789012 - (it will be displayed as  002 12345 123 4567 8901 2)");
			customer.setCountryCode("002");
			customer.setAreaCode("12345");
			customer.setMainPhone("123456789012");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	

			extentReport.info("1400 -V-Verify that change Customer page validates that all the fields entered are valid."+"<br>"+"1500-V- As entered values are valid as per requirement  system should accept it without any error",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();
			
			
			extentReport.info("1300-S-  Enter below valid data for phone number (OUS) field one at a time. and click on save button -+31 (06) 123-123 1234 - (it will be displayed as  31 06 123 1231 234 )");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			customer.setCountryCode("+31");
			customer.setAreaCode("(06) 123");
			customer.setMainPhone("-123 1234");
			changeCustomerProfilePage.changeCustomer(customer);
			changeCustomerProfilePage.clickSaveButton();	

			extentReport.info("1400 -V-Verify that change Customer page validates that all the fields entered are valid."+"<br>"+"1500-V- As entered values are valid as per requirement  system should accept it without any error",new String[] {"ClncAcct6028"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();
			
			extentReport.info("Signing out from the application");
			customerListPage.verifyLogout();
			
			extentReport.info("1600-S- Test case ends");
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_03 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_03 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}
