package com.test.qa.ui.tests.UC013B;

import java.sql.ResultSet;
import java.util.ArrayList;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class WA_AD015_ChangeCustomerDynamicComponents_02 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	DataBaseConnector dataBaseConnector;
	String recordPatientData , allowMobileDirectAlert;
	ArrayList<String> clinicFeatures = new ArrayList<>();
	private Log logger = new Log();
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector =  new DataBaseConnector();
	}
	
	@Test(groups= {"Regression3"})
	public void wa_AD015_ChangeCustomerDynamicComponents_02() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_ChangeCustomerDynamicComponents_02");
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");

		try {
			
			Assertions assertion =  new Assertions(extentTest);
			extentReport.info("100 S The actor logs into the system and clicks on customer name displayed on Customer list");
			loginPage.login(login, "internaluser");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			assertion.assertEqualsWithReporting(true, customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile page is displayed");
			
			extentReport.info("150 S Actor clicks on 'Change' button to navigate to the Change customer page");			
			customerProfilePage.goToChangeCustomerProfilePage();
			
			String userId = changeCustomerProfilePage.getUserId();
			
			extentTest = extentReport.info("200 V Verify that Change Customer page displays the following components:",new String[]{"ClncAcct6044", "ClncAcct6103","ClncAcct6491","ClncAcct6046" ,"ClncAcct6104"});
			changeCustomerProfilePage.scrollToView(changeCustomerProfilePage.allowedApplications_OR);
			assertion.assertEquals("Electrophysiology", changeCustomerProfilePage.getAllowedApplications(),  "1. Application Control:<br>One or more applications to which the clinic is authorized (eg. EP, HF)");
			extentReport.reportScreenShot("Allowed Applications");
			
			changeCustomerProfilePage.scrollToView(changeCustomerProfilePage.recordPatientDataCollectionFlag_OR);
			extentReport.reportScreenShot("General Feature Controls");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.recordPatientDataCollectionFlag_OR, changeCustomerProfilePage.recordPatientDataCollectionFlag_S),  "2. General Feature Controls<ClncAcct6491>:<br>Record patient data collection consent flag: controls whether or not patient data mining consent collected in patient profile");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.allowSmartAlertFlg_OR, changeCustomerProfilePage.allowSmartAlertFlg_S),  "Allow Mobile DirectAlerts� notifications");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.allowCommCenterAccess_OR, changeCustomerProfilePage.allowCommCenterAccess_S),  "Allow access to Communication Center");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.allowComplianceReport_OR, changeCustomerProfilePage.allowComplianceReport_S),  "Allow access to Compliance Report");
			
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.allowDirectCallVoiceFlg_OR, changeCustomerProfilePage.allowDirectCallVoiceFlg_S),  "3.Patient Messaging Feature Controls<ClncAcct6046> <ClncAcct6104>:<br>Allow use of Patient Messaging via Voice Messages Flag");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresentwithoutException(changeCustomerProfilePage.allowDirectCallTextFlg_OR, changeCustomerProfilePage.allowDirectCallTextFlg_S),  "Allow use of Patient Messaging via Text Messages Flag");
			
			extentTest = extentReport.info("300 S Actor tries to remove EP application from Application control through remove link"+"<br>"+"400 V  Verify that Remove link is not displayed restricting the actor from subsequently removing Customer access/authorization to an Application.",new String[] { "ClncAcct334"});
			changeCustomerProfilePage.scrollToView(changeCustomerProfilePage.allowedApplications_OR);
			extentReport.reportScreenShot("Capturing non availability of remove EP application button");
			assertion.assertEquals(true, changeCustomerProfilePage.isElementNotPresent(changeCustomerProfilePage.removeEPApplicationButton), "Remove link is not displayed restricting the actor from subsequently removing Customer access/authorization to an Application");
			
			extentReport.info("500 S Change value of Record patient data collection consent flag, Allow Mobile DirectAlert Notification, Allow use of Patient Messaging via Voice Messages Flag, Allow use of Patient Messaging via Text Messages Flag");
			changeCustomerProfilePage.dynamicComponentsVerification(customer);
			
			extentReport.info("600 S Click on 'Save' button and 'Ok' button of subsequent dialog box");
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.clickOKButton();
			
			//Database Validation
			extentTest = extentReport.info("700 V Verify that customer record in database is updated with new changed values as in step 500",new String[] {"ClncAcct222"});
			dataBaseConnector.getConnection();
			
			String query = "select c.show_data_mining_consent_flg , c.allow_smartalert_flg ,(SELECT code_desc FROM lookup.code cd where cd.code_id=cf.feature_cd and cd.code_qualifier ='Feature_Cd') as clinic_features from customers.customer c, users.customer_account ca, users.user_record ur, customers.customer_application cap, customers.clinic_feature cf "
					+ "where cf.customer_application_id = cap.customer_application_id and cap.customer_id = c.customer_id and c.customer_id = ca.customer_id "
					+ "and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='"+userId+"'";
			
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);

			if (customer.getAllowVoiceMessage().equalsIgnoreCase("No")
					&& customer.getAllowVoiceMessage().equalsIgnoreCase("No")
					&& customer.getRecordPatientDataCollection().equalsIgnoreCase("No")
					&& customer.getAllowMobileDirectAlert().equalsIgnoreCase("No")) {
				assertion.assertFalse(customerRecord.next(),
						"Send Voice Message Feature, Send Text Message feature,Record Patient Data Collection and Allow Mobile Direct Alert Flag  is verified");
			}
			else {
			while (customerRecord.next()) {
				recordPatientData = customerRecord.getString("show_data_mining_consent_flg");
				allowMobileDirectAlert = customerRecord.getString("allow_smartalert_flg");
				clinicFeatures.add(customerRecord.getString("clinic_features"));
			}
			
			
			if (customer.getAllowVoiceMessage().equalsIgnoreCase("Yes")) {
				assertion.assertTrue(clinicFeatures.contains("Send Voice Message Feature"), "Send Voice Message Feature is verified");
			} else if (customer.getAllowVoiceMessage().equalsIgnoreCase("No")) {
				assertion.assertTrue(!clinicFeatures.contains("Send Voice Message Feature"), "Send Voice Message Feature is verified");
			}
			
			if (customer.getAllowTextMessage().equalsIgnoreCase("Yes")) {
				assertion.assertTrue(clinicFeatures.contains("Send Text Message Feature"), "Send Text Message Feature is verified");
			} else if (customer.getAllowVoiceMessage().equalsIgnoreCase("No")) {
				assertion.assertTrue(!clinicFeatures.contains("Send Text Message Feature"), "Send Text Message Feature is verified");
			}
			
			if (customer.getRecordPatientDataCollection().equalsIgnoreCase("Yes")) {
				assertion.assertEquals("1", recordPatientData, "Record Patient Data Collection Flag is verified");
			} else if (customer.getRecordPatientDataCollection().equalsIgnoreCase("No")) {
				assertion.assertEquals("0", recordPatientData, "Record Patient Data Collection Flag is verified");
			}
			
			if (customer.getAllowMobileDirectAlert().equalsIgnoreCase("Yes")) {
				assertion.assertEquals("1", allowMobileDirectAlert, "Allow Mobile Direct Alert Flag is verified");
			} else if (customer.getAllowMobileDirectAlert().equalsIgnoreCase("No")) {
				assertion.assertEquals("0", allowMobileDirectAlert, "Allow Mobile Direct Alert Flag is verified");
			}
			}
			extentReport.pass("800 S Test case ends.");
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_ChangeCustomerDynamicComponents_02 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_AD015_ChangeCustomerDynamicComponents_02 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		//customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
	
	

}
