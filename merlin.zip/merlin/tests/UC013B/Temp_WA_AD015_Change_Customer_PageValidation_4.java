package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
/*ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.CustomerListPage;
import com.test.qa.ui.pageObjects.CustomerProfilePage;
import com.test.qa.ui.pageObjects.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
 */
public class Temp_WA_AD015_Change_Customer_PageValidation_4 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	DataBaseConnector dataBaseConnector;
	String testName, invalidPostalCode, validPostalCode, UpdatedPostCode, expOutPostCode;

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		logger = new Log();
	}

	@Test
	public void wa_AD015_Change_Customer_PageValidation_04() throws Exception { // 1244018
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		softAssert = new Assertions(extentTest);
		assertion = new Assertions(extentTest);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData(testName);
		extentTest.assignAuthor("Author: ChandraMohan");
		try {
			extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
			loginPage.login(login);
			String customerName= customerListPage.searchCustomerAndClick(customer.getCustomerName());
			//	String customerName = customerListPage.getAndclickOnFirstCustomerLink("clicking 1st CustomerName");
			/*customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.clearElementInChangeCustomer("ZipPostalCode","200 -S-  Delete the data entered in below fields - Zip/ postal code"); 
			changeCustomerProfilePage.saveChanges();

			/****************** US *********************/
			searchCustomerAndLandInChangeCustomerPage(customerName);
			changeCustomerProfilePage.changeCustomerFieldValue("Country","USA",true);
			extentReport.info("500-S- Enter below invalid data for above mentioned field one at a time. and click on save button.V3C 4X1 2,%1234");

			/*US-InValid Data-1 extentReport.
			searchCustomerAndLandInChangeCustomerPage(customerName);
			String invalidPostalCode ="V3C 4X1 2";
			UpdatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(invalidPostalCode,"500-S-  Enter invalid data for Zip/ postal code field one at a time. and click on save button"); 
			changeCustomerProfilePage.saveChanges();
			String expOutPostCode=CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are NOTvalid. System informs user that Zip code entered above is not valid",new String[] {"ClncAcct6028"});
			assertion.assertEquals(UpdatedPostCode,expOutPostCode,"Invalid Zip Postal Code verification");

			*/
			searchCustomerAndLandInChangeCustomerPage(customerName);
			invalidPostalCode ="%1234";
			UpdatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(invalidPostalCode); 
			changeCustomerProfilePage.saveChanges();
			expOutPostCode=CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are NOTvalid. System informs user that Zip code entered above is not valid",new String[] {"ClncAcct6028"});
			softAssert(UpdatedPostCode,expOutPostCode,"Invalid Zip Postal Code verification");

			extentReport.info("700-S- Enter valid data for zip code (US) field one at a time and click on save button. Note- below sample Zip code are unique.12345, 123456789");

			//US-Valid Data-1 extentReport.
			//searchCustomerAndLandProfilePage(customerName);
			searchCustomerAndLandInChangeCustomerPage(customerName);
			String validPostalCode ="12345";
			UpdatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(validPostalCode); expOutPostCode=CommonUtils.extractIntAndChar(invalidPostalCode, 'e');
			changeCustomerProfilePage.savePositiveChanges();
			expOutPostCode=CommonUtils.extractIntAndChar(validPostalCode, 'e');
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid. < ClncAcct6028>");
			assertion.assertEquals(UpdatedPostCode,expOutPostCode,"Valid Zip Postal Code verification");

			//US-Valid Data-2 extentReport.
			searchCustomerAndLandInChangeCustomerPage(customerName);
			validPostalCode ="123456789";
			UpdatedPostCode=changeCustomerProfilePage.updateAndgetPostalCode(validPostalCode); 
			changeCustomerProfilePage.savePositiveChanges();
			expOutPostCode=CommonUtils.extractIntAndChar(validPostalCode, 'e');
			extentReport.info("800 -V-Verify that change Customer page validates that all the fields entered are valid.",new String[] {"ClncAcct6028"});
			assertion.assertEquals(UpdatedPostCode,expOutPostCode,"Valid Zip Postal Code verification"); 

			extentReport.info("900-V- As entered values are valid as per requirement <CommUI4822> <CommUI4823> system should accept it without any error.");

			/****************** NON-US **********************/
			/*searchCustomerAndLandInChangeCustomerPage(customerName);
			changeCustomerProfilePage.changeCustomerFieldValue("Country", "India","1000-S- Update coutry field to any value other than USA");
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.selectLegalJurisdiction("Canada","1000-S- Update legalJurisdiction field to any value other than USA");
			*/

			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	public void searchCustomerAndLandInChangeCustomerPage(String custName) throws Exception {
		//extentReport.info("Search Customer again in Listpage And Land in ProfilePage");
		customerListPage.searchCustomerAndClick(custName);
		customerProfilePage.goToChangeCustomerProfilePage();
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}