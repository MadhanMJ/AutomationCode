package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class UC013B_E01_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer, changingCustomer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	private Log logger = new Log();
	List<String> emailValue = new ArrayList<String>();
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		changingCustomer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		emailValue.add("abcds");
	}
	
	@Test
	public void uc013b_E01_01_Invalid_Or_MissingData() throws Exception { //1243605
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("UC013B_E01_01_Invalid_Or_MissingData");
		changingCustomer = customer;
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			
			assertion =  new Assertions(extentTest);
				
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to Change Customer page");
			loginPage.login(login);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change Customer Profile page is displayed");
			
			//Customer Name field verification
			extentReport.info("200-S-The actor clears the value entered in the Customer Name field, fills all other required fields with valid values, and click the Save button AD 808 is displayed");
			
			changeCustomerProfilePage.changeCustomer(changingCustomer);
			changeCustomerProfilePage.clearElement("CustomerName");
			extentReport.reportScreenShot("All the required fields are filled and cleared the value entered in Customer Name field");
			
			changeCustomerProfilePage.clickSaveButton();
			extentTest = extentReport.info("300-V-The Change Customer page validates that all the required fields are entered"+"<br>"+"400-V-The system displays CS 818 (missing required fields) inline message listing out missing field names"+"<br>"+"600-V-The system displays page with entered values", new String[] {"ClncAcct6027","ClncAcct236","CustUI46461"});
			extentReport.reportScreenShot("Customer Name missing error message displayed");
			
			assertion.assertEqualsWithReporting("This field should not be empty...",changeCustomerProfilePage.getErrorMessage("CustomerName") , extentReport, "Customer Name missing error message verification");
			changeCustomerProfilePage.closeErrorPopUp();
			
			
			//Clinic Location field verification
			extentReport.info("200-S-The actor clears the value entered in the Clinic Location field, fills all other required fields with valid values, and click the Save button AD 808 is displayed");
			
			changeCustomerProfilePage.changeCustomer(changingCustomer);
			changeCustomerProfilePage.clearElement("ClinicLocation");
			extentReport.reportScreenShot("All the required fields are filled and cleared the value entered in Clinic Location field");
			
			changeCustomerProfilePage.clickSaveButton();
			extentTest = extentReport.info("300-V-The Change Customer page validates that all the required fields are entered"+"<br>"+"400-V-The system displays CS 818 (missing required fields) inline message listing out missing field names"+"<br>"+"600-V-The system displays page with entered values", new String[] {"ClncAcct6027","ClncAcct236", "CustUI46461"});
			extentReport.reportScreenShot("Clinic Location missing error message displayed");
			
			assertion.assertEqualsWithReporting("This field should not be empty...",changeCustomerProfilePage.getErrorMessage("ClinicLocation") , extentReport, "Clinic Location missing error message verification");
			changeCustomerProfilePage.closeErrorPopUp();
			
			
			//Main Phone field verification
			extentReport.info("200-S-The actor clears the value entered in the Main Phone field, fills all other required fields with valid values, and click the Save button AD 808 is displayed");
			
			changeCustomerProfilePage.changeCustomer(changingCustomer);
			changeCustomerProfilePage.clearElement("MainPhone");
			extentReport.reportScreenShot("All the required fields are filled and cleared the value entered in Main Phone field");
			
			changeCustomerProfilePage.clickSaveButton();
			extentTest = extentReport.info("300-V-The Change Customer page validates that all the required fields are entered"+"<br>"+"400-V-The system displays CS 818 (missing required fields) inline message listing out missing field names"+"<br>"+"600-V-The system displays page with entered values", new String[] {"ClncAcct6027","ClncAcct236","CustUI46461"});
			extentReport.reportScreenShot("Main Phone missing error message displayed");
			
			assertion.assertEqualsWithReporting("This field should not be empty...",changeCustomerProfilePage.getErrorMessage("MainPhone") , extentReport, "Main Phone missing error message verification");
			changeCustomerProfilePage.closeErrorPopUp();
			
			
			//Email field verification
			extentReport.info("200-S-The actor clears the value entered in the Email field, fills all other required fields with valid values, and click the Save button AD 808 is displayed");
			
			changeCustomerProfilePage.changeCustomer(changingCustomer);
			changeCustomerProfilePage.clearElement("Email");
			extentReport.reportScreenShot("All the required fields are filled and cleared the value entered in Email field");
			
			changeCustomerProfilePage.clickSaveButton();
			extentTest = extentReport.info("300-V-The Change Customer page validates that all the required fields are entered"+"<br>"+"400-V-The system displays CS 818 (missing required fields) inline message listing out missing field names"+"<br>"+"600-V-The system displays page with entered values", new String[] {"ClncAcct6027","ClncAcct236","CustUI46461"});
			changeCustomerProfilePage.closeErrorPopUp();
			assertion.assertEqualsWithReporting("This field should not be empty...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email missing error message verification");
			extentReport.reportScreenShot("Email missing error message displayed");
			
			
			//Email field - Invalid Data
			extentReport.info("800 -S The actor enters invalid value for the fields on change customer page - email ID as abcds");
			
			changingCustomer.setEmail(emailValue.get(0));
			changeCustomerProfilePage.changeCustomer(changingCustomer);
			extentReport.reportScreenShot("The actor enters invalid value for Email field on change customer page");
			
			extentReport.info("900- S- Click the Save button");
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("1200 -V- The Change Customer page shall validate that all the fields entered are valid"+"<br>"+"1300 -V System displays the inline message CS 816 to inform actor that data entered in invalid for listed fields", new String[] {"ClncAcct6028","ClncAcct236"});
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email Invalid error message verification");
			extentReport.reportScreenShot("Email invalid error message displayed");
			
			extentReport.info("1400-S- The actor enters valid values in all fields and clicks on save button");
			changingCustomer.setEmail(changingCustomer.getEmailId());
			changeCustomerProfilePage.changeCustomer(changingCustomer);
			extentReport.reportScreenShot("The actor enters valid value for the fields on change customer page");
			changeCustomerProfilePage.clickSaveButton();
			
			extentReport.info("1500-V- Verify that customer list page is displayed and inline message CS 816 is no more displayed", new String[] {"ClncAcct6028"});
			changeCustomerProfilePage.clickOKButton();
			customerListPage.verifyLandingPage();
			extentReport.reportScreenShot("Customer list page is displayed and inline message CS 816 is no more displayed");
			
		} catch (AssertionError e) {
			extentReport.fail( "UC013B_E01_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "UC013B_E01_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}
