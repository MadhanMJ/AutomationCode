package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class UC013B_B01_02 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	Map<String, String> customerExistingData = new HashMap<String, String>();
	Map<String, String> customerDataAfterCancel = new HashMap<String, String>();
	private Log logger = new Log();
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}
	
	@Test(groups= {"Regression3"})
	public void uc013b_B01_02_Cancel_Changing_Customer() throws Exception { //1243604
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("UC013B_B01_02");
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			
			assertion =  new Assertions(extentTest);
				
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to page - Customer List");
			loginPage.login(login,"internaluser");
			
			extentReport.info("200-S-The actor clicks a link in the Customer Name column");
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			
			extentTest = extentReport.info("300-S- The system The system displays page- Customer Profile with the customer's details pre-populated");
			customerProfilePage.verifyLandingPage();
			extentReport.reportScreenShot("Customer Profile page displayed with the customer's details pre-populated");
			
			CommonUtils.extentTest = extentTest;
			List<String> customerObject = new ArrayList<>();
			customerObject.add("CustomerLocation");
			customerObject.add("CustomerMainPhone");
			customerObject.add("CustomerCityText");
			customerObject.add("CustomerCountry");
			customerObject.add("CustomerEmail");
			
			Iterator<String> iter = customerObject.iterator();
			
			while(iter.hasNext()) {
				String key = iter.next();
				customerExistingData.put(key, viewCustomerPage.VerifyCustomerDataInViewMode(key));
			}
			
			extentReport.info("400-S-The actor clicks on 'Change' button");
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentReport.info("600-S-The actor The actor changes some customer details as desired with entering valid values in the fields");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("The actor changed some customer details");
			
			extentReport.info("650-S- Actor clicks on 'Cancel' button");
			changeCustomerProfilePage.clickCancelButton();
			
			extentTest=extentReport.info("700-S-The system The system displays CS801 confirm box");
			assertion.assertEquals("Canceling this operation will cause your changes to be lost.\n\nAre you sure you want to cancel?", changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent), "System confirms to actor that changes are made to customer data by displaying AD802 alert box");
			
			extentReport.info("800-S-The actor The actor clicks the OK button on the confirm box");
			changeCustomerProfilePage.clickOKButton();
			
			extentTest=extentReport.info("900-V-The system discards the changes made to customer profile and displays customer profile page with previously saved customer's details", new String[] {"ClncAcct6020"});
			Thread.sleep(4000);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.verifyLandingPage();
			
			CommonUtils.extentTest = extentTest;
			Iterator<String> iter1 = customerObject.iterator();
			while(iter1.hasNext()) {
				String key = iter1.next();
				customerDataAfterCancel.put(key, viewCustomerPage.VerifyCustomerDataInViewMode(key));
			}
			assertion = new Assertions(extentTest);
			assertion.assertEquals(customerExistingData.get("CustomerCountry"), customerDataAfterCancel.get("CustomerCountry"), "Country drop down is verified");
			assertion.assertEquals(customerExistingData.get("CustomerMainPhone"), customerDataAfterCancel.get("CustomerMainPhone"), "Customer Main Phone is verified");
			assertion.assertEquals(customerExistingData.get("CustomerEmail"), customerDataAfterCancel.get("CustomerEmail"), "Customer Email is verified");
			assertion.assertEquals(customerExistingData.get("CustomerCityText"), customerDataAfterCancel.get("CustomerCityText"), "Customer CityText is verified");
			assertion.assertEquals(customerExistingData.get("CustomerLocation"), customerDataAfterCancel.get("CustomerLocation"), "Customer Location is verified");
			
		} catch (AssertionError e) {
			extentReport.fail( "UC013B_B01_02_Cancel_Changing_Customer is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "UC013B_B01_02_Cancel_Changing_Customer is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
}
