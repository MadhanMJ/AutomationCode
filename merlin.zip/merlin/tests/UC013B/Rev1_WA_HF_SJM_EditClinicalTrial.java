package com.test.qa.ui.tests.UC013B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

import junit.framework.Assert;

public class Rev1_WA_HF_SJM_EditClinicalTrial extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	private Log logger = new Log();

	@BeforeMethod(alwaysRun=true)
	public void initializeObjects() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		customer = new Customer();
	}

	@Test(groups= {"Regression3"})
	public void rev1_WA_HF_SJM_EditClinicalTrial() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		testDataProvider = new TestDataProvider();
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("Rev1_WA_HF_SJM_EditClinicalTrial");
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		try {
			
			Assertions assertion =  new Assertions(extentTest);
			
			extentReport.info("100 S Login to application using admin credentials and select customer from customer List");
			loginPage.login(login, "internaluser");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			assertion.assertEqualsWithReporting(true, customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile page is displayed");
			
			extentTest = extentReport.info("200 V Verify that the Clinical Trial section title displays <label.gb.allwd_clinical.trials> ('Allowed Clinical Trials')");
			clinicalTrailSectionTitle = customerProfilePage.getText(customerProfilePage.allowedClinicalTrailSectionTitle_OR, customerProfilePage.allowedClinicalTrailSectionTitle_S);
			extentReport.reportScreenShot("Allowed Clinical Trials tile is displayed successfully");
			assertion.assertEquals("Allowed clinical trials",clinicalTrailSectionTitle,"Allowed Clinical Trials tile is displayed successfully");
			
			extentReport.info("300 S The actor clicks on Change button");
			customerProfilePage.goToChangeCustomerProfilePage();

			extentTest = extentReport.info("400 V Verify that the allowed clinical trials section is blank and non-editable.(EP only Customer )",new String[] {"ClncAcct6611"});
			int allowedClinicalTrails = changeCustomerProfilePage.getAllowedClinicalTrails().size();
			assertion.assertEquals(0,allowedClinicalTrails,"Allowed clinical trials section is blank for EP only clinic");
			String checkClinincalTrailProperty = changeCustomerProfilePage.getAttributeWithoutReport(changeCustomerProfilePage.addClinincalTrailButton_OR, "disabled", changeCustomerProfilePage.addClinincalTrailButton_S);
			changeCustomerProfilePage.scrollUp();
			
			extentReport.reportScreenShot("Allowed clinical trials section is non editable");
			assertion.assertEquals("true", checkClinincalTrailProperty,"Allowed clinical trials section is non editable");
			extentReport.pass( "Clinical Trail Section validation is completed successfully");
			assertion.assertAll();

		} catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_HF_SJM_EditClinicalTrial is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_HF_SJM_EditClinicalTrial is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		//customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}

}
