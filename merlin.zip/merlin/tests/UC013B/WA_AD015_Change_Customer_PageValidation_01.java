package com.test.qa.ui.tests.UC013B;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_AD015_Change_Customer_PageValidation_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	Map<String, String> customerExistingData = new HashMap<String, String>();
	Map<String, String> customerDataAfterCancel = new HashMap<String, String>();
	private Log logger = new Log();
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}
	
	@Test
	public void wa_AD015_Change_Customer_PageValidation_01() throws Exception {  //1244015
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD015_Change_Customer_PageValidation_01");
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");

		try {
			
			assertion =  new Assertions(extentTest);
				
			extentReport.info("100-S-The actor logs into the system and navigates to the Change customer page");
			loginPage.login(login);
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerProfilePage.goToChangeCustomerProfilePage();
			
			extentReport.info("200 -S-  Delete the data entered in below fields - Email address (for clinic)");
			changeCustomerProfilePage.clearElement("Email");
			extentReport.reportScreenShot("Deleted the data entered in Email address field");
			
			extentReport.info("300-S- Click on save button");
			changeCustomerProfilePage.clickSaveButton();
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("400- V- Verify that the Change Customer page validates that all the required fields are entered. System informs actor that no data is entered for above mentioned fields", new String[] {"ClncAcct6027"});
			assertion.assertEqualsWithReporting("This field should not be empty...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress missing error message verification");			
			extentReport.reportScreenShot("Email address missing error message displayed");
			
			
			extentReport.info("500-S- Enter below invalid data for above mentioned fields one at a time. and click on save button - abcdefghijklmnopqrstuvwxyzabcd(abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.12345678989");
			customer.setEmail("abcdefghijklmnopqrstuvwxyzabcd(abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.12345678989");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abcdefghijklmnopqrstuvwxyzabcd(abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.12345678989 value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that email address entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentReport.info("500-S- Enter below invalid data for above mentioned fields one at a time. and click on save button - abc@sjmcom");
			customer.setEmail("abc@sjmcom");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abc@sjmcom value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest =extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that email address entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentReport.info("500-S- Enter below invalid data for above mentioned fields one at a time. and click on save button - abc123@@#$@sjm.com");
			customer.setEmail("abc123@@#$@sjm.com");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abc123@@#$@sjm.com value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			extentTest = extentReport.info("600-V- Verify that change Customer page shall validate that all the fields entered are valid. System informs user that email address entered above are not valid", new String[] {"ClncAcct6028"});
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentTest = extentReport.info("700-S-  Enter below invalid data for above mentioned fields one at a time. and click on save button.- abcdefghijklmnopqrstuvwxyzabcd_abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.1234567");
			customer.setEmail("abcdefghijklmnopqrstuvwxyzabcd_abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.1234567");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abcdefghijklmnopqrstuvwxyzabcd_abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.1234567 value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
						
			extentTest = extentReport.info("700-S-  Enter below invalid data for above mentioned fields one at a time. and click on save button.- abc.sjm@com");
			customer.setEmail("abc.sjm@com");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abc.sjm@com value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentTest = extentReport.info("700-S-  Enter below invalid data for above mentioned fields one at a time. and click on save button.- abc123@@#$@sjm.com");
			customer.setEmail("abc123@@#$@sjm.com");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abc123@@#$@sjm.com value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentTest = extentReport.info("700-S-  Enter below invalid data for above mentioned fields one at a time. and click on save button.- abcdefghijklmnopqrstuvwxyzabcd*abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.123456");
			customer.setEmail("abcdefghijklmnopqrstuvwxyzabcd*abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.123456");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("abcdefghijklmnopqrstuvwxyzabcd*abcdefghijklmnopqrstuvwxyzabcd@abcdefghijklmnopqrstuvwxyzabcd.123456 value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentTest = extentReport.info("700-S-  Enter below invalid data for above mentioned fields one at a time. and click on save button.- .@");
			customer.setEmail(".@");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot(".@ value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentTest = extentReport.info("700-S-  Enter below invalid data for above mentioned fields one at a time. and click on save button.- @.s");
			customer.setEmail("@.s");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("@.s value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();	
			changeCustomerProfilePage.closeErrorPopUp();
			
			assertion.assertEqualsWithReporting("enter a valid email address...",changeCustomerProfilePage.getErrorMessage("Email") , extentReport, "Email adddress invalid error message verification");
			extentReport.reportScreenShot("Email address invalid error message displayed");
			
			extentReport.info("800-S-  Enter below valid data for above mentioned fields one at a time. and click on save button - p@sjm.com");
			customer.setEmail("p@sjm.com");
			changeCustomerProfilePage.changeCustomer(customer);
			extentReport.reportScreenShot("p@sjm.com value entered in Email Address field");
			changeCustomerProfilePage.clickSaveButton();
			
			extentReport.info("900 -V-Verify that change Customer page shall validate that all the fields entered are valid"+"<br>"+"1000-V- As entered values are valid as per requirement system should accept it without any error",new String[] {"ClncAcct6028","CommUI4552"});
			assertion.assertEquals(changeCustomerProfilePage.getText(changeCustomerProfilePage.okPopUpContent),"I'm ready to change "+customer.getCustomerName()+" for you.\nShall I go ahead?", "Change Customer page validates if all the fields are having valid values entered");
			changeCustomerProfilePage.clickOKButton();				
			
			extentReport.info("Signing out from the application");
			customerListPage.verifyLogout();
			
			extentReport.info("1100-S- Test case ends");
		} catch (AssertionError e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_AD015_Change_Customer_PageValidation_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}
