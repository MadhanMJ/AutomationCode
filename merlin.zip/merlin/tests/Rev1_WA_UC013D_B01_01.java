package com.test.qa.ui.tests;

import java.sql.ResultSet;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.pojo.*;
import com.test.qa.dataBaseTables.CustomerAccount;
import com.test.qa.dataBaseTables.CustomerAddress;
import com.test.qa.dataBaseTables.Location;
import com.test.qa.dataBaseTables.LookUp;
import com.test.qa.dataBaseTables.Phone;
import com.test.qa.dataBaseTables.UserRecord;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class Rev1_WA_UC013D_B01_01 extends CommonUtils {

	//LoginPage loginPage;
	Login login;
	Customer customer;
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	CustomerListPage customerListPage;
	TestDataProvider testDataProvider;
	AddSecondarylocationPage addSecondarylocationPage;
	CustomerProfilePage customerProfilePage;
	private String testName;
	public DataBaseConnector dataBase;

	@BeforeClass
	public void initialize() {
		
		login = new Login();
		customer = new Customer();// New Pojo classes
		testDataProvider = new TestDataProvider();
		extentReport = new ExtentReport(driver,extentReport);
		driver = initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		addSecondarylocationPage = new AddSecondarylocationPage(driver, extentReport);
	}

	@Test
	public void addSecondaryLocation() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		//CommonUtils.iteration = iteration;
		extentTest = extentReport.initiateTest(testName);
		try {
			login = testDataProvider.getLoginData("SJMAdmin");
			customer = testDataProvider.getCustomerData("Rev1_WA_UC013D_B01_01");// getting the data
			

			loginPage.login(login); 
			System.out.println("Entered username pwd");
			Thread.sleep(10000);

			customerListPage.goTo_CustomerProfilePage(customer.getCustomerName());
			customerProfilePage.goToAddSecondaryLocationPage();
			addSecondarylocationPage.addSecondaryLocationValue(customer.getSecondaryLocation(), false);
			customerListPage.launchUrl();
			customerListPage.searchCustomer(customer.getCustomerName());
			Thread.sleep(5000);
			boolean recordExists = customerListPage.modifiedCustomerPresence(customer.getCustomerName(), customer.getSecondaryLocation());
			System.out.println("" + recordExists);
			//boolean recordExists = addSecondarylocationPage.secLocValueEmptyErrorMsg();
			System.out.println("RecordExists/ Appeared Actually -->"+recordExists);
			Thread.sleep(4000);
			Assert.assertEquals(true,recordExists,"Updated Customer  with new Add secondaryLocation is available");
			extentReport.reportPass("Updated Customer  with new Add secondaryLocation is available");

		} catch (Exception e) {
			extentReport.reportFail("Add Secondary Location functionality is not completed successfully");
			e.printStackTrace();
			throw e;
		}
	}

	@AfterClass
	public void shutdown() {
		driver.close();
	}
}
