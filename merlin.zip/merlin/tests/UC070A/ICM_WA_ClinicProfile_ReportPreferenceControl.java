package com.test.qa.ui.tests.UC070A;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vrushali Hitendra Barhate
 * Test Case: ICM_WA_ClinicProfile_ReportPreferenceControl
 * Report: Dummy xpaths
 */
public class ICM_WA_ClinicProfile_ReportPreferenceControl extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	
	Login loginSJMAdmin;
	Login loginPhysician;
	Login loginAlliedProf;
	Login loginDMR;
	
	ClinicianHomeTopNavPage clinicTopNavPage;
	CA_ClinicProfilePage clinicProfilePage;
	ClinicianHomePage clinicianHomePage;
	CA_LeftNavPage clinicLeftNavPage;
	
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	@BeforeClass
	public void initialize() {

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		loginSJMAdmin = new Login();	
		loginPhysician = new Login();
		loginAlliedProf = new Login();
		loginDMR = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void ICM_WA_ClinicProfile_ReportPreferenceControl() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
		loginAlliedProf = testDataProvider.getLoginData("");
		loginPhysician = testDataProvider.getLoginData("");
		loginDMR = testDataProvider.getLoginData("");
		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			
			extentReport.info("100 S The Actor navigates to Clinic Profile page.");
			loginPage.login(loginAlliedProf);			
			assertion.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true, clinicTopNavPage.verifyLandingPage(), extentReport, "Clinician Top Navigation pannel not found");
			clinicLeftNavPage.clickUserProfile();
			
			extentReport.info("200 V Verify that the following fields are displayed:"
					+ "a) Transmitter Serial Number"
					+ "b) Email Re cipients List"
					+ "c) checkbox for clinic level control of sending unpaired transmitter emails securely."
					+ "d) Report preference control with below radio buttons.\r\n"
					+ "1. Standard limited reports with latest VT/VF episode only"
					+ "2. Reports specified in Clinic Print Preferences", new String[] {"ClncMgt32031"});
			assertion.assertEquals(true, clinicProfilePage.verifyTransmitterWithMODCapabilityFields());
			
			extentReport.info("300 S Select any one of the radio button and click on save button.");
			clinicProfilePage.clickEditButton();
			clinicProfilePage.selectreportWithLatestVPVF();
			clinicProfilePage.clickSaveButton();
			
			extentReport.info("400 V Verify the selected radio button is saved successfully");
			clinicProfilePage.verifyEmailFaxContent4TransmissionsFromUnpairedTransmitters("Standard limited reports with latest VT/VF episode only");
			
			extentReport.info("500 S Login as a DMR user enter the clinic name and navigates to Clinic Profile page.");
			clinicTopNavPage.clickSignOutLink();
			loginPage.login(loginDMR);
			assertion.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			clinicTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true, clinicTopNavPage.verifyLandingPage(), extentReport, "Clinician Top Navigation pannel not found");
			clinicLeftNavPage.clickUserProfile();
			
			extentReport.info("600 V Verify that the following fields are displayed:"
					+ "a) Transmitter Serial Number"
					+ "b) Email Re cipients List"
					+ "c) checkbox for clinic level control of sending unpaired transmitter emails securely."
					+ "d) Report preference control with below radio buttons.\r\n"
					+ "1. Standard limited reports with latest VT/VF episode only"
					+ "2. Reports specified in Clinic Print Preferences", new String[] {"ClncMgt32031"});
			assertion.assertEquals(true, clinicProfilePage.verifyTransmitterWithMODCapabilityFields());
			
			extentReport.info("700 S Select any one of the radio button and click on save button.");
			clinicProfilePage.clickEditButton();
			clinicProfilePage.selectreportWithLatestVPVF();
			clinicProfilePage.clickSaveButton();
			
			extentReport.info("800 V Verify the selected radio button is saved successfully");
			clinicProfilePage.verifyEmailFaxContent4TransmissionsFromUnpairedTransmitters("Standard limited reports with latest VT/VF episode only");
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
	

}
