package com.test.qa.ui.tests.BVT;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicAdminMobAppTransPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicHoursAndHolidays;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ExportOptions;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_EpisodesAndEGMPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientSummaryPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_TransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ClinicalCommentsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ToolsPage;
import com.test.qa.utilities.CommonUtils;

public class BVT_Tests extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	AddCustomerPage addCustomerPage;
	ExtentTest extentTest;
	Login login, clinicianLogin;
	ViewCustomerPage viewCustomerPage;
	PatientListPage patientListPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_ClinicProfilePage clinicProfilePage;
	CA_LeftNavPage leftNavPage;
	CA_SchedulingAndMessagingPage schedulingAndMessagingPage;
	CA_ClinicHoursAndHolidays clinicHoursAndHolidays;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_ICD_CRTD_MerlinAtHomePage;
	CA_ClinicAdminMobAppTransPage clinicAdminMobAppTransPage;
	CA_DirectAlert_Pacemaker_CRTP_Page directAlert_Pacemaker_CRTP_Page;
	CA_DirectAlert_CardiacMonitorPage directAlert_CardiacMonitorPage;
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	CA_ClinicSettings_ExportOptions clinicSettings_ExportOptions;
	CA_ClinicSettings_ClinicalCommentsPage clinicSettings_ClinicalCommentsPage;
	CA_ClinicUsers clinicUsers;
	CA_ClinicLocationsPage clinicLocationsPage;
	CA_TransmissionsPage transmissionsPage;
	PL_PatientProfilePage patientProfilePage;
	CA_EpisodesAndEGMPage episodesAndEGMPage;
	ToolsPage toolsPage;
	PL_PatientSummaryPage patientSummaryPage;
	private Log logger = new Log();
	Customer customer, changingCustomer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() throws Exception {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver,extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		episodesAndEGMPage = new CA_EpisodesAndEGMPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		recentTransmissionsPage = new CA_RecentTransmissionsPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicProfilePage = new CA_ClinicProfilePage(driver,extentReport);
		clinicHoursAndHolidays = new CA_ClinicHoursAndHolidays(driver,extentReport);
		toolsPage = new ToolsPage(driver,extentReport);
		leftNavPage = new CA_LeftNavPage(driver,extentReport);
		schedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver,extentReport);
		directAlert_ICD_CRTD_MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver,extentReport);
		clinicAdminMobAppTransPage = new CA_ClinicAdminMobAppTransPage(driver,extentReport);
		directAlert_Pacemaker_CRTP_Page = new CA_DirectAlert_Pacemaker_CRTP_Page(driver,extentReport);
		directAlert_CardiacMonitorPage = new CA_DirectAlert_CardiacMonitorPage(driver,extentReport);
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver,extentReport);
		clinicSettings_ExportOptions = new CA_ClinicSettings_ExportOptions(driver,extentReport);
		clinicSettings_ClinicalCommentsPage = new CA_ClinicSettings_ClinicalCommentsPage(driver,extentReport);
		clinicUsers = new CA_ClinicUsers(driver,extentReport);
		clinicLocationsPage = new CA_ClinicLocationsPage(driver,extentReport);
		patientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		transmissionsPage = new CA_TransmissionsPage(driver,extentReport);
		patientSummaryPage = new PL_PatientSummaryPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		
		

		login = testDataProvider.getLoginData("SJMAdmin");
		clinicianLogin = testDataProvider.getLoginData("SJMClinic_ICMDevice");
		customer = testDataProvider.getCustomerData("BVTTest");
		
		assertion =  new Assertions(extentTest);
	}
	
	@Test(priority=0)
	public void addCustomerFunctionalityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		
		extentReport.info("Add Customer functionality check");
		loginPage.login(login,"internaluser");
		customerListPage.clickOnAddCustomerButton();
		String newCustomerName = addCustomerPage.addCustomerfieldupdate(customer, "Text");
		addCustomerPage.addCustomerSave();
		addCustomerPage.addCustomerConfirmCancel();
		addCustomerPage.clickOkButton();
		String actualCustomerName = customerListPage.searchCustomer(newCustomerName);
		assertion.assertEquals(actualCustomerName, newCustomerName, "Customer list page provides a mechanism to add a new customer and new customer is displayed in the list");
		extentReport.reportScreenShot("Customer list page provides a mechanism to add a new customer and new customer is displayed in the list");
		customerListPage.verifyLogout();
		} catch (AssertionError e) {
			extentReport.fail( "Add Customer functionality check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Add Customer functionality check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
		}
	
	@Test(priority=1)
	public void customerListPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
			extentTest = extentReport.initiateTest(testName);
			extentReport.info("Verify whether the Customer List page is displayed");
			loginPage.login(login, "internaluser");
			loginPage.loadingWithoutReport();
			assertion.assertEqualsWithReporting(customerListPage.verifyLandingPage(), true, extentReport,"Customer list page is displayed successfully");
			
		} catch (AssertionError e) {
			extentReport.fail("Customer List page Availability check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail("Customer List page Availability check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	@Test(priority=2)
	public void changeCustomerPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		customer = testDataProvider.getCustomerData("BVTTest");
		
		extentReport.info("Verify whether the Change Customer page is displayed");
		loginPage.login(login, "internaluser");
		customerListPage.searchCustomerAndClick(customer.getCustomerName());
		customerProfilePage.clickChangeButton();
		assertion.assertEqualsWithReporting(changeCustomerProfilePage.verifyLandingPage(),true,extentReport,"Change customer page is displayed successfully");
		} catch (AssertionError e) {
			extentReport.fail( "Change Customer Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Change Customer Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	@Test(priority=3)
	public void viewCustomerPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		customer = testDataProvider.getCustomerData("BVTTest");
		
		extentReport.info("Verify whether the View Customer page is displayed");
		loginPage.login(login, "internaluser");
		customerListPage.searchCustomerAndClick(customer.getCustomerName());
		assertion.assertEqualsWithReporting(customerProfilePage.verifyLandingPage(),true,extentReport,"View customer page is displayed successfully");
		customerListPage.verifyLogout();
		} catch (AssertionError e) {
			extentReport.fail( "View Customer Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "View Customer Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	
	@Test(priority=5)
	public void recentTransmissionPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		
		extentReport.info("Verify whether the Recent Transmission page is displayed");
		loginPage.login(clinicianLogin);
		clinicianHomeTopNavPage.loadingWithoutReport();
		assertion.assertEqualsWithReporting(recentTransmissionsPage.verifyLandingPage(),true,extentReport,"Recent Transmission page is displayed successfully");

		} catch (AssertionError e) {
			extentReport.fail( "Recent Transmission Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Recent Transmission Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	@Test(priority=6)
	public void patientListPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		
		extentReport.info("Verify whether the Patient List page is displayed");
		loginPage.login(clinicianLogin);
		clinicianHomeTopNavPage.clickPatientListLink();
		assertion.assertEqualsWithReporting(patientListPage.verifyLandingPage(),true,extentReport,"Patient List page is displayed successfully");

		} catch (AssertionError e) {
			extentReport.fail( "Patient List Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Patient List Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	@Test(priority=7)
	public void toolsPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		
		extentReport.info("Verify whether the Tools page is displayed");
		loginPage.login(clinicianLogin);
		clinicianHomeTopNavPage.clickToolsLink();
		assertion.assertEqualsWithReporting(toolsPage.verifyLandingPage(),true,extentReport,"Tools page is displayed successfully");

		} catch (AssertionError e) {
			extentReport.fail( "Tools Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Tools Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	@Test(priority=8)
	public void clinicAdministrationPageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		
		extentReport.info("Verify whether the Clinic Administration page is displayed");
		loginPage.login(clinicianLogin);
		clinicianHomeTopNavPage.clickClinicAdministrationLink();
		clinicianHomeTopNavPage.loadingWithoutReport();
		assertion.assertEqualsWithReporting(clinicProfilePage.verifyLandingPage(),true,extentReport,"Clinic Administration page is displayed successfully");
		extentReport.reportScreenShot("Clinic Administration page is displayed successfully");
		} catch (AssertionError e) {
			extentReport.fail( "Clinic Administration Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Clinic Administration Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
	
	@Test(priority=9)
	public void clinicProfilePageAvailabilityCheck() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		try {
		extentTest = extentReport.initiateTest(testName);
		
		extentReport.info("Verify whether the Clinic Profile page is displayed");
		loginPage.login(clinicianLogin);
		clinicianHomeTopNavPage.clickClinicAdministrationLink();
		clinicianHomeTopNavPage.loadingWithoutReport();
		assertion.assertEqualsWithReporting(clinicProfilePage.verifyLandingPage(),true,extentReport,"Clinic Profile page is displayed successfully");
		extentReport.reportScreenShot("Clinic Profile page is displayed successfully");
		} catch (AssertionError e) {
			extentReport.fail( "Clinic Profile Page Availability Check is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Clinic Profile Page Availability Check is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
		
	}
		@Test(priority=10)
		public void schedulingAndMessagingPageAvailabilityCheck() throws Exception {
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;
			try {
			extentTest = extentReport.initiateTest(testName);
			
			extentReport.info("Verify whether the Scheduling And Messaging page is displayed");
			loginPage.login(clinicianLogin);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			leftNavPage.clickSchedMessagingLink();
			assertion.assertEqualsWithReporting(schedulingAndMessagingPage.verifyLandingPage(),true,extentReport,"Scheduling And Messaging page is displayed successfully");

			} catch (AssertionError e) {
				extentReport.fail( "Scheduling And Messaging Page Availability Check is failed due to assertion failure");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			} catch (Exception e) {
				extentReport.fail( "Scheduling And Messaging Page Availability Check is failed due to some exception");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			}
	}
		
		@Test(priority=11)
		public void clinicHoursHolidaysPageAvailabilityCheck() throws Exception {
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;
			try {
			extentTest = extentReport.initiateTest(testName);
			
			extentReport.info("Verify whether the Clinic Hours And Holidays page is displayed");
			loginPage.login(clinicianLogin);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			leftNavPage.clickClinicHoursAndHolidaysLink();
			assertion.assertEqualsWithReporting(clinicHoursAndHolidays.verifyLandingPage(),true,extentReport,"Clinic Hours And Holidays page is displayed successfully");

			} catch (AssertionError e) {
				extentReport.fail( "Clinic Hours And Holidays Page Availability Check is failed due to assertion failure");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			} catch (Exception e) {
				extentReport.fail( "Clinic Hours And Holidays Page Availability Check is failed due to some exception");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			}
	}
		
		@Test(priority=12)
		public void directAlert_MerlinHome_TransmitterPageAvailabilityCheck() throws Exception {
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;
			try {
			extentTest = extentReport.initiateTest(testName);
			
			extentReport.info("Verify whether the Direct Alerts ICD CRT-D Merlin@Home Transmitter page is displayed");
			loginPage.login(clinicianLogin);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			leftNavPage.clickDirectAlertsICD_CRTD_MerlinHomeLink();
			assertion.assertEqualsWithReporting(directAlert_ICD_CRTD_MerlinAtHomePage.verifyLandingPage(),true,extentReport,"Direct Alerts ICD CRT-D Merlin@Home Transmitter page is displayed successfully");

			} catch (AssertionError e) {
				extentReport.fail( "Direct Alerts ICD CRT-D Merlin@Home Transmitter Page Availability Check is failed due to assertion failure");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			} catch (Exception e) {
				extentReport.fail( "Direct Alerts ICD CRT-D Merlin@Home Transmitter Page Availability Check is failed due to some exception");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			}
		}
		
		@Test(priority=13)
		public void directAlert_MobileApp_TransmitterPageAvailabilityCheck() throws Exception {
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;
			try {
			extentTest = extentReport.initiateTest(testName);
			
			extentReport.info("Verify whether the Direct Alerts ICD CRT-D Mobile App Transmitter page is displayed");
			loginPage.login(clinicianLogin);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			leftNavPage.clickDirectAlertsICD_CRTD_MobileAppLink();
			assertion.assertEqualsWithReporting(clinicAdminMobAppTransPage.verifyLandingPage(),true,extentReport,"Direct Alerts ICD CRT-D Mobile App Transmitter page is displayed successfully");

			} catch (AssertionError e) {
				extentReport.fail( "Direct Alerts ICD CRT-D Mobile App Transmitter Page Availability Check is failed due to assertion failure");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			} catch (Exception e) {
				extentReport.fail( "Direct Alerts ICD CRT-D Mobile App Transmitter Page Availability Check is failed due to some exception");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			}
		}
		
		@Test(priority=14)
		public void paceMaker_CRTP_PageAvailabilityCheck() throws Exception {
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;
			try {
			extentTest = extentReport.initiateTest(testName);
			
			extentReport.info("Verify whether the Pacemaker / CRT-P page is displayed");
			loginPage.login(clinicianLogin);
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			leftNavPage.clickpacemaker_CRTPLink();
			assertion.assertEqualsWithReporting(directAlert_Pacemaker_CRTP_Page.verifyLandingPage(),true,extentReport,"Pacemaker / CRT-P page is displayed successfully");

			} catch (AssertionError e) {
				extentReport.fail( "Pacemaker / CRT-P Page Availability Check is failed due to assertion failure");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			} catch (Exception e) {
				extentReport.fail( "Pacemaker / CRT-P Page Availability Check is failed due to some exception");
				logger.error(CommonUtils.convertStackTraceToString(e));
				e.printStackTrace();
				throw e;
			}
		}
			
			@Test(priority=15)
			public void cardiacMonitorPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Cardiac Monitor page is displayed");
				loginPage.login(clinicianLogin);
				clinicianHomeTopNavPage.clickClinicAdministrationLink();
				leftNavPage.clickCardiacMonitor_Link();
				assertion.assertEqualsWithReporting(directAlert_CardiacMonitorPage.verifyLandingPage(),true,extentReport,"Cardiac Monitor page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Cardiac Monitor Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Cardiac Monitor Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=16)
			public void reportSettingsPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Report Settings page is displayed");
				loginPage.login(clinicianLogin);
				clinicianHomeTopNavPage.clickClinicAdministrationLink();
				leftNavPage.clickReportSettingsLink();
				assertion.assertEqualsWithReporting(clinicSettings_ReportSettingsPage.verifyLandingPage(),true,extentReport,"Report Settings page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Report Settings Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Report Settings Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=17)
			public void exportOptionsPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Export Options page is displayed");
				loginPage.login(clinicianLogin);
				clinicianHomeTopNavPage.clickClinicAdministrationLink();
				leftNavPage.navigateExportSettingsPage();
				assertion.assertEqualsWithReporting(clinicSettings_ExportOptions.verifyLandingPage(),true,extentReport,"Export Options page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Export Options Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Export Options Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=18)
			public void clinicalCommentsPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Clinical Comments page is displayed");
				loginPage.login(clinicianLogin);
				clinicianHomeTopNavPage.clickClinicAdministrationLink();
				leftNavPage.clickClinicalCommentsLink();
				assertion.assertEqualsWithReporting(clinicSettings_ClinicalCommentsPage.verifyLandingPage(),true,extentReport,"Clinical Comments page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Clinical Comments Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Clinical Comments Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=19)
			public void clinicUsersPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Clinic Users page is displayed");
				loginPage.login(clinicianLogin);
				clinicianHomeTopNavPage.clickClinicAdministrationLink();
				leftNavPage.clinicUserPage();
				assertion.assertEqualsWithReporting(clinicUsers.verifyLandingPage(),true,extentReport,"Clinic Users page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Clinic Users Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Clinic Users Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=20)
			public void clinicLocationsPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Clinic Locations page is displayed");
				loginPage.login(clinicianLogin);
				clinicianHomeTopNavPage.clickClinicAdministrationLink();
				leftNavPage.navigateToClinicLocationsPage();
				assertion.assertEqualsWithReporting(clinicLocationsPage.verifyLandingPage(),true,extentReport,"Clinic Locations page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Clinic Locations Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Clinic Locations Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=21)
			public void patientProfilePageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Patient Profile page is displayed");
				loginPage.login(clinicianLogin);
				recentTransmissionsPage.clickOnPatientNameFromTrnmsnList();
				assertion.assertEqualsWithReporting(patientProfilePage.verifyLandingPage(),true,extentReport,"Patient Profile page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Patient Profile Page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Patient Profile Page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=22)
			public void episodesAndEGMPageAvailabilityCheck_ICM() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Episodes & EGM page is displayed for ICM device");
				loginPage.login(clinicianLogin);
				recentTransmissionsPage.selectTireOTwoFilterOption("cardiac monitor");
				recentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
				assertion.assertEqualsWithReporting(transmissionsPage.verifyLandingPage(),true,extentReport,"Transmission page is displayed successfully");
				transmissionsPage.clickOnICMEpisodesAndEGMLink();
				assertion.assertEqualsWithReporting(episodesAndEGMPage.verifyLandingPage(),true,extentReport,"ICM device_Episodes & EGM page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "ICM device_Episodes & EGM page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "ICM device_Episodes & EGM page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			@Test(priority=23)
			public void patientSummaryPageAvailabilityCheck() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Patient Summary page is displayed");
				loginPage.login(clinicianLogin);
				recentTransmissionsPage.selectTireOTwoFilterOption("cardiac monitor");
				recentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
				assertion.assertEqualsWithReporting(transmissionsPage.verifyLandingPage(),true,extentReport,"Transmission page is displayed successfully");
				transmissionsPage.clickOnPatientSummaryLink();
				assertion.assertEqualsWithReporting(patientSummaryPage.verifyLandingPage(),true,extentReport,"Patient Summary page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Patient Summary page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Patient Summary page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
		
			@Test(priority=24)
			public void episodesAndEGMPageAvailabilityCheck_NonICM() throws Exception {
				testName = CommonUtils.getTestName();
				CommonUtils.currentTestCaseName = testName;
				try {
				extentTest = extentReport.initiateTest(testName);
				
				extentReport.info("Verify whether the Episodes & EGM page is displayed for Non ICM device");
				loginPage.login(clinicianLogin);
				recentTransmissionsPage.selectTireOTwoFilterOption("all");
				recentTransmissionsPage.selectTireOTwoFilterOption("icd/pacemaker");
				recentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
				assertion.assertEqualsWithReporting(transmissionsPage.verifyLandingPage(),true,extentReport,"Transmission page is displayed successfully");
				transmissionsPage.clickOnNonICMEpisodesAndEGMLink();
				assertion.assertEqualsWithReporting(episodesAndEGMPage.verifyLandingPageForNonICM(),true,extentReport,"Non ICM device_Episodes & EGM page is displayed successfully");

				} catch (AssertionError e) {
					extentReport.fail( "Non ICM device_Episodes & EGM page Availability Check is failed due to assertion failure");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				} catch (Exception e) {
					extentReport.fail( "Non ICM device_Episodes & EGM page Availability Check is failed due to some exception");
					logger.error(CommonUtils.convertStackTraceToString(e));
					e.printStackTrace();
					throw e;
				}
		}
			
			


}
