package com.test.qa.ui.tests;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPage;
import com.test.qa.utilities.CommonUtils;

public class SearchAndSortingTest extends CommonUtils{

	LoginPage loginPage;;
	CustomerListPage customerPage;
	ExtentTest extentTest;
	private String testName;
	private Assertions softAssert;

	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPage(driver, extentReport);
		customerPage=new CustomerListPage(driver, extentReport);
		softAssert = new Assertions(extentTest);
	}

	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
	public void customerSearch(String iteration, String username, String password,String searchtext) throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		CommonUtils.iteration = iteration;
		extentTest = extentReport.initiateTest(testName + "_Iteration_" + iteration);
		CommonUtils.extentTest = extentTest;
		
		try {
			loginPage.login(username, password);
			customerPage.customerList();
			softAssert = new Assertions(extentTest);
		    customerPage.customerSearch("CLINIC");
			boolean Check=customerPage.check;
			softAssert.assertEquals(Check, true," Search Result is diaplayed for  string");
			customerPage.customerSearch("10");
			boolean Checkint=customerPage.check;
			softAssert.assertEquals(Checkint, true," Search Result is diaplayed for Number");
			customerPage.customerSearch("@");
			boolean Checkspecial=customerPage.check;
			softAssert.assertEquals(Checkspecial, true," Search Result is diaplayed for Special Char ");
			//customerPage.customerPageNavigationValidation();
			
		} catch (Exception e) {
			extentReport.reportFail("Search Result is not working ");
			throw e;
		}
		
	}
	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
	public void customerSearchsorting(String iteration, String username, String password,String searchtext) throws Exception {
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;
			CommonUtils.iteration = iteration;
			extentTest = extentReport.initiateTest(testName + "_Iteration_" + iteration);
			CommonUtils.extentTest = extentTest;
			
			try {
				customerPage.launchUrl();
				loginPage.login(username, password);
				customerPage.customerList();
				softAssert = new Assertions(extentTest);
				customerPage.customerListPageSortingValidation();
			} catch (Exception e) {
				extentReport.reportFail("Shorting is not working ");
				throw e;
			}
		
			
	
	        
	}

	@AfterClass
	public void shutdown() {
		driver.close();
	}

}
