package com.test.qa.ui.tests;

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPage;
import com.test.qa.utilities.CommonUtils;

public class LoginTest extends CommonUtils {

	LoginPage loginPage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	private String testName;

	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
	}

	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)

	public void loginOfPCSAdmin(String iteration, String username, String password) throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);

		try {
			loginPage.login(username, password);
			Boolean loginCheck = customerListPage.verifyLandingPage();
			Assert.assertTrue(loginCheck);
			customerListPage.verifyLogout();
			extentTest.log(Status.PASS, "Login functionality is verified");
		} catch (AssertionError e) {
			extentReport.reportFail("Login functionality not successfully verified for PCS Admin ");
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("Login functionality not successfully verified for PCS Admin ");
			throw e;
		}
	}
	

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		copySaintsEvidences(currentMethod);

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
