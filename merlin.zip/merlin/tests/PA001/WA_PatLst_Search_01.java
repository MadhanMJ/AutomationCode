package com.test.qa.ui.tests.PA001;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_PatLst_Search_01 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	ClinicianHomePage clinicianHomePage;
	AppHomeTopNavPage appHomeTopNavPage;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	PatientListPage patientListPage;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		patientListPage=new PatientListPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
	}
	
	/* TC ID: 1244244
	 * TC name: WA-PatLst-PA001-Search
	 */
	
	@Test
	public void wA_PA001_PatLst_ColDsp_03() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("DirectPhysician");

		extentTest.assignAuthor("Author - Snehal Mane");
		
		try {
			Assertions assertions=new Assertions(extentTest);
            //clicking clinicLocation page in clinicAdministration tab			
			extentReport.info("100 S The actor selects the following filter 'A Physician’s patient and enters a string to search on the Patient column and click on Search icon.");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Physician Name/ID");
			String phy_patient = "prasanna";
			patientListPage.enterTier3FilterInputBx(phy_patient);
			patientListPage.clickOnSearchOption();
			extentReport.reportScreenShot("User apply the filter and clicked on Search");
			
			extentReport.info("200 V Verify the system displays records for all the patients that match the partial/complete entered string and limits the search to the Patient column");
			//refer WA-CA110-ClinicLocations-Search
			
			extentReport.info("300 V Verify the search field accepts characters, numbers and special characters", new String[] {"TransMgt16796", "CommUI8491", "CommUI8195"});
			String search_char = "s";
			patientListPage.enterTier3FilterInputBx(search_char);
			String search_num = "91";
			patientListPage.enterTier3FilterInputBx(search_num);
			String search_SpclChar = "#";
			patientListPage.enterTier3FilterInputBx(search_SpclChar);
			String search_combination = "phy#12";
			patientListPage.enterTier3FilterInputBx(search_combination);
			
			extentReport.info("400 S Repeat steps from 100 to 300 for all the filters mentioned below: " +
					"<\br>" + "Patient Merlin.net Number" +
					"<\br>" + "Lead Model");
			//***************Patient Merlin.net Number********************
			//-----------------step 100
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Patient Merlin.net™ Number");
			//take merlinnet_num from DB 
			String merlinnet_num = "UUYTTHJ44,854OP";
			patientListPage.enterTier3FilterInputBx(merlinnet_num);
			patientListPage.clickOnSearchOption();
			extentReport.reportScreenShot("User apply the filter and clicked on Search");
			//Enter validation steps from step 200
			
			//------------------step 300
			patientListPage.enterTier3FilterInputBx(search_char);
			patientListPage.enterTier3FilterInputBx(search_num);
			patientListPage.enterTier3FilterInputBx(search_SpclChar);
			patientListPage.enterTier3FilterInputBx(search_combination);
			
			//***************Lead Model********************
			//-----------------step 100
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Lead Model");
			//take lead_model from DB 
			String lead_model = "LPA1200M TENDRIL MRI";
			patientListPage.enterTier3FilterInputBx(lead_model);
			patientListPage.clickOnSearchOption();
			extentReport.reportScreenShot("User apply the filter and clicked on Search");
			//Enter validation steps from step 200
			
			//------------------step 300
			patientListPage.enterTier3FilterInputBx(search_char);
			patientListPage.enterTier3FilterInputBx(search_num);
			patientListPage.enterTier3FilterInputBx(search_SpclChar);
			patientListPage.enterTier3FilterInputBx(search_combination);	
			
			extentReport.info("500 S The actor selects the following filter ‘A specific Device Serial number’ and searches for a specific serial number on the Device Type column");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Device Serial Number");
			//take deviceSerialNum from DB 
			String deviceSerialNum = "676756";
			patientListPage.enterTier3FilterInputBx(deviceSerialNum);
			patientListPage.clickOnSearchOption();
			extentReport.reportScreenShot("User apply the filter and clicked on Search");
						
			
			extentReport.info("600 V Verify the system displays all the patients that match the partial/complete entered string and limits the search to the Device Serial Number column");
			//(Example-user enters ‘34 in the search field, the  patients with twebsite notifications whose device serial number contains 34 will be displayed, such as 2334, 3423 etc.)
			
			//Add verification points after search
			
			extentReport.info("700 S The actor hides  'A specific Device Serial number’  Column and repeats step 500 and 600");
			patientListPage.removeColumn("Device");
			assertions.assertEqualsWithReporting(false, patientListPage.verifyPatientListColumnsHeading("Device"), extentReport, "Column is removed and not present on the page");
	//		assertions.assertNotEquals(true, patientListPage.verifyPatientListColumnsHeading("Device"));
			
			//step 500
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Device Serial Number");
			//take deviceSerialNum from DB 
			patientListPage.enterTier3FilterInputBx(deviceSerialNum);
			patientListPage.clickOnSearchOption();
			extentReport.reportScreenShot("User apply the filter and clicked on Search");
			//step 600
			//add steps from 600
			
			
			extentReport.info("800 V Verify the system searches the hidden column even if the column is hidden and displays results if the search criterion matches");
			//add few steps from 600 for searched results
			assertions.assertEqualsWithReporting(false, patientListPage.verifyPatientListColumnsHeading("Device"), extentReport, "Column is not present on the page");
			
			
			extentReport.info("900 S Repeat steps from 500 to 800 for all the filters mentioned below:" +
					"<\br>" + "Patient Name" +
					"<\br>" + "Patient ID", new String[] {"CommUI8195", "CommUI8491"});
			
			//work on this once complete 500 to 800
			
			
			//****Search Functionality-List Search Mode*****
			appHomeTopNavPage.clickSignOutLink();
			login = testDataProvider.getLoginData("DirectAll");
			
			extentReport.info("1000 S The actor logs in to the system and navigates to the Patient List page (PA001)");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("1100 S Select Tier 1 Filter as \"All Active Patients\" and Tier 2 filter as \"ALL");
			patientListPage.selectTierOneFilterOption("My Active Patients");
			patientListPage.selectTierTwoFilterOption("All");
			extentReport.reportScreenShot("User apply the filter");
			
			extentReport.info("1200 S The actor enters a string in the search field");
			patientListPage.enterTier3FilterInputBx("31");
			extentReport.reportScreenShot("User enters a string in the search box");
			
			extentReport.info("1300 V Verify the system performs a search on all the displayed columns on the page and displays patients that match the partial/Complete string entered in the search field", new String[] {"CommUI8194", "CommUI8491"});
			//(Example-user enters ‘31’ in the search field; the list is filtered on all displayed columns and displays the results that match the search criterion-Such as Patient with next transmissions dateas 8/31/2013 and patient with device serial number 523125)
			patientListPage.performSearchOnAllFields("31");
			int initialRecords = patientListPage.countPatientWithFilter();
						
			extentReport.info("1400 V Verify the search action is initiated even as the user enters values in the search field");
			//need to modify this method
			patientListPage.verifySearch();
			
			extentReport.info("1500 S The actor hides the Device column and inputs search string from previous step.");
			patientListPage.removeColumn("Device");
			assertions.assertEqualsWithReporting(false, patientListPage.verifyPatientListColumnsHeading("Device"), extentReport, "Column is removed and not present on the page");
			patientListPage.enterTier3FilterInputBx("31");
			extentReport.reportScreenShot("User enters a string in the search box");
			int recordsAfterColhide = patientListPage.countPatientWithFilter();
			
			extentReport.info("1600 V Verify the search is not performed on the hidden column and the patient displayed in previous step for matching value from hidden column is not displayed in the list");
			assertions.assertNotEquals(initialRecords, recordsAfterColhide);
			
			
		}
		catch (AssertionError e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
		
	}
}
	