package com.test.qa.ui.tests.PA001;

import java.util.List;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class WA_PatLst_PA001_PatLstFilters_04 extends CommonUtils {

	Assertions assetions;
	Login loginClinicUser_withAllDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	Login loginAP;
	Login loginPhy;
	Login loginLimited;
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	List<Date> latestTransDate;
	List<Date> comparedDate;
	SimpleDateFormat df;
	private String DATE_FORMAT;

	@BeforeClass
	public void initialize() {
		testDataProvider = new TestDataProvider();
		loginAP = new Login();
		loginPhy = new Login();
		loginLimited = new Login();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		latestTransDate = new ArrayList<Date>();
		comparedDate = new ArrayList<Date>();
		DATE_FORMAT = "MM/dd/yyyy";
		df = new SimpleDateFormat(DATE_FORMAT);

	}

	@Test
	public void PA001_PatLstFilters_04() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);

		loginAP = testDataProvider.getLoginData("DirectAll");
		// loginPhy = testDataProvider.getLoginData("");
		// loginLimited = testDataProvider.getLoginData("");

		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			assertion = new Assertions(extentTest);

			extentReport.info("100 – S Login to Merlin.net and Click on EP Application.");
			loginPage.login(loginAP, "externaluser");
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport,
					"Clinician Home Landing page is NOT displayed");

			extentReport.info("200 – S Select the Patient List tab and filter by ‘Last transmission’ for the patients");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.selectTierTwoFilterOption("Latest Transmission Date Range");

			extentReport.info("250 - S Provide the date in Date From and To field.");
			String fromdate = "12/2/2021";
			String todate = "15/2/2022";
			Thread.sleep(20000);
			patientListPage.enterTier3DateValues(fromdate, todate);
			patientListPage.clickOnSearchOption();

			// Open Bug - Defect:PCN00031257

			extentReport.info(
					"300 – V Verify the Patient list display all the patients who have transmission in the date provided above.");

			Date fromDate = df.parse(fromdate);
			Date toDate = df.parse(todate);
			for (Date value : latestTransDate) {
				if (!(value.compareTo(fromDate) >= 0) && !(value.compareTo(toDate) <= 0))
					comparedDate.add(value);
			}
			if (comparedDate.isEmpty())
				extentReport.pass(" Latest Transmissions dates are in the given date range");
			else
				extentReport.fail(" Latest Transmissions dates are not in the given date range");

			
			  extentReport.info(" ******Iteration2: Provide Date Range where in NO transmission are received(“DD-MM-YYYY”)**********"); 
			  fromdate = "12/2/1998"; 
			  todate = "15/2/1999";
			  patientListPage.enterTier3DateValues(fromdate, todate);
			  patientListPage.clickOnSearchOption();
			  
			  extentReport. info("400 – V Verify the Patient list doesnot display any patients as there are no transmission received for any patient in the date provided.");
			  
			  extentReport.info("******Iteration3: Provide Invalid Values in ‘From’ and ‘to’ field**********"); 
			  fromdate = "45/32/1998"; 
			  todate = "34/36/1999";
			  patientListPage.enterTier3DateValues(fromdate, todate);
			  patientListPage.clickOnSearchOption();
			  
			  extentReport.info("500– V Verify the system does not display any patients as there are no transmission received for any patient in the date provided.");
			  
			  extentReport.info("******Iteration4: Provide Date Range for which transmission are avaliable (“MM-DD-YYYY”)**********"); 
			  fromdate = "12/02/2021"; 
			  todate = "10/02/2022";
			  patientListPage.enterTier3DateValues(fromdate, todate);
			  patientListPage.clickOnSearchOption();
			  
			  extentReport.info("600 - V Verify the Patient list display all the patients who have transmission in the date provided above.");
			  
			  extentReport.info("*****Iteration5: Provide Date Range for which transmission are avaliable (“YYYY-MM-DD”)********** "
					  +" From: Current System date To: Current System date"); 
			  fromdate ="2021/2/20"; 
			  todate = "2022/2/20";
			  patientListPage.enterTier3DateValues(fromdate, todate);
			  patientListPage.clickOnSearchOption();
			  
			  extentReport.info("700 - V Verify the system does not display any patients as there are no transmission received for any patient in the date provided.");
			  
			  extentReport.info("From: Future date To: Future date"); //need to work on future date 
			  fromdate = "2021/2/20"; 
			  todate = "2022/2/20";
			  patientListPage.enterTier3DateValues(fromdate, todate);
			  patientListPage.clickOnSearchOption();
			  
			  extentReport.info("800 - V Verify the system does not display any patients as there are no transmission received for any patient in the date provided.");
			  
			  extentReport.info("From: Past Date To: Future date"); 
			  fromdate = "2021/2/20";
			  todate = "2022/2/20"; 
			  patientListPage.enterTier3DateValues(fromdate, todate);
			  patientListPage.clickOnSearchOption();
			  
			  extentReport.info("900 - V V Verify the Patient list display all the patients who have transmission in the date provided above.");
			  
			  extentReport.info("From: Current System date To: Future date");
			  
			  extentReport.info("1000 - V Verify the system does not display any patients as there are no transmission received for any patient in the date provided" );
			  
			 

			assertion.assertAll();
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
		/*
		 * Customer name - Test Customer1244240 - Jr. - 365 HCL1244240_CL_Direct1
		 * Merlinnet123!
		 * 
		 * Allied Prof HCL1244240_SP_AP Merlinnet123!
		 * 
		 * Physician HCL1244240_D_Phy Merlinnet123!
		 * 
		 * Limited HCL1244240_D_LU Merlinnet123!
		 */
	}

	private String addDaysToDate(String date, String days) {
		Calendar c = Calendar.getInstance();
		try {
			Date myDate = df.parse(date);
			c.setTime(myDate);
			c.add(Calendar.DATE, Integer.parseInt(days));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String toDate = df.format(c.getTime());
		return toDate;
	}

	private String subtractDaysFromDate(String date, String days) {
		Calendar c = Calendar.getInstance();
		try {
			Date myDate = df.parse(date);
			c.setTime(myDate);
			c.add(Calendar.DATE, (Integer.parseInt(days) * -1));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String toDate = df.format(c.getTime());
		return toDate;
	}

}
