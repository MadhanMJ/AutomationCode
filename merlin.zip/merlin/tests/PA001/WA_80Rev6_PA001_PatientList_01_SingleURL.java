package com.test.qa.ui.tests.PA001;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_80Rev6_PA001_PatientList_01_SingleURL extends CommonUtils {
	LoginPageWithPOJO loginPage;

	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CommonUtils commonUtils;
	CA_LeftNavPage clncAdnLftNav;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	PatientListPage patientListPg;


	@BeforeClass
	public void initialize() {
		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clncAdnLftNav=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		patientListPg = new  PatientListPage(driver, extentReport);
	}


	//Author: Alok
	//Test case : WA_80Rev6_PA001_PatientList_01_SingleURL
	@Test
	public void WA_80Rev2_PA001_PatientList_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		extentTest = extentReport.initiateTest(testName);

		login = testDataProvider.getLoginData("PatientTC");
		extentTest.assignAuthor("Bhupend Dhore");

		

		try {
			Assertions assertion =  new Assertions(extentTest);
			extentReport.info("100 S The actor logs into the EP Clinic and navigate to Patient List.");		
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.clickPatientListLink();
			extentReport.reportScreenShot("Navigated to Patient List.");



			
		} 
		catch (AssertionError e) {
			extentTest = extentReport.fail( "UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed due to assertion failure");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed due to some exception");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			status = "Success";
		} 

		writeInTextFile(testMethodName, status);
	}

}

