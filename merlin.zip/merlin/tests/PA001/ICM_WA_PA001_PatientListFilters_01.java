package com.test.qa.ui.tests.PA001;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;


public class ICM_WA_PA001_PatientListFilters_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	ExtentTest extentTest;
	Login login;
	Login login_scenario_2;
	TestDataProvider testDataProvider;
	private String testName;
	Customer customer;
	ClinicianHomeTopNavPage ClinicianHomeTopNavPage;
	PatientListPage patientListPage;
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		ClinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		login = new Login();
		login_scenario_2= new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		patientListPage=new PatientListPage(driver, extentReport);
	}
	
	@Test
	public void ICM_WA_PA001_PatientListFilters_01() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("Priyam");
		login_scenario_2=testDataProvider.getLoginData("DirectAll");
		
		extentTest.assignAuthor("Author - Shanmugapriya");

		try {
			Assertions assertions=new Assertions(extentTest);
	
			extentReport.info("100 S Login to a EP clinic A not having any ICM/BLE Capable Device assigned and navigate to EP Patient list");
			loginPage.login(login,"externaluser");
			ClinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("200 S Select tier 1 filter as Active Clinic Patients and select tier 2 filter dropdown.");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
//			patientListPage.selectTier2FilterInDropdown();
			extentReport.reportScreenShot("User is able to select Active Clinic Patients in tier 1 and select tier 2 filter dropdown");
			
			extentReport.info("300 V Verify that tier 2 show filters ‘Cardiac Monitor’ & ‘ICD/PM’ are not displayed in filter list", new String[] {"TransMgt17591", "TransMgt17592"});
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTier2FilterInDropdown();
			assertions.assertEqualsWithReporting(false, patientListPage.validateDrpdwnContainDevice("Cardiac Monitor"), extentReport, "Cardiac Monitor is not displayed in filter list");
			assertions.assertEqualsWithReporting(false, patientListPage.validateDrpdwnContainDevice("ICD"), extentReport, "ICD Pacemaker is not displayed in filter list");
			extentReport.reportScreenShot("Cardiac Monitor and ICD/Pacemaker are not found in tier 2 filter");
			ClinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("400 S Login to a EP clinic having BLE Capable Device assigned. Clinic has ICD/PM/BLE Capable patients with in-clinic and remote transmissions. Navigate to EP Patient list.");
			loginPage.login(login_scenario_2); 
			ClinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("500 S Select tier 1 filter as Active Clinic Patients and select tier 2 filter dropdown.");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTier2FilterInDropdown();
			extentReport.reportScreenShot("User is able to select Active Clinic Patients in tier 1 and select tier 2 filter dropdown");
			
			extentReport.info("600 V Verify that tier 2 show filters ‘Cardiac Monitor’ & ‘ICD/PM’ are displayed in filter list ", new String[] {"TransMgt17591", "TransMgt17592"});
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTier2FilterInDropdown();
			assertions.assertEqualsWithReporting(true, patientListPage.validateDrpdwnContainDevice("Cardiac Monitor"), extentReport, "Cardiac Monitor is displayed in filter list");
			assertions.assertEqualsWithReporting(true, patientListPage.validateDrpdwnContainDevice("ICD"), extentReport, "ICD/Pacemaker is displayed in filter list");
			extentReport.reportScreenShot("User is able to see Cardiac Monitor and ICD/PM are displayed in tier 2 filter");
			
			extentReport.info("700 S Select tier 1 filter as Active Clinic Patients and tier 2 filter as Cardiac Monitor");
//			patientListPage.selectTireOneFilterOption("Active Clinic Patients");
//			patientListPage.selectTireOTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			extentReport.reportScreenShot("User is able to select Cardiac Monitor in tier 2 filter");
			
			extentReport.info("800 V Verify that all active and released for transfer ICM Capable Patients in current clinic are displayed",new String[] {"TransMgt17591","TransMgt16775"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyPatientStatus("vardhani 813 confirm first"),extentReport,"Status of patient should be active or released");
			extentReport.reportScreenShot("User is able to see status for ICM Capable patients as active and released");
			
			extentReport.info("900 V Verify that in ‘All Transmissions’ column, for each ICM Capable Patient, Remote transmission count and In-clinic transmission count is displayed.", new String[] {"TransMgt17532", "TransMgt17533", "TransMgt13301"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyAllTransmissionInPatientList(),extentReport,"Remote and In-clinic transmission count is displayed");
			extentReport.reportScreenShot("User is able to see count of Remote and In-clinic transmission for Cardiac monitor");
			
			extentReport.info("1000 S Select tier 1 filter as My Active patients and tier 2 filter as Cardiac Monitor");
			patientListPage.selectTierOneFilterOption("My Active Patients");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			extentReport.reportScreenShot("User is able to select My Active Patients in tier 1 and Cardiac Monitor in tier 2 filter");
			
			extentReport.info("1100 V Verify that all active and released for transfer ICM Capable  Patients having logged in user as medical team member are displayed ",new String[] {"TransMgt17591", "TransMgt17683"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyPatientStatus("vardhani 813 confirm first"),extentReport,"Status of patient should be active or released");
			//Need to check
			assertions.assertEqualsWithReporting(true,patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName","1"),extentReport,"User logged as medical team member");
			extentReport.reportScreenShot("User is able to verify active and released for transfer ICM Capable  Patients having logged in user as medical team member.");
			
			extentReport.info("1200 S Select tier 1 filter as My Active patients and tier 2 filter as ICD/PM");
			patientListPage.selectTierOneFilterOption("My Active Patients");
			patientListPage.selectTierTwoFilterOption("ICD");
			extentReport.reportScreenShot("User is able to select My Active Patients in tier 1 and ICD/PM in tier 2 filter");
			
			extentReport.info("1300 V Verify that all active and released for transfer ICD/PM Patients having logged in user as medical team member are displayed",new String[] {"TransMgt17592>", "TransMgt17683"});
			//need to check
			assertions.assertEqualsWithReporting(true,patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName","1"),extentReport,"User logged as medical team member");
			extentReport.reportScreenShot("User is able to verify active and released for transfer ICD/PM Patients having logged in user as medical team member.");
			
			extentReport.info("1400 S Select tier 1 filter as Active Clinic Patients and tier 2 filter as ICD/PM");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("ICD/Pacemaker");
			extentReport.reportScreenShot("User is able to select ICD/Pacemaker in tier 2 filter");
			
			extentReport.info("1500 V Verify that all active and released for transfer ICD/PM Patients in current clinic are displayed", new String[] {"TransMgt17592", "TransMgt16775"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyPatientStatusInPatientListTable("patientName"),extentReport,"Status of patient should be active or released");
			extentReport.reportScreenShot("User is able to see status for ICM Capable patients as active and released");
			
			extentReport.info("1600 V Verify that in ‘All Transmissions’ column, for each ICD/PM Patient, Remote transmission count & In-clinic transmission count is displayed.", new String[] {"TransMgt17532", "TransMgt17533", "TransMgt13301"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyAllTransmissionInPatientList(),extentReport,"Remote and In-clinic transmission count is displayed");
			extentReport.reportScreenShot("User is able to see count of Remote and In-clinic transmission for ICD/Pacemaker");
			
			
		}catch (AssertionError e) {
			extentReport.reportFail("ICM_WA_PA001_PatientListFilters_01 is failed due to assertion failure",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("ICM_WA_PA001_PatientListFilters_01 is failed due to some exception",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	
		
	}

	
	
}
