package com.test.qa.ui.tests.PA001;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;


public class WA_80Rev2_PA001_PatientList_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;

	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CommonUtils commonUtils;
	CA_LeftNavPage clncAdnLftNav;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	PatientListPage patientListPg;
	PL_AllTransmissionsPage allTransmissionsPage;
	AddCustomerPage addCustomerPage;


	@BeforeClass
	public void initialize() {
		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clncAdnLftNav=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		patientListPg = new  PatientListPage(driver, extentReport);
		allTransmissionsPage = new PL_AllTransmissionsPage(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
	}


	//Author: Bhupendra Dhore
	//Test case name : WA_80Rev2_PA001_PatientList_01
	@Test
	public void WA_80Rev2_PA001_PatientList_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("PatientTC");
		extentTest.assignAuthor("Bhupend Dhore");
		String user="";

		

		try {
			Assertions assertion =  new Assertions(extentTest);
			
			
			//1.code to capture the latest downloaded file in downloads folder  			1
//			extentReport.info("100 S The actor logs into the EP Clinic and navigate to Patient List.");		
//			loginPage.login(login,"externaluser");
//			clinicianHomeTopNavPage.clickPatientListLink();
//			extentReport.reportScreenShot("Navigated to Patient List.");
//			
//			
//			//patientListPg.validatePatientListFilterWithDifferentValues();
//
//
//			extentReport.info( "200 S The actor selects 'Download Spreadsheet' option from the More Actions-List Actions dropdown menu");	
//			patientListPg.validateDwnldSpreadSheetMoreActionOption();
//
//
//
//			extentReport.info("300 V Verify  the contents of the list is saved in .csv format on the actors computer");		
//			assertion.assertEquals(true, patientListPg.getLatestDownloadedFile(System.getProperty("user.dir")+"\\Downloads\\").contains("Merlin.net™ PCN"), "Verify  the contents of the list is saved in .csv format on the actors computer");
//			
//			
//			
//			
//			extentReport.info("400 S The actor opens downloaded .csv file.");
//			String path=System.getProperty("user.dir")+"\\Downloads\\"+patientListPg.getLatestDownloadedFile(System.getProperty("user.dir")+"\\Downloads\\");
//
//
//			extentReport.info("500 V Verify the downloaded spreadsheet displays the table with the list of rows and columns in the order displayed to the user while performing the ‘Download to Spreadsheet’ action.", new String[] {"TransMgtt16808"});
//			patientListPg.compareSpreadsheetAndUIValues(path);
//
//
//			extentReport.info("600 S The actor selects 'Add or Remove Columns' option from the More Actions-List Actions dropdown menu and removes Latest Transmission column.");
//			patientListPg.removeColumn("latest transmission");
//
//
//
//			extentReport.info("700 S The actor selects 'Download Spreadsheet' option from the More Actions-List Actions dropdown menu");
//			patientListPg.validateDwnldSpreadSheetMoreActionOption();
//			
//			
//			extentReport.info("800 V Verify the downloaded spreadsheet displays the table with the list of rows and columns in the order dicsplayed to the user while performing the 'Download to Spreadsheet’ action. <TransMgtt16808>");
//			patientListPg.compareSpreadsheetAndUIValues(path);
//			patientListPg.addColumn("latest transmission");
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			//2.**** 8.0 Rev2 Issue 15 ****
//			extentReport.info("900 V Verify that on Patient list, Remote and In-clinic text in All Transmissions column are displayed as a hyperlink.", new String[] {"TransMgt16380"});
//			//write code to validate hyperlinks
//			
//			
//			
//			extentReport.info("1000 S On Patient list, click on Remote hyperlink for patient having remote transmissions");
//			patientListPg.clickonAllTransmissionFrmList("pat");
//			
//			
//			extentReport.info("1100 V Verify that All Transmission page is displayed for the selected patient.", new String[] {"TransMgt16380"});
//			assertion.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
//			
//			
//			
//			extentReport.info("1200 S The actor logout of the clinic.");
//			appHomeTopNavPage.clickSignOutLink();
//			extentReport.reportScreenShot("Actor logged out of the clinic.");

			
			
			
			
			
			
//			3.**** 8.0 Rev2 Issue 20 ****
			extentReport.info("1300 S Using SJM Admin create new Direct clinic and change password for the user.");		
//			login = testDataProvider.getLoginData("SJMAdmin_delete");
//			loginPage.login(login,"internaluser");			
//			customer = testDataProvider.getCustomerData("AddCustomerNew");
//			user=customer.getUserid();
//			addCustomerPage.addCustomerClick();
//			addCustomerPage.addCustomerPageLanding();
//			addCustomerPage.addCustomerfieldupdate(customer, "Text");
//			addCustomerPage.addCustomerSave();
//			addCustomerPage.addCustomerConfirmCancel();
//			appHomeTopNavPage.clickSignOutLink();
//			//addCustomerPage.createNewClinicSjmAdmin(customer,login);
//			
//			
//			
//			extentReport.info("1400 S Login with the user of newly created direct clinic.");		
//			loginPage.loginWithNewCreatedClinic(customer,login);
//			
//			
//			
//			extentReport.info("1500 V Verify that on Patient List page, Clinical Comments column is displayed.", new String[] {"TransMgt16823"});
//			patientListPg.verifyLatestCommentsHeader();
//			
//			
//			
//			extentReport.info("1600 S The actor lo out of the clinic.");
//			appHomeTopNavPage.clickSignOutLink();
//			extentReport.reportScreenShot("Actor logged out of the clinic.");
			
			
			
			extentReport.info("1700 S Using SJM Admin create new SP2 clinic and change password for the user.");
			customer = testDataProvider.getCustomerData("WA_80Rev2_PA001_PatientList_01_SP2");	
			loginPage.login(login,"internaluser");			
			user=customer.getUserid();
			addCustomerPage.addCustomerClick();
			addCustomerPage.addCustomerPageLanding();
			addCustomerPage.addCustomerfieldupdate(customer, "Text");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
			appHomeTopNavPage.clickSignOutLink();
			//addCustomerPage.createNewClinicSjmAdmin(customer,login);
			
					
			
			
			extentReport.info("1800 S Login with the user of newly created SP2 clinic.");
			loginPage.loginWithNewCreatedClinic(customer,login);
			
			
			
			extentReport.info("1900 V Verify that on Patient List page, Clinical Comments column is displayed.", new String[] {"TransMgt16823"});
			patientListPg.verifyLatestCommentsHeader();
			
			
			
			
			extentReport.info("2000 S The actor lo out of the clinic.");
			appHomeTopNavPage.clickSignOutLink();
			extentReport.reportScreenShot("actor logged out of the clinic.");
			
			
			
			
			
			
			
			
			
			
			//tier two filter value is not retained after navigation ffrom othe page
			//4.**** 8.0 Rev2 Issue 21 ****
//			extentReport.info("2100 S Login to EP clinic having patients enrolled. Navigate to Patient List.");
//			login = testDataProvider.getLoginData("PatientTC");
//			loginPage.login(login,"externaluser");
//			clinicianHomeTopNavPage.clickPatientListLink();
//			
//			
//			
//			extentReport.info("2200 S On Patient List page, with tier1 filter as ‘Active Clinic Patients’ and Tier 2 filter as ‘All’, enter search text. Patients matching search string are displayed.");
//			patientListPg.selectTierOneFilterOption("Active Clinic Patients");
//			patientListPg.selectTierTwoFilterOption("All");
//			
//			
//			
//			
//			extentReport.info("2300 S Navigate to some other page and come back to Patient List.");
//			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
//			clinicianHomeTopNavPage.navigateToPatientListPage();
//			
//			
//			
//			
//			extentReport.info("2400 V Verify that Filter selection and search string entered in search box is retained and patients matching search string are displayed.", new String[] {"TransMgt16857","CommUI8491","CommUI9014"});
//			assertion.assertEqualsWithReporting(true,patientListPg.verifyTier1FilterValue("Active Clinic Patients"), extentReport, "Verified tier one filetr is retained on patinet list page after navigation from other page.");
//			assertion.assertEqualsWithReporting(true,patientListPg.verifyTier2FilterValue("All"), extentReport, "Verified tier two filetr is retained on patinet list page after navigation from other page.");
//			
//			
//			
//			extentReport.info("2500 S - Repeat Step 2400 to Step 2600 for different filters with and without search text");
//			patientListPg.validatePatientListFilterWithDifferentValues("pat");
//			
//			
//			
//			
//			extentReport.info("2600 S- The Actor logs out and re-login");
//			patientListPg.selectTierOneFilterOption("Active Clinic Patients");
//			patientListPg.selectTierTwoFilterOption("All");
//			appHomeTopNavPage.clickSignOutLink();
//			loginPage.login(login,"externaluser");
//			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
//			clinicianHomeTopNavPage.navigateToPatientListPage();
//			
//			
//			extentReport.info("2700 V- Verify the previous user sessions filter selection and search text are not retained and application displays the default filters.");
//			assertion.assertEqualsWithReporting(false,patientListPg.verifyTier1FilterValue("Active Clinic Patients"), extentReport, "Verified tier one filetr is retained on patinet list page after user log out and login.");
//			assertion.assertEqualsWithReporting(false,patientListPg.verifyTier2FilterValue("All"), extentReport, "Verified tier two filetr is no retained on patinet list page after user log out and login.");
//			appHomeTopNavPage.clickSignOutLink();
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			//5.*** 8.0 Rev2 Enhancement 1 in SWR 22151 ***
//			extentReport.info("2800 S Login to EP clinic having patients enrolled");
//			login = testDataProvider.getLoginData("PatientTC");
//			loginPage.login(login,"externaluser");
//			
//			
//			
//			extentReport.info("2900 S Navigate to Patient List.");
//			clinicianHomeTopNavPage.clickPatientListLink();
//			
//			
//			
//			extentReport.info("3000 V Verify that on Patient List page, default pagination filter value is selected as 25", new String[] {"CommUI9017"});
//			assertion.assertEqualsWithReporting(true,patientListPg.verifyPaginationValue("25"), extentReport, "Verified that on Patient List page, default pagination filter value is selected as 25");
//			
//			
//			
//			extentReport.info("3100 S Change pagination filter value to 50. Navigate to few other pages and come back to Patient List page.");
//			patientListPg.selectPaginationValue("50");
//			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
//			clinicianHomeTopNavPage.navigateToPatientListPage();
//			
//			
//			
//			extentReport.info("3200 V Verify that on Patient List page, pagination filter value is selected as 50 ", new String[] {"CommUI9017"});
//			assertion.assertEqualsWithReporting(true,patientListPg.verifyPaginationValue("50"), extentReport, "Verified that on Patient List page, default pagination filter value is selected as 50");
//			//check this function as it is been edited by you
//
//			
//			extentReport.info("3300 S The Actor logs out and re-login and navigate to Patient List.");
//			appHomeTopNavPage.clickSignOutLink();
//			loginPage.login(login,"externaluser");
//			clinicianHomeTopNavPage.navigateToPatientListPage();
//			
//			
//			extentReport.info("3400 V Verify that on Patient List page, pagination filter value is selected as 50", new String[] {"CommUI9017"});
//			assertion.assertEqualsWithReporting(false,patientListPg.verifyPaginationValue("50"), extentReport, "Verified that on Patient List page, default pagination filter value is selected as 50");
//			
			



		} 
		catch (AssertionError e) {
			extentTest = extentReport.fail( "UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed due to assertion failure");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed due to some exception");
			extentTest.fail("UC021A UC021B_WA_EP_ClinicAdmin_PercentPacing_AlertGroup_Pacemaker_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			status = "Success";
		} 

		writeInTextFile(testMethodName, status);
	}

}
