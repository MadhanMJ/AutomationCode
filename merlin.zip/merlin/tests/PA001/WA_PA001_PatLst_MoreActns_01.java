package com.test.qa.ui.tests.PA001;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Keys;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_PA001_PatLst_MoreActns_01 extends CommonUtils {

	/*
	 * Test case name: WA_PA001_PatLst_MoreActns_01 
	 * Author: Rajesh Singaraj 
	 * Test case ID: 1244071
	 * 
	 */
	LoginPageWithPOJO loginPage;
	Login login;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTrnsPg;
	private String testName;
	private Log logger = new Log();
	Customer customer;
	PatientListPage patientListPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	
	@BeforeMethod
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);		
		login = new Login();
		testDataProvider = new TestDataProvider();
		recentTrnsPg = new CA_RecentTransmissionsPage(driver, extentReport);
		customer = new Customer();
		patientListPage=new PatientListPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
	}

	@Test
	public void WA_PA001_PatLst_MoreActns_01() throws Exception {	
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("physicianUser1");
		//customer = testDataProvider.getCustomerData("WA_80Rev3_PA001_PatinetList_01");
		extentTest.assignAuthor("Author: Rajesh Singaraj");
		try {
			Assertions assertions = new Assertions(extentTest);												
			String path=System.getProperty("user.dir")+"\\Downloads\\Merlin.net™ PCN.csv";
			
			
			
			extentReport.info("100 S The actor logs to a clinic where no columns have been removed and navigates to Patient List page");
			//patientListPage.loginAndNavigateToPatientListpage(login,"All");
			//loginPage.login(login,"externaluser");
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");			
			//patientListPage.selectTireOneFilterOption("Active Clinic Patients");
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTireOTwoFilterOption("All");
			
			
			extentReport.info("200 S The actor selects 'Add or Remove Columns' option from the More Actions-List Actions dropdown menu and navigates to PA002 modal window");
			//patientListPage.clickElement("MoreAction");
			//patientListPage.clickElement("AddOrRemoveColumns");
			//patientListPage.clickElement("AddOrRemoveModelWindow");
			
			extentReport.info("300 V Verify the list of columns displayed in the modal window are all checked");
			//patientListPage.SelectCheckBoxForAllColumns();
			
			extentReport.info("400 S The actor unchecks the Next Transmission column and saves the information");
			//patientListPage.clickElement("NextTransmission");
			//patientListPage.clickElement("ModelWindowSaveButton");
			
			extentReport.info("500 V Verify the Next Transmission column is saved as a preference and is no longer  displayed on PA001 page");
			//patientListPage.clickElement("nextTransmissionColumnInPA001");
			
			extentReport.info("600 V Verify when the actor re-logins to PA001, the add or remove column preferences are retained and the Next Transmission column is not displayed on the page");
			//recentTrnsPg.clickOnElement("SignOut");
			//patientListPage.minimizeBrowser();
			//loginPage.login(login,"externaluser");
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");			
			//patientListPage.selectTireOneFilterOption("Active Clinic Patients");
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTireOTwoFilterOption("All");
			//patientListPage.clickElement("nextTransmissionColumnInPA001");
			
			extentReport.info("700 S Repeat the steps from 100 to 600 for the following columns Patient Status, Past Transmission, Device Implant Date and Last Transmission");			
			//Patient status			
			//patientListPage.RemoveEachColumnAndVerifyInPatientList("PatientStatus","patientStatusColumnInPA001");
			//loginPage.login(login,"externaluser");
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTireOneFilterOption("Active Clinic Patients");
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTireOTwoFilterOption("All");
			//patientListPage.clickElement("patientStatusColumnInPA001");
			//Last transmission
			//patientListPage.RemoveEachColumnAndVerifyInPatientList("LastTransmission","lastTransmissionColumnInPA001");
			//loginPage.login(login,"externaluser");
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTireOneFilterOption("Active Clinic Patients");
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTireOTwoFilterOption("All");
			//patientListPage.clickElement("patientStatusColumnInPA001");
			//Past transmission
			//patientListPage.RemoveEachColumnAndVerifyInPatientList("PastTransmission","pastTransmissionColumnInPA001");	
			//loginPage.login(login2,"externaluser");
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTireOneFilterOption("Active Clinic Patients");
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTireOTwoFilterOption("All");
			//patientListPage.clickElement("patientStatusColumnInPA001");
			//Device Implant
			//patientListPage.RemoveEachColumnAndVerifyInPatientList("DeviceImplant","deviceImplantColumnInPA001");
			//loginPage.login(login,"externaluser");
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTireOneFilterOption("Active Clinic Patients");
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTireOTwoFilterOption("All");
			//patientListPage.clickElement("patientStatusColumnInPA001");
			
			extentReport.info("800 V Verify the system does not allow removing of the following fields  as they are not listed in PA001-Patient name");
			//patientListPage.clickElement("MoreAction");
			//patientListPage.clickElement("AddOrRemoveColumns");
			//patientListPage.clickElement("AddOrRemoveModelWindow");
			//patientListPage.verifyPatientNameInModelWindow();
			//patientListPage.clickElement("ModelWindowCancelButton");
			//patientListPage.clickElement("SignOut");
			
			extentReport.info("1200 S The actor logs to a clinic where no columns have been removed and navigates to Patient List page");
			//loginPage.login(login,"externaluser");
			//patientListPage.invisibleOfSpinner();
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//patientListPage.invisibleOfSpinner();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			//patientListPage.invisibleOfSpinner();
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.selectTierTwoFilterOption("All");
			//patientListPage.invisibleOfSpinner();
			//patientListPage.verifyTotalColumnsInPatientList();
			
			extentReport.info("1300 S The actor selects 'Download Spreadsheet' option from the More Actions-List Actions dropdown menu");
			//patientListPage.clickElement("MoreAction");
			//patientListPage.fileDeletion(path);
			//patientListPage.clickElement("DownloadSpreadsheet");
			
			extentReport.info("1400 V Verify a Save dialog box is displayed to save the downloaded spreadsheet");
			
			extentReport.info("1500 V Verify when the actor specifies a location and saves the file, the contents of the list is saved in .csv format on the actors computer");
			//patientListPage.copyingValueToClipboard(System.getProperty("user.dir")+"\\Downloads\\Merlin.net™ PCN.csv");
			//patientListPage.keyboardActions("Paste");
			//patientListPage.keyboardActions("Enter");
			
			extentReport.info("1600 V Verify the downloaded spreadsheet displays the table with the list of rows and columns in the order displayed to the user while performing the ‘Download to Spreadsheet’ action");
			//patientListPage.compareSpreadsheetAndUIValues(path);
						
			extentReport.info("1700 V Verify no Selection boxes, Images and Hyperlinks are downloaded to the spreadsheet");
			//patientListPage.verifySelectionBoxesImagesLinks(path,"PatientTable");
			//patientListPage.clickElement("SignOut");
			
			extentReport.info("1800 S Repeats steps from 1200 to 1700 by removing one or more columns from PA001 modal window");
			//loginPage.login(login,"externaluser");	
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.waitForLoading();
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.selectTier2FilterInDropdown();		
			//patientListPage.validationOfSpreadsheetWithPatientTableValues("RemoveOneOrMoreColumn");
			
			extentReport.info("1900 S Repeat steps from 1200 to 1700 for each of the filter options listed in the filter dropdown menu");
			//loginPage.login(login,"externaluser");	
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.waitForLoading();
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.validationOfSpreadsheetWithPatientTableValues("FilterOption");
			
			extentReport.info("2000 S Repeat steps from 1200 to 1700 with results from Search functionality in Column search mode");
			//loginPage.login(login,"externaluser");	
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.waitForLoading();
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.validationOfSpreadsheetWithPatientTableValues("ColumnSearch");
			
			extentReport.info("2100 S Repeat steps from 1200 to 1700 with results from  Search functionality in List search mode");
			//loginPage.login(login,"externaluser");	
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.waitForLoading();
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//patientListPage.invisibleOfSpinner();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			//patientListPage.invisibleOfSpinner();
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.validationOfSpreadsheetWithPatientTableValues("ListSearch");
			
			extentReport.info("2200 S Repeat steps from 1200 to 1700 using the Sort functionality on the columns");
			//loginPage.login(login,"externaluser");	
			//patientListPage.waitForLoading();patientListPage.waitForLoading();
			//patientListPage.waitForLoading();
			//clinicianHomeTopNavPage.navigateToPatientListPage();
			//patientListPage.invisibleOfSpinner();
			//assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			//patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			//patientListPage.invisibleOfSpinner();
			//patientListPage.selectTier2FilterInDropdown();
			//patientListPage.validationOfSpreadsheetWithPatientTableValues("SortFunctionality");
		
			extentReport.info("2300 S The actor logs to a clinic where no columns have been removed and navigates to Patient List page");
			loginPage.login(login,"externaluser");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.invisibleOfSpinner();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			patientListPage.invisibleOfSpinner();
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.invisibleOfSpinner();
			patientListPage.verifyTotalColumnsInPatientList();
			
			extentReport.info("2400 S The actor selects the Print List option from the More Actions dropdown menu");
			ArrayList<ArrayList<String>> value21=patientListPage.storeElementsFromUI("PatientTable");
			patientListPage.clickElement("MoreAction");
			patientListPage.clickElement("PrintButton");
			
			extentReport.info("2500 V Verify the system displays a print preview of the displayed list in the Print List modal window");
			patientListPage.clickElement("PrintPreviewButton");			
			
			extentReport.info("2600 V Verify the Print preview displays the table with the list of rows and columns in the order displayed to the user while performing the ‘Print List’ action");					
			ArrayList<ArrayList<String>> value22=patientListPage.storeElementsFromUI("PrintPreview");
			value21.containsAll(value22);
						
			extentReport.info("2700 V Verify no Selection boxes and Hyperlinks are displayed");
			patientListPage.verifySelectionBoxesImagesLinks(path,"PrintPreview");
			
			extentReport.info("2800 S The actor clicks on Print button on the Print preview page");
			patientListPage.clickElement("PrintButtonInPreview");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.clickElement("CancelButtonInPreview");
			
			//We cannot automate since this is in print preview
			extentReport.info("2900 V Verify the system sends the displayed list to the printer");			
			extentReport.info("3000 V Verify the Printed list displays the table with the list of rows and columns in the order displayed to the user while performing the ‘Print’ action");			
			extentReport.info("3100 V Verify no Selection boxes and Hyperlinks are displayed");
			
			extentReport.info("3200 S Repeats steps from 2300 to 3100 by removing one or more columns from PA002 modal window");
			loginPage.login(login,"externaluser");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.invisibleOfSpinner();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			patientListPage.invisibleOfSpinner();
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.invisibleOfSpinner();
			patientListPage.validationOfPrintPreviewWithPatientTableValues("RemoveOneOrMoreColumn");
			
			extentReport.info("3300 S Repeat steps from 2300 to 3100 for all the filter options listed in the filter dropdown menu");
			loginPage.login(login,"externaluser");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.invisibleOfSpinner();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			patientListPage.invisibleOfSpinner();
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.invisibleOfSpinner();
			patientListPage.validationOfPrintPreviewWithPatientTableValues("FilterOption");
			
			extentReport.info("3400 S Repeat steps from 2300 to 3100 with Search functionality in Column search mode");
			loginPage.login(login,"externaluser");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.invisibleOfSpinner();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			patientListPage.invisibleOfSpinner();
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.invisibleOfSpinner();
			patientListPage.validationOfPrintPreviewWithPatientTableValues("ColumnSearch");
			
			extentReport.info("3500 S Repeat steps from 2300 to 3100 with Search functionality in List search mode");
			loginPage.login(login,"externaluser");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.invisibleOfSpinner();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			patientListPage.invisibleOfSpinner();
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.invisibleOfSpinner();
			patientListPage.validationOfPrintPreviewWithPatientTableValues("ListSearch");
			
			extentReport.info("3600 S Repeat steps from 2300 to 3100 using the Sort functionality on the columns");
			loginPage.login(login,"externaluser");
			patientListPage.waitForLoading();patientListPage.waitForLoading();
			patientListPage.waitForLoading();
			clinicianHomeTopNavPage.navigateToPatientListPage();
			patientListPage.invisibleOfSpinner();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");	
			patientListPage.invisibleOfSpinner();
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.invisibleOfSpinner();
			patientListPage.validationOfPrintPreviewWithPatientTableValues("SortFunctionality");
			
		} catch (AssertionError e) {
			extentReport.fail("WA_80Rev3_PA001_PatinetList_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail("WA_80Rev3_PA001_PatinetList_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
