package com.test.qa.ui.tests.PA001;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;


public class WA_PatLst_PA001_PatLstFilter_06 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	private String testName;
	Customer customer;
	ClinicianHomeTopNavPage ClinicianHomeTopNavPage;
	PatientListPage patientListPage;
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		ClinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		login = new Login();
		
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		patientListPage=new PatientListPage(driver, extentReport);
	}
	
	@Test
	public void WA_PatLst_PA001_PatLstFilter_06() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("HCL_CA");
		
		
		extentTest.assignAuthor("Author - Victor");

		try {
			Assertions assertions=new Assertions(extentTest);
	
			extentReport.info("100 S Navigate to Patient List Page");
			loginPage.login(login,"externaluser");
			ClinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("200 S Select Tier1 filter as \"Inactive Patients\" and Tier 2 filter \"ALL");
			patientListPage.selectTierOneFilterOption("Inactive Patients");
			patientListPage.selectTierTwoFilterOption("All");
			extentReport.reportScreenShot("User is able to select Inactive Patients in tier 1 and select tier 2 filter dropdown as All");
			
			extentReport.info("300 V Verify that Patient Pat3, Pat4 and Pat5 are displayed in the Patient List Page for the filters selected.", new String[] {"<TransMgt16777>"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifySearchedPatientInTable("Patient_Expired"),extentReport, "Patient with Expired status is displayed");
			assertions.assertEqualsWithReporting(true,patientListPage.verifySearchedPatientInTable("Patient_Explanted"),extentReport, "Patient with Explanted status is displayed");
			assertions.assertEqualsWithReporting(true,patientListPage.verifySearchedPatientInTable("Patient_Removed"),extentReport, "Patient with Explanted status is displayed");
			
			
			extentReport.info("400 V Verify that the Pat1, Pat2 are not displayed in the Patient List page for the filters selected.", new String[] {"<TransMgt16777>"});
			assertions.assertEqualsWithReporting(false, patientListPage.verifySearchedPatientInTable("Patient_Released"), extentReport, "Patient_Released not displayed in filter list");
			assertions.assertEqualsWithReporting(false, patientListPage.verifySearchedPatientInTable("Patient_Active"), extentReport, "Patient_Active is not displayed in filter list");
			extentReport.reportScreenShot("Pat1, Pat2 are not displayed in the Patient List page for the filters selected");
			ClinicianHomeTopNavPage.clickSignOut();
			
			
			
			
		}catch (AssertionError e) {
			extentReport.reportFail("WA_PatLst_PA001_PatLstFilter_06 is failed due to assertion failure",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("WA_PatLst_PA001_PatLstFilter_06 is failed due to some exception",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	
		
	}

	
	
}
