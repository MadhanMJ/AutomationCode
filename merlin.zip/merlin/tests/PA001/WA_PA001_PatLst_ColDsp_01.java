package com.test.qa.ui.tests.PA001;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.*;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;


/* Author: Poojitha Gangiri
 * TC Name: WA-PA001-PatLst-ColDsp-01
 */

public class WA_PA001_PatLst_ColDsp_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	PL_TopNavPage pl_TopNavPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	DataBaseConnector dataBaseConnector;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	List<String> optionsValues;
	ArrayList<Date> transDateValue;
	
	@BeforeClass
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		pl_PatientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();	
		databaseResults = new HashMap<String,String>();
		optionsValues = new ArrayList<String>();
		transDateValue = new ArrayList<Date>();
		
	}

	@Test
	public void TC_WA_PA001_PatLst_ColDsp_01() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("TC1244068");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		
		try {
			assertion =  new Assertions(extentTest);
			extentReport.info("100 S-Navigate to Patient List Page.");
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			
			extentReport.info("200 S-Select Patient A(Test Data req) from Patient List.");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Tier1 filter is selected");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Tier2 filter is selected");
			patientListPage.enterTier3FilterInputBx("Radhya");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			
			extentReport.info("300 V-Verify that the patient First Name, Last name, and first letter of Middle name is displayed in patient name column.",new String[] {"TransMgt16797"});
			softAssert.assertEquals("Radhya",pl_PatientProfilePage.verifyFirstName(),"FirstName is displayed");
			softAssert.assertEquals("G",pl_PatientProfilePage.verifyMiddleName(),"MiddleName is displayed");
			softAssert.assertEquals("Sekhar",pl_PatientProfilePage.verifyLastName(),"LastName is displayed");
			extentReport.reportScreenShot("Patient name is populated on Patient profile page");
			
			extentReport.info("400 V-Verify that patient First Name, Last name, and Middle name is associated with Patient.FirstName, Patient.LastName and Patient.MiddleName in database.");
			String query = "select first_name,middle_name,last_name from patients.patient p where first_name  = 'Radhya';";
			databaseResults = queryResults.patientTable_TC1244068_scenario1(query);
			softAssert.assertEquals(databaseResults.get("first_name"),pl_PatientProfilePage.verifyFirstName(),"FirstName field is matching b/w database and UI");
			softAssert.assertEquals(databaseResults.get("middle_name"),pl_PatientProfilePage.verifyFirstName(),"MiddleName field is matching b/w database and UI");
			softAssert.assertEquals(databaseResults.get("last_name"),pl_PatientProfilePage.verifyFirstName(),"LastName field is matching b/w database and UI");
			
			extentReport.info("500 S-Select Patient B from Patient List.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Navigated to Patient List Page");
			patientListPage.enterTier3FilterInputBx("Niharikaniharikaniharikanihari");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Entered patient name in Tier3 filter");
			patientListPage.clickOnPatientNameFrmList("Niharikaniharikaniharikanihari");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			
			extentReport.info("600 V-Verify that Patient first, last and first letter of middle name is displayed correctly in patient name column.");
			softAssert.assertEquals("Niharikaniharikaniharikanihari",pl_PatientProfilePage.verifyFirstName(),"FirstName is displayed");
			softAssert.assertEquals("A",pl_PatientProfilePage.verifyMiddleName(),"MiddleName is displayed");
			softAssert.assertEquals("Niharikaniharikaniharikanihari",pl_PatientProfilePage.verifyLastName(),"LastName is displayed");
			extentReport.reportScreenShot("Patient name is populated on Patient profile page as expected");
			
			extentReport.info("900 S-Select Patient C from Patient List.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Navigated to Patient List Page");
			patientListPage.enterTier3FilterInputBx("Aditya");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Entered patient name in Tier3 filter");
			patientListPage.clickOnPatientNameFrmList("Aditya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			
			extentReport.info("1000V-Verify that the patient First Name, Last name, and first letter of Middle name is displayed in patient name column.");
			softAssert.assertEquals("Aditya",pl_PatientProfilePage.verifyFirstName(),"FirstName is displayed");
			softAssert.assertEquals("P",pl_PatientProfilePage.verifyMiddleName(),"MiddleName is displayed");
			softAssert.assertEquals("Adi",pl_PatientProfilePage.verifyLastName(),"LastName is displayed");
			extentReport.reportScreenShot("Patient name is populated on Patient profile page as expected");
				
			extentReport.info("1100 S-Select Patient D from Patient List.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Navigated to Patient List Page");
			patientListPage.enterTier3FilterInputBx("5347172");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Entered patient name in Tier3 filter");

			extentReport.info("1200 V-Verify the Patient ID is displayed in patient name column.",new String[] {"TransMgt16799"});
			softAssert.assertEquals(true,patientListPage.verifyPatientNameColumn("5347172"),"PatientId is displayed");
			patientListPage.clickOnPatientNameFrmList("5347172");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			softAssert.assertEquals("5347172",pl_PatientProfilePage.verifyPatientId(),"PatientId is displayed");
			
			extentReport.info("1300 V-Verify that patient ID is associated with Patient ID associated with [Customer_Application_Patient.Patient_Num in database.",new String[] {"TransMgt16799"});
			query = "select patient_num from patients.customer_application_patient cap where patient_num = '5347172';";
			databaseResults = queryResults.patientTable_TC1244068_scenario2(query);
			softAssert.assertEquals(databaseResults.get("patient_num"),pl_PatientProfilePage.verifyPatientId(),"Patient Id field is matching b/w database and UI");
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
