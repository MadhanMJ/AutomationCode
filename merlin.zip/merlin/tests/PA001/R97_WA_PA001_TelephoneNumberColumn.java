package com.test.qa.ui.tests.PA001;

import org.openqa.selenium.devtools.Command;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class R97_WA_PA001_TelephoneNumberColumn extends CommonUtils {
	LoginPageWithPOJO loginPage;
	Login login;
	Login loginEPClinic;
	Login loginActivatorClinic;
	
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	
	
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	
	
	@BeforeClass
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		loginEPClinic = new Login();
		loginActivatorClinic = new Login();
	}
	
	
	@Test
	public void PA001_TelephoneNumberColumn() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Vrushali Barhate");// comments
		try {
			loginEPClinic = testDataProvider.getLoginData("EPClinic_1238683"); //EP clinic
			
			assertion = new Assertions(extentTest);
			
			extentReport.info("100S Actor logs in to the Regular clinic and navigates to patient list page");
			loginPage.login(loginEPClinic);
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Landing page is NOT displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Patient list page is NOT displayed");
			
			extentReport.info("110V Verify that Telephone number column is not present [Negative]" , new String[] {"TransMgt17982"});
			patientListPage.addAllColumns();
			assertion.assertEqualsWithReporting(false, patientListPage.verifyTeleNumColumn(), extentTest, "Telephone Number column should not be displayed");
			
			extentReport.info("200S Select Patients with disconnected transmitters filter");
			patientListPage.selectTierTwoFilterOption("Patients with disconnected transmitters");
			patientListPage.addAllColumns();
			
			extentReport.info("300V Verify the order of the columns as below" +
					"Column 1: Patient Details" +
					"Column 2: Device" +
					"Column 3: Advisory" +
					"Column 4: Device Implant Date" +
					"Column 5: Connectivity" +
					"Column 6: Telephone Number" +
					"Column 7: Last Transmitter Communication" +
					"Column 8: Communication Type" +
					"Column 9: Connectivity Note" +
					"Column 10: Patient Select Box" , new String[] {"TransMgt17982"});
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Patient Details"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Device"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Advisory"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Device Implant Date"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Connectivity"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Telephone Number"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Last Transmitter Communication"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Communication Type"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Connectivity Note"));
			assertion.assertEquals(true, patientListPage.verifyPatientListColumnsHeading("Patient Select Box"));
			
			extentReport.info("400S Select Cardiac Moniter in 2nd tier filter");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			patientListPage.addAllColumns();
			
			extentReport.info("500V Verify that telephone number column is present" , new String[] {"TransMgt17982"});
			assertion.assertEqualsWithReporting(true, patientListPage.verifyTeleNumColumn(), extentTest, "Telephone Number column should not be displayed");
			
			extentReport.info("600S Click on sort button of Telephone number column");
			patientListPage.sort("telephone");
			
			extentReport.info("700V Verify the the column is sorted  and reverse order should be visible " , new String[] {"TransMgt17982"});
			assertion.assertEquals(patientListPage.getSortOrder(), "Ascending", "Sort Order should be ascending");
			
			extentReport.info("800S Again Click on sort button of Telephone number column");
			patientListPage.sort("telephone");
			
			extentReport.info("900V Verify the the column is sorted in other previous order ascending" , new String[] {"TransMgt17982"});
			assertion.assertEquals(patientListPage.getSortOrder(), "Descending", "Sort Order should be Descending");
			
			extentReport.info("1000S Select ICD/Pacemaker in filter");
			patientListPage.selectTierTwoFilterOption("ICD/Pacemaker");
			patientListPage.addAllColumns();
			
			extentReport.info("1100V Verify that Telephone number column is present" , new String[] {"TransMgt17982"});
			assertion.assertEqualsWithReporting(true, patientListPage.verifyTeleNumColumn(), extentTest, "Telephone Number column should be displayed");
			
			extentReport.info("1200S Select Patients with snoozed disconnected transmitters reporting filter");
			patientListPage.selectTierTwoFilterOption("Patients with snoozed disconnected transmitter reporting");
			patientListPage.addAllColumns();
			
			extentReport.info("1300V Verify that Telephone number column is present" , new String[] {"TransMgt17982"});
			assertion.assertEqualsWithReporting(true, patientListPage.verifyTeleNumColumn(), extentTest, "Telephone Number column should be displayed");
			
			extentReport.info("1400S logout and login into activator clinic");
			clinicianHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginActivatorClinic);
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Landing page is NOT displayed");
			
			extentReport.info("1500V Verify that The telephone number column not present and not able to sort" , new String[] {"TransMgt17980"});
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Patient list page is NOT displayed");
			patientListPage.addAllColumns();
			assertion.assertEqualsWithReporting(false, patientListPage.verifyTeleNumColumn(), extentTest, "Telephone Number column should not be displayed");
					 
			
			
		} catch (AssertionError e) {
			extentReport.reportFail("R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_5 Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_5 Validation not  successfull");
			throw e;
		}
	}

}
