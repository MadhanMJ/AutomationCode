package com.test.qa.ui.tests.PA001;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

/*Testcase name : WA-PA001-PatLst-ColDsp-03
 * Testcase Id: 1244070
 * Author : Shanmugapriya
 */

public class WA_PA001_PatLst_ColDsp_03 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	Login login_scenario_2;
	Login login_scenario_3;
	Login login_scenario_4;
	Login login_scenario_5;
	Login login_scenario_6;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	PatientListPage patientListPage;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		login = new Login();
		login_scenario_2= new Login();
		login_scenario_3= new Login();
		login_scenario_4= new Login();
		login_scenario_5= new Login();
		login_scenario_6= new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		patientListPage=new PatientListPage(driver, extentReport);
		
	}
	@Test
	public void wA_PA001_PatLst_ColDsp_03() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("DirectPhysician");
		login_scenario_2=testDataProvider.getLoginData("DirectAllied");
		login_scenario_3=testDataProvider.getLoginData("DirectAssistant");
		login_scenario_4=testDataProvider.getLoginData("SpPhysician");
		login_scenario_5=testDataProvider.getLoginData("SpAllied");
		login_scenario_6=testDataProvider.getLoginData("SpAssistant");
		extentTest.assignAuthor("Author - Shanmugapriya");
		try {
			Assertions assertions=new Assertions(extentTest);
            //clicking clinicLocation page in clinicAdministration tab			
			extentReport.info("100 S Login to clinic 1 and navigate to Patient List Page.");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("200 V Verify the defaults as"+ "Tier 1 Filter: Clinic Patients"+ "Tier 2 Filter: Patient Name" ,new String[] {"TransMgt16793"});
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier1FilterValue("My Active Patients"), extentReport, "Default value in Tier 1 is displayed");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier2FilterValue("Patient Name"), extentReport, "Default value in Tier 2 is displayed");		
			extentReport.reportScreenShot("User is able to see default values in Tier 1 and Tier 2");
			clinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("300 S Login to clinic 2 and navigate to Patient List Page");
			loginPage.login(login_scenario_2);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("400 V Verify the defaults as"+ "Tier 1 Filter: Clinic Patients"+ "Tier 2 Filter: Patient Name", new String[] {"TransMgt16793"});
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier1FilterValue("My Active Patients"), extentReport, "Default value in Tier 1 is displayed");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier2FilterValue("Patient Name"), extentReport, "Default value in Tier 2 is displayed");		
			extentReport.reportScreenShot("User is able to see default values in Tier 1 and Tier 2");
			clinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("500 S Login to clinic 3 and navigate to Patient List Page.");
			loginPage.login(login_scenario_3);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("600 V Verify the defaults as"+ "Tier 1 Filter: My Patients"+ "Tier 2 Filter: ALL", new String[] {"TransMgt16793"});
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier1FilterValue("My Active Patients"), extentReport, "Default value in Tier 1 is displayed");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier2FilterValue("Patient Name"), extentReport, "Default value in Tier 2 is displayed");		
			extentReport.reportScreenShot("User is able to see default values in Tier 1 and Tier 2");
			clinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("700 S Login to clinic 4 and navigate to Patient List Page.");
			loginPage.login(login_scenario_4);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("800 V Verify the defaults as"+ "Tier 1 Filter: Clinic Patients"+ "Tier 2 Filter: Patient Name", new String[] {"TransMgt16793"});
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier1FilterValue("My Active Patients"), extentReport, "Default value in Tier 1 is displayed");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier2FilterValue("Patient Name"), extentReport, "Default value in Tier 2 is displayed");		
			extentReport.reportScreenShot("User is able to see default values in Tier 1 and Tier 2");
			clinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("900 S Login to clinic 5 and navigate to Patient List Page.");
			loginPage.login(login_scenario_5);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("1000 V Verify the defaults as"+ "Tier 1 Filter: Clinic Patients"+ "Tier 2 Filter: Patient Name", new String[] {"TransMgt16793"});
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier1FilterValue("My Active Patients"), extentReport, "Default value in Tier 1 is displayed");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier2FilterValue("Patient Name"), extentReport, "Default value in Tier 2 is displayed");		
			extentReport.reportScreenShot("User is able to see default values in Tier 1 and Tier 2");
			clinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("1100 S Login to clinic 6 and navigate to Patient List Page.");
			loginPage.login(login_scenario_6);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("1200 V Verify the defaults as"+ "Tier 1 Filter: Clinic Patients"+ "Tier 2 Filter: ALL", new String[] {"TransMgt16793"});
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier1FilterValue("My Active Patients"), extentReport, "Default value in Tier 1 is displayed");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyTier2FilterValue("Patient Name"), extentReport, "Default value in Tier 2 is displayed");		
			extentReport.reportScreenShot("User is able to see default values in Tier 1 and Tier 2");
			clinicianHomeTopNavPage.clickSignOut();
			
			assertion.assertAll();
			
		}catch (AssertionError e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	

}

