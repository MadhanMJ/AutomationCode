package com.test.qa.ui.tests.PA001;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;


public class WA_96_PatientList_DisconnectedTransmitter_SnoozedDT_Filter extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	private String testName;
	ClinicianHomeTopNavPage ClinicianHomeTopNavPage;
	PatientListPage patientListPage;
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		ClinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		patientListPage=new PatientListPage(driver, extentReport);
	}
	
	@Test
	public void TC_WA_96_PatientList_DisconnectedTransmitter_SnoozedDT_Filter() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("MIST_NODC");
		
		extentTest.assignAuthor("Author - Madhan/Sai");

		try {
			Assertions assertions=new Assertions(extentTest);
	
			extentReport.info("100 S Login to a Direct/SP2 EP Clinic and click on the patient list tab");
			loginPage.login(login,"externaluser");
			ClinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("200 S Click on active patients option in tier 1 and Disconnected Transmitter filter in tier 2");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("Patients with disconnected transmitters");
			extentReport.reportScreenShot("User is able to select My Active Patients in tier 1 and selected Disconnected Transmitter in tier 2 filter dropdown");
			
			extentReport.info("300 V Verify all those patients who are having MIST or NODC condition are displayed <TransMgt17762>");
			patientListPage.enterTier3FilterInputBx("0310 Smoke0310");
		//	patientListPage.toVerifyMistcondition("No Communication >{{0}} days");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyMistcondition("No Communication >{{0}} days"), extentReport, "MIST Condition is displayed");
			
			extentTest = extentReport.info("400 S Select sub filter 'Cardiac Monitor' under Disconnected Transmitter filter in tier 2");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor under disconnected transmitters"); 
			extentTest = extentReport.info("500 V verify that only ICM device patients having MIST or NODC condition are displayed <TransMgt17763>");
			patientListPage.enterTier3FilterInputBx("1234778");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyICMcondition("Not Paired"), extentReport, "ICM Condition is displayed");
			
			extentTest = extentReport.info("600 S Select sub filter 'ICD/PM' under Disconnected Transmitter filter in tier 2");
			patientListPage.selectTierTwoFilterOption("ICD/Pacemaker under disconnected transmitters"); 
			extentTest = extentReport.info("700 V verify that only ICD/PM device patients having MIST and NODC condition are displayed <TransMgt17764>");
			patientListPage.enterTier3FilterInputBx("patient1 patient1");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyICMcondition("Not Paired"), extentReport, "ICM Condition is displayed");
			
			extentTest = extentReport.info("800 S Select Disconnected Transmitter filter in tier 2");
			patientListPage.selectTierTwoFilterOption("Patients with disconnected transmitters");
			
			extentTest = extentReport.info("900 V Verify that implant date column is displayed on the page and it displays the date of device implanted to patient <TransMgt17768>");
			patientListPage.enterTier3FilterInputBx("1234778");
			patientListPage.clickElement("deviceImplantColumnInPA001");
			extentReport.reportScreenShot("User is able to view the Implant Column");
			assertions.assertEqualsWithReporting(true, patientListPage.toImplantDate("06-07-2021"), extentReport, "Implant Date is displayed");
			
			extentTest = extentReport.info("1000 V verify that device field displays device name and device serial no <TransMgt19042>");
		 // assertions.assertEqualsWithReporting(true, patientListPage.toVerifyDevice("Confirm Rx? ICM :1234778"), extentReport, "Device Name and Serial no is displayed");
			
			extentTest = extentReport.info("1100 V Verify that the connectivity column is displayed which displays the current state of connection of patient<TransMgt17769>");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyConnectivityColumn(), extentReport, "Connectivity Column is displayed");
			
			extentTest = extentReport.info("1200 V Verify that advisory column and its information is displayed on the page , "
					+ "it displays those patients which are affected by premature battery depletion<TransMgt17766><TransMgt17756>");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyAdviosryColumn(), extentReport, "Connectivity Column is displayed");
		
			extentTest = extentReport.info("1300 V Verify that the last transmitter communication column is displayed and "
					+ "it displays date when last communication happened b/w merlin.net and transmitter<TransMgt17770>");
			patientListPage.clickElement("LastTrasnmitterCommunicationColumnInPA001");
			extentReport.reportScreenShot("User is able to view the last transmitter communication Column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyLastTransmitterDate("06-08-2021"), extentReport, "Last Transmitter Date is displayed");
			
			extentTest = extentReport.info("1400 V Verify that communication type is displayed on DT filter and "
					+ "it displays by which means communication has been done<TransMgt17771>");
			patientListPage.clickElement("MoreAction");
			patientListPage.clickElement("AddOrRemoveColumns");
			patientListPage.clickElement("ConnectionBtn");
			patientListPage.clickElement("DoneBtn");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyCommunicationType("Mobile Communication"), extentReport, "Communication Type is displayed");
		
			/*extentTest = extentReport.info("1500 V Verify that communication type column is not displayed on any of the patient list filters except "
					+ "DT and Snoozed DT filters <negative test><TransMgt17771>");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for Cardiac Monitor");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("ICD/Pacemaker");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for ICD/Pacemaker");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("Patients with no future schedule");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Patients with no future schedule");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("Patients with overdue follow-up");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for Patients with overdue follow-up");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("Patients with pending transmissions due today");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for Patients with pending transmissions due today");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("Patients released for transfer");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for Patients released for transfer");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("Release Requests from another clinic");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for Release Requests from another clinic");
			
			extentReport.reportScreenShot("User is not able to view the communication type");
			patientListPage.selectTierTwoFilterOption("Patients ready for billing (Cardiac Monitors)");
			extentReport.reportScreenShot("User could not able to see the connection column");
			assertions.assertEqualsWithReporting(true, patientListPage.connectionColumnIsNotDisplay(), extentReport, "Connection Column not displayed for Patients ready for billing (Cardiac Monitors)");
			
			extentTest = extentReport.info("1600 V Verify that the connectivity note is displayed "
					+ "only on DT filter and snoozed DT filters<TransMgt17772>");
			patientListPage.selectTierTwoFilterOption("Patients with snoozed disconnected transmitter reporting");
			extentReport.reportScreenShot("Snoozed DT is able to view the Connectivity Note");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Snoozed DT is able to view the Connectivity Note");
			patientListPage.selectTierTwoFilterOption("Patients with disconnected transmitters");
			extentReport.reportScreenShot("Disconnected transmitters is able to view the Connectivity Note");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Disconnected transmitters is able to view the Connectivity Note");
			*/
			extentTest = extentReport.info("1700 V Verify that user can add the connectivity note < TransMgt17774>");
			patientListPage.enterTier3FilterInputBx("patient1 patient1");
			patientListPage.connectivitityNote("addConnectivityNote");
			extentReport.reportScreenShot("User Added the connectivity note");
			//assertions.assertEqualsWithReporting(true, patientListPage.addConnectivityNote("Hello Abbott"), extentReport, "User Can add Connectivity Note");
			
			extentTest = extentReport.info("1800 V Verify that user can modify the connectivity note < TransMgt17774>");
			patientListPage.connectivitityNote("modifyConnectivityNote");
			extentReport.reportScreenShot("User modify the connectivity note");
			//assertions.assertEqualsWithReporting(true, patientListPage.addConnectivityNote("Hello Abbott"), extentReport, "User Can add Connectivity Note");
			
			extentTest = extentReport.info("1900 V Verify that user can clear the connectivity note < TransMgt17774>");
			patientListPage.connectivitityNote("clearConnectivityNote");
			extentReport.reportScreenShot("User cleared the connectivity note");
			//assertions.assertEqualsWithReporting(true, patientListPage.addConnectivityNote("Hello Abbott"), extentReport, "User Can add Connectivity Note");
			
			extentTest = extentReport.info("2000 V Verify that connectivity note column is not displayed on any of the patient list"
					+ "filters except DT and Snoozed DT filters <negative test> <TransMgt17772>");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note Column not displayed for Cardiac Monitor");
			
			patientListPage.selectTierTwoFilterOption("ICD/Pacemaker");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for ICD/Pacemaker");
			
			patientListPage.selectTierTwoFilterOption("Patients with no future schedule");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for Patients with no future schedule");
			
			patientListPage.selectTierTwoFilterOption("Patients with overdue follow-up");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for Patients with overdue follow-up");
			
			patientListPage.selectTierTwoFilterOption("Patients with pending transmissions due today");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for Patients with pending transmissions due today");
			
			patientListPage.selectTierTwoFilterOption("Patients released for transfer");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for Patients released for transfer");
			
			patientListPage.selectTierTwoFilterOption("Release Requests from another clinic");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for Release Requests from another clinic");
			
			patientListPage.selectTierTwoFilterOption("Patients ready for billing (Cardiac Monitors)");
			extentReport.reportScreenShot("User could not able to see the connectivity note column");
			assertions.assertEqualsWithReporting(true, patientListPage.toVerifyConnectivityNoteIsPresent(), extentReport, "Connectivity Note not displayed for Patients ready for billing (Cardiac Monitors)");
			
			extentTest = extentReport.info("2200 S Select one or more patients by checking the checkbox against each patient and "
					+ "go to more actions and click on snooze");
			patientListPage.selectTierTwoFilterOption("Patients with disconnected transmitters");
			patientListPage.enterTier3FilterInputBx("patient1");
			patientListPage.selectCheckBox();
			patientListPage.clickElement("MoreAction");
			patientListPage.clickElement("SnoozeNotifications");
			patientListPage.clickElement("snoozeOKButton_OR");
			
			
			
			//	assertions.assertEqualsWithReporting(true, patientListPage.toVerifyMistcondition(), extentReport, "PatientListPage is displayed");
//			patientListPage.toVerifyMistcondition("No Communication > {{0}} days");
		/*	patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTier2FilterInDropdown();
			assertions.assertEqualsWithReporting(false, patientListPage.validateDrpdwnContainDevice("Cardiac Monitor"), extentReport, "Cardiac Monitor is not displayed in filter list");
			assertions.assertEqualsWithReporting(false, patientListPage.validateDrpdwnContainDevice("ICD"), extentReport, "ICD Pacemaker is not displayed in filter list");
			extentReport.reportScreenShot("Cardiac Monitor and ICD/Pacemaker are not found in tier 2 filter");
			ClinicianHomeTopNavPage.clickSignOut();
			
			extentReport.info("400 S Login to a EP clinic having BLE Capable Device assigned. Clinic has ICD/PM/BLE Capable patients with in-clinic and remote transmissions. Navigate to EP Patient list.");
			loginPage.login(login_scenario_2); 
			ClinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			
			extentReport.info("500 S Select tier 1 filter as Active Clinic Patients and select tier 2 filter dropdown.");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTier2FilterInDropdown();
			extentReport.reportScreenShot("User is able to select Active Clinic Patients in tier 1 and select tier 2 filter dropdown");
			
			extentReport.info("600 V Verify that tier 2 show filters ‘Cardiac Monitor’ & ‘ICD/PM’ are displayed in filter list ", new String[] {"TransMgt17591", "TransMgt17592"});
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTier2FilterInDropdown();
			assertions.assertEqualsWithReporting(true, patientListPage.validateDrpdwnContainDevice("Cardiac Monitor"), extentReport, "Cardiac Monitor is displayed in filter list");
			assertions.assertEqualsWithReporting(true, patientListPage.validateDrpdwnContainDevice("ICD"), extentReport, "ICD/Pacemaker is displayed in filter list");
			extentReport.reportScreenShot("User is able to see Cardiac Monitor and ICD/PM are displayed in tier 2 filter");
			
			extentReport.info("700 S Select tier 1 filter as Active Clinic Patients and tier 2 filter as Cardiac Monitor");
//			patientListPage.selectTireOneFilterOption("Active Clinic Patients");
//			patientListPage.selectTireOTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			extentReport.reportScreenShot("User is able to select Cardiac Monitor in tier 2 filter");
			
			extentReport.info("800 V Verify that all active and released for transfer ICM Capable Patients in current clinic are displayed",new String[] {"TransMgt17591","TransMgt16775"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyPatientStatus("vardhani 813 confirm first"),extentReport,"Status of patient should be active or released");
			extentReport.reportScreenShot("User is able to see status for ICM Capable patients as active and released");
			
			extentReport.info("900 V Verify that in ‘All Transmissions’ column, for each ICM Capable Patient, Remote transmission count and In-clinic transmission count is displayed.", new String[] {"TransMgt17532", "TransMgt17533", "TransMgt13301"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyAllTransmissionInPatientList(),extentReport,"Remote and In-clinic transmission count is displayed");
			extentReport.reportScreenShot("User is able to see count of Remote and In-clinic transmission for Cardiac monitor");
			
			extentReport.info("1000 S Select tier 1 filter as My Active patients and tier 2 filter as Cardiac Monitor");
			patientListPage.selectTierOneFilterOption("My Active Patients");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			extentReport.reportScreenShot("User is able to select My Active Patients in tier 1 and Cardiac Monitor in tier 2 filter");
			
			extentReport.info("1100 V Verify that all active and released for transfer ICM Capable  Patients having logged in user as medical team member are displayed ",new String[] {"TransMgt17591", "TransMgt17683"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyPatientStatus("vardhani 813 confirm first"),extentReport,"Status of patient should be active or released");
			//Need to check
			assertions.assertEqualsWithReporting(true,patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName","1"),extentReport,"User logged as medical team member");
			extentReport.reportScreenShot("User is able to verify active and released for transfer ICM Capable  Patients having logged in user as medical team member.");
			
			extentReport.info("1200 S Select tier 1 filter as My Active patients and tier 2 filter as ICD/PM");
			patientListPage.selectTierOneFilterOption("My Active Patients");
			patientListPage.selectTierTwoFilterOption("ICD");
			extentReport.reportScreenShot("User is able to select My Active Patients in tier 1 and ICD/PM in tier 2 filter");
			
			extentReport.info("1300 V Verify that all active and released for transfer ICD/PM Patients having logged in user as medical team member are displayed",new String[] {"TransMgt17592>", "TransMgt17683"});
			//need to check
			assertions.assertEqualsWithReporting(true,patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName","1"),extentReport,"User logged as medical team member");
			extentReport.reportScreenShot("User is able to verify active and released for transfer ICD/PM Patients having logged in user as medical team member.");
			
			extentReport.info("1400 S Select tier 1 filter as Active Clinic Patients and tier 2 filter as ICD/PM");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTierTwoFilterOption("ICD/Pacemaker");
			extentReport.reportScreenShot("User is able to select ICD/Pacemaker in tier 2 filter");
			
			extentReport.info("1500 V Verify that all active and released for transfer ICD/PM Patients in current clinic are displayed", new String[] {"TransMgt17592", "TransMgt16775"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyPatientStatusInPatientListTable("patientName"),extentReport,"Status of patient should be active or released");
			extentReport.reportScreenShot("User is able to see status for ICM Capable patients as active and released");
			
			extentReport.info("1600 V Verify that in ‘All Transmissions’ column, for each ICD/PM Patient, Remote transmission count & In-clinic transmission count is displayed.", new String[] {"TransMgt17532", "TransMgt17533", "TransMgt13301"});
			assertions.assertEqualsWithReporting(true,patientListPage.verifyAllTransmissionInPatientList(),extentReport,"Remote and In-clinic transmission count is displayed");
			extentReport.reportScreenShot("User is able to see count of Remote and In-clinic transmission for ICD/Pacemaker");
			
			
		}catch (AssertionError e) {
			extentReport.reportFail("ICM_WA_PA001_PatientListFilters_01 is failed due to assertion failure",
					CommonUtils.convertStackTraceToString(e));
			throw e;*/
		} catch (Exception e) {
			extentReport.reportFail("ICM_WA_PA001_PatientListFilters_01 is failed due to some exception",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	
		
	}

	
	
}
