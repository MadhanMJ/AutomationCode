package com.test.qa.ui.tests.PA001;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_80Rev3_PA001_PatinetList_01 extends CommonUtils {

	/*
	 * Test case name: WA_80Rev3_PA001_PatinetList_01 Author: Rajesh Singaraj 
	 * Test case ID: 1244287
	 * 
	 */
	LoginPageWithPOJO loginPage;
	Login login;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTrnsPg;
	private String testName;
	private Log logger = new Log();
	Customer customer;
	PatientListPage patientListPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	
	@BeforeMethod
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);		
		login = new Login();
		testDataProvider = new TestDataProvider();
		recentTrnsPg = new CA_RecentTransmissionsPage(driver, extentReport);
		customer = new Customer();
		patientListPage=new PatientListPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
	}

	@Test
	public void wA_80Rev3_PA001_PatinetList_01() throws Exception {	
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("physicianUser1");
		customer = testDataProvider.getCustomerData("WA_80Rev3_PA001_PatinetList_01");
		extentTest.assignAuthor("Author: Rajesh Singaraj");
		try {
			Assertions assertions = new Assertions(extentTest);							
			
			extentReport.info("100 S Login to the application");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");			
			
			extentReport.info("200 S On Patient List page, select the filter for ‘Patients with overdue follow-up’.");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("Patients with overdue follow-up");
			
			extentReport.info("300 V Verify that the patients which have not send transmissions on the scheduled date are displayed. <TransMgt17284>");
			patientListPage.verifyPresenceOfPatient("NoOfPatientsInOverdueList",customer);			
			
			extentReport.info("400 S select any patient from the list");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.clickElement("SearchedPatient");
			
			extentReport.info("500 V Verify that the More Actions drop down has Clear Overdue Status option.<TransMgt17280>");
			patientListPage.clickElement("MoreAction");
			
			
			extentReport.info("600 S Remove the patient from the overdue list.");
			patientListPage.clickElement("ClearOverDue");
			
			extentReport.info("700 V Verify that the patient is not displayed in the overdue list.<TransMgt17280>");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.verifyPresenceOfPatient("verifyOverduePatientNotPresent", customer);
			
			
			extentReport.info("800 S Change the filter from ‘Patients with overdue follow-up’ to ‘All’.");
			patientListPage.selectTier2FilterInDropdown();
  			patientListPage.selectTierTwoFilterOption("All");
			
			extentReport.info("900 V Verify that the patient is displayed in that list");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.verifyPresenceOfPatient("PatientPresenceInPatientsList",customer);
			
			
			extentReport.info("1000 S Change the filter to ‘Patients with overdue follow-up’.");
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("Patients with overdue follow-up");
			
			extentReport.info("1100 S Select a patient which has one schedule date which is overdue and one has future schedule date.");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.clickElement("SearchedPatient");
			
			extentReport.info("1200 S From the More Action dropdown select Clear Overdue Status .");
			patientListPage.clickElement("MoreAction");
			patientListPage.clickElement("ClearOverDue");
			
			extentReport.info("1300 V Verify that the patient is not displayed in the  ‘Patients with overdue follow-up’ filter.<TransMgt17280>");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.verifyPresenceOfPatient("verifyOverduePatientNotPresent", customer);			
			
			
			extentReport.info("1400 S Again the transmission is not received on the scheduled future date.");
			//patientListPage.updatePatientToOverdueOrFutureStatus(customer.getCustomerApplicationID(),customer.getFollowupDateID(),false);
			extentReport.info("1500 V Verify that the patient is displayed again in  ‘Patients with overdue follow-up’ filter.");			
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.selectTier2FilterInDropdown();
			patientListPage.selectTierTwoFilterOption("Patients with overdue follow-up");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.verifyPresenceOfPatient("PatientPresenceInPatientsList",customer);
			
			
			extentReport.info("1600 S Select a patient which has one schedule date which is overdue and one has future schedule date.");
			patientListPage.clickElement("SearchedPatient");
			
			extentReport.info("1700 S From the More Action dropdown select Clear Overdue Status .");
			patientListPage.clickElement("MoreAction");
			patientListPage.clickElement("ClearOverDue");
			
			extentReport.info("1800 V Verify that the patient is not displayed in the ‘Patients with overdue follow-up’ filter");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.verifyPresenceOfPatient("verifyOverduePatientNotPresent", customer);
			extentReport.reportScreenShot("Verified that the patient is not displayed in ‘Patients with overdue follow-up’ filter.");
			
			extentReport.info("1900 S Again the transmission is received on the scheduled future date.");
			//Need to call upload transmission
			
			extentReport.info("2000 V Verify that the patient is not displayed again in ‘Patients with overdue follow-up’ filter. <TransMgt17284>");
			//patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.verifyPresenceOfPatient("verifyOverduePatientNotPresent", customer);
			//patientListPage.updatePatientToOverdueOrFutureStatus(customer.getCustomerApplicationID(),customer.getFollowupDateID(),false);
		  //patientListPage.updatePatientToOverdueOrFutureStatus(customer.getCustomerApplicationID(),customer.getFollowupDateID(),true);
								
			
			
			
		} catch (AssertionError e) {
			extentReport.fail("WA_80Rev3_PA001_PatinetList_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail("WA_80Rev3_PA001_PatinetList_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
