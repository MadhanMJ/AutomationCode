package com.test.qa.ui.tests.UC007AUC007B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.utilities.CommonUtils;

public class WA_IB001P_PrntTrans_DynComp_04 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	DataBaseConnector dataBaseConnector;
	CA_LeftNavPage ca_LeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	private Assertions assertion;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	private String testName;
	CA_RecentTransmissionsPage recentTransmissionPage ;  
	
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		clinicianHomeTopNavPage=new ClinicianHomeTopNavPage(driver, extentReport);
		ca_LeftNavPage=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage=new AppHomeTopNavPage(driver, extentReport);
		recentTransmissionPage = new CA_RecentTransmissionsPage(driver, extentReport);
		
	}
	
	@Test
	public void TC_WA_IB001P_PrntTrans_DynComp_04() throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		assertion = new Assertions(extentTest);
		
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("ActivaterClinicUser");
		extentTest.assignAuthor("Author - Abhishek kumar");
		try {
			
			extentTest = extentReport.info("100 S - The actor logs into the EP application and navigates to IB001.");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true, recentTransmissionPage.verifyLandingPage(), extentReport, "Recent Transmission page verified");
			
			extentReport.reportInfo("---VT/VF Episodes---");
			extentTest = extentReport.reportInfo("200 S - The actor checks checkbox of transmission for Patient A having all types of Episode reports. (Two of each type of episode, 1 marked as new, 1 marked as old) and click on Print button");
			recentTransmissionPage.enterTier3FilterInputBx("PatientName");
			recentTransmissionPage.slctVwdPatientChkBx("PateintName", "0");
			recentTransmissionPage.clickOnPrintButton();
			recentTransmissionPage.switchToWindow("Print Transmission");
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentTest = extentReport.reportInfo("300 S – The actor uncheck all checkboxes on Print Transmission page.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("UncheckAll");
			
			extentTest = extentReport.reportInfo("400 S - The actor checks VT/VF Episodes checkbox on Print Transmission page and select value “All” in the dropdown field for the VT/VF Episodes checkbox.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("VTVFEpisode");
			recentTransmissionPage.selectDropdownForEpisode("VT/VF Episodes","All");
			
			extentTest = extentReport.reportInfo("500 S - The actor clicks on Print button on Print Transmission page.");
			recentTransmissionPage.clickPrintButton();
			
			extentTest = extentReport.info("600 V - The Pop-up PDF Viewer Window is instantiated. It displays episode reports concatenated to each other only for following types of Episodes, which are marked as “New” by DDT. Old episode reports are not printed. ", new String [] {"<TransMgt3962>, <TransMgt16866>, <TransMgt4405>"});
			// need to implement this after discussion with Jaison
			
			extentTest = extentReport.reportInfo("700 S - The actor clicks the “Print” button on the PDF viewer.");
			recentTransmissionPage.clickPrintOnPatientRecord();
			
			extentTest = extentReport.reportInfo("800 S - The system opens a generic Print Dialog window and the actor clicks on the OK button on it");
			// need to implement this after discussion with JAison
			
			extentTest = extentReport.info("900 V - Verify that all the displayed VT/VF episode reports along with the cover sheet are printed appropriately in correct order as they are listed on the PDF viewer window.", new String[] {"TransMgt3964"});
			// need to implement this after discussion with Jaison / framework team
			
			extentTest = extentReport.reportInfo("1000 S - The actor clicks the close button on the PDF viewer window and returns back to the IB001 page.");
			recentTransmissionPage.clickCloseButton();
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentReport.reportInfo("---SVT Episodes---");
			
			extentTest = extentReport.info("1100 S -1100 S - The actor repeats steps 200 & 300");
			
			extentTest = extentReport.reportInfo("200 S - The actor checks checkbox of transmission for Patient A having all types of Episode reports. (Two of each type of episode, 1 marked as new, 1 marked as old) and click on Print button");
			recentTransmissionPage.enterTier3FilterInputBx("PatientName");
			recentTransmissionPage.slctVwdPatientChkBx("PateintName", "0");
			recentTransmissionPage.clickOnPrintButton();
			recentTransmissionPage.switchToWindow("Print Transmission");
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentTest = extentReport.reportInfo("300 S – The actor uncheck all checkboxes on Print Transmission page.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("UncheckAll");
			
			extentTest = extentReport.reportInfo("1200 S - The actor checks SVT Episodes checkbox on Print Transmission page and select value “All” in the dropdown field for the SVT Episodes checkbox.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("SVT Episodes");
			recentTransmissionPage.selectDropdownForEpisode("SVT Episodes","All");
			
			extentTest = extentReport.reportInfo("1300 S - The actor clicks on Print button on Print Transmission page.");
			recentTransmissionPage.clickPrintButton();
			
			extentTest = extentReport.info("1400 V - The Pop-up PDF Viewer Window is instantiated. It displays episode reports concatenated to each other only for following types of Episodes, which are marked as “New” by DDT. Old episode reports are not printed.", new String [] {"TransMgt3962, TransMgt16866, TransMgt4405"});
			// need to implement this after discussion with Jaison
			
			extentTest = extentReport.reportInfo("700 S - The actor clicks the “Print” button on the PDF viewer.");
			recentTransmissionPage.clickPrintOnPatientRecord();
			
			extentTest = extentReport.reportInfo("800 S - The system opens a generic Print Dialog window and the actor clicks on the OK button on it");
			// need to implement this after discussion with JAison
			
			extentTest = extentReport.info("1500 V - Verify that all the displayed SVT episode reports along with the cover sheet are printed appropriately in correct order as they are listed on the PDF viewer window.", new String[] {"TransMgt3964"});
			// need to implement this after discussion with Jaison / framework team
			
			extentTest = extentReport.reportInfo("1600 S - The actor clicks the close button on the PDF viewer window and returns back to the IB001 page.");
			recentTransmissionPage.clickCloseButton();
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());	
			
			
			extentReport.reportInfo("---AT/AF Episodes---");
			
			extentTest = extentReport.info("1700 S - The actor repeats steps 200 & 300");
			
			extentTest = extentReport.reportInfo("200 S - The actor checks checkbox of transmission for Patient A having all types of Episode reports. (Two of each type of episode, 1 marked as new, 1 marked as old) and click on Print button");
			recentTransmissionPage.enterTier3FilterInputBx("PatientName");
			recentTransmissionPage.slctVwdPatientChkBx("PateintName", "0");
			recentTransmissionPage.clickOnPrintButton();
			recentTransmissionPage.switchToWindow("Print Transmission");
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentTest = extentReport.reportInfo("300 S – The actor uncheck all checkboxes on Print Transmission page.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("UncheckAll");
			
			extentTest = extentReport.reportInfo("1800 S - The actor checks AT/AF Episodes checkbox on Print Transmission page and select value “All” in the dropdown field for the AT/AF Episodes checkbox.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("AT/AF Episodes");
			recentTransmissionPage.selectDropdownForEpisode("AT/AF Episodes","All");
			
			extentTest = extentReport.reportInfo("1900 S - The actor clicks on Print button on Print Transmission page.");
			recentTransmissionPage.clickPrintButton();
			
			extentTest = extentReport.info("2000 V - The Pop-up PDF Viewer Window is instantiated. It displays episode reports concatenated to each other only for following types of Episodes, which are marked as “New” by DDT. Old episode reports are not printed.", new String [] {"TransMgt3962, TransMgt16866, TransMgt4405"});
			// need to implement this after discussion with Jaison
			
			extentTest = extentReport.reportInfo("700 S - The actor clicks the “Print” button on the PDF viewer.");
			recentTransmissionPage.clickPrintOnPatientRecord();
			
			extentTest = extentReport.reportInfo("800 S - The system opens a generic Print Dialog window and the actor clicks on the OK button on it");
			// need to implement this after discussion with JAison
			
			extentTest = extentReport.info("2100 V - Verify that all the displayed AT/AF episode reports along with the cover sheet are printed appropriately in correct order as they are listed on the PDF viewer window.", new String[] {"TransMgt3964"});
			// need to implement this after discussion with Jaison / framework team
			
			extentTest = extentReport.reportInfo("2200 S - The actor clicks the close button on the PDF viewer window and returns back to the IB001 page.");
			recentTransmissionPage.clickCloseButton();
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());	
			
			extentReport.reportInfo("---Non-Sustainable Episodes---");
			
			extentTest = extentReport.info("2300 S - The actor repeats steps 200 & 300");
			
			extentTest = extentReport.reportInfo("200 S - The actor checks checkbox of transmission for Patient A having all types of Episode reports. (Two of each type of episode, 1 marked as new, 1 marked as old) and click on Print button");
			recentTransmissionPage.enterTier3FilterInputBx("PatientName");
			recentTransmissionPage.slctVwdPatientChkBx("PateintName", "0");
			recentTransmissionPage.clickOnPrintButton();
			recentTransmissionPage.switchToWindow("Print Transmission");
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentTest = extentReport.reportInfo("300 S – The actor uncheck all checkboxes on Print Transmission page.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("UncheckAll");
			
			extentTest = extentReport.reportInfo("2400 S - The actor checks Non-sustained Events checkbox on Print Transmission page and select value “All” in the dropdown field for the Non-sustained Events checkbox.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("Non-Sustainable Episodes");
			recentTransmissionPage.selectDropdownForEpisode("Non-Sustainable Episodes","All");
			
			extentTest = extentReport.reportInfo("2500 S - The actor clicks on Print button on Print Transmission page.");
			recentTransmissionPage.clickPrintButton();
			
			extentTest = extentReport.info("2600 V - The Pop-up PDF Viewer Window is instantiated. It displays episode reports concatenated to each other only for following types of Episodes, which are marked as “New” by DDT. Old episode reports are not printed.", new String [] {"TransMgt3962, TransMgt16866, TransMgt4405"});
			// need to implement this after discussion with Jaison
			
			extentTest = extentReport.reportInfo("700 S - The actor clicks the “Print” button on the PDF viewer.");
			recentTransmissionPage.clickPrintOnPatientRecord();
			
			extentTest = extentReport.reportInfo("800 S - The system opens a generic Print Dialog window and the actor clicks on the OK button on it");
			// need to implement this after discussion with JAison
			
			extentTest = extentReport.info("2700 V - Verify that all the displayed NSVT episode reports along with the cover sheet are printed appropriately in correct order as they are listed on the PDF viewer window.", new String[] {"TransMgt3964"});
			// need to implement this after discussion with Jaison / framework team
			
			extentTest = extentReport.reportInfo("2800 S - The actor clicks the close button on the PDF viewer window and returns back to the IB001 page.");
			recentTransmissionPage.clickCloseButton();
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentReport.reportInfo("---Other Episodes---");
			
			extentTest = extentReport.info("2900 S - The actor repeats steps 200 & 300");
			
			extentTest = extentReport.reportInfo("200 S - The actor checks checkbox of transmission for Patient A having all types of Episode reports. (Two of each type of episode, 1 marked as new, 1 marked as old) and click on Print button");
			recentTransmissionPage.enterTier3FilterInputBx("PatientName");
			recentTransmissionPage.slctVwdPatientChkBx("PateintName", "0");
			recentTransmissionPage.clickOnPrintButton();
			recentTransmissionPage.switchToWindow("Print Transmission");
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			extentTest = extentReport.reportInfo("300 S – The actor uncheck all checkboxes on Print Transmission page.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("UncheckAll");
			
			extentTest = extentReport.reportInfo("3000 S - The actor checks Other Episodes checkbox on Print Transmission page and select value “All” in the dropdown field for the Other Episodes checkbox.");
			recentTransmissionPage.allPrintSummaryCheckboxStatus("Non-Sustainable Episodes");
			recentTransmissionPage.selectDropdownForEpisode("Non-Sustainable Episodes","All");
			
			extentTest = extentReport.reportInfo("3100 S - The actor clicks on Print button on Print Transmission page.");
			recentTransmissionPage.clickPrintButton();
			
			extentTest = extentReport.info("3200 V - The Pop-up PDF Viewer Window is instantiated. It displays episode reports concatenated to each other only for following types of Episodes, which are marked as “New” by DDT. Old episode reports are not printed.", new String [] {"TransMgt3962, TransMgt16866, TransMgt4405"});
			// need to implement this after discussion with Jaison
			
			extentTest = extentReport.reportInfo("700 S - The actor clicks the “Print” button on the PDF viewer.");
			recentTransmissionPage.clickPrintOnPatientRecord();
			
			extentTest = extentReport.reportInfo("800 S - The system opens a generic Print Dialog window and the actor clicks on the OK button on it");
			// need to implement this after discussion with JAison
			
			extentTest = extentReport.info("3300 V - Verify that all the displayed Other episode reports along with the cover sheet are printed appropriately in correct order as they are listed on the PDF viewer window.", new String[] {"TransMgt3964"});
			// need to implement this after discussion with Jaison / framework team
			
			extentTest = extentReport.reportInfo("3400 S - The actor clicks the close button on the PDF viewer window and returns back to the IB001 page.");
			recentTransmissionPage.clickCloseButton();
			assertion.assertTrue(recentTransmissionPage.verifyPrintTransmission());
			
			assertion.assertAll();
	      		
	}
		catch (AssertionError e) {
			extentReport.reportFail( "WA_IB001P_PrntTrans_DynComp_04 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			
			
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "WA_IB001P_PrntTrans_DynComp_04 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			
			
			throw e;
		}		

}

	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}
}
