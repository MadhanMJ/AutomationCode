package com.test.qa.ui.tests.UC021A;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ClinicalCommentsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_CA_800_Clinical_Comments_Dynamic_Components_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	CA_ClinicSettings_ClinicalCommentsPage clinicSettings_ClinicalCommentsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage leftNavPage;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	Login login;
	private String testName;
	private Log logger = new Log();
	
	@BeforeClass
	public void initialize() {
		
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicSettings_ClinicalCommentsPage = new CA_ClinicSettings_ClinicalCommentsPage(driver, extentReport);
		leftNavPage = new CA_LeftNavPage(driver, extentReport);
	}
	
	// Testcase id: 1244038, Test Def ID:  2629753
	//Testcase name: WA-CA 800-Clinical Comments-Dynamic Components-01, Author- Snehal Mane
	
	@Test(groups= {"Regression"})
	public void Clinical_Comments_Dynamic_Components_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		login = testDataProvider.getLoginData("PhAdmDirUs");
		
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
			
		extentTest.assignAuthor("Author-Snehal Mane");
		try {
		
			extentReport.info("100-S- The Actor is logged into system and navigates to Clinical Comments page");
			loginPage.login(login, "externaluser");			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertEqualsWithReporting(true, leftNavPage.verifyLandingPage(), extentReport, "Clinical Administration page is displayed");
			leftNavPage.clickClinicalCommentsLink();
			
			extentReport.info("200-V- Verify that the Clinical Comments page is displayed.", new String[] {"ClncMgt27722"});
			clinicSettings_ClinicalCommentsPage.pageLoad();
			assertion.assertEqualsWithReporting(true, clinicSettings_ClinicalCommentsPage.verifyLandingPage(), extentReport, "Clinical Comments page is landed successfully");
			
			extentReport.info("300-V- Verify that the following preferences are available in Clinical Comments page:"+"<br/>"+
			"a) Allow Free form Text"+"<br/>"+"b) Allow Pre-Set Comments", new String[] {"ClncMgt27805", "ClncMgt30978", "ClncMgt206"});
			assertion.assertEqualsWithReporting(true, clinicSettings_ClinicalCommentsPage.checkPreferenceAvailable(), extentReport, "Allow Free Form Text Preference and Allow Pre-Set Comments Preference Check");
						
			extentTest = extentReport.info("400-V- The Default Pre-set Comments contains values available", new String[] {"ClncMgt30979"});		
			assertion.assertEqualsWithReporting(true, clinicSettings_ClinicalCommentsPage.verifyAllowPreSetCommentsChkBoxSelected(), extentReport, "Allow Pre-Set Comments checkbox is selected");
			assertion.assertEqualsWithReporting(true, clinicSettings_ClinicalCommentsPage.verifyDefaultPreSetComments(), extentReport, "Pre-Set Comments are present");
			extentTest.info(clinicSettings_ClinicalCommentsPage.preSetComments().toString());
			
			extentReport.info("500-V- Verify the following comments are available in the same order on the Predefined List of comments:"
					+"<br/>"+ " a) Change in Blood Pressure"
					+"<br/>"+ " b) Chronic AFib"
					+"<br/>"+ " c) Increased Chest Pain", new String[] {"ClncMgt27809"});
		
			assertion.assertEqualsWithReporting(true, clinicSettings_ClinicalCommentsPage.validatePreSetCommentsOrder(), extentReport, "Pre-Set comments are available in the same order on the Predefined List of comments");
			
		} 
		
		
		
		catch (AssertionError e) {
			extentTest = extentReport.fail("WA_CA_800_Clinical_Comments_Dynamic_Components_01 to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			extentTest.fail("Clinical_Comments_Dynamic_Components_01 to assertion failure"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
			}

			catch (Exception e) {
			extentTest = extentReport.fail("WA_CA_800_Clinical_Comments_Dynamic_Components_01 due to exception");
			extentTest.fail("Clinical_Comments_Dynamic_Components_01 due to some exception"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
			}
		}
		
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
	

}