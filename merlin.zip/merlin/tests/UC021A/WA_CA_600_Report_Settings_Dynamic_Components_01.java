package com.test.qa.ui.tests.UC021A;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Poojitha Gangiri
 * Test Case: WA-CA 600-Report Settings-Dynamic Components-01
 * Test case id: 1244036
 */

public class WA_CA_600_Report_Settings_Dynamic_Components_01 extends CommonUtils {

	
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	
	LoginPageWithPOJO loginPage;
	Login login;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;


	@BeforeMethod(alwaysRun=true)
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		softAssert = new Assertions(extentTest);
	}

	@Test
	public void TC_WA_CA_600_Report_Settings_Dynamic_Components_01() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("TC1244036_Physician");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		try {
			assertion =  new Assertions(extentTest);
			extentReport.info( "100-S- The Actor is logged into system and navigates to Report Settings page from Clinic Administration tab");
			
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and Clinician HomePage is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicAdminLeftNavPage.navigateToReportSettingsPage();
			
			extentReport.info("200-V- Verify that the Report Settings page is displayed.",new String[] {"ClncMgt32174"});
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport,"Report settings Page is displayed");
			
			extentReport.info("300-V- Verify that the printing preferences display the reports contains all the values mentioned",new String[] {"ClncMgt27717", "Config23009", "ClncMgt32176", "ClncMgt27020", "ClncMgt30781", "ClncMgt32176"});
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("SelectAll"), false, "The 'Select All' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("SelectAll"), "Select All", "The 'Select All' check box text equals to 'Select All'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("Summary"), false, "The 'Summary' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("Summary"),"Summary", "The 'Summary' check box text equals to 'Summary'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("FastPathSummary"), true, "The 'Fast Path Summary' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("FastPathSummary"),"FastPath™ Summary", "The 'Fast Path Summary' check box text equals to 'FastPath Summary'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("EpisodesSummary"), false, "The 'Episodes Summary' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("EpisodesSummary"),"Episodes Summary", "The 'Episodes Summary' check box text equals to 'Episodes Summary'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("DiagnosticSummary"), false, "The 'Diagnostics Summary' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("DiagnosticSummary"),"Diagnostics Summary", "The 'Diagnostics Summary' check box text equals to 'Diagnostics Summary'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("PatientInfoLeads"), true, "The 'Patient Info and Leads' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("PatientInfoLeads"),"Patient Info and Leads", "The 'Patient Info and Leads' check box text equals to 'Patient Info and Leads'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("MRISummary"), true, "The 'MRI Summary' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("MRISummary"), "MRI Summary", "The 'MRI Summary' check box text equals to 'MRI Summary'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("AllTests"), false, "The 'All Tests' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("AllTests"), "All Tests", "The 'All Tests' check box text equals to 'All Tests'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("RTMTrend"), false, "The 'RTM Trend' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("RTMTrend"), "RTM Trend", "The 'RTM Trend' check box text equals to 'RTM Trend'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("CaptureThreshold"), false, "The 'Capture Threshold' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("CaptureThreshold"), "Capture Threshold", "The 'Capture Threshold' check box text equals to 'Capture Threshold'");

			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("TestResults"), false, "The 'Test Results' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("TestResults"), "Test Results", "The 'Test Results' check box text equals to 'Test Results'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("CRTToolKit"), false, "The 'CRT Toolkit' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("CRTToolKit"), "CRT Toolkit", "The 'CRT Toolkit' check box text equals to 'CRT Toolkit'");

			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("AllAlertsEpisodes"), false, "The 'All Alerts and Episodes' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("AllAlertsEpisodes"), "All Alerts and Episodes", "The 'All Alerts and Episodes' check box text equals to 'All Alerts and Episodes'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("AlertSummary"), false, "The 'Alert Summary' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("AlertSummary"), "Alert Summary", "The 'Alert Summary' check box text equals to 'Alert Summary'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("RealtimeEGM"), false, "The 'Real-time EGMs' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("RealtimeEGM"), "Real-time EGMs", "The 'Real-time EGMs' check box text equals to 'Real-time EGMs'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("ExtendedEpisodes"), false, "The 'Extended Episodes' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("ExtendedEpisodes"), "Extended Episodes", "The 'Extended Episodes' check box text equals to 'Extended Episodes'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("VT/VFEpisodes"), false, "The 'VT/VF Episodes' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("VT/VFEpisodes"), "VT/VF Episodes", "The 'VT/VF Episodes' check box text equals to 'VT/VF Episodes'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("SVTEpisodes"), false, "The 'SVT Episodes' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("SVTEpisodes"), "SVT Episodes", "The 'SVT Episodes' check box text equals to 'SVT Episodes'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("AT/AFEpisodes"), false, "The 'AT/AF Episodes' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("AT/AFEpisodes"), "AT/AF Episodes", "The 'AT/AF Episodes' check box text equals to 'AT/AF Episodes'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("NonSustainedEpisodes"), false, "The 'Non-sustained Events' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("NonSustainedEpisodes"), "Non-sustained Events", "The 'Non-sustained Events' check box text equals to 'Non-sustained Events'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("OtherEpisodes"), false, "The 'Other Episodes' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("OtherEpisodes"), "Other Episodes", "The 'Other Episodes' check box text equals to 'Other Episodes'");
			
		//	assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("CardiacMonitor"), false, "The 'Episodes' check box is unchecked.");
		//	assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("CardiacMonitor"), "Episodes", "The 'Episodes' check box text equals to 'Episodes'");
			
			

			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("AllDiagnostics"), false, "The 'All Diagnostics' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("AllDiagnostics"), "All Diagnostics", "The 'All Diagnostics' check box text equals to 'All Diagnostics'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("ExtendedDiagnostics"), false, "The 'Extended Diagnostics' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("ExtendedDiagnostics"), "Extended Diagnostics", "The 'Extended Diagnostics' check box text equals to 'Extended Diagnostics'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("Tachy"), false, "The 'Tachy' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("Tachy"), "Tachy", "The 'Tachy' check box text equals to 'Tachy'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("Brady"), false, "The 'Brady' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("Brady"), "Brady", "The 'Brady' check box text equals to 'Brady'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("HeartInFocus"), false, "The 'Heart In Focus' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("HeartInFocus"), "Heart In Focus™", "The 'Heart In Focus' check box text equals to 'Heart In Focus'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("STMonitoring"), false, "The 'ST Monitoring' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("STMonitoring"), "ST Monitoring", "The 'ST Monitoring' check box text equals to 'ST Monitoring'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("Corvue"), false, "The 'Corvue Report' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("Corvue"), "Corvue™ Report", "The 'Corvue Report' check box text equals to 'Corvue Report'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("AT/AF"), false, "The 'AT/AF' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("AT/AF"), "AT/AF", "The 'AT/AF' check box text equals to 'AT/AF'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("DirectTrend"), false, "The 'Direct Trend Report' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("DirectTrend"), "DirectTrend™ Report", "The 'Direct Trend Report' check box text equals to 'Direct Trend Report'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("Parameters"), false, "The 'Parameters' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("Parameters"), "Parameters", "The 'Parameters' check box text equals to 'Parameters'");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("WrapUp"), false, "The 'Wrap Up Overview' check box is unchecked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("WrapUp"), "Wrap Up Overview", "The 'Wrap Up Overview' check box text equals to 'Wrap Up Overview'");
						
			extentReport.info("400-V- Verify that in the Print Cover Sheet section, the preferences displayed matches with the requirement",new String[] {"Config269", "ClncMgt27029", "ClncMgt32176"});
			clinicSettings_ReportSettingsPage.clickEditButton();
			assertion.assertEqualsWithReporting(true,clinicSettings_ReportSettingsPage.verifyLandingPage(),extentReport,"Report settings page is loaded after clicking on edit button");			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("PrintCoverSheet"), true,"The 'Always print cover sheet' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("PrintCoverSheet"), "Always print cover sheet", "The 'Always print cover sheet' check box text equals to 'Always print cover sheet'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("PrintCoverSheet"), "Enabled","The 'Always print cover sheet' check box is enabled.");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("PatientName"), true, "The 'Patient name' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("PatientName"), "Patient name", "The 'Patient name' check box text equals to 'Patient name'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("PatientName"), "Enabled","The 'PatientName' check box is enabled.");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("ClinicName"), true, "The 'Clinic name' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("ClinicName"), "Clinic name", "The 'Clinic name' check box text equals to 'Clinic name'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("ClinicName"), "Enabled","The 'ClinicName' check box is enabled.");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("CommentBox"), false, "The 'Comment box' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("CommentBox"), "Comment box", "The 'Comment box' check box text equals to 'Comment box'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("CommentBox"), "Enabled","The 'CommentBox' check box is enabled.");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("MedicalTeam"), false, "The 'Medical Team' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("MedicalTeam"), "Medical Team", "The 'Medical Team' check box text equals to 'Medical Team'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("MedicalTeam"), "Enabled","The 'MedicalTeam' check box is enabled.");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("PageNumber"), false, "The 'Page number' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("PageNumber"), "Page Number", "The 'Page number' check box text equals to 'Page number'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("PageNumber"), "Enabled","The 'Page number' check box is enabled.");
			
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("TodayDate"), true, "The 'Today's date' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyLabelText("TodayDate"), "Today's date", "The 'Today's date' check box text equals to 'Today's date'");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("TodayDate"), "Enabled","The 'TodayDate' check box is enabled.");
			
			extentReport.info("500-V- Verify that preferences for printing comments contains the value as mentioned in requirement",new String[] {"Config13122","ClncMgt27010","ClncMgt6626"});
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBox("PrintComments"), true, "'Always Print Comments' check box is checked.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyTextInAlwaysPrintCommentsStarting_span_ClncMgt27010("90"),true, "Default days is 90 as expected");
			clinicSettings_ReportSettingsPage.selectCheckBox("PrintComments");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyCheckBoxEnabled("PrintComments"), "Enabled","The 'PrintComments' check box is enabled.");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyPrintCommentsDropdownValues(),true,"Print comments dropdown values are matching with 10,20,30,60 and 90 days");
			assertion.assertEquals(clinicSettings_ReportSettingsPage.verifyAbleToChoosePrintCommentStartingDays("60 days"),true,"User is able to select 60 days from dropdown");
			extentReport.reportScreenShot("Always Print comments section validation is successful");
			
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
		clinicianHomeTopNavPage.clickSignOutLink();
		saintResult(result, extentTest);
		}
}

