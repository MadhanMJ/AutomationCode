package com.test.qa.ui.tests.UC021A;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ExportOptions;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

import io.restassured.internal.common.assertion.Assertion;

import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;

public class WA_CA_700_ExportOptionsDynamicComponents_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;			
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;	
	CA_LeftNavPage clinicAdminLeftNav;
	AppHomeTopNavPage appHomeTopNavPage;	
	CA_ClinicSettings_ExportOptions exportOpt;

	@BeforeClass
	public void initialize() {
		//initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();			
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicAdminLeftNav=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);		
		exportOpt = new CA_ClinicSettings_ExportOptions(driver, extentReport);
	}

	//Test case name: WA-CA 700-Export Options-Dynamic Components-01
	//Author: Bhupendra Dhore
	@Test
	public void UC021AWA_CA_700_ExportOptionsDynamicComponents_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);

		extentTest.assignAuthor("Bhupendra Dhore");
		Assertions assertion =  new Assertions(extentTest);
		try {			

			ArrayList<Login> users = new ArrayList<>();
			users.add(testDataProvider.getLoginData("PH_CLINIC_I"));
			users.add(testDataProvider.getLoginData("AP_H_8_ADM"));
			
			for(Login user : users)				
			{
				extentReport.info("100-S- The Actor is logged into system and navigates to Export Options page");		
				loginPage.login(user,"externaluser");
				clinicianHomeTopNavPage.clickClinicAdministrationLink();			
				clinicAdminLeftNav.navigateExportSettingsPage();


				extentReport.info( "200-V- Verify that the Export Options page is displayed.", new String[] {"ClncMgt27025"});			
				assertion.assertEquals(true, exportOpt.verifyLandingPage(), "Verified that the Export Options page is displayed.");


				extentReport.info("300-V- Verify that a preference to enable/disable Export to EHR is displayed", new String[] {"ClncMgt6622","ClncMgt27221"});
				exportOpt.verifyEnablAutoExprToEHRChkBx();


				extentReport.info("400-V- Verify that the following fields are available when setup export to EHR field is enabled for the clinic in the Export to EHRsection a) IP, b) Port,c) Character Encoding with value UTF-8,d) EHR Application name, e) EHR Facility name,f) Message payload format",new String[] {"ClncMgt28237","ClncMgt31020"});		
				exportOpt.verifyExportOptionInputFields();


				extentReport.info( "500-V- Verify that the preference to include clinical comments is displayed.", new String[] {"ClncMgt28240"});
				exportOpt.verifyInclCmntInExprtRprtChkBx();


				extentReport.info("600-V- Verify that the preference to set Auto Export to EHR is displayed.", new String[] {"ClncMgt27537"});
				exportOpt.verifyEnablAutoExprToEHRChkBx();


				extentReport.info("700-V- Verify that the default value for Auto Export to EHR is 'OFF'.", new String[] {"ClncMgt27537","Config264"});
				exportOpt.verifyEnablAutoExprToEHRChkBxIsDisable();


				extentReport.info("800-V- Verify that the default value for Auto Export to PC database is 'OFF'.", new String[] {"Config265","ClncMgt6624"});
				exportOpt.verifySetupEcprtToPcChkBxIsDisable();		


				extentReport.info("900-V- Verify that the default value for Export of Transmission Data files is 'OFF'.", new String[] {"ClncMgt6624","Config13110"});
				exportOpt.verifySetupExprtOfTrnsDataChkBxIsDisable();
				
				appHomeTopNavPage.clickSignOutLink();
			}

		} 
		catch (AssertionError e) {
			extentTest = extentReport.fail( "UC021AWA_CA_700_ExportOptionsDynamicComponents_01 is failed due to assertion failure");
			extentTest.fail("UC021A UC021AWA_CA_700_ExportOptionsDynamicComponents_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("UC021A UC021AWA_CA_700_ExportOptionsDynamicComponents_01 is failed due to some exception");
			extentTest.fail("UC021A UC021AWA_CA_700_ExportOptionsDynamicComponents_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			status = "Success";
		} 

		writeInTextFile(testMethodName, status);
	}

}
