package com.test.qa.ui.tests.UC021A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_CA_200_SchedulingAndMessaging_DynamicComponents_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_SchedulingAndMessagingPage clinicAdminSchedulingAndMessagingPage;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;
	private Log logger = new Log();
	List<String> expectedSchedulingOptions = new ArrayList<String>();

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminSchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		expectedSchedulingOptions.add("SmartSchedule™ calendar");
		expectedSchedulingOptions.add("Manual entry calendar");
		expectedSchedulingOptions.add("None");
	}

	@Test
	public void wa_CA_200_SchedulingAndMessaging_DynamicComponents_01() throws Exception {
		//TC Name - WA-CA 200-Scheduling and Messaging-Dynamic Components-01
		//TC Id - 1244033
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMClinic_locations");
		customer = testDataProvider.getCustomerData("WA_CA_200_SchedulingAndMessaging_DynamicComponents_01");
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");

		try {
			softAssert = new Assertions(extentTest);
			
			extentReport.info("100-S- The Actor is logged into system and navigates to the Scheduling & Messaging page");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			clinicAdminLeftNavPage.clickSchedMessagingLink();
			
			extentTest = extentReport.info("200-V- Verify that the Scheduling & Messaging page shall be displayed",new String[] {"ClncMgt26750"});
			softAssert.assertEqualsWithReporting(clinicAdminSchedulingAndMessagingPage.verifyLandingPage(),true, extentTest,"Scheduling & Messaging page is displayed");
			
			extentReport.info("400-V- Verify that options available in Scheduling Method matches with the requirement",new String[] {"Config278","ClncMgt26754","ClncMgt30989"});
			//clinicAdminSchedulingAndMessagingPage.invisibilityOfElementLocated(clinicAdminSchedulingAndMessagingPage.pageLoading);
			extentReport.reportScreenShot("Scheduling method options");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getSchedulingMethods(), expectedSchedulingOptions,"Scheduling Method Options verified");
		
			extentReport.info("500-V- Verify that the following options are available in DirectCall Preference",new String[] {"ClncMgt26755","ClncMgt6627","Config13127","ClncMgt30982","Config14566","ClncMgt30983"});
			//clinicAdminSchedulingAndMessagingPage.invisibilityOfElementLocated(clinicAdminSchedulingAndMessagingPage.pageLoading);
			extentReport.reportScreenShot("Options are available in DirectCall Preference");
			
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.directCallAutomatedReferences_OR, clinicAdminSchedulingAndMessagingPage.directCallAutomatedReferences_S),true," a) DirectCall Automated Followup Reminder Call preference checkbox verification");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttributeWithReport(clinicAdminSchedulingAndMessagingPage.directCallAutomatedReferencesInput_OR, "aria-checked",clinicAdminSchedulingAndMessagingPage.directCallAutomatedReferencesInput_S),"false"," a) DirectCall Automated Followup Reminder Call preference with default value as 'OFF'");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.directCallOverdueMessages_OR, clinicAdminSchedulingAndMessagingPage.directCallOverdueMessages_S),true,"b) DirectCall Automated overdue call preferences checkbox verification");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttributeWithReport(clinicAdminSchedulingAndMessagingPage.directCallOverdueMessagesInput_OR,"aria-checked", clinicAdminSchedulingAndMessagingPage.directCallOverdueMessagesInput_S),"false","b) DirectCall Automated overdue call preferences with with default value as 'OFF'");
			
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.sendMessagesBetweenBox_OR, clinicAdminSchedulingAndMessagingPage.sendMessagesBetweenBox_S),true,"c) DirectCall Time Range preference - Send Messages Between");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.sendMessagesAndBox_OR, clinicAdminSchedulingAndMessagingPage.sendMessagesAndBox_S),true,"c) DirectCall Time Range preference - Send Messages And");
			
			extentReport.info("600-V- Verify that the following fields are displayed in the Transmitter Setup Preference section of the page",new String[] {"ClncMgt26756","ClncMgt30986","ClncMgt26758","ClncMgt30984","ClncMgt26760","ClncMgt30985","ClncMgt26757"});
			
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.dailyDirectAlertsCheck_OR, clinicAdminSchedulingAndMessagingPage.dailyDirectAlertsCheck_S),true,"a)RF daily DirectAlerts check");
			extentReport.reportScreenShot("Transmitter Setup Preference section");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.lockoutUnscheduledTransmissions_OR, clinicAdminSchedulingAndMessagingPage.lockoutUnscheduledTransmissions_S),true,"b)Lockout patients from sending unscheduled Transmissions");
			
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.lockoutUnscheduledDirectAlertCheck_OR, clinicAdminSchedulingAndMessagingPage.lockoutUnscheduledDirectAlertCheck_S),true,"c)Lockout patients from sending unscheduled DirectAlerts checks");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.isElementPresentwithoutException(clinicAdminSchedulingAndMessagingPage.collectDirectTrendViewerDiagnostics_OR, clinicAdminSchedulingAndMessagingPage.collectDirectTrendViewerDiagnostics_S),true,"d)Collect DirectTrend Viewer Diagnostics");
			
			
			extentReport.info("700-V- Verify that the following fields are displayed in the Automatically Clear section of the page",new String[] {"ClncMgt31963","Config454","ClncMgt26834","ClncMgt31037","Config455","ClncMgt26835","ClncMgt31038","Config276","ClncMgt26836","ClncMgt31039","Config2119","ClncMgt26839","ClncMgt31040"});
			extentReport.reportScreenShot("Automatically Clear section");
			
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttributeWithReport(clinicAdminSchedulingAndMessagingPage.disgnosticsInput_OR,"aria-checked",clinicAdminSchedulingAndMessagingPage.disgnosticsInput_S),"true"," a)Diagnostics with default value as ON as mentioned in requirement");
			
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttributeWithReport(clinicAdminSchedulingAndMessagingPage.episodes_OR, "aria-checked", clinicAdminSchedulingAndMessagingPage.episodes_S),"true","b)Episodes with default value as ON as mentioned in requirement");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttributeWithReport(clinicAdminSchedulingAndMessagingPage.storesEGMS_OR,"aria-checked", clinicAdminSchedulingAndMessagingPage.storesEGMS_S),"true","c)Stored EGMs with default value as ON as mentioned in requirement");
			softAssert.assertEquals(clinicAdminSchedulingAndMessagingPage.getAttributeWithReport(clinicAdminSchedulingAndMessagingPage.stDiagnostics_OR, "aria-checked",clinicAdminSchedulingAndMessagingPage.stDiagnostics_S),"false","d)ST Diagnostics with default value as OFF as mentioned in requirement");
			softAssert.assertAll();
			extentReport.info("800-S- The Actor ends the testcase");
		} catch (AssertionError e) {
			extentReport.fail( "WA_CA_200_SchedulingAndMessaging_DynamicComponents_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_CA_200_SchedulingAndMessaging_DynamicComponents_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}