package com.test.qa.ui.tests.UC021A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicHoursAndHolidays;
import com.test.qa.utilities.CommonUtils;

public class WA_CA_300_Clinic_Hours_and_Holidays_Dynamic_Components_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicHomeTopNavPage;
	ExtentTest extentTest;
	Login loginClinicA;
	Login loginClinicB;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_ClinicHoursAndHolidays clinicHoursAndHolidaysPage;
	CA_LeftNavPage clinicAdminLeftNavPage;

	@BeforeClass
	public void initialize() {

	driver = CommonUtils.initializeDriver();
	extentReport = new ExtentReport(driver, extentReport);
	loginPage = new LoginPageWithPOJO(driver, extentReport);
	loginClinicA = new Login();
	loginClinicB = new Login();
	testDataProvider = new TestDataProvider();
	clinicHoursAndHolidaysPage = new CA_ClinicHoursAndHolidays(driver, extentReport);
	clinicHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
	clinicAdminLeftNavPage = new CA_LeftNavPage(driver,extentReport);

	}
	
	@Test
	public void WA_CA300_ClinicHoursandHolidaysDynamicComponents01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		// created clinic a and clinic b
		loginClinicA = testDataProvider.getLoginData("new clinic for clinic a");
		loginClinicB = testDataProvider.getLoginData("new clinic for clinic B");
		extentTest.assignAuthor("Salin-Gambhir");

		try {
			
			String[] weekday = {"Monday", "Tuesday", "Wednesday", "Thrusday", "Friday", "Saturday", "Sunday"};
			List<String> defaultUSHolidays =Arrays.asList("New Year's Day", "Martin Luther King Day", "President's Day", "Easter", "Memorial Day", "Independence Day", "Labor Day", "Thanksgiving", "Christmas");
			List<String> defaultOUSHolidays =Arrays.asList("New Year's Day");
			Assertions assertion=new Assertions(extentTest);
			
			extentReport.reportInfo( "100 S- The Actor is logged into system and navigates to the Clinic Hours and Holidays page");		
			loginPage.login(loginClinicA);
			clinicHomeTopNavPage.clickClinicAdministrationLink();
			clinicAdminLeftNavPage.clickClinicHoursAndHolidaysLink();
			Boolean loginCheck = clinicHoursAndHolidaysPage.verifyLandingPage();
			Assert.assertTrue(loginCheck);
						
			extentReport.reportInfo("200-V- Verify that the Clinic Hours and Holidays page is displayed in View mode. <ClncMgt29607>");
			Boolean checkEditButtonStatusOnClinicHourAndHolidays = clinicHoursAndHolidaysPage.elementVisibleOnPage(clinicHoursAndHolidaysPage.editButton, "Edit Button is present so In View Mode", "Not In ViewMode");
			Assert.assertTrue(checkEditButtonStatusOnClinicHourAndHolidays);
			
			extentReport.reportInfo("300-V- Verify that the business hours with Open and Close time for every day in the week are displayed in the Clinic Hours section with values as mentioned in requirement <ClncMgt29611>, <ClncMgt30980>");
			//1. First check for all days open and close time box is shown
			//Boolean 
			
			for (int i=0; i<weekday.length; i++)
			{
				if (weekday[i].equals("Sunday") || weekday[i].equals("Saturday")) 
				{						
					Boolean checkHoursFields = clinicHoursAndHolidaysPage.verifyClinicHours(weekday[i], "", "");
					softAssert.assertTrue(checkHoursFields);
					
				}
				else 
				{
					// this need to be passed from excel data
					Boolean checkHoursFields = clinicHoursAndHolidaysPage.verifyClinicHours(weekday[i], "08:00 AM", "05:00 PM");
					softAssert.assertTrue(checkHoursFields);	
				}
				
			}
			
			extentTest = extentReport.info("400-V- Verify that the Holidays mentioned in the requirement are displayed in chronological order.", new String[] {"<ClncMgt29696>"});
			assertion.assertEqualsWithReporting(true, clinicHoursAndHolidaysPage.verifyHolidayInChronologicalOrder(defaultUSHolidays), extentReport, "US Holidays are in chronological order");
			
			
			extentReport.reportInfo("500-V- Verify that the following fields are displayed for each Clinic holiday in the Clinic Holidays section of the page: ");
			//assertion.assertEqualsWithReporting(true, clinicHoursAndHolidaysPage.verifyHoliday(clinicHoursAndHolidaysPage.getAttribute(clinicHoursAndHolidaysPage.textHolidayName,"aria-required")), extentTest, "Holiday Name exist on Page");
			Boolean validateHolidayCheck = clinicHoursAndHolidaysPage.verifyHoliday("Holiday Name", "Start Date", "End Date");
			// this will fail as start date abd end date are not available 
			// need to update code to check for all list values end time and start tine is shown nothint should be empty
			Assert.assertTrue(validateHolidayCheck);
			
			
			extentReport.reportInfo("600-V- Verify that the list of default Holidays for Clinic A is as mentioned in <ClncMgt30981>");
			// need to implement this once data is shown in application
			boolean checkDefaultHolidayforUS = clinicHoursAndHolidaysPage.verifyDefaultHolidays(defaultUSHolidays);
			softAssert.assertTrue(checkDefaultHolidayforUS);
			
			
			extentReport.reportInfo("700-V- Verify that the list of default Holidays for Clinic B is as mentioned in <ClncMgt30981>");
			loginPage.login(loginClinicB);
			clinicHomeTopNavPage.clickClinicAdministrationLink();
			clinicAdminLeftNavPage.clickClinicHoursAndHolidaysLink();
			loginCheck = clinicHoursAndHolidaysPage.verifyLandingPage();
			Assert.assertTrue(loginCheck);
			boolean checkDefaultHolidayforOUS = clinicHoursAndHolidaysPage.verifyDefaultHolidays(defaultOUSHolidays);
			softAssert.assertTrue(checkDefaultHolidayforOUS);
			
			assertion.assertAll();
			

		}
		catch (AssertionError e) {
			extentTest = extentReport.fail( "WA_CA300_ClinicHoursandHolidaysDynamicComponents01 is failed due to assertion failure");
			//extentTest.fail("WA_AD015_Change_Customer_PageValidation_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}
			
		catch (Exception e) {
			extentTest = extentReport.fail( "WA_CA300_ClinicHoursandHolidaysDynamicComponents01 is failed due to some exception");
			//extentTest.fail("UC013B_E01_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
			
		} 
		
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
	
}

