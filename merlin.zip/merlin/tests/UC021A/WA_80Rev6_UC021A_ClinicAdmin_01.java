package com.test.qa.ui.tests.UC021A;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.pojo.Customer;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicHoursAndHolidays;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.utilities.CommonUtils;

public class WA_80Rev6_UC021A_ClinicAdmin_01 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_ClinicProfilePage clinicProfilePage;
	CA_ClinicHoursAndHolidays clinicHoursAndHolidaysPage;
	CA_SchedulingAndMessagingPage clinicSchedulingAndMessagingPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_ClinicUsers clinicUsersPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage merlinAtHomePage;
	Login loginUserA;
	Login loginUserB;
	Login loginUserC;
	Login loginUserD;
	CustomerListPage customerListPage;
	
	
	@BeforeClass
	public void initialize() {
		
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		clinicHoursAndHolidaysPage = new CA_ClinicHoursAndHolidays(driver, extentReport);
		clinicSchedulingAndMessagingPage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicUsersPage = new CA_ClinicUsers(driver, extentReport);
		merlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		loginUserA = new Login();
		loginUserB = new Login();
		loginUserC = new Login();
		loginUserD = new Login();
		customerListPage = new CustomerListPage(driver, extentReport);
	}
	
	@Test
	public void TC_WA_80Rev6_UC021A_ClinicAdmin_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		
		String expectedClinicName = "";
		String expectedUserID = "";
		boolean checkUserCreated = false;
		String expectedPhoneNumber = "";
		String startTime = "8:00";
		String endTime = "5:00";
		String startTimeAmPm = "PM";
		String endTimeAmPm = "AM";

		try {
			//customer = testDataProvider.getCustomerData("WA_80Rev6_UC021A_ClinicAdmin_01_UserA");
			
			loginUserA = testDataProvider.getLoginData("userA");
			assertion =  new Assertions(extentTest);
			
			extentTest = extentReport.reportInfo("100 S Log into application with User 'A'");
			loginPage.login(loginUserA);
			assertion.assertTrue(clinicianHomePage.verifyLandingPage(), "Clinician Home Page is NOT Displayed.");
			
			extentTest = extentReport.reportInfo("200 S Navigate to EP Clinic Profile page.");
			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertion.assertTrue(clinicProfilePage.verifyLandingPage(),
					"Clinic Administration Page is NOT Displayed.");
			
			expectedClinicName = "HCL1244306Testusera,Story - III - 434";
			extentTest = extentReport.reportInfo("300 V Verify that Clinic name has comma ',' character in clinic name");
			//assertion.assertEqualsWithReporting(true, clinicProfilePage.verifyClinicName(expectedClinicName), extentReport, "Clinic Name matches correctly");			
			
			extentTest = extentReport.reportInfo("400 S Click on Clinic Hours and Holidays page");
			clinicAdminLeftNavPage.clickHoursAndHolidayLink();
			
			extentTest = extentReport.info("500 V Verify that Clinic Hours and holidays page is displayed properly.", new String[] {"ClncMgt29607"});
			assertion.assertEqualsWithReporting(true, clinicHoursAndHolidaysPage.verifyLandingPage(), extentReport,
					"Hours and Holidays Page is Displayed.");
			
			clinicianHomeTopNavPage.clickSignOutLink(); 
			
			
			loginUserB = testDataProvider.getLoginData("userB");
			extentTest = extentReport.reportInfo("600 S Login application with User B");
			loginPage.login(loginUserB);
			extentTest = extentReport.reportPass("700 S Navigate to clinic Administration-> Scheduling and Messaging page"); 
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			clinicAdminLeftNavPage.navigateToSchedMessagingPage();
			assertion.assertTrue(clinicSchedulingAndMessagingPage.verifyLandingPage(), "Scheduling and Messaging Page is NOT displayed");
			extentTest = extentReport.reportPass("800 S Click on Edit button and alter direct call messaging settings with valid values and click on Save button"); 
			clinicSchedulingAndMessagingPage.clickEditButton();
			//assertion.assertTrue(clinicSchedulingAndMessagingPage.visibilityOfElementLocatedWithReport(clinicSchedulingAndMessagingPage.saveButton, "Page in Edit Mode"));
			
			clinicSchedulingAndMessagingPage.alterMessagingDetails(startTime,startTimeAmPm, endTime, endTimeAmPm); 
			clinicSchedulingAndMessagingPage.clickSaveButton();
			
			 extentTest = extentReport.info("900 V Verify that correct message (String10139) is displayed on dialogue box.", new String[]{"ClncMgt29607"}); 
			 String msg = "This will change preferences for your entire clinic. Do you want to continue?";
			 assertion.assertEqualsWithReporting(true, clinicSchedulingAndMessagingPage.verifyAlertTextForAccepting(msg), extentReport, "Verifying Alert message");
			 clinicSchedulingAndMessagingPage.clickAlerts();
			 
			 clinicianHomeTopNavPage.clickSignOutLink(); 
			 
			 loginUserC = testDataProvider.getLoginData("userC"); 
			 extentTest = extentReport.reportInfo("1000 S Login application with User C and navigate to clinic user page."); 
			 loginPage.login(loginUserC);
			 
			 clinicianHomeTopNavPage.clickClinicAdministrationLink();
			 clinicAdminLeftNavPage.clickClinicUserLink();
			 
			 assertion.assertTrue(clinicUsersPage.verifyLandingPage());
			 
			 extentTest = extentReport.info("1100 V Verify that all the created user should get displayed on the clinic user page with the respective data/information.", new String[] {"<ClncMgt29607>"}); 
			 assertion.assertEqualsWithReporting(true, clinicUsersPage.verifyUserCreated(expectedUserID), extentReport, "Clinic User created successfully");
			 
			 clinicianHomeTopNavPage.clickSignOutLink(); 
			 
			  
			  /*
			 login = testDataProvider.getLoginData("SJMAdmin"); 
			 extentTest = extentReport.reportInfo("1110 S Login as Sjm Admin navigate to TT users or customer list.");
			 loginPage.login(login);
			 
			 extentTest = extentReport.info("1120 V Verify that all the created Clinic should get displayed on the TT users list page with the respective data/information.",new String[] {"ClncMgt29607"}); // verify that 3 created clinics are in customer list page.
			 String[] clinicNamesToBeValidated = {"HCL1244306Testusera,Story", "HCL1244306Testuserb,Story - MD - 578", "HCL1244306Testuserc,Story - Sr. - 226", ""};
			 for (String clinicName: clinicNamesToBeValidated)
			 {
				 assertion.assertEqualsWithReporting(true, customerListPage.verifyCustomerNameInListPage(clinicName), extentReport, "Verified Customer Name " + clinicName +" verfieid");
				 
			 }
			 
			 
			 clinicianHomeTopNavPage.clickSignOutLink();
			 */
			  
			 loginUserD = testDataProvider.getLoginData("userD"); 
			 extentTest = extentReport.reportPass("1130 S Login application with User D and navigate to clinic user page."); 
			 loginPage.login(loginUserD);
			 clinicianHomeTopNavPage.clickClinicAdministrationLink();
			 clinicAdminLeftNavPage.clickClinicUserLink();
			 assertion.assertEqualsWithReporting(true, clinicUsersPage.verifyLandingPage(), extentReport, "Clinic user page is displayed");
			 
			 extentTest = extentReport.info("1140 V Verify that all the created user should get displayed on the clinic user page with the respective data/information.", new String[]{"<ClncMgt29607>"}); 
			 expectedUserID = "userd";
			 assertion.assertTrue(clinicUsersPage.verifyUserCreated(expectedUserID));
			 
			 extentTest = extentReport.reportInfo("1150 S Delete a user from the list displayed on clinic user page "); 
			 assertion.assertEqualsWithReporting(true, clinicUsersPage.deleteUser(expectedUserID), extentTest, "Delete User successful");
			 
			  // 1160 need to be confirmed
			 clinicianHomeTopNavPage.clickSignOutLink();	
			 		 
			 
			 loginUserD = testDataProvider.getLoginData("userD"); 
			 extentTest = extentReport.reportInfo("1200 S Login in to application and navigate to DirectAlerts� settings page under clinic admin tab. "); 
			 loginPage.login(loginUserD);
			 clinicianHomeTopNavPage.clickClinicAdministrationLink(); 
			 clinicAdminLeftNavPage.clickMerlinHomeTransmitterLink();
			 assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyLandingPage(), extentReport, "Merlin at Home page present");
			 merlinAtHomePage.openEditAdditonalNotificationSectioon();
			 
			 extentTest = extentReport.reportInfo("1300 S Change the value of 'On-call Physician Contact' to fax and save it");
			 merlinAtHomePage.changeOncallPhysicianContact("Fax", "1-234-3322332");
			 
			 
			 extentTest = extentReport.reportPass("1400 S Logout and login again now navigate to clinic profile page. ");
			 clinicianHomeTopNavPage.clickSignOutLink();
			 loginUserD = testDataProvider.getLoginData("userD"); 
			 loginPage.login(loginUserD);
			 
			 extentTest = extentReport.info("1500 V Verify the labels for fax field are displayed.",new String[] {"<ClncMgt29607>"});
			 clinicianHomeTopNavPage.clickClinicAdministrationLink(); 
			 clinicAdminLeftNavPage.clickMerlinHomeTransmitterLink();
			 assertion.assertTrue(merlinAtHomePage.verifyLandingPage());
			 assertion.assertEqualsWithReporting(true, merlinAtHomePage.verifyOnCallPhysicianContact("Fax", "1-234-3322332"), extentReport, "Verified FAX details");

			 
			assertion.assertAll();
			

		} catch (AssertionError e) {
			
			extentTest = extentReport.fail( "WA_80Rev6_UC021A_ClinicAdmin_01 is failed due to assertion failure");
			
			e.printStackTrace();
			throw e;
			
		} catch (Exception e) {
			
			extentTest = extentReport.fail( "WA_80Rev6_UC021A_ClinicAdmin_01 is failed due to assertion failure");
			e.printStackTrace();
			throw e;
			
		}
	}

	private void extentReport(String string) {
		// TODO Auto-generated method stub
		
	}

}
