package com.test.qa.ui.tests.UC021A;


import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.pojo.Customer;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ClinicalCommentsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_CA400_500_DirectAlerts_DynamicComponents_01 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	CA_LeftNavPage clinicAdminLeftNavPage;
	private String testName;
	String clinicalTrailSectionTitle;
	//CA_DirectAlert_ICD_CRTD_MerlinAtHomePage
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage merlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;
	CA_ClinicSettings_ClinicalCommentsPage clinicSettings_ClinicalCommentsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage leftNavPage;
	
	@BeforeClass
	public void initialize() {
		
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicAdminLeftNavPage=new CA_LeftNavPage(driver, extentReport);
		merlinAtHomePage=new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page (driver, extentReport);;
		clinicSettings_ClinicalCommentsPage = new CA_ClinicSettings_ClinicalCommentsPage(driver, extentReport);
		leftNavPage = new CA_LeftNavPage(driver, extentReport);

		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
	}
	
	@Test
	public void wa_CA400_500_DirectAlerts_DynamicComponents_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("Allied_Acct");
		//customer = testDataProvider.getCustomerData("WA_CA400_500_DirectAlerts_DynamicComponents_01");
		extentTest.assignAuthor("Author-Mohan Sekar");//comments
		try {
			Assertions assertion =  new Assertions(extentTest);
			
			extentReport.info("100-S- The Actor is logged into system and navigates to the DirectAlerts Settings page for ICD/CRT-D with Merlin@Home Transmitter.");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			clinicianHomeTopNavPage.clickMelinathomeLink();
			extentReport.info("200-V- Verify that the DirectAlerts settings page shall be displayed.",new String[] {"ClncMgt30312"} );
			assertion.assertEquals(true, clinicAdminLeftNavPage.verifyDirectAlertTab(), "Direct Alerts Settings is present");
			extentReport.info("400-V Verify that the contact method and contact information during clinic hours and after are displayed for each of the following section</br> a) Urgent Alerts </br>b) Standard Alerts",new String[] {"ClncMgt30316","ClncMgt6636","ClncMgt6637"} );
			assertion.assertEquals(true, merlinAtHomePage.verifyRedAlert(), "Red Alert is present");
			assertion.assertEquals(true, merlinAtHomePage.verifyYellowAlert(), "Yellow Alert Settings is present");
			
			extentReport.info("500-V- Verify that the default values for Urgent Alerts during office hours is ‘None’.",new String[] {"Config286","ClncMgt30990"} );
			assertion.assertEquals("None",merlinAtHomePage.UrgentAlertsduringofficehours() , "Urgent Alerts during officehours");
			extentReport.info("600-V- Verify that the default values for Urgent Alerts after office hours is ‘None’.",new String[] {"Config14576","ClncMgt30990"} );
			assertion.assertEquals("None",merlinAtHomePage.UrgentAlertsAfterofficehours() , "Urgent Alerts After office hours");
			
			extentReport.info("700-V-Verify that the default values for Standard Alerts during office hours is ‘Phone’.",new String[] {"Config14577","ClncMgt30990"} );
			assertion.assertEquals("Phone",merlinAtHomePage.yellowalertduringofficehours() , "yellow alert during office hours");
			extentReport.info("800-V-Verify that the default values for Standard Alerts after office hours is ‘Email’.",new String[] {"Config14578","ClncMgt30990"} );
			assertion.assertEquals("Email",merlinAtHomePage.yellowalertafterofficehours() , "yellow alert after office hours");
			extentReport.info("900-V- Verify that the following fields are available:</br>a) Medical team notification setting after hours</br> b) On Call Physician contact information",new String[] {"ClncMgt30316","ClncMgt6636"} );
			assertion.assertEquals(true,merlinAtHomePage.medicalteamnotificationsettingafterhours() , "medical team notification setting after hours");
			assertion.assertEquals(true,merlinAtHomePage.OnCallPhysiciancontactinformation() , "OnCall Physician contact information");
			extentReport.info("1000-V- Verify that the following preferences is displayed for each Alert in the list:</br> a) Alert Priority (Urgent, Standard and None) with values equal to the values in </br>  b) Threshold and Duration values (for supported alert groups)</br>c) Notify Patient",new String[] {"ClncMgt6637", "ClncMgt6638","Config289", "Config21468", "Config14686"} );
			assertion.assertEquals(true,merlinAtHomePage.verifyAlertTypelist() , "Preferences is displayed for each Alert List");
			extentReport.info("1100-V- Verify that the list of Alerts matches with the list in:",new String[] {"Alerts1875", "ClncMgt6639"} );
			merlinAtHomePage.validateMerlinHomeAlertValueInTable();
			extentReport.info("1200-S- The Actor clicks on the Edit button." );
			merlinAtHomePage.clickEditButton();
			extentReport.info("1300-S- The Actor sets the priority of any of the Urgent or Standard Alerts to None/Off." );
			merlinAtHomePage.changeAlertClassification("Tachy Therapy Disabled","OFF");
			extentReport.info("1400-V- Verify that if the Alert priority is None, the preference to notify the patient remains inactive.",new String[] {"ClncMgt6640", "ClncMgt6639"}  );
			assertion.assertEquals(false,merlinAtHomePage.checkboxvalue() , "Check Box Value ");
			extentReport.info("1500-S- The Actor reverts the priority of the Alert that is changed and click on Save");
			merlinAtHomePage.changeAlertClassification("Tachy Therapy Disabled","Yellow");
			merlinAtHomePage.clickSave();
			merlinAtHomePage.acceptSavePopup();
			
			extentReport.info("1600-S- The Actor navigates to DirectAlerts Settings page for Pacemaker/CRT-P .");
			pacemaker.pacemakerCRTP_linkclick();
			merlinAtHomePage.acceptSavePopup();
			extentReport.info("200-V- Verify that the DirectAlerts settings page shall be displayed.",new String[] {"ClncMgt30312"} );
			assertion.assertEquals(true, pacemaker.verifyDirectAlertTab(), "Direct Alerts Settings is present");
			extentReport.info("400-V Verify that the contact method and contact information during clinic hours and after are displayed for each of the following section</br> a) Urgent Alerts </br>b) Standard Alerts",new String[] {"ClncMgt30316","ClncMgt6636","ClncMgt6637"} );
			assertion.assertEquals(true, pacemaker.verifyRedAlert(), "Red Alert is present");
			assertion.assertEquals(true, pacemaker.verifyYellowAlert(), "Yellow Alert Settings is present");
		
			extentReport.info("500-V- Verify that the default values for Urgent Alerts during office hours is ‘None’.",new String[] {"Config286","ClncMgt30990"} );
			assertion.assertEquals("None",pacemaker.UrgentAlertsduringofficehours() , "Urgent Alerts during officehours");
			extentReport.info("600-V- Verify that the default values for Urgent Alerts after office hours is ‘None’.",new String[] {"Config14576","ClncMgt30990"} );
			assertion.assertEquals("None",pacemaker.UrgentAlertsAfterofficehours() , "Urgent Alerts After office hours");
			
			extentReport.info("700-V-Verify that the default values for Standard Alerts during office hours is ‘Phone’.",new String[] {"Config14577","ClncMgt30990"} );
			assertion.assertEquals("Phone",pacemaker.yellowalertduringofficehours() , "yellow alert during office hours");
			extentReport.info("800-V-Verify that the default values for Standard Alerts after office hours is ‘Email’.",new String[] {"Config14578","ClncMgt30990"} );
			assertion.assertEquals("Email",pacemaker.yellowalertafterofficehours() , "yellow alert after office hours");
			extentReport.info("900-V- Verify that the following fields are available:</br>a) Medical team notification setting after hours</br> b) On Call Physician contact information",new String[] {"ClncMgt30316","ClncMgt6636"} );
			assertion.assertEquals(true,pacemaker.medicalteamnotificationsettingafterhours() , "medical team notification setting after hours");
			assertion.assertEquals(true,pacemaker.OnCallPhysiciancontactinformation() , "OnCall Physician contact information");
			extentReport.info("1000-V- Verify that the following preferences is displayed for each Alert in the list:</br> a) Alert Priority (Urgent, Standard and None) with values equal to the values in </br>  b) Threshold and Duration values (for supported alert groups)</br>c) Notify Patient",new String[] {"ClncMgt6637", "ClncMgt6638","Config289", "Config21468", "Config14686"} );
			assertion.assertEquals(true,merlinAtHomePage.verifyAlertTypelist() , "Preferences is displayed for each Alert List");
			extentReport.info("1100-V- Verify that the list of Alerts matches with the list in:",new String[] {"Alerts1875", "ClncMgt6639"} );
			pacemaker.validatepacemakerAlertValueInTable();
			extentReport.info("1200-S- The Actor clicks on the Edit button." );
			pacemaker.clickEditButton();
			extentReport.info("1300-S- The Actor sets the priority of any of the Urgent or Standard Alerts to None/Off." );
			pacemaker.changeAlertClassification("Device Programmed to Emergency Pacing Values","OFF");
			extentReport.info("1400-V- Verify that if the Alert priority is None, the preference to notify the patient remains inactive.",new String[] {"ClncMgt6640", "ClncMgt6639"}  );
			assertion.assertEquals(false,pacemaker.checkboxvalue() , "Check Box Value ");
			extentReport.info("1500-S- The Actor reverts the priority of the Alert that is changed and click on Save");
			pacemaker.changeAlertClassification("Device Programmed to Emergency Pacing Values","Yellow");
			merlinAtHomePage.clickSave();
			merlinAtHomePage.acceptSavePopup();
			
			extentReport.info("1700S- The Actor ends the testcase");
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_CA400_500_DirectAlerts_DynamicComponents_01 validation is failed due to Assertion Failure",CommonUtils.convertStackTraceToString(e));
			
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "WA_CA400_500_DirectAlerts_DynamicComponents_01 validation is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			
			e.printStackTrace();
			throw e;
		}
		}
		
		@AfterMethod
		public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
			saintResult(result,extentTest);
		}

	}
