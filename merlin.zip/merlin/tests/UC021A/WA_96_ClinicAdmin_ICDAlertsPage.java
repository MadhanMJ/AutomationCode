package com.test.qa.ui.tests.UC021A;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Vinay Babu, Shafiya Sunkesala
 * Date: 15/02/2022
 * Test Case: WA_96_ClinicAdmin_ICDAlertsPage
 * Report: Good
 */

public class WA_96_ClinicAdmin_ICDAlertsPage extends CommonUtils {
	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_ICT_CRTD_MerlinAtHomePage;

	LoginPageWithPOJO loginPage;
	Login login_without_BatteryPerform_Alert;
	Login login_with_BatteryPerform_Alert;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {

		clinicianHomePage = new ClinicianHomePage(driver, extentReport);

		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);

		directAlert_ICT_CRTD_MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login_without_BatteryPerform_Alert = new Login();
		login_with_BatteryPerform_Alert = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void TC_WA_96_ClinicAdmin_ICDAlertsPage()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		login_without_BatteryPerform_Alert = testDataProvider.getLoginData("SJMClinic_without_BatteryPerform_Alert");
		login_with_BatteryPerform_Alert = testDataProvider.getLoginData("SJMClinic_with_BatteryPerform_Alert");
		
		extentTest.assignAuthor("Author: Vinay Babu");
		try {
			assertions = new Assertions(extentTest);
			
//			extentReport.info(
//					"100 S Login with an EP clinic not having battery performance alert added. Navigate to clinic admin->ICD Direct Alert settings tab.");
//			loginPage.login(login_without_BatteryPerform_Alert, "externaluser");
//			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
//			clinicianHomeTopNavPage.clickClinicAdministrationLink();
//			assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
//			extentReport.reportScreenShot("Navigation to Clinic Administration Page is successful");
//			
//			clinicAdminLeftNavPage.clickDirectAlertsICD_CRTD_MerlinHomeLink();
//			assertions.assertEqualsWithReporting(true, directAlert_ICT_CRTD_MerlinAtHomePage.verifyLandingPage(), extentReport, "Merlin Home Transmitter page is displayed T");
//			extentReport.reportScreenShot("Navigation to Clinic Admin -> ICD/CRTD -> Merlin@Home Transmitter Page is successful");
//			
//			extentReport.info(
//					"200 V Verify that Additional Alert Notification Section is not displayed on the page <negative test>", new String[] {"ClncMgt32109"});
//			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyAdditionAlertNotifSectionDisplayed(), false, "Additional Alert Notification section is not displayed");
//			extentReport.reportScreenShot("Additional Alert Notification section is not displayed");
//			clinicianHomeTopNavPage.clickSignOutLink();
			
			extentReport.info(
					"300 S Login with an EP clinic having battery performance alerts Navigate to clinic admin->ICD Direct Alert settings tab.");
			loginPage.login(login_with_BatteryPerform_Alert, "externaluser");
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");			
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
			extentReport.reportScreenShot("Navigation to Clinic Administration Page is successful");
			
			clinicAdminLeftNavPage.clickDirectAlertsICD_CRTD_MerlinHomeLink();
			assertions.assertEqualsWithReporting(true, directAlert_ICT_CRTD_MerlinAtHomePage.verifyLandingPage(), extentReport, "Merlin Home Transmitter page is displayed T");
			extentReport.reportScreenShot("Navigation to Clinic Admin -> ICD/CRTD -> Merlin@Home Transmitter Page is successful");
			

			extentReport.info("400 V Verify that Additional Alert Notifications section is displayed on the page.",
					new String[] { "ClncMgt32109" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyAdditionAlertNotifSectionDisplayed(), true, "Additional Alert Notification section is displayed");

			extentReport.info("500 S Click on edit button and open the additional alert notifications section.");
			directAlert_ICT_CRTD_MerlinAtHomePage.clickEditButton();
//			directAlert_ICT_CRTD_MerlinAtHomePage.openEditAdditonalNotificationSection();

			extentReport.info("600 V verify an ADD link is displayed by default under the section",
					new String[] { "ClncMgt32109" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isAddLinkAvailable(), true, "ADD link is displayed by default under the section 'Additional Alert Notification'");
			
			extentReport.info(
					"700 V Verify that user have following methods to send extended alert notifications: -Fax -Email -Text message",
					new String[] { "ClncMgt32109" });
			String options = directAlert_ICT_CRTD_MerlinAtHomePage.verifyNotificationMethods_in_sendNotifications_drpdwn();
			assertions.assertEquals(options.contains("Email"), true, "Send Notifications to dropdown contains 'Email' option");
			assertions.assertEquals(options.contains("Fax"), true, "Send Notifications to dropdown contains 'Fax' option");
			assertions.assertEquals(options.contains("Text Message"), true, "Send Notifications to dropdown contains 'Text Message' option");
			extentReport.reportScreenShot("Send extended alert notifications: -Fax -Email -Text message options are displayed");
			directAlert_ICT_CRTD_MerlinAtHomePage.sendspecialKeysOnPage("escape");
			
			extentReport.info(
					"800 V Verify that user views the following values in \"Send additional alerts to\" dropdown list: Blank/Fax/Email/Text message and by default blank is selected",
					new String[] { "ClncMgt32109" });
			String dropdownOptions = directAlert_ICT_CRTD_MerlinAtHomePage.verifyNotificationMethods_in_sendNotifications_drpdwn();
			assertions.assertEquals(dropdownOptions.contains("Email"), true, "Send Notifications to dropdown contains 'Email' option");
			assertions.assertEquals(dropdownOptions.contains("Fax"), true, "Send Notifications to dropdown contains 'Fax' option");
			assertions.assertEquals(dropdownOptions.contains("Text Message"), true, "Send Notifications to dropdown contains 'Text Message' option");
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifySendNotificationAlert_defaultBlank(), true, "Default Blank is selected in 'Send Notification To' dropdown");
			extentReport.reportScreenShot("Send additional alerts to drop down list has: Blank/Fax/Email/Text message values and by default blank is selected");			
			directAlert_ICT_CRTD_MerlinAtHomePage.sendspecialKeysOnPage("escape");	

			extentReport.info(
					"900 V Verify if user selects anyone of fax/Email/Text message from the dropdown list, a corresponding text box is displayed with the ADD link",
					new String[] { "ClncMgt32135" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTexboxdisplayed_ForOptions_inSendNotificatonAlertList("Email"), true, "Email Input Box Available");
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isAddLinkAvailable(), true, "Add Link Available For Email");
			extentReport.reportScreenShot("Send Notification->Email is selected, corresponding text box and Add link is displayed");
			
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTexboxdisplayed_ForOptions_inSendNotificatonAlertList("Fax"), true, "Country Code Input Box Available - Area Code Input Box Available - Phone Input Box Available for Fax");
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isAddLinkAvailable(), true, "Add Link Available For Fax");
			extentReport.reportScreenShot("Send Notification->Fax is selected, corresponding Country Code, Area Code, Fax text boxes and Add link is displayed");
			
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTexboxdisplayed_ForOptions_inSendNotificatonAlertList("TextMessage"), true, "Text Message Input Box Available");
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isAddLinkAvailable(), true, "Add Link Available For Text Message");
			extentReport.reportScreenShot("Send Notification->Email is selected, corresponding text box and Add link is displayed");
//			Assert.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyEmailSelectionInSendNotificationAlertList(),
//					"Email Input Box Available - Add Link Available");
//
//			Assert.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyTextSelectionInSendNotificationAlertList(),
//					"Text Message Input Box Available - Add Link Available");
//
//			Assert.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyFaxSelectionInSendNotificationAlertList(),
//					"Country Code Input Box Available - Area Code Input Box Available - Phone Input Box Available - Add Link Available");

			///////////////////////////////////////////////////
			extentReport.info(
					"1000 V Verify user is able to see 3 textboxes for fax no. and one text box for email and one for text message",
					new String[] { "ClncMgt32109" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTexboxdisplayed_ForOptions_inSendNotificatonAlertList("TextMessage"), true, "One Text Box is displayed for Text Message");
			extentReport.reportScreenShot("1 text box is displayed for Text Message");
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTexboxdisplayed_ForOptions_inSendNotificatonAlertList("Email"), true, "One Text Box is displayed for Email");
			extentReport.reportScreenShot("1 text box is displayed for Email");
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTexboxdisplayed_ForOptions_inSendNotificatonAlertList("Fax"), true, "Country Code Input Box Available - Area Code Input Box Available - Phone Input Box Available for Fax");
			extentReport.reportScreenShot("3 text boxes are displayed for Fax Number");
//			Assert.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyFaxSelectionInSendNotificationAlertList(),
//					"Country Code Input Box Available - Area Code Input Box Available - Phone Input Box Available - Add Link Available");

			///////////////////////////////////////////////////

			extentReport.info(
					"1100 V Verify that by filling the textbox and clicking on ADD link ,alert notification gets added and a REMOVE link gets displayed corresponding to that alert notification.",
					new String[] { "ClncMgt32109" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isTextMessageAdded_SendNotification(), true, "On click of Add link, alert notificatio gets added and a Remove link is displayed");
			extentReport.reportScreenShot("By filling the textbox and clicking on ADD link ,alert notification gets added and a REMOVE link gets displayed corresponding to that alert notification");
//			Assert.assertEquals(
//					directAlert_ICT_CRTD_MerlinAtHomePage.selectTextSelectionInSendNotificationAlertList_andAdd(),
//					"Add Notification Successful");

			///////////////////////////////////////////////////

			extentReport.info(
					"1200 V Verify that by clicking on REMOVE link, alert notification gets removed from the additional alerts sections.",
					new String[] { "ClncMgt32109" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.isAlertNotif_Removed(), true, "Alert Notification is removed");
			extentReport.reportScreenShot("On click of Remove link, alert notification is removed from the additional alerts sections.");
//			Assert.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.removeTextAlert(),
//					"Remove Notification Successful");

			///////////////////////////////////////////////////

			extentReport.info("1300 V Verify that user is not able to add more than 10 alert notifications.",
					new String[] { "ClncMgt32109" });
			assertions.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyCanAddOnly10NotificationAlertS(), true, "User is not able to add more than 10 alert Notifications");
//			Assert.assertEquals(directAlert_ICT_CRTD_MerlinAtHomePage.verifyCanAddOnly10NotificationAlertS(),
//					"Only 10 Notification Alerts can be added");
			 assertions.assertAll();

		} catch (AssertionError e) {
			extentReport.reportFail( "WA_96_ClinicAdmin_ICDAlertsPage is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "WA_96_ClinicAdmin_ICDAlertsPage is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}
}
