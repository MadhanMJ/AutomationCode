package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.hamcrest.text.pattern.Parse;
import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;


public class WA_IB001_RecentTransmission_01 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	CA_RecentTransmissionsPage recentTrnsPg;
	AppHomeTopNavPage appHomeTopNavPage;
	
	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_ClinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		recentTrnsPg= new CA_RecentTransmissionsPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		commonUtils=new CommonUtils();
		
	}
	
	
	// Testcase id: 1238698, Testcase name: WA_IB001_RecentTransmission_01, Author- Bhupendra
	
	@Test	
	public void WA_IB001_RecentTransmission_01_TC() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		//login = testDataProvider.getLoginData("PH_CLINIC_D");
		extentTest.assignAuthor("Author: Bhupendra");
		try {
			
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100 S Login with Direct Clinic A and navigate to Recent Transmissions Page.");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"), extentReport, "Recent Transmission Tab is displayed");			
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
				
			
			extentReport.info("200 S Select tier 1 filter as Clinic Patients and tier 2 filter as All");
			assertion.assertEqualsWithReporting(true, recentTrnsPg.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("all");
			extentReport.reportScreenShot("Selected tier 1 filter as Clinic Patients and tier 2 filter as All");
			
			
			
			extentReport.info("300 V Verify that all unarchived transmissions in clinic are displayed in Transmission list.",new String[] {"TransMgt16990","TransMgt8929"});
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_1 is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_B"), extentReport, "Patient_Name_1 is present in the list");
			extentReport.reportScreenShot("Verified that all unarchived transmissions in clinic are displayed in Transmission list.");
			
			
			extentReport.info("400 S Select tier 2 filter Unviewed Transmissions");
			recentTrnsPg.selectTireOTwoFilterOption("unviewed transmissions");
			extentReport.reportScreenShot("Selected tier 2 filter Unviewed Transmissions");
			
			
			extentReport.info("500 V Verify that all Unviewed transmissions are displayed in Transmission list.",new String[] {"TransMgt16990","TransMgt16759"});
			assertion.assertEqualsWithReporting(true, (recentTrnsPg.viewedTrnsmissionDipInTable()==0), extentReport, "all Unviewed transmissions are displayed in Transmission list.");
			int count=recentTrnsPg.unviewedTrnsmissionDipInTable();
			int unviewedTrnsDisplInTbl=recentTrnsPg.unviewedTrnsmissionDipInTable();
			extentReport.reportScreenShot("all Unviewed transmissions are displayed in Transmission list.");
			
			
			
			extentReport.info("600 V Verify Quick link count of Unviewed transmissions is displayed correctly",new String[] {"Gen2065"});
			int unviewedCountQuikLnk= Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount());
			assertion.assertEqualsWithReporting(true, (unviewedTrnsDisplInTbl==unviewedCountQuikLnk), extentReport, "Verified Quick link count of Unviewed transmissions is displayed correctly");
			
			
			extentReport.info("700 S Select tier 1 filter as Clinic Patients and tier 2 filter as Location. Select any one location from the location dropdown");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("patient’s clinic location");
			extentReport.reportScreenShot("Selected tier 1 filter as Clinic Patients and tier 2 filter as Location. Select any one location from the location dropdown");
			
			
			extentReport.info("800 V Verify that transmissions for patient from selected location are displayed in Transmission list",new String[] {"TransMgt8935","TransMgt16990"});
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_WithRespLocation"), extentReport, "Patient_Name_1 is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_WithRespLocation"), extentReport, "Patient_Name_1 is present in the list");
			extentReport.reportScreenShot("Verified transmissions for patient from selected location are displayed in Transmission list");
			
			
			extentReport.info("900 S Select tier 1 filter as Clinic Patients and tier 2 filter as Cardiac Monitor");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("cardiac monitor");
			extentReport.reportScreenShot("Select tier 1 filter as Clinic Patients and tier 2 filter as Cardiac Monitor");
			
			
			extentReport.info("1000 V Verify that transmissions of patients having only Cardiac Monitor devices are displayed.",new String[] {"TransMgt16990","TransMgt17587"});
			//write a xpath which willpoint to only transmission having cardiac monitor devices
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_WithCardiacMonitor"), extentReport, "Patient_Name_1 is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_WithCardiacMonitor"), extentReport, "Patient_Name_1 is present in the list");
			extentReport.reportScreenShot("Verified transmissions of patients having only Cardiac Monitor devices are displayed.");
			
			
			extentReport.info("1100 S Select tier 1 filter as Clinic Patients and tier 2 filter as ICD/Pacemaker");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("icd/pacemaker");
			extentReport.reportScreenShot("Selected tier 1 filter as Clinic Patients and tier 2 filter as ICD/Pacemaker");
			
			
			
			extentReport.info("1200 V Verify that transmissions of patients having only ICD/Pacemaker devices are displayed.",new String[] {"TransMgt17588","TransMgt16990"});
			//very complex logic as need to check all icd/pacemaker devices capture on ui and then check all transmission in table and validate
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_WithICD_PacemakerDevices"), extentReport, "Patient_Name_1 is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_WithICD_PacemakerDevices"), extentReport, "Patient_Name_1 is present in the list");
			extentReport.reportScreenShot("Verified transmissions of patients having only ICD/Pacemaker devices are displayed.");
			
			
			
			extentReport.info("1300 S Select tier 1 filter as My Patients and tier 2 filter as All");
			recentTrnsPg.selectTireOneFilterOption("my patients");
			recentTrnsPg.selectTireOTwoFilterOption("all");
			extentReport.reportScreenShot("Selected tier 1 filter as My Patients and tier 2 filter as All");
			
			
			extentReport.info("1400 V Verify that all transmissions of patients, where logged in user is in Medical team are displayed in Transmission list.",new String[] {"TransMgt8930","TransMgt8929"});
			//pass patient name who where in the medical team of the physician
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_1"), extentReport, "Patient_Name_1 is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_2"), extentReport, "Patient_Name_2 is present in the list");
			
			
			extentReport.info("1500 S Select tier 2 filter Unviewed Transmissions");
			recentTrnsPg.selectTireOTwoFilterOption("unviewed transmissions");
			extentReport.reportScreenShot("Selected tier 2 filter Unviewed Transmissions");
			
			
			
			extentReport.info("1600 V Verify that all Unviewed transmissions of patients, where logged in user is in Medical team are displayed in Transmission list.",new String[] {"TransMgt16759","TransMgt8930"});
			//pass patient name of Unviewed transmissions of patients, where logged in user is in Medical team
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyUnViewedPatientInTable("Patient_Name_1","1"), extentReport, "Patient_Name_1 is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyUnViewedPatientInTable("Patient_Name_2","1"), extentReport, "Patient_Name_2 is present in the list");
			extentReport.reportScreenShot("Verified that all Unviewed transmissions of patients, where logged in user is in Medical team are displayed in Transmission list.");
			
			
			extentReport.info("1700 V Verify Quick link count of Unviewed transmissions is displayed correctly.",new String[] {"Gen2065"});
			//write the function to capture the displayed unviewd transmission and validate with quick link
			unviewedTrnsDisplInTbl=1;//pass the number of viewed transmission peresent for physiscian
			unviewedCountQuikLnk= Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount());
			assertion.assertEqualsWithReporting(true, (unviewedTrnsDisplInTbl==unviewedCountQuikLnk), extentReport, "Verified Quick link count of Unviewed transmissions is displayed correctly");
			
			
			extentReport.info("1800 S Select tier 1 filter as Clinic Patients and tier 2 filter as All. Search for transmissions of Patient A");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("all");
			extentReport.reportScreenShot("Selected tier 1 filter as Clinic Patients and tier 2 filter as All.");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");//viewed
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");//unviewed
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");
			extentReport.reportScreenShot("transmissions of Patient A is validated successfully.");
			
						
			
			extentReport.info("1900 S Select patient selection checkbox next to two viewed and two unviewed transmissions");
			//write the function to slect check box of transmission of particular patient
			recentTrnsPg.slctPatientChkBx("Patient_A","index of the patient check box");
			recentTrnsPg.slctPatientChkBx("Patient_A","index of the patient check box");
			recentTrnsPg.slctPatientChkBx("Patient_A","index of the patient check box");
			recentTrnsPg.slctPatientChkBx("Patient_A","index of the patient check box");
			
			
			extentReport.info("2000 S Click on Archive Button");
			extentReport.reportScreenShot("Archive Button is successfully validated");
			recentTrnsPg.validateArchiveBtn();
			extentReport.reportScreenShot("Archive button is successfully clicked.");
			
			
			
			extentReport.info("2100 V Verify confirmation dialog is showing message that viewed and unviewed transmissions are selected are archiving.",new String[] {"TransMgt16652"});
			String archiveMsgExpt="1 of the 2 transmissions has not been viewed. Would you like to archive all selected transmissions or only the viewed transmissions?";
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyArchivePopupMsg().equalsIgnoreCase(archiveMsgExpt), extentReport, "Validated confirmation dialog is showing message that viewed and unviewed transmissions are selected are archiving.");
			extentReport.reportScreenShot("Validated confirmation dialog is showing message that viewed and unviewed transmissions are selected are archiving.");
			
			
			
			extentReport.info("2200 V Verify that on confirmation dialog, there is option to archive only viewed or all selected transmissions.",new String[] {"TransMgt16652"});
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyArchiveSlctdTrnsBtn(), extentReport, "Validated on confirmation dialog, there is option to archive only viewed or all selected transmissions.");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyArchiveViwdTrnsBtn(), extentReport, "Validated on confirmation dialog, there is option to archive only viewed or all selected transmissions.");
			extentReport.reportScreenShot("Validated on confirmation dialog, there is option to archive only viewed or all selected transmissions.");
			
			
			
			extentReport.info("2300 S Select to archive only viewed transmissions and complete archive action.");
			recentTrnsPg.valArchiveViwdTrnsBtn();
			extentReport.reportScreenShot("Selected to archive only viewed transmissions and completed archive action.");
			
			
			extentReport.info("2400 V Verify that only viewed transmissions selected are archived. Archived transmissions are not displayed in Transmission list. Unviewed transmissions continue to display in Transmission list.",new String[] {"TransMgt16652","TransMgt17430"});
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyUnViewedPatientInTable("Patient NAme","index of the transmission"), extentReport, "Validated Unviewed transmissions continue to display in Transmission list.");//first viewed transmission
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyUnViewedPatientInTable("Patient NAme","index of the transmission"), extentReport, "Validated Unviewed transmissions continue to display in Transmission list.");//second viewed transmission
			assertions.assertEqualsWithReporting(false, recentTrnsPg.verifyViewedPatientInTable("Patient NAme","index of the transmission"), extentReport, "Validated viewed transmissions selected are archived");
			assertions.assertEqualsWithReporting(false, recentTrnsPg.verifyViewedPatientInTable("Patient NAme","index of the transmission"), extentReport, "Validated viewed transmissions selected are archived");
			extentReport.reportScreenShot("Verified that only viewed transmissions selected are archived. Archived transmissions are not displayed in Transmission list. Unviewed transmissions continue to display in Transmission list.");
			
			
			
			extentReport.info("2500 S Note Unviewed transmission count in Quick links");
			unviewedCountQuikLnk= Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount());
			
			
			extentReport.info("2800 S Click on Transmission link of one unviewed transmission.");
			//capture the date and time of the transmission
			String dtTimeOftrnsmission =recentTrnsPg.dtTimeValueUnviewedTrns("Patient_Nme", "index");
			recentTrnsPg.validateUnviewedTransLinkWithPatientName("Patient_Nme", "index");
			extentReport.reportScreenShot("Clicked on Transmission link of one unviewed transmission.");
			
			
			
			extentReport.info("2900 V Verify that Transmission Details page is displayed showing reports in selected transmission.",new String[] {"TransMgt9112"});
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyTransmissionReportPage(), extentReport, "Verified that Transmission Details page is displayed showing reports in selected transmission.");
			extentReport.reportScreenShot("Verified that Transmission Details page is displayed showing reports in selected transmission.");
			
			
			
			extentReport.info("3000 S Navigate to Recent Transmission page");
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
			
			
			
			
			extentReport.info("3100 V Verify that transmission selected to view reports is marked as Viewed.",new String[] {"TransMgt16765"});
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyViewedTrnsWithPatientNameNTrnsDtTime("Patient_Nme", dtTimeOftrnsmission), extentReport, "Verified that transmission selected to view reports is marked as Viewed");
			extentReport.reportScreenShot("Verified that transmission selected to view reports is marked as Viewed");
			
			
			
			
			extentReport.info("3200 V Verify that Unviewed transmission count in Quick links is reduced by one",new String[] {"Gen2065"});
			assertions.assertEqualsWithReporting(true,unviewedCountQuikLnk > Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount()), extentReport, "Verified that Unviewed transmission count in Quick links is reduced by one");
			extentReport.reportScreenShot("Verified that Unviewed transmission count in Quick links is reduced by one");
			
			
			
			extentReport.info("3300 S Select patient selection checkbox next to recently viewed transmission");
			dtTimeOftrnsmission = recentTrnsPg.dtTimeValueViewedTrns("Patient_Nme", "index");
			recentTrnsPg.slctVwdPatientChkBx("Patient_Name","1");
			extentReport.reportScreenShot("Selected patient selection checkbox next to recently viewed transmission");
			
			
			
			extentReport.info("3400 S Select More Action button and select option to Mark as Unviewed");
			recentTrnsPg.validateMoreActionBtn();
			recentTrnsPg.validateMrkAsUnvwdOption();
			extentReport.reportScreenShot("More Action button and select option to Mark as Unviewed");


			
			extentReport.info("3500 V Verify that selected transmission is marked as Unviewed.",new String[] {"TransMgt17431"});
			assertions.assertEqualsWithReporting(true,unviewedCountQuikLnk == Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount()), extentReport, "Verified that selected transmission is marked as Unviewed.");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyUnViewedTrnsWithPatientNameNTrnsDtTime("Patient_Nme", dtTimeOftrnsmission), extentReport, "Verified that transmission selected to view reports is marked as Viewed");
			extentReport.reportScreenShot("Verified that selected transmission is marked as Unviewed.");
			
			
			
			
			
			
			extentReport.reportScreenShot("Verified that selected transmission is marked as Unviewed.");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyUnViewedTrnsWithPatientNameNTrnsDtTime("Patient_Nme", dtTimeOftrnsmission), extentReport, "Verified that selected transmission is marked as Unviewed.");
			extentReport.reportScreenShot("Verified that selected transmission is marked as Unviewed.");
			
			
			
			
			extentReport.info("3600 V Verify that Unviewed transmission count in Quick links is increased by one",new String[] {"Gen2065"});
			assertions.assertEqualsWithReporting(true,unviewedCountQuikLnk == Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount()), extentReport, "Verified that Unviewed transmission count in Quick links is reduced by one");
			extentReport.reportScreenShot("Verified that Unviewed transmission count in Quick links is increased by one");
			
			
			
			extentReport.info("3700 S Select More Action button and select option to Add or Remove Columns");
			recentTrnsPg.validateMoreActionBtn();
			recentTrnsPg.validateAddRemoveCol();
			extentReport.reportScreenShot("Selected More Action button and select option to Add or Remove Columns");
			
			
			
			extentReport.info("3800 S On Add Remove column dialog, uncheck Device checkbox and click on Done button.");
			recentTrnsPg.validateSelectAddRemoveDeviceChckBx();
			extentReport.reportScreenShot("Add Remove column dialog, unchecked Device checkbox");
			recentTrnsPg.validateAddRemPopupDoneBtn();
			extentReport.reportScreenShot("Add Remove column dialog, clicked on Done button.");
			
			
			
			extentReport.info("3900 V Verify that Device Column is not displayed on RT Page",new String[] {"TransMgt16763"});
			assertions.assertEqualsWithReporting(false,recentTrnsPg.verifyDeviceColumn(), extentReport, "Verified that Device Column is not displayed on RT Page");
			extentReport.reportScreenShot("Verified that Device Column is not displayed on RT Page");
			
			
			extentReport.info("4000 S Click on Enroll a new patient button");
			recentTrnsPg.verifyEnrollPatientBtn();
			recentTrnsPg.validateEnrollPatientBtn();
			extentReport.reportScreenShot("Clicked on Enroll a new patient button");
			
			
			extentReport.info("4100 V Verify that Patient Finder page is displayed",new String[] {"Gen2069"});
			assertion.assertEqualsWithReporting(true,recentTrnsPg.verifyEnrollPatientPg(), extentReport, "Verified that Patient Finder page is displayed");
			
			
			
			
			extentReport.info("4200 S Navigate to Recent Transmission page");
			assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"), extentReport, "Navigated to Recent Transmission page");
			extentReport.reportScreenShot("Navigated to Recent Transmission page");
			
			
			
			extentReport.info("4300 S Click on Pen icon in Latest Comments column");
			recentTrnsPg.validatePencilIcon();
			extentReport.reportScreenShot("Clicked on Pen icon in Latest Comments column");
			
			
			extentReport.info("4400 V Verify that Clinical Comments dialog is displayed",new String[] {"TransMgt16824"});			
			assertion.assertEqualsWithReporting(true,recentTrnsPg.verifyClinicCommentPoup(), extentReport, "Verifed that Clinical Comments dialog is displayed");
			extentReport.reportScreenShot("Verifed that Clinical Comments dialog is displayed");
			
			
			
			extentReport.info("4500 S Click on Cancel button on Clinical Comments dialog");
			recentTrnsPg.validateClinicCommentPoupCloseBtn();
			extentReport.reportScreenShot("Clicked on Cancel button on Clinical Comments dialog");
			
			
			extentReport.info("4600 S Search transmissions for Patient B");
			recentTrnsPg.enterTier3FilterInputBx("Patient_A");
			extentReport.reportScreenShot("Searched transmissions for Patient B");
			
			
			
			
			extentReport.info("4700 V Verify DirectAlert Flag is displayed as Red",new String[] {"TransMgt8946"});
			assertion.assertEqualsWithReporting(true,recentTrnsPg.ValidateColorOfDirectAlertFlag("Patient_A").equalsIgnoreCase("Color rgba value"), extentReport, "Verifed that Clinical Comments dialog is displayed");
			extentReport.reportScreenShot("Verified DirectAlert Flag is displayed as Red");
			
			
			extentReport.info("4800 S Search transmissions for Patient C");
			recentTrnsPg.enterTier3FilterInputBx("Patient_C");
			extentReport.reportScreenShot("Searched transmissions for Patient C");
			
			extentReport.info("4900 V Verify DirectAlert Flag is displayed as Yellow",new String[] {"TransMgt8946"});
			assertion.assertEqualsWithReporting(true,recentTrnsPg.ValidateColorOfDirectAlertFlag("Patient_C").equalsIgnoreCase("Color rgba value"), extentReport, "Verifed that Clinical Comments dialog is displayed");
			extentReport.reportScreenShot("Verified DirectAlert Flag is displayed as Red");
			
			
			extentReport.info("5000 S Click on user name link in Signed in as to open My Account page");
			recentTrnsPg.navigateToMyAccountPg();
			extentReport.reportScreenShot("Clicked on user name link in Signed in as to open My Account page");
			
			
			extentReport.info("5100 S Click on Edit button");
			recentTrnsPg.validateEditBtnMyAcnt();
			extentReport.reportScreenShot("Clicked on Edit button");
			
			
			
			extentReport.info("5200 S In RT Preference section, select Clinic Location Radio button and save the changes");
			recentTrnsPg.validateSelectClinicLocRdBtn();
			assertion.assertEqualsWithReporting(true,recentTrnsPg.verifyClinicLocRdBtn(), extentReport, "Clinic Location Radio button is selected");
			extentReport.reportScreenShot("Clicked on Edit button");
			recentTrnsPg.validateSaveBtn();
			extentReport.reportScreenShot("Clicked on Save button");
			
			
			
			extentReport.info("5300 S Logout and relogin to clinic with same physician");
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"), extentReport, "Recent Transmission Tab is displayed");			
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
					
			
			
			extentReport.info("5400 V Verify that transmission list is sorted on Location column in ascending order",new String[] {"TransMgt16810","TransMgt15516"});
			assertion.assertEqualsWithReporting(true,recentTrnsPg.verifyLocationOfTrnsInAscendingOrderInTable(), extentReport, "Verified that transmission list is sorted on Location column in ascending order");	
			
			
			
			extentReport.info("5500 S Click on user name link in Signed in as to open My Account page");
			recentTrnsPg.navigateToMyAccountPg();
			extentReport.reportScreenShot("Clicked on user name link in Signed in as to open My Account page");
			
			
			
			extentReport.info("5600 S Click on Edit button");
			recentTrnsPg.validateEditBtnMyAcnt();
			extentReport.reportScreenShot("Clicked on Edit button");
			
			
			
			extentReport.info("5700 S In RT Preference section, select DirectAlerts Radio button and save the changes");
			recentTrnsPg.validateDeSelectClinicLocRdBtn();
			assertion.assertEqualsWithReporting(false,recentTrnsPg.verifyClinicLocRdBtn(), extentReport, "Clinic Location Radio button is deselected");
			extentReport.reportScreenShot("Clicked on Edit button");
			recentTrnsPg.validateSaveBtn();
			extentReport.reportScreenShot("Clicked on Save button");
			
			
			
			
			extentTest = extentReport.info("5800 S Run update query to mark archived transmission of Patient A back to unarchived state.");
			//capture the list of unarchive transmission
			dataBaseConnector.getConnection();			
			String unArchiveTrnsquery = "SELECT website_notification_id  FROM transmissions.rt_cache where transmission_id IN (Select transmission_id FROM transmissions.transmission"
					+ "			Where patient_id= (SELECT patient_id FROM patients.patient where first_name = 'Pat_AllTrans_FN'))";			
			ResultSet unArchveTrnsmsList = dataBaseConnector.executeQuery(unArchiveTrnsquery);			
			ArrayList<String> unArchivetransmissionList= new ArrayList<String>() ;			
			while(unArchveTrnsmsList.next())
			{
				unArchivetransmissionList.add(unArchveTrnsmsList.getString("website_notification_id")) ;
			}
			
			//capture all transmission id
			String archiveTrnsquery = "SELECT website_notification_id FROM alerts.website_notification where transmission_id IN \r\n"
					+ "			(Select transmission_id FROM transmissions.transmission Where patient_id= \r\n"
					+ "			(SELECT patient_id FROM patients.patient where first_name = 'Pat_AllTrans_FN'))";			
			ResultSet archveTrnsmsList = dataBaseConnector.executeQuery(archiveTrnsquery);			
			ArrayList<String> archivetransmissionList= new ArrayList<String>() ;			
			while(archveTrnsmsList.next())
			{
				archivetransmissionList.add(archveTrnsmsList.getString("website_notification_id")) ;
			}			
			//capture unarchive transmission count
			archivetransmissionList.removeAll(unArchivetransmissionList);
			String dltdTrnsId=archivetransmissionList.get(0).toString();			
			
//			//insert the query
			String InsertQuer = "insert into transmissions.rt_cache\r\n"
					+ "select wn.website_notification_id,\r\n"
					+ "wn.status_cd,alert_severity_cd,forwarded_highlighting_flg,alert_highlighting_flg,last_viewed_by,v.customer_appl_patient_id,v.transmission_id,session_date_and_time,\r\n"
					+ "scheduled_flg,transmission_type_cd,telemetry_type_cd,device_serial_num,device_model_num,transmission_source_cd,total_episode_alert_count,ep_non_episodal_alert_count,\r\n"
					+ "hf_non_episodal_alert_count,episode_count,card_data_arrival_event_id,patient_id,first_name,middle_name,last_name,alt_first_name,alt_last_name,\r\n"
					+ "patient_messaging_reminder_flg,patient_call_sms,patient_num,patient_call_contact_type_cd,patient_application_status_cd,device_implant_date,\r\n"
					+ "currently_implanted_flg,device_type,device_name,device_full_description,v.FDA_IDE_FLG device_fda_ide_flg,device_category_cd,v.customer_application_id,customer_id,\r\n"
					+ "cp_messaging_flg,v.PHONE_NUM primary_phone_num,location_name,customer_location_id,scheduled_time,latest_patient_comment,v.leads lead_models,other_clinic_name,advisory_indication_cd,\r\n"
					+ "next_followup_date,alert_info_cache,medteam_info_cache,medteam_caid_info_cache,wn.has_key_episode_flg\r\n"
					+ "from transmissions.V_RTC_WEBSITE_NOTIF_INS v,alerts.website_notification wn where v.customer_application_id=146225 and wn.website_notification_id=221232     and\r\n"
					+ "wn.transmission_id=v.transmission_id\r\n"
					+ "and not exists(select 1 from transmissions.rt_cache rc where rc.transmission_id=v.transmission_id)";			
			int InsertQueeyExc = dataBaseConnector.updateInsertQuery(InsertQuer);
			
			//commit the insert query
			String commitQuer = "commit";			
			int commitQueryExc = dataBaseConnector.updateInsertQuery(commitQuer);
			
			//update rtcahce table
			String updateRtCacheTbl = "UPDATE transmissions.rt_cache rc set status_cd =69 where website_notification_id =221232";			
			int updateRtCacheTb = dataBaseConnector.updateInsertQuery(updateRtCacheTbl);
			
			//update webnotification tbale table
			String webNotTablTbl = "update alerts.website_notification wn set status_cd = 69 where website_notification_id =221232";			
			int webNotTableTbl = dataBaseConnector.updateInsertQuery(webNotTablTbl);
			
			
			
			
			
			//limited user login
			extentReport.info("5900 S Login with Limited Account User and navigate to Recent Transmission page");
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"), extentReport, "Recent Transmission Tab is displayed");			
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
			
			
			//blocked due to not able to create limited user
			extentReport.info("6000 S Select tier 1 filter as Clinic Patients and tier 2 filter as All");			
			assertion.assertEqualsWithReporting(true, recentTrnsPg.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("all");
			extentReport.reportScreenShot("Selected tier 1 filter as Clinic Patients and tier 2 filter as All");
			
			
			
			extentReport.info("6100 V Verify that all unarchived transmissions in clinic are displayed in Transmission list.",new String[] {"TransMgt8929","TransMgt16990"});
			//check with lakshmi how to check that all transmissions are unarchived or we can do it like check known transmission are present as they are unarchived
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");//viewed
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");//unviewed
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");
			
			
			
			extentReport.info("6200 S Select patient selection checkbox next to any one transmission");
			recentTrnsPg.slctPatientChkBx("Patient_A","index of the patient check box");
			extentReport.reportScreenShot("Select patient selection checkbox next to Patient_A transmission.");
			
			
			extentReport.info("6300 V Verify that Archive button is in inactive state",new String[] {"TransMgt17430"});
			assertions.assertEqualsWithReporting(false, recentTrnsPg.verifyArchiveBtn(), extentReport, "Verified that Archive button is in inactive state");
			
			
			extentReport.info("6400 V Verify that pen icon in Latest Comments section is not displayed.",new String[] {"TransMgt16824"});
			assertions.assertEqualsWithReporting(false, recentTrnsPg.verifyPencilIcon(), extentReport, "Verified that pen icon in Latest Comments section is not displayed.");
			
			
			extentReport.info("6500 S Search for transmissions of Patient A");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");//viewed
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");//unviewed
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyPatientInTable("Patient_Name_A"), extentReport, "Patient_Name_A is present in the list");
			extentReport.reportScreenShot("transmissions of Patient A is validated successfully.");
			
			
			
			extentReport.info("6600 S Click on Transmission link of one unviewed transmission.");
			recentTrnsPg.validateUnviewedTransLinkWithPatientName("Patient_Nme", "index");
			extentReport.reportScreenShot("Clicked on Transmission link of one unviewed transmission.");
			
			
			
			extentReport.info("6700 S Transmission Details page is displayed showing reports in selected transmission. ");
			assertions.assertEqualsWithReporting(true, recentTrnsPg.verifyTransmissionReportPage(), extentReport, "Verified that Transmission Details page is displayed showing reports in selected transmission.");
			extentReport.reportScreenShot("Verified that Transmission Details page is displayed showing reports in selected transmission.");
			
			
			
			extentReport.info("6800 S Navigate to Recent Transmission page");
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
			
			
			
			extentReport.info("6900 V Verify that transmission selected to view reports is still marked as unviewed.",new String[] {"TransMgt16765"});
			
			
			
			
			extentReport.info("7000 S Logout. End of TC.");
			appHomeTopNavPage.clickSignOutLink();
			extentReport.reportScreenShot("Logged out of an application");
			
			
			
		}catch (AssertionError e) {
			 extentReport.reportFail( "WA_IB001_RecentTransmission_01_TC is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "WA_IB001_RecentTransmission_01_TC is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}
