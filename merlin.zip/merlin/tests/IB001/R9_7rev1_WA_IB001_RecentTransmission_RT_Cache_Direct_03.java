package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;


/*
 * Author: Victor
 * Test Case: R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03
 * Test case id: 1238698,
 */

public class R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	
	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		
		
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		commonUtils=new CommonUtils();
		
	}
	
	
	@Test	
	public void R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMAdmin");
		extentTest.assignAuthor("Author: Victor");
		try {
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100S Login to the Direct Clinic having Transmissions.");
			loginPage.login(login);
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			//assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Record patient data collection consent");
				
			
			extentReport.info("200V Verify that Recent Transmission Page is displayed and Clinic Patients is displayed in Tier1 filter and All in Tier2 filter.",new String[] {"<TransMgt16395>"});
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission Page is not displayed ");
			recentTransmissionsPage.verifyMyPatientIsdisplayedTier1();
			recentTransmissionsPage.verifyALLIsdisplayedTier2();
			
			
			
			extentReport.info("300S Select Cardiac Monitor filter in tier2.");
			recentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			recentTransmissionsPage.selectTireOTwoFilterOption("cardiac monitor");
			
			//Xpath issue -
			extentReport.info("400V Verify that only patients having Cardiac Monitor Device are displayed",new String[] {"<TransMgt16395>"});
			recentTransmissionsPage.verifyPatientHavingICM("ICM");
			extentReport.reportScreenShot("ICM Device displayed");
			
			
			
			extentReport.info("500S Select ICD/Pacemaker filter from tier2 filter.");
			recentTransmissionsPage.selectTireOTwoFilterOption("all");
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission Page is not displayed ");
			recentTransmissionsPage.selectTireOTwoFilterOption("icd/pacemaker");
			
			//Xpath issue -
			extentReport.info("600V Verify that only patients having ICD/ Device are displayed",new String[] {"<TransMgt17588>"});
			recentTransmissionsPage.verifyPatientsHavingICDPaceMaker("ICM");
			extentReport.reportScreenShot("ICD Pacemaker displayed");
			
			extentReport.info("700S Select Transmission with alerts filter in tier2.");
			recentTransmissionsPage.selectTireOTwoFilterOption("transmissions with alerts");
			
			//Xpath issue -
			extentReport.info("800V Verify that only Patients having Transmission with alerts is displayed",new String[] {"<TransMgt8934>"});
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyAlertwithTransmission(), extentReport, "Transmission with alerts is not displayed ");
			extentReport.reportScreenShot("Transmission with alerts is displayed");
			
			extentReport.info("900S Select the Patient filter and type a name in search box.");
			recentTransmissionsPage.selectTireOTwoFilterOption("all");
			recentTransmissionsPage.selectTireOTwoFilterOption("patient");
			recentTransmissionsPage.enterTier3FilterInputBx("0727 Jsontext");
			
			//Xpath issue -
			extentReport.info("1000V Verify that only Patients with the name searched are displayed.",new String[] {"<TransMgt8932>"});
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyPatientNameisDisplayed("0727 Jsontext"), extentReport, "Patient name is not displayed ");
			extentReport.reportScreenShot("Patients with the name searched is displayed");
			
			extentReport.info("1100S Navigate to any of the Primary Tabs (Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), extentReport, "Clinic Administration page is displayed");
			
			
			extentReport.info("1200S Navigate back to the Recent Transmission Page.");
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			
			//issue raised on this defect - issue #3898
			extentReport.info("1300V Verify that Search box displays the previous searched word and same Patients are displayed in the list.",new String[] {"<TransMgt8932>"});
			recentTransmissionsPage.verifyTextInSearchBox("0727 Jsontext");
			extentReport.reportScreenShot("Patients with the name searched is displayed");
			
			
			extentReport.info("1400S Select the Physician name/ID filter and type a name or ID in search box.");
			recentTransmissionsPage.selectTireOTwoFilterOption("physician name/id");
			recentTransmissionsPage.enterTier3FilterInputBx("icm115_allied");
			
			//Xpath issue -
			extentReport.info("1500V Verify that only Patients having Physician name/ID searched are displayed.",new String[] {"<TransMgt8931>","TransMgt17000"});
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyPatientNameisDisplayed("icm115_allied"), extentReport, "Physician ID is not displayed ");
			
			
			extentReport.info("1600S Navigate to any of the Primary Tabs (Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), extentReport, "Clinic Administration page is displayed");
			
			
			extentReport.info("1700S Navigate back to the Recent Transmission Page.");
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Clinic Administration page is displayed");
			
	
			extentReport.info("1800V Verify that Search box displays the previous searched word and same Patients are displayed in the list.",new String[] {"<TransMgt8931>","<TransMgt17000>"});
			recentTransmissionsPage.verifyTextInSearchBox("0727 Jsontext");
			extentReport.reportScreenShot("Same Patients with the name searched is displayed");
			//Jot Dx ICM, DM4500 : 1170655
			
			extentReport.info("1900S Select the Device filter and type a Device in search box.");
			recentTransmissionsPage.selectTireOTwoFilterOption("device");
			recentTransmissionsPage.enterTier3FilterInputBx("Jot Dx ICM, DM4500 : 1170655");//need to enter valid Device
			
			//xpath issue -
			extentReport.info("2000V Verify that only Patients matching the device number or the device name searched are displayed.",new String[] {"<TransMgt8937>"});
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyDeviceNameisDisplayed("Jot Dx ICM, DM4500 : 1170655"), extentReport, "Physician ID is not displayed ");
			extentReport.reportScreenShot("Same Device with the name searched is displayed");
			
			
			extentReport.info("2100S Navigate to any of the Primary Tabs(Patient List, tools, Clinic administration");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), extentReport, "Clinic Administration page is displayed");
			
			
			
			extentReport.info("2200S Navigate back to the Recent Transmission Page.");
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Clinic Administration page is displayed");
			
			
			//xpath issue -
			extentReport.info("2300V Verify that Search box displays the previous searched word and same Patients are displayed in the list.",new String[] {"<TransMgt8937>"});
			recentTransmissionsPage.verifyTextInSearchBox("Jot Dx ICM, DM4500 : 1170655");
			extentReport.reportScreenShot("Same Patients with the name searched is displayed");
			
			
			extentReport.info("2400S Select the Device type in teir2 filter and select a device type in search box.");
			recentTransmissionsPage.selectTireOTwoFilterOption("device type");
			recentTransmissionsPage.enterTier3FilterInputBx("Cardiac Monitor(ICM)");//need to enter valid Device
			
			
			//xpath issue -
			extentReport.info("2500V Verify that only Patients matching the device type are displayed.",new String[] {"<TransMgt8936>","TransMgt8939"});
			recentTransmissionsPage.verifyPatientHavingICM("ICM");
			extentReport.reportScreenShot("Same Patients with the name searched is displayed");
			
			
			extentReport.info("2600S Navigate to any of the Primary Tabs (Patient List, tools, Clinic administration");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), extentReport, "Clinic Administration page is displayed");
			
			
			
			extentReport.info("2700S Navigate back to the Recent Transmission Page.");
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Clinic Administration page is displayed");
			
			
		
			//xpath issue -
			extentReport.info("2800V Verify that Search box displays the previous searched word and same Patients are displayed in the list.",new String[] {"<TransMgt8936>","TransMgt8939"});
			recentTransmissionsPage.verifyTextInSearchBox("Cardiac Monitor(ICM)");
			extentReport.reportScreenShot("Same Patients with the name searched is displayed");
			
			extentReport.info("2900S Select the Patient’s clinic location in teir2 filter and select a location in search box.");
			recentTransmissionsPage.selectTireOTwoFilterOption("patient’s clinic location");
			recentTransmissionsPage.enterTier3FilterInputBx("Ohio");//need to enter valid Device
			
			
			
			//xpath issue -
			extentReport.info("3000V Verify that only Patients in that location are displayed.",new String[] {"<TransMgt8935>"});
			recentTransmissionsPage.verifyPatientLocation("Ohio");
			extentReport.reportScreenShot("Patients with the Location searched is displayed");
			
			extentReport.info("3100S Navigate to any of the Primary Tabs (Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), extentReport, "Clinic Administration page is displayed");
			recentTransmissionsPage.navigateToRecentTransmissionPage();
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Clinic Administration page is displayed");
		
			
			
			//xpath issue -
			extentReport.info("3200V Verify that Search box displays the previous searched word and same Patients are displayed in the list.",new String[] {"<TransMgt8935>"});
			recentTransmissionsPage.verifyTextInSearchBox("Ohio");
			extentReport.reportScreenShot("Same Patients with the Location searched is displayed");
			
			assertion.assertAll();
			
			
		}catch (AssertionError e) {
			 extentReport.reportFail( "R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}
