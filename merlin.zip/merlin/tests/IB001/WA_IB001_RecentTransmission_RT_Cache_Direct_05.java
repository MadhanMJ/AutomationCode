package com.test.qa.ui.tests.IB001;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.AlliedndPhyscianLeftNav;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.AlliedndPhyscianTopNav;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTrasnmissions_MoreActions;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_IB001_RecentTransmission_RT_Cache_Direct_05 extends CommonUtils
{

	ClinicianHomePage clinicianHomePage;
	CA_RecentTransmissionsPage recenttrasmissionpage;
	ClinicianHomeTopNavPage clinicianhometopnavpage;
	PatientListPage patientlistpage;
	
	LoginPageWithPOJO loginPage;
	Login Clinic_User;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	@BeforeClass
	public void initialize() 
	{
		
         clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		recenttrasmissionpage=new CA_RecentTransmissionsPage(driver, extentReport);
		clinicianhometopnavpage=new ClinicianHomeTopNavPage(driver, extentReport);
		patientlistpage=new PatientListPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		Clinic_User = new Login();
		testDataProvider = new TestDataProvider();
	}
	
	
  @Test
  public void TC_WA_IB001_RecentTransmission_RT_Cache_Direct_05() {
	  
	  
	  testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		Clinic_User = testDataProvider.getLoginData("SJMClinic3");
		
		
		extentTest.assignAuthor("Author: Kundan Kumar");
		try {
			
			extentReport.info("100 S Login to the Direct Clinic having Transmissions and  Navigate back to the Recent Transmission Page.");
			loginPage.login(Clinic_User);
			Assert.assertTrue(recenttrasmissionpage.verifyLandingPage(), "Clinicial Home Page is Displayed.");
			recenttrasmissionpage.navigateToRecentTransmissionPage();
			
			extentReport.info("200 S Select the More Action click on download Spreadsheet.");
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoDownloadSpreadhsheetOption();
			
			extentReport.info("300 V Verify that Spreadsheet downloaded in specified location given by user.", new String[] {"CommUI10852,TransMgt16752"});
			recenttrasmissionpage.verifySpreadhsheetDownloaded();
			//Need to discuss how to automate verification part.Is there any method to verify this
			
			extentReport.info("400 S Select the More Action click on Add or Remove columns");
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoAddorRemovecoloumnoption();
			
			extentReport.info("500 S Add some columns and remove some in add or remove window");
			recenttrasmissionpage.selectandunselectcolumnoptions();
			
			extentReport.info("600 V Verify that the Columns added are visible and removed are not visible.", new String[] {"CommUI8478,TransMgt16763"});
			recenttrasmissionpage.validateAddedorRemoveColumnHeader();
			
			extentReport.info("700 S Select Print in More Actions dropdown");
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoPrintOption();
			
			extentReport.info("800 V Verify that only columns present are appeared in the print window .", new String[] {"CommUI10852,CommUI8478,TransMgt16807,TransMgt16763"});
			recenttrasmissionpage.validateAddedorRemoveColumnHeader();
			recenttrasmissionpage.closePrintWindow();
			
			
			extentReport.info("900 S Select Download Spreadsheet & Save.");
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoDownloadSpreadhsheetOption();
			
			extentReport.info("1000 V Verify that only the added columns are visible and downloaded.", new String[] {"CommUI10852,CommUI8478,TransMgt16763"});
			//Need to discuss how to automate this step
			
			extentReport.info("1100 S Check a patient in recent Transmission, select More Action and and click select Export Transmission.");
			recenttrasmissionpage.selectpatientcheckbox();
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoExportTransMissionWindow();
			
			extentReport.info("1200 V Verify that Export Transmission window is displayed.", new String[] {"TransMgt16752"});
			recenttrasmissionpage.validateExportTransmissionWindow();
			
			
			extentReport.info("1300 S Check a patient in recent Transmission, select More Action and and click select Send a Directcall.");
			recenttrasmissionpage.selectpatientcheckbox();
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoDirectCallOption();
			
			extentReport.info("1400 V Verify that the send direct call window is displayed.", new String[] {"TransMgt9110"});
			recenttrasmissionpage.validateDirectCallWindow();
			
			extentReport.info("1500 V Verify that the radio box is not enabled.", new String[] {"TransMgt9110"});
			recenttrasmissionpage.verifyDirectcallRadioButtonNotEnabled();
			
			
			extentReport.info("1600 S Navigate to patient list page, select the same  Patient in Patient list page to goto patient profile page,check the DirectCall™ Automated follow-up reminders and DirectCall™ Automated overdue messages and save.");
			clinicianhometopnavpage.navigateToPatientListPage();
			//patientlistpage.searchAPatient(testName, testName, testName);
			patientlistpage.editPatientProfile();
			
            extentReport.info("1700 S Navigate to recent Transmission page and select the patient you have checked and select the send a direct call.");
            recenttrasmissionpage.selectpatientcheckbox();
			recenttrasmissionpage.navigatetoMoreActionsOption();
			recenttrasmissionpage.navigatetoDirectCallOption();
			
            extentReport.info("1800 V Send a direct call window opens and able to enable radio button and a success message is displayed." ,new String[] {"TransMgt9110"});
            recenttrasmissionpage.validateDirectCallWindow();
            recenttrasmissionpage.directcallEnableRadioButton();
            
            
            extentReport.info("1900 S Navigate to Patients List Page and select a patient with Transmissions, navigate to Transmission tab.");
            clinicianhometopnavpage.navigateToPatientListPage();
			///patientlistpage.searchAPatient(testName, testName, testName);
			patientlistpage.navigateToTranmissionTab();
			
            extentReport.info("2000 S Select More Action select Marked as Unviewed.");
            patientlistpage.navigateToTransmissionMoreaction();
            patientlistpage.naviagteToMarkunviewedOption();
           
            extentReport.info("2100 V Verify that the transmission becomes Unviewed (Bold) on All Transmission tab." ,new String[] {"TransMgt16919,TransMgt17431"});
           patientlistpage.navigateToAllTransmissionTab();
           patientlistpage.verifyTranmissionInBold();
            
            extentReport.info("2200 S Navigate to Patients List Page and select a patient with Transmissions, navigate to Transmission tab.");
            clinicianhometopnavpage.navigateToPatientListPage();
			//patientlistpage.searchAPatient(testName, testName, testName);
			patientlistpage.navigateToTranmissionTab();
			
            extentReport.info("2300 S Select More Action and select Export the Transmission.");
            patientlistpage.navigateToTransmissionMoreaction();
            patientlistpage.navigateToExportTransmission();
            
            extentReport.info("2400 V Verify that the Export transmission page is displayed. <TransMgt16919>", new String[] {"TransMgt16919"});
            patientlistpage.verifyExportTransmissionWindow();
            //Method Need to define
            
           extentReport.info("2500 S Select More Action select a direct Call(send the direct call check the box");
           patientlistpage.navigateToTransmissionMoreaction();
           patientlistpage.navigateToDirectCallOption();
		
			
           extentReport.info("2600 V Send a direct call window opens and able to enable radio button and a success message is displayed.", new String[] {"TransMgt16919"});
           patientlistpage.validatePtListDirectcallwindow();
           patientlistpage.selectRadioButtonDirectCallWindow();
           
           extentReport.info("2700 S Select contact a Colleague in more Action.");
           patientlistpage.navigateToTransmissionMoreaction();
           patientlistpage.navigateToContactColleague();

          extentReport.info("2800 V Verify that the contact a colleague page opens.", new String[] {"TransMgt16919"});
           patientlistpage.validateContactAcolleagueWindow();
  
          extentReport.info("2900 S Select the Transmission in all Transmission Page and check a transmission.");
          patientlistpage.navigateToAllTransmissionTab();
          //Need to write for select transmission
          
          extentReport.info("3000 S select the View as unviewed Transmission");
          patientlistpage.navigateToAllTransmissionMoreaction();
          patientlistpage.naviagteToMarkunviewedOption();

          extentReport.info("3100 V Verify that in Recent Transmission page it is viewed as unviewed (Bold).", new String[] {"TransMgt16919"});
          recenttrasmissionpage.navigateToRecentTransmissionPage();
          //Need to verify transmission in bold
          
          extentReport.info("3200 S Select the Transmission in all Transmission Page and check a transmission.");
          clinicianhometopnavpage.navigateToPatientListPage();
          patientlistpage.navigateToAllTransmissionTab();
          //Need to write for select transmission
          
          extentReport.info("3300 S select the Export a Transmission");
          patientlistpage.navigateToAllTransmissionMoreaction();
          patientlistpage.navigateToAllTransmissionExportTransmission();

          extentReport.info("3400 V Verify that the Export transmission page is displayed.",new String[] {"TransMgt16639"});
          //ExportTransmission window is not coming yet
          
          extentReport.info("3500 S Select the Transmission in all Transmission Page and check a transmission.");
          clinicianhometopnavpage.navigateToPatientListPage();
          patientlistpage.navigateToAllTransmissionTab();
          //Need to write for select transmission
          
          extentReport.info("3600 S Select More Action select a direct Call(send the direct call check the box).");
          patientlistpage.navigateToAllTransmissionMoreaction();
          patientlistpage.navigateToAllTransmissionDirectCall();
          
          extentReport.info("3700 V Send a direct call window opens and able to enable radio button and a success message is displayed.", new String[] {"TransMgt16640"});
          patientlistpage.validatePtListDirectcallwindow();
          patientlistpage.selectRadioButtonDirectCallWindow();
          
			}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	/*	@AfterMethod
		public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
			String status = null;
			String testMethodName = result.getMethod().getMethodName();
			 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
				 status = "Failure";
			    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			    	status = "Success";
			    } 
			
			writeInTextFile(testMethodName, status);
		}*/
		
}
  }

