package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

/***********************************************************************************/
//Saints Id :  1238705
//Test Case :  R9.7rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_5[
//Author    : Jeetendra Gupta
//Date      : 02/05/2021
/***********************************************************************************/

public class R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_5 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	Login login;
	Login loginClinicUser_withoutICDDevice;
	CA_SchedulingAndMessagingPage scmePage;
	ClinicianHomeTopNavPage appHomeTopNavPage;
	CA_LeftNavPage LeftNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage MerlinAtHomePage;
	CA_ClinicProfilePage profilepage;
	PatientListPage patientListPage;
	PL_AllTransmissionsPage plTransmission;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		scmePage = new CA_SchedulingAndMessagingPage(driver, extentReport);
		appHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		recentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		MerlinAtHomePage = new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		plTransmission=new PL_AllTransmissionsPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		LeftNavPage = new CA_LeftNavPage(driver, extentReport);
		profilepage = new CA_ClinicProfilePage(driver, extentReport);
	}

	@Test
	public void RecentTransmission_RT_Cache_SP2_5() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		loginClinicUser_withoutICDDevice = testDataProvider.getLoginData("JitClinic7");
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Jeetendra Gupta");// comments
		try {			
			Assertions assertion = new Assertions(extentTest);
			extentReport.info("100S Login to Sp2 Clinic");
			loginPage.login(loginClinicUser_withoutICDDevice,"externaluser");
			assertion.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");

//			extentReport.info(
//					"200S Select the any Patient with viewed transmission (unbold) and Click on More Actions. Click Mark as unviewed");
//			recentTransmissionsPage.verifyViewedPatientInTable("", ""); -- Need Fix
//			recentTransmissionsPage.navigatetoMoreActionsOption();
//			recentTransmissionsPage.clickOnMoreActionUnviewed();
//			extentReport.info("300V Verify that the Transmission becomes unviewed(bold)");
//			recentTransmissionsPage.verifyUnViewedPatientInTable("", ""); -- Need Fix
			extentReport.info("400S Click on more Action. Click on Print");
			recentTransmissionsPage.navigatetoMoreActionsOption();
//			recentTransmissionsPage.clickOnMoreActionPrintBtn(); --need to fix

			extentReport.info("500V Verify that all the patients details window is displayed and click print");
			recentTransmissionsPage.verifyPrintWindow();
			recentTransmissionsPage.clickPrintButton();
			extentReport.info("600V Verify that the Patient list is Printed.");
			recentTransmissionsPage.verifyPrintPdfWindow();
//			recentTransmissionsPage.savepdflocation(); -- need to fix
			extentReport.info("700S Select the More Action click on download Spreadsheet.");
			recentTransmissionsPage.navigatetoMoreActionsOption();
			recentTransmissionsPage.navigatetoDownloadSpreadhsheetOption();
			extentReport.info("800V Verify that Spreadsheet downloaded in specified location given by user.");
//			recentTransmissionsPage.verifyspreadsheetdownloadedLocation(); --need to fix 
			extentReport.info("900S Select the More Action click on Add or Remove columns.");
			recentTransmissionsPage.navigatetoMoreActionsOption();
			recentTransmissionsPage.navigatetoAddorRemovecoloumnoption();
			extentReport.info("1000S Add some columns and remove some in add or remove window");
			recentTransmissionsPage.selectandunselectcolumnoptions();			
			extentReport.info("1100V Verify that the Columns added are visible and removed are not visible.");
			recentTransmissionsPage.validateAddedorRemoveColumnHeader(); 
			extentReport.info("1200S Select Print in More Actions dropdown");
			recentTransmissionsPage.navigatetoMoreActionsOption();
			recentTransmissionsPage.clickOnMoreActionPrintBtn();
			extentReport
					.info("1300V Verify that only columns present are appeared in the print window and click print.");
			recentTransmissionsPage.verifyPrintWindow();
			recentTransmissionsPage.clickPrintButton();			
			
			extentReport.info("1400V Verify the printed sheet contains only the Added columns.");
//			recentTransmissionsPage.verifyHeaderinpdfSheet(); --need to fix
			
			extentReport.info("1500S Select Download Spreadsheet.");
			recentTransmissionsPage.navigatetoMoreActionsOption();
			recentTransmissionsPage.navigatetoDownloadSpreadhsheetOption();
			extentReport.info("1600V Verify that only the added columns are visible and downloaded. ");
			recentTransmissionsPage.verifySpreadhsheetDownloaded();
//			recentTransmissionsPage.verifySpreadsheetHeaderwithWebHeader(); --need to fix
			extentReport.info(
					"1900S Check a patient in recent Transmission, select More Action and and click select Send a Directcall.");
			recentTransmissionsPage.selectpatientcheckbox();
			recentTransmissionsPage.navigatetoMoreActionsOption();
			recentTransmissionsPage.navigatetoDirectCallOption();
			
			extentReport.info("2000V Verify that the send direct call window is displayed.");
			recentTransmissionsPage.validateDirectCallWindow();
			
			extentReport.info(
					"2100V Verify that the radio box is not enabled if DirectCall™ Automated follow-up reminders and DirectCall™ Automated 			overdue messages are unchecked in patient profile.");
			recentTransmissionsPage.verifyDirectcallRadioButtonNotEnabled();
			extentReport.info(
					"2200S Select the same  Patient in Patient list page ,check the DirectCall™ Automated follow-up reminders and DirectCall™ Automated overdue messages and save.");

			extentReport.info(
					"2300S Navigate to recent Transmission page and select the patient you have checked and select the send a direct call.");
			recentTransmissionsPage.selectpatientcheckbox();
			recentTransmissionsPage.navigatetoMoreActionsOption();
			recentTransmissionsPage.navigatetoDirectCallOption();
			extentReport.info(
					"2400V Send a direct call window opens and able to enable radio button and a success message is displayed.");
			recentTransmissionsPage.directcallEnableRadioButton();
			extentReport.info(
					"2500S Navigate to Patients List Page and select a patient with Transmissions, navigate to Transmission tab.");
			appHomeTopNavPage.clickPatientListLink();
			patientListPage.verifyLandingPage();
			patientListPage.searchPatients(testName);
			patientListPage.clickOnPatientNameFrmList(testName);
			plTransmission.verifyLandingPage();
			extentReport.info("2600 select More Action select Marked as Unviewed.");
			plTransmission.clickOnmoreActionButton();
			plTransmission.clickOnmarkasUnviewed();
			extentReport.info("2700V Verify that the transmission becomes Unviewed(Bold)");
			appHomeTopNavPage.navigateToRecentTransmissionLink();
			recentTransmissionsPage.verifyUnViewedPatientInTable(testName, testName);
			extentReport.info(
					"2800S Navigate to Patients List Page and select a patient with Transmissions, navigate to Transmission tab.");
			appHomeTopNavPage.navigateToPatientListPage();
			patientListPage.verifyLandingPage();
			patientListPage.searchPatients(testName);
			patientListPage.clickOnPatientNameFrmList(testName);
			plTransmission.verifyLandingPage();
			
			extentReport.info(
					"2900S Select More Action select a direct Call(send the direct call check the box in patient profile).");
			plTransmission.clickOnmoreActionButton();
			plTransmission.ClickonSend_a_DirectCall_link();
			
			extentReport.info(
					"3000V Send a direct call window opens and able to enable radio button and a success message is displayed.");
			plTransmission.verifyDirectCallWindow();
			plTransmission.verifyradioButton_enabled();
			plTransmission.clickSendButton();
			extentReport.info("3100S Select contact a Colleague in more Action");
			plTransmission.clickOnmoreActionButton();
			plTransmission.ClickOnContact_a_Colleague();
			extentReport.info("3200V Verify that the contact a colleague page opens and email is send to the email");
			plTransmission.verifyContact_a_ColleagueWindow();
			extentReport.info("3210S Give a valid mail address in to Mail confirm mail and subject and click send");

			extentReport.info("​3220V Verify that The mail is send to to mail address");

			extentReport.info("3300S Select the Transmission in all Transmission Page and check a transmission.");

			extentReport.info("3400S select the View as unviewed Transmission in more action.");

			extentReport.info("3500V Verify that in Recent Transmission page it is viewed as unviewed (Bold).");

			extentReport.info("3600S Select the Transmission in all Transmission Page and check a transmission.");

			extentReport.info(
					"3700V Select More Action select a direct Call(send the direct call check the box in patient profile).");

			extentReport.takeFullSnapShot(driver,
					"3800V Send a direct call window opens and able to enable radio button and a success message is displayed.");

			extentReport.info("Test Case ends.");
			assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.reportFail("R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_5 Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_5 Validation not  successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}