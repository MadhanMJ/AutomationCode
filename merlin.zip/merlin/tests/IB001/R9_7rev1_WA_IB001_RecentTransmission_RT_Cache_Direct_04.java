package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_04 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_ClinicLocationsPage clinicLocationsPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	PatientListPage patientListPage;
	PL_AllTransmissionsPage allTransmissionsPage;
	PL_TransmissionPage transmissionPage;
	Customer customer;
	String location;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	
	@BeforeMethod(alwaysRun = true)
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		recentTransmissionsPage =  new CA_RecentTransmissionsPage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		allTransmissionsPage = new PL_AllTransmissionsPage(driver, extentReport); 
		transmissionPage = new PL_TransmissionPage(driver, extentReport); 
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		location = "abc";
	
		
	}
	
	
	// Testcase id: 1238699, Testcase name: R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_04, Author- Snehal Mane
	
	@Test	
	public void R97rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_04() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMClinic7");
		extentTest.assignAuthor("Author: Snehal Mane");
		try {
			Assertions assertions = new Assertions(extentTest);
			extentReport.info("100S Login to the Direct Clinic having Transmissions.");
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Logged in and ClinicianHomePage is displayed");
			
			
			extentReport.info("200S Navigate to the Clinic Administration -> Clinic Locations.");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport, "Navigated to clinic administration page");
			clinicAdminLeftNavPage.navigateToClinicLocationsPage();
			assertions.assertEqualsWithReporting(true,clinicLocationsPage.verifyLandingPage(),extentReport, "Navigated to clinic location page");
			
			extentReport.info("300S Click on add a location and add location, Navigate to the Recent Transmission Page and select Tier 2 filter 'Location'.");
			clinicLocationsPage.AddAndSearchLocations(location);
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTransmissionsPage.verifyLandingPage(),extentReport, "Recent Tranmission Page is displayed");
			recentTransmissionsPage.selectTireOTwoFilterOption("Patient’s Clinic Location");
			extentReport.reportScreenShot("'Patient’s Clinic Location' selected from tier2 filter");
			
			extentReport.info("400V Verify the location dropdown the location must be displayed.");
			recentTransmissionsPage.validateTier3FilterOptions(location);
			extentReport.reportScreenShot(location + " is present under tier3 filter options");
			
			extentReport.info("500S Check the checkbox of any Patient with unviewed transmission and Click archive");
			recentTransmissionsPage.slctUnvwdPatientChkBx("patientName", "index");
			extentReport.reportScreenShot("Checkbox is selected for unviewed transmission");
			recentTransmissionsPage.validateArchiveBtn();
			
			extentReport.info("600V Verify that a Dialog box with a message ‘1 Transmission have not yet been viewed. Would like to archive the selected transmission?’");
			String archiveMsgExpt = "1 transmissions have not yet been viewed. Would you like to archive the selected transmissions?";
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyArchivePopupMsgUnviewdTrans().equalsIgnoreCase(archiveMsgExpt), extentReport, "Validated dialog box with message '"+ archiveMsgExpt +"'");
			extentReport.reportScreenShot("Validated dialog box with message '"+ archiveMsgExpt +"'");
			
			extentReport.info("700S Click on OK");
			recentTransmissionsPage.ClickOnArchivePopupOKBtn();
			
			extentReport.info("800V Verify that the transmission is not displayed in the Recent Transmission Page now.");
			recentTransmissionsPage.validateArchivedTransNotPresent("patientName", "index");
			
			extentReport.info("900S Navigate to PatientList Page-> Select the patient whose transmission have been archived and Navigate to All Transmissions.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName");
			patientListPage.clickonAllTransmissionFrmList("patientName");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			
			extentReport.info("1000V Verify that the Transmission is marked as archived under Status column.");
			extentReport.reportScreenShot("All Transmissions are present");
			allTransmissionsPage.verifyAtchivedStatusForUnviwdTrans();
			
			extentReport.info("1300S Navigate to Patient List, select a patient having Transmission and move to Transmission Page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			//patientName2--> need the patient having transmissions from db
			patientListPage.enterTier3FilterInputBx("patientName2");
			//need to add validation point to chk if searched patient having transmission
			patientListPage.clickOnPatientNameFrmList("patientName2");
			transmissionPage.navigateToTransmissionTab();
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport, "TransmissionPage is displayed");
			
			extentReport.info("1400S Select archive option and navigate to the Recent Transmission Page.");
			transmissionPage.clickOnArchiveBtn();
			extentReport.pass("'" + transmissionPage.verifyArchiveMsg() + "' message is displayed");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTransmissionsPage.verifyLandingPage(),extentReport, "Recent Tranmission Page is displayed");
						
			extentReport.info("1500V Verify that the transmission is not displayed in the Recent Transmission Page now.");
			recentTransmissionsPage.validateArchivedTransNotPresent("patientName2", "index");
			
			extentReport.info("1600S Navigate to PatientList Page-> Select the patient whose transmission have been archived and Navigate to All Transmissions.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName2");
			patientListPage.clickonAllTransmissionFrmList("patientName2");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			
			extentReport.info("1700V Verify that the Transmission is marked as archived under Status column.");
			extentReport.reportScreenShot("All Transmissions are present");
			allTransmissionsPage.verifyAtchivedStatusOfTrans();
			
			extentReport.info("1800S Navigate to Patient List, select a patient having Transmission and move to All Transmission Page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			//patientName3--> need the patient having transmissions from db
			patientListPage.enterTier3FilterInputBx("patientName3");
			//need to add validation point to chk if searched patient having transmission
			patientListPage.clickonAllTransmissionFrmList("patientName3");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			extentReport.reportScreenShot("All Transmissions are present");
			
			extentReport.info("1900S Select a Transmission by checking the checkbox and archive option and navigate to the Recent Transmission Page.");			
			allTransmissionsPage.archiveTransmission();		
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTransmissionsPage.verifyLandingPage(),extentReport, "Recent Tranmission Page is displayed");
			
			extentReport.info("2000V Verify that the transmission is not displayed in the Recent Transmission Page now.");
			recentTransmissionsPage.validateArchivedTransNotPresent("patientName3", "index");
			
			extentReport.info("2100S Navigate to PatientList Page-> Select the patient whose transmission have been archived");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName3");
			
			extentReport.info("2200S Navigate to All Transmissions.");
			patientListPage.clickonAllTransmissionFrmList("patientName3");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			
			extentReport.info("2300V Verify that the Transmission is marked as archived under Status column.");
			extentReport.reportScreenShot("All Transmissions are present");
			allTransmissionsPage.verifyAtchivedStatusOfTrans();
			
			
			//Print Reports
			extentReport.info("2400S select one patient having transmission by checking the checkbox.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			//patientName3--> need the patient having transmissions from db
			recentTransmissionsPage.enterTier3FilterInputBx("patientName3");
			recentTransmissionsPage.slctVwdPatientChkBx("PateintName3", "0");
			extentReport.reportScreenShot("Checkbox is selected");			
			
			extentReport.info("2500S Click Print");
			recentTransmissionsPage.clickOnPrintButton();
			
			extentReport.info("2600V verify that the print Transmission window is open");
			recentTransmissionsPage.switchToWindow("Print Transmission");
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyPrintTransmission(), extentReport, "All Transmissions Page is displayed");			
			
			extentReport.info("2700S select any check box and click print");
			recentTransmissionsPage.allPrintSummaryCheckboxStatus("UncheckAll");
			recentTransmissionsPage.allPrintSummaryCheckboxStatus("VTVFEpisode");
			recentTransmissionsPage.clickPrintButton();
			
			//Pravin's Comments:[MNET1-4969] This test does not ask to do the actual print. But the print preview is supposed to be displayed in 3100V. So that can be verified. You dont need to verify the pdf contents. Verify that pdf is displayed in the pdf window.
			//Hence validating only that print report is displaying as per patient name
			extentReport.info("2800V Verify that Print of the transmission is done properly.");
			recentTransmissionsPage.switchToWindow("Patient Records");
			recentTransmissionsPage.verifyPatientNameInPrintReport("patientName3");
						
			extentReport.info("2900S Navigate to the Patient list page and select a patient with Transmission, Navigate to Transmission Page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName3");
			patientListPage.clickOnPatientNameFrmList("patientName3");
			transmissionPage.navigateToTransmissionTab();
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport, "TransmissionPage is displayed");
						
			extentReport.info("3000S Select Print and Print Transmission window will be open and click Print");
			transmissionPage.clickPrintButton();
			transmissionPage.switchToWindow("Print Transmission");
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyPrintTransmission(), extentReport, "All Transmissions Page is displayed");			
			transmissionPage.clickPrintBtnOnPrintTrans();
			
			//Pravin's Comments:[MNET1-4969] This test does not ask to do the actual print. But the print preview is supposed to be displayed in 3100V. So that can be verified. You dont need to verify the pdf contents. Verify that pdf is displayed in the pdf window.
			//Hence validating only that print report is displaying as per patient name
			extentReport.info("3100V Verify a window to start Transmission is appeared and click print .observe print is matching the Transmission.");
			transmissionPage.switchToWindow("Patient Records");
	//		transmissionPage.clickPrintBtnOnPatientRecords();
			transmissionPage.verifyPatientNameInPrintReport("patientName3");
			
			//More Action
			extentReport.info("3200S Select the any Patient with viewed transmission (unbold) and Click on More Actions. Click Mark as unviewed");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			//patientName3--> need the patient with viewed transmission
			recentTransmissionsPage.enterTier3FilterInputBx("patientName3");
			recentTransmissionsPage.slctVwdPatientChkBx("PateintName3", "0");
			extentReport.reportScreenShot("Checkbox is selected for viewed transmission (unbold)");
			recentTransmissionsPage.validateMoreActionBtn();
			recentTransmissionsPage.validateMrkAsUnvwdOption();
			
			extentReport.info("3300V Verify that the Transmission becomes unviewed (bold).");
			recentTransmissionsPage.verifyUnViewedPatientInTable("PateintName3", "0");
			extentReport.reportScreenShot("Transmission is Unviewed (bold).");
			
			extentReport.info("3400S Click on more Action. Click on Print");
			recentTransmissionsPage.validateMoreActionBtn();
			recentTransmissionsPage.clickOnMoreActionPrintBtn();
			
			extentReport.info("3500V Verify that all the patients details window is displayed and click print");
			recentTransmissionsPage.switchToWindow("Print");
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyPrintWindow(), extentReport, "Print window is displayed");			
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.validatePatientDetailsOnPrintReport(), extentReport, "Verified Patient details with count");
			recentTransmissionsPage.clickOnPrintBtnOnPrintWnndow();
			
			extentReport.info("3600V Verify that the Patient list is printed.");
			//Checking count of patient in above step as on this page not able to inspect object
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyPrintPdfWindow(), extentReport, "Print Pdf window is displayed");
			
		
		}
		
			catch (AssertionError e) {
			 extentReport.reportFail( "R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
			} 
			catch (Exception e) {
			 extentReport.reportFail( "R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_03 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
			}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}
