package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;


public class WA_IB001_RecentTransmission_RT_Cache_Direct_01 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	CA_RecentTransmissionsPage recentTrnsPg;
	PL_PatientProfilePage patientProfilePg;
	PL_TransmissionPage transmissionPg;
	PatientListPage patientListPg;
	PL_AllTransmissionsPage allTransmissionPg;
	
	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_ClinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		recentTrnsPg= new CA_RecentTransmissionsPage(driver, extentReport);
		patientProfilePg = new PL_PatientProfilePage(driver, extentReport);
		 transmissionPg = new PL_TransmissionPage(driver, extentReport);
		  patientListPg = new PatientListPage(driver, extentReport);
		   allTransmissionPg = new PL_AllTransmissionsPage(driver, extentReport);
		
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		commonUtils=new CommonUtils();
		
	}
	
	
	// Testcase id: 1238696, Testcase name: R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_Direct_01, Author- Dhaval
	
	@Test	
	public void WA_IB001_RecentTransmission_RT_Cache_Direct_01_TC() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("PH_CLINIC_D");
		extentTest.assignAuthor("Author: Dhaval Kothari");
		try {
			Assertions assertions=new Assertions(extentTest);
			
					
			extentTest= extentReport.info("100 S Login with Direct Clinic A and navigate to Recent Transmissions Page");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			  assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
				//recentTrnsPg.selectTireOneFilterOption("clinic patients");
				//recentTrnsPg.selectTireOTwoFilterOption("cardiac monitor");
				recentTrnsPg.enterTier3FilterInputBx("Jsontext");//3rd Patient
				String transmissionDatTime= recentTrnsPg.verifyFirstTranmissionDtTimeOnRT();
				
				recentTrnsPg.clickFirstTranmissionOnRT();
				
			  
			  extentReport.info("2400 V Verify its navigates to Transmission tab of Patient list",new String[] {"TransMgt4040","TransMgt4351","TransMgt4352","TransMgt4353","TransMgt4354"});
			  assertions.assertEqualsWithReporting(true,transmissionPg.verifyPLTranmissionTabIsSelected().contains("active"),extentReport, "Tranmission Tab under Patient List is displayed");
			  assertions.assertEqualsWithReporting(true,transmissionPg.verifyTransmissionDtTime().contains(transmissionDatTime),extentReport, "Tranmission Date Time  is displayed correctly");
			  assertions.assertEqualsWithReporting(true,transmissionPg.verifyPatientName().contains("Jsontext"),extentReport, "Patient Name  is displayed correctly");  
			  extentReport.reportScreenShot("User is able to successfully navigate to Transmission under Patient List page");
			  
			  
			  extentReport.info("2500 S Click on All Transmission tab");
			  patientListPg.clickAllTransmissionTab();
			  assertions.assertEqualsWithReporting(true,allTransmissionPg.verifyLandingPage(),extentReport, "All Tranmission Page is displayed");
			  
            extentReport.info("2600 V Verify all transmissions for particular patient are displayed.", new String[] {"TransMgt16380"});
            assertions.assertEqualsWithReporting(true,allTransmissionPg.verifyPatientName().contains("Jsontext"),extentReport, "Patient Name  is displayed correctly");
            
            dataBaseConnector.getConnection(); 
            String query = "SELECT count(*) as count FROM transmissions.rt_cache where transmission_id IN" +
            "(Select transmission_id FROM transmissions.transmission" +
          		   " Where patient_id= (SELECT patient_id FROM patients.patient where first_name = '"+"Jsontext"+"'))";
			  
			  
			  ResultSet transmissionCount = dataBaseConnector.executeQuery(query);
			 transmissionCount.next(); 
			 String count = transmissionCount.getString("count");
			 
			 assertions.assertEqualsWithReporting(allTransmissionPg.allTransmissionCount(),Integer.parseInt(count),extentReport, "Transmission Count Matching"); 
			
			 
			dataBaseConnector.getConnection(); 
            String query2 = "SELECT session_date_and_time  FROM transmissions.rt_cache where transmission_id IN" +
            "(Select transmission_id FROM transmissions.transmission" +
          		   " Where patient_id= (SELECT patient_id FROM patients.patient where first_name = '"+"Jsontext"+"')) order by session_date_and_time desc";
			  
			  
			  ResultSet transmissionDtTime = dataBaseConnector.executeQuery(query2);
			 ArrayList<String> transmissionDateTime= new ArrayList<String>() ;
			 while(transmissionDtTime.next())
					 {
			
			transmissionDateTime.add(transmissionDtTime.getString("session_date_and_time")) ;
					 }
			 
			 allTransmissionPg.populatedTransDateTimeValidations(transmissionDateTime);
			loginPage.login(login);
			
			assertions.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),extentReport, "Record Tranmission Page is displayed");
			
			
			extentReport.info("200 S Select any ICD patient with Transmissions, click on the patient.");
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.selectTireOTwoFilterOption("icd/pacemaker");
			
			extentReport.info("300 V Verify patient navigates to Patient profile page.");
			recentTrnsPg.enterTier3FilterInputBx("MODpatient");
			recentTrnsPg.navigateToPatientProfilePage("MODpatient");
			assertions.assertEqualsWithReporting(true,patientProfilePg.verifyLandingPage(),extentReport, "Patient Profile Page is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient Profile page");
			
			
			
			extentReport.info("400 S Click on Edit to change First name, Middle name, Last name, User ID and Location and click on save.");
			//Capturing original values before editing, in order to revert back to original value post validation
			String firstNameBeforeEdit = patientProfilePg.verifyFirstName();
			String middleNameBeforeEdit = patientProfilePg.verifyMiddleName();
		    String lastNameBeforeEdit = patientProfilePg.verifyLastName();
		    String patientIdBeforeEdit = patientProfilePg.verifyPatientId();
		    String locationBeforeEdit = patientProfilePg.verifyLocation();
		    
			patientProfilePg.clickEditButton();
			patientProfilePg.enterFirstNameInputBx("EditFirst");
			patientProfilePg.enterMiddleNameInputBx("EditMiddle");
			patientProfilePg.enterLastNameInputBx("EditLast");
			patientProfilePg.enterPatientIdInputBx("123456");
			patientProfilePg.selectLocationFromDropdownOption("Pune");
			patientProfilePg.clickSaveButton();
			
			extentReport.info("500 V Verify changes are reflected on Patient profile page, Recent transmission page and RT_Cache Database Table");
			softAssert.assertEquals(patientProfilePg.verifyFirstName(),"EditFirst");
			softAssert.assertEquals(patientProfilePg.verifyMiddleName(),"EditMiddle");
			softAssert.assertEquals(patientProfilePg.verifyLastName(),"EditLast");
			softAssert.assertEquals(patientProfilePg.verifyPatientId(),"123456");
			softAssert.assertEquals(patientProfilePg.verifyLocation(),"Pune");
			
			//reverting back to original values
			patientProfilePg.clickEditButton();
			patientProfilePg.enterFirstNameInputBx(firstNameBeforeEdit);
			patientProfilePg.enterMiddleNameInputBx(middleNameBeforeEdit);
			patientProfilePg.enterLastNameInputBx(lastNameBeforeEdit);
			patientProfilePg.enterPatientIdInputBx(patientIdBeforeEdit);
			patientProfilePg.selectLocationFromDropdownOption(locationBeforeEdit);
			patientProfilePg.clickSaveButton();
			
			
			/*
			 * //HF related steps extentReport.
			 * info("600 S Select patient enroll in both EP and HF with Transmissions, Navigate to HF."
			 * ); extentReport.
			 * info("700 S Click on Edit to change First name, Middle name, Last name, User ID and Location and click on save."
			 * ); extentReport.
			 * info("800 V Verify changes are reflected on Patient profile page of HF. ");
			 * extentReport.
			 * info("900 V Navigate to EP and Verify changes in Patient last name, first name and Middle name only are reflected on Patient profile page, Recent transmission page and RT_Cache Database Table."
			 * );
			 * 
			 */
			  		  
			  extentReport.info("1000 S Navigate to RT page, Select any ICM patient with transmission and click on the patient.");
			  clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			  assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
				recentTrnsPg.selectTireOneFilterOption("clinic patients");
				recentTrnsPg.selectTireOTwoFilterOption("cardiac monitor");
				recentTrnsPg.enterTier3FilterInputBx("Transcheck");
				String oldDeviceName = recentTrnsPg.verifyDeviceNameOnRT();
				recentTrnsPg.navigateToPatientProfilePage("Transcheck");
				assertions.assertEqualsWithReporting(true,patientProfilePg.verifyLandingPage(),extentReport, "Patient Profile Page is displayed");
			  
			  extentReport.info("1100 S On Patient profile page, click on edit and Select the another device from Device name dropdown(Those are support to Battery Advisory) and click on Save button.");
			  patientProfilePg.clickEditButton();
			  patientProfilePg.selectDeviceFromDropdownOption("");
			  patientProfilePg.clickSaveButton();
			  
			  extentReport.info("1200 S Select the Device change-out radio button from Device Change window and click on Continue button.");
			  patientProfilePg.selectRadioButtonDeviceChangePopup("Device Change-Out");
			  patientProfilePg.clickContinueButton();
			  
			  extentReport.info("1300 S Click on Save button.");
			  patientProfilePg.clickSaveButton();
			  
			  
			  extentReport.info("1400 V Verify device change is reflected on Patient profile page.");
			  softAssert.assertEquals(patientProfilePg.verifyDevice(),"new device");
			  
			  
			  extentReport.info("1500 V Verify transmissions for patient still available for previous device.");
			  clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			  assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
				recentTrnsPg.selectTireOneFilterOption("clinic patients");
				recentTrnsPg.selectTireOTwoFilterOption("cardiac monitor");
				recentTrnsPg.enterTier3FilterInputBx("Transcheck");
				softAssert.assertEquals(recentTrnsPg.verifyDeviceNameOnRT(),oldDeviceName);
				
				
			  
			  extentReport.info("1600 S Upload transmission for same patient with new device.");
			  //Issue with api for upload tranmission
              
			  extentReport.info("1700 V Verify transmission is uploaded on Transmission tab of Patient List page, All Transmission tab of Patient List page, Recent transmission page and RT_Cache Database Table with new device information.");
			  //As step 1600 is not done hence 1700 also pending
			  
			  extentReport.info("1800 S Navigate to RT page, Select another patient having at least one transmission and click on the patient.");
			  clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			  assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
				recentTrnsPg.selectTireOneFilterOption("clinic patients");
				recentTrnsPg.selectTireOTwoFilterOption("cardiac monitor");
				recentTrnsPg.enterTier3FilterInputBx("Transcheck");
				recentTrnsPg.navigateToPatientProfilePage("Transcheck");
				assertions.assertEqualsWithReporting(true,patientProfilePg.verifyLandingPage(),extentReport, "Patient Profile Page is displayed");
			  
			  
			  extentReport.info("1900 S On Patient profile page, click on edit and Select the another device from Device name dropdown(Those are support to Battery Advisory) and click on Save button.");
			  patientProfilePg.clickEditButton();
			  patientProfilePg.selectDeviceFromDropdownOption("");
			  patientProfilePg.clickSaveButton();
			  
			  extentReport.info("2000 S Try Selecting  the Data Correction radio button from Device Change window.");
			  patientProfilePg.selectRadioButtonDeviceChangePopup("Data Correction");
			  
			  
              extentReport.info("2100 V Verify that the radio button for Data Correction is enabled.", new String[] {"PatAcct9081"});
              assertions.assertEqualsWithReporting(true,patientProfilePg.verifyDeviceChangePopupRdBtn("Data Correction"),extentReport, "Data Correction is enabled");
              
			  extentReport.info("2200 S Click on Cancel Button.");
			  patientProfilePg.clickCancleButton();
			  
//			  extentReport.info("2300 S On RT page, under Transmission column, click on any patient’s Transmission.");
//			  clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
//			  assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
//				recentTrnsPg.selectTireOneFilterOption("clinic patients");
//				recentTrnsPg.selectTireOTwoFilterOption("cardiac monitor");
//				recentTrnsPg.enterTier3FilterInputBx("Pat_AllTrans_FN");//3rd Patient
//				String transmissionDatTime= recentTrnsPg.verifyFirstTranmissionDtTimeOnRT();
//				recentTrnsPg.clickFirstTranmissionOnRT();
//				
//			  
//			  extentReport.info("2400 V Verify its navigates to Transmission tab of Patient list",new String[] {"TransMgt4040","TransMgt4351","TransMgt4352","TransMgt4353","TransMgt4354"});
//			  assertions.assertEqualsWithReporting(true,transmissionPg.verifyPLTranmissionTabIsSelected().contains("active"),extentReport, "Tranmission Tab under Patient List is displayed");
//			  assertions.assertEqualsWithReporting(true,transmissionPg.verifyTransmissionDtTime().contains(transmissionDatTime),extentReport, "Tranmission Date Time  is displayed correctly");
//			  assertions.assertEqualsWithReporting(true,transmissionPg.verifyPatientName().contains("Pat_AllTrans_FN"),extentReport, "Patient Name  is displayed correctly");  
//			  extentReport.reportScreenShot("User is able to successfully navigate to Transmission under Patient List page");
//			  
//			  
//			  extentReport.info("2500 S Click on All Transmission tab");
//			  patientListPg.clickAllTransmissionTab();
//			  assertions.assertEqualsWithReporting(true,allTransmissionPg.verifyLandingPage(),extentReport, "All Tranmission Page is displayed");
//			  
//              extentReport.info("2600 V Verify all transmissions for particular patient are displayed.", new String[] {"TransMgt16380"});
//              assertions.assertEqualsWithReporting(true,allTransmissionPg.verifyPatientName().contains("Pat_AllTrans_FN"),extentReport, "Patient Name  is displayed correctly");
//              
//              dataBaseConnector.getConnection(); 
//              String query = "SELECT count(*) as count FROM transmissions.rt_cache where transmission_id IN" +
//              "(Select transmission_id FROM transmissions.transmission" +
//            		   " Where patient_id= (SELECT patient_id FROM patients.patient where first_name = '"+"Pat_AllTrans_FN"+"'))";
// 			  
// 			  
// 			  ResultSet transmissionCount = dataBaseConnector.executeQuery(query);
// 			 transmissionCount.next(); 
// 			 String count = transmissionCount.getString("count");
// 			 
// 			softAssert.assertEquals(allTransmissionPg.allTransmissionCount(),count);
// 			 
// 			 
// 			 
//              
//			  extentReport.info("2700 V Verify all details about transmission date, time are displayed on RT_Cache Database Table.", new String[] {"TransMgt16380"});
//			   
//			  dataBaseConnector.getConnection(); 
//              String query2 = "SELECT session_date_and_time  FROM transmissions.rt_cache where transmission_id IN" +
//              "(Select transmission_id FROM transmissions.transmission" +
//            		   " Where patient_id= (SELECT patient_id FROM patients.patient where first_name = '"+"Pat_AllTrans_FN"+"')) order by session_date_and_time desc";
// 			  
// 			  
// 			  ResultSet transmissionDtTime = dataBaseConnector.executeQuery(query2);
// 			 ArrayList<String> transmissionDateTime= new ArrayList<String>() ;
// 			 while(transmissionDtTime.next())
// 					 {
// 			
// 			transmissionDateTime.add(transmissionDtTime.getString("session_date_and_time")) ;
// 					 }
 			allTransmissionPg.populatedTransDateTimeValidations(transmissionDateTime);
 			
			softAssert.assertAll();
		}catch (AssertionError e) {
			 extentReport.reportFail( "WA_IB001_RecentTransmission_RT_Cache_Direct_01_TC is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "WA_IB001_RecentTransmission_RT_Cache_Direct_01_TC is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}


