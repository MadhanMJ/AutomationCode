package com.test.qa.ui.tests.IB001;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Shafiya Sunkesala
 * Date: 21/02/2022
 * Test Case: R9.7rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_2 
 * Test case Id: 1238702
 */

public class R9_7rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_2  extends CommonUtils {
	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	CA_ClinicUsers ca_ClinicUsers;
	
	LoginPageWithPOJO loginPage;
	Login login_Clinic_SP2;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeMethod(alwaysRun = true)
	public void initialize() {

		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
//		pl_TransmissionPage = new PL_TransmissionPage(driver, extentReport);
//		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
//		pl_TopNavPage = new PL_TopNavPage(driver, extentReport);
//		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver,extentReport);
		ca_ClinicLocationsPage = new CA_ClinicLocationsPage(driver,extentReport);
		ca_ClinicUsers = new CA_ClinicUsers(driver,extentReport);

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login_Clinic_SP2 = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test(groups= {"Regression"})
	public void TC_WA_80Rev3_PA210_AllTrans_01()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		login_Clinic_SP2 = testDataProvider.getLoginData("SJMClinicSP12387");

		extentTest.assignAuthor("Author: Shafiya Sunkesala");
		try {
			assertions = new Assertions(extentTest);
			extentReport.info("100 S Login to Clinic Sp2");
			loginPage.login(login_Clinic_SP2, "externaluser");
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			extentReport.reportScreenShot("Clinician Home Page is Displayed");
			
			extentReport.info("110V Verify that default Filters are Clinic Patients and All", new String[] {"TransMgt16395"});
			assertions.assertEquals(ca_RecentTransmissionsPage.verifyDefaultTier1FilterOptions_Sp2(), true, "Default Filters are 'Clinic Patients' and 'All' in Tier1 Filter");
			extentReport.reportScreenShot("Default Filters 'Clinic Patients' and 'All' are displayed in Recent Transmissions-> Tier1 Filter");
			//This is added to close the dropdown filter
			ca_RecentTransmissionsPage.sendspecialKeysOnPage("escape");
			
			extentReport.info("200S Navigate to the clinic admin Page-> clinic location");
			clinicianHomeTopNavPage.clickClinicAdministrationLink();
			assertions.assertEqualsWithReporting(true, clinicAdminLeftNavPage.verifyLandingPage(), extentReport, "Clinic Administration Page is Displayed.");
			extentReport.reportScreenShot("Navigation to Clinic Administration Page is successful");
			clinicAdminLeftNavPage.navigateToClinicLocationsPage();
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyLandingPage(), extentReport, "Navigated to clinic admin Page-> clinic location.");
			extentReport.reportScreenShot("Navigation to clinic admin Page-> clinic location is successful");
			
			extentReport.info("300S Click on add Location and Fill the required fields, click save button");
			ca_ClinicLocationsPage.clickAddLocationBtn();
			ca_ClinicLocationsPage.enterSecondayLocation("Hyderabad");
			ca_ClinicLocationsPage.clickSaveBtn();			
			
			extentReport.info("400S Navigate to the Clinic users and associate the recently added Location");
			clinicAdminLeftNavPage.clickClinicUserLink();
			assertions.assertEqualsWithReporting(true, ca_ClinicUsers.verifyLandingPage(), extentReport, "Navigated to Clinic Users page");
			ca_ClinicUsers.associateClinicLocation();
			
			extentReport.info("500V Verify that the added location is present in the clinic Location filter dropdown after the location is assigned to medical team member.");
			
			extentReport.info("600S Navigate to the Patient list Page, Select a patient with Transmission, Change the Location.");
			
			extentReport.info("700S Navigate to Recent Transmission Page ");
			
			extentReport.info("800V Verify that the location column displays new location.");
			
			extentReport.info("900S Select the tier 2 filter as clinic Location and search with the added clinic location.");
			
			extentReport.info("1000V Verify that the Clinic with searched location is visible.");
			
			extentReport.info("1100S Add the User in medical team(i.e physician)");
			
			extentReport.info("1200S Save and Logout from clinic and Login into the User/Physician");
			
			extentReport.info("1300V Verify that the Patient with the same user is present in the MY Patients filter");
			
			extentReport.info("1400S Login to the SP2 Clinic");
			
			extentReport.info("1500S Select the Patient with medical team member and remove medical team member.");
			
			extentReport.info("1600S Logout and Login to the SP2 user.");
			
			extentReport.info("1700V Verify that the Patient is not displayed in MY Clinic Filter.");
			
			
			
			
			
			
			
			
			assertions.assertAll();

		} catch (AssertionError e) {
			extentReport.reportFail( "R9.7rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_2 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "R9.7rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_2 is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
	appHomeTopNavPage.clickSignOutLink();
	saintResult(result, extentTest);

	}
}

