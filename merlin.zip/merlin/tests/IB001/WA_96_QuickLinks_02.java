package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ToolsPage;
import com.test.qa.utilities.CommonUtils;

public class WA_96_QuickLinks_02 extends CommonUtils {

	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	PatientListPage patientListPage;
	LoginPageWithPOJO loginPage;
	Login loginAlliedProffessional;
	Login loginPhysician;
	ExtentTest extentTest;
	String testName;
	TestDataProvider testDataProvider;
	Customer customer;
	ToolsPage toolsPage;
	
	@BeforeClass
	public void initialize() {
		//driver = CommonUtils.initializeDriver();
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		recentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		loginAlliedProffessional = new Login();
		loginPhysician = new Login();
		testDataProvider = new TestDataProvider();
		toolsPage = new ToolsPage(driver, extentReport);

	}
	// Testcase id: 1244360, Testcase name: WA_96_QuickLinks_02
	@Test
	public void TC_WA_96_QuickLinks_02() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		loginAlliedProffessional = testDataProvider.getLoginData("alliedProfessional_1234479");
		loginPhysician = testDataProvider.getLoginData("alliedProfessional_1234479"); 
		extentTest.assignAuthor("Author-Salin Gambhir");
		
		try {
			Assertions assertion =  new Assertions(extentTest);
			extentTest = extentReport.info( "100 S Login to an EP Clinic and navigate to Recent Transmissions page.");
			loginPage.login(loginAlliedProffessional);
			//clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, testName); 
		 
		    extentTest = extentReport.info("200 V Verify that disconnected transmitter link is displayed in the quick links window <Gen2359>");
		    assertion.assertEqualsWithReporting(true, recentTransmissionsPage.verifyDisconnectedTransmitterLink(), extentReport, testName);
		    
		    extentTest = extentReport.info( "300 S Click on the Disconnected transmitter link in the quick links.");
		    recentTransmissionsPage.goToDisconnectedTransmitterLink();
		    
		    extentTest = extentReport.info( "400 V Verify that actor is navigated to PA 001 Patient List page with the filter disconnected transmitter", new String[] {"Gen2359"});			
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Patient List page is present");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyDropdownFilter("Patients with Disconnected Transmitters"), extentReport, "Dropdown has Patients With Disconnected Transmitter shown");
			int countPatient = patientListPage.countPatientWithFilter();
			
			extentTest = extentReport.info("500 V Verify on navigation to disconnected transmitter page both active and released patients are displayed", new String[] {"Gen2359"});
			assertion.assertEqualsWithReporting(true,patientListPage.verifyDropdownFilter("Active Clinic Patients"), extentReport, "Dropdown has My Clinic Dropdown shown");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyDropdownFilter("Patients with Disconnected Transmitters"), extentReport, "Dropdown has Patients With Disconnected Transmitter shown");
			
			
			extentTest = extentReport.info("600 S Navigate back to Recent Transmissions page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			
			extentTest = extentReport.info("700 V Verify that count displayed in front of disconnected transmitter link is number of active and released patients with MIST and NODC condition" , new String[] {"Gen2360"});
			recentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			recentTransmissionsPage.selectTireOTwoFilterOption("all");
			assertion.assertEqualsWithReporting(true, recentTransmissionsPage.verifyDisconnectedTransmitterLinkCount(countPatient), extentReport, "Count displayed in front of Disconnected Transmitter wih MIST and NODC Conditions");
			
		    extentTest = extentReport.info("800 S Logout and login as a physician and navigate to Recent Transmissions page/");
		    clinicianHomeTopNavPage.clickSignOutLink();
		    loginPage.login(loginPhysician);
		    
		    
		    extentTest = extentReport.info("900 V Verify that count displayed in front of disconnected transmitter link is number of active and released 'my patients' with MIST and NODC condition", new String[] {"Gen2360"});
		    recentTransmissionsPage.goToDisconnectedTransmitterLink();
		    assertion.assertEqualsWithReporting(true,patientListPage.verifyDropdownFilter("My Active Patients"), extentReport, "Dropdown has My Active Patients shown");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyDropdownFilter("Patients with Disconnected Transmitters"), extentReport, "Dropdown has Patients With Disconnected Transmitter shown");
			countPatient = patientListPage.countPatientWithFilter();
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			
		    assertion.assertEqualsWithReporting(true, recentTransmissionsPage.verifyDisconnectedTransmitterLinkCount(countPatient), extentReport, "Count displayed in front of Disconnected Transmitter wih MIST and NODC Conditions");
			
		    extentTest = extentReport.reportInfo("1000 S Logout and login to EP clinic as an AP and navigate to Recent Transmissions page");
		    clinicianHomeTopNavPage.clickSignOutLink();
		    loginPage.login(loginAlliedProffessional);
		    recentTransmissionsPage.navigateToRecentTransmissionPage();
		    
		    
		    extentTest = extentReport.reportInfo("1100 S Click on messages link in quick links window.");
		    recentTransmissionsPage.goToMessageQuickLink();
		    
		    extentTest = extentReport.info("1200 V Verify if the user is navigated to the TO 040 Messages list page", new String[] {"<Gen2358>"});
		    assertion.assertTrue(toolsPage.verifyLandingPage());
		    assertion.assertEqualsWithReporting(true, toolsPage.verifyMessageLink(), extentReport, "Message List Page");
		    
		    extentTest = extentReport.info("1300 V Verify messages page includes following active Clinic level message and Patient specific messages:", new String[] {"<Auto5050>"});
		    toolsPage.clickOnVariousMessages("Clinic-Related Messages");
		    assertion.assertEqualsWithReporting(true, toolsPage.verifyMessages("Clinic-Related Messages"), extentReport, "Clinic-Related Messages");
		    toolsPage.clickOnVariousMessages("Patient-Related Messages");
		    assertion.assertEqualsWithReporting(true, toolsPage.verifyMessages("Patient-Related Messages"), extentReport, "Clinic-Related Messages");
		 
			assertion.assertAll();
		}catch (AssertionError e) {
				
				extentReport.reportFail("WA_96_QuickLinks_02 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
				
				
				throw e;
			}
		 catch (Exception e) {
			extentReport.reportFail( "WA_96_QuickLinks_02 Validation not successful",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}

}
