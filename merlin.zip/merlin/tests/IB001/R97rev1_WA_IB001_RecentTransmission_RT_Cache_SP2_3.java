package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_3 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils;
	DriverUtils driverUtils;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;

	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		commonUtils = new CommonUtils();
		ca_RecentTransmissionsPage= new CA_RecentTransmissionsPage(driver, extentReport);
	}

	// Testcase id: 1238703, Testcase name:
	// R9.7rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_3, Author- Shanmugapriya

	@Test
	public void WA_IB001_RecentTransmission_RT_Cache_SP2_3() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);

		login = testDataProvider.getLoginData("Priyam");
		extentTest.assignAuthor("Author - Shanmugapriya");
		try {
			
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100S Login to the SP2 clinic having Transmissions.");
			loginPage.login(login);
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
			
			extentReport.info("300S Select Cardiac Monitor filter in tier2.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("cardiac monitor");
			extentReport.reportScreenShot("Selected Cardiac Monitor in Tier 2");
			
			extentReport.info("400V Verify that only patients having Cardiac Monitor Device are displayed.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientHavingICM("ICM"), extentReport, "Patients having ICM device");
			extentReport.reportScreenShot("Patients having Cardiac monitor device");
			
			extentReport.info("500S Select ICD/Pacemaker filter from tier2 filter.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("icd/pacemaker");
			extentReport.reportScreenShot("Selected ICD/Pacemaker in Tier 2");
			
			extentReport.info("600V Verify that only patients having ICD/Pacemaker Device are displayed");
//			ca_RecentTransmissionsPage.verifyPatientsHavingICDPaceMaker("ICM");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientsHavingICDPaceMaker("ICM"), extentReport, "Patients having ICD/Pacemaker device");
			extentReport.reportScreenShot("Patients having ICD/Pacemaker device");
			
			extentReport.info("700S Select Transmission with alerts filter in tier2.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("transmissions with alerts");
			extentReport.reportScreenShot("Selected transmissions with alerts in Tier 2");
			
			extentReport.info("800V Verify that only Patients having Transmission with alerts is displayed");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientsHavingAlerts(), extentReport, "Patients having alerts");
			extentReport.reportScreenShot("Patients having Transmission with alerts");
			
			extentReport.info("900S Select the Patient filter and type a name in search box.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("patient");
			ca_RecentTransmissionsPage.enterInputInSearchBox("0727");//need to change patient name
			extentReport.reportScreenShot("Selected patients with alerts in Tier 2 and typed a name in search box");
			
			extentReport.info("1000V Verify that only Patients with the name searched are displayed.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientsName("0727"), extentReport, "Only Patients with the name searched are displayed");
			extentReport.reportScreenShot("Patients having with the name searched are displayed");
			
			extentReport.info("1100S Navigate to any of the Primary Tabs(Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();			
			extentReport.reportScreenShot("User is able to Navigate to primary tab");
			
			extentReport.info("1200S Navigate back to the Recent Transmission Page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			extentReport.reportScreenShot("User is again able to navigate Recent Transmission tab");
			
			extentReport.info("1300V Verify that Search box displays the previous searched word and same Patients are displayed in the list.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyTextInSearchBox("0727"), extentReport, "Search box displays previous searched word");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientsName("0727"), extentReport, "Only Patients with the name searched are displayed");
			extentReport.reportScreenShot("Search box displayed previous searched word and same Patients are displayed in the list");
			
			extentReport.info("1400S Select the Physician name/ID filter and type a name or ID in search box.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("physician name/id");
			ca_RecentTransmissionsPage.enterInputInSearchBox("icm115_allied");
			
			extentReport.info("1500V Verify that only Patients having Physician name/ID searched are displayed.");
//			need to change
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientsNameOrID("0727"), extentReport, "Only Patients with the name searched are displayed");
			extentReport.reportScreenShot("Patients having with the name searched are displayed");
			
			
			extentReport.info("1600S Navigate to any of the Primary Tabs(Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();			
			extentReport.reportScreenShot("User is able to Navigate to primary tab");
			
			extentReport.info("1700S Navigate back to the Recent Transmission Page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			extentReport.reportScreenShot("User is again able to navigate Recent Transmission tab");
			
			//need to check
			extentReport.info("1800V Verify that Search box displays the previous searched word and same Patients are displayed in the list.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyTextInSearchBox("icm115_allied"), extentReport, "Search box displays previous searched word");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyPatientsName("0727"), extentReport, "Only Patients with the name searched are displayed");
			extentReport.reportScreenShot("Search box displayed previous searched word and same Patients are displayed in the list");
			
			extentReport.info("1900S Select the Device filter and type a Device in search box.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("device");
			ca_RecentTransmissionsPage.enterInputInSearchBox("3500");
			extentReport.reportScreenShot("Selected device in Tier 2 and typed a device name in search box");
			
			extentReport.info("2000V Verify that only Patients matching the device number or the device name searched are displayed.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyDeviceName("DM3500"), extentReport, "Only Patients matching the device number searched are displayed");
			extentReport.reportScreenShot("Patients having with the device name searched are displayed");
			
			extentReport.info("2100S Navigate to any of the Primary Tabs(Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();			
			extentReport.reportScreenShot("User is able to Navigate to primary tab");
			
			extentReport.info("2200S Navigate back to the Recent Transmission Page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			extentReport.reportScreenShot("User is again able to navigate Recent Transmission tab");
			
			extentReport.info("2300V Verify that Search box displays the previous searched word and same Patients are displayed in the list.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyTextInSearchBox("DM3500"), extentReport, "Search box displays previous searched word");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyDeviceName("3500"), extentReport, "Only Patients with the device searched are displayed");
			extentReport.reportScreenShot("Search box displayed previous searched word and same Patients with device are displayed in the list");
			
			extentReport.info("2400S Select the Device type in teir2  filter and select a device type in search box.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("device type");
			ca_RecentTransmissionsPage.selectDropdownForDeviceType("Cardiac Monitor(ICM)");
			extentReport.reportScreenShot("Selected device type in Tier 2 and selected type in search box");
			
			//need to check
			extentReport.info("2500V Verify that only Patients matching the device type are displayed.");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyDeviceType("ICM"), extentReport, "Only Patients matching the device type searched are displayed");
			extentReport.reportScreenShot("Patients having with the device type searched are displayed");
			
			
			extentReport.info("2600S Navigate to any of the Primary Tabs(Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();			
			extentReport.reportScreenShot("User is able to Navigate to primary tab");
			
			extentReport.info("2700S Navigate back to the Recent Transmission Page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			extentReport.reportScreenShot("User is again able to navigate Recent Transmission tab");
			
			extentReport.info("2800V Verify that Search box displays the previous searched word and same Patients are displayed in the list.");
			//need to check
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyTextInDeviceTypeFilter("Cardiac Monitor(ICM)"), extentReport, "Search box displays previous searched word");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyDeviceType("ICM"), extentReport, "Only Patients with the device type searched are displayed");
			extentReport.reportScreenShot("Search box displayed previous searched word and same Patients with device type are displayed in the list");
			
			
			extentReport.info("2900S Select the Patient’s clinic location in teir2  filter and select a location in search box.");
			ca_RecentTransmissionsPage.selectTireOTwoFilterOption("patient’s clinic location");
			ca_RecentTransmissionsPage.selectLocationInLocationFilter();
			extentReport.reportScreenShot("Selected device in Tier 2 and typed a device name in search box");
			
			extentReport.info("3000V Verify that only Patients in that location are displayed.");
			String locationValue = ca_RecentTransmissionsPage.locationValue();
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLocation(locationValue), extentReport, "Only Patients matching the location searched are displayed");
			extentReport.reportScreenShot("Patients having with the location searched are displayed");
			
			extentReport.info("3100S Navigate to any of the Primary Tabs(Patient List, tools, Clinic administration)");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();			
			extentReport.reportScreenShot("User is able to Navigate to primary tab");
			
			extentReport.info("3200S Navigate back to the Recent Transmission Page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			extentReport.reportScreenShot("User is again able to navigate Recent Transmission tab");
			
			extentReport.info("3300V Verify that Search box displays the previous searched word and same Patients are displayed in the list");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyTextInLocationFilter(locationValue), extentReport, "Search box displays previous searched word");
			assertions.assertEqualsWithReporting(true, ca_RecentTransmissionsPage.verifyLocation(locationValue), extentReport, "Only Patients matching the location searched are displayed");
			extentReport.reportScreenShot("Search box displayed previous searched word and same Patients with locations are displayed in the list");			
			

		} catch (AssertionError e) {
			extentReport.reportFail("WA_IB001_RecentTransmission_RT_Cache_SP2_3 is failed due to assertion failure",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("WA_IB001_RecentTransmission_RT_Cache_SP2_3 is failed due to some exception",
					CommonUtils.convertStackTraceToString(e));
			throw e;
		}

	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}

		writeInTextFile(testMethodName, status);
	}
}
