package com.test.qa.ui.tests.IB001;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_SchedulingAndMessagingPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_4 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	Login login;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	PL_AllTransmissionsPage allTransmissionsPage;
	PL_TransmissionPage transmissionPage;
	@BeforeClass
	public void initialize() {

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		testDataProvider = new TestDataProvider();
		recentTransmissionsPage =  new CA_RecentTransmissionsPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		allTransmissionsPage = new PL_AllTransmissionsPage(driver, extentReport);
		transmissionPage = new PL_TransmissionPage(driver, extentReport);
	}
	@Test
	public void RecentTransmission_RT_Cache_SP2_4() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Victor");// comments
		try {
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100s Login into Sp2 Clinic");
			loginPage.login(login);
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");

			extentReport.info("200S Check the checkbox of any Patient with unviewed  transmission and Click archive");
			recentTransmissionsPage.verifyUnViewedPatientInTable("patientName", "index");
			recentTransmissionsPage.slctUnvwdPatientChkBx("patientName", "index");
			extentReport.reportScreenShot("Checkbox is selected for unviewed transmission");
			recentTransmissionsPage.validateArchiveBtn();
			
			extentReport.info("300V Verify that a Dialog box with a message ‘1 Transmission have not yet been viewed . Would like to archive the selected transmission?’");
			String archiveMsgExpt = "1 transmissions have not yet been viewed. Would you like to archive the selected transmissions?";
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyArchivePopupMsgUnviewdTrans().equalsIgnoreCase(archiveMsgExpt), extentReport, "Validated dialog box with message '"+ archiveMsgExpt +"'");
			extentReport.reportScreenShot("Validated dialog box with message '"+ archiveMsgExpt +"'");
			
			
			extentReport.info("400S Click on OK");
			recentTransmissionsPage.ClickOnArchivePopupOKBtn();
			
			extentReport.info("500V Verify that the transmission is not displayed in the Recent Transmission Page now.");
			recentTransmissionsPage.validateArchivedTransNotPresent("patientName", "index");
			
			extentReport.info("600S Navigate to PatientList Pag-> Select the patient whose transmission have been archived"
					+ "Navigate to All Transmissions.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName");
			patientListPage.clickonAllTransmissionFrmList("patientName");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			
			
			extentReport.info("700V Verify that the Transmission is marked as archived under Status column.");
			extentReport.reportScreenShot("All Transmissions are present");
			allTransmissionsPage.verifyAtchivedStatusForUnviwdTrans();
			
			
			extentReport.info("800S Unarchive the Transmission.");
			
			
			extentReport.info("900V Verify that the transmission is unarchived all transmission page nothing is displayed under status.");
			
			extentReport.info("1000S Navigate to Patient List, select a patient having Transmission and move to Transmission Page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			//patientName2--> need the patient having transmissions from db
			patientListPage.enterTier3FilterInputBx("patientName2");
			//need to add validation point to chk if searched patient having transmission
			patientListPage.clickOnPatientNameFrmList("patientName2");
			transmissionPage.navigateToTransmissionTab();
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport, "TransmissionPage is displayed");
			
			
			extentReport.info("1100S Select archive option  and navigate to the Recent Transmission Page.");
			extentReport.pass("'" + transmissionPage.verifyArchiveMsg() + "' message is displayed");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTransmissionsPage.verifyLandingPage(),extentReport, "Recent Tranmission Page is displayed");
			
			
			
			extentReport.info("1200V Verify that the transmission is not displayed in the Recent Transmission Page now.");
			recentTransmissionsPage.validateArchivedTransNotPresent("patientName2", "index");
			
			extentReport.info("1300S Navigate to PatientList Pag-> Select the patient whose transmission have been archived"
					+ "Navigate to All Transmissions.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName2");
			patientListPage.clickonAllTransmissionFrmList("patientName2");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			
			
			extentReport.info("1400V Verify that the Transmission is marked as archived under Status column.");
			extentReport.reportScreenShot("All Transmissions are present");
			allTransmissionsPage.verifyAtchivedStatusOfTrans();
			
			extentReport.info("1500S Unarchive the Transmission from DB.");
			
			
			
			extentReport.info("1600V Verify that the transmission is unarchived all transmission page nothing is displayed under status.");
			extentReport.reportScreenShot("All Transmissions are present");
			

			extentReport.info("1700S Navigate to Patient List, select a patient having Transmission and move to All Transmission Page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			//patientName2--> need the patient having transmissions from db
			patientListPage.enterTier3FilterInputBx("patientName2");
			//need to add validation point to chk if searched patient having transmission
			patientListPage.clickOnPatientNameFrmList("patientName2");
			transmissionPage.navigateToTransmissionTab();
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport, "TransmissionPage is displayed");
			
			extentReport.info("1800S Select a Transmission by checking the checkbox and archive option  and navigate to the Recent Transmission Page.");
			extentReport.pass("'" + transmissionPage.verifyArchiveMsg() + "' message is displayed");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTransmissionsPage.verifyLandingPage(),extentReport, "Recent Tranmission Page is displayed");
			
			
			
			extentReport.info("1900V Verify that the transmission is not displayed in the Recent Transmission Page now.");
			recentTransmissionsPage.validateArchivedTransNotPresent("patientName2", "index");
			
			
			extentReport.info("2000S Navigate to PatientList Pag-> Select the patient whose transmission have been archived"
					+ "Navigate to All Transmissions");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName2");
			patientListPage.clickonAllTransmissionFrmList("patientName2");
			assertions.assertEqualsWithReporting(true, allTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is displayed");
			

			extentReport.info("2100V Verify that the Transmission is marked as archived under Status column.");
			extentReport.reportScreenShot("All Transmissions are present");
			allTransmissionsPage.verifyAtchivedStatusOfTrans();
			
			
			extentReport.info("2200S Unarchive the Transmission from DB.");

			extentReport.info("2300V Verify that the transmission is unarchived all transmission page nothing is displayed under status"
					+ "Print");
			extentReport.reportScreenShot("All Transmissions are present");
			

			extentReport.info("2400S Navigate to Recent Transmission page select one patient having transmission by checking the checkbox.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			//patientName3--> need the patient having transmissions from db
			recentTransmissionsPage.enterTier3FilterInputBx("patientName3");
			recentTransmissionsPage.slctVwdPatientChkBx("PateintName3", "0");
			extentReport.reportScreenShot("Checkbox is selected");
			
			extentReport.info("2500S Click Print");
			recentTransmissionsPage.clickOnPrintButton();

			extentReport.info("2600V verify that the print Transmission window is open ");
			recentTransmissionsPage.switchToWindow("Print Transmission");
			assertions.assertEqualsWithReporting(true, recentTransmissionsPage.verifyPrintTransmission(), extentReport, "All Transmissions Page is displayed");			
			
			extentReport.info("2700S select any check box and click print");
			recentTransmissionsPage.allPrintSummaryCheckboxStatus("UncheckAll");
			recentTransmissionsPage.allPrintSummaryCheckboxStatus("VTVFEpisode");
			recentTransmissionsPage.clickPrintButton();
			
			extentReport.info("2800V Verify that Print of the transmission is done properly");
			recentTransmissionsPage.switchToWindow("Patient Records");
			recentTransmissionsPage.verifyPatientNameInPrintReport("patientName3");

			extentReport.info("2900S close the window and Navigate to the Patient list page and select a patient with Transmission, Navigate to Transmission Page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName3");
			patientListPage.clickOnPatientNameFrmList("patientName3");
			transmissionPage.navigateToTransmissionTab();
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport, "TransmissionPage is displayed");
					
			 

			extentReport.info("3000S Select Print and Print Transmission window will be open and click Print");
			transmissionPage.clickPrintButton();
			transmissionPage.switchToWindow("Print Transmission");
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyPrintTransmission(), extentReport, "All Transmissions Page is displayed");			
			transmissionPage.clickPrintBtnOnPrintTrans();
			
			//Pravin's Comments:[MNET1-4969] This test does not ask to do the actual print. But the print preview is supposed to be displayed in 3100V. So that can be verified. You dont need to verify the pdf contents. Verify that pdf is displayed in the pdf window.
			//Hence validating only that print report is displaying as per patient name
			extentReport.info("3100V Verify a window to start Transmission is appeared and click print .observe print is matching the Transmission.");
			transmissionPage.switchToWindow("Patient Records");
			//		transmissionPage.clickPrintBtnOnPatientRecords();
					transmissionPage.verifyPatientNameInPrintReport("patientName3");
					
					
					
			extentReport.info("3200S close the window and Navigate to the Patient list page and select a patient with Transmission, Navigate to All Transmission Page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "PatientListPage is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient List page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.enterTier3FilterInputBx("patientName3");
			patientListPage.clickOnPatientNameFrmList("patientName3");
			transmissionPage.navigateToTransmissionTab();
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport, "TransmissionPage is displayed");
				
			
			extentReport.info("3300S Select a transmission and check ckeckbox, Select Print and Print Transmission window will be open and click Print");
			transmissionPage.clickPrintButton();
			transmissionPage.switchToWindow("Print Transmission");
			assertions.assertEqualsWithReporting(true, transmissionPage.verifyPrintTransmission(), extentReport, "All Transmissions Page is displayed");			
			transmissionPage.clickPrintBtnOnPrintTrans();
			extentReport.info("3400V Verify a window to start Transmission is appeared and click print .observe print is matching the Transmission.");
			transmissionPage.switchToWindow("Patient Records");
			//		transmissionPage.clickPrintBtnOnPatientRecords();
					transmissionPage.verifyPatientNameInPrintReport("patientName3");
			
			
			
		} catch (AssertionError e) {
			extentReport.reportFail("R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_4 Validation not  successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("R97rev1_WA_IB001_RecentTransmission_RT_Cache_SP2_4 Validation not  successfull");
			throw e;
		}
	}
		}


