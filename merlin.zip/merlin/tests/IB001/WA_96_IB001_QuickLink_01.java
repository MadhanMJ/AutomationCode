package com.test.qa.ui.tests.IB001;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_PatientDeviceData;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Gowshalya
 * Test Case: WA_96_IB001_QuickLink_01
 */

public class WA_96_IB001_QuickLink_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	CustomerListPage customerListPage;
	PL_PatientEnrollment patientEnrollment;
	PL_PatientEnrollment_PatientDeviceData patientDeviceDataPage;
	PL_PatientProfilePage patientProfilePage;
	Assertions softAssert;
	ExtentTest extentTest;
	Login login_ClinicA, login_ClinicB, physician_LimitedAccess, ap_PatientDataRights;
	Customer customer;
	Patient patient;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	private Log logger = new Log();
	List<String> trnsfdPatientList = new ArrayList<String>();
	List<String> patientList = new ArrayList<String>();
	List<String> releasePatientList = new ArrayList<String>();
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		recentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		customerListPage = new CustomerListPage(driver,extentReport);
		patientEnrollment = new PL_PatientEnrollment(driver,extentReport);
		patientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		login_ClinicA = new Login();
		login_ClinicB = new Login();
		physician_LimitedAccess = new Login();
		ap_PatientDataRights = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		patient = new Patient();
		patientDeviceDataPage = new PL_PatientEnrollment_PatientDeviceData(driver, extentReport);
	}
	
	@Test
	public void wa_96_IB001_QuickLink_01() throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		//Direct
		//physician without admin rights - physician_noadmin, Bhuvanadevi$92
		//t4 - physican_noadmin - bHuvanadevi$92
		
		//SP2
		//physician_noadmin1 - bHuvanadevi$92  --> without admin rights
		
		//Sp2 
		//lakshmisp2ap1/ Veda!1624 - patient data rights enabled AP and no admin right
		
		
		extentTest = extentReport.initiateTest(testName);
		
		login_ClinicA = testDataProvider.getLoginData("Regular_ClinicA");
		login_ClinicB = testDataProvider.getLoginData("Regular_ClinicB");
		physician_LimitedAccess = testDataProvider.getLoginData("Physician_LimitedAccess");
		ap_PatientDataRights = testDataProvider.getLoginData("AP_PatientDataRights");
		customer = testDataProvider.getCustomerData("WA_96_IB001_QuickLink_01");
		patient = testDataProvider.getPatientData("WA_96_IB001_QuickLink_01");
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		List<String> list_icm = new ArrayList<String>();
        list_icm.add(patient.getDevice());
		try {
			softAssert = new Assertions(extentTest);
			
			extentReport.info("100 S Login to Regular Clinic A and select ‘Enroll a new Patient’ on Recent Transmission page");
			loginPage.login(login_ClinicA,"externaluser");
			//once bug is resolved, uncomment it
			recentTransmissionsPage.clickEnrollANewPatientButton();
			//clinicianHomeTopNavPage.clickPatientListLink();
			//patientListPage.clickEnrollAPatientButton();
			
			extentReport.info("200 S Enroll ICM or ICD patient ABC and release the patient with reason as ‘Transfer to another clinic’ & associated referring regular clinic B");
			patientEnrollment.clickManualEnrollButton();
			patientDeviceDataPage.enrollNewPatientManually("ICM",list_icm, patient);
			patientDeviceDataPage.clickOnSaveAndCloseButton();
			
			//Patient enrollment Need to check with Manual team and update.
			clinicianHomeTopNavPage.clickPatientListLink();
			patientListPage.selectTierTwoFilterOption("All");
			
			//give patinet name
			patientListPage.searchPatients(patient.getFirstName()+" "+patient.getFirstName());
			patientListPage.clickOnPatientName();
			softAssert.assertEqualsWithReporting(true, patientProfilePage.verifyLandingPage(), extentReport, "Patient Profile Page is Displayed");
			String merlinNetNumber = patientDeviceDataPage.getMerlinNetNumber();
			clinicianHomeTopNavPage.clickPatientListLink();
			patientListPage.clickOnPatientCheckBox(patient.getFirstName());
			patientListPage.clickMoreActionsButton();
			patientListPage.clickReleasePatientLink();
			
			//ReasonforRelease needs to be shared from excel
			
			patientListPage.selectValueInReasonForReleaseDropDown(patient.getReleaseReason());
			//clinic name needs to be provided from excel
			patientListPage.selectClinicName(patient.getAssociatedClinic());
			patientListPage.clickReleaseButton();

			extentReport.info("300 S Logout from Clinic A. Login to Clinic B and navigate to Recent Transmission page");
			customerListPage.verifyLogout();
			loginPage.login(login_ClinicB, "externaluser");
			softAssert.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmission page is displayed");
			
			extentReport.info("400 V Verify the number of patients listed in Patient Finder page under 'Enroll Transferred Patients' section & total number of count of 'Enroll Transferred Patients' quick link is correct", new String[] {"Gen2346"});
			softAssert.assertEquals(recentTransmissionsPage.getEnrollTransferredPatientCount(), "1", "Enroll Transferred Patients count is verified");
			extentReport.reportScreenShot("Number of patients available under Enroll Transferred Patients");
			
			extentReport.info("500 S Click on 'Enroll Transferred Patients' from Quick Link section");
			extentReport.reportScreenShot("Click on 'Enroll Transferred Patients' from Quick Link section");
			recentTransmissionsPage.clickOnEnrollTransferredPatient();
			
			extentReport.info("600 V Verify page is navigated to Patient Finder Page & enroll Transferred Patient List is displayed with all the patients which are pushed into current clinic", new String[] {"Gen2345"});
			softAssert.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Patient List page is displayed");
			trnsfdPatientList=patientListPage.getEnrollTransferredPatientList();
			//Released patinet name we need to pass here
			softAssert.assertTrue(trnsfdPatientList.contains(patient.getFirstName()),"Patient List is displayed with all the patients which are pushed into current clinic");
			
			//Need clarification on the below step and needs to implement
			extentReport.info("700 S Enter the details of patient BBB(ICM or ICD) to enroll which is enrolled in Clinic A (Merlin.Net number of active patient). Request for Transfer of the same patient by clicking on Request Transfer button on yellow banner");
			patientEnrollment.enrollPatientByMerlinNetNumber(merlinNetNumber);
			patientEnrollment.sendspecialKeysOnPage("Enter");
			// few steps are pending
			
			extentReport.info("800 S Logout from Clinic B & login with Clinic A");
			customerListPage.verifyLogout();
			loginPage.login(login_ClinicA,"externaluser");
			
			extentReport.info("900 S Navigate to Recent Transmission page and note down the count displayed for ‘Release Requests sent by another clinic’ option under Quick Link section");
			String releaseRequestSentByAnotherClinicCount = recentTransmissionsPage.getReleaseRequestSentByAnotherClinicCount();
			extentReport.reportScreenShot("Release Requests sent by another clinic");
			
			extentReport.info("1000 S Select 'Clinic Patients' option from Tier 1 filter. Click on ‘Release Requests sent by another clinic’ link from Quick link section");
			recentTransmissionsPage.selectTireOneFilterOption("Clinic Patients");
			extentReport.reportScreenShot("Selected 'Clinic Patients' option");
			recentTransmissionsPage.clickOnReleaseRequestSentByAnotherClinic();
			extentReport.reportScreenShot("Clicked on ‘Release Requests sent by another clinic’ link");
			
			extentReport.info("1100 V Verify the patient list page is displayed with list of patients pending for Release", new String[] {"Gen2347"});
			patientList = patientListPage.getPatientList();
			extentReport.reportScreenShot("Patient List is displayed with list of patients pending for Release");
			//Released patinet name we need to pass here
			softAssert.assertTrue(patientList.contains(patient.getFirstName()+" "+patient.getFirstName()),"Patient List is displayed with list of patients pending for Release");
			
			extentReport.info("1200 V Verify the number of patient listed on patient list page & total number of count of ‘Release Requests sent by another clinic’ quick link is same", new String[] {"Gen2348"});
			softAssert.assertEquals(patientList.size(), Integer.parseInt(releaseRequestSentByAnotherClinicCount),"Patient listed on patient list page & total number of count of ‘Release Requests sent by another clinic’ quick link is verified");
			
			extentReport.info("1300 V Verify the filter Tier 1 is selected as 'Active Clinic Patients' & Tier 2 filter as 'Release Request sent by another clinic'", new String[] {"Gen2347"});
			extentReport.reportScreenShot("Verifying Tier 1 & Tier 2 filter in Patient List Page");
			softAssert.assertEquals(patientListPage.verifyDropdownFilter("Active Clinic Patients"), true, "Tier 1 filter is selected as 'Active Clinic Patients");
			softAssert.assertEquals(patientListPage.verifyDropdownFilter("Release Requests from another clinic"), true, "Tier 2 filter is selected as 'Release Request sent by another clinic");
			
			extentReport.info("1400 S Navigate to Recent Transmission page, select Tier 1 filter as 'My Patients' & click on 'Release Requests from another clinic' quick link");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			recentTransmissionsPage.selectTireOneFilterOption("My Patients");
			extentReport.reportScreenShot("Selected 'My Patients' option");
			String releaseRequestSentByAnotherClinicCount2 = recentTransmissionsPage.getReleaseRequestSentByAnotherClinicCount();
			recentTransmissionsPage.clickOnReleaseRequestSentByAnotherClinic();
			extentReport.reportScreenShot("Clicked on ‘Release Requests sent by another clinic’ link");
			
			extentReport.info("1500 V Verify patient list page is displayed with Tier 1 filter set as 'My Active Patients' & Tier 2 filter as 'Release Requests from another clinic'", new String[] {"Gen2252"});
			extentReport.reportScreenShot("Verifying Tier 1 & Tier 2 filter in Patient List Page");
			softAssert.assertEquals(patientListPage.verifyDropdownFilter("My Active Patients"), true, "Tier 1 filter is selected as 'My Active Patients'");
			softAssert.assertEquals(patientListPage.verifyDropdownFilter("Release Requests from another clinic"), true, "Tier 2 filter is selected as 'Release Requests from another clinic'");
			
			extentReport.info("1600 V Verify the number of patients listed on patient list page & the count displayed for ‘Released Request from another clinic’ link on Recent Transmission page are same",new String[] {"Gen2252"});
			releasePatientList = patientListPage.getPatientList();
			extentReport.reportScreenShot("Patient List is displayed with list of patients pending for Release");
			softAssert.assertEquals(patientList.size(), Integer.parseInt(releaseRequestSentByAnotherClinicCount2),"Patients listed on patient list page & the count displayed for ‘Released Request from another clinic’ link on Recent Transmission page is verified");
			customerListPage.verifyLogout();
			
			extentReport.info("1700 S Login to Regular SP2 Clinic (Physician user with limited access), navigate to recent transmission page");
			loginPage.login(physician_LimitedAccess, "externaluser");
			
			extentReport.info("1800 V Verify Enroll Transferred Patients link is not displayed & ‘Release Requests sent by another clinic’ link is displayed in Quick link section for SP2 Physician user(Derived Test)", new String[] {"Gen2345","Gen2348"});
			extentReport.reportScreenShot("Verification of Enroll Transferred Patients link is not displayed and ‘Release Requests sent by another clinic’ link is displayed");
			softAssert.assertTrue(recentTransmissionsPage.isElementNotPresentWithoutexception(recentTransmissionsPage.enrollTranferredPatientLink_OR, recentTransmissionsPage.enrollTranferredPatientLink_S),"Verification of unavailability of Enroll Transferred Patients link");
			softAssert.assertTrue(recentTransmissionsPage.isElementPresentwithoutException(recentTransmissionsPage.releaseRequestSentAnotherClinicLink_OR, recentTransmissionsPage.releaseRequestSentAnotherClinicLink_S),"Verification of availability of Release Requests sent by another clinic link");
			customerListPage.verifyLogout();
			
			extentReport.info("1900 S Login to Regular SP2 Clinic as a AP user(with patient data entry rights), navigate to recent transmission page");
			loginPage.login(ap_PatientDataRights, "externaluser");
			
			extentReport.info("2000 V Verify Enroll Transferred Patients link is displayed in Quick link section", new String[] {"Gen2345"});
			extentReport.reportScreenShot("Verification of Enroll Transferred Patients link is displayed");
			softAssert.assertTrue(recentTransmissionsPage.isElementPresentwithoutException(recentTransmissionsPage.enrollTranferredPatientLink_OR, recentTransmissionsPage.enrollTranferredPatientLink_S),"Verification of availability of Enroll Transferred Patients link");
			
			extentReport.info("2100 S Logout from Clinic C & login with Clinic A");
			customerListPage.verifyLogout();
			loginPage.login(login_ClinicA, "externaluser");
			
			extentReport.info("2200 S The actor logs in to an EP clinic and navigates to Recent Transmissions page");
			softAssert.assertEqualsWithReporting(true, recentTransmissionsPage.verifyLandingPage(), extentReport, "Recent Transmissions page is displayed");
			
			extentReport.info("2300 V Verify that the column 'Advisory' is displayed on the recent transmissions page", new String[] {"TransMgt17756"});
			extentReport.reportScreenShot("Verification of 'Advisory' column on the recent transmissions page");
			softAssert.assertEquals(recentTransmissionsPage.isElementPresentwithoutException(recentTransmissionsPage.advisoryTablecolumn_OR, recentTransmissionsPage.advisoryTablecolumn_S), "'Advisory' column is displayed on the recent transmissions page");
			
			extentReport.info("2400 V Verify for patient A, website notification with advisory condition is displayed in the advisory column", new String[] {"TransMgt17756"});
			recentTransmissionsPage.enterInputInSearchBox(patient.getPatientA());
			extentReport.info("2500 V Verify for patient B following advisory condition is displayed in the advisory column - Lithium Cluster Premature Battery Depletion (ICD Battery)", new String[] {"TransMgt17756"});
			recentTransmissionsPage.enterInputInSearchBox(patient.getPatientB());
			
			softAssert.assertAll();
		} catch (AssertionError e) {
			extentReport.fail( "WA_96_IB001_QuickLink_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_96_IB001_QuickLink_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}
