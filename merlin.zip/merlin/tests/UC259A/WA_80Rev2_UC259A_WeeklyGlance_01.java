package com.test.qa.ui.tests.UC259A;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.AlliedndPhyscianLeftNav;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.AlliedndPhyscianTopNav;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.Weekly_Glance_Page;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_80Rev2_UC259A_WeeklyGlance_01 extends CommonUtils 
{
	CA_ClinicSettings_ReportSettingsPage clinicSettings_ReportSettingsPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	AppHomeTopNavPage appHomeTopNavPage;
	AlliedndPhyscianTopNav alliedndPhyscianTopNav;
	AlliedndPhyscianLeftNav alliedndPhyscianLeftNav;
	Weekly_Glance_Page weeklyglancepage;
	
	LoginPageWithPOJO loginPage;
	Login Allied_User;
	Login loginAdminUser;
	Login Physcian_User;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	
	@BeforeClass
	public void initialize() {

		clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		
		
		clinicSettings_ReportSettingsPage = new CA_ClinicSettings_ReportSettingsPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		alliedndPhyscianTopNav=new AlliedndPhyscianTopNav(driver,extentReport);
		alliedndPhyscianLeftNav=new AlliedndPhyscianLeftNav(driver, extentReport);
		weeklyglancepage=new Weekly_Glance_Page(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		Allied_User = new Login();
		Physcian_User = new Login();
		loginAdminUser = new Login();
		
		testDataProvider = new TestDataProvider();
	}
	
  @Test
  public void TC_WA_80Rev2_UC259A_WeeklyGlance_01() 
  {
	  testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		//loginAdminUser = testDataProvider.getLoginData("SJMAdmin3");
		Allied_User = testDataProvider.getLoginData("alliedProfessional");
		Physcian_User = testDataProvider.getLoginData("physicianUser");
		
		
		extentTest.assignAuthor("Author: Kundan Kumar");
		try {
			
			extentReport.info("100 S Login to the system and navigate to EP application");
			loginPage.login(Allied_User,"externaluser");
			Assert.assertTrue(clinicianHomePage.verifyLandingPage(), "Allied Home Page is Displayed.");
			
			extentReport.info("200 S Click on the Tools tab and then select Weekly Glance on the Tertiary nav panel.");
			alliedndPhyscianTopNav.navigateToToolPage();
			alliedndPhyscianLeftNav.navigateToWeeklyGlancePage();
			
			extentReport.info("300 V Verify that the Weekly Glance page (TO006) is displayed<CSched4953>", new String[] {"CSched4953"});
			weeklyglancepage.verifyWeeklyGlancepagedisplayed();
			
			extentReport.info("400 V Verify that the current week option is displayed by default in the dropdown box <CSched4953>", new String[] {"CSched4953"});
            weeklyglancepage.verifyWeeklyGlanceDefaultOption();
           
            extentReport.info("500 V Verify that the Report for the current week is displayed by default <CSched4953>", new String[] {"CSched4953"});
            weeklyglancepage.verifyCurrentweekReport();
            
            extentReport.info("600 S Select 1st week past the current week option from the dropdown box.");
            weeklyglancepage.navigateToFirstWeekOption();
            
            extentReport.info("700 V Verify that the weekly glance information for 1st week past the current week i.e. Current week + 1 is displayed <CSched4953>", new String[] {"CSched4953"});
            weeklyglancepage.verify1stWeekReport();
            
            extentReport.info("800 S Select 2nd week past the current week option from the dropdown box.");
            weeklyglancepage.naviagteTo2WeekOption();

            extentReport.info("900 V Verify that the weekly glance information for the 2nd week past the current week i.e. Current week - 2 is displayed <CSched4953>", new String[] {"CSched4953"});
            weeklyglancepage.verify2ndWeeksReport();
            
           extentReport.info("1000 S Select 3rd week past the current week option from the dropdown box.");
           weeklyglancepage.naviagteTo3WeekOption();
           
           extentReport.info("1100 V Verify that the weekly glance information for the 3rd week past the current week i.e. Current week -3 is displayed <CSched4953>", new String[] {"CSched4953"});
			weeklyglancepage.verify3rdWeeksReport();
			
  }
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	/*	@AfterMethod
		public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
			String status = null;
			String testMethodName = result.getMethod().getMethodName();
			 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
				 status = "Failure";
			    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			    	status = "Success";
			    } 
			
			writeInTextFile(testMethodName, status);
		}*/
		
  }
}
