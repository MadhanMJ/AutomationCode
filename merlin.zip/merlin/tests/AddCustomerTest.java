package com.test.qa.ui.tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataBaseTables.Customer;
import com.test.qa.dataBaseTables.CustomerAccount;
import com.test.qa.dataBaseTables.CustomerAddress;
import com.test.qa.dataBaseTables.Location;
import com.test.qa.dataBaseTables.LookUp;
import com.test.qa.dataBaseTables.Phone;
import com.test.qa.dataBaseTables.UserRecord;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPage;
import com.test.qa.utilities.CommonUtils;


public class AddCustomerTest extends CommonUtils{

	LoginPage loginPage;
	AddCustomerPage addCustomerPage;
	//CustomerListPage1 customerListPage;
	ExtentReport extentReport;
	ExtentTest extentTest,child1,child2,child3,child4;
	private String testName;
	private String actualCustomerName;
	private Assertions softAssert;
	private UserRecord userRecord;
	private CustomerAccount customerAccount;
	private Customer customer;
	private CustomerAddress customerAddress;
	private Phone phone;
	private LookUp lookUp;
	private Location location;
	private String legal_jurisdiction_cd="";
	private String customer_type_cd="";
	private String time_zone_cd="";
	private String phone_id="";
	private String spoken_language_cd="";
	private String country_cd ="";
	private String address_id = "";
	public DataBaseConnector dataBase;
		
	@BeforeClass
	public void initialize() {
		driver = initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		//customerListPage = new CustomerListPage1(driver, extentReport);
		loginPage = new LoginPage(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver,extentReport);
		userRecord= new UserRecord();
		customerAccount = new CustomerAccount();
		phone = new Phone();
		customer = new Customer();
		lookUp= new LookUp();
		location = new Location();
		customerAddress = new CustomerAddress();
		dataBase = new DataBaseConnector();		
	}
	
		
	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
	public void addCustomer(String iteration, String username, String password,String customerName,String userid,String customerType,
			String clinicLocation, String countryCode, String areaCode, String mainPhone, String country, String email,
			String clinicTimeZone, String legalJurisdiction, String clinicLanguage, String newPassword,
			String confirmNewPassword, String firstName, String lastName, String emailId, String ElecExport) throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		CommonUtils.iteration = iteration;
		extentTest = extentReport.initiateTest(testName + "_Iteration_" + iteration);
		CommonUtils.extentTest = extentTest;
		
		try {
			softAssert = new Assertions(extentTest);
			loginPage.login(username, password);
			//customerListPage.goToAddCustomerPage();
			String customerNameValue = addCustomerPage.addCustomer(customerName, userid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			
			if(addCustomerPage.addcustomer)
			{
				System.out.println("**********************DB Verification**********************");
			//actualCustomerName = customerListPage.searchCustomer(customerNameValue); 
			actualCustomerName=customerNameValue;
			
			Assert.assertEquals(actualCustomerName.toLowerCase(),addCustomerPage.customerNameValue.toLowerCase(), "Customer Name is verified");
			extentTest.log(Status.PASS, "Customer Name is verified");
			
			//Database Validation
			//User record table
			//child1 = extentTest.createNode("User Record table Validation");
			//softAssert = new Assertions(child1);
			//softAssert = new Assertions(extentTest);
			
			userRecord.readUserRecordTable(userid);
			Thread.sleep(1200);
			String userRecordId = userRecord.getUserRecordId();
			softAssert.assertEquals(true, true,"/***********************USER RECORD TABLE VALIDATION*****************************/");
			softAssert.assertEquals(firstName, userRecord.getFirstName(),"First name field is verified");
			softAssert.assertEquals(lastName, userRecord.getLastName(), "Last name field is verified");
			softAssert.assertEquals(newPassword, userRecord.getTempPwd(),"Temprory Password field is verified");
			
			customerAccount.readCustomerAccountTable(userRecordId);
			Thread.sleep(1200);
			String customerId = customerAccount.getCustomerId();
			softAssert.assertEquals(true, true,"/***********************CUSTOMER TABLE VALIDATION*****************************/");
			// customertable
			//child2 = extentTest.createNode("Customer Table Validation");
			//softAssert = new Assertions(child2);
			//softAssert = new Assertions(extentTest);
			customer.readCustomerTable(customerId);
			softAssert.assertEquals(addCustomerPage.customerNameValue.toLowerCase(), customer.getCustomerName().toLowerCase(),"Customer Name field is verified");
			softAssert.assertEquals(email, customer.getEmailAddress(),"Email Address field is verified");
			
			customer_type_cd = customer.getCustomerTypeCd();
			time_zone_cd = customer.getTimeZoneCd();
			spoken_language_cd = customer.getSpokenLanguageCd();
			phone_id = customer.getPhoneId();
			legal_jurisdiction_cd = customer.getLegalJurisdictionCd();
			address_id = customer.getAddressId();
			
			lookUp.readLookUpTable(customer_type_cd, "Customer_Type_Cd");
			softAssert.assertEquals(customerType,lookUp.getCodeDescription(), "Customer Type field is verified");
			
			lookUp.readLookUpTable(time_zone_cd, "Time_Zone_Cd");
			softAssert.assertEquals(clinicTimeZone, lookUp.getCodeDescription(), "Time Zone field is verified");
			
			lookUp.readLookUpTable(legal_jurisdiction_cd, "Legal_Jurisdiction_Cd");
			softAssert.assertEquals(legalJurisdiction, lookUp.getCodeDescription(),"Legal Jurisdiction field is verified");
			
			lookUp.readLookUpTable(spoken_language_cd, "Language_Cd");
			softAssert.assertEquals(clinicLanguage, lookUp.getCodeDescription(),"Language field is verified");
			
			//Location Table
			//child3 = extentTest.createNode("Location Table Validation");
			//softAssert = new Assertions(child3);
			//softAssert = new Assertions(extentTest);
			location.readLocationTable(customerId);
			softAssert.assertEquals(clinicLocation, location.getLocationName(),"Clinic Location field is verified");
			
			//customer Address table
			//child4 = extentTest.createNode("Customer Address Table Validation");
			//softAssert = new Assertions(child4);
			//softAssert = new Assertions(extentTest);
			customerAddress.readAddressTable(address_id);
			country_cd = customerAddress.getCountryCode();
			lookUp.readLookUpTable(country_cd, "Country_Cd");
			softAssert.assertEquals(country, lookUp.getCodeDescription(), "Country field is verified");
			
			phone.readPhoneTable(phone_id);
			softAssert.assertEquals(areaCode.toString().trim(), phone.getAreaCode().toString().trim(),"Area code field is verified");
			softAssert.assertEquals(countryCode, phone.getCountryCode(), "Country code field is verified");
			softAssert.assertEquals(mainPhone, phone.getPhoneNumber(), "Phone number field is verified");
			extentTest.pass("Data base table validation completed successfully");
			//addCustomerPage.addcustomer=false;
			}
		} catch (Exception e) {
			extentReport.reportFail("Add customer functionality is not completed successfully");
			e.printStackTrace();
			throw e;
		}
	}
	
	
	@AfterClass
	public void shutdown() throws Exception {
		//customerListPage.verifyLogout();
		driver.close();
	}

}
