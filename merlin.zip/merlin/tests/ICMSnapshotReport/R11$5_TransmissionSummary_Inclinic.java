package com.test.qa.ui.tests.ICMSnapshotReport;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.*;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientSummaryPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;


/* Author: Poojitha Gangiri
 * TC Name: R11.5_TransmissionSummary_Inclinic
 */

public class R11$5_TransmissionSummary_Inclinic extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	PL_TopNavPage pl_TopNavPage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	DataBaseConnector dataBaseConnector;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	List<String> optionsValues;
	ArrayList<Date> transDateValue;
	PL_PatientSummaryPage pl_PatientSummaryPage;
	int transCount, episodesCount;
	
	@BeforeClass
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		pl_PatientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		pl_PatientSummaryPage = new PL_PatientSummaryPage(driver,extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();	
		databaseResults = new HashMap<String,String>();
		optionsValues = new ArrayList<String>();
		transDateValue = new ArrayList<Date>();
		
	}

	@Test
	public void TC_R11$5_TransmissionSummary_Inclinic() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("DirectAll");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		
		try {
			assertion =  new Assertions(extentTest);
			
			extentReport.info("100S User navigates to Patient 1 Snapshot report page.");
			loginPage.login(login);
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier1 filter");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier2 filter");
			patientListPage.enterTier3FilterInputBx("Inclinic_ICM_P2");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickonAllTransmissionFrmList("Inclinic_ICM_P2");
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"All Transmissions Page is displayed");
			pl_TopNavPage.navigateToPatientSummary();
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");

			
			extentReport.info("200V Verify Page displays informational message for data not being available", new String[] {"TransMgt18924","TransMgt19135","TransMgt19136","TransMgt19133","TransMgt18773","CommUI10820","CommUI10821"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDataUnavailabilityMessage(),extentReport,"Patient Summary Page is displayed");
			
			
			extentReport.info("300S User navigates to Patient 2 Snapshot report page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("Inclinic_ICM_P2");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickonAllTransmissionFrmList("Inclinic_ICM_P2");
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"All Transmissions Page is displayed");
			pl_TopNavPage.navigateToPatientSummary();
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");

			
			extentReport.info("400V Verify Page displays informational message for data not being available", new String[] {"TransMgt18924","TransMgt19135","TransMgt19136","TransMgt19133","TransMgt18773","CommUI10820","CommUI10821"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDataUnavailabilityMessage(),extentReport,"Patient Summary Page is displayed");
			
			extentReport.info("500S User navigates to Patient 3 Snapshot report page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx("Inclinic_ICM_P2");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickonAllTransmissionFrmList("Inclinic_ICM_P2");
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"All Transmissions Page is displayed");
			pl_TopNavPage.navigateToPatientSummary();
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");
			
			extentReport.info("600V Verify Page displays informational message for data not being available", new String[] {"TransMgt18924","TransMgt19135","TransMgt19136","TransMgt19133","TransMgt18773","CommUI10820","CommUI10821"});
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyDataUnavailabilityMessage(),extentReport,"Patient Summary Page is displayed");
			
			extentReport.info("700S User navigates to Patient 4 Snapshot report page from Ready for Billing filter on Patient List Page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("Patients ready for billing (Cardiac Monitors)");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier2 filter");
			patientListPage.enterTier3FilterInputBx("EnrollbackICM_FVR");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickonPatientSummaryFrmList("EnrollbackICM_FVR");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");

			
			extentReport.info("800V Verify Page displays Episodes counts and transmissions counts for selected date range", new String[] {"TransMgt18924","TransMgt19135","TransMgt19136","TransMgt19133","TransMgt18773","CommUI10820","CommUI10821"});
			pl_PatientSummaryPage.enterDateValues("12/30/2021","01/9/2022");
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");
			transCount = pl_PatientSummaryPage.getTotalTransmissionsCount();
			episodesCount = pl_PatientSummaryPage.getTotalEpisodesCount();
			pl_TopNavPage.navigateToAllTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TopNavPage.verifyLandingPage(),extentReport,"PatientList AllTransmissions Page is displayed");
			transDateValue = pl_AllTransmissionPage.captureTransDate("MM-dd-yyyy",false);
			pl_AllTransmissionPage.selectTierOneFilterOption("DateRange");
			assertion.assertEquals(pl_AllTransmissionPage.populatedTransValidations(transDateValue,"12/30/2021","01/9/2022"),transCount, "Total transmissions count is matching with 800V step");
			pl_TopNavPage.navigateToAllTransmissionPage();
			
			extentReport.info("900S User navigates to Patient 4 Snapshot report page from Patient Profile page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("Patients ready for billing (Cardiac Monitors)");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier2 filter");
			patientListPage.enterTier3FilterInputBx("EnrollbackICM_FVR");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickOnPatientNameFrmList("Radhya");
			assertion.assertEqualsWithReporting(true,pl_PatientProfilePage.verifyLandingPage(),extentReport,"PatientProfile Page is displayed");
			pl_TopNavPage.navigateToPatientSummary();
			assertion.assertEqualsWithReporting(true,pl_PatientSummaryPage.verifyLandingPage(),extentReport,"Patient Summary Page is displayed");

			extentReport.info("1000V Verify Page displays Episodes counts and transmissions counts for selected date range (counts should be same with above step)", new String[] {"TransMgt18924","TransMgt19135","TransMgt19136","TransMgt19133","TransMgt18773","CommUI10820","CommUI10821"});
			assertion.assertEquals(pl_PatientSummaryPage.getTotalTransmissionsCount(),transCount, "Total transmissions count is matching with 800V step");
			assertion.assertEquals(pl_PatientSummaryPage.getTotalEpisodesCount(),episodesCount, "Total episodes count is matching with 800V step");
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
