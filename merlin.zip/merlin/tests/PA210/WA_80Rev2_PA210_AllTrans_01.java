package com.test.qa.ui.tests.PA210;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_80Rev2_PA210_AllTrans_01 extends CommonUtils {
	
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	PL_TopNavPage pl_TopNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	LoginPageWithPOJO loginPage;
	Login login_Clinic;
	Login login;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	PatientListPage patientListPage;

	@BeforeMethod(alwaysRun = true)
	public void initialize() {

		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver, extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver, extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login_Clinic = new Login();
		login = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test(groups= {"Regression"})
	public void WA_80Rev2_PA210_AllTrans_01()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("DirectAll");
		login_Clinic = testDataProvider.getLoginData("SJMClinic1244");

		extentTest.assignAuthor("Author: Shanmugapriya");
		try {
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100 S The actor logs into the EP Clinic.");
			loginPage.login(login,"externaluser");
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			extentReport.reportScreenShot("Clinician Home Page is Displayed");
			
			extentReport.info("200 S Actor navigate to All Transmissions page for patient having multiple transmissions and click on Transmission Date, Time column to sort on it.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier1 filter");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after selecting Tier2 filter");
			patientListPage.enterTier3FilterInputBx("patient_1");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is loaded after entering in Tier3 filter");
			patientListPage.clickonPatientNameFrmList();
//			assertions.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TopNavPage.navigateToAllTransmissionPage();
//			patientListPage.clickonAllTransmissionFrmList("Enrollbackwithdevice1");
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"All Transmissions Page is displayed");
			pl_AllTransmissionPage.clickTransDateAndTime();
			extentReport.reportScreenShot("User is able to navigate All Transmission page and Click on Transmission DateAndTime column");

			extentReport.info("300 V Verify that transmissions are sorted on Transmission date and time correctly.", new String[] {"TransMgt16623", "CommUI8623"});
			assertions.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyTransDateAndTimeSorted(),extentReport,"Transmissions DateAndTime column sorted correctly.");
			extentReport.reportScreenShot("User is able to see transmissions are sorted on Transmission date and time correctly");
			
			extentReport.info("400 S On All Transmission page, select checkbox next to unviewed follow-up transmission and click on Print button");
			String value = pl_AllTransmissionPage.selectUnviewedCheckbox();
			pl_AllTransmissionPage.clickPrintButton();
			extentReport.reportScreenShot("User is able to select unview checkedbox and print button");
			
			extentReport.info("500 S On Print Transmission Dialog, select All Report checkbox and click on Print button");
			pl_AllTransmissionPage.selectPrintAllAndPrint();
			extentReport.reportScreenShot("User is able to select Print All checkbox and print the reports");
			
			extentReport.info("600 S PDF popup viewer is opened showing all reports available in selected transmission. Close the PDF popup viewer.");
			assertions.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyPDFReport(),extentReport,"PDF pop viewer is opened.");
			pl_AllTransmissionPage.closePDF();
			extentReport.reportScreenShot("User is able to see PDF popup viewer opened showing all reports available");
			
			extentReport.info("700 V Verify that All Transmission page is refreshed and transmission selected for printing is marked as Viewed.", new String[] {"TransMgt16765"});
			assertions.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyTransmissionStatus(value),extentReport,"All Transmission page is refreshed and transmission selected for printing is marked as Viewed.");
			extentReport.reportScreenShot("User is able to see All Transmission page is refreshed and transmission selected for printing is marked as Viewed.");
			pl_AllTransmissionPage.changeToUnviewedTransmission(value);
			assertion.assertAll();
			
			
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_80Rev2_PA210_AllTrans_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "WA_80Rev2_PA210_AllTrans_01 is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
	appHomeTopNavPage.clickSignOutLink();
	saintResult(result, extentTest);

	}
}



