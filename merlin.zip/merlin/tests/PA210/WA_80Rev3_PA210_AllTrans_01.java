package com.test.qa.ui.tests.PA210;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Shafiya Sunkesala
 * Date: 18/02/2022
 * Test Case: WA_80Rev3_PA210_AllTrans_01
 * Test case Id: 1244288
 */

public class WA_80Rev3_PA210_AllTrans_01 extends CommonUtils {
	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	PL_TopNavPage pl_TopNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	
	LoginPageWithPOJO loginPage;
	Login login_Clinic;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeMethod(alwaysRun = true)
	public void initialize() {

		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver, extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver, extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login_Clinic = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test(groups= {"Regression"})
	public void TC_WA_80Rev3_PA210_AllTrans_01()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		login_Clinic = testDataProvider.getLoginData("SJMClinic1244");

		extentTest.assignAuthor("Author: Shafiya Sunkesala");
		try {
			assertions = new Assertions(extentTest);
			extentReport.info("100 S Login application and navigate to All transmission page of patient having multiple transmissions");
			loginPage.login(login_Clinic, "externaluser");
			//Thread.sleep(10000);
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			extentReport.reportScreenShot("Clinician Home Page is Displayed");
			//need to remove this as already clinic patients is selected in recent transmissions page
			ca_RecentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			assertions.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier1 filter.");
			//after test data is given need to change this
			ca_RecentTransmissionsPage.enterTier3FilterInputBx("0509");
			assertions.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			extentReport.reportScreenShot("Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertions.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TopNavPage.navigateToAllTransmissionPage();
			assertions.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"PatientList All Transmissions Page is displayed");
			extentReport.reportScreenShot("PatientList All Transmissions Page is displayed");
			
			extentReport.info("200 V Verify that default primary sort order is on column ‘status’.", new String[] {"TransMgt9788"});
			pl_AllTransmissionPage.isSortSymbolDisplayed();
			//assertions.assertEquals(pl_AllTransmissionPage.isTransmissionDateSorted(), true, "Transmission Date/Time is in descending order");
			extentReport.info("300 V Verify that default secondary sort order is on column ‘transmission date and time’ and is in descending.", new String[] {"TransMgt9788"});
			assertions.assertEquals(pl_AllTransmissionPage.isTransmissionDateSorted(), true, "Transmission Date/Time is in descending order");
			extentReport.takeFullSnapShot(driver, "Transmission Date/Time is in descending order");
			
			
			assertions.assertAll();

		} catch (AssertionError e) {
			extentReport.reportFail( "WA_80Rev3_PA210_AllTrans_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "WA_80Rev3_PA210_AllTrans_01 is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
	appHomeTopNavPage.clickSignOutLink();
	saintResult(result, extentTest);

	}
}

