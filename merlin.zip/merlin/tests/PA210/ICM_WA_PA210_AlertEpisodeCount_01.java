package com.test.qa.ui.tests.PA210;

import java.util.ArrayList;
import java.util.Date;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.*;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.utilities.CommonUtils;


/* Author: Poojitha Gangiri
 * TC Name: ICM_WA_PA210_AlertEpisodeCount_01
 * Test case Id: 1234183
 * Test data: Direct/SP2/EP+HF Clinic with below patient data
 * ICM, Pacemaker, Unity and NGQ Patients having multiple transmissions including alerts & episodes
 */

public class ICM_WA_PA210_AlertEpisodeCount_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	PL_TopNavPage pl_TopNavPage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	ArrayList<Date> transDateValue;
	Patient patient;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		patient = new Patient();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
		transDateValue = new ArrayList<Date>();
		
	}

	@Test
	public void TC_ICM_WA_PA210_AlertEpisodeCount_01() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		
		login = testDataProvider.getLoginData("Regular_ClinicA");
		patient = testDataProvider.getSearchPatientData(testName+"_Scenario1");
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		
		try {
			assertion =  new Assertions(extentTest);
			
			//Logging in as clinician user and navigating to PatientList Page
			extentReport.info("100 S Login to a EP clinic having ICD/PM/ICM patients with transmissions having alerts & episodes and navigate to EP Patient list page");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			
			//Navigating to All Transmissions page through a ICM Patient having multiple transmissions 
			extentReport.info("200 S On EP Patient list page, Select Patient 1 and navigate to All Transmission page.");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.selectTierTwoFilterOption("All");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickonAllTransmissionFrmList(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"PatientList All transmissions Page is displayed");
			extentReport.reportScreenShot("Patient with ICM device is displayed");
			
			//Validation of alerts to be displayed
			extentReport.info("300 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of unique non-episode alerts.",new String[] {"TransMgt16868"});
			pl_AllTransmissionPage.alertsValidation("ICM");
			
			//Validation for episodes not to be displayed
			extentReport.info("400 V Verify that on All Transmissions page, for each transmission in Alerts column system does not displays count of episodes.",new String[] {"TransMgt19106"});
			pl_AllTransmissionPage.episodesValidation("ICM");
			
			//Click on Alerts
			extentReport.info("500 S Select Alert types link under Alert column.");
			pl_AllTransmissionPage.clickOnAlerts();
			
			//Validation of navigation to FastPath Summary page
			extentReport.info("600 V Verify that page navigates to Transmission tab, Fast path summary.",new String[] {"TransMgt16633"});
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationTofastPathSummary();
			extentReport.reportScreenShot("Navigation to FastPath™ Summary page is successful after clicking on Alerts");	
			
			//Filtering the transmissions with date range on All transmissions page
			extentReport.info("700 S Navigate to All Transmission page filter as Date Range and select From and To date according to transmissions available.");
			pl_TopNavPage.navigateToAllTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"PatientList All Transmissions Page is displayed");
			transDateValue = pl_AllTransmissionPage.captureTransDate("MM-dd-yyyy",false);
			pl_AllTransmissionPage.selectTierOneFilterOption("DateRange");
			pl_AllTransmissionPage.enterDateValues(patient.getTransmissionFromDate(),patient.getTransmissionToDate());
			
			//Validation of displayed transmissions whether they lies in the given date range or not
			extentReport.info("800 V Verify that transmissions falling in selected date range are displayed.",new String[] {"TransMgt16638"});
			pl_AllTransmissionPage.populatedTransValidations(transDateValue,patient.getTransmissionFromDate(),patient.getTransmissionToDate());
			extentReport.reportScreenShot("Populated Transmissions lies in the given input date range");	
			
			//Navigating to All Transmissions page through a Pacemaker Patient having multiple transmissions
			patient = testDataProvider.getSearchPatientData(testName+"_Scenario2");
			extentReport.info("900 S On EP Patient list page, Select Patient 2 and navigate to All Transmission page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickonAllTransmissionFrmList(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"PatientList All transmissions Page is displayed");
			
			//Validation of displaying the alerts
			extentReport.info("1000 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of unique non-episode alerts.",new String[] {"TransMgt16868"});
			pl_AllTransmissionPage.alertsValidation("ICM");
			
			//Validation of displaying the episodes
			extentReport.info("1100 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of episodes having episodes.",new String[] {"TransMgt19106"});
			pl_AllTransmissionPage.episodesValidation("Other");
			
			//Click on Alerts
			extentReport.info("1200 S Select Alert types link under Alert column.");
			pl_AllTransmissionPage.clickOnAlerts();
			
			//Validation of navigation to FastPath Summary page
			extentReport.info("1300 V Verify that page navigates to Transmission tab, Fast path summary.",new String[] {"TransMgt16633"});
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationTofastPathSummary();
			extentReport.reportScreenShot("Navigation to FastPath™ Summary page is successful after clicking on Alerts");	
			
			//Click on Episodes
			extentReport.info("1400 S Go to All Transmission page, select Episodes link under Alert column.");
			pl_TopNavPage.navigateToAllTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TopNavPage.verifyLandingPage(),extentReport,"PatientList AllTransmissions Page is displayed");
			pl_AllTransmissionPage.clickOnEpisodes("Other");
			
			//Validation of navigation to Episode & EGM page
			extentReport.info("1500 V Verify that page navigates to Transmission tab, Episode and EGM page.",new String[] {"TransMgt16633"});
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationToEpisodes();
			extentReport.reportScreenShot("Navigation to Episodes and EGM page is successful after clicking on Alerts");	
			 
			//Navigating to All Transmissions page through a Unity Patient having multiple transmissions
			patient = testDataProvider.getSearchPatientData(testName+"_Scenario3");
			extentReport.info("1600 S On EP Patient list page, Select Patient 3 and navigate to All Transmission page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickonAllTransmissionFrmList(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"PatientList All transmissions Page is displayed");
			
			//Validation of displaying the alerts
			extentReport.info("1700 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of unique non-episode alerts.",new String[] {"TransMgt16868"});
			pl_AllTransmissionPage.alertsValidation("Unify");
			
			//Validation of displaying the episodes
			extentReport.info("1800 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of episodes having episodes.",new String[] {"TransMgt19106"});
			pl_AllTransmissionPage.episodesValidation("Other");
			
			//Click on Alerts
			extentReport.info("1900 S Select Alert types link under Alert column.");
			pl_AllTransmissionPage.clickOnAlerts();
			
			//Validation of navigation to FastPath Summary page
			extentReport.info("2000 V Verify that page navigates to Transmission tab, Fast path summary.",new String[] {"TransMgt16633"});
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationTofastPathSummary();
			extentReport.reportScreenShot("Navigation to FastPath™ Summary page is successful after clicking on Alerts");	
			
			//Click on Episodes
			extentReport.info("2100 S Go to All Transmission page, select Episodes link under Alert column.");
			pl_TopNavPage.navigateToAllTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TopNavPage.verifyLandingPage(),extentReport,"PatientList AllTransmissions Page is displayed");
			pl_AllTransmissionPage.clickOnEpisodes("Other");
			
			//Validation of navigation to Episode & EGM page
			extentReport.info("2200 V Verify that page navigates to Transmission tab, Episode and EGM page.",new String[] {"TransMgt16633"});
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationToEpisodes();
			extentReport.reportScreenShot("Navigation to Episodes and EGM page is successful after clicking on Alerts");
			 
			//Navigating to All Transmissions page through a NGQ Patient having multiple transmissions 
			patient = testDataProvider.getSearchPatientData(testName+"_Scenario4");
			extentReport.info("2300 S On EP Patient list page, Select Patient 4 and navigate to All Transmission page.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"PatientList Page is displayed");
			patientListPage.clickonAllTransmissionFrmList(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,pl_AllTransmissionPage.verifyLandingPage(),extentReport,"PatientList All transmissions Page is displayed");
			
			//Validation of displaying the alerts
			extentReport.info("2400 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of unique non-episode alerts.",new String[] {"TransMgt16868"});
			pl_AllTransmissionPage.alertsValidation("CD");
			
			//Validation of displaying the episodes
			extentReport.info("2500 V Verify that on All Transmissions page, for each transmission in Alerts column system displays count of episodes having episodes",new String[] {"TransMgt19106"});
			pl_AllTransmissionPage.episodesValidation("Other");
			
			//Click on Alerts
			extentReport.info("2600 S Select Alert types link under Alert column.");
			pl_AllTransmissionPage.clickOnAlerts();
			
			//Validation of navigation to FastPath Summary page
			extentReport.info("2700 V Verify that page navigates to Transmission tab, Fast path summary. <TransMgt16633>");
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationTofastPathSummary();
			extentReport.reportScreenShot("Navigation to FastPath™ Summary page is successful after clicking on Alerts");	
			
			//Click on Episodes
			extentReport.info("2800 S Go to All Transmission page, select Episodes link under Alert column.");
			pl_TopNavPage.navigateToAllTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TopNavPage.verifyLandingPage(),extentReport,"PatientList AllTransmissions Page is displayed");
			pl_AllTransmissionPage.clickOnEpisodes("Other");
			
			//Validation of navigation to Episode & EGM page
			extentReport.info("2900 V Verify that page navigates to Transmission tab, Episode and EGM page. <TransMgt16633>");
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"PatientList Transmissions Page is displayed");
			pl_TransmissionPage.verifyNavigationToEpisodes();
			extentReport.reportScreenShot("Navigation to Episodes and EGM page is successful after clicking on Alerts");	
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
		clinicianHomeTopNavPage.clickSignOutLink();
		saintResult(result, extentTest);
		}

}