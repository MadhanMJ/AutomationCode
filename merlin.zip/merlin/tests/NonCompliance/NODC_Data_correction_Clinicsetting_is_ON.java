package com.test.qa.ui.tests.NonCompliance;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.RecentTransmissions.RecentTransmissionsPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

/*
 * Author: Vrushali Hitendra Barhate
 * Test Case: 96rev2_NODC_Data_correction_Clinicsetting is ON
 * Report: Dummy xpaths
 */
public class NODC_Data_correction_Clinicsetting_is_ON extends CommonUtils {
	LoginPageWithPOJO loginPage;
	PatientListPage patientListPage;
	RecentTransmissionsPage recentTransmissionPage;

	Login loginClinician;
	Assertions assertion, softAssert;
	Log logger;
	CommonUtils utils;
	DataBaseConnector dataBaseConnector;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	TestDataProvider testDataProvider;
	ExtentTest extentTest;
	String testName;

	@BeforeClass
	public void initialize() {

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		recentTransmissionPage = new RecentTransmissionsPage(driver, extentReport);
		dataBaseConnector = new DataBaseConnector();
		loginClinician = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void TC_R7_SJM100000234() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		loginClinician = testDataProvider.getLoginData("SJMAdmin");
		
				
		extentTest.assignAuthor("Author: Vrushali Barhate");
		
		try {
			assertion =  new Assertions(extentTest);
			extentReport.info("100 S Enroll a new RF Capable /ICM patient");
			loginPage.login(loginClinician);
			assertion.assertEqualsWithReporting(true,recentTransmissionPage.verifyLandingPage(),extentReport,"Recent transmission page is not getting displayed after clinician login");
			//enroll patient method - reach to Salin
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Patient list page is not displayed after patient enrollment");
			
			extentReport.info("200 S The device check flag is set to 1 in the DB");
			
			extentReport.info("300 V Verify the Patient is listed as Not Paired in the patient list page");
			patientListPage.searchPatients(testName);
			
			
			
		} catch (AssertionError e) {
			extentReport.fail(testName + "Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail(testName + " Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

}
