package com.test.qa.ui.tests.UC013C;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;


//Bhupendra Dhore
public class UC013C_A01_01 extends CommonUtils{

	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	int deleted_flg;
	private Log logger = new Log();
	//mohan
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}


	//test data pre-requisites steps yet to implemented due to pending framework level changes and open  defect for patient enrollment for physician user.
	@Test
	public void rev1_UC013C_A01_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		//login = testDataProvider.getLoginData("SJMAdmin");
		//customer = testDataProvider.getCustomerData(testName);// key value  getting the data
		login = testDataProvider.getLoginData("SJMAdmin_delete");
		customer = testDataProvider.getCustomerData("rev1_WA_AD005_DeleteCustomer_01");
		extentTest.assignAuthor("Author - Bhupendra Dhore");

		try {
			softAssert = new Assertions(extentTest);


			//this block of code will add customer/clinic login
			String userId = CommonUtils.randomUserId();	
			customer.setUserid(userId);
			String user=customer.getUserid();
			System.out.println(user);
			softAssert = new Assertions(extentTest);
			String custUserId=customer.getUserid();

			extentReport.info("100-S- The actor (SJM Enrollment Administrator) logs into the system and navigates to page Customer List.");
			loginPage.login(login);
			extentReport.reportScreenShot("The Actor logs into the system");

			addCustomerPage.addCustomerClick();
			addCustomerPage.addCustomerPageLanding();
			
			addCustomerPage.addCustomerfieldupdate(customer, "Text");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
			extentReport.info("200-S- The actor clicks a link in the Customer Name column (Customer A) so that customer profile page is displayed with the customer's details pre-populated.");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			extentReport.reportScreenShot("The Actor successfully navigated to the customer profile page");
			extentReport.info("210-V- Veriy that the system displays Change and Delete button", new String[] {"ClncAcct2048"});
			changeCustomerProfilePage.scrollToDelChngBtnCustProfilePg();
			extentReport.reportScreenShot("Change and Delete button is displayed.");



			extentReport.info("300-S- The actor clicks the Delete button");
			changeCustomerProfilePage.validateAndDeleteCustomer();
			extentReport.reportScreenShot("Delete button is clicked successfully.");



			extentReport.info("400-V-Verify that the system shall provide the capacity to delete the customer.", new String[] {"ClncAcct217","ClncAcct6000"});
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD800(customer.getCustomerName());
			extentReport.reportScreenShot("Actor has the capacity to delete the customer.");
			changeCustomerProfilePage.AcceptDeletePopUp();
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD802();
			extentReport.reportScreenShot("Actor has the capacity to delete the customer.");
			changeCustomerProfilePage.AcceptDeletePopUp();




			extentReport.info("500-V- Verify in database that the System marks the Customer record (CustomerA)as deleted.", new String[] {"ClncAcct229"});
			//Database Validation
			dataBaseConnector.getConnection();
			String query = "select deleted_flg from\r\n"
					+ "customers.customer where customer_id= (select customer_id from users.customer_account\r\n"
					+ "where user_record_id = (select user_record_id from users.user_record where logon_user_name ='" + custUserId + "'))";		
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				deleted_flg = customerRecord.getInt("deleted_flg");				
			}
			softAssert.assertEquals( deleted_flg,1,"Customer is status in database is deleted");


			extentReport.info("600-V- Verify in database that the System marks all the Customer_Accounts  and Users for the deleted Customer (UserP) as deleted.", new String[] {"ClncAcct230"});
			// db query to physicia/allied proffesional/assistant is deleted
			dataBaseConnector.getConnection();
			String phyStatusquery = "(select * from users.customer_account\r\n"
					+ "where user_record_id = (select user_record_id from users.user_record where logon_user_name ='"+custUserId+"'))";		
			ResultSet phyRecord = dataBaseConnector.executeQuery(phyStatusquery);
			while (phyRecord.next()) {
				deleted_flg = phyRecord.getInt("deleted_flg");				
			}
			softAssert.assertEquals( deleted_flg,1,"Customer is status in database is deleted");




			extentReport.info("700-V- Verify in database that the System shall mark all patient enrollments for that Customer as 'released'. It includes all patient enrollments for all applications for that Customer.", new String[] {"ClncAcct231"});
			dataBaseConnector.getConnection();
			String getDelPatietnQuery = "select code_id, code_desc from lookup.code where code_id IN ( select patient_application_status_cd from patients.customer_application_patient where customer_application_id IN (select customer_application_id from customers.customer_application where customer_id IN (select customer_id from customers.customer where customer_id= (select customer_id from users.customer_account\r\n"
					+ "					where user_record_id = (select user_record_id from users.user_record where logon_user_name ='"+custUserId+"')))))";		
			ResultSet delPatientRecord = dataBaseConnector.executeQuery(getDelPatietnQuery);
			String codeDesc;
			while (delPatientRecord.next()) {
				codeDesc = delPatientRecord.getString("code_desc");				
				softAssert.assertEquals( delPatientRecord,"Released/Transfer to Another Clinic","Patient status in database is deleted");
			}








			extentReport.info("800-S-Navigate to Customer list page");
			extentReport.reportScreenShot("Actor navigated to customer list page.");



			extentReport.info("900-V-Verify that list of customers does not include the customer just marked deleted.",new String [] {"ClncAcct229"});
			customerListPage.validateNSrchDltdCust(customer.getCustomerName());
			extentReport.reportScreenShot("Deleted customer is not included in the list of customers.");




			extentReport.pass("1000 -S Test case ends");

		} catch (AssertionError e) {
			extentReport.fail( "rev1_UC013C_A01_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "rev1_UC013C_A01_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
