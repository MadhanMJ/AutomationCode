package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class UC013C_B01_01_ViewCustomer extends CommonUtils{
	
	private String testName;
	ExtentTest extentTest;
	TestDataProvider testDataProvider;
	Login login;
	Customer customer;
	LoginPageWithPOJO loginPage;
	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	Assertions assertion;
	private Log logger = new Log();
	
	
	@BeforeMethod(alwaysRun=true)
	public void initialize()
	{
		extentReport = new ExtentReport(driver,extentReport);
		testDataProvider = new TestDataProvider();
		login = new Login();
		customer = new Customer();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
	}
	
	@Test(groups= {"Regression3"})
	public void uC013C_B01_01_ViewCustomer() throws Exception
	{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("UC013C_B01_01_ViewCustomer");
		
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try
		{
			assertion =  new Assertions(extentTest);
			
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page");
			loginPage.login(login,"internaluser");
			assertion.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(),extentReport,"Customer List page is displayed");
			
			extentReport.info("200-S -The actor searches for specific customer"+"<br>"+"300-S- The actor clicks a link in the Customer Name column so that system displays Customer Profile page with the customer's details pre-populated");
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			
			extentTest = extentReport.info("400-V- Verify that Customer profile page displays the following  components",new String[] {"ClncAcct264"});
			extentReport.takeFullSnapShot(driver, "Customer profile page displays the components");
			
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.customerNameText_OR, customerProfilePage.customerNameText_S),  "Customer Profile Page Customer name Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.customerTypeDropdown_OR, customerProfilePage.customerTypeDropdown_S),  "Customer Profile Page Customer Type Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.customerLocationText_OR, customerProfilePage.customerLocationText_S),  "Customer Profile Page Clinic Location Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.mainPhoneText_OR, customerProfilePage.mainPhoneText_S),  "Customer Profile Page Main Phone Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.countryCodeText_OR, customerProfilePage.countryCodeText_S),  "Customer Profile Page Country Code Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.areaCodeText_OR, customerProfilePage.areaCodeText_S),  "Customer Profile Page Area Code Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.address1Text_OR, customerProfilePage.address1Text_S),  "Customer Profile Page Address1 Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.address2Text_OR, customerProfilePage.address2Text_S),  "Customer Profile Page Address2 Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.address3Text_OR, customerProfilePage.address3Text_S),  "Customer Profile Page Address3 Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.cityText_OR, customerProfilePage.cityText_S),  "Customer Profile Page City Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.clinicLanguageDropdown_OR, customerProfilePage.clinicLanguageDropdown_S),  "Customer Profile Page Clinic Language Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.faxCountryCodeText_OR, customerProfilePage.faxCountryCodeText_S),  "Customer Profile Page Fax country code Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.faxAreaCodeText_OR, customerProfilePage.faxAreaCodeText_S),  "Customer Profile Page Fax Area code Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.stateProvDropdownField_OR, customerProfilePage.stateProvDropdownField_S),  "Customer Profile Page State Province Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.countryText_OR, customerProfilePage.countryText_S),  "Customer Profile Page Country Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.zipPostalcodeText_OR, customerProfilePage.zipPostalcodeText_S),  "Customer Profile Page Zip Code Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.secondaryPhoneText_OR, customerProfilePage.secondaryPhoneText_S),  "Customer Profile Page Secondary Phone Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.faxText_OR, customerProfilePage.faxText_S),  "Customer Profile Page Fax Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.clinicTimeZoneDropdown_OR, customerProfilePage.clinicTimeZoneDropdown_S),  "Customer Profile Page Clinic Time Zone Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.legalJurisdictionDropdown_OR, customerProfilePage.legalJurisdictionDropdown_S),  "Customer Profile Page Legal Jurisdiction Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.emailText_OR, customerProfilePage.emailText_S),  "Customer Profile Page Email Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.middlenameText_OR, customerProfilePage.middlenameText_S),  "Customer Profile Page Middle Name Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.lastNameText_OR, customerProfilePage.lastNameText_S),  "Customer Profile Page Last Name Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.userIDText_OR, customerProfilePage.userIDText_S),  "Customer Profile Page User ID Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.firstNameText_OR, customerProfilePage.firstNameText_S),  "Customer Profile Page First Name Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.mainEmailText_OR, customerProfilePage.mainEmailText_S),  "Customer Profile Page Main Contact Mail Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.credentialsText_OR, customerProfilePage.credentialsText_S),  "Customer Profile Page Credentials Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.merlinOnDemandCheckbox_OR, customerProfilePage.merlinOnDemandCheckbox_S),  "Customer Profile Page Customer On Demand Check Box Validation");
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.testClinicCheckbox_OR, customerProfilePage.testClinicCheckbox_S),  "Customer Profile Page Test Clinic Check Box Validation");
			
			extentTest = extentReport.info("600-V- Verify that Secure Communication for Contact a Colleague emails Control check box is displayed",new String[] {"ClncAcct6087"});
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.authenticationToViewCollegueEmail_OR, customerProfilePage.authenticationToViewCollegueEmail_S),  "Require recipient authentication to view Contact a Colleague emails checbox validation");
			extentReport.reportScreenShot("Require recipient authentication to view Contact a Colleague emails checbox is displayed");
			
			extentTest = extentReport.info("700-V- Verify that Secure Communication for Unpaired Transmitter emails Control check box is displayed",new String[] {"ClncAcct6097"});
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.authenticationToViewUnPairedTransmitterEmail_OR, customerProfilePage.authenticationToViewUnPairedTransmitterEmail_S),  "Require recipient authentication to view Unpaired transmitter emails checbox validation");
			extentReport.reportScreenShot("Require recipient authentication to view Unpaired transmitter emails checbox is displayed");
			
			extentTest = extentReport.info("800-V-Verfiy that Secure Communication for all email messages and text messages Control check box is displayed",new String[] {"ClncAcct6089"});
			assertion.assertEquals(true, customerProfilePage.isElementPresentwithoutException(customerProfilePage.secureCommForAllTheEmailsAndMessages_OR, customerProfilePage.secureCommForAllTheEmailsAndMessages_S),  "Enforce patient privacy standards for clinic checbox validation");
			extentReport.reportScreenShot("Enforce patient privacy standards for clinic checbox is displayed");
			
			extentReport.pass("900-S- Test case ends.");
			assertion.assertAll();
	} catch (AssertionError e) {
		extentReport.fail( "UC013C_B01_01_ViewCustomer validation is failed due to Assertion Failure");
		logger.error(CommonUtils.convertStackTraceToString(e));
		e.printStackTrace();
		throw e;
	} catch (Exception e) {
		extentReport.fail( "UC013C_B01_01_ViewCustomer validation is failed due to some exception");
		logger.error(CommonUtils.convertStackTraceToString(e));
		e.printStackTrace();
		throw e;
	}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}

}