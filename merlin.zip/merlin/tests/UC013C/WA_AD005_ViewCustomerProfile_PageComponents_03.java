package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_AD005_ViewCustomerProfile_PageComponents_03 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Log logger;
	ViewCustomerPage viewpage;
	TestDataProvider testDataProvider;
	private String testName;
	Customer customer1, customer2, customer3, customer4, customer5;

	@BeforeMethod(alwaysRun=true)
	public void initialize() throws Exception {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		logger =  new Log();
		viewpage = new ViewCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer1 = testDataProvider.getCustomerData("WA_AD005_ViewCustomerProfile_PageComponents_03_01");	
		customer2 = testDataProvider.getCustomerData("WA_80Rev2_PA001_PatientList_01_SP2");	
		customer3 = testDataProvider.getCustomerData("WA_80Rev2_PA001_PatientList_01_SP2");	
		customer4 = testDataProvider.getCustomerData("WA_80Rev2_PA001_PatientList_01_SP2");	
		customer5 = testDataProvider.getCustomerData("WA_80Rev2_PA001_PatientList_01_SP2");	
	}
	
	/*
	 * Saints ID: 1243996
	 * Saints Definition ID: 2629843
	 * Data sheet used:- JurisdictionAlerts.xlsx, Login.xlsx
	 * Test Data requirement:- SJM administrator account, Pre-enrolled customer having authorized for EP and HF
	 */

	@Test(groups= {"Regression"})
	public void ViewCustomerProfile_PageComponents_03() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMAdmin");
		extentTest.assignAuthor("Author-Snehal Mane");
		
		
		try {
			Assertions assertions = new Assertions(extentTest);
			
			extentReport.info("100S The actor logs into the system as SJM Admin and navigates to the View customer profile page.");

			loginPage.login(login,"externaluser");

			//loginPage.login(login);

			assertions.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Logged into the application and navigated to Customer list page");
			customerListPage.searchWithExactCustomerNameAndClick(customer1.getCustomerName());
			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer1.getCustomerName()), extentReport, "Searched customer and verified profile page");
			
			extentReport.info("300V Verify the display of list of special alert groups for patient notification to which the clinic is authorized for the EP application, selected from the display groups available and marked as relevant for the EP application", new String[] {"ClncAcct6106", "ClncAcct5991"});	
			viewpage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
			viewpage.clicktoAllAbbottCustTab();
			
			extentReport.info("310V General Device Control - A list of devices the clinic is authorized to use when enrolling patients for EP and HF application, based upon jurisdiction.", new String[] {"ClncAcct6107"});
			customerListPage.searchWithExactCustomerNameAndClick(customer1.getCustomerName());
			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer1.getCustomerName()), extentReport, "Searched customer and verified profile page");
			viewpage.jurisdictionAllowedDeviceValidation();
			viewpage.clicktoAllAbbottCustTab();
			
			extentReport.info("400V Verify the display of list of A list of alert groups to which the clinic is authorized for each of the EP and HF application, selected from the Alert Groups marked as relevant for each of those  applications based on jurisdiction.", new String[] {"ClncAcct6109"});
			customerListPage.searchWithExactCustomerNameAndClick(customer2.getCustomerName());
			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer2.getCustomerName()), extentReport, "Searched customer and verified profile page");
			viewpage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
			viewpage.clicktoAllAbbottCustTab();
			
//			customerListPage.searchWithExactCustomerNameAndClick(customer3);
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer3), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
//			viewpage.clicktoAllAbbottCustTab();
//			
//			customerListPage.searchWithExactCustomerNameAndClick(customer4);
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer4), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
//			viewpage.clicktoAllAbbottCustTab();
//			
//			customerListPage.searchWithExactCustomerNameAndClick(customer5);
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer5), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
//			viewpage.clicktoAllAbbottCustTab();
//			
//			extentReport.info("500V Verify the display of  list of devices the clinic is authorized to use when enrolling patients for EP and HF application, based upon jurisdiction.", new String[] {"ClncAcct5992"});
//			customerListPage.searchWithExactCustomerNameAndClick(customer2.getCustomerName());
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer2.getCustomerName()), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAllowedDeviceValidation();
//			viewpage.clicktoAllAbbottCustTab();
//			
//			customerListPage.searchWithExactCustomerNameAndClick(customer3);
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer3), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAllowedDeviceValidation();
//			viewpage.clicktoAllAbbottCustTab();
//			
//			customerListPage.searchWithExactCustomerNameAndClick(customer4);
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer4), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAllowedDeviceValidation();
//			viewpage.clicktoAllAbbottCustTab();
//			
//			customerListPage.searchWithExactCustomerNameAndClick(customer5);
//			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer5), extentReport, "Searched customer and verified profile page");
//			viewpage.jurisdictionAllowedDeviceValidation();
//			
		}
		
			catch (AssertionError e) {
				extentReport.reportFail( "WA_AD005_ViewCustomerProfile_PageComponents_03 due to some exception is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
				throw e;
				}
		
		

				catch (Exception e) {
					extentReport.reportFail("WA_AD005_ViewCustomerProfile_PageComponents_03 due to some exception", CommonUtils.convertStackTraceToString(e));
				throw e;
				}
		
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
	
}
