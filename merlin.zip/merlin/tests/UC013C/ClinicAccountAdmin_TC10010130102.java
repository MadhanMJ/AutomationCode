package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class ClinicAccountAdmin_TC10010130102 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	ViewCustomerPage viewpage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	CustomerListPage customerListPage;
	private String testName;
	String clinicalTrailSectionTitle;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	String show_export_session_flg,order_transmitter_flg, exportToEHR;
	List<String> expectedxportTOEHROptions = new ArrayList<String>();
	Log logger;
	
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		viewpage = new ViewCustomerPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		customerListPage = new CustomerListPage(driver, extentReport);
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		expectedxportTOEHROptions.add("No Export");
		expectedxportTOEHROptions.add("Manual");
		expectedxportTOEHROptions.add("Auto/manual");
	}
	
	@Test(groups= {"Regression"})
	public void WAAD001CustomerListpageNavigation01M2() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
	
		login = testDataProvider.getLoginData("SJMAdmin");
		extentTest.assignAuthor("Author-Mohan Sekar");
		
		try {
			//User login to application and clicks add customer and clicks cancel without filling form
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			assertion =  new Assertions(extentTest);
            extentReport.info("100 S Actor logs into application and navigates to Customer List page.");
            //Assert.assertTrue(customerProfilePage.verifyLandingPage());
            loginPage.login(login,"internaluser");
            viewpage.pageload();
			extentTest = extentReport.info("200 S Click On Add Customer Button.");
			extentReport.takeFullSnapShot(driver,"Add Customer Click");
			viewpage.clickOnAddCustomerButton();
			viewpage.pageload();
		
			extentTest = extentReport.info("300 S System will navigate to Add Customer Page.");
			viewpage.pageload();
			extentReport.takeFullSnapShot(driver,"Add Customer Page");
			viewpage.scrollToView(viewpage.addcustomercancelbutton);
			extentReport.info("400 S Click On Cancel button.");
			viewpage.pageload();
			viewpage.cancel();
			viewpage.pageload();
			extentTest = extentReport.info("500 V Verify that the navigation goes from Add Customer Page to Customer List page ",new String[] {"ClncAcct5982"});
			//User is in customer list  page and clicks any one customer and then clicks add sec location and then cancel
			viewpage.presenceOfElementLocated(viewpage.addButton);
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.isElementPresent(viewpage.addButton), extentReport, " Customer List page Displayed ");
			extentTest = extentReport.info("600 S Click On Customer Name link on Customer List page.");
			extentReport.takeFullSnapShot(driver,"Click On Customer Name link on Customer List page.");
			viewpage.clickElement(viewpage.customerlistName);
			viewpage.pageload();
			//extentReport.reporttakeSnapShot(driver,"System will navigate to Customer profile Page.");
			extentReport.info("700 S System will navigate to Customer profile Page.");
			viewpage.scrollToView(viewpage.addSecondaryLocation);
			extentReport.reportScreenShot("Customer profile Page");
			extentReport.info("800 S Click On Add Customer Location button.");
			viewpage.clickElement(viewpage.addSecondaryLocation);
			extentReport.reportScreenShot("Click On Add Customer Location button");
			viewpage.pageload();
			
			viewpage.presenceOfElementLocated(viewpage.addloctioncancel);
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.isElementPresent(viewpage.addloctioncancel), extentReport, " Add Secondary Location view Page Displayed ");
			extentReport.info("900 S System will display Add Customer Location page.");
			viewpage.pageload();
			viewpage.scrollToView(viewpage.addloctioncancel);
			extentReport.reportScreenShot("Add Customer Location page");
			extentReport.info("1000 S Click On Cancel button.");
			viewpage.addseclocationcancel();
			
			viewpage.pageload();
			extentTest = extentReport.info("1100 V Verify that the navigation goes from Add Customer Location page to Customer List page ",new String[] {"ClncAcct5982"});
			viewpage.pageload();
			viewpage.presenceOfElementLocated(viewpage.addButton);
			//used is in customer list page
			assertion.assertEqualsWithReporting(true, changeCustomerProfilePage.isElementPresent(viewpage.addButton), extentReport, " Customer List page Displayed ");
			extentReport.info("1200 S Test case ends.");

			
		} catch (AssertionError e) {
			extentReport.fail( "ClinicAccountAdmin_TC10010130102  are not verified successfully");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( "ClinicAccountAdmin_TC10010130102  are not verified successfully ");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
	//	customerListPage.verifyLogout();
		saintResult(result,extentTest);
	}
	
	}

