package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_ADOO1_ViewCustomerListandSortableColumnHeader extends CommonUtils {
	CommonUtils utils;
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	AddSecondarylocationPage addSecondarylocationPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	String testName,customerinListPage,customerinProflePage;
	Assertions assertions ;
	Assertions softAssert;
	Log logger;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;	
	boolean sorted =false;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		addCustomerPage= new AddCustomerPage (driver, extentReport);
		addSecondarylocationPage= new AddSecondarylocationPage (driver, extentReport);		
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		logger = new Log();
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		utils= new CommonUtils();
		
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void wA_ADOO1_ViewCustomerListandSortableColumnHeader() throws Exception { 

		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		assertions =  new Assertions(extentTest);
		
		customer = testDataProvider.getCustomerData(testName);
		extentTest.assignAuthor("Author: ChandraMohanSingaram");		

		try {
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page.");
			loginPage.login(login,"internaluser");

			extentReport.info("200-V-Verify the Customer List page shall display the following information about each customer:",new String[] {"ClncAcct5933"},new String[] {"ClncAcct5933"});
			//softAssert(true,customerListPage.checkColumnHeader("CustomerName"),"Verify CustomerName");
			assertions.assertEquals(true,customerListPage.checkColumnHeader("CustomerName"),"Verify CustomerName");
			//softAssert(true,customerListPage.checkColumnHeader("Location"),"Verify Location");
			assertions.assertEquals(true,customerListPage.checkColumnHeader("Location"),"Verify Location");
			//softAssert(true,customerListPage.checkColumnHeader("CustomerType"),"Verify CustomerType");
			assertions.assertEquals(true,customerListPage.checkColumnHeader("CustomerType"),"Verify CustomerType");
			//softAssert(true,customerListPage.checkColumnHeader("TelephoneNo"),"Verify TelephoneNo");
			assertions.assertEquals(true,customerListPage.checkColumnHeader("TelephoneNo"),"Verify TelephoneNo");
			extentReport.reportScreenShot(" Customer List page shall display all the four informations about each customer");
			
			extentReport.info("250-V- Verify that default sorting is based upon customer name.");
			assertions.assertEquals(true,customerListPage.verifyDefaultsortingByCustomerName(),"Customers sort based on CustomerName by default");
			
			extentReport.info("300-V-Verify the Customer List page shall provide a mechanism to sort the displayed customers based on on any of the following attributes: location,customerType,telephoneNo",new String[] {"ClncAcct5933"});
			assertions.assertEquals(true,customerListPage.verifysortingInCustomerListPage("location"),"Customers sort based on location");
			extentReport.reportScreenShot("Customers sort based on location");
			
			assertions.assertEquals(true,customerListPage.verifysortingInCustomerListPage("customerType"),"Customers sort based on customerType");
			extentReport.reportScreenShot("Customers sort based on customerType");
			
			assertions.assertEquals(true,customerListPage.verifysortingInCustomerListPage("customerType"),"Customers sort based on customerType");
			extentReport.reportScreenShot("Customers sort based on customerType");
			
			assertions.assertEquals(true,customerListPage.verifysortingInCustomerListPage("telephoneNo"),"Customers sort based on telephoneNo");
			extentReport.reportScreenShot("Customers sort based on telephoneNo");
			
			extentReport.info("350-S-Click on a Add a Customer button");
			addCustomerPage.addCustomerClick();
			
			extentReport.info("400-V-Verify that the system displays Add Customer Page",new String[] {"ClncAcct5932"});			
			assertions.assertEqualsWithReporting(addCustomerPage.addCustomerPageLanding(),true,extentTest, "Verify that the system displays Add Customer Page");
			extentReport.reportScreenShot("Verify that the system displays Add Customer Page");
			
			extentReport.info("450-S- Press Cancel");
			addCustomerPage.addCustomerCancel();

			extentReport.info("500-V-Verify that the system displays existing customer in order to view the selected customer's profile.",new String[] {"ClncAcct5934"});
			customerinListPage=customerListPage.getAndclickOnFirstCustomerLink();
			
			customerinProflePage=customerProfilePage.VerifyCustomerDataInViewMode("CustomerName");
			assertions.assertEqualsWithReporting(customerinListPage,customerinProflePage, extentTest,"Displayed existing customer");

			extentReport.info("600-S-End Test Case.");

		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		//customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
