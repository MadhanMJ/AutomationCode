package com.test.qa.ui.tests.UC013C;

import java.io.IOException;
import java.lang.reflect.Method;
import org.openqa.selenium.Alert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
//import com.test.qa.ui.tests.ChangeCustomerTest;
//import com.test.qa.ui.tests.ViewCustomerTest;
import com.test.qa.utilities.CommonUtils;

import junit.framework.Assert;
public class Rev1_AD005_ViewCustomerProfile_PageComponents_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Log logger;
	Customer customer;
	ViewCustomerPage viewpage;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		logger =  new Log();
		viewpage=new ViewCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void ViewCustomerProfile_PageComponents_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD005_ViewCustomerProfile_PageComponents_01");
		extentTest.assignAuthor("Author-Mohan Sekar");
		//WA-AD005-ViewCustomerProfile-PageComponents-01-1243997
		//Test Case Link -http://saints/saints/TestManager/ManageExternalsDesignsForm.aspx?DesignID=1243997&Action=Edit&DesignIDFilter=1243997&Feature=&VTDName=&DesignGroup=&AssigneeFilter=&StatusFilter=&PriorityFilter=&TitleFilter=&ReqTagsFilter=&GridObjectiveFilter=&GridProcedureFilter=&ShowActiveTestCases=True&ShowInactiveTestCases=False&ProjectID=694&PageIndex=0

		try {
			softAssert = new Assertions(extentTest);
			extentReport.info("100-S-The actor SJM Enrollment Administrator is logged into the system and navigates to page Customer List");
			loginPage.login(login,"internaluser");
			extentReport.info("200-V-Verify the Customer List with a list of customers is displayed",new String[]{"ClncAcct6522"});
			viewpage.customerList(); 
			extentReport.info("300-S-The actor clicks on a link in the Customer Name column and navigates to customer profile page.");
			 viewpage.customerListclick();
			 extentReport.info("400-V-The system displays Customer Profile  page with the customer's  pre-populated details.",new String[]{"ClncAcct264","ClncAcct5996","ClncAcct2048"});
			 Assert.assertTrue(viewpage.verifyLandingPage());
			 extentReport.takeFullSnapShot(driver,"View Customer Page");
			 extentReport.info("500-V-Verify the Customer Profile page shall displayed as per the Requirements.",new String[]{"ClncAcct6523","ClncAcct6103","ClncAcct6521", "ClncAcct6491", "ClncAcct6104", "ClncAcct6489", "ClncAcct6632", "ClncAcct6044", "ClncAcct6490", "ClncAcct6046", "ClncAcct6047", "ClncAcct6048", "ClncAcct6049", "ClncAcct6050"});
			 viewpage.ViewCustomerProfile_PageComponents();
			
			
		} catch (AssertionError e) {
			extentReport.fail("Customer details are not  verified");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		} catch (Exception e) {
			extentReport.fail("Customer details are not  verified");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		}			
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		
		saintResult(result,extentTest);
	}
}
