package com.test.qa.ui.tests.UC013C;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_AD005_ViewCustomerProfile_PageComponents_02 extends CommonUtils{

	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ViewCustomerPage viewCustomerPage;
	DataBaseConnector dataBaseConnector;
	Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Log logger;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName, component, appName;
	//String legalJurisdiction, areaCode, city, clinicLanguage, mainPhone;

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage=new ViewCustomerPage(driver, extentReport);
		login = new Login();
		logger =  new Log();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test
	public void viewCustomerProfile_PageComponents_02() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD005_ViewCustomerProfile_PageComponents_01");
		extentTest.assignAuthor("Author: ChandraMohanSingaram");
		
		try {
			softAssert = new Assertions(extentTest);
			extentReport.info("100S The actor logs into the system and selects a customer to view by clicking on a customer");
			loginPage.login(login);
			viewCustomerPage.loading(); 
			viewCustomerPage.customerListclick();
			viewCustomerPage.loading();
			extentReport.info("200S Verify the Customer profile page displays the following static components as listed below.");

			component="ReceiveDirectAlertsCheckbox";
			extentReport.info("400V Verify the display of check box to receive Direct Alerts emails and text messages without the patient information.",new String[]{"ClncAcct6355"});
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="ColleagueEmailsCheckbox";
			extentReport.info("500V Verify the display of check box to Contact a colleague emails.",new String[]{"ClncAcct6355"});
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");

			component="UnpairedTransmitterEmailCheckbox";
			extentReport.info("600V Verify the display of check box for Unpaired Transmitter email through a secure email system",new String[]{"ClncAcct6355"});
			//viewCustomerPage.customerPageElementExistence("UnpairedTransmitterEmailCheckbox");
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			extentReport.info("700V Verify the application should display EP and HF.",new String[]{"ClncAcct6103","ClncAcct5986"});
			appName="Electrophysiology";
			softAssertO(appName,viewCustomerPage.getAllowedAppications(appName), appName+"  Application is displayed");

			appName="HF";
			softAssertO(appName,viewCustomerPage.getAllowedAppications(appName), appName+"  Application is displayed");
			
			extentReport.info("800V Verify the application should display the  check box for following",new String[]{"ClncAcct6596","ClncAcct6491"});
			component="RecordPatientDataCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="MobileDirectAlertCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="AccessToCommunicationCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="AccessToComplianceCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			extentReport.info("900V Verify the application should display the  check box for following",new String[]{"ClncAcct6104","ClncAcct5988"});
			component="VoiceMessagesFlag";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="TextMessagesFlag";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			extentReport.info("1000V Verify the application should display the check box for following below.");
			component="ExportTransmissionCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="ExportToEMREHRCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			component="OrderTransmitterCheckbox";
			softAssertO(viewCustomerPage.customerPageElementExistence(component),true,component +" is displayed");
			
			extentReport.info("Test Case Ends");

		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
