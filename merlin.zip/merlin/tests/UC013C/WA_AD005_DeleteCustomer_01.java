package com.test.qa.ui.tests.UC013C;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;


//Abhishek kumar
public class WA_AD005_DeleteCustomer_01 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	int deleted_flg;
	private Log logger = new Log();

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}

	
	
	
	@Test
	public void rev1_WA_AD005_DeleteCustomer_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		//login = testDataProvider.getLoginData("SJMAdmin");
		//customer = testDataProvider.getCustomerData(testName);// key value  getting the data
		login = testDataProvider.getLoginData("SJMAdmin_delete");
		customer = testDataProvider.getCustomerData("rev1_WA_AD005_DeleteCustomer_01");
		extentTest.assignAuthor("Author - Abhishek kumar");

		try {
			softAssert = new Assertions(extentTest);
			
			extentReport.info("100-S Login to SJM Admin");
			loginPage.login(login);
			
			
			String userId = CommonUtils.randomUserId();	
			customer.setUserid(userId);
			String user=customer.getUserid();
			System.out.println(user);
			softAssert = new Assertions(extentTest);
			
			//create direct customer
			addCustomerPage.addCustomerClick();
			addCustomerPage.addCustomerPageLanding();

			addCustomerPage.addCustomerfieldupdate(customer,"text");	
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
			String usrIdCust1 = customer.getUserid();
			String directCustUName = customer.getCustomerName();
			
			
			//create sp2 customer
			
			customer = testDataProvider.getCustomerData("rev1_WA_AD005_DeleteCustomer_01_sp2");
			String userId2 = CommonUtils.randomUserId();	
			customer.setUserid(userId2);
			String usersp2=customer.getUserid();
			System.out.println(usersp2);


			addCustomerPage.addCustomerClick();
			addCustomerPage.addCustomerPageLanding();

			
			addCustomerPage.addCustomerfieldupdate(customer, "text");	
			addCustomerPage.seletCustType(customer);
			
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
			
			String usrIdCustSP2 = customer.getUserid();
			String sp2CustUName = customer.getCustomerName();
			
			
			
			extentReport.reportInfo("200-S Select a Clinic A from customer List ");
			customerListPage.searchCustomerAndClick(directCustUName);
			
			extentReport.reportInfo("300-V Verify that Clinic A is displayed in view mode");
			changeCustomerProfilePage.validateAndDeleteCustomer();
			
			
			extentReport.reportInfo("400-S Click on the Delete button on view customer page");
			extentReport.reportInfo("500-V Verify that alert message AD800 is displayed");
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD800(directCustUName);
			
			extentReport.reportInfo("600-S Click ok on alert message");
			changeCustomerProfilePage.AcceptDeletePopUp();
			extentReport.reportInfo("700-S Verify that alert message AD802 is displayed");
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD802();
			extentReport.reportInfo("800-S click ok on alert message");
			changeCustomerProfilePage.AcceptDeletePopUp();
			extentReport.info("900-V Verify that customer list is displayed  ");
			extentReport.reportInfo("1000-S Enter the customer name for deleted customer (ClinicA) in search box on patient list ");
			extentReport.info("1100-V Verify that ClinicA is no longer listed in Customer List");
			customerListPage.validateNSrchDltdCust(directCustUName);
			
			
			
		
			//Database Validation
			dataBaseConnector.getConnection();
			String query = "select deleted_flg from\r\n"
					+ "customers.customer where customer_id= (select customer_id from users.customer_account\r\n"
					+ "where user_record_id = (select user_record_id from users.user_record where logon_user_name ='" + usrIdCust1 + "'))";
					
			
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				deleted_flg = customerRecord.getInt("deleted_flg");
				
			}
			
			extentReport.reportInfo("1200-V Verify that database still has entry for ClinicA but  Customer.deleted flag is set to 1");
			softAssert.assertEquals( deleted_flg,1,"Flag value is as expected");
			
			
			
			
			
			
			
			// sp2 customer deletion
			extentReport.reportInfo("200-S Select a Clinic A from customer List ");
			customerListPage.searchCustomerAndClick(sp2CustUName);
			
			extentReport.reportInfo("300-V Verify that Clinic A is displayed in view mode");
			changeCustomerProfilePage.validateAndDeleteCustomer();
			
			
			extentReport.reportInfo("400-S Click on the Delete button on view customer page");
			extentReport.reportInfo("500-V Verify that alert message AD800 is displayed");
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD800(sp2CustUName);
			
			extentReport.reportInfo("600-S Click ok on alert message");
			changeCustomerProfilePage.AcceptDeletePopUp();
			extentReport.reportInfo("700-S Verify that alert message AD802 is displayed");
			changeCustomerProfilePage.captureandVerifyDeleteMessagePopUpAD802();
			extentReport.reportInfo("800-S click ok on alert message");
			changeCustomerProfilePage.AcceptDeletePopUp();
			extentReport.info("900-V Verify that customer list is displayed  ");
			extentReport.reportInfo("1000-S Enter the customer name for deleted customer (ClinicA) in search box on patient list ");
			extentReport.info("1100-V Verify that ClinicA is no longer listed in Customer List");
			customerListPage.validateNSrchDltdCust(sp2CustUName);
			
			
			
		
			//Database Validation
			dataBaseConnector.getConnection();
			 query = "select deleted_flg from\r\n"
					+ "customers.customer where customer_id= (select customer_id from users.customer_account\r\n"
					+ "where user_record_id = (select user_record_id from users.user_record where logon_user_name ='" + usrIdCustSP2 + "'))";
					
			
			 customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				deleted_flg = customerRecord.getInt("deleted_flg");
				
			}
			
			extentReport.reportInfo("1200-V Verify that database still has entry for ClinicA but  Customer.deleted flag is set to 1");
			softAssert.assertEquals( deleted_flg,1,"Flag value is as expected");
			
			extentReport.pass("1300 S Test case ends");
			
		} catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
