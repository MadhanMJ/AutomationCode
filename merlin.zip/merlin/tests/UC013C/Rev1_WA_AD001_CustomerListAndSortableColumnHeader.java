package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

public class Rev1_WA_AD001_CustomerListAndSortableColumnHeader extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	AddCustomerPage addCustomerPage;
	ExtentTest extentTest;
	Login login;
	Customer customer, changingCustomer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	QueryResults queryResults;
	private String customerName, customerType, phoneNumber;
	private Log logger = new Log();
	Map<String, String> customerTypeValue = new HashMap<String, String>();
	Map<String, String> customerIdValue = new HashMap<String, String>();
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver,extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		changingCustomer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		queryResults =  new QueryResults();
	}
	
	@Test(groups= {"Regression3"})
	public void rev1_WA_AD001_CustomerListAndSortableColumnHeader() throws Exception { 
		//
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("Rev1_WA_AD001_CustomerListAndSortableColumnHeader");
		changingCustomer = customer;
		extentTest.assignAuthor("Author - Gowshalyadevi Rathinam");
		
		try {
			
			assertion =  new Assertions(extentTest);
				
			extentReport.info("100-S-The actor SJM Enrollment Administrator is logged into the system and navigates to page Customer List page");
			loginPage.login(login, "internaluser");
			
			extentReport.info("200-S-The system will display Customer List page with a list of customers");
			assertion.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(),extentReport,"Customer List page is displayed");
			extentReport.reportScreenShot("The system displays Customer List page with a list of customers");
			
			extentTest = extentReport.info("300-V-Verify Sortable Table coloumn Header", new String[] {"ClncAcct5920"});
			customerListPage.checkColumnHeaderSorting("CustomerName");
			
			extentTest = extentReport.info("400-V- Verify the Customer Name Field", new String[] {"ClncAcct5921"});
			customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerName = customerProfilePage.VerifyCustomerDataInViewMode("CustomerName");
			phoneNumber = customerProfilePage.VerifyCustomerDataInViewMode("CountryCode")+" "+customerProfilePage.VerifyCustomerDataInViewMode("AreaCode")+" "+customerProfilePage.VerifyCustomerDataInViewMode("MainPhone");
			System.out.println("1@@"+customerName+"2@@@"+phoneNumber);
			
			assertion.assertEquals(customerName,customer.getCustomerName(),"Upon selection of the Customer name in Customer list page, Customer Profile page is displayed for the selected customer");
			
			
			//customerProfilePage.getURL(CommonUtils.url);
			loginPage.login(login, "internaluser");
			
			extentTest = extentReport.info("500-V- Verify the Column 3 Customer Type", new String[] {"ClncAcct5923"});
			customerListPage.checkColumnHeaderSorting("CustomerType");
			
			extentTest = extentReport.info("600-V- Verify the Column 4 Telephone No", new String[] {"ClncAcct5924"});
			customerListPage.checkColumnHeaderSorting("TelephoneNo");
			
			extentTest = extentReport.info("700-V- Verify the component for Location field", new String[] {"ClncAcct5926"});
			customerListPage.checkColumnHeaderSorting("Location");
			
			extentTest = extentReport.info("800-V- Verify the component for Customer Type Field", new String[] {"ClncAcct5927"});
			customerListPage.searchCustomer(customerName);
			
			String query = "select (SELECT code_desc FROM lookup.code cd where cd.code_id=c.customer_type_cd and cd.code_qualifier ='Customer_Type_Cd') as customer_type "
					+ "from customers.customer c where c.name ='"+customerName+"'";
			
			customerTypeValue = queryResults.readCustomerType(query);
			customerType = customerTypeValue.get("customer_type");
			
			assertion.assertEquals(customerListPage.getText(customerListPage.customerTypeValue_OR, customerListPage.customerTypeValue_S), customerType,"Displayed the description associated with Code.Code_desc for the code value which matches the customer type");
			
			extentTest = extentReport.info("900-V- Verify the component for Telephone Number Field", new String[] {"ClncAcct5928"});
			assertion.assertEquals(customerListPage.getText(customerListPage.telephoneNoValue_OR, customerListPage.telephoneNoValue_S), phoneNumber,"Displays Main Phone number of the customer");
			
			//customerProfilePage.getURL(CommonUtils.url);
			loginPage.login(login, "internaluser");
			extentTest = extentReport.info("1000-V-Verify the  components of the Add Customer Option", new String[] {"ClncAcct5929"});
			customerListPage.clickOnAddCustomerButton();
			assertion.assertTrue(addCustomerPage.verifyLandingPage(),"Upon Add Customer Button activation, Add Customer page is displayed");
			
			//customerProfilePage.getURL(CommonUtils.url);
			loginPage.login(login, "internaluser");

			extentTest = extentReport.info("1100-V-Verify the components of the Customer Search Box", new String[] {"ClncAcct5930"});
			customerListPage.customerSearch(customer.getSearchLocation1());
			customerListPage.customerSearch(customer.getSearchLocatio2());
			
			loginPage.login(login, "internaluser");
			
			extentTest = extentReport.info("1200-V- Verify the Customer list shall provide a mechanism to add a new customer", new String[] {"ClncAcct5932"});
			String customerName = customer.getCustomerName();
			customerListPage.clickOnAddCustomerButton();
			String newCustomerName = addCustomerPage.addCustomerfieldupdate(customer, "Text");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
			addCustomerPage.clickOkButton();
			String actualCustomerName = customerListPage.searchCustomer(newCustomerName);
			assertion.assertEquals(actualCustomerName, newCustomerName, "Customer list provides a mechanism to add a new customer and new customer is displayed in the list");
			
			String query1 = "select customer_id from customers.customer where name = '"+newCustomerName+"'";
			customerIdValue = queryResults.readCustomerId(query1);
			
			String customerId = customerIdValue.get("customer_id");
			assertion.assertTrue(!customerId.isEmpty(), "Customer is added successfully and the data is available in DB");
			
			extentTest = extentReport.info("1300-V-Verify the Customer list page shall provide a mechanism to select an existing customer profile", new String[] {"ClncAcct5934"});
			customerListPage.searchCustomerAndClick(customerName);

			String customerNameText = customerProfilePage.VerifyCustomerDataInViewMode("CustomerName");
			assertion.assertEquals(customerNameText,customerName,"Customer list page provides a mechanism to select an existing customer profile");
			
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_AD001_CustomerListAndSortableColumnHeader is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_AD001_CustomerListAndSortableColumnHeader is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		saintResult(result, extentTest);
	}
}