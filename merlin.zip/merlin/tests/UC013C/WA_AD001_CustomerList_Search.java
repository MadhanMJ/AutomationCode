package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class WA_AD001_CustomerList_Search extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer, changingCustomer;
	TestDataProvider testDataProvider;
	private String testName;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;
	Log logger;
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		logger = new Log();
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		changingCustomer = new Customer();
		dataBaseConnector = new DataBaseConnector();
	}
	
	@Test(groups= {"Regression"})
	public void AD001_CustomerList_Search() throws Exception { //1243605
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		

		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("WA_AD001_CustomerList_Search");
		changingCustomer = customer;
		extentTest.assignAuthor("Author-Mohan Sekar");
		//Validating Search with number , Special Char , Alphanumberic and page navigations
		try {
			
			assertion =  new Assertions(extentTest);
			
			extentReport.info("100 S The actor logs in to the Clinic Account Admin and is navigated to Customer List page");
			
			loginPage.login(login,"internaluser");
		    
		    
			extentReport.info("200 S The actor enters a string in the search field");
			extentReport.info("300 V Verify that the system performs a search on all the displayed columns on the page and displays users that match the partial/Complete string entered in the search field."); 
			//Search with string
			customerListPage.customerSearch(customer.getCustomerName());
			
			//Example-user enters �10� in the search field; the list is filtered on all displayed columns and displays the results that match the search criterion-Such as Customer which has text �10� in Customer Name eg: abc10 and Customer with telephone number 1 101 111 1001
			//Customer Name field verification
			extentReport.info("400 S Repeat steps 200-300 for different search values entered. (eg: alphanumeric, special characters, numbers, alphabets)");
			
			extentReport.info("200 S The actor enters Number in the search field");
			extentTest =extentReport.info("300 V Verify that the system performs a search on all the displayed columns on the page and displays users that match the partial/Complete Number entered in the search field."); 
			//Search with number
			customerListPage.customerSearch("123");
			extentReport.info("200 S The actor enters special charactersr in the search field");
			extentTest =extentReport.info("300 V Verify that the system performs a search on all the displayed columns on the page and displays users that match the partial/Complete special characters entered in the search field."); 
		    CommonUtils.extentTest = extentTest;
		  //Search with special Char
		    customerListPage.customerSearch("@");
			extentReport.info("200 S The actor enters alphabets in the search field");
			extentTest =extentReport.info("300 V Verify that the system performs a search on all the displayed columns on the page and displays users that match the partial/Complete alphabets and numbers entered in the search field."); 
		    CommonUtils.extentTest = extentTest;
		  //Search with alphanumberic
			customerListPage.customerSearch("123Abc");
			customerListPage.pageload();
			extentTest = extentReport.info("400 S Click on Add a Customer ");
			//User is in customer list  page and clicks any one customer and then clicks cancel
			customerListPage.clickOnAddCustomerButton();
			customerListPage.pageload();
			
			Assert.assertTrue(customerListPage.verifyLandingPage());
			extentReport.info("500 V Verify that the system displays Add a customer page. ",new String[] {"ClncAcct5967"});
			
			customerListPage.pageload();
			extentReport.takeFullSnapShot(driver,"Add Customer Page");
			customerListPage.scrollToView(customerListPage.addcustomercancelbutton);
			extentReport.info("600 S Click on cancel.");
			customerListPage.pageload();
			customerListPage.cancel();
			customerListPage.pageload();
			
			
			extentReport.info("700 V Verify that the system displays Customer list page. ",new String[] {"ClncAcct6116"});
			customerListPage.presenceOfElementLocated(customerListPage.addButton);
			assertion.assertEquals(true, changeCustomerProfilePage.isElementPresent(customerListPage.addButton),  " Customer List page Displayed ");
			customerListPage.pageload();
			
			extentTest = extentReport.info("800 S Click on any customer listed in a customer list");
			
			customerListPage.clickElement(customerListPage.customerlistName);
			customerListPage.pageload();
			 
			Assert.assertTrue(customerListPage.verifyLandingPage());
			extentReport.info("900 V Verify that the system displays customer profile page.",new String[] {"ClncAcct5967"});
			extentReport.info("Test Case ends.");
			
		} catch (AssertionError e) {
			extentReport.fail( "AD001_CustomerList_Searche is not verified successfully");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( "AD001_CustomerList_Search is not verified successfully");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
		
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
