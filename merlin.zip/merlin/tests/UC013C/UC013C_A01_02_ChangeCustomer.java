package com.test.qa.ui.tests.UC013C;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class UC013C_A01_02_ChangeCustomer extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	String testName,customerName,fieldValue;
	Assertions assertion ;
	Assertions softAssert;
	Log logger;
	CommonUtils utils;
	DataBaseConnector dataBaseConnector;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void uC013C_A01_02_ChangeCustomer() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		assertion =  new Assertions(extentTest);
		softAssert = new Assertions(extentTest);
		customer = testDataProvider.getCustomerData(testName);
		extentTest.assignAuthor("Author: ChandraMohanSingaram");
		try {
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page.");
			loginPage.login(login,"internaluser");
			
			extentReport.info("200-S -The actor searches for specific customer");
			customerName=customerListPage.searchCustomer(customer.getCustomerName());
			
			extentReport.info("300-S- The actor clicks a link in the Customer Name column so that system displays Customer Profile page with the customer's details pre-populated.");
			customerListPage.clickCustomer(customerName);
		
			//customerName=customerListPage.searchCustomerAndClick(customer.getCustomerName());
			//String cNameProfile= customerProfilePage.VerifyCustomerDataInViewMode(fieldValue);
			//softAssert.assertEquals(cNameProfile, "stoakhillhospitalav",fieldValue+" detail is Prepopulated");
	
			fieldValue= "CustomerName";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+" detail is Prepopulated");
			
			fieldValue= "MainPhone";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "CountryCode";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "Country";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "Email";
			softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "ClinicTimeZone";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "UserID";
			softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "FirstName";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true,fieldValue+"detail is pre-populated. ");
			
			fieldValue= "LastName";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "UserID";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");
			
			fieldValue= "MainContactEmail";
			softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			customerProfilePage.VerifyCustomerDataInViewModee("ClinicLocation","Before Change, Prepopulated");
			
			extentReport.info("400-S- The actor clicks on 'Change' button");
			customerProfilePage.clickChangeButton();
			String enteredClinicLocValue=CommonUtils.randomDataGenerator("ClinicLoc");
			changeCustomerProfilePage.changeCustomerFieldValue("ClinicLocation",enteredClinicLocValue,true);
			Thread.sleep(3000);
			System.out.println("Searched customer Name "+customerName);
			customerListPage.searchCustomer(customerName);
			Thread.sleep(5000);
			String changedClinicLocVal=customerListPage.matchedSecLocation(enteredClinicLocValue);
			
			extentReport.info("500-V- Verify that the Change Customer page provide a mechanism for the user to save the changes through 'Save' button. >",new String[] {"ClncAcct5999"});
			assertion.assertEqualsWithReporting(enteredClinicLocValue.toLowerCase(), changedClinicLocVal.toLowerCase(), extentReport, "Change Customer page provide a mechanism for the user to save the changes through 'Save' button. ");
			
			extentReport.info("600- S- Test case ends");
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		//customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
