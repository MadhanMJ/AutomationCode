package com.test.qa.ui.tests.UC015C;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ViewProfile.ViewProfile;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_HF_MyAccount_DynamicComponents_01 extends CommonUtils  {
	AppHomeTopNavPage appHomeTopNavPage;
	ViewProfile viewProfile;
	LoginPageWithPOJO loginPage;
	Login loginTraige_Account;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	@BeforeClass
	public void initialize() {
		viewProfile = new ViewProfile(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		loginTraige_Account = new Login();
		testDataProvider = new TestDataProvider();
	}

  @Test
  public void WA_HF_MyAccount_DynamicComponents_01() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		loginTraige_Account = testDataProvider.getLoginData("Triage Account");
		extentTest.assignAuthor("Author: Alok Kumar");
		try {
			Assertions assertion =  new Assertions(extentTest);	
			extentReport.info("100-S- The Actor navigates to My Profile page. ");
			loginPage.login(loginTraige_Account);
			appHomeTopNavPage.profileLink();
			assertion.assertEqualsWithReporting(true,viewProfile.verifyLandingPage(),extentReport,"Customer Profile page is displayed with customer's details ");
			
			extentReport.info("200-V- Verify that the My Profile page is displayed in View mode.",new String[] {"ClncnMgt14767","ClncnMgt14766","CommUI8620","ClncnMgt411","ClncnMgt412"});
			viewProfile.checkPageInViewMode();
			extentReport.reportScreenShot( "User able to Verify that the My Profile page is displayed in View mode.");
			
			extentReport.info("300-S- The Actor clicks the Edit button on the page");
			viewProfile.clickOnEdit();
			extentReport.reportScreenShot( "User able to click on edit button");
			
			extentReport.info("400 V Verify that User Profile section is displayed as a non-editable section with the following fields:\n"
					+ "\n"
					+ "First/ Middle/ last name\n"
					+ "\n"
					+ "Credentials\n"
					+ "\n"
					+ "User type\n"
					+ "\n"
					+ "Department\n"
					+ "\n"
					+ "Admin status");
			viewProfile.VerifyingField("FirstName_TextField");
			viewProfile.VerifyingField("MiddleName_TextField");
			viewProfile.VerifyingField("LastName_TextField");
			viewProfile.VerifyingField("Credential_TextField");
			viewProfile.VerifyingField("UserType_TextField");
			viewProfile.VerifyingField("Department_TextField");
			viewProfile.VerifyingField("Administrator_checkbox");
			extentReport.reportScreenShot( "User able to Verify that User Profile section is displayed as a non-deitable.");
			
			extentReport.info("410 S Erase data in the Primary phone field and click on Save button");
			viewProfile.clearPrimaryPhoneNumber();
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User able to clear Primary Phone number");
			viewProfile.clickOnSave(); 
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User able to Save the changes");
			
			extentReport.info("420 V Verify that message CS 818 is displayed ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			
			extentReport.info("450 S Repeat steps 410-420 for Email and Security Stamp fields");
			extentReport.info("410 S Erase data in the Email field and click on Save button");
			viewProfile.clearEmailAddress();
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User able to clear Email");
			viewProfile.clickOnSave(); 
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User able to Save the changes");
			extentReport.info("420 V Verify that message CS 818 is displayed ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.info("410 S Erase data in the Security stamp field and click on Save button");
			viewProfile.clearStamp();
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User able to clear Security stamp field");
			viewProfile.clickOnSave(); 
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User able to Save the changes");
			extentReport.info("420 V Verify that message CS 818 is displayed ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			
			extentReport.info("500 S Enter an invalid address i.e enter 101 characters");
			viewProfile.updatingAddress1("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55hh");
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User enter address with more than 100 charecter");
			
			extentReport.info("600 V Verify that the system does not allow to enter more than 100 characters ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.checkingCharacterLengthOfAddress();
			extentReport.reportScreenShot( "User not able to enter address with more than 100 charecter");
			
			extentReport.info("700 S Repeat steps for Address2 and Address3 fields. ");
			extentReport.info(" Enter an invalid address i.e enter 101 characters");
			viewProfile.updatingAddress2("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55hh");
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User enter address with more than 100 charecter");
			extentReport.info(" Verify that the system does not allow to enter more than 100 characters ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.checkingCharacterLengthOfAddress();
			extentReport.reportScreenShot( "User not able to enter address with more than 100 charecter");
			extentReport.info(" Enter an invalid address i.e enter 101 characters");
			viewProfile.updatingAddress3("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55hh");
			Thread.sleep(10000);
			extentReport.reportScreenShot( "User enter address with more than 100 charecter");
			extentReport.info(" Verify that the system does not allow to enter more than 100 characters ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.checkingCharacterLengthOfAddress();
			extentReport.reportScreenShot( "User not able to enter address with more than 100 charecter");
			
			extentReport.info(" 800 S Enter valid values in Address 1, 2 & 3 fields (upto 100 characters) and click on Save button ");
			viewProfile.updatingAddress1("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55h");
			viewProfile.updatingAddress2("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55h");
			viewProfile.updatingAddress3("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55h");
			viewProfile.clickOnSave(); 
			extentReport.reportScreenShot( "User able to enter address with 100 charecter");
			
			extentReport.info("900 V Verify that the system saves the value and message CP808 is displayed",new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifySuccessMsg();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			extentReport.info("950 V Verify that the changes made are visisble",new String[] {"ClncnMgt275"});
			viewProfile.verifyingAddressUpdated("Zippy Diagnostics 123 Center Ln. Plymouth, MN 55441Zippy Diagnostics 123 Center Ln. Plymouth, MN 55h");
			extentReport.reportScreenShot( "User able to Verify that the changes made are visisble");
			
			extentReport.info("1000S Click on Edit button on the page.");
			viewProfile.clickOnEdit();
			extentReport.reportScreenShot( "User able to Click on Edit button on the page.");
			
			extentReport.info("1100 S Enter an invalid input in City i.e enter 31 characters.");
			viewProfile.clearCity();
			viewProfile.updatingCity("Enter an invalid input in City");
			viewProfile.checkingCharacterlengthOfCity();
			extentReport.reportScreenShot( "User not able to enter city with more than 30 charecter");
			
			extentReport.info("1200 V Verify that the system does not allow to enter more than 30 characters",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002","ClncnMgt274"});
			viewProfile.checkingCharacterlengthOfCity();
			extentReport.reportScreenShot( "User not able to enter city detail with more than 30 charecter");
			
			extentReport.info("1300 S Enter valid values in City field (upto 30 characters) and click on Save button");
			viewProfile.updatingCity("New York City New York City ne");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Enter valid values in City field (upto 30 characters) and click on Save button");
			
			extentReport.info("1400 V Verify that the system saves the value and message CP808 is displayed",new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.verifyingCityUpdated("New York City New York City ne");
			extentReport.reportScreenShot("User able to update city");
			
			extentReport.info("1500 S Ensure that Country selected is USA. Enter following invalid values in Zip/ Postal code field and click on Save button.\n"
					+ "\n"
					+ "1. enter V3C 4X1\n"
					+ "\n"
					+ "2. enter 123\n"
					+ "\n"
					+ "3. enter 123456\n"
					+ "\n"
					+ "4. enter %1234\n"
					+ "\n"
					+ "5. enter \\1234567\n"
					+ "\n"
					+ "6. enter 33456789\n"
					+ "\n"
					+ "7. Enter zipcode as odd characters: \"\n"
					+ "\n"
					+ "/`~!@#$%\n"
					+ "\n"
					+ "\n"
					+ "^&*()_+={}\n"
					+ "\n"
					+ " \n"
					+ "\n"
					+ "[ ]\\:\";'<>?,A-Z,a-z.\n"
					+ "\n"
					+ "8. enter enter 3345678998");
			viewProfile.updateZipOrPostalCode("V3C 4X1");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("123");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("123456");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("%1234");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("%1234");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("\1234567");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("33456789");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("asdfsdsgfdgdf");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("`~!@#$%");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("^&*()_+={}");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("[ ]\\:\";'<>?,A-Z,a-z.");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			viewProfile.updateZipOrPostalCode("3345678998");
			viewProfile.clickOnSave();
			extentReport.info("1600 V Verify that message CS 816 is displayed  ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that message CS 816 is displayed");
			
			extentReport.info("1700 S Enter valid value in Zip code field\n"
					+ "\n"
					+ "which contains exact 5 or 9 digits and click on Save button.");
			viewProfile.updateZipOrPostalCode("334567899");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot("User able to  valid zipcode");
			
			extentReport.info("1800 V Verify that the system saves the value, message CP808 is displayed and the page is displayed in View mode. ",new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifySuccessMsg();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			extentReport.info("1900 S Click on Edit button and select a non US Country value");
			viewProfile.clickOnEdit();
			viewProfile.updateCountry("Brazil");
			extentReport.reportScreenShot( "User able to click on Edit button and select a non US Country value");
			
			extentReport.info("2000 S Enter following invalid values in Zip/ Postal code field and click on Save button.");
			viewProfile.updateZipOrPostalCode("3345678998");
			viewProfile.clickOnSave();
			extentReport.info("2100 V Verify that the system does not allow to enter more than 30 characters   ",new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot("User able to  Verify that system does not allow to enter more than 30 characters");
			
			extentReport.info("2200 S Enter valid value in Zip code field");
			viewProfile.updateZipOrPostalCode("334567891234567891234567891238");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot("User able to enter 30 characters");
			
			extentReport.info("2300 V Verify that the system saves the value, message CP 808 is displayed and the page is displayed in View mode", new String[] {"ClncnMgt14765","ClncnMgt15008"});	
			viewProfile.VerifySuccessMsg();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			extentReport.info("2400S Click on Edit button");
			viewProfile.clickOnEdit();
			viewProfile.updateCountry("Brazil");
			extentReport.reportScreenShot( "User able to click on Edit button");
			
			extentReport.info("2500-S- Enter an invalid email address in this field. Test the following invalid entries:\n"
					+ "1.Email Id which does not contain \"@\" e.g. \"johns.ibm.com\"\n"
					+ "2.Email id which does not contain \".\" e.g. \"\n"
					+ "\n"
					+ "john@ibm\n"
					+ "\n"
					+ "\"");
			viewProfile.updatingEmail("johns.ibm.com");
			extentReport.reportScreenShot( "User able to enter email address");
			
			extentReport.info("2600-S- Click on the Save button and OK on the confirmation dialog that appears");
			viewProfile.clickOnSave();
			
			extentReport.info("2700-S Verify that message CS 816 is displayed", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			viewProfile.updatingEmail("john@ibm");
			extentReport.reportScreenShot( "User able to enter email address");
			
			extentReport.info("2600-S- Click on the Save button and OK on the confirmation dialog that appears");
			viewProfile.clickOnSave();
			
			extentReport.info("2700-S Verify that message CS 816 is displayed", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			extentReport.info("2800 SThe actor enters an invalid email with 101 characters in the Email Address field, which contains \"@\" and '.'");	
			viewProfile.updatingEmail("johnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcom@abbott.com");
			extentReport.reportScreenShot( "User able to enter email with 101 characters in the Email Address ");
			
			extentReport.info("2900-S- Click on the Save button and OK on the confirmation dialog that appears.");	
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( " User able to Click on the Save button ");
			
			extentReport.info("3000 V Verify that the actor is not allowed to enter more than 100 character" , new String[] {"ClncnMgt274","ClncnMgt14767"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the actor is not allowed to enter more than 100 character ");
			
			extentReport.info("3100-S- Enter a valid email ID. Click on the Save button and OK on the confirmation dialog that appears.");	
			viewProfile.updatingEmail("john@abbott.com");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( " User able to Enter a valid email ID ");
			
			extentReport.info("3200-V- Verify that a message stating that the changes have been successfully made is displayed " , new String[] {"ClncnMgt14765","ClncnMgt15008"});	
			viewProfile.VerifySuccessMsg();
			extentReport.reportScreenShot( "User able to Verify that a message stating that the changes have been successfully made is displayed ");
			
			extentReport.info("3250 S Repeat steps 2400-3200 for 'Email' selected as After hours contact method");	
			extentReport.info("2400S Click on Edit button");
			viewProfile.clickOnEdit();
			viewProfile.updateCountry("Brazil");
			extentReport.reportScreenShot( "User able to click on Edit button");
			
			extentReport.info("2500-S- Enter an invalid email address in this field. Test the following invalid entries:\n"
					+ "1.Email Id which does not contain \"@\" e.g. \"johns.ibm.com\"\n"
					+ "2.Email id which does not contain \".\" e.g. \"\n"
					+ "\n"
					+ "john@ibm\n"
					+ "\n"
					+ "\"");
			viewProfile.updatingEmail("johns.ibm.com");
			extentReport.reportScreenShot( "User able to enter email address");
			
			extentReport.info("2600-S- Click on the Save button and OK on the confirmation dialog that appears");
			viewProfile.clickOnSave();
			
			extentReport.info("2700-S Verify that message CS 816 is displayed", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			viewProfile.updatingEmail("john@ibm");
			extentReport.reportScreenShot( "User able to enter email address");
			
			extentReport.info("2600-S- Click on the Save button and OK on the confirmation dialog that appears");
			viewProfile.clickOnSave();
			
			extentReport.info("2700-S Verify that message CS 816 is displayed", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system saves the value and message CP808 is displayed");
			
			extentReport.info("2800 SThe actor enters an invalid email with 101 characters in the Email Address field, which contains \"@\" and '.'");	
			viewProfile.updatingEmail("johnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcomjohnibmcom@abbott.com");
			extentReport.reportScreenShot( "User able to enter email with 101 characters in the Email Address ");
			
			extentReport.info("2900-S- Click on the Save button and OK on the confirmation dialog that appears.");	
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( " User able to Click on the Save button ");
			
			extentReport.info("3000 V Verify that the actor is not allowed to enter more than 100 character" , new String[] {"ClncnMgt274","ClncnMgt14767"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the actor is not allowed to enter more than 100 character ");
			
			extentReport.info("3100-S- Enter a valid email ID. Click on the Save button and OK on the confirmation dialog that appears.");	
			viewProfile.updatingEmail("john@abbott.com");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( " User able to Enter a valid email ID ");
			
			extentReport.info("3200-V- Verify that a message stating that the changes have been successfully made is displayed " , new String[] {"ClncnMgt14765","ClncnMgt15008"});	
			viewProfile.VerifySuccessMsg();
			extentReport.reportScreenShot( "User able to Verify that a message stating that the changes have been successfully made is displayed ");
			
			extentReport.info("3300S Click on Edit button");	
			viewProfile.clickOnEdit();
			extentReport.reportScreenShot( "User able to click on Edit button");
			
			extentReport.info("3400-S- The actor submits an incomplete Phone Number Complex. Enter 1 (empty area city code) 1234567");	
			viewProfile.updatingPhoneNumber("1234567","","1");
			extentReport.reportScreenShot( "User able to enter country code,area code and phone number");
			
			extentReport.info("3500-V- The system displays message CS 818");	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "3500-V- The system displays message CS 818 <ClncnMgt274>, <ClncnMgt14767>, <ClncnMgt15002>");
			
			extentReport.info("3600-S-The Actor The actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","123","");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button");
			
			extentReport.info("3700-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt12580","ClncnMgt14997","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3600-S-The Actor The actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","123","1a34");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button");
			
			extentReport.info("3700-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt12580","ClncnMgt14997","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3800-S- The actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","12","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3900-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3800-S- The actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","1234","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3900-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3800-S- The actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","A12","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("3900-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4000-S- The actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("123456","123","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4100-V- The system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4000-S- The actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("12345678","123","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4100-V- The system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4000-S- The actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("12A4567","123","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4100-V- The system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4200-S-The actor enters a valid Phone Number Complex, which has 1 numerical digit for country code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks corresponding button (see parent test case) to submit the form to the system for validation. Include a Phone number complex which uses space, - , or ( and ) for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");	
			viewProfile.updatingPhoneNumber("1234567","123","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number");
			
			extentReport.info("4300-V-Verify that the system saves the value and message CP 808 is displayed." , new String[] {"ClncnMgt14767","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("4200-S-The actor enters a valid Phone Number Complex, which has 1 numerical digit for country code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks corresponding button (see parent test case) to submit the form to the system for validation. Include a Phone number complex which uses space, - , or ( and ) for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");	
			viewProfile.updatingPhoneNumber("1234567","123","(1)");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number");
			
			extentReport.info("4300-V-Verify that the system saves the value and message CP 808 is displayed." , new String[] {"ClncnMgt14767","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("4200-S-The actor enters a valid Phone Number Complex, which has 1 numerical digit for country code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks corresponding button (see parent test case) to submit the form to the system for validation. Include a Phone number complex which uses space, - , or ( and ) for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");	
			viewProfile.updatingPhoneNumber("1234567","(123)","(1)");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number");
			
			extentReport.info("4300-V-Verify that the system saves the value and message CP 808 is displayed." , new String[] {"ClncnMgt14767","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("4200-S-The actor enters a valid Phone Number Complex, which has 1 numerical digit for country code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks corresponding button (see parent test case) to submit the form to the system for validation. Include a Phone number complex which uses space, - , or ( and ) for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");	
			viewProfile.updatingPhoneNumber("1234567","123-","1-");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number");
			
			extentReport.info("4300-V-Verify that the system saves the value and message CP 808 is displayed." , new String[] {"ClncnMgt14767","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("4400- S Select a OUS Country.");	
			viewProfile.updateCountry("Austria");
			extentReport.reportScreenShot( "User able to Select a OUS Country.");
			
			extentReport.info("4500-S- The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks save button.\n"
					+ "\n"
					+ "Test each following invalid inputs:\n"
					+ "\n"
					+ "1. enter 2 123 12\n"
					+ "\n"
					+ "2. enter 123 123 1234567890123\n"
					+ "\n"
					+ "3. enter 123 123 12A");	
			viewProfile.updatingPhoneNumber("12","123","1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a Invalid Phone Number");
			
			extentReport.info("4600-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4500-S- The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks save button.\n"
					+ "\n"
					+ "Test each following invalid inputs:\n"
					+ "\n"
					+ "1. enter 2 123 12\n"
					+ "\n"
					+ "2. enter 123 123 1234567890123\n"
					+ "\n"
					+ "3. enter 123 123 12A");	
			viewProfile.updatingPhoneNumber("1234567890123","123","123");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a Invalid Phone Number");
			
			extentReport.info("4600-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4500-S- The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks save button.\n"
					+ "\n"
					+ "Test each following invalid inputs:\n"
					+ "\n"
					+ "1. enter 2 123 12\n"
					+ "\n"
					+ "2. enter 123 123 1234567890123\n"
					+ "\n"
					+ "3. enter 123 123 12A");	
			viewProfile.updatingPhoneNumber("12A","123","123");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a Invalid Phone Number");
			
			extentReport.info("4600-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("4700-S- The Actor enters a Phone Number Complex that is not complete then clicks Save button. Test each following invalid inputs:");	
			viewProfile.updatingPhoneNumber("1234567","123","");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number and area code with empty country code");
			
			extentReport.info("4800-V-The system displays message CS 818 ." , new String[] {"ClncnMgt274","ClncnMgt14767"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 818.");
			
			extentReport.info("4700-S- The Actor enters a Phone Number Complex that is not complete then clicks Save button. Test each following invalid inputs:");	
			viewProfile.updatingPhoneNumber("","123","123");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a empty Phone Number , area code along with country code");
			
			extentReport.info("4800-V-The system displays message CS 818 ." , new String[] {"ClncnMgt274","ClncnMgt14767"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 818.");
			
			extentReport.info("4700-S- The Actor enters a Phone Number Complex that is not complete then clicks Save button. Test each following invalid inputs:");	
			viewProfile.updatingPhoneNumber("","123","");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a empty Phone Number and empty country code with area code");
			
			extentReport.info("4800-V-The system displays message CS 818 ." , new String[] {"ClncnMgt274","ClncnMgt14767"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 818.");
			
			extentReport.info("3600-S-The Actor enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button.");	
			viewProfile.updatingPhoneNumber("","123","");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a empty Phone Number and empty country code with area code");
			
			extentReport.info("4900-V- The system should save the value and message CP 808 is displayed ." , new String[] {"ClncnMgt14765","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CP 808.");
			
			extentReport.info("3600-S-The Actor enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button.");	
			viewProfile.updatingPhoneNumber("123456789012 ","12345","002");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button");
			
			extentReport.info("4900-V- The system should save the value and message CP 808 is displayed ." , new String[] {"ClncnMgt14765","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CP 808.");
			
			extentReport.info("3600-S-The Actor enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button.");	
			viewProfile.updatingPhoneNumber("123-123 1234 ","(06)","(+31)");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to enters a valid Phone Number Complex which has 1-3 digits for country code, 0-5 digits for Area City Code and 3-12 digits for Phone Number; then clicks Save button");
			
			extentReport.info("4900-V- The system should save the value and message CP 808 is displayed ." , new String[] {"ClncnMgt14765","ClncnMgt15008"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CP 808.");
			
			extentReport.info("5000 S Repeat steps 3400-3700 for Fax / Secondary phone field and for 'Phone/ Fax' selected as After hours Contact method.");	
			extentReport.info("3400-S- The actor submits an incomplete Fax Number Complex. Enter 1 (empty area city code) 1234567");	
			viewProfile.updatingFaxNumber("1234567","","1");
			extentReport.reportScreenShot( "User able to enter country code,area code and Fax number");
			extentReport.info("3500-V- The system displays message CS 818");	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "3500-V- The system displays message CS 818 <ClncnMgt274>, <ClncnMgt14767>, <ClncnMgt15002>");
			extentReport.info("3600-S-The Actor The actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","123","");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button");
			extentReport.info("3700-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt12580","ClncnMgt14997","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			extentReport.info("3400-S- The actor submits an incomplete Fax Number Complex. Enter 1 (empty area city code) 1234567");	
			viewProfile.updatingFaxNumber("1234567","","1");
			extentReport.reportScreenShot( "User able to enter country code,area code and Fax number");
			extentReport.info("3500-V- The system displays message CS 818");	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "3500-V- The system displays message CS 818 <ClncnMgt274>, <ClncnMgt14767>, <ClncnMgt15002>");
			extentReport.info("3600-S-The Actor The actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save button.");	
			viewProfile.updatingPhoneNumber("1234567","123","1a34");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks Save button");
			extentReport.info("3700-V-Verify that the system displays message CS 816." , new String[] {"ClncnMgt12580","ClncnMgt14997","ClncnMgt15002"});	
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("5100 S Click on Edit button");
			viewProfile.clickOnEdit();
			extentReport.reportScreenShot( "User able to click on edit button");
			
			extentReport.info("5200 S Enter the following invalid values in the Text Message field and clicks on Save button");
			viewProfile.updatingTextMessage("johns.ibm.com ");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid values in the Text Message field and clicks on Save button");
			
			extentReport.info("5300V Verify that message CS 816 is displayed.", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("5200 S Enter the following invalid values in the Text Message field and clicks on Save button");
			viewProfile.updatingTextMessage("john@ibm");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid values in the Text Message field and clicks on Save button");
			
			extentReport.info("5300V Verify that message CS 816 is displayed.", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			
			extentReport.info("5400S Actor enters valid data in Text Message field (e.g:john@abc.com) and clicks on Save button");
			viewProfile.updatingTextMessage("john@abc.com");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an valid data in Text Message field and clicks on Save button");
			
			extentReport.info("5500 V Verify that the system saves the value and message CP 808 is displayed.", new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("5600 V Verify that the page is now displayed in View mode.",new String[] {"CommUI7681"});
			viewProfile.checkPageInViewMode();
			extentReport.reportScreenShot( "User able to Verify that the My Profile page is displayed in View mode.");
			
			extentReport.info("5650 S Repeat steps 5100-5600 for 'Text message' selected as After hours contact method");
			extentReport.info("5100 S Click on Edit button");
			viewProfile.clickOnEdit();
			extentReport.reportScreenShot( "User able to click on edit button");
			extentReport.info("5200 S Enter the following invalid values in the Text Message field and clicks on Save button");
			viewProfile.updatingTextMessage("johns.ibm.com ");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid values in the Text Message field and clicks on Save button");
			extentReport.info("5300V Verify that message CS 816 is displayed.", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			extentReport.info("5200 S Enter the following invalid values in the Text Message field and clicks on Save button");
			viewProfile.updatingTextMessage("john@ibm");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an invalid values in the Text Message field and clicks on Save button");
			extentReport.info("5300V Verify that message CS 816 is displayed.", new String[] {"ClncnMgt274","ClncnMgt14767","ClncnMgt15002"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 816.");
			extentReport.info("5400S Actor enters valid data in Text Message field (e.g:john@abc.com) and clicks on Save button");
			viewProfile.updatingTextMessage("john@abc.com");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "The actor able to enters an valid data in Text Message field and clicks on Save button");
			extentReport.info("5500 V Verify that the system saves the value and message CP 808 is displayed.", new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			extentReport.info("5600 V Verify that the page is now displayed in View mode.",new String[] {"CommUI7681"});
			viewProfile.checkPageInViewMode();
			extentReport.reportScreenShot( "User able to Verify that the My Profile page is displayed in View mode.");
			
			extentReport.info("5700 S Click on the Edit button and enter (abc1234) value in the Security stamp field and click on Save button.");
			viewProfile.clickOnEdit();
			viewProfile.updatingSecurityStamp("abc1234");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Edit button and enter (abc1234) value in the Security stamp field and click on Save button.");
			
			extentReport.info("5800V Verify that message CP 808 is displayed.", new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("5950 S Repeat steps 5700- 5800 for following values\n"
					+ "1. Enter *1234567\n"
					+ "2. Enter ab1");
			viewProfile.updatingSecurityStamp("*1234567");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Edit button and enter (abc1234) value in the Security stamp field and click on Save button.");
			extentReport.info("5800V Verify that message CP 808 is displayed.", new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			viewProfile.updatingSecurityStamp("ab1");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Edit button and enter (abc1234) value in the Security stamp field and click on Save button.");
			extentReport.info("5800V Verify that message CP 808 is displayed.", new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("6000 S Enter a valid value (between 4 and 20 char) and click on Save button.");
			viewProfile.updatingSecurityStamp("12334");
			viewProfile.clickOnSave();
			extentReport.reportScreenShot( "User able to Enter a valid value (between 4 and 20 char) and click on Save button.");
			
			extentReport.info("6100 V Verify that the system saves the value and message CP 808 is displayed.", new String[] {"ClncnMgt14765","ClncnMgt15008"});
			viewProfile.VerifyMessage();
			extentReport.reportScreenShot( "User able to Verify that the system displays message CS 808.");
			
			extentReport.info("6200 V Verify that the page is now displayed in View mode.",new String[] {"ClncnMgt14993"});
			viewProfile.checkPageInViewMode();
			extentReport.reportScreenShot( "User able to Verify that the My Profile page is displayed in View mode.");
			
			extentReport.info("6300-S- The Actor clicks on the Edit Button.");
			viewProfile.clickOnEdit();
			extentReport.reportScreenShot( "User able to clicks on the Edit Button.");
			
			extentReport.info("6400 S Click on Change Password link on the page.");
			viewProfile.clickOnChangePassword();
			extentReport.reportScreenShot( "User able to Change Password link on the page.");
			
			extentReport.info("6500 V Verify that the password change page is displayed.",new String[] {"ClncMgt12596"});
			viewProfile.verifyChangePasswordPage();
			assertion.assertEqualsWithReporting(true,viewProfile.verifyChangePasswordPage(),extentReport,"Customer Profile page is displayed with customer's details ");
			extentReport.reportScreenShot( "User able to Verify that the password change page is displayed.");
			
			extentReport.info("6600 S Change the password and login using the new password created.");
			viewProfile.changePassword("Merlinnet123!","Merlinnet123#","Merlinnet123#");
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginTraige_Account);
			extentReport.reportScreenShot( "User able to login with new password.");
			
			extentReport.info("6700 V Verify that the user is able to login using the newly created password.",new String[] {"ClncMgt12596","ClncnMgt15040"});
			appHomeTopNavPage.profileLink();
			assertion.assertEqualsWithReporting(true,viewProfile.verifyLandingPage(),extentReport,"Customer Profile page is displayed with customer's details ");
			
			extentReport.info("6800S navigate again to My Account page.");
			
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
  }
}
