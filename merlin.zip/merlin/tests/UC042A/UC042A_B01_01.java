package com.test.qa.ui.tests.UC042A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;


/* Testcase id: 1243696
Testcase name: UC042A-B01-01
Author- Shanmugapriya
Test data : Physician with Admin privilege, Allied Professional with Admin privilege */


public class UC042A_B01_01 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest;
	Login login;
	Login login_scenario_2;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_ClinicProfilePage ca_clinicProfilePage;
	CA_LeftNavPage ca_leftNavPage;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	CustomerListPage customerListPage;
	CA_ClinicUsers clinicUsersPage;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_ClinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		ca_clinicProfilePage = new CA_ClinicProfilePage(driver, extentReport);
		ca_leftNavPage = new CA_LeftNavPage(driver, extentReport);
		login = new Login();
		login_scenario_2= new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		commonUtils=new CommonUtils();
		customerListPage = new CustomerListPage(driver, extentReport);
		clinicUsersPage=new CA_ClinicUsers(driver, extentReport);
		
	}
	
	@Test(groups= {"Regression"})
	public void uC042A_B01_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("PhysicianAdmin");
		login_scenario_2=testDataProvider.getLoginData("AlliedAdmin");
		extentTest.assignAuthor("Author - Shanmugapriya");
		try {
			Assertions assertions=new Assertions(extentTest);
			//Physician
			extentReport.info("100-S- The Actor navigates to Clinic Location page.");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_leftNavPage.verifyLandingPage(), extentReport, "Clinic Administration page is loaded");
			ca_leftNavPage.clickClinicUserLink();
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyLandingPage(), extentReport, "Clinic Users page is loaded");
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyUserType(login.getCustomer(),login.getTest()), extentReport, "Type of user is displayed");
			extentReport.reportScreenShot("User is able to see User Type in Clinic User page");
			ca_leftNavPage.navigateToClinicLocationsPage();	
				
			//verifying clinic location page is loaded
			extentReport.info("200-V- Verify that the Clinic Location page is displayed.",new String[] {"ClncMgt25562", "ClncMgt303"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyLandingPage(), extentReport, "Clinic Location page is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic locations page");
				
			//verifying clinic locations are in alphabetical order
			extentReport.info("300-V- Verify that the Clinic Location in the clinic are sorted in Alphabetical order.",new String[] {"ClncMgt25566"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyLocationOrder(), extentReport, "Clinic locations are sorted in Alphabetical order");
			extentReport.reportScreenShot("Clinic Locations in Clinic locations page are sorted in Alphabetical order");
				
			//selecting any location in location page
			extentReport.info("400-S- The Actor clicks on any of the Clinic locations available.");
			ca_ClinicLocationsPage.selectAnyLocationInclinicLocation();
			extentReport.reportScreenShot("Selected any of the Clinic Location in Clinic locations page");
			
			//clicking on edit button
			extentReport.info("450-S- The Actor clicks on Edit button.");
			ca_ClinicLocationsPage.EditLocation();
			extentReport.reportScreenShot("Edit button is clicked in clinic locations page");
				
			//verifying clinic location name is mandatory
			extentReport.info("500-V- Verify that Clinic Location name is displayed as mandatory.",new String[] {"ClncMgt25567"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyCustomerLocationMandatory(), extentReport, "Clinic Location name is displayed as mandatory");
			extentReport.reportScreenShot("Clinic Location name is diplayed as mandatory");
				
			//clicking cancel button
			extentReport.info("550-S- The Actor clicks on Cancel  button");
			ca_ClinicLocationsPage.cancelLocation();
			extentReport.reportScreenShot("Cancel button is clicked in clinic locations page");
				
			//selecting any location in location page
			extentReport.info("580-S- The Actor again clicks on any of the Clinic locations available.");
			ca_ClinicLocationsPage.selectAnyLocationInclinicLocation();
			extentReport.reportScreenShot("Selected any of the Clinic Location in Clinic locations page");
				
			//verifying main location information
			extentReport.info("600-S- Verify that the following main location information:",new String[] {"ClncMgt30768","CommUI6686","CommUI7793","CommUI7794","CommUI7795","CommUI7796","CommUI7798","CommUI77801", "CommUI77804"});
//			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyClinicLocationsFields(), extentReport, "Main informations are displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Address1"), extentReport, "Address1 field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Address2"), extentReport, "Address2 field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Address3"), extentReport, "Address3 field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Country"), extentReport, "Country field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("City"), extentReport, "City field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("State"), extentReport, "State field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Zipcode"), extentReport, "Zipcode field is displayed in view mode");
			extentReport.reportScreenShot("Verified Address1, Address2, Address3, Country, City, State, Zipcode fields in Clinic locations page are displayed in view mode");
				
			extentReport.info("700-S- The Actor ends the testcase");
			clinicianHomeTopNavPage.clickSignOutLink();
			
//			Allied Professional
			extentReport.info("100-S- The Actor navigates to Clinic Location page.");
			loginPage.login(login_scenario_2,"externaluser");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			assertions.assertEqualsWithReporting(true, ca_clinicProfilePage.verifyLandingPage(), extentReport, "Clinic Administration page is loaded");
			ca_leftNavPage.clickClinicUserLink();
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyLandingPage(), extentReport, "Clinic Users page is loaded");
			assertions.assertEqualsWithReporting(true, clinicUsersPage.verifyUserType(login_scenario_2.getCustomer(),login_scenario_2.getTest()), extentReport, "Type of user is displayed");
			extentReport.reportScreenShot("User is able to see User Type in Clinic User page");
			ca_leftNavPage.navigateToClinicLocationsPage();	
			
			//verifying clinic location page is loaded
			extentReport.info("200-V- Verify that the Clinic Location page is displayed.",new String[] {"ClncMgt25562", "ClncMgt303"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyLandingPage(), extentReport, "Clinic Location page is displayed");
			extentReport.reportScreenShot("User is able to successfully navigate to Clinic locations page");
			
			//verifying clinic locations are in alphabetical order
			extentReport.info("300-V- Verify that the Clinic Location in the clinic are sorted in Alphabetical order.",new String[] {"ClncMgt25566"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyLocationOrder(), extentReport, "Clinic locations are sorted in Alphabetical order");
			extentReport.reportScreenShot("Clinic Locations in Clinic locations page are sorted in Alphabetical order");
			
			//selecting any location in location page
			extentReport.info("400-S- The Actor clicks on any of the Clinic locations available.");
			ca_ClinicLocationsPage.selectAnyLocationInclinicLocation();
			extentReport.reportScreenShot("Selected any of the Clinic Location in Clinic locations page");
			
			//clicking on edit button
			extentReport.info("450-S- The Actor clicks on Edit button.");
			ca_ClinicLocationsPage.EditLocation();
			extentReport.reportScreenShot("Edit button is clicked in clinic locations page");
			
			//verifying clinic location name is mandatory
			extentReport.info("500-V- Verify that Clinic Location name is displayed as mandatory.",new String[] {"ClncMgt25567"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.verifyCustomerLocationMandatory(), extentReport, "Clinic Location name is displayed as mandatory");
			extentReport.reportScreenShot("Clinic Location name is diplayed as mandatory");
			
			//clicking cancel button
			extentReport.info("550-S- The Actor clicks on Cancel  button");
			ca_ClinicLocationsPage.cancelLocation();
			extentReport.reportScreenShot("Cancel button is clicked in clinic locations page");
			
			//selecting any location in location page
			extentReport.info("580-S- The Actor again clicks on any of the Clinic locations available.");
			ca_ClinicLocationsPage.selectAnyLocationInclinicLocation();
			extentReport.reportScreenShot("Selected any of the Clinic Location in Clinic locations page");
			
			//verifying main location information
			extentReport.info("600-S- Verify that the following main location information:",new String[] {"ClncMgt30768","CommUI6686","CommUI7793","CommUI7794","CommUI7795","CommUI7796","CommUI7798","CommUI77801", "CommUI77804"});
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Address1"), extentReport, "Address1 field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Address2"), extentReport, "Address2 field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Address3"), extentReport, "Address3 field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Country"), extentReport, "Country field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("City"), extentReport, "City field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("State"), extentReport, "State field is displayed in view mode");
			assertions.assertEqualsWithReporting(true, ca_ClinicLocationsPage.VerifyClinicLocDataInViewMode("Zipcode"), extentReport, "Zipcode field is displayed in view mode");
			extentReport.reportScreenShot("Verified Address1, Address2, Address3, Country, City, State, Zipcode fields in Clinic locations page are displayed in view mode");
			
			extentReport.info("700-S- The Actor ends the testcase");
			assertion.assertAll();
			
			
		}catch (AssertionError e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "UC042A_B01_01 is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
//		customerListPage.verifyLogout();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}
