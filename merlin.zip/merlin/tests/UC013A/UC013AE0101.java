package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class UC013AE0101 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	Log logger;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		 logger = new Log();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
		
	}

	@Test(groups= {"Regression"})
	public void addcustomervalidtion() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
        login = testDataProvider.getLoginData("SJMAdmin");
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		customer = testDataProvider.getCustomerData("UC013AE0101");
		CommonUtils.iteration = login.getIteration();
		
		extentTest.assignAuthor("Author-Mohan Sekar");//comments
		try {
			Assertions softassert=new Assertions(extentTest);
			System.out.println("CustomerID: "+customer.getUserid());
			
			extentReport.info( "100S The actor (SJM Enrollment Administrator) is logged into the system and navigates to Customer List page");
			//Login application
			loginPage.login(login);
			
			//Assert.assertTrue(customerListPage.verifyLandingPage());
			extentReport.info( "200V The system Customer List page is displayed.");
			extentReport.info( "300S The actor clicks the Add a customer menu item");
			addCustomerPage.addcustomerclickurl();
			addCustomerPage.loading();
			
			
			
		//	loginPage.login(login);
			
			// addCustomerPage.addcustomerclick(); 
			//Adding  manadatory fields in add customer 
			//Assert.assertTrue(customerListPage.verifyLandingPage());
		   extentTest =extentReport.info( "400V The system displays Add Customer page");
			CommonUtils.extentTest = extentTest;
			addCustomerPage.FieldVerfication("CustomerName");
			extentTest =extentReport.info( "500S The actor leaves the Customer Name blank or enters spaces in the Customer Name field, fills all other required fields with valid values, and click the Save button");
			addCustomerPage.ErrorFieldVerfication("CustomerName");
		    extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
			CommonUtils.extentTest = extentTest;
			extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
			
			  addCustomerPage.addcustomerclickurl(); 
		     addCustomerPage.FieldVerfication("ClinicLocation");
			  extentTest =extentReport.info( "500S The actor leaves the Clinic Location blank or enters spaces in the Clinic Location field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("ClinicLocation");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("Mainphone");
			  extentTest =extentReport.info( "500S The actor leaves the Main phone blank or enters spaces in the Main phone field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Mainphone");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("Email");
			  extentTest =extentReport.info( "500S The actor leaves the Email blank or enters spaces in the Email field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Email");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("Clinictimezone");
			  extentTest =extentReport.reportPass( "500S The actor leaves the Clinic timezone blank or enters spaces in the Clinic timezone field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Clinictimezone");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl();
			  
			  addCustomerPage.FieldVerfication("Cliniclegaljurisdiction");
			  extentTest =extentReport.reportPass( "500S The actor leaves the Cliniclegal jurisdiction blank or enters spaces in the Cliniclegal jurisdiction field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Cliniclegaljurisdiction");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl();
			  
			  addCustomerPage.FieldVerfication("UserID");
			  extentTest =extentReport.info( "500S The actor leaves the User ID blank or enters spaces in the User ID field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("UserID");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("Password");
			  extentTest =extentReport.info( "500S The actor leaves the Password blank or enters spaces in the Password field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Password");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("ConfirmNewPassword");
			  extentTest =extentReport.info( "500S The actor leaves the Confirm New Password blank or enters spaces in the Confirm New Password field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("ConfirmNewPassword");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("Firstname");
			  extentTest =extentReport.info( "500S The actor leaves the First Name blank or enters spaces in the First Name field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Firstname");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
			  CommonUtils.extentTest = extentTest;
				extentReport.info("700V The actor Repeat steps 500 to 600. At Step 500, the actor leaves the following fields blank or enters spaces in this field seperately:");
				
			  addCustomerPage.addcustomerclickurl(); 
			  
			  addCustomerPage.FieldVerfication("Lastname");
			  extentTest =extentReport.info( "500S The actor leaves the Last Name blank or enters spaces in the Last Name field, fills all other required fields with valid values, and click the Save button");
			  addCustomerPage.ErrorFieldVerfication("Lastname");
			  extentTest =extentReport.info("600V The system displays CS 818 alert box including the missing field name.",new String[] {"ClncAcct189"});
				CommonUtils.extentTest = extentTest;
				
			 
			addCustomerPage.addcustomerclickurl();
			
			addCustomerPage.FieldVerfication("AddCustomer");
			//extentReport.takeSnapShot( driver,"800V The system displays Add Customer page with entered values.");
			extentReport.info( "Test case ends");
			
		} 
		catch (AssertionError e) {
			
			extentReport.reportFail( "UC013A-E01-01 -  is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			
			throw e;
		}
		catch (Exception e) {
			extentReport.reportFail( "UC013A-E01-01 - Add Customer Field Validation not  successfull");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
		customerListPage.verifyLogout();
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		
		
		writeInTextFile(testMethodName, status);
	}

}