package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

/*
 * Author: Shafiya Sunkesala
 * Test Case Name: 10.0Rev1_WA_UC013A-B01-01
 */

public class $_10_0_Rev1_WA_UC013A_B01_01 extends CommonUtils {	
	private Assertions assertions;
	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	AppHomeTopNavPage appHomeTopNavPage;
	AddCustomerPage addCustomerPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	ViewCustomerPage viewCustomerPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage leftNavPage;
	CA_ClinicUsers clinicUsersPage;
	
	LoginPageWithPOJO loginPage;
	Login loginDirectClinic;
	Login loginSJMAdmin;
	Customer customer_Direct_USA;
	Customer customer_SP_USA;
	Customer customer_Direct_Japan;
	Customer customer_Direct_Canada;
	Customer customer_Direct_Australia;
	Customer customer_Direct_Europe;
	QueryResults queryResults;
	
	int deleted_flg;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	DataBaseConnector dataBaseConnector;
	Map<String, String> databaseResults;
	Map<String, String> databaseResults2;

	@BeforeClass
	public void initialize() {
		
		customerListPage = new CustomerListPage(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		leftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicUsersPage = new CA_ClinicUsers(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		
		dataBaseConnector = new DataBaseConnector();
		loginSJMAdmin = new Login();
		loginDirectClinic = new Login();
		customer_Direct_USA = new Customer();
		customer_SP_USA = new Customer();
		customer_Direct_Japan = new Customer();
		customer_Direct_Canada = new Customer();
		customer_Direct_Australia = new Customer();
		customer_Direct_Europe = new Customer();
		testDataProvider = new TestDataProvider();
		databaseResults = new HashMap<String,String>();
		databaseResults2 = new HashMap<String,String>();
	}

	@Test
	public void TC_10_0_Rev1_WA_UC013A_B01_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author: Shafiya Sunkesala");
		
		try {
			assertions = new Assertions(extentTest);
			
			loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
			customer_Direct_USA = testDataProvider.getCustomerData(testName + "_Direct");
			customer_SP_USA = testDataProvider.getCustomerData(testName + "_SP");
			customer_Direct_Japan = testDataProvider.getCustomerData(testName + "_Japan");
			customer_Direct_Canada = testDataProvider.getCustomerData(testName + "_Canada");
			customer_Direct_Australia = testDataProvider.getCustomerData(testName + "_Australia");
			customer_Direct_Europe = testDataProvider.getCustomerData(testName + "Europe");
			
			String userId_Direct = CommonUtils.randomUserId();
			customer_Direct_USA.setUserid(userId_Direct);
			customer_Direct_USA.setCustomerName(CommonUtils.randomCustomerName());


			String userId_SP = CommonUtils.randomUserId();
			customer_SP_USA.setUserid(userId_SP);			
			customer_SP_USA.setCustomerName(CommonUtils.randomCustomerName());
			
			String userId_Japan = CommonUtils.randomUserId();
			customer_Direct_Japan.setUserid(userId_Japan);
			customer_Direct_Japan.setCustomerName(CommonUtils.randomCustomerName());
			
			String userId_Canada = CommonUtils.randomUserId();
			customer_Direct_Canada.setUserid(userId_Canada);
			customer_Direct_Canada.setCustomerName(CommonUtils.randomCustomerName());
			
			String userId_Europe = CommonUtils.randomUserId();
			customer_Direct_Europe.setUserid(userId_Europe);
			customer_Direct_Europe.setCustomerName(CommonUtils.randomCustomerName());
			
			String userId_Aus = CommonUtils.randomUserId();
			customer_Direct_Australia.setUserid(userId_Aus);
			customer_Direct_Australia.setCustomerName(CommonUtils.randomCustomerName());

			
			extentReport.info("100 S The actor (SJM Enrollment Administrator) is logged into the Merlin.net system and navigates to Customer List page ");
			loginPage.login(loginSJMAdmin, "internaluser");	
			
			extentReport.info("200 V Verify that Customer List page is displayed.");
			assertions.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Customer List page is Displayed.");
											
			extentReport.info("300 S The actor clicks the \"Add a customer\" button ");
			customerListPage.clickOnAddCustomerButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Add Customer Page is Displayed.");
			
			extentReport.info("400 V The system displays Add Customer Page also "
					+ "verify that the system shall provide the capacity for the actor to enter new customer data.", new String[] {"ClncAcct175"});

//			addCustomerPage.FieldVerfication("CustomerName");
//			addCustomerPage.FieldVerfication("ClinicLocation");
//			addCustomerPage.FieldVerfication("Mainphone");
//			addCustomerPage.FieldVerfication("Email");
//			addCustomerPage.FieldVerfication("Clinictimezone");
//			addCustomerPage.FieldVerfication("Cliniclegaljurisdiction");
//			addCustomerPage.FieldVerfication("UserID");
//			addCustomerPage.FieldVerfication("Password");
//			addCustomerPage.FieldVerfication("ConfirmNewPassword");
//			addCustomerPage.FieldVerfication("Firstname");
//			addCustomerPage.FieldVerfication("Lastname");
//			addCustomerPage.FieldVerfication("AddCustomer");
			
			extentReport.info("500 V There shall be two types of customer support by PCS:"
					+ "a. Direct - This type of customer uses PCS to view patient records."
					+ " • All Physicians and Allied Professionals for a Clinic can view all patients records that belong to the Clinic. "
					+ "• Patients must be added to the Clinic manually for transmissions to be associated with the patient."
					+ "b. Type 2 SP - This customer uses PCS to view patient records. "
					+ "• Allied Professionals for a Type 2 SP can view all patients records that belong to the Clinic. "
					+ "• Physicians for a Type 2 SP can only view patient records that have been explicitly assigned to their account or that have been assigned to one of the locations to which the Physician's account has been granted visibility.\r\n"
					+ "• Patients must be added to the Type 2 SP manually for transmissions to be associated with the patient.", new String[] {"ClncAcct316"});			
			
			
			assertions.assertEquals(addCustomerPage.verifyCustType(), true, "Direct and Service provider customer types are available in dropdown");
			
			
			extentReport.info("600 S Case #1 - add a Direct (Customer Type) The actor selects \"Direct\" in the Customer Type field, "
					+ "and enters valid and required information in the Customer headquarters, Clinic location, Clinic main contact, "
					+ "and Clinic feature control sections.");
			
			extentReport.info("800 S Select legal jurisdiction as USA");		
			addCustomerPage.EnterValueAllfields(customer_Direct_USA.getCustomerName(), userId_Direct,customer_Direct_USA.getCustomerType() ,
					customer_Direct_USA.getClinicLocation(), customer_Direct_USA.getCountryCode(), customer_Direct_USA.getAreaCode(), 
					customer_Direct_USA.getMainPhone(), customer_Direct_USA.getCountry(), customer_Direct_USA.getEmail(), customer_Direct_USA.getClinicTimeZone(), 
					customer_Direct_USA.getLegalJurisdiction(), customer_Direct_USA.getClinicLanguage(), customer_Direct_USA.getNewPassword(), 
					customer_Direct_USA.getConfirmNewPassword(), customer_Direct_USA.getFirstName(), customer_Direct_USA.getLastName(),
					customer_Direct_USA.getEmailId(), customer_Direct_USA.getElecExport());

			extentReport.info("900 S Click Save button");
			addCustomerPage.addCustomerSave();
			
			
			extentReport.info("1000 V Verify that the system displays AD 806 with text msg.ad806.text.");
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustomerConfirmMsg(), extentReport, "Add customer successfull and add another physical location confirmation popup is displayed.");
			
			extentReport.info("1100 S The actor clicks the Cancel button on AD 806 ");
			addCustomerPage.addCustomerConfirmCancel();
			
			extentReport.info("1200 V The system displays AD 804 (customer added) alert box with text  msg.ad804.text.", 
					new String[] {"ClncAcct6587"} );
			extentReport.info("1300 S The actor clicks the Okay button on the AD 804 alert box ");
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentReport, "AD 804 popup is displayed.");
			
			extentReport.info("700 V The “headquarters” location for a customer shall be the one specified during initial creation of the customer. "
					+ "The system creates the Customer and Customer Account, and stores details in the database "
					+ "(Tables: CUSTOMER, ADDRESS, LOCATION, CUSTOMER_ACCOUNT, USER_RECORD) and passwords in LDAP Check database if customer is added with correct Type_Cd",
					new String[] {"ClncAcct318"});
			customerListPage.customerSearch(customer_Direct_USA.getCustomerName());
			assertions.assertEquals(customer_Direct_USA.getClinicLocation(), customerListPage.getCustomerLocationByCustName(customer_Direct_USA.getCustomerName()), "Customer location is not matching in customer list page,");
			String userId = changeCustomerProfilePage.getUserId();
			String query = "select ur.logon_user_name ,c.name ,c.email_address,ca.street_address,ca.street_address2 ,"+
					"ca.city as city,(SELECT code_desc FROM lookup.code cd"+ 
							" where cd.code_id= ca.state_cd"+
							" and cd.code_qualifier ='State_Cd') as State_Code,ca.zip_code,"+ 
							" (SELECT code_desc FROM lookup.code cd"+
							" where cd.code_id=c.legal_jurisdiction_cd "+
							" and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction,"+
							" (SELECT code_desc FROM lookup.code cd where cd.code_id=c.locale_cd and cd.code_qualifier ='Language_Cd') as language,"+
							" area_code as area_code,phone_num as main_phone "+
							" FROM customers.customer c ,customers.customer_phone cp ,customers.customer_address ca, users.user_record ur," +
							" users.customer_account ca2 where c.main_phone_id = cp.customer_phone_id"+
							" and c.customer_address_id = ca.customer_address_id"+
							" and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id"+ 
							" and ur.logon_user_name ='"+userId+"'";
			databaseResults = queryResults.customerTable_TC1234183(query);
			assertions.assertEquals(databaseResults.get("clinicName"),customer_Direct_USA.getCustomerName(),"Clinic name field is verified");
			assertions.assertEquals(databaseResults.get("logon_user_name"),customer_Direct_USA.getCustomerName(),"Log in clinic user field is verified");
			assertions.assertEquals(databaseResults.get("area_code"),customer_Direct_USA.getAreaCode(),"Area code field is verified");
			assertions.assertEquals(databaseResults.get("main_phone"),customer_Direct_USA.getMainPhone(),"Phone Number field is verified");
			assertions.assertEquals(databaseResults.get("customerEmailAddress"),customer_Direct_USA.getEmail(), "Email address field is verified");
			assertions.assertEquals(databaseResults.get("addressLine1"),customer_Direct_USA.getAddress1(), "AddressLine1 field is verified");
			assertions.assertEquals(databaseResults.get("addressLine2"),customer_Direct_USA.getAddress2(), "AddressLine2 field is verified");
			assertions.assertEquals(databaseResults.get("city"),customer_Direct_USA.getCity(), "City field is verified");
			assertions.assertEquals(databaseResults.get("stateCode"),customer_Direct_USA.getStateProvince(), "stateCode field is verified");
			assertions.assertEquals(databaseResults.get("zipCode"),customer_Direct_USA.getZipPostalCode(), "zipCode field is verified");
			assertions.assertEquals(databaseResults.get("legal_jurisdiction"),customer_Direct_USA.getLegalJurisdiction(), "Legal Jurisdiction field is verified");
			assertions.assertEquals(databaseResults.get("language"), customer_Direct_USA.getClinicLanguage(),"Clinic Language field is verified");
			
			
			extentReport.info("1400 V The system displays Customer List Page and the list of customers displayed on page should include the customer just added. ");
			assertions.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Customer List page is displayed");
			assertions.assertEqualsWithReporting(customer_Direct_USA.getCustomerName(), customerListPage.searchCustomer(customer_Direct_USA.getCustomerName()), extentReport, "Created Customer is displayed");
			
			extentReport.info("1500 V Verify webapp version ID and DDT version ID from Customer_application table are populated with correct values corresponding to Legal Jurisdiction.",
					new String[] {"ClncAcct6114, ClncAcct6115"} );
			String query2 = "select cd.code_desc legal_jurisdiction,ca.ddt_version_id,ca.webapp_version_id,ca.*"
					+ "from customers.customer c,customers.customer_application ca,lookup.code cd"
					+ "where c.name="+ customer_Direct_USA.getCustomerName() +" and ca.customer_id=c.customer_id and cd.code_id=c.legal_jurisdiction_cd;";
			databaseResults2 = queryResults.getDDTAndWebAppVersionID(query2);
			assertions.assertEquals(databaseResults2.get("ddt_version_id") , "" , "DDT version id is not matching for USA legal jurisdiction");
			assertions.assertEquals(databaseResults2.get("webapp_version_id") , "" , "Webapp version id is not matching for USA legal jurisdition");
			
			extentReport.info("2200 V The system Verify that the Customer Main Contact account type is Allied Professional and has the Admin status granted: "
					+ "Login to PCS as Clinic Main Contact using userID and temporary password created in step 500-S by SJM Admin [to the new Clinic], "
					+ "select Clinic Administration link and view Clinic Main Contact account information.", new String[] {"ClncAcct6093"});
			
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginDirectClinic,"externaluser");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			leftNavPage.clickClinicUserLink();
			assertions.assertEquals(clinicUsersPage.verifyUserType(customer_Direct_USA.getUserid(), "Allied Professional"), true, "User type should be Allied proffessional");
			
			
			extentReport.info("1600 S The actor Case #2 - add a Type 2 Service Provider (Customer Type) Repeat steps under case one replacing Clinic with Type 2 Service Provider in the Customer Type field" );
			loginPage.login(loginSJMAdmin, "internaluser");
			assertions.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Customer List page is Displayed.");
			customerListPage.clickOnAddCustomerButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Add Customer Page is Displayed.");
			addCustomerPage.EnterValueAllfields(customer_SP_USA.getCustomerName(), userId_SP,customer_SP_USA.getCustomerType() ,
					customer_SP_USA.getClinicLocation(), customer_SP_USA.getCountryCode(), customer_SP_USA.getAreaCode(), 
					customer_SP_USA.getMainPhone(), customer_SP_USA.getCountry(), customer_SP_USA.getEmail(), customer_SP_USA.getClinicTimeZone(), 
					customer_SP_USA.getLegalJurisdiction(), customer_SP_USA.getClinicLanguage(), customer_SP_USA.getNewPassword(), 
					customer_SP_USA.getConfirmNewPassword(), customer_SP_USA.getFirstName(), customer_SP_USA.getLastName(),
					customer_SP_USA.getEmailId(), customer_SP_USA.getElecExport());
			addCustomerPage.seletCustType(customer_SP_USA);
			
			
			addCustomerPage.EnterValuesForNonMandatoryfields(customer_SP_USA.getAddress1(), customer_SP_USA.getAddress2(), customer_SP_USA.getAddress3(),
					customer_SP_USA.getStateProvince(), customer_SP_USA.getCity(), customer_SP_USA.getZipPostalCode(), customer_SP_USA.getSecondaryCountryCode(), 
					customer_SP_USA.getSecondaryAreaCode(), customer_SP_USA.getSecondaryMainPhone(), customer_SP_USA.getFaxCountryCode(), customer_SP_USA.getFaxAreaCode(),
					customer_SP_USA.getFaxMainPhone(), customer_SP_USA.getTextMessage(),customer_SP_USA.getMiddleName(), customer_SP_USA.getCredentials());
			
			
			addCustomerPage.addCustomerSave();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustomerConfirmMsg(), extentReport, "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentReport, "AD 804 popup is displayed.");
			
			
			extentReport.info("1700 V Verify that the prompt panel is displayed with text defined by <msg.ad001.prompt>", new String[] {"ClncAcct433, ClncAcct434, ClncAcct435"}  );
			String dateInString =new SimpleDateFormat("MM-dd-yyy").format(new Date());
			assertions.assertEquals(customerListPage.getHeading(), "Here's your Abbott Customer List as of " + dateInString, "Customer list page heading is matching.");
			extentReport.reportScreenShot("the prompt panel is displayed with text defined by <msg.ad001.prompt>");
			
			extentReport.info("1800 V Verify that the system shall validate the Customer data entered by actor.The Customer Profile shall contain the following details:"
					+ "Customer headquarters section: Customer Name Customer Type"
					+ "Clinic information section: Clinic Location Address (3 lines) City State/Province "
					+ "Country Zip/Postal Code Main Phone Secondary Phone Fax Text Message ID Email Clinic Language Clinic Time Zone Clinic legal jurisdiction Test Clinic CheckBox"
					+ "Clinic main contact section: User ID Password Confirm new password First Name Middle name Last Name Credentials Email"
					+ "Security Settings Minimum password length Clinic control for password expiration"
					+ "Clinic feature control section: -"
					+ " Allowed applications / Applications / Allowed applications -"
					+ " General Features / Record patient data collection consent - General Features / Display patient name (Inactive) - General Features / Allow mobile DirectAlert{tm} notification -"
					+ " Allowed DirectCallTM features / Send voice messages - Allowed DirectCallTM features / Send text messages -"
					+ " Electrophysiology features / Export transmission data files - Electrophysiology features / Export to EHR (Export to EMR/EHR Option (No Export/Manual Only/Manual and Automatic)) - Electrophysiology features / Order Transmitter - Electrophysiology features / Lockout Epic/Atlas DirectAlert{tm} check -"			
					+ " HF Application Feature controls/View RX Functionality Flag - General Device control / EP DirectAlerts{tm} Alerts / EP Allowed DirectAlerts{tm} Alerts - General Device control / DirectAlerts{tm} Notifications / Allowed DirectAlerts{tm} Notifications - General Device control / Devices / Allowed Devices - General Device control / HF DirectAlerts{tm} Alerts / HF Allowed DirectAlerts{tm} Alerts (Alert Group Control/ List of alert groups to which the clinic is authorized for each of the EP and HF application."				
					+ " Physiological Alerts Groups are specific to HF application only.)", 
					new String[] {"PCS5615", "PCS9341","ClncAcct6103", "PCS9887", "ClncAcct6491", "ClncAcct6104", "PCS10153", "PCS10154", "PCS10155", "PatAcct792", "PCS10623", "ClncAcct321", "ClncAcct6341"} );
			
			customerListPage.searchCustomerAndClick(customer_SP_USA.getCustomerName());
			assertions.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile Page is displayed");
			
			assertions.assertEquals(customerProfilePage.validateFields("CustomerName"), true, "Customer name field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("CustomerType"), true, "Customer type field is present on Customer Profile Page.");
			
			assertions.assertEquals(customerProfilePage.validateFields("ClinicLocation"), true, "Clinic location field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Address1"), true, "Address1 field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Address2"), true, "Address2 field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Address3"), true, "Address3 field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Country"), true, "Country field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("StateProvinence"), true, "State provinence field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("City"), true, "City field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Zip/PostalCode"), true, "Zip/Postal code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("CountryCode"), true, "Country code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("AreaCode"), true, "Area code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("MainPhone"), true, "Mainphone field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("SecondaryCountryCode"), true, "Secondary Country code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("SecondaryAreaCode"), true, "Secondary Area code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("SecondaryPhone"), true, "Secondary phone field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("FaxCountryCode"), true, "Fax Country code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("FaxAreaCode"), true, "Fax Area code field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Fax"), true, "Fax field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("TextMesssage"), true, "Text Messsage field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Email"), true, "Clinic email field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("ClinicTimeZone"), true, "Clinic time zone field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("LegalJurisdiction"), true, "Legal jurisdiction field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("ClinicLanguage"), true, "Clinic language field is present on Customer Profile Page.");
			
			assertions.assertEquals(customerProfilePage.validateFields("UserId"), true, "UserId field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("FirstName"), true, "First Name field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("MiddleName"), true, "Middle Name field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("LastName"), true, "Last Name field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("Credentials"), true, "Credentials field is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("ClinicMainContactEmail"), true, "Clinic Main Contact Email field is present on Customer Profile Page.");
			
			assertions.assertEquals(customerProfilePage.validateFields("AllowedApplications"), true, "Allowed Applications is present on Customer Profile Page.");		
			
			assertions.assertEquals(customerProfilePage.validateFields("PatientDataCollectionConsent"), true, "PatientDataCollectionConsent checkbox is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("MobileDirectAlerts"), true, "MobileDirectAlerts checkbox is present on Customer Profile Page.");
			
			assertions.assertEquals(customerProfilePage.validateFields("SendVoiceMessages"), true, "SendVoiceMessages checkbox is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("SendTextMessages"), true, "SendTextMessages checkbox is present on Customer Profile Page.");
			
			assertions.assertEquals(customerProfilePage.validateFields("ExportTransmission"), true, "ExportTransmission checkbox is present on Customer Profile Page.");
			assertions.assertEquals(customerProfilePage.validateFields("OrderTransmitter"), true, "OrderTransmitter checkbox is present on Customer Profile Page.");
			//The below code is added to verify Export to EHR dropdown contains the values No Export, Manual, Auto/Manual as part of step 1800 V
			customerProfilePage.clickChangeButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyEditCustLandingPage(), extentReport, "Add Customer Page is displayed in Edit mode");
			assertions.assertEquals(addCustomerPage.isDisplayExportTransDataFilesCbox(), true, "Export Transmission Data files checkbox is displayed");
			assertions.assertEquals(addCustomerPage.isDisplayOrderTransCbox(), true, "Order transmission checkbox is displayed.");
			List<String> list = new ArrayList<String>();
			list = addCustomerPage.verifyExportToEHRList();
			assertions.assertEquals(list.contains("Auto/manual"), true, "Auto/Manual option is  displayed in the Export to EHR list");
			assertions.assertEquals(list.contains("Manual"), true, "Manual option is displayed in the Export to EHR list");
			assertions.assertEquals(list.contains("No Export"), true, "No Export option is displayed in the Export to EHR list");
			
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("CustomerName"),customer_SP_USA.getCustomerName(), "Customer name is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("CustomerType"), customer_SP_USA.getCustomerType(), "Customer Type is matching with the updated data");
			
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("ClinicLocation"), customer_SP_USA.getClinicLocation(), "Customer location is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Address1"), customer_SP_USA.getAddress1(), "AddressLine1 is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Address2"), customer_SP_USA.getAddress2(), "Address Line2 is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Address3"), customer_SP_USA.getAddress3(), "Address Line3 is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("City"), customer_SP_USA.getCity(), "City is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("State/Prov"), customer_SP_USA.getStateProvince(), "State code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Country"), customer_SP_USA.getCountry(), "Country name is matching with the updated data");			
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Zip/PostalCode"), customer_SP_USA.getZipPostalCode(), "zipPostal code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("CountryCode"), customer_SP_USA.getCountryCode(), "Country Code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("AreaCode"), customer_SP_USA.getAreaCode(), "Area code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("MainPhone"), customer_SP_USA.getMainPhone(), "Main phone number is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("SecondaryCountryCode"), customer_SP_USA.getSecondaryCountryCode(), "Secondary Country Code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("SecondaryAreaCode"), customer_SP_USA.getSecondaryAreaCode(), "Secondary Area code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("SecondaryPhone"), customer_SP_USA.getSecondaryMainPhone(), "Secondary Main phone number is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("FaxCountryCode"), customer_SP_USA.getFaxCountryCode(), "Fax Country Code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("FaxAreaCode"), customer_SP_USA.getFaxAreaCode(), "Fax Area code is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Fax"), customer_SP_USA.getFaxMainPhone(), "Fax Main phone number is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("TextMessage"), customer_SP_USA.getTextMessage(), "Text Message is matching with the updated data");		
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Email"), customer_SP_USA.getEmail(), "Email is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("ClinicTimeZone"), customer_SP_USA.getClinicTimeZone(), "ClinicTimeZone is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("LegalJurisdiction"), customer_SP_USA.getLegalJurisdiction(), "LegalJurisdiction is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("ClinicLanguage"), customer_SP_USA.getClinicLanguage(), "Clinic Language is matching with the updated data");

			
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("UserID"), customer_SP_USA.getUserid(), "User ID is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("FirstName"), customer_SP_USA.getFirstName(), "First Name is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("MiddleName"), customer_SP_USA.getMiddleName(), "Middle Name is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("LastName"), customer_SP_USA.getLastName(), "Last Name is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Credentials"), customer_SP_USA.getCredentials(), "Credentials is matching with the updated data");
			assertions.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("MainContactEmail"), customer_SP_USA.getEmailId(), "MainContactEmail is matching with the updated data");
									
			
			extentReport.info("1900 V General Device Control: (Customer Profile Details - Feature Controls) This is a list of devices the clinic is authorized to "
					+ "use when enrolling patients for EP and HF application, based upon jurisdiction. "
					+ "> See Matrix Configuration for Devices, and availability of device models based on jurisdiction", new String[] {"ClncAcct6107"});
			//customerListPage.searchWithExactCustomerNameAndClick(customer_SP_USA.getCustomerName());
			//Need to work on this once we get clarification from praveen on devices
			viewCustomerPage.jurisdictionAllowedDeviceValidation();
			
			extentReport.info("2000 V Alert Group Control: (Customer Profile Details - Feature Controls) "
					+ "This is a list of alert groups to which the clinic is authorized for each of the EP and HF application, "
					+ "selected from the Alert Groups marked as relevant for each of those applications based on jurisdiction. "
					+ "Physiological Alert Groups are specific to the HF application only. See Alerts Configuration for the list of supported Alert Groups, "
					+ "associated application relevance: EP, HF or both and availability of alerts based on jurisdiction.", new String[] {"ClncAcct6665"});
			//Need to work on this once we get clarification from praveen on alerts
			viewCustomerPage.jurisdictionAlertValidation("allowed_ep_directAlert_4NBLE_S");
			
			//Need to move this step at appropriate place
			extentReport.info("2100 V The system Verify that the customer is created from the data entered. "
					+ "Also verify that system shall also confirm that a new customer has been created by displaying the following: "
					+ "The system displays AD 804 (customer added) dialog with text defined by <msg.ad804.text> "
					+ "(\"Thanks. Your [location/customer/SJM DMR person] has been added.\") <ClncAcct178>,<ClncAcct6096>", new String[] {"ClncAcct178, ClncAcct6096"});			
			
			assertions.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport,"Customer List page is displayed");
			assertions.assertEquals(customerListPage.searchCustomer(customer_SP_USA.getCustomerName()), customer_SP_USA.getCustomerName());
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentReport, "AD 804 popup is displayed.");
						
			
			extentReport.info("2300 V The System \"DirectAlertsTM Notification allowed for patients\" Control should be displayed under clinic feature control section "
					+ "This is a list of special alert groups for patient notification to which the clinic is authorized for the EP application, "
					+ "selected from the display groups available and marked as relevant for the EP application. "
					+ "{See Alerts Configuration for the list of supported Alert Groups, Display Group Availability and associated application relevance: EP, HF or both} ", new String[] {"ClncAcct6106"});
			assertions.assertEqualsWithReporting(true,customerProfilePage.validationDirectAlertsForPatientsAvailability(), extentReport, "Patients Direct Alerts are under Clinic feature control section");
			//Need to work on this once we get clarification from praveen on alerts
			viewCustomerPage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
			extentReport.reportScreenShot("Patients Direct Alerts are under Clinic feature control section");			
			
			extentReport.info("2400 S Click on 'Add a customer' link in right navigation panel.");
			customerListPage.clickOnAddCustomerButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Click on 'Add a customer' link in right navigation panel is successful");
			
			extentReport.info("2500 S Select legal jurisdiction as  'European Union', fill in other mandatory fields and Click on 'Save button'");
			addCustomerPage.EnterValueAllfields(customer_Direct_Europe.getCustomerName(), userId_Direct,customer_Direct_Europe.getCustomerType() ,
					customer_Direct_Europe.getClinicLocation(), customer_Direct_Europe.getCountryCode(), customer_Direct_Europe.getAreaCode(), 
					customer_Direct_Europe.getMainPhone(), customer_Direct_Europe.getCountry(), customer_Direct_Europe.getEmail(), customer_Direct_Europe.getClinicTimeZone(), 
					customer_Direct_Europe.getLegalJurisdiction(), customer_Direct_Europe.getClinicLanguage(), customer_Direct_Europe.getNewPassword(), 
					customer_Direct_Europe.getConfirmNewPassword(), customer_Direct_Europe.getFirstName(), customer_Direct_Europe.getLastName(),
					customer_Direct_Europe.getEmailId(), customer_Direct_Europe.getElecExport());
			addCustomerPage.addCustomerSave();
			
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustomerConfirmMsg(), extentReport, "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentReport, "Customer with European Union jurisdiction is created successfully.");
			
			extentReport.info("2600 V Repeat step 1530 V. For European Union the default preference is enabled.", new String[] {"ClncAcct6745", "Config21436"});
			String query3 = "select cd.code_desc legal_jurisdiction,ca.ddt_version_id,ca.webapp_version_id,ca.*"
					+ "from customers.customer c,customers.customer_application ca,lookup.code cd"
					+ "where c.name="+ customer_Direct_Europe.getCustomerName() +" and ca.customer_id=c.customer_id and cd.code_id=c.legal_jurisdiction_cd;";
			databaseResults2 = queryResults.getDDTAndWebAppVersionID(query3);
			assertions.assertEquals(databaseResults2.get("ddt_version_id") , "" , "DDT version id is matching for USA legal jurisdiction");
			assertions.assertEquals(databaseResults2.get("webapp_version_id") , "" , "Webapp version id is matching for USA legal jurisdition");
			
			extentReport.info("2700 S Repeat steps 1900 S to 2100 V for all other legal jurisdictions i.e. 'Canada', 'Australia/New Zealand' and 'Japan'", new String[] {"Config21437", "Config21438", "Config21439"});
			//Canada Jurisdiction
			customerListPage.clickOnAddCustomerButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Add Customer Page is displayed");
			
			addCustomerPage.EnterValueAllfields(customer_Direct_Canada.getCustomerName(), userId_Canada,customer_Direct_Canada.getCustomerType() ,
					customer_Direct_Canada.getClinicLocation(), customer_Direct_Canada.getCountryCode(), customer_Direct_Canada.getAreaCode(), 
					customer_Direct_Canada.getMainPhone(), customer_Direct_Canada.getCountry(), customer_Direct_Canada.getEmail(), customer_Direct_Canada.getClinicTimeZone(), 
					customer_Direct_Canada.getLegalJurisdiction(), customer_Direct_Canada.getClinicLanguage(), customer_Direct_Canada.getNewPassword(), 
					customer_Direct_Canada.getConfirmNewPassword(), customer_Direct_Canada.getFirstName(), customer_Direct_Canada.getLastName(),
					customer_Direct_Canada.getEmailId(), customer_Direct_Canada.getElecExport());
			addCustomerPage.addCustomerSave();
			
			
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustomerConfirmMsg(), extentReport, "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentReport, "Customer with Canada jurisdiction is created successfully.");
			
			//Australia/Newzealand Jurisdiction
			customerListPage.clickOnAddCustomerButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Add Customer Page is displayed");
			
			addCustomerPage.EnterValueAllfields(customer_Direct_Australia.getCustomerName(), userId_Direct,customer_Direct_Australia.getCustomerType() ,
					customer_Direct_Australia.getClinicLocation(), customer_Direct_Australia.getCountryCode(), customer_Direct_Australia.getAreaCode(), 
					customer_Direct_Australia.getMainPhone(), customer_Direct_Australia.getCountry(), customer_Direct_Australia.getEmail(), customer_Direct_Australia.getClinicTimeZone(), 
					customer_Direct_Australia.getLegalJurisdiction(), customer_Direct_Australia.getClinicLanguage(), customer_Direct_Australia.getNewPassword(), 
					customer_Direct_Australia.getConfirmNewPassword(), customer_Direct_Australia.getFirstName(), customer_Direct_Australia.getLastName(),
					customer_Direct_Australia.getEmailId(), customer_Direct_Australia.getElecExport());
			addCustomerPage.addCustomerSave();
			
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustomerConfirmMsg(), extentReport, "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentReport, "Customer with Australia/Newzealand jurisdiction is created successfully.");
			
			//Japan Jurisdiction
			customerListPage.clickOnAddCustomerButton();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Add Customer Page is displayed");
			
			addCustomerPage.EnterValueAllfields(customer_Direct_Japan.getCustomerName(), userId_Japan,customer_Direct_Japan.getCustomerType() ,
					customer_Direct_Japan.getClinicLocation(), customer_Direct_Japan.getCountryCode(), customer_Direct_Japan.getAreaCode(), 
					customer_Direct_Japan.getMainPhone(), customer_Direct_Japan.getCountry(), customer_Direct_Japan.getEmail(), customer_Direct_Japan.getClinicTimeZone(), 
					customer_Direct_Japan.getLegalJurisdiction(), customer_Direct_Japan.getClinicLanguage(), customer_Direct_Japan.getNewPassword(), 
					customer_Direct_Japan.getConfirmNewPassword(), customer_Direct_Japan.getFirstName(), customer_Direct_Japan.getLastName(),
					customer_Direct_Japan.getEmailId(), customer_Direct_Japan.getElecExport());
			addCustomerPage.addCustomerSave();
			
			extentReport.info("2800 V Verify that he System shall confirm a new Customer has been created and check if the user wants to add a new location", new String[] {"ClncAcct6096"});
			assertions.assertTrue(addCustomerPage.verifyAddCustomerConfirmMsg(), "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertions.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "Customer with Japan jurisdiction is created successfully.");			
			
			
//			extentReport.info("2900 V-Verify If the user initiates creation of a new location, the use case shall restart at step 50 of the Basic Flow. "
//					+ "Else, use case goes to next step.", new String[] {"ClncAcct6095"});
			
			 assertions.assertAll();
			
			
			 
			
		}  catch (AssertionError e) {
			extentReport.reportFail( "10.0Rev1_WA_UC013A-B01-01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "10.0Rev1_WA_UC013A-B01-01 is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}
	private Login getLoginCredentials(Customer cust) {
		Login loginData = new Login();
		loginData.setIteration("1");
		loginData.setUserName(cust.getUserid());
		loginData.setPassword(cust.getNewPassword());
		return loginData;
		
	}
	
}

