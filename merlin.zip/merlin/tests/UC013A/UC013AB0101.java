package com.test.qa.ui.tests.UC013A;

import static org.testng.Assert.assertEquals;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicSettings_ReportSettingsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_CardiacMonitorPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

import net.bytebuddy.implementation.MethodDelegation.WithCustomProperties;

/*
 * Author: Vrushali Hitendra Barhate
 * Test Case: UC013AB0101
 * Report: Good
 */

public class UC013AB0101 extends CommonUtils {

	CustomerListPage customerListPage;
	CustomerProfilePage customerProfilePage;
	AppHomeTopNavPage appHomeTopNavPage;
	AddCustomerPage addCustomerPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CA_LeftNavPage leftNavPage;
	CA_ClinicUsers clinicUsersPage;
	ViewCustomerPage viewCustomerPage;
	
	LoginPageWithPOJO loginPage;
	Login loginSJMAdmin;
	Login loginDirectClinic;
	Customer customerDirect;
	Customer customerSP;
	Customer custJapanDirect;
	Customer custCanadaDirect;
	Customer custEuropeDirect;
	Customer custAustreliaDirect;
	QueryResults queryResults;
	
	int deleted_flg;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	DataBaseConnector dataBaseConnector;
	Map<String, String> databaseResults;
	Map<String, String> databaseResults2;

	@BeforeClass
	public void initialize() {
		
		customerListPage = new CustomerListPage(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		leftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicUsersPage = new CA_ClinicUsers(driver, extentReport);
		viewCustomerPage = new ViewCustomerPage(driver, extentReport);
		dataBaseConnector = new DataBaseConnector();
		loginSJMAdmin = new Login();
		loginDirectClinic = new Login();
		customerDirect = new Customer();
		customerSP = new Customer();
		custEuropeDirect = new Customer();
		custJapanDirect = new Customer();
		custCanadaDirect = new Customer();
		custAustreliaDirect = new Customer();
		testDataProvider = new TestDataProvider();
		
		databaseResults = new HashMap<String,String>();
		databaseResults2 = new HashMap<String,String>();
	}

	@Test
	public void UC013A_B0101_SJM_EA_Enroll_Customer() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		
		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			
			loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
			loginDirectClinic = testDataProvider.getLoginData("UC013AB0101 New User");
			
			customerDirect = testDataProvider.getCustomerData(testName + "_Direct");
			customerSP = testDataProvider.getCustomerData(testName + "_SP");
			custAustreliaDirect = testDataProvider.getCustomerData(testName + "_Austrelia");
			custEuropeDirect = testDataProvider.getCustomerData(testName + "_Europe");
			custJapanDirect = testDataProvider.getCustomerData(testName + "_Japan");
			custCanadaDirect = testDataProvider.getCustomerData(testName + "_Canada");
			
			String userId_Japan = CommonUtils.randomUserId();
			custJapanDirect.setUserid(userId_Japan);
			custJapanDirect.setCustomerName(userId_Japan);
			
			String userId_Canada = CommonUtils.randomUserId();
			custCanadaDirect.setUserid(userId_Canada);
			custCanadaDirect.setCustomerName(userId_Canada);
			
			String userId_Europe = CommonUtils.randomUserId();
			custEuropeDirect.setUserid(userId_Europe);
			custEuropeDirect.setCustomerName(userId_Europe);
			
			String userId_Aus = CommonUtils.randomUserId();
			custAustreliaDirect.setUserid(userId_Aus);
			custAustreliaDirect.setCustomerName(userId_Aus);
			
			String userId_Direct = CommonUtils.randomUserId();
			customerDirect.setUserid(userId_Direct);
			customerDirect.setCustomerName(userId_Direct);
		
			String userId_SP = CommonUtils.randomUserId();
			customerSP.setUserid(userId_SP);
			customerSP.setCustomerName(userId_SP);
			
			extentReport.info("100 S The actor (SJM Enrollment Administrator) is logged into the Merlin.net system and navigates to Customer List page ");
			loginPage.login(loginSJMAdmin, "internaluser");	
			assertion.assertEquals(customerListPage.verifyLandingPage(), true , "Customer List page is displayed");
			
			extentReport.info("200 V Verify that Customer List page is displayed.");
			assertion.assertEquals(customerListPage.verifyLandingPage(), true , "Customer List page is displayed");
			
			extentReport.info("300 S The actor clicks the \"Add a customer\" button ");
			customerListPage.clickOnAddCustomerButton();
			assertion.assertEquals(addCustomerPage.verifyLandingPage() , true , "Add Customer Page is displayed");
			
			extentReport.info("400 V The system displays Add Customer Page also verify that the system shall provide the capacity for the actor to enter new customer data." , new String[] {"ClncAcct189"});
//			addCustomerPage.addCustomerfieldupdate(newCustomer, testName);
//			addCustomerPage.FieldVerfication("CustomerName");
//			addCustomerPage.FieldVerfication("ClinicLocation");
//			addCustomerPage.FieldVerfication("Mainphone");
//			addCustomerPage.FieldVerfication("Email");
//			addCustomerPage.FieldVerfication("Clinictimezone");
//			addCustomerPage.FieldVerfication("Cliniclegaljurisdiction");
//			addCustomerPage.FieldVerfication("UserID");
//			addCustomerPage.FieldVerfication("Password");
//			addCustomerPage.FieldVerfication("ConfirmNewPassword");
//			addCustomerPage.FieldVerfication("Firstname");
//			addCustomerPage.FieldVerfication("Lastname");
//			addCustomerPage.FieldVerfication("AddCustomer");
			
			extentReport.info("450 V Verify 'Direct' and 'SP2\" types of customer support by PCS are available:\n" + 
					"Direct - This type of customer uses PCS to view patient records. "+
					"All Physicians and Allied Professionals for a Clinic can view all patients records that belong to the Clinic. " +
					"Patients must be added to the Clinic manually for transmissions to be associated with the patient.\n" + 
					"Type 2 SP - This customer uses PCS to view patient records."+
					"Allied Professionals for a Type 2 SP can view all patients records that belong to the Clinic." +
					"Physicians for a Type 2 SP can only view patient records that have been explicitly assigned to their account " +
					"or that have been assigned to one of the locations to which the Physician's account has been granted visibility. "+
					"Patients must be added to the Type 2 SP manually for transmissions to be associated with the patient", 
					new String[] {"ClncAcct316"});
			
			//Verify 'Direct' and 'SP2" types of customer support by PCS are available
			assertion.assertEquals(true, addCustomerPage.verifyCustType(), "Direct and Service provider customer types are available in dropdown");
			
			
			extentReport.info("500 S Case #1 - add a Direct (Customer Type) The actor selects \"Direct\" in the Customer Type field, " + 
					"and enters valid and required information in the Customer headquarters, Clinic location, Clinic main contact, " + 
					"and Clinic feature control sections."
					+ "700 S Select legal jurisdiction as USA");
			
			addCustomerPage.EnterValueAllfields(customerDirect.getCustomerName(), userId_Direct,customerDirect.getCustomerType() ,
					customerDirect.getClinicLocation(), customerDirect.getCountryCode(), customerDirect.getAreaCode(), 
					customerDirect.getMainPhone(), customerDirect.getCountry(), customerDirect.getEmail(), customerDirect.getClinicTimeZone(), 
					customerDirect.getLegalJurisdiction(), customerDirect.getClinicLanguage(), customerDirect.getNewPassword(), 
					customerDirect.getConfirmNewPassword(), customerDirect.getFirstName(), customerDirect.getLastName(),
					customerDirect.getEmailId(), customerDirect.getElecExport());
			
			extentReport.info("750 S Click Save button");
			addCustomerPage.addCustomerSave();
			
			
			extentReport.info("760 V Verify that the system displays AD 806 with text msg.ad806.text.");
			assertion.assertEquals(addCustomerPage.verifyAddCustomerConfirmMsg(), true ,  "Add customer successfull and add another physical location confirmation popup is displayed.");
			
			extentReport.info("800 S The actor clicks the Cancel button on AD 806 ");
			addCustomerPage.addCustomerConfirmCancel();
			
			extentReport.info("900 V The system displays AD 804 (customer added) alert box with text  msg.ad804.text.", 
					new String[] {"ClncAcct6587"} );
			extentReport.info("1000 S The actor clicks the Okay button on the AD 804 alert box ");
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "AD 804 popup is displayed.");
			
			extentReport.info("600 V The �headquarters� location for a customer shall be the one specified during initial creation of the customer. "+
					"The system creates the Customer and Customer Account, and stores details in the database "+
					"(Tables: CUSTOMER, ADDRESS, LOCATION, CUSTOMER_ACCOUNT, USER_RECORD) and passwords in LDAP Check database if customer is added with correct Type_Cd",
					new String[] {"ClncAcct318"});
			customerListPage.customerSearch(customerDirect.getCustomerName());
			assertion.assertEquals(customerDirect.getClinicLocation(), customerListPage.getCustomerLocationByCustName(customerDirect.getCustomerName()), "Customer location is not matching in customer list page,");
			String userId = changeCustomerProfilePage.getUserId();
			String query = "select ur.logon_user_name ,c.name ,c.email_address,ca.street_address,ca.street_address2 ,"+
							"ca.city as city,(SELECT code_desc FROM lookup.code cd"+ 
							" where cd.code_id= ca.state_cd"+
							" and cd.code_qualifier ='State_Cd') as State_Code,ca.zip_code,"+ 
							" (SELECT code_desc FROM lookup.code cd"+
							" where cd.code_id=c.legal_jurisdiction_cd "+
							" and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction,"+
							" (SELECT code_desc FROM lookup.code cd where cd.code_id=c.locale_cd and cd.code_qualifier ='Language_Cd') as language,"+
							" area_code as area_code,phone_num as main_phone "+
							" FROM customers.customer c ,customers.customer_phone cp ,customers.customer_address ca, users.user_record ur," +
							" users.customer_account ca2 where c.main_phone_id = cp.customer_phone_id"+
							" and c.customer_address_id = ca.customer_address_id"+
							" and c.customer_id = ca2.customer_id and ca2.user_record_id = ur.user_record_id"+ 
							" and ur.logon_user_name ='"+userId+"'";
			databaseResults = queryResults.customerTable_TC1234183(query);
			assertion.assertEquals(databaseResults.get("clinicName"),customerDirect.getCustomerName(),"Clinic name field is verified");
			assertion.assertEquals(databaseResults.get("logon_user_name"),customerDirect.getCustomerName(),"Log in clinic user field is verified");
			assertion.assertEquals(databaseResults.get("area_code"),customerDirect.getAreaCode(),"Area code field is verified");
			assertion.assertEquals(databaseResults.get("main_phone"),customerDirect.getMainPhone(),"Phone Number field is verified");
			assertion.assertEquals(databaseResults.get("customerEmailAddress"),customerDirect.getEmail(), "Email address field is verified");
			assertion.assertEquals(databaseResults.get("addressLine1"),customerDirect.getAddress1(), "AddressLine1 field is verified");
			assertion.assertEquals(databaseResults.get("addressLine2"),customerDirect.getAddress2(), "AddressLine2 field is verified");
			assertion.assertEquals(databaseResults.get("city"),customerDirect.getCity(), "City field is verified");
			assertion.assertEquals(databaseResults.get("stateCode"),customerDirect.getStateProvince(), "stateCode field is verified");
			assertion.assertEquals(databaseResults.get("zipCode"),customerDirect.getZipPostalCode(), "zipCode field is verified");
			assertion.assertEquals(databaseResults.get("legal_jurisdiction"),customerDirect.getLegalJurisdiction(), "Legal Jurisdiction field is verified");
			assertion.assertEquals(databaseResults.get("language"), customerDirect.getClinicLanguage(),"Clinic Language field is verified");
			
			extentReport.info("1100 V The system displays Customer List Page and the list of customers displayed on page should include the customer just added. ");
			assertion.assertEquals(customerListPage.verifyLandingPage(), true , "Customer List page is not displayed");
			assertion.assertEquals(customerListPage.searchCustomer(customerDirect.getCustomerName()), true , customerDirect.getCustomerName());
			
			extentReport.info("1150 V Verify webapp version ID and DDT version ID "
					+ "from Customer_application table are populated with correct values corresponding to Legal Jurisdiction.",
					new String[] {"ClncAcct6114, ClncAcct6115"} );
			String query2 = "select cd.code_desc legal_jurisdiction,ca.ddt_version_id,ca.webapp_version_id,ca.*"
					+ "from customers.customer c,customers.customer_application ca,lookup.code cd"
					+ "where c.name="+ customerDirect.getCustomerName() +" and ca.customer_id=c.customer_id and cd.code_id=c.legal_jurisdiction_cd;";
			databaseResults2 = queryResults.getDDTAndWebAppVersionID(query2);
			assertion.assertEquals(databaseResults2.get("ddt_version_id") , "" , "DDT version id is matching for USA legal jurisdiction");
			assertion.assertEquals(databaseResults2.get("webapp_version_id") , "" , "Webapp version id is matching for USA legal jurisdition");
			
			extentReport.info("1200 S The actor Case #2 - add a Type 2 Service Provider (Customer Type) Repeat steps under case one replacing Clinic with Type 2 Service Provider in the Customer Type field." );
			customerListPage.clickOnAddCustomerButton();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport, "Add Customer Page is Displayed.");
			addCustomerPage.EnterValueAllfields(customerSP.getCustomerName(), userId_Direct,customerSP.getCustomerType() ,
					customerSP.getClinicLocation(), customerSP.getCountryCode(), customerSP.getAreaCode(), 
					customerSP.getMainPhone(), customerSP.getCountry(), customerSP.getEmail(), customerSP.getClinicTimeZone(), 
					customerSP.getLegalJurisdiction(), customerSP.getClinicLanguage(), customerSP.getNewPassword(), 
					customerSP.getConfirmNewPassword(), customerSP.getFirstName(), customerSP.getLastName(),
					customerSP.getEmailId(), customerSP.getElecExport());
			addCustomerPage.seletCustType(customerSP);
						
			addCustomerPage.EnterValuesForNonMandatoryfields(customerSP.getAddress1(), customerSP.getAddress2(), customerSP.getAddress3(),
					customerSP.getStateProvince(), customerSP.getCity(), customerSP.getZipPostalCode(), customerSP.getSecondaryCountryCode(), 
					customerSP.getSecondaryAreaCode(), customerSP.getSecondaryMainPhone(), customerSP.getFaxCountryCode(), customerSP.getFaxAreaCode(),
					customerSP.getFaxMainPhone(), customerSP.getTextMessage(),customerSP.getMiddleName(), customerSP.getCredentials());
			
			addCustomerPage.addCustomerSave();
			Assert.assertTrue(addCustomerPage.verifyAddCustomerConfirmMsg(), "Add customer successful and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "SP2 customer has got created successfully");
			
			extentReport.info("1600 V The system Verify that the customer is created from the data entered. Also verify that system shall also confirm that a new customer has been created by displaying the following: The system displays AD 804 (customer added) dialog with text defined by <msg.ad804.text> (\"Thanks. Your [location/customer/SJM DMR person] has been added.\")", new String[] {"ClncAcct178, ClncAcct6096"});
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "AD 804 popup is displayed.");
			Assert.assertTrue(customerListPage.verifyLandingPage(), "Customer List page is displayed");
			Assert.assertEquals(customerListPage.searchCustomer(customerSP.getCustomerName()), customerSP.getCustomerName());
			
			
			extentReport.info("1300 V Verify that the prompt panel is displayed with text defined by <msg.ad001.prompt>", new String[] {"ClncAcct433, ClncAcct434, ClncAcct435"}  );
			String dateInString =new SimpleDateFormat("MM-dd-yyy").format(new Date());
			assertion.assertEquals(customerListPage.getHeading(), "Here's your Abbott Customer List as of " + dateInString, "Customer list page heading is matching with the application.");
			
			extentReport.info("1400 V Verify that the system shall validate the Customer data entered by actor. The Customer Profile shall contain the following details:" + 
					"Clinic information section: Clinic Location Address (3 lines) City State/Province Country Zip/Postal Code Main Phone Secondary Phone Fax Text Message ID Email Clinic Language Clinic Time Zone Clinic legal jurisdiction Test Clinic Check Box" + 
					"Clinic main contact section: User ID Password Confirm new password First Name Middle name Last Name Credentials Email" + 
					"Security Settings Minimum password length Clinic control for password expiration" + 
					"Clinic feature control section: -" + 
					"Allowed applications / Applications / Allowed applications -" + 
					"General Features / Record patient data collection consent - General Features / Display patient name (Inactive) - General Features / Allow mobile DirectAlert{tm} notification -" + 
					"Allowed DirectCallTM features / Send voice messages - Allowed DirectCallTM features / Send text messages -" + 
					"- Electrophysiology features / Export transmission data files - Electrophysiology features / Export to EHR (Export to EMR/EHR Option (No Export/Manual Only/Manual and Automatic)) - Electrophysiology features / Order Transmitter", 
					new String[] {"PCS5615, PCS9341, ClncAcct6103, PCS9887, ClncAcct6491, ClncAcct6104, PCS10153, PCS10154, PCS10155, PatAcct792, PCS10623, ClncAcct321, ClncAcct6341"} );
			
			customerListPage.searchCustomerAndClick(customerSP.getCustomerName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile Page is displayed");
			
			assertion.assertEquals(customerProfilePage.validateFields("CustomerName"), true, "Customer name field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("CustomerType"), true, "Customer type field is present on Customer Profile Page.");
			
			assertion.assertEquals(customerProfilePage.validateFields("ClinicLocation"), true, "Clinic location field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Address1"), true, "Address1 field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Address2"), true, "Address2 field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Address3"), true, "Address3 field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Country"), true, "Country field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("StateProvinence"), true, "State provinence field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("City"), true, "City field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Zip/PostalCode"), true, "Zip/Postal code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("CountryCode"), true, "Country code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("AreaCode"), true, "Area code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("MainPhone"), true, "Mainphone field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("SecondaryCountryCode"), true, "Secondary Country code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("SecondaryAreaCode"), true, "Secondary Area code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("SecondaryPhone"), true, "Secondary phone field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("FaxCountryCode"), true, "Fax Country code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("FaxAreaCode"), true, "Fax Area code field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Fax"), true, "Fax field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("TextMesssage"), true, "Text Messsage field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Email"), true, "Clinic email field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("ClinicTimeZone"), true, "Clinic time zone field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("LegalJurisdiction"), true, "Legal jurisdiction field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("ClinicLanguage"), true, "Clinic language field is present on Customer Profile Page.");
			
			assertion.assertEquals(customerProfilePage.validateFields("UserId"), true, "UserId field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("FirstName"), true, "First Name field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("MiddleName"), true, "Middle Name field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("LastName"), true, "Last Name field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("Credentials"), true, "Credentials field is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("ClinicMainContactEmail"), true, "Clinic Main Contact Email field is present on Customer Profile Page.");
			
			assertion.assertEquals(customerProfilePage.validateFields("AllowedApplications"), true, "Allowed Applications is present on Customer Profile Page.");		
			
			assertion.assertEquals(customerProfilePage.validateFields("PatientDataCollectionConsent"), true, "PatientDataCollectionConsent checkbox is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("MobileDirectAlerts"), true, "MobileDirectAlerts checkbox is present on Customer Profile Page.");
			
			assertion.assertEquals(customerProfilePage.validateFields("SendVoiceMessages"), true, "SendVoiceMessages checkbox is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("SendTextMessages"), true, "SendTextMessages checkbox is present on Customer Profile Page.");
			
			assertion.assertEquals(customerProfilePage.validateFields("ExportTransmission"), true, "ExportTransmission checkbox is present on Customer Profile Page.");
			assertion.assertEquals(customerProfilePage.validateFields("OrderTransmitter"), true, "OrderTransmitter checkbox is present on Customer Profile Page.");
			
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("CustomerName"),customerSP.getCustomerName(), "Customer name is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("CustomerType"), customerSP.getCustomerType(), "Customer Type is matching with the updated data");
			
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("ClinicLocation"), customerSP.getClinicLocation(), "Customer location is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Address1"), customerSP.getAddress1(), "AddressLine1 is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Address2"), customerSP.getAddress2(), "Address Line2 is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Address3"), customerSP.getAddress3(), "Address Line3 is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("City"), customerSP.getCity(), "City is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("State/Prov"), customerSP.getStateProvince(), "State code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Country"), customerSP.getCountry(), "Country name is matching with the updated data");			
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Zip/PostalCode"), customerSP.getZipPostalCode(), "zipPostal code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("CountryCode"), customerSP.getCountryCode(), "Country Code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("AreaCode"), customerSP.getAreaCode(), "Area code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("MainPhone"), customerSP.getMainPhone(), "Main phone number is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("SecondaryCountryCode"), customerSP.getSecondaryCountryCode(), "Secondary Country Code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("SecondaryAreaCode"), customerSP.getSecondaryAreaCode(), "Secondary Area code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("SecondaryPhone"), customerSP.getSecondaryMainPhone(), "Secondary Main phone number is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("FaxCountryCode"), customerSP.getFaxCountryCode(), "Fax Country Code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("FaxAreaCode"), customerSP.getFaxAreaCode(), "Fax Area code is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Fax"), customerSP.getFaxMainPhone(), "Fax Main phone number is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("TextMessage"), customerSP.getTextMessage(), "Text Message is matching with the updated data");		
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Email"), customerSP.getEmail(), "Email is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("ClinicTimeZone"), customerSP.getClinicTimeZone(), "ClinicTimeZone is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("LegalJurisdiction"), customerSP.getLegalJurisdiction(), "LegalJurisdiction is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("ClinicLanguage"), customerSP.getClinicLanguage(), "Clinic Language is matching with the updated data");
			
			
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("UserID"), customerSP.getUserid(), "User ID is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("FirstName"), customerSP.getFirstName(), "First Name is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("MiddleName"), customerSP.getMiddleName(), "Middle Name is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("LastName"), customerSP.getLastName(), "Last Name is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("Credentials"), customerSP.getCredentials(), "Credentials is matching with the updated data");
			assertion.assertEquals(customerProfilePage.VerifyCustomerDataInViewMode("MainContactEmail"), customerSP.getEmailId(), "MainContactEmail is matching with the updated data");
						
			extentReport.info("1500 v Export transmission data files Flag - controls whether or not clinic can export transmission archive data" + 
					"Export to EMR/EHR Option (None/Manual Only/Manual and Automatic)" + 
					"Set default for Order Transmitter to ON Flag - controls clinic's ability to Order Transmitter", new String[] {"ClncAcct6811 , ClncAcct6835"});
			
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyEditCustLandingPage(), extentTest, "");
			assertion.assertEquals(addCustomerPage.isDisplayExportTransDataFilesCbox(), true, "Export Transmission Data files checkbox is visible");
			assertion.assertEquals(addCustomerPage.isDisplayOrderTransCbox(), true, "Order transmission checkbox is displayed.");
			List<String> list = new ArrayList<String>();
			list = addCustomerPage.verifyExportToEHRList();
			assertion.assertEquals(list.contains("Auto/manual"), true, "Auto/Manual option is displayed in the Export to EHR list");
			assertion.assertEquals(list.contains("Manual"), true, "Manual option is displayed in the Export to EHR list");
			assertion.assertEquals(list.contains("No Export"), true, "No Export option is displayed in the Export to EHR list");
			
			extentReport.info("1560 V General Device Control: (Customer Profile Details - Feature Controls) This is a list of devices the clinic is authorized to use when enrolling patients for EP and HF application, based upon jurisdiction. > See Matrix Configuration for Devices, and availability of device models based on jurisdiction", new String[] {"ClncAcct6107"});
			// query need to be raised to Pravven for expected list of devices
			
			
			
			extentReport.info("1700 V The system Verify that the Customer Main Contact account type is Allied Professional and has the Admin status granted: "+
					"Login to PCS as Clinic Main Contact using userID and temporary password created in step 500-S by SJM Admin [to the new Clinic], " +
					"select Clinic Administration link and view Clinic Main Contact account information. ", new String[] {"ClncAcct6093"});
			
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginDirectClinic, "externaluser");
			clinicianHomeTopNavPage.navigateToClinicAdministrationLink();
			leftNavPage.clickClinicUserLink();
			assertion.assertEquals(clinicUsersPage.verifyUserType(customerDirect.getUserid(), "Allied Professional"), true, "User type is Allied proffessional");
			
			extentReport.info("1800 V The System \"DirectAlertsTM Notification allowed for patients\" Control should be displayed under clinic feature control section This is a list of special alert groups for patient notification to which the clinic is authorized for the EP application, selected from the display groups available and marked as relevant for the EP application. {See Alerts Configuration for the list of supported Alert Groups, Display Group Availability and associated application relevance: EP, HF or both} ", new String[] {"ClncAcct6106"});
			appHomeTopNavPage.clickSignOutLink();
			loginPage.login(loginSJMAdmin, "internaluser");
			customerListPage.customerSearch(customerSP.getCustomerName());
			viewCustomerPage.jurisdictionAlertValidation("allowed_ep_Devices_S");
			
			extentReport.info("1900 S Click on 'Add a customer' link in right navigation panel.");
			
			customerListPage.clickOnAddCustomerButton();
			Assert.assertTrue(addCustomerPage.verifyLandingPage(), "Add Customer Page is displayed");
			
			extentReport.info("2000 S Select legal jurisdiction as  'European Union', fill in other mandatory fields and Click on 'Save button'");
			addCustomerPage.EnterValueAllfields(custEuropeDirect.getCustomerName(), userId_Europe,custEuropeDirect.getCustomerType() ,
					custEuropeDirect.getClinicLocation(), custEuropeDirect.getCountryCode(), custEuropeDirect.getAreaCode(), 
					custEuropeDirect.getMainPhone(), custEuropeDirect.getCountry(), custEuropeDirect.getEmail(), custEuropeDirect.getClinicTimeZone(), 
					custEuropeDirect.getLegalJurisdiction(), custEuropeDirect.getClinicLanguage(), custEuropeDirect.getNewPassword(), 
					custEuropeDirect.getConfirmNewPassword(), custEuropeDirect.getFirstName(), custEuropeDirect.getLastName(),
					custEuropeDirect.getEmailId(), custEuropeDirect.getElecExport());
			addCustomerPage.addCustomerSave();
			
			extentReport.info("2200 V Verify that he System shall confirm a new Customer has been created and check if the user wants to add a new location", new String[] {"ClncAcct6096"});
			assertion.assertTrue(addCustomerPage.verifyAddCustomerConfirmMsg(), "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "Customer with European Union jurisdiction is created successfully.");
			
			extentReport.info("2100 S Repeat steps 1900 S to 2000 V for all other legal jurisdictions i.e. 'Canada', 'Australia/New Zealand' and 'Japan' "
					+ "and verify the default GDC2 collection preference.", new String[] {"Config21437, Config21438, Config21439"});
			
			//Canada Jurisdiction
			customerListPage.clickOnAddCustomerButton();
			Assert.assertTrue(addCustomerPage.verifyLandingPage(), "Add Customer Page is not displayed");
			
			addCustomerPage.EnterValueAllfields(custCanadaDirect.getCustomerName(), userId_Canada,custCanadaDirect.getCustomerType() ,
					custCanadaDirect.getClinicLocation(), custCanadaDirect.getCountryCode(), custCanadaDirect.getAreaCode(), 
					custCanadaDirect.getMainPhone(), custCanadaDirect.getCountry(), custCanadaDirect.getEmail(), custCanadaDirect.getClinicTimeZone(), 
					custCanadaDirect.getLegalJurisdiction(), custCanadaDirect.getClinicLanguage(), custCanadaDirect.getNewPassword(), 
					custCanadaDirect.getConfirmNewPassword(), custCanadaDirect.getFirstName(), custCanadaDirect.getLastName(),
					custCanadaDirect.getEmailId(), custCanadaDirect.getElecExport());
			addCustomerPage.addCustomerSave();
			
			
			assertion.assertTrue(addCustomerPage.verifyAddCustomerConfirmMsg(), "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "Customer with Canada jurisdiction is not created successfully.");
			
			//Austrelia Jurisdiction
			customerListPage.clickOnAddCustomerButton();
			Assert.assertTrue(addCustomerPage.verifyLandingPage(), "Add Customer Page is not displayed");
			
			addCustomerPage.EnterValueAllfields(custAustreliaDirect.getCustomerName(), userId_Aus,custAustreliaDirect.getCustomerType() ,
					custAustreliaDirect.getClinicLocation(), custAustreliaDirect.getCountryCode(), custAustreliaDirect.getAreaCode(), 
					custAustreliaDirect.getMainPhone(), custAustreliaDirect.getCountry(), custAustreliaDirect.getEmail(), custAustreliaDirect.getClinicTimeZone(), 
					custAustreliaDirect.getLegalJurisdiction(), custAustreliaDirect.getClinicLanguage(), custAustreliaDirect.getNewPassword(), 
					custAustreliaDirect.getConfirmNewPassword(), custAustreliaDirect.getFirstName(), custAustreliaDirect.getLastName(),
					custAustreliaDirect.getEmailId(), custAustreliaDirect.getElecExport());
			addCustomerPage.addCustomerSave();
			
			assertion.assertTrue(addCustomerPage.verifyAddCustomerConfirmMsg(), "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "Customer with Austrelia jurisdiction is created successfully.");
			
			//Japan Jurisdiction
			customerListPage.clickOnAddCustomerButton();
			Assert.assertTrue(addCustomerPage.verifyLandingPage(), "Add Customer Page is displayed");
			
			addCustomerPage.EnterValueAllfields(custJapanDirect.getCustomerName(), userId_Japan,custJapanDirect.getCustomerType() ,
					custJapanDirect.getClinicLocation(), custJapanDirect.getCountryCode(), custJapanDirect.getAreaCode(), 
					custJapanDirect.getMainPhone(), custJapanDirect.getCountry(), custJapanDirect.getEmail(), custJapanDirect.getClinicTimeZone(), 
					custJapanDirect.getLegalJurisdiction(), custJapanDirect.getClinicLanguage(), custJapanDirect.getNewPassword(), 
					custJapanDirect.getConfirmNewPassword(), custJapanDirect.getFirstName(), custJapanDirect.getLastName(),
					custJapanDirect.getEmailId(), custJapanDirect.getElecExport());
			addCustomerPage.addCustomerSave();
			
			assertion.assertTrue(addCustomerPage.verifyAddCustomerConfirmMsg(), "Add customer successfull and add another physical location confirmation popup is displayed.");
			addCustomerPage.addCustomerConfirmCancel();
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyAddCustSuccessPopupAndClickOK(), extentTest, "Customer with Japan jurisdiction is not created successfully.");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
	
	private Login getLoginCredentials(Customer cust) {
		Login loginData = new Login();
		loginData.setIteration("1");
		loginData.setUserName(cust.getUserid());
		loginData.setPassword(cust.getNewPassword());
		return loginData;
	}
	
	@AfterMethod
	public void cleanup() {
		/*
		 * testName = CommonUtils.getTestName(); CommonUtils.currentTestCaseName =
		 * testName;
		 * 
		 * extentTest = extentReport.initiateTest(testName);
		 * 
		 * loginClinicUser_withAllDevice = testDataProvider.getLoginData("SJMClinic6");
		 * //Clinic A loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
		 * 
		 * extentTest.assignAuthor("Author: Vinay Babu"); try {
		 * 
		 * 
		 * appHomeTopNavPage.clickSignOutLink(); loginPage.login(loginSJMAdmin);
		 * Assert.assertTrue(customerListPage.verifyLandingPage(),
		 * "Customer List page is not displayed");
		 * customerListPage.goTo_CustomerProfilePage(loginClinicUser_withAllDevice.
		 * getUserName()); Assert.assertTrue(customerProfilePage.verifyLandingPage(),
		 * "Customer List page is not displayed");
		 * customerProfilePage.clickChangeButton();
		 * Assert.assertTrue(changeCustomerProfilePage.verifyLandingPage(),
		 * "Change Customers Profile Page is NOT Displayed.");
		 * 
		 * List<String> list = new ArrayList<String>();
		 * list.add("Confirm Rx ICM, DM3500 "); list.add("Jot Dx ICM, DM4500 ");
		 * changeCustomerProfilePage.addDevicesToAllowedListAndSave(list);
		 * 
		 * appHomeTopNavPage.clickSignOutLink();
		 * 
		 * 
		 * } catch (AssertionError e) { e.printStackTrace();
		 * extentReport.reportFail(e.getMessage()); throw new AssertionError(); } catch
		 * (Exception e) { e.printStackTrace();
		 * extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
		 * throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]); }
		 */}
	
}

