package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class WA_AD010_AddCustomerGeneralFeatureControl extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DriverUtils drivereuse;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		drivereuse=new DriverUtils(driver,extentReport);
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}

	@Test(groups= {"Regression"})
	public void AddCustomerGeneralFeatureControl () throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
        login = testDataProvider.getLoginData("SJMAdmin");
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		
		CommonUtils.iteration = login.getIteration();
		
		extentTest.assignAuthor("Author-Mohan Sekar");//comments
		//User Navigate to add customer page and check General Feautre Controls are displayed or not.
		try {
			
		
			extentReport.info( "100-S-The actor logs into the system and navigates to the Add customer page");
			loginPage.login(login,"internaluser");
			
			
	    	addCustomerPage.addcustomerclick();
			
			extentReport.info( "200-V- Verify that the customer page contains following components related to General Feautre Controls :"+"<br>"+"Record patient data collection consent flag: controls whether or not patient data mining consent collected in patient profile"+"<br>"+"Allow Mobile DirectAlert Notification"+"<br>"+"Allow access to Communication Center"+"<br>"+"Allow access to Compliance Report",new String[] {"ClncAcct6035"});
			addCustomerPage.generalFeautreControlscomponents();
			extentReport.info( "300-S- Test case ends");
			
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_AD010_AddCustomer General FeatureControl  is failed due to assertion failure");
			e.printStackTrace();
			throw e;	
		
		} catch (Exception e) {
			extentReport.reportFail( "WA_AD010_AddCustomer General FeatureControl  Validation not successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		saintResult(result,extentTest);
		}

}