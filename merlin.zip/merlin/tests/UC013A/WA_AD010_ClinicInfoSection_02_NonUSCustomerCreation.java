package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class WA_AD010_ClinicInfoSection_02_NonUSCustomerCreation extends CommonUtils {

	/*
	 * Testcase id: 1244005, 
	 * Testcase name: WA_AD010_ClinicInfoSection_02
	 */
	
	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DriverUtils drivereuse;

	@BeforeMethod
	public void initialize() {
		drivereuse=new DriverUtils(driver,extentReport);
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void WA_AD010_ClinicInfoSection_02_NonUSCustomerCreation () throws Exception {
		
		try {
			Assertions assertion =  new Assertions(extentTest);
			SoftAssert asert= new SoftAssert();
			
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;			
			extentTest = extentReport.initiateTest(testName);			
			customer = testDataProvider.getCustomerData("WA_AD010_ClinicInfoSection_02_NewCustomerCreation");
			extentTest.assignAuthor("Author-Rajesh Singaraj");
			

			extentReport.info( "100 -S Actor logins to system using admin account");
			loginPage.login(login);
			extentReport.info( "200 -S Actor navigates to Customer list page");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.addACustomer_OR), extentTest, "Divider section has been verified successfully");

			
			extentReport.info( "300 -S Actor clicks on  Enroll new customer button");			
	    	addCustomerPage.addcustomerclick();
			extentReport.info( "400 -V Verify that the Clinic Information section head and divider line are displayed.");
	    	addCustomerPage.verifyingDividerSection();
			extentReport.reportScreenShot("400 -V Verify that the Clinic Information section head and divider line are displayed.");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.customerPageDividerSection_OR), extentTest, "Divider section has been verified successfully");
			
			extentReport.info("500 -V Verify that the Clinic (HQ) Location data entry field is active, is displayed, is a required field, defaults to empty/null value.");			
			addCustomerPage.addCustomerHeadQuarters(customer);
			addCustomerPage.verifyClinicLocation();
			extentReport.reportScreenShot("500 -V Verify that the Clinic (HQ) Location data entry field is active, is displayed, is a required field, defaults to empty/null value.");
			
			extentReport.info("600 -S Actor enters more than 30 characters to clinic location field.");
			addCustomerPage.enterValueInField("verifyClinicLocation", customer);
			extentReport.info("700 -S Verify that system dose not allow entering more than 30 characters.");
			addCustomerPage.verifyLengthyClinicLocation();
			extentReport.reportScreenShot("700 -S Verify that system dose not allow entering more than 30 characters.");
			
			extentReport.info("800 -S Actor deletes data from Clinic location field and click save");
			addCustomerPage.verifyClinicLocation(customer);
			extentReport.info("900 -S Verify that CS 818 is displayed with message that Clinic Location is a mandatory field");
			extentReport.reportScreenShot("900 -S Verify that CS 818 is displayed with message that Clinic Location is a mandatory field");
			
			addCustomerPage.verifyAllAddressInfoFieldsDisplayed();
			extentReport.info("1000 -V Verify that the Address Line One , Address Line Two,  Address Line Three, Country, City, State/Province , Zip/Postal Code.");
			extentReport.reportScreenShot("1000 -V Verify that the Address Line One , Address Line Two,  Address Line Three, Country, City, State/Province , Zip/Postal Code.");
			
			extentReport.info("1100 -V Verify that the Address data entry fields (3 lines) are active, are displayed, default value is blank/null");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicAddress");
			extentReport.reportScreenShot("1100 -V Verify that the Address data entry fields (3 lines) are active, are displayed, default value is blank/null");
			
			extentReport.info("1200 -S Actor enters more than 100 characters to Address 1 field");
			addCustomerPage.enterValueInField("verifyClinicAddress", customer);
			
			addCustomerPage.verifyLength(addCustomerPage.clinicAddress_1_OR,100);
			extentReport.info("1300 -V Verify that system does not allow user to enter more than 100 characters");
			extentReport.reportScreenShot("1300 -V Verify that system does not allow user to enter more than 100 characters");
			addCustomerPage.enterValueInField("clinicAddress_1", customer);
			
			
			extentReport.info("1400 -V  Verify that the City data entry field is active, is displayed, defaults to empty/null value");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicCity");
			extentReport.reportScreenShot("1400 -V  Verify that the City data entry field is active, is displayed, defaults to empty/null value");
			extentReport.info("1500 -S Actor enters more than 30 characters to city field");
			addCustomerPage.enterValueInField("verifyCliniCity", customer);
			
			
			addCustomerPage.verifyLength(addCustomerPage.clinicCity_OR,30);
			extentReport.info("1600 -V Verify that system dose not allow to enter more than 30 characters");
			extentReport.reportScreenShot("1600 -V Verify that system dose not allow to enter more than 30 characters");
			addCustomerPage.enterValueInField("cliniCity", customer);
			
			extentReport.info("1700 -V The State/Province dropdown field is active, is displayed, defaults to empty/null value,and that the actor can enter a value from the dropdown selection list.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicState");
			extentReport.reportScreenShot("1700 -V Verify that the State/Province dropdown field is active, is displayed, defaults to empty/null value");
			
			addCustomerPage.verifyDropDownValuesWithDOOR("state", customer);
			extentReport.info("1800 -V Verify that the State/Province dropdown selection values are correct. [Refer Matrix Document: Merlin net EP -HF Configuration >> Configurable Parameters >> Datasets >> Customer State/Province]");
			extentReport.reportScreenShot("1800 -V Verify that the State/Province dropdown selection values are correct. [Refer Matrix Document: Merlin net EP -HF Configuration >> Configurable Parameters >> Datasets >> Customer State/Province]");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicCountry");
			extentReport.info("1900 -V Verify that the Country dropdown field is active, is displayed, and that the actor can enter a value from the dropdown selection list.");
			extentReport.reportScreenShot("1900 -V Verify that the Country dropdown field is active, is displayed, and that the actor can enter a value from the dropdown selection list.");
			addCustomerPage.verifyDropDownValuesWithDOOR("country", customer);
			extentReport.info("2000 -S Verify that country values are as per matrix document [Refer: [Refer Matrix Document: Merlin net EP -HF Configuration >> Configurable Parameters >> Datasets >> Customer Country]");
			addCustomerPage.selectValuefromDropdownviaVisibleText(addCustomerPage.countryTextBox_OR, customer.getCountry());
			
			extentReport.info("2100 -V Verify that the Zip/Postal Code data entry field is active, is displayed, defaults to empty/null value, and that the actor can enter valid data.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicZipCode");

			extentReport.info("2200 –S Enter more than 30 characters to zip code field");
			addCustomerPage.invalidZipCodeValidation();
			extentReport.info("2300 –S Verify that system dose not allow entering more than 30 characters to zip code field");			

			//Phone number
			extentReport.info("2400 –S Submit the phone number complex without changing anything.");

			addCustomerPage.enterValueInField("clinicCountryCode", customer);
			addCustomerPage.enterValueInField("clinicAreaCode", customer);
			addCustomerPage.enterValueInField("clinicMainPhone", customer);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);

			addCustomerPage.invalidCountryCodeValidation(addCustomerPage.countryCode_OR);
			extentReport.info("2600-S- The actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save.");
			addCustomerPage.clear(addCustomerPage.countryCode_OR);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			addCustomerPage.presenceOfElementLocated(addCustomerPage.countryCodeAlertMsg_OR);
			extentReport.info("2700-V- Verify that system displays CS 816 with message that phone number value is invalid");
			
			addCustomerPage.countryCodeInvalidValidation();
			extentReport.info("2800 – S Repeat Steps 2600 to 2700 with following data:");
			addCustomerPage.verifyPhoneNumberAcceptsAlphabets(addCustomerPage.countryCode_OR);
			extentReport.info("2900 V - The System The Phone Number Country Code should be 1 to 3 numeric digits. "
					+ "'(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' "
					+ "- space should be accepted as additional entry values but should be removed upon save and not re-displayed..");
			addCustomerPage.nonUSAreaCodeSymbolValidation();
			extentReport.info("2800 V- Verify that the Phone Number Area-City Code should be 0 to 5 numeric digits if the associated phone "
					+ "number country code DOES NOT correspond to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'-"
					+ " Dot, '-' - dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save "
					+ "and not re-displayed. <CommU4662> e.g. enter 123 (123) 1234567 . This format should be saved with out showing any "
					+ "attention message. But on \"view\" of the page under test, brackets should not be displayed in phone field");
			
			extentReport.info("2900-S-The Actor The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks Save.");
			addCustomerPage.invalidNonUSPhoneNumberValidation();
			extentReport.info("3000-V- Verify that system displays CS 816 with message that phone number value is invalid");
			extentReport.info("3100 – S Repeat Steps 2900 – 3000 with below values: 1. enter 2 123 12 2. enter 123 123 123456789012");
			addCustomerPage.nonUSPhoneNumberSymbolValidation(addCustomerPage.mainPhone_OR);
			extentReport.info("3200 V- Verify that the Phone Number should be 3 to 12 numeric digits if the associated phone number country code"
					+ " DOES NOT correspond to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' "
					+ "- dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed.");
			extentReport.info("3300-S-The Actor The Actor enters a Phone Number Complex that is not complete then clicks save Test each "
					+ "following invalid inputs: 1. enter (empty country code) 123 1234 2. enter 123 123 (empty phone number) 3. enter (empty country code) 12 (empty phone number)");
			addCustomerPage.invalidNonUSPhoneNumberComplexValidation();
			extentReport.info("3400 – V Verify that system displays CS 816 with message that phone number value is invalid");
			
			//Secondary Phone numbers");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicSecCountryCode");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicSecAreaCode");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicSecMainPhone");
			extentReport.info("3500 -V The Secondary Phone data entry field is is active, is displayed, and defaults to empty/null value. Value: Associated with [Customer.Secondary_Phone_ID]");
			
			extentReport.info("2400 –S Submit the secondary phone number complex without changing anything.");
			addCustomerPage.enterValueInField("clinicSecCountryCode", customer);
			addCustomerPage.enterValueInField("clinicSecAreaCode",customer);
			addCustomerPage.enterValueInField("clinicSecMainPhone",customer);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			
			addCustomerPage.invalidCountryCodeValidation(addCustomerPage.secondarycountryCode_OR);
			extentReport.info("2600-S- The actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save.");
			addCustomerPage.clear(addCustomerPage.secondarycountryCode_OR);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			addCustomerPage.presenceOfElementLocated(addCustomerPage.countryCodeAlertMsg_OR);
			extentReport.info("2700-V- Verify that system displays CS 816 with message that phone number value is invalid");
			
			addCustomerPage.secondaryCountryCodeInvalidValidation();
			extentReport.info("2800 – S Repeat Steps 2600 to 2700 with following data:");
			addCustomerPage.verifyPhoneNumberAcceptsAlphabets(addCustomerPage.secondarycountryCode_OR);
			extentReport.info("2900 V - The System The Phone Number Country Code should be 1 to 3 numeric digits. "
					+ "'(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' "
					+ "- space should be accepted as additional entry values but should be removed upon save and not re-displayed..");
			addCustomerPage.nonUSAreaCodeSymbolValidation(addCustomerPage.secondarycountryCode_OR);
			extentReport.info("2800 V- Verify that the Phone Number Area-City Code should be 0 to 5 numeric digits if the associated phone "
					+ "number country code DOES NOT correspond to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'-"
					+ " Dot, '-' - dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save "
					+ "and not re-displayed. <CommU4662> e.g. enter 123 (123) 1234567 . This format should be saved with out showing any "
					+ "attention message. But on \"view\" of the page under test, brackets should not be displayed in phone field");
			
			extentReport.info("2900-S-The Actor The actor enters an invalid Phone Number which has less than 3 and more than 12 numeric digits, then clicks Save.");
			addCustomerPage.invalidNonUSSecondaryPhoneNumberValidation();
			extentReport.info("3000-V- Verify that system displays CS 816 with message that phone number value is invalid");
			extentReport.info("3100 – S Repeat Steps 2900 – 3000 with below values: 1. enter 2 123 12 2. enter 123 123 123456789012");
			addCustomerPage.nonUSPhoneNumberSymbolValidation(addCustomerPage.secondaryMainPhone_OR);
			extentReport.info("3200 V- Verify that the Phone Number should be 3 to 12 numeric digits if the associated phone number country code"
					+ " DOES NOT correspond to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' "
					+ "- dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed.");
			extentReport.info("3300-S-The Actor The Actor enters a Phone Number Complex that is not complete then clicks save Test each "
					+ "following invalid inputs: 1. enter (empty country code) 123 1234 2. enter 123 123 (empty phone number) 3. enter (empty country code) 12 (empty phone number)");
			addCustomerPage.invalidNonUSSecondaryPhoneNumberComplexValidation();
			extentReport.info("3400 – V Verify that system displays CS 816 with message that phone number value is invalid");
			extentReport.info("3600 S Repeat steps 2400 to 3500");
			
			//Fax Area code");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicfaxCountryCode");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicFaxAreaCode");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicFaxNumber");
			extentReport.info("4500 -V Verify that the Fax data entry field is active, is displayed, defaults to empty/null value, and that the actor can enter valid data. Associated with [Customer.Fax_Num_ID]");
			
			extentReport.info("2400 –S Submit the secondary phone number complex without changing anything.");

			addCustomerPage.enterValueInField("clinicFaxCountryCode", customer);
			addCustomerPage.enterValueInField("clinicFaxAreaCode",customer);
			addCustomerPage.enterValueInField("clinicFaxMainPhone",customer);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			
			addCustomerPage.invalidCountryCodeValidation(addCustomerPage.faxCountryCode_OR);
			extentReport.info("2600-S- The actor enters an invalid Fax data Country code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save.");
			addCustomerPage.clear(addCustomerPage.faxCountryCode_OR);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			addCustomerPage.presenceOfElementLocated(addCustomerPage.countryCodeAlertMsg_OR);
			extentReport.info("2700-V- Verify that system displays CS 816 with message that Fax data value is invalid");
			
			addCustomerPage.faxCountryCodeInvalidValidation();
			extentReport.info("2800 – S Repeat Steps 2600 to 2700 with following data:");
			addCustomerPage.verifyPhoneNumberAcceptsAlphabets(addCustomerPage.faxCountryCode_OR);
			extentReport.info("2900 V - The System Fax data Country Code should be 1 to 3 numeric digits. "
					+ "'(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' "
					+ "- space should be accepted as additional entry values but should be removed upon save and not re-displayed..");
			addCustomerPage.nonUSAreaCodeSymbolValidation(addCustomerPage.faxCountryCode_OR);
			extentReport.info("2800 V- Verify that the Fax data Area-City Code should be 0 to 5 numeric digits if the associated phone "
					+ "number country code DOES NOT correspond to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'-"
					+ " Dot, '-' - dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save "
					+ "and not re-displayed. <CommU4662> e.g. enter 123 (123) 1234567 . This format should be saved with out showing any "
					+ "attention message. But on \"view\" of the page under test, brackets should not be displayed in phone field");
			
			extentReport.info("2900-S-The Actor The actor enters an invalid Fax data which has less than 3 and more than 12 numeric digits, then clicks Save.");
			addCustomerPage.invalidNonUSFaxPhoneNumberValidation();
			extentReport.info("3000-V- Verify that system displays CS 816 with message that Fax data value is invalid");
			extentReport.info("3100 – S Repeat Steps 2900 – 3000 with below values: 1. enter 2 123 12 2. enter 123 123 123456789012");
			addCustomerPage.nonUSPhoneNumberSymbolValidation(addCustomerPage.faxnumber_OR);
			extentReport.info("3200 V- Verify that the Phone Number should be 3 to 12 numeric digits if the associated phone number country code"
					+ " DOES NOT correspond to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' "
					+ "- dash, '+' - plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed.");
			extentReport.info("3300-S-The Actor The Actor enters a Phone Number Complex that is not complete then clicks save Test each "
					+ "following invalid inputs: 1. enter (empty country code) 123 1234 2. enter 123 123 (empty phone number) 3. enter (empty country code) 12 (empty phone number)");
			addCustomerPage.invalidNonUSFaxNumberComplexValidation();
			extentReport.info("3400 – V Verify that system displays CS 816 with message that phone number value is invalid");
			extentReport.info("4600 S Repeat steps 2900 to 4300");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicEmail");
			extentReport.info("4700 -V The Email data entry field is displayed, is required, and defaults to empty/null value. Value: Associated with [Customer.email_Address]");
			addCustomerPage.enterValueInField("clinicFaxCountryCode", customer);
			extentReport.info("4800-S- Enter an invalid email in this Email Address field, which does not contain \"@\" , then clicks Save e.g. \"johns.sjm.com");
			addCustomerPage.verifyEmailAddressField();
			extentReport.info("4900-V- Verify that system displays CS 816 with message that email value is invalid");
			extentReport.info("5000-S- Enter an invalid email in this Email Address field, which does not contain \".\" , then click save  e.g. \"john@sjm\"");
			addCustomerPage.emailAddressFieldValidation();
			extentReport.info("5100-V- Verify that system displays CS 816 with message that email value is invalid");
			
			addCustomerPage.enterValueInField("VerifyEmail", customer);
			extentReport.info("5200-S-The Actor The actor enters an invalid email with 101 characters in the Email Address field, which contains \"@\" and '.' , then click save");
			addCustomerPage.verifyLength(addCustomerPage.email_OR, 100);
			extentReport.info("5300-V-The System will not allow the entry of more than 100 characters.");
			addCustomerPage.enterValueInField("clinicEmail", customer);
			extentReport.info("5400-S-The Actor The actor enters an valid email with in a range 1 - 100 characters in the Email Address field, which contains \"@\" and '.' , then clicks save e.g: john@ibm.com");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicTextMessage");
			extentReport.info("5500 -V Verify that the Text Message ID data entry field is is active, is displayed, defaults to empty/null value. Value: Associated with Customer.SMS ");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicTimeZone");
			extentReport.info("5600 -V Verify that the Clinic Time Zone dropdown field is active, is displayed, is required, and defaults to empty/null value. Value: Associated with Customer.Time_Zone_CD");
			addCustomerPage.verifyDropDownValuesWithDOOR("timezone", customer);
			extentReport.info("5700 -V Verify that the Clinic Time Zone dropdown selection values are correct as per matrix configuration. [Refer: Merlin .Net EP –HF Configuration >> Configurable Parameter >>Data Sets >> Clinic Time zone]");
			addCustomerPage.verifyClinicTimeZoneInOrder();
			extentReport.info("5800 V Clinic Time Zone Dropdown values should be sorted in GMT order overall (-GMT to +GMT).");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicLanguage");
			extentReport.info("5900 -V Verify that the Clinic Language dropdown field is active, is displayed, is required, and defaults to empty/null value. Value: Associated with [Customer.Locale_CD] ");
			
			addCustomerPage.verifyClinicLanguage();
			extentReport.info("6000 -V Verify that the Clinic Language dropdown selection values are correct.");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("legalJurisdictionText");
			extentReport.info("6100 -V Verify that the Clinic legal jurisdiction dropdown field is active, is displayed, is required, and defaults to empty/null value. Value: Associated with [Customer.Legal_Jurisdiction_CD] ");
			addCustomerPage.verifyClinicJurisdiction();			
			extentReport.info("6200 -V Verify that the Clinic legal jurisdiction dropdown selection values are correct.");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("testClinicCheckBox.");
			extentReport.info("6300- V Verify that the \"Test Clinic\" checkbox is always displayed and active with default value Unchecked value associated with [Customer.Test_Clinic_Flg].");
			
			addCustomerPage.ClickSaveBtn();
			addCustomerPage.verifyPhoneNumberinDBUponSave();
			extentReport.info("2500 -V-The System The phone number complex shall not be validated and shall not be stored to the database.");
			extentReport.info("4200-V-Verify that the system should save the value in the database. Verify that Phone Numbers ( Phone Data Type) should be displayed in the format 'ddd ddd ddd dddd' where d = any single decimal digit, any leading zeros will be displayed");
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_AD010_ClinicInfoSection_02_NewCustomerCreation is failed due to assertion failure");
			e.printStackTrace();
			throw e;	
		
		} catch (Exception e) {
			extentReport.reportFail( "WA_AD010_ClinicInfoSection_02_NewCustomerCreation Validation not successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
