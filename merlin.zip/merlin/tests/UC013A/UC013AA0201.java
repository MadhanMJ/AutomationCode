package com.test.qa.ui.tests.UC013A;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class UC013AA0201 extends CommonUtils{

	private String testName;
	TestDataProvider testDataProvider;
	AddCustomerPage addCustomerPage;
	LoginPageWithPOJO loginPage;
	CustomerListPage customerListPage;
	
	Login loginSJMAdmin;
	
	@BeforeClass
	public void initialize() {
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customerListPage = new CustomerListPage(driver, extentReport);
		loginSJMAdmin = new Login();
	}
	
	@Test
	public void UC013A_B0101_SJM_EA_Enroll_Customer() {
		
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			
			loginSJMAdmin = testDataProvider.getLoginData("SJMAdmin3");
			
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) is logged into the system "
					+ "and navigates to Add Customer page "
					+ "and Actor is able to login Successfully with the given user id and password. ");
			loginPage.login(loginSJMAdmin, "internaluser");	
			Assert.assertTrue(customerListPage.verifyLandingPage(), "Customer List page is not displayed");
			
			customerListPage.clickOnAddCustomerButton();
			Assert.assertTrue(addCustomerPage.verifyLandingPage(), "Add Customer Page is not displayed");
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
	}
}
