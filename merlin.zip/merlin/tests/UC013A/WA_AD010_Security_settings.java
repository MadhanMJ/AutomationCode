package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class WA_AD010_Security_settings extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	Assertions assertion ;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	
	Log logger;
	@BeforeClass(alwaysRun=true)
	public void initialize() {
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
		logger =  new Log();
		
	}
	// Testcase id: 1244042, Testcase name: WA-CA110-ClinicLocations-Search
	@Test(groups= {"Regression"})
	public void Securitysettings() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
        CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("SJMAdmin");
		//login = testDataProvider.getLoginData("MFA");
		customer = testDataProvider.getCustomerData("AddCustomer");
		extentTest.assignAuthor("Author-Mohan Sekar");
		
		try {
			assertion = new Assertions(extentTest);
			System.out.println("CustomerID: " + customer.getUserid());
			extentReport.info("100-S- Login to application using admin and select an option to enroll new customer");
			//adminLogin();
			loginPage.login(login,"internaluser");
			addCustomerPage.loading();
			//Boolean loginCheck = customerListPage.verifyLandingPage();
			//Assert.assertTrue(loginCheck);
			addCustomerPage.addcustomerclick();
		 
		    extentTest =extentReport.info("200-V- Verify that the add customer page should contain the static component related to security setting as follows. Security Settings Header should be displayed");
		    //extentReport.pass( " 200-V- Verify that the add customer page should contain the static component related to security setting as follows. Security Settings Header should be displayed <ClncAcct6110>");
		    addCustomerPage.customerHeadquarters_Section_Stripe();
		    extentTest =extentReport.info( "300-V- Verify that application provides below Secure communication controls</br> Secure Communication control for DirectAlert</br>Secure Communication control for Contact a Colleague emails</br>Secure Communication Control for Unpaired Transmitter emails</br>Secure Communication Control for all emails and messages",new String[] {"ClncAcct6081", "ClncAcct6078", "ClncAcct6063","ClncAcct6088","ClncAcct6087","ClncAcct6089"});
		    addCustomerPage.customerNameFieldValidation();
			assertion.assertAll();
		}catch (AssertionError e) {
				
				extentReport.reportFail( "WA_AD010_Security_settings   is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
				
				
				throw e;
			}
		 catch (Exception e) {
			extentReport.reportFail( "WA_AD010_Security_settings  Validation not  successfull",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		saintResult(result,extentTest);

}
}
