package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class WA_AD010_ClinicInfoSection_01_NewCustomerCreation extends CommonUtils {

	/*
	 * Testcase id: 1244004, 
	 * Testcase name: WA_AD010_ClinicInfoSection_01
	 */
	
	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DriverUtils drivereuse;

	@BeforeMethod
	public void initialize() {
		drivereuse=new DriverUtils(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void WA_AD010_ClinicInfoSection_01_NewCustomerCreation () throws Exception {
		
		try {
			Assertions assertion =  new Assertions(extentTest);
			SoftAssert asert= new SoftAssert();
			
			testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;

			extentTest = extentReport.initiateTest(testName);
			CommonUtils.extentTest = extentTest;
			
			login = testDataProvider.getLoginData("SJMAdmin");		
			customer = testDataProvider.getCustomerData("WA_AD010_ClinicInfoSection_01_NewCustomerCreation");
			extentTest.assignAuthor("Author-Rajesh Singaraj");
			

			extentReport.info( "100 -S Actor logins to system using admin account");
			loginPage.login(login);
			extentReport.info( "200 -S Actor navigates to Customer list page");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.addACustomer_OR,"addACustomer_S"), extentTest, "Divider section has been verified successfully");

			
			extentReport.info( "300 -S Actor clicks on  Enroll new customer button");			
	    	addCustomerPage.addcustomerclick();
			extentReport.info( "400 -V Verify that the Clinic Information section head and divider line are displayed.");
	    	addCustomerPage.verifyingDividerSection();
			
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.customerPageDividerSection_OR,addCustomerPage.customerPageDividerSection_S), extentTest, "Divider section has been verified successfully");
			
			extentReport.info("500 -V Verify that the Clinic (HQ) Location data entry field is active, is displayed, is a required field, defaults to empty/null value.");			
			addCustomerPage.addCustomerHeadQuarters(customer);
			addCustomerPage.verifyClinicLocation();
			
			
			extentReport.info("600 -S Actor enters more than 30 characters to clinic location field.");
			addCustomerPage.enterValueInField("verifyClinicLocation", customer);
			extentReport.info("700 -S Verify that system dose not allow entering more than 30 characters.");
			addCustomerPage.verifyLengthyClinicLocation();
			
			
			extentReport.info("800 -S Actor deletes data from Clinic location field and click save");
			//Need an attention
			//addCustomerPage.verifyClinicLocation(customer);
			extentReport.info("900 -S Verify that CS 818 is displayed with message that Clinic Location is a mandatory field");
			
						
			extentReport.info("1000 -V Verify that the Address Line One , Address Line Two,  Address Line Three, Country, City, State/Province , Zip/Postal Code.");
			addCustomerPage.verifyAllAddressInfoFieldsDisplayed();
			
			extentReport.info("1100 -V Verify that the Address data entry fields (3 lines) are active, are displayed, default value is blank/null");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicAddress");
			
			
			extentReport.info("1200 -S Actor enters more than 100 characters to Address 1 field");
			addCustomerPage.enterValueInField("verifyClinicAddress", customer);
			
			addCustomerPage.verifyLength(addCustomerPage.clinicAddress_1_OR,100);
			extentReport.info("1300 -V Verify that system does not allow user to enter more than 100 characters");
			extentReport.reportScreenShot("1300 -V Verify that system does not allow user to enter more than 100 characters");
			addCustomerPage.enterValueInField("clinicAddress_1", customer);
			
			
			extentReport.info("1400 -V  Verify that the City data entry field is active, is displayed, defaults to empty/null value");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicCity");
			extentReport.reportScreenShot("1400 -V  Verify that the City data entry field is active, is displayed, defaults to empty/null value");
			extentReport.info("1500 -S Actor enters more than 30 characters to city field");
			addCustomerPage.enterValueInField("verifyCliniCity", customer);
			
			
			addCustomerPage.verifyLength(addCustomerPage.clinicCity_OR,30);
			extentReport.info("1600 -V Verify that system dose not allow to enter more than 30 characters");
			extentReport.reportScreenShot("1600 -V Verify that system dose not allow to enter more than 30 characters");
			addCustomerPage.enterValueInField("cliniCity", customer);
			
			
			extentReport.info("1700 -V Verify that the State/Province dropdown field is active, is displayed, defaults to empty/null value, "
					+ "and that the actor can enter a value from the dropdown selection list. Drop-down Entry Field if in Entry Mode and the Country Field is currently "
					+ "set to the value corresponding to the United States. Should display: - existing State/Province value if previously entered - empty field if not "
					+ "entered and field is entry field - displays first of the dropdown values if not previously saved and field is Dropdown Data Type = US_State and "
					+ "associated with [Address.State_Cd] if Country Field Value currently corresponds to United States. Data Type = State_Province and associated with "
					+ "[Address.State_Province] if Country Field Value currently does not correspond to United States.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicState");
			//Need a attention
			addCustomerPage.verifyDefaultValueOfState();
			addCustomerPage.enterValueInField("ClinicState", customer);
			
			addCustomerPage.verifyDropDownValuesWithDOOR("state", customer);
			extentReport.info("1800 -V Verify that the State/Province dropdown selection values are correct. [Refer Matrix Document: Merlin net EP -HF Configuration >> Configurable Parameters >> Datasets >> Customer State/Province]");
			extentReport.reportScreenShot("1800 -V Verify that the State/Province dropdown selection values are correct. [Refer Matrix Document: Merlin net EP -HF Configuration >> Configurable Parameters >> Datasets >> Customer State/Province]");			
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicCountry");
			extentReport.info("1900 -V Verify that the Country dropdown field is active, is displayed, and that the actor can enter a value from the dropdown selection list.");					
			addCustomerPage.keyboardActions(Keys.ESCAPE);
			
			addCustomerPage.verifyDropDownValuesWithDOOR("country", customer);
			addCustomerPage.keyboardActions(Keys.ESCAPE);
			extentReport.info("2000 -S Verify that country values are as per matrix document [Refer: [Refer Matrix Document: Merlin net EP -HF Configuration >> Configurable Parameters >> Datasets >> Customer Country]");
			addCustomerPage.enterValueInField("ClinicCountry", customer);
			
			
			extentReport.info("2100 -V Verify that the Zip/Postal Code data entry field is active, is displayed, defaults to empty/null value, and that the actor can enter valid data.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicZipCode");			
			extentReport.info("2200-S- Actor enters an invalid zip code in this Zip Code field, (ensure that all other mandatory fields are filled) which contains not exact 5 or 9 digits, then click save button");
			
			addCustomerPage.verifyInvalidZipCode();
			extentReport.info("2300-V- Verify that system displays CS 816 with message that zip code value is invalid");
			addCustomerPage.enterValueInField("clinicZipCode", customer);			
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);

			addCustomerPage.enterValueInField("clinicZipCode", customer);			
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			
			extentReport.info("2400-S- Actor enters a valid zip code in this Zip Code field, which contains exact 5 or 9 digits, then click Save button");
			addCustomerPage.clear(addCustomerPage.zipPostalCode_OR);
			addCustomerPage.enterValueInField("clinicZipCode", customer);
			
			extentReport.info("2500-V- Verify that ZipCode Type should be displayed in the format 'ddddd or ddddd-dddd'. where d = any single decimal digit");
			addCustomerPage.verifyZipCodeFormat();
			
			//Phone number
			extentReport.info("2600 -V Verify that the Main Phone data entry field is active, is displayed, is required, and defaults to empty/null value.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicMainPhone");
			extentReport.info("2700-S-Actor submits the phone number complex without changing anything.");
			

			addCustomerPage.enterValueInField("clinicCountryCode", customer);
			addCustomerPage.enterValueInField("emptyAreaCode",customer);
			addCustomerPage.enterValueInField("clinicMainPhone",customer);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);

			/*
			 * addCustomerPage.EnterValueInField(addCustomerPage.countryCode_OR,
			 * customer.getCountry());
			 * addCustomerPage.EnterValueInField(addCustomerPage.areaCode_OR, "");
			 * addCustomerPage.EnterValueInField(addCustomerPage.mainPhone_OR,
			 * customer.getMainPhone());
			 * addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			 */

			extentReport.info("2900-S-Actor submits an incomplete Phone Number Complex. Enter 1 (empty area city code) 1234567");
			
			asert.assertEquals(true,addCustomerPage.isDisplayed(addCustomerPage.areaCodeAlertMsg_OR));
			extentReport.info("3000 -S Verify that CS 818 is displayed with message that Phone Number is a mandatory field");
			addCustomerPage.verifyDefaultCountryValue(addCustomerPage.countryCode_OR);
			extentReport.info("3100 –V Verify that country code value is set to be 1 as selected country is US");
			
			addCustomerPage.enterValueInField("clinicCountryCode", customer);
			addCustomerPage.verifyPhoneNumberAcceptsAlphabets(addCustomerPage.countryCode_OR);
			extentReport.info("3200-V Verify that the Phone Number Country Code should be 1 to 3 numeric digits. "
					+ "'(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - "
					+ "space should be accepted as additional entry values but should be removed upon save and not re-displayed.");
			
			addCustomerPage.invalidCountryCodeValidation(addCustomerPage.countryCode_OR);
			extentReport.info("3300-S- Actor enters an invalid Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save");
			addCustomerPage.clear(addCustomerPage.countryCode_OR,addCustomerPage.countryCode_S);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			addCustomerPage.presenceOfElementLocatedWithReport(addCustomerPage.countryCodeAlertMsg_OR,addCustomerPage.countryCodeAlertMsg_S);
			extentReport.info("3400-V- Verify that system displays CS 816 with message that phone number value is invalid");
			
			addCustomerPage.countryCodeInvalidValidation();
			extentReport.info("3450 –S Repeat Steps 3300-3400 with invalid values");			
			addCustomerPage.areaCodeSymbolValidation(addCustomerPage.areaCode_OR);
			extentReport.info(
					"3500 -V Verify that the Phone Number Area-City Code should be 3 numeric digits if the associated phone number "
							+ "country code corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' "
							+ "- plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed.");
						
			extentReport.info("3600-S- Actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks save.");
			addCustomerPage.areaCodeAlphabetValidation(addCustomerPage.areaCode_OR);
			extentReport.info("3700-V- Verify that system displays CS 816 with message that phone number value is invalid");			
			addCustomerPage.verifyInvalidAreaCodeValidation();
			extentReport.info("3750- Repeat 3600 to 3700 with following values");			
			addCustomerPage.verifyPhoneNumberSymbolValidation(addCustomerPage.mainPhone_OR);
			extentReport.info("3800 V Verify that the Phone Number should be 7 numeric digits if the associated phone number country code "
							+ "corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - "
							+ "space are accepted as additional entry values but should be removed upon save and not re-displayed.");			
			extentReport.info("3900-S-The Actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks save.");
			addCustomerPage.verifyValidPhoneNumberValidation();
			extentReport.info("4000-V- Verify that system displays CS 816 with message that zip code value is invalid");
			extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:1. enter 1 123 123456 2. enter 1 123 12345678 3. enter 1 123 12A4567");
			addCustomerPage.verifyPhoneNumberComplexValidation();
			extentReport.info("4100-S-The Actor enters a valid Phone Number Complex, which has 1 numerical digit for country "
					+ "code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks save "
					+ "for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");
			
			//Secondary Phone number
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicSecMainPhone");
			extentReport.info("4300 -V Verify that the Secondary Phone data entry field is is active, is displayed, and defaults to empty/null value. Value: Associated with [Customer.Secondary_Phone_ID]");
			
			extentReport.info("4400 S Repeat steps 2900 to 4300");
			extentReport.info("2600 -V Verify that the Main Phone data entry field is active, is displayed, is required, and defaults to empty/null value.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicSecMainPhone");
			extentReport.info("2700-S-Actor submits the secondary phone number complex without changing anything.");
			

			addCustomerPage.enterValueInField("clinicSecCountryCode", customer);
			addCustomerPage.enterValueInField("clinicSecAreaCode",customer);
			addCustomerPage.enterValueInField("clinicSecMainPhone",customer);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);

			extentReport.info("2900-S-Actor submits an incomplete secondary Phone Number Complex. Enter 1 (empty area city code) 1234567");
			
			asert.assertEquals(true,addCustomerPage.isDisplayed(addCustomerPage.areaCodeAlertMsg_OR));
			extentReport.info("3000 -S Verify that CS 818 is displayed with message that Secondary Phone Number is a mandatory field");
			addCustomerPage.verifyDefaultCountryValue(addCustomerPage.secondarycountryCode_OR);
			extentReport.info("3100 –V Verify that Secondary country code value is set to be 1 as selected country is US");
			
			addCustomerPage.enterValueInField("clinicSecCountryCode", customer);
			addCustomerPage.verifyPhoneNumberAcceptsAlphabets(addCustomerPage.secondarycountryCode_OR);
			extentReport.info("3200-V Verify that the Secondary Phone Number Country Code should be 1 to 3 numeric digits. "
					+ "'(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - "
					+ "space should be accepted as additional entry values but should be removed upon save and not re-displayed.");
			
			addCustomerPage.invalidCountryCodeValidation(addCustomerPage.secondarycountryCode_OR);
			extentReport.info("3300-S- Actor enters an invalid secondary Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save");
			addCustomerPage.clear(addCustomerPage.secondarycountryCode_OR);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			addCustomerPage.presenceOfElementLocated(addCustomerPage.countryCodeAlertMsg_OR);
			extentReport.info("3400-V- Verify that system displays CS 816 with message that secondary phone number value is invalid");
			
			addCustomerPage.secondaryCountryCodeInvalidValidation();
			extentReport.info("3450 –S Repeat Steps 3300-3400 with invalid values");			
			addCustomerPage.areaCodeSymbolValidation(addCustomerPage.secondaryAreaCode_OR);
			extentReport.info(
					"3500 -V Verify that the Phone Number Area-City Code should be 3 numeric digits if the associated phone number "
							+ "country code corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' "
							+ "- plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed.");
						
			extentReport.info("3600-S- Actor enters an invalid Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks save.");
			addCustomerPage.areaCodeAlphabetValidation(addCustomerPage.secondaryAreaCode_OR);
			extentReport.info("3700-V- Verify that system displays CS 816 with message that phone number value is invalid");			
			addCustomerPage.verifyInvalidSecondaryAreaCodeValidation();
			extentReport.info("3750- Repeat 3600 to 3700 with following values");			
			addCustomerPage.verifyPhoneNumberSymbolValidation(addCustomerPage.secondaryMainPhone_OR);
			extentReport.info("3800 V Verify that the Phone Number should be 7 numeric digits if the associated phone number country code "
							+ "corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - "
							+ "space are accepted as additional entry values but should be removed upon save and not re-displayed.");			
			extentReport.info("3900-S-The Actor enters an invalid Phone Number which uses alphabetic characters, which has more or less than 7 digits, then clicks save.");
			addCustomerPage.verifyValidSecondaryPhoneNumberValidation();
			extentReport.info("4000-V- Verify that system displays CS 816 with message that zip code value is invalid");
			extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:1. enter 1 123 123456 2. enter 1 123 12345678 3. enter 1 123 12A4567");
			addCustomerPage.verifySecondaryPhoneNumberComplexValidation();
			extentReport.info("4100-S-The Actor enters a valid Phone Number Complex, which has 1 numerical digit for country "
					+ "code, 3 numerical digits for Area City Code and 7 numerical digits for Phone Number; then clicks save "
					+ "for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");
			
			
			//Fax number
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicFaxNumber");
			extentReport.info("4500 -V Verify that the Fax data entry field is active, is displayed, defaults to empty/null value, and that the actor can enter valid data. Associated with [Customer.Fax_Num_ID] ");
			
			extentReport.info("4600 S Repeat steps 2900 to 4300");
			extentReport.info("2600 -V Verify that the Fax data entry field is active, is displayed, is required, and defaults to empty/null value.");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicFaxNumber");
			extentReport.info("2700-S-Actor submits the fax number complex without changing anything.");
			

			addCustomerPage.enterValueInField("clinicFaxCountryCode", customer);
			addCustomerPage.enterValueInField("clinicFaxAreaCode",customer);
			addCustomerPage.enterValueInField("clinicFaxMainPhone",customer);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);

			extentReport.info("2900-S-Actor submits an incomplete fax Number Complex. Enter 1 (empty area city code) 1234567");
			
			asert.assertEquals(true,addCustomerPage.isDisplayed(addCustomerPage.areaCodeAlertMsg_OR));
			extentReport.info("3000 -S Verify that CS 818 is displayed with message that fax Number is a mandatory field");
			addCustomerPage.verifyDefaultCountryValue(addCustomerPage.faxCountryCode_OR);
			extentReport.info("3100 –V Verify that fax country code value is set to be 1 as selected country is US");
			
			addCustomerPage.enterValueInField("clinicFaxCountryCode", customer);
			addCustomerPage.verifyPhoneNumberAcceptsAlphabets(addCustomerPage.faxCountryCode_OR);
			extentReport.info("3200-V Verify that the fax Number Country Code should be 1 to 3 numeric digits. "
					+ "'(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - "
					+ "space should be accepted as additional entry values but should be removed upon save and not re-displayed.");
			
			addCustomerPage.invalidCountryCodeValidation(addCustomerPage.faxCountryCode_OR);
			extentReport.info("3300-S- Actor enters an invalid fax Country Code which uses alphabetic characters, which has less than 1 or more than 3 digits, then clicks Save");
			addCustomerPage.clear(addCustomerPage.faxCountryCode_OR);
			addCustomerPage.clickElement(addCustomerPage.addCustomerSave_OR);
			addCustomerPage.presenceOfElementLocated(addCustomerPage.countryCodeAlertMsg_OR);
			extentReport.info("3400-V- Verify that system displays CS 816 with message that fax number value is invalid");
			
			addCustomerPage.faxCountryCodeInvalidValidation();
			extentReport.info("3450 –S Repeat Steps 3300-3400 with invalid values");			
			addCustomerPage.areaCodeSymbolValidation(addCustomerPage.faxAreaCode_OR);
			extentReport.info(
					"3500 -V Verify that the fax Area-City Code should be 3 numeric digits if the associated fax number "
							+ "country code corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' "
							+ "- plus, ' ' - space are accepted as additional entry values but should be removed upon save and not re-displayed.");
			  
			extentReport.info("3600-S- Actor enters an invalid fax Area-City Code which uses alphabetic characters, which has more or less than 3 digits, then clicks save.");
			addCustomerPage.areaCodeAlphabetValidation(addCustomerPage.faxAreaCode_OR);
			extentReport.info("3700-V- Verify that system displays CS 816 with message that fax number value is invalid");			
			addCustomerPage.verifyInvalidFaxAreaCodeValidation();
			extentReport.info("3750- Repeat 3600 to 3700 with following values");			
			addCustomerPage.verifyPhoneNumberSymbolValidation(addCustomerPage.faxnumber_OR);
			extentReport.info("3800 V Verify that the fax Number should be 7 numeric digits if the associated fax number country code "
							+ "corresponds to the US (ie 1). '(' - open bracket, ')' - close bracket, ',' - comma, '.'- Dot, '-' - dash, '+' - plus, ' ' - "
							+ "space are accepted as additional entry values but should be removed upon save and not re-displayed.");			
			extentReport.info("3900-S-The Actor enters an invalid fax Number which uses alphabetic characters, which has more or less than 7 digits, then clicks save.");
			addCustomerPage.verifyValidFaxPhoneNumberValidation();
			extentReport.info("4000-V- Verify that system displays CS 816 with message that value is invalid");
			extentReport.info("4050 – Repeat steps 3900 – 4000 for following values:1. enter 1 123 123456 2. enter 1 123 12345678 3. enter 1 123 12A4567");
			addCustomerPage.verifyFaxNumberComplexValidation();
			extentReport.info("4100-S-The Actor enters a valid fax Number Complex, which has 1 numerical digit for country "
					+ "code, 3 numerical digits for Area City Code and 7 numerical digits for fax Number; then clicks save "
					+ "for example: 1 123 1234567 (1)1231234567 (1)(123)1234567 1-123-1234567 1-123-1234567");
			
			
			//Email address
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicEmail");
			extentReport.info("4700 -V The Email data entry field is displayed, is required, and defaults to empty/null value. Value: Associated with [Customer Email_Address]");
			addCustomerPage.enterValueInField("clinicFaxCountryCode", customer);
			extentReport.info("4800-S- Enter an invalid email in this Email Address field, which does not contain \"@\" , then clicks Save e.g. \"johns.sjm.com");
			addCustomerPage.verifyEmailAddressField();
			extentReport.info("4900-V- Verify that system displays CS 816 with message that email value is invalid");
			extentReport.info("5000-S- Enter an invalid email in this Email Address field, which does not contain \".\" , then click save  e.g. \"john@sjm\"");
			addCustomerPage.emailAddressFieldValidation();
			extentReport.info("5100-V- Verify that system displays CS 816 with message that email value is invalid");
			
			addCustomerPage.enterValueInField("VerifyEmail", customer);
			extentReport.info("5200-S-The Actor The actor enters an invalid email with 101 characters in the Email Address field, which contains \"@\" and '.' , then click save");
			addCustomerPage.verifyLength(addCustomerPage.email_OR, 100);
			extentReport.info("5300-V-The System will not allow the entry of more than 100 characters.");
			addCustomerPage.enterValueInField("clinicEmail", customer);
			extentReport.info("5400-S-The Actor The actor enters an valid email with in a range 1 - 100 characters in the Email Address field, which contains \"@\" and '.' , then clicks save e.g: john@ibm.com");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicTextMessage");
			extentReport.info("5500 -V Verify that the Text Message ID data entry field is is active, is displayed, defaults to empty/null value. Value: Associated with Customer.SMS ");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicTimeZone");
			extentReport.info("5600 -V Verify that the Clinic Time Zone dropdown field is active, is displayed, is required, and defaults to empty/null value. Value: Associated with Customer.Time_Zone_CD");
			addCustomerPage.verifyDropDownValuesWithDOOR("timezone", customer);
			extentReport.info("5700 -V Verify that the Clinic Time Zone dropdown selection values are correct as per matrix configuration. [Refer: Merlin .Net EP –HF Configuration >> Configurable Parameter >>Data Sets >> Clinic Time zone]");
			addCustomerPage.verifyClinicTimeZoneInOrder();
			extentReport.info("5800 V Clinic Time Zone Dropdown values should be sorted in GMT order overall (-GMT to +GMT).");
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("clinicLanguage");
			extentReport.info("5900 -V Verify that the Clinic Language dropdown field is active, is displayed, is required, and defaults to empty/null value. Value: Associated with [Customer.Locale_CD] ");
			
			addCustomerPage.verifyClinicLanguage();
			extentReport.info("6000 -V Verify that the Clinic Language dropdown selection values are correct.");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("legalJurisdictionText");
			extentReport.info("6100 -V Verify that the Clinic legal jurisdiction dropdown field is active, is displayed, is required, and defaults to empty/null value. Value: Associated with [Customer.Legal_Jurisdiction_CD] ");
			addCustomerPage.verifyClinicJurisdiction();			
			extentReport.info("6200 -V Verify that the Clinic legal jurisdiction dropdown selection values are correct.");
			
			addCustomerPage.verifyFieldsDisplayedEnabledAndEmpty("testClinicCheckBox.");
			extentReport.info("6300- V Verify that the \"Test Clinic\" checkbox is always displayed and active with default value Unchecked.value associated with [Customer.Test_Clinic_Flg].");
			
			addCustomerPage.ClickSaveBtn();
			addCustomerPage.verifyPhoneNumberinDBUponSave();
			extentReport.info("2500 -V-The System The phone number complex shall not be validated and shall not be stored to the database.");
			extentReport.info("4200-V-Verify that the system should save the value in the database. Verify that Phone Numbers ( Phone Data Type) should be displayed in the format 'ddd ddd ddd dddd' where d = any single decimal digit, any leading zeros will be displayed");
			
			extentReport.info("Test case ends");
			assertion.assertAll();
						
			
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_AD010_ClinicInfoSection_01 is failed due to assertion failure");
			e.printStackTrace();
			throw e;	
		
		} catch (Exception e) {
			extentReport.reportFail( "WA_AD010_ClinicInfoSection_01 is Validation not successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
