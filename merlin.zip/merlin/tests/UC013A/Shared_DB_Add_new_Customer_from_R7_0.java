package com.test.qa.ui.tests.UC013A;

import java.lang.reflect.Method;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;

import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

/***********************************************************************************/
// Saints Id :  1238756
// Test Case :  Shared DB- Add new Customer from R7.0
// Author    : Jeetendra Gupta
/***********************************************************************************/

public class Shared_DB_Add_new_Customer_from_R7_0 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	Login login_SJM_User;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	ClinicianHomeTopNavPage appHomeTopNavPage;
	Customer customer1, customer2;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DataBaseConnector dataBaseConnector;
	QueryResults qrresult;
	private String create_userid = null;
	private String create_dtm = null;
	private String UserName = null;
	private String userId = null;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		appHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		qrresult = new QueryResults();
		testDataProvider = new TestDataProvider();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups = {"Regression"})
	public void Shared_DB_Add_new_Customer() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		login_SJM_User = testDataProvider.getLoginData("SJMAdmin3");
		customer1 = testDataProvider.getCustomerData("Shared_DB_Add_new_Customer_from_R7_0_Data1");
		customer2 = testDataProvider.getCustomerData("Shared_DB_Add_new_Customer_from_R7_0_Data2");
		extentTest = extentReport.initiateTest(testName);
		extentTest.assignAuthor("Author-Jeetendra Gupta");// comments
		try {
			Assertions assertion = new Assertions(extentTest);
			/******************************************************************************************/
			extentReport.info(
					"100-S-The actor (SJM Enrollment Administrator) is logged into the Merlin.net system (R7.0) and navigates to Customer List page");
//---------------------------- 1. Create US clinic-------------------------
			loginPage.login(login_SJM_User,"internaluser");
			/******************************************************************************************/
			extentReport.info("200-S-The actor clicks the 'Add a customer' button");
			customerListPage.clickOnAddCustomerButton();
			/******************************************************************************************/
			extentReport.info("300--V-The system displays Add Customer Page");
			assertion.assertEqualsWithReporting(true, addCustomerPage.verifyLandingPage(), extentReport,
					"clicks the 'Add a customer' button");
			/******************************************************************************************/
			extentReport.info(
					"400-S- Enter below values Customer type- Service Provider Country- USA Legal Jurisdiction- USA");
			/******************************************************************************************/
			extentReport.info(
					"500-S- Complete customer profile by enteing valid values for all remaining mandatory fields");
			UserName = addCustomerPage.addCustomerfieldupdate(customer1, "Text");
			/******************************************************************************************/
			extentReport.info("600-S- Actor clicks on Save button");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
//			addCustomerPage.verifyAddCustomerConfirmMsg();
			addCustomerPage.verifyAddCustSuccessPopupAndClickOK();
			/******************************************************************************************/
			extentReport.info("700-S- Customer list will be displayed");
			/******************************************************************************************/
			extentReport.info("800-V- Verify that newly added customer is listed in Customer list");
			assertion.assertEqualsWithReporting(UserName, customerListPage.searchCustomerAndClick(UserName),
					extentReport, "Newly added customer is listed in Customer list");

			customerProfilePage.goToChangeCustomerProfilePage();

			userId = changeCustomerProfilePage.getCustomerId(UserName);

			/******************************************************************************************/
			extentReport.info("900-S- Login shared DB");
			dataBaseConnector.getConnection();

//extentReport.reportInfo("1000-V- Verify that newly added customer has entry created in migrated_clinic table. <ClncAcct179>");

			/******************************************************************************************/
			extentReport.reportInfo("1100-V- Verify that newly added customer has entry in customer table.");

			String query = "Select customer_id,name,create_userid,create_dtm from customers.customer where customer_id ='"
					+ userId + "'";
			Map<String, String> ResultSet = qrresult.customerTable_TC1238756(query);
			assertion.assertEquals(ResultSet.get("customer_id"), userId, "Customer Id");
			assertion.assertEquals(ResultSet.get("name"), UserName, "Customer Name");
			assertion.assertEquals(ResultSet.get("create_userid"), create_userid, "Creator Id");
			assertion.assertEquals(ResultSet.get("create_dtm"), create_dtm, "Creation Time Stamp");

			/******************************************************************************************/
			appHomeTopNavPage.clickSignOutLink();

//---------------------------- 1. Create OUS clinic-------------------------

			extentReport.info("1200-S-The actor clicks the 'Add a customer' button");
			loginPage.login(login_SJM_User);
			customerListPage.clickOnAddCustomerButton();
			/******************************************************************************************/
			extentReport.info("1300--V-The system displays Add Customer Page");
			addCustomerPage.verifyLandingPage();
			/******************************************************************************************/
			extentReport.info(
					"1400-S- Enter below values. Customer type- Direct Country- Germany Legal Jurisdiction- European Union");
			/******************************************************************************************/
			extentReport.info(
					"1500-S- Complete customer profile by enteing valid values for all remaining mandatory fields");
			/******************************************************************************************/
			extentReport.info("1600-S- Actor clicks on Save button");
			UserName = addCustomerPage.addCustomerfieldupdate(customer2, "Text");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmCancel();
			addCustomerPage.verifyAddCustomerConfirmMsg();
			addCustomerPage.verifyAddCustSuccessPopupAndClickOK();
			/******************************************************************************************/
			extentReport.info("1700-S- Customer list will be displayed.");

			/******************************************************************************************/
			extentReport.info("1800-V- Verify that newly added customer is listed in Customer list");

			assertion.assertEqualsWithReporting(UserName, customerListPage.searchCustomerAndClick(UserName),
					extentReport, "Newly added customer is listed in Customer list");

			customerProfilePage.goToChangeCustomerProfilePage();
			userId = changeCustomerProfilePage.getCustomerId(UserName);
			/******************************************************************************************/
			extentReport.info("1900-S- Login shared DB by user WEB_UI");

			dataBaseConnector.getConnection();

//extentReport.reportInfo("2000-V- Verify that newly added customer has entry created in migrated_clinic table.<ClncAcct179>");

			extentReport.info("2100-V- Verify that newly added customer has entry in customer table.");
			query = "Select customer_id,name,create_userid,create_dtm from customers.customer where customer_id ='"
					+ userId + "'";

			ResultSet = qrresult.customerTable_TC1238756(query);
			
			assertion.assertEquals(ResultSet.get("customer_id"), userId, "Customer Id");
			assertion.assertEquals(ResultSet.get("name"), UserName, "Customer Name");
			assertion.assertEquals(ResultSet.get("create_userid"), create_userid, "Creator Id");
			assertion.assertEquals(ResultSet.get("create_dtm"), create_dtm, "Creation Time Stamp");

			/******************************************************************************************/
			extentReport.takeFullSnapShot(driver,
					"2100-V- Verify that newly added customer has entry in customer table.");

			extentReport.info("Test case ends");
			assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.reportFail("Shared_DB_Add_new_Customer_from_R7_0 Validation not successfull");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.reportFail("Shared_DB_Add_new_Customer_from_R7_0 Validation not successfull");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}