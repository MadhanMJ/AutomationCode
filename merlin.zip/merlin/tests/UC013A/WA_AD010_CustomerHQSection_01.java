package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class WA_AD010_CustomerHQSection_01 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	Assertions assertion ;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DriverUtils drivereuse;Log logger;
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		logger = new Log();
		drivereuse=new DriverUtils(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}
	// Testcase id: 1244007, Testcase name: WA-AD010-CustomerHQSection_01
	@Test(groups= {"Regression"})
	public void WAAD010Securitysettings() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
        CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("AddCustomer");
		extentTest.assignAuthor("Author-Mohan Sekar");
		
		try {
			assertion =  new Assertions(extentTest);
			 extentReport.info( "100 -S Login to Admin and navigate to Customer list page.</br>200 -S Select a option to enroll a new customer");
			// adminLogin();
			loginPage.login(login,"internaluser");
			//assertion.assertEqualsWithReporting(addCustomerPage.verifyLandingPage(),true,extentReport,"Add Customer page is displayed successfully");
			// extentReport.info( "200 -S Select a option to enroll a new customer");
			addCustomerPage.addcustomerclick();
			extentReport.info( "300 -V Verify that the Customer Headquarters section stripe is displayed");
		    addCustomerPage.customerHeadquarters_Section_Stripe();
		    extentReport.info( "400 -V The Customer Name is a data entry field is active, is displayed, is required, and defaults to empty/null value.",new String[] {"ClncAcct321","ClncAcct6033"});
		    addCustomerPage.customerNameFieldValidation();
		    extentReport.info("500 -S Try entering more than 50 characters for Customer Name field");
		    addCustomerPage.customerNameLength(55);
		   	extentReport.info( "600 -V Verify that system dosen't let user enter more than 50 charcters",new String[] {"CommUI2797","CommUI2798"});
		   	addCustomerPage.customerNameLengthValidation();
			extentReport.info("700 -S Leave the Customer Name field blank. Provide data in all other mandatory fields</br> 800 -S Press Save.");
			//Validating  customer type options
		    addCustomerPage.FieldVerfication("CustomerName");
		    extentReport.info( "900 -S Verify that message CS 818 is displayed and border of Customer Name is marked in red",new String[] {"ClncAcct5911"});
		    addCustomerPage.ErrorFieldVerfication("CustomerName");
			extentReport.info( "1000 -V The Customer Type dropdown field is is active, is displayed, is a required field, and defaults to \"Direct,\" Input Customer's Type selection..",new String[] {"ClncAcct321","ClncAcct6033"});
			addCustomerPage.customerTypeDropdownValidation();
		    extentReport.info("1100 -V Verify that values displayed under Customer type are as per matrix configuration. [Refer: EP-HF Configuration >>Configurable Parameters >> DataSets>> Customer Type]");
		    addCustomerPage.customerTypeDropdownValidation(); 
		    extentTest=extentReport.info("Test Case Ends");
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_AD010_CustomerHQSection_01 Validation  is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;	
		} catch (Exception e) {
			extentReport.reportFail( "WA_AD010_CustomerHQSection_01 Validation not successfull");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		saintResult(result,extentTest);
		}

}
