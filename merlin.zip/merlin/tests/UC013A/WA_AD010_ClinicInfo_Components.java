package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class WA_AD010_ClinicInfo_Components extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	DataBaseConnector dataBaseConnector;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DriverUtils drivereuse;
	Log logger;
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		drivereuse=new DriverUtils(driver,extentReport);
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		 logger = new Log();
		testDataProvider = new TestDataProvider();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void ClinicInfoComponents () throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("AddCustomer");
		CommonUtils.iteration = login.getIteration();
		extentTest = extentReport.initiateTest(testName + "_Iteration_" + iteration);
		CommonUtils.extentTest = extentTest;
		extentTest.assignAuthor("Author-Mohan Sekar");
		try {
			Assertions assertion =  new Assertions(extentTest);
		//	System.out.println("CustomerID: "+customer.getUserid());
			Thread.sleep(3000);
			extentReport.info( "100-S-The actor (SJM Enrollment Administrator) is logged into the system and navigates to page AD001(Customer List)");
			loginPage.login(login,"internaluser");
			Boolean loginCheck = customerListPage.verifyLandingPage();
			//Assert.assertTrue(loginCheck);
			addCustomerPage.loading();
			
			extentReport.info( "200-S-The actor clicks the Add a customer menu item.");
			
	    	addCustomerPage.addcustomerclick();
			addCustomerPage.loading();
			extentReport.info( "300-V-The system displays page AD010 (Add Customer)");
			addCustomerPage.loading();
			drivereuse.scrollToView(addCustomerPage.customerName);
			addCustomerPage.loading();
			
			extentTest=extentReport.info( "310-V- Verify the page should display the following");
			
			extentReport.takeFullSnapShot(driver,"View Customer Page Full Screenshot");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.customerName), "Add Customer Page Customer Name Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.customerType), "Add Customer Page Customer Type Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.clinicLocation_OR), "Add Customer Page clinic Location  Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.clinicAddress_1), "Add Customer Page Clinic Address Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.clinicCity), "Add Customer Page City Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.stateProvinceDropDown), "Add Customer Page State Procince Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.country_OR), "Add Customer Page Country Validation"); 
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.zipPostalCode), "Add Customer Page Zip Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.mainPhone_OR), "Add Customer Page Main Phone Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.secPhone), "Add Customer Page Secondary Phone Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.faxNumber), "Add Customer Page Fax Number Validation");
		    assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.textMessage), "Add Customer Page Text Message Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.email_OR), "Add Customer Page Email Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.clinicLanguage_OR), "Add Customer Page clinic Language Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.clinicTimeZone_OR), "Add Customer Page clinic TimeZone Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.legalJurisdiction), "Add Customer Page legal Jurisdiction Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.testClinic), "Add Customer Page Test Clinic Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.onDemandFeatureControl), "Add Customer Page onDemandFeatureControl Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.userId_OR), "Add Customer Page userId Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.password_OR), "Add Customer Page password Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.firstName_OR), "Add Customer Page firstName Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.lastName_OR), "Add Customer Page lastName Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.middleName), "Add Customer Page middleName Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.credentials), "Add Customer Page credentials Validation");
			assertion.assertEquals(true, addCustomerPage.isElementPresent(addCustomerPage.emailId), "Add Customer Page Email Id Validation");
			extentTest=extentReport.info( "310-V- Verify the page should display the following Mandatory check for fields");
			CommonUtils.extentTest = extentTest;
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.customerName,"aria-required")), "Add Customer Page Customer Name Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.customerType,"aria-required")), "Add Customer Page customer Type Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.clinicAddress_1,"aria-required")), "Add Customer Page clinic Address Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.clinicLocation_OR,"aria-required")), "Add Customer Page clinic LocationValidation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.clinicCity,"aria-required")), "Add Customer Page clinic City Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.stateProvinceDropDown,"aria-required")), "Add Customer Page state/Province Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.country_OR,"aria-required")), "Add Customer Page country Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.zipPostalCode,"aria-required")), "Add Customer Page zip Postal Code Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.mainPhone_OR,"aria-required")), "Add Customer Page main Phone Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.secPhone,"aria-required")), "Add Customer Page secondary Phone Name Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.faxNumber,"aria-required")), "Add Customer Page fax Number Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.textMessage,"aria-required")), "Add Customer Page Text Message Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.email_OR,"aria-required")), "Add Customer Page Email Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.clinicLanguage_OR,"aria-required")), "Add Customer Page clinic Language Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.clinicTimeZone_OR,"aria-required")), "Add Customer Page clinic TimeZone Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.legalJurisdiction,"aria-required")), "Add Customer Page legal Jurisdiction Validation");
			assertion.assertEquals(false,addCustomerPage.Stringtoboolean( addCustomerPage.getAttribute(addCustomerPage.testClinic,"aria-required")), "Add Customer Page Test Clinic Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.onDemandFeatureControl,"aria-required")), "Add Customer Page onDemand FeatureControl Validation");
			assertion.assertEquals(true,addCustomerPage.Stringtoboolean( addCustomerPage.getAttribute(addCustomerPage.userId_OR,"aria-required")), "Add Customer Page user Id Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.password_OR,"aria-required")), "Add Customer Page password Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.firstName_OR,"aria-required")), "Add Customer Page firstName Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.lastName_OR,"aria-required")), "Add Customer Page lastName Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.middleName,"aria-required")), "Add Customer Page middleName Validation");
			assertion.assertEquals(false, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.credentials,"aria-required")), "Add Customer Page credentials Validation");
			assertion.assertEquals(true, addCustomerPage.Stringtoboolean(addCustomerPage.getAttribute(addCustomerPage.emailId,"aria-required")), "Add Customer Page email Id Validation");
			
			addCustomerPage.addCustomerfieldupdate( customer, "Text");	
			extentTest=extentReport.info( "400-V- Verify that all the required fields are entered on the Add Customer page.",new String[] {"ClncAcct6014"});
			
			assertion.assertEquals(true, addCustomerPage.ErrorSize(), "Add Customer Page Mandatory Fields validations");
			
			extentReport.takeFullSnapShot(driver,"Add Customer Page with All values");
			extentTest=extentReport.info( "500-V- Verify that all the fields entered are valid on  Add Customer page.",new String[] {"ClncAcct6012"});
			
			assertion.assertEquals(true, addCustomerPage.ErrorSize(), "Add Customer Page Mandatory Fields validations");
			addCustomerPage.scrollToView(addCustomerPage.password_OR);
			extentTest=extentReport.info( "600-V- Verify that the Main Contact new password meets the password validation rules. ",new String[] {"ClncAcct6015"});
			
			
			assertion.assertEquals(false, addCustomerPage.isElementPresent(addCustomerPage.passwordError), "Add Customer Page Password Validation");
			extentTest=extentReport.info( "700-V- Verify that the entry in the Main Contact new password equals the entry in the Main Contact confirm password on the Add Customer page. ",new String[] {"ClncAcct6016"});
			
			
			assertion.assertEquals(false, addCustomerPage.isElementPresent(addCustomerPage.newPasswordError), "Add Customer Page Password Validation");
			
			
			extentTest=extentReport.info( "800-V- Verify that the UserID for the Main Contact is new and unique",new String[] {"ClncAcct6017"});
			dataBaseConnector.getConnection();
			//DB validation for unique
			String text=drivereuse.getAttribute(addCustomerPage.userId_OR, "value");
			
			ArrayList<String> customerRecord1 =  dataBaseConnector.datatable("SELECT  logon_user_name FROM users.user_record where logon_user_name ='"+text+"';","logon_user_name");
			int Size=customerRecord1.size();
			
			assertion.assertEquals(true, addCustomerPage.resultsetsize(Size), "User Id is Unique and New");
			assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_AD010_ClinicInfo_Components Validation  is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;	
		
		} catch (Exception e) {
			extentReport.reportFail( "WA_AD010_ClinicInfo_Components Validation not successfull");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		
		saintResult(result,extentTest);

	}
}