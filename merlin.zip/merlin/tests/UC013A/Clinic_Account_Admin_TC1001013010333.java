package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class Clinic_Account_Admin_TC1001013010333 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	DataBaseConnector dataBaseConnector;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	DriverUtils drivereuse;
	Log logger;
	@BeforeClass
	public void initialize() {
		drivereuse=new DriverUtils(driver,extentReport);
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		 logger = new Log();
		testDataProvider = new TestDataProvider();
		dataBaseConnector = new DataBaseConnector();
	}


	@Test(dataProvider = "TestData", dataProviderClass = TestDataProvider.class)
	public void ClinicInfoComponents (String iteration, String username, String password,String customerName,String userid,String customerType,
			String clinicLocation, String countryCode, String areaCode, String mainPhone, String country, String email,
			String clinicTimeZone, String legalJurisdiction, String clinicLanguage, String newPassword,
			String confirmNewPassword, String firstName, String lastName, String emailId, String ElecExport) throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("AddCustomer");
		
		CommonUtils.iteration = login.getIteration();
		
		extentTest = extentReport.initiateTest(testName + "_Iteration_" + iteration);
		CommonUtils.extentTest = extentTest;
			
		extentTest.assignAuthor("Author-Victor");
		try {
			Assertions assertion =  new Assertions(extentTest);
			System.out.println("CustomerID: "+customer.getUserid());
			Thread.sleep(3000);
			extentReport.reportInfo( "100 S Login to system using admin account");
			loginPage.login(login);
			Boolean loginCheck = customerListPage.verifyLandingPage();
			Assert.assertTrue(loginCheck);
			addCustomerPage.loading();
			extentReport.reportInfo( "200 S Navigate to Customer list page");
	    	addCustomerPage.addcustomerclick();
			addCustomerPage.loading();
			extentReport.reportInfo( "300 S Click on Add a customer button");
			addCustomerPage.loading();
			drivereuse.scrollToView(addCustomerPage.customerName);
			addCustomerPage.loading();
			
			
			extentTest=extentReport.info( "400 V The Clinic Main Contact section header is displayed.",new String[] {"ClncAcct6524"});
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.clinicMainContactHeader), extentTest, "Add Customer Page Clinic Main contact Header section Validation");
			
			CommonUtils.extentTest = extentTest;
			extentReport.reportScreenShot("View Customer Page Full Screenshot");
			
			extentTest=extentReport.info( "500 V The User ID data entry field is active, defaults to empty/null value, is required, and is displayed.",new String[] {"ClncAcct6014"});
			CommonUtils.extentTest = extentTest;
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.customerName), extentTest, "Add Customer Page Customer Name Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.customerType), extentTest, "Add Customer Page Customer Type Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.clinicLocation), extentTest, "Add Customer Page clinic Location  Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.clinicAddress_1), extentTest, "Add Customer Page Clinic Address Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.clinicCity), extentTest, "Add Customer Page City Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.stateProvinceDropDown), extentTest, "Add Customer Page State Procince Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.country), extentTest, "Add Customer Page Country Validation"); 
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.zipPostalCode), extentTest, "Add Customer Page Zip Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.mainPhone), extentTest, "Add Customer Page Main Phone Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.secPhone), extentTest, "Add Customer Page Secondary Phone Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.faxNumber), extentTest, "Add Customer Page Fax Number Validation");
		    assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.textMessage), extentTest, "Add Customer Page Text Message Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.email), extentTest, "Add Customer Page Email Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.clinicLanguage), extentTest, "Add Customer Page clinic Language Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.clinicTimeZone), extentTest, "Add Customer Page clinic TimeZone Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.legalJurisdiction), extentTest, "Add Customer Page legal Jurisdiction Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.testClinic), extentTest, "Add Customer Page Test Clinic Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.activatorClinic), extentTest, "Add Customer Page Activator Clinic Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.onDemandFeatureControl), extentTest, "Add Customer Page Merlin On Demand Feature Control Validation");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.userId), extentTest, "Add Customer Page userId Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.password), extentTest, "Add Customer Page password Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.confirmNewPassword), extentTest, "Add Customer Page Confirm password Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.firstName), extentTest, "Add Customer Page firstName Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.lastName), extentTest, "Add Customer Page lastName Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.middleName), extentTest, "Add Customer Page middleName Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.credentials), extentTest, "Add Customer Page credentials Validation in Clinic main contact section");
			assertion.assertEqualsWithReporting(true, addCustomerPage.isElementPresent(addCustomerPage.emailId), extentTest, "Add Customer Page Email Id Validation");
			
			
					
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.userId,"required")),extentTest,"Verify User ID data entry field is required");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.password,"required")),extentTest,"Verify password data entry field is required");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.confirmNewPassword,"required")),extentTest,"Verify Confirm password data entry field is required");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.firstName,"required")),extentTest,"Verify firstName data entry field is required");
		//	assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.credentials,"required")),extentTest,"Verify credentials data entry field is required");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.lastName,"required")),extentTest,"Verify lastName data entry field is required");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.emailId,"required")),extentTest,"Verify Email Id data entry field is required");
			assertion.assertEqualsWithReporting(false,(addCustomerPage.isAttributeAvailable(addCustomerPage.middleName,"required")),extentTest,"Verify middleName data entry field is not required");
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.userId).length() == 0),extentTest,"Verify User ID data entry field is default empty value");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.password).length() == 0),extentTest,"Verify password data entry field is default empty value");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.confirmNewPassword).length() == 0),extentTest,"Verify Confirm password data entry field is default empty value");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.firstName).length() == 0),extentTest,"Verify firstName data entry field is default empty value");
		//	assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.credentials).length() == 0),extentTest,"Verify credentials data entry field is default empty value");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.lastName).length() == 0),extentTest,"Verify lastName data entry field is default empty value");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.emailId).length() == 0),extentTest,"Verify Email Id data entry field is default empty value");
		//	assertion.assertEqualsWithReporting(false,(addCustomerPage.getText(addCustomerPage.middleName).length() == 0),extentTest,"Verify middleName data entry field is not default empty value");
		
			assertion.assertEqualsWithReporting(true, addCustomerPage.ErrorSize(), extentTest, "Add Customer Page Mandatory Fields validations");
			
			extentReport.reportScreenShot("Add Customer Page with All values");
			extentTest=extentReport.info( "600 S Enter valid details in all required fields & enter invalid user ids in the �user id� field then click save");
			
			String invalidUserid= "12282021";
			String successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			System.out.println(addCustomerPage.getText(addCustomerPage.useridErrorText));
			
			extentTest=extentReport.info( "700 V Verify that system displays CM 816 with message that user id value is invalid. ");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.useridErrorText).contains("UserId doesn't meet the minimum")),extentTest,"CM 816 with message that user id value is invalid");
		
 			
			extentTest=extentReport.info( "800.1 S Enter invalid user ids in the �user id� field for following values & then click save 800.1. enter 21 characters");
			invalidUserid= "Userid21ChractersTest";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			
			extentTest=extentReport.info( "900.1 V Verify that system displays CM 816 with message that user id value is invalid (Negative Test) <ClncAcct6012> <CommUI4802> <CommUI4803> <CommFn790> ");
			assertion.assertEqualsWithReporting(false,(addCustomerPage.getText(addCustomerPage.userId).length() == invalidUserid.length()),extentTest,"900.1 V Verify that system displays CM 816 with message that user id value is invalid (Negative Test) <ClncAcct6012> <CommUI4802> <CommUI4803> <CommFn790> ");
		
			extentTest=extentReport.info( "800.2 S Enter invalid user ids in the �user id� field for following values & then click save 800.2. enter blank. <--User ID starts with space(s)/blank(s)");
			invalidUserid= " LeadSpaceTest";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
		
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.useridErrorText).contains("UserId doesn't meet the minimum")),extentTest,"CM 816 with message that user id value is invalid");
			extentTest=extentReport.info( "900.2 V Verify that system displays CM 816 with message that user id value is invalid (Negative Test) <ClncAcct6012> <CommUI4802> <CommUI4803> <CommFn790> ");
			
			extentTest=extentReport.info( "800.3 S Enter invalid user ids in the �user id� field for following values & then click save enter all possible negative boundary conditions. * Space(s) or Blank(s) to start the User ID are invalid");
			
			invalidUserid= "*negativeTest";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.useridErrorText).contains("UserId doesn't meet the minimum")),extentTest,"CM 816 with message that user id value is invalid");
			extentTest=extentReport.info( "900.3 V Verify that system displays CM 816 with message that user id value is invalid (Negative Test) <ClncAcct6012> <CommUI4802> <CommUI4803> <CommFn790> ");
			
			
			extentTest=extentReport.info( "1000 S Enter User ID fill blank or keep it empty and then click on Save button");
			invalidUserid= "";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.useridErrorText).contains("UserId doesn't meet the minimum")),extentTest,"CM 816 with message that user id value is invalid");
			extentTest=extentReport.info( "1100 V Verify that message <msg.cs818.text> is displayed for empty User ID details. (Negative Test) ");
		
			Date date = Calendar.getInstance().getTime();  
			DateFormat dateFormat = new SimpleDateFormat("yyyymmddhh_mm_ss");  
			String strDate = dateFormat.format(date);  
		
			extentTest=extentReport.info( "1200 S Enter a valid userid in the 'userid' field then click on save");
			invalidUserid= "Usid"+strDate;
			customerName="Customer"+strDate;
			System.out.println(customerName);
			successMessage = addCustomerPage.addCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "1300 V Verify that the new User Id's entered to the System as input should be validated to ensure they conform to the following rules ");
			addCustomerPage.addcustomerclick();

			extentTest=extentReport.info( "1400 V Verify that UserID's are unique across the application");
			invalidUserid= "Usid"+strDate;
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(true,(successMessage.contains("User already exists with the given username")),extentTest,"CM 816 with message that user id value is invalid");
			
		
			extentTest=extentReport.info( "1500 S Navigate to Customer list page. Click on Enroll new customer button. Enter all required valid entries in the add customer page except User ID field. Enter newly created User ID in the User Id field & click on Save button.");
			
			invalidUserid= "Usid"+strDate;
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(true,(successMessage.contains("User already exists with the given username")),extentTest,"userid is already in use & not allow to save with existing");

			extentTest=extentReport.info( "1600 V Verify that system displays error message indicating userid is already in use & not allow to save with existing active User ID. (Negative Test) <CommFn467>");
		
			addCustomerPage.addCustomerCancel();
			//assertion.assertEqualsWithReporting(true,addCustomerPage.searchCustomer(customerName),extentTest,"Search with existing Active customer");
			
			
			//addCustomerPage.deleteButtonClick();
			
			extentTest=extentReport.info( "2200 S Click on Enroll new customer button on customer list page.");
			addCustomerPage.addcustomerclick();
			
		
			extentTest=extentReport.info( "2300 V The Password data entry field is active, is required, defaults to empty/null value, and is displayed. Value: Associated with [User_Record_ID.Logon_User_Name] <ClncAcct6521> <ClncAcct6524>");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.password,"required")),extentTest,"Verify password data entry field is required");
			
			
			
			extentTest=extentReport.info( "2400 V The Confirm New Password data entry field is active, defaults to empty/null value, is required, and is displayed. <ClncAcct6521> <ClncAcct6524>");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.isAttributeAvailable(addCustomerPage.confirmNewPassword,"required")),extentTest,"Verify Confirm password data entry field is required");
			
		
			extentTest=extentReport.info( "2500 S Enter all valid entries in all required fields and enter valid password & confirm password but both are not matching. Click on Save button.");
			invalidUserid= "Uid"+strDate;
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword+"a", firstName, lastName, emailId, ElecExport);
			
		
			extentTest=extentReport.info( "2600 V Verify that an error message < msg.cs820.text> is displayed indicating that new password and confirmation password are not the same. <CommUI4637>");	
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.confirmPasswordErrorText).contains("Password and Re-Enter Password should match")),extentTest,"error message < msg.cs820.text> is displayed indicating that new password and confirmation password are not the same. <CommUI4637>");
			
			
		
			extentTest=extentReport.info( "2700.1 1. enter password less than 8 characters: ab123, $123 S Enter invalid passwords for following values, then clicks save.");
			invalidUserid= "Uid"+strDate;
			newPassword="ab123";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, newPassword, firstName, lastName, emailId, ElecExport);
			System.out.println(addCustomerPage.getText(addCustomerPage.password).length());
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.PasswordErrorText).contains("Password doesn't meet the minimum requirement. Please see the info icon for more detials")),extentTest,"error message < msg.cs820.text> is displayed indicating that new password and confirmation password are not the same. <CommUI4637>");
			
			extentTest=extentReport.info( "2800.1.1 V Verify that system displays CS 821 with message that password value is invalid (Negative Test) <ClncAcct6012> <CommUI4637> <CommUI4638>");
			assertion.assertEqualsWithReporting(true,(successMessage.contains("Some mandatory fields are not filled. Please check for the inline errors!!!")),extentTest,"ClncAcct6012 The Add Customer page shall validate that all the fields entered are valid.");
			newPassword="abgrefs*$#";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, newPassword, firstName, lastName, emailId, ElecExport);
			System.out.println(addCustomerPage.getText(addCustomerPage.password).length());
			extentTest=extentReport.info( "2700.1 2. enter password abgrefs*$# S Enter invalid passwords for following values, then clicks save.");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.PasswordErrorText).contains("Password doesn't meet the minimum requirement. Please see the info icon for more detials")),extentTest,"error message < msg.cs820.text> is displayed indicating that new password and confirmation password are not the same. <CommUI4637>");
			extentTest=extentReport.info( "2800.1.2 V Verify that system displays CS 821 with message that password value is invalid (Negative Test) <ClncAcct6012> <CommUI4637> <CommUI4638>");
			assertion.assertEqualsWithReporting(true,(successMessage.contains("Some mandatory fields are not filled. Please check for the inline errors!!!")),extentTest,"ClncAcct6012 The Add Customer page shall validate that all the fields entered are valid.");
			
			extentTest=extentReport.info( "2700.1 3. enter password abcdef S Enter invalid passwords for following values, then clicks save.");
			newPassword="abcdef";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, newPassword, firstName, lastName, emailId, ElecExport);
			System.out.println(addCustomerPage.getText(addCustomerPage.password));
			
			extentTest=extentReport.info( "2800.1.3 V Verify that system displays CS 821 with message that password value is invalid (Negative Test) <ClncAcct6012> <CommUI4637> <CommUI4638>");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.PasswordErrorText).contains("Password doesn't meet the minimum requirement. Please see the info icon for more detials")),extentTest,"error message < msg.cs820.text> is displayed indicating that new password and confirmation password are not the same. <CommUI4637>");
			
			assertion.assertEqualsWithReporting(true,(successMessage.contains("Some mandatory fields are not filled. Please check for the inline errors!!!")),extentTest,"ClncAcct6012 The Add Customer page shall validate that all the fields entered are valid.");
			
			newPassword="ABCDDEFG";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, newPassword, firstName, lastName, emailId, ElecExport);
			System.out.println(addCustomerPage.getText(addCustomerPage.password));
			extentTest=extentReport.info( "2700.1 4. enter password abcdef S Enter invalid passwords for following values, then clicks save.");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.PasswordErrorText).contains("Password doesn't meet the minimum requirement. Please see the info icon for more detials")),extentTest,"error message < msg.cs820.text> is displayed indicating that new password and confirmation password are not the same. <CommUI4637>");
			extentTest=extentReport.info( "2800.1.4 V Verify that system displays CS 821 with message that password value is invalid (Negative Test) <ClncAcct6012> <CommUI4637> <CommUI4638>");
			assertion.assertEqualsWithReporting(true,(successMessage.contains("Some mandatory fields are not filled. Please check for the inline errors!!!")),extentTest,"ClncAcct6012 The Add Customer page shall validate that all the fields entered are valid.");
			
			
			newPassword="Abc$1234";
			successMessage = addCustomerPage.EnterValueandSaveCustomer(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, newPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "3000 S Enter valid passwords in the Password field, then clicks save");
			assertion.assertEqualsWithReporting(true,(newPassword.length()>6),extentTest,"Password must be 6 or more characters in length");
			assertion.assertEqualsWithReporting(true,(newPassword.length()<20),extentTest,"less than or equal to 20 characters in length");
			assertion.assertEqualsWithReporting(true,newPassword.matches(".*[a-z].*"),extentTest,"Valid characters include: (a-z)");
				assertion.assertEqualsWithReporting(true,(newPassword.matches(".*[A-Z].*")),extentTest,"Valid characters include: -Upper case letters (A, B, C, �.Z) ");
			assertion.assertEqualsWithReporting(true,(newPassword.matches(".*[0-9].*")),extentTest,"Valid characters include: Numeric Digits");
			boolean specialChar = false;
			String specialCharactersString = "[~!#$^()-_+{}[]:;<>,.?*]";
	        for (int i=0; i < newPassword.length() ; i++)
	        {
	            char ch = newPassword.charAt(i);
	            if(specialCharactersString.contains(Character.toString(ch))) {
	                System.out.println(ch+ " contains special character");
	                specialChar=true;
	                break;
	            }    
	            else if(i == newPassword.length()-1)     
	                System.out.println(newPassword+ " does NOT contain special character");
	        }
			assertion.assertEqualsWithReporting(true,specialChar,extentTest,"Valid characters include: [~!#$^()-_+{}[]:;<>,.?*]");
			extentTest=extentReport.info( "3100 V Verify that the password entered to the System should be validated to ensure they conform with the following:");
			
			
			//3200 V Verify that the password is hidden and should be displayed as '*'s. <CommUI4638>
			//3300 V Verify that the Confirm Password is hidden and should be displayed as '*'s. <CommUI4638>
			
			
			addCustomerPage.addcustomerclick();
			extentTest=extentReport.info( "3400 S Navigate to Customer list page. Click on Enroll new customer button.");
		
				
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.firstName).length() == 0),extentTest,"Verify firstName data entry field is default empty value");
			extentTest=extentReport.info( "3500 V The First name data entry field is active, defaults to empty/null value, is required, and is displayed. <ClncAcct6521> <ClncAcct6524>");
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.middleName).length() == 0),extentTest,"Verify middleName data entry field is default empty value");
			extentTest=extentReport.info( "3600 V The Middle Name data entry field is active, is displayed, and defaults to empty/null value. <ClncAcct6521> <ClncAcct6524>");
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.lastName).length() == 0),extentTest,"Verify lastName data entry field is default empty value");
			extentTest=extentReport.info( "3700 V The Last name data entry field is active, is displayed, is required, and defaults to empty/null value. <ClncAcct6521> <ClncAcct6524>");
			
			
			invalidUserid= "Usid"+strDate;
			firstName="FirstnameMorethanThirtyCharctersAbc";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "3800 S Enter all required input fields on new customer page. Enter more than 30 characters to First name field");
			assertion.assertEqualsWithReporting(false,(addCustomerPage.getText(addCustomerPage.firstName).length() == firstName.length()),extentTest,"Verify that system does not allow entering more than 30 characters");
			
			extentTest=extentReport.info( "3900 V Verify that system does not allow entering more than 30 characters (Negative Test) <CommUI4622>");
		
			//
			extentTest=extentReport.info( "4000 S Enter exactly 30 characters in First name.");
			invalidUserid= "Usid"+strDate;
			firstName="FirstnameeExactThirtyCharcters";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.firstName).length() == firstName.length()),extentTest,"Verify that system  allow entering exact 30 characters");
			
			extentTest=extentReport.info( "4100 V Verify that system allows entering exact 30 characters <CommUI4622>");
			
			
			extentTest=extentReport.info( "4200 S Enroll new Customer on customer list page. Enter all valid data in required fields & delete data from field and click save.");
			invalidUserid= "Usid"+strDate;
			firstName="FirstnameMorethanThirtyCharctr";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			successMessage = addCustomerPage.ClearAllfields();
			successMessage = addCustomerPage.SaveCustomer();
			assertion.assertEqualsWithReporting(true,(successMessage.contains("Some mandatory fields are not filled. Please check for the inline errors!!!")),extentTest,"ClncAcct6012 The Add Customer page shall validate that all the fields entered are valid.");
			extentTest=extentReport.info( "4300 V Verify that CS 818 is displayed with message that field is mandatory. (Negative Test) <ClncAcct6014>");
				
		
			invalidUserid= "Usid"+strDate;
			String middleName="MiddlenameMorethanThirtyCharcter";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			addCustomerPage.EnterMiddleName(middleName);
			extentTest=extentReport.info( "4400 S For a new customer creation, enter more than 30 characters to Middle name field.");
			assertion.assertEqualsWithReporting(false,(addCustomerPage.EnterMiddleName(middleName).length() == middleName.length()),extentTest,"4500 V Verify that system does not allow entering more than 30 characters (Negative Test) <CommUI4622>");
			
			extentTest=extentReport.info( "4600 S Enter exactly 30 characters & clicks on Save button.");
			invalidUserid= "Usid"+strDate;
			middleName="MiddlenameExactThirtyCharcters";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			addCustomerPage.EnterMiddleName(middleName);
			assertion.assertEqualsWithReporting(true,(addCustomerPage.EnterMiddleName(middleName).length() == middleName.length()),extentTest,"4700 V Verify that system allows entering exact 30 characters in middle name field. <CommUI4622>");
			
			
			addCustomerPage.addcustomerclick();
			extentTest=extentReport.info( "4800 S Navigate to Customer list page. Click on Enroll new customer button.");
		
			extentTest=extentReport.info( "4900 S Enter all required input fields on new customer page. Enter more than 30 characters to Last name field");
			invalidUserid= "Usid"+strDate;
			lastName ="LastNameMorethanThirtyCharcters";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(false,(addCustomerPage.getText(addCustomerPage.lastName).length() == lastName.length()),extentTest,"5000 V Verify that system does not allow entering more than 30 characters (Negative Test) <CommUI4622>");
			
			
			addCustomerPage.enterLastName("");
			successMessage=addCustomerPage.SaveCustomer();
			extentTest=extentReport.info( "5100 S Delete data from field and click save.");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.lastnameError).contains("This field should not be empty...")),extentTest,"5200 V Verify that CS 818 is displayed with message that field is mandatory (Negative Test) <ClncAcct6014>");
			
			
			extentTest=extentReport.info( "5300 S Enter exactly 30 characters");
			invalidUserid= "Usid"+strDate;
			lastName ="LastNameExactlyThirtyCharcters";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.lastName).length() == lastName.length()),extentTest,"5400 V Verify that system allows entering exact 30 characters <CommUI4622>");
		
			
			addCustomerPage.addcustomerclick();
			extentTest=extentReport.info( "5500 S Navigate to Customer List page. Enroll new Customer.");
		
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.clinicMainContactcredentialsCd).length() == 0),extentTest,"V Credentials dropdown field is active, is displayed, and defaults to empty/null value");
			extentTest=extentReport.info( "5600 V Credentials dropdown field is active, is displayed, and defaults to empty/null value. <ClncAcct6521> <ClncAcct6524>");
		
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.clinicmaincontactEmail).length() == 0),extentTest,"The Clinic Main Contact Email address data entry field is active, is displayed, is required, and defaults to empty/null value");
			extentTest=extentReport.info( "5800 V The Clinic Main Contact Email address data entry field is active, is displayed, is required, and defaults to empty/null value. <ClncAcct6521> <ClncAcct6524>");
		
		
			invalidUserid= "Usid"+strDate;
			email="invalidemail.com";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "5900 S Enter all required entries in the input fields. Enter an invalid email in this Email Address field, which does not contain \"@\" , then clicks Save e.g. \"johns.sjm.com\"");
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.emailError).contains("enter a valid email address")),extentTest,"6000 V Verify that system displays CS 816 with message that email value is invalid (Negative Test) <ClncAcct6012> <CommUI4552>");
		
			invalidUserid= "Usid"+strDate;
			email="invalidemail@com";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "6100 S Enter an invalid email in this Email Address field, which does not contain \".\" , then click save  e.g. \"john@sjm\"");
			
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.emailError).contains("enter a valid email address")),extentTest,"6200 V Verify that system displays CS 816 with message that email value is invalid (Negative Test) <ClncAcct6012> <CommUI4552>");
			
			invalidUserid= "Usid"+strDate;
	            		
			email="enterinvalidonehundredandenterinvalidonehundredandenterinvalidonehundredandenterinvalidone@hundre.com";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "6300 S The actor enters an invalid email with 101 characters in the Email Address field, which contains \"@\" and '.' , then click save");
			
			assertion.assertEqualsWithReporting(false,(addCustomerPage.getText(addCustomerPage.email).length() == email.length()),extentTest,"6400 V The System will not allow the entry of more than 100 characters. (Negative Test) <CommUI4552>");
			
				//
			invalidUserid= "Usid"+strDate;
			email="entervalidonehundredentervalidonehundredentervalidonehundredentervalidonehundredentervalid@hundr.com";
			successMessage = addCustomerPage.EnterValueAllfields(customerName, invalidUserid,customerType, clinicLocation, countryCode, areaCode, mainPhone,country, email, clinicTimeZone, legalJurisdiction, clinicLanguage, newPassword, confirmNewPassword, firstName, lastName, emailId, ElecExport);
			extentTest=extentReport.info( "6500 S The actor enters a valid email with in a range 1 - 100 characters in the Email Address field, which contains \"@\" and '.' , then clicks save e.g: john@ibm.com <CommUI4552>");
			assertion.assertEqualsWithReporting(true,(addCustomerPage.getText(addCustomerPage.email).length() == email.length()),extentTest,"6600 V The System will allow the entry of valid email with range of 1-100 characters. <CommUI4552>");
			
		
		} catch (AssertionError e) {
			extentReport.reportFail( "WA_AD010_ClinicInfo_Components Validation  is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;	
		
		} catch (Exception e) {
			extentReport.reportFail( "WA_AD010_ClinicInfo_Components Validation not successfull");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
