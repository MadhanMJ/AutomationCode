package com.test.qa.ui.tests.UC013A;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;

public class Partition_CreateClinic_001 extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	DataBaseConnector dataBaseConnector;
	AddCustomerPage addCustomerPage;
	private String testName;
	TestDataProvider testDataProvider;
	String partitionTypeCD;
	int customerTypeCD;
	DriverUtils drivereuse;
	Log logger;
	@BeforeClass
	public void initialize() {
		drivereuse=new DriverUtils(driver,extentReport);
		//driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		addCustomerPage=new AddCustomerPage(driver,extentReport);
		customer  =  new Customer();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		dataBaseConnector = new DataBaseConnector();
	}

	@Test
	public void TC_Partition_CreateClinic_001() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("AddCustomer");
		
		CommonUtils.iteration = login.getIteration();
		
		extentTest = extentReport.initiateTest(testName + "_Iteration_" + iteration);
		CommonUtils.extentTest = extentTest;
		extentTest.assignAuthor("Author-Salin Gambhir");
		try {
			Assertions assertion =  new Assertions(extentTest);
			//creating a data for clinic having Partition enabled
			extentReport.reportInfo( "100 S Enroll Clinic A (Direct type Clinic that is identified for partition)");
			loginPage.login(login);
			Boolean loginCheck = customerListPage.verifyLandingPage();
			Assert.assertTrue(loginCheck);
			extentReport.reportInfo( "200 V Verify that the Partition_Type_Cd column gets updated with code 'BY_CLINIC' in the Customer table");
			
			dataBaseConnector.getConnection();
			
			String query = "select partition_type_cd from customers.customer c where \"name\" = 'SAL_TEST_Direct'";
			
			ResultSet partitionTypeCDRecord = dataBaseConnector.executeQuery(query);
			
			while (partitionTypeCDRecord.next()) {
				partitionTypeCD = partitionTypeCDRecord.getString("partition_type_cd");
				customerTypeCD = partitionTypeCDRecord.getInt("customer_type_cd");
			}	
			
			
			
			
			
		} catch (AssertionError e) {
			extentReport.reportFail( "Partition_CreateClinic_001 Validation  is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;	
		
		} catch (Exception e) {
			extentReport.reportFail( "Partition_CreateClinic_001 Validation not successfull");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		extentReport.generateTestReport();
		driver.quit();
		

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
