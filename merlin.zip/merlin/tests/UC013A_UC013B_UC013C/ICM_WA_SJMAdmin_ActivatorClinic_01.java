package com.test.qa.ui.tests.UC013A_UC013B_UC013C;



import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.*;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientEnrollment_PatientDeviceData;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;


/* Author: Poojitha Gangiri
 * TC Name: ICM_WA_SJMAdmin_ActivatorClinic_01
 */

public class ICM_WA_SJMAdmin_ActivatorClinic_01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	AddCustomerPage addCustomerPage;
	CustomerProfilePage customerProfilePage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	DataBaseConnector dataBaseConnector;
	QueryResults queryResults;
	Customer customer_NonActivator,customer_Activator;
	CA_LeftNavPage clinicAdminLeftNavPage;
	CA_ClinicUsers clinicUsersPage;
	PatientListPage patientListPage;
	PL_PatientEnrollment patientEnrollment;
	PL_PatientEnrollment_PatientDeviceData patientDeviceDataPage;
	
	
	@BeforeMethod (alwaysRun=true)
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		clinicUsersPage = new CA_ClinicUsers(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		patientEnrollment = new PL_PatientEnrollment(driver,extentReport);
		patientDeviceDataPage = new PL_PatientEnrollment_PatientDeviceData(driver,extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();	
		
	}

	@Test
	public void TC_ICM_WA_SJMAdmin_ActivatorClinic_01() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("ActivatorClinic");
		//customer_NonActivator = testDataProvider.getCustomerData(testName+ "_NonActivator");
		//customer_Activator = testDataProvider.getCustomerData(testName+ "Activator");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		
		try {
			assertion =  new Assertions(extentTest);
			
			String userId_Direct = CommonUtils.randomUserId();
			//customer_NonActivator.setUserid(userId_Direct);
			//customer_NonActivator.setCustomerName(userId_Direct);
		/*
			extentReport.info("100 S Actor logins to the SJM admin account navigate to customer list page. Click on Add a Customer button.");
			loginPage.login(login_SJMAdmin,"internaluser");
			assertion.assertEqualsWithReporting(true,customerListPage.verifyLandingPage(),extentReport,"Customer List Page is displayed");
			customerListPage.clickOnAddCustomerButton();
			assertion.assertEqualsWithReporting(true,addCustomerPage.verifyLandingPage(),extentReport,"Add Customer Page is displayed");

			extentReport.info("200 V Verify that Add Customer page (AD 010) of SJM admin is displayed with Activator Clinic checkbox which is default uncheck (No)", new String[] {"ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,addCustomerPage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked by default");
			extentReport.reportScreenShot("Activator clinic checkbox is unchecked by default");
			
			extentReport.info("300 V Verify that Activator Clinic checkbox is displayed in editable mode (user can check or uncheck) on Add Customer page (AD 010).", new String[] {"ClncAcct6524","ClncAcct6521"});
			assertion.assertEqualsWithReporting(true,addCustomerPage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is not mandatory");
			extentReport.reportScreenShot("User is able to check the activator clinic checkbox");
			
			extentReport.info("400 V Verify that Activator Clinic Checkbox is non-mandatory field on Add Customer page (AD 010).", new String[] {"ClncAcct6524","ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,addCustomerPage.verifyActivatorClincCheckBoxMandatory(),extentReport,"Activator clinic checkbox is not mandatory");
			extentReport.reportScreenShot("Activator clinic checkbox is a non-mandatory field on AddCustomer Page");
			
			extentReport.info("500 S Actor does not check the Activator clinic checkbox and provide other mandatory fields detail on Add Customer page (Ad 010). Click on Save button.");
			addCustomerPage.EnterValueAllfields(customer_NonActivator.getCustomerName(), userId_Direct,customer_NonActivator.getCustomerType() ,
					customer_NonActivator.getClinicLocation(), customer_NonActivator.getCountryCode(), customer_NonActivator.getAreaCode(), 
					customer_NonActivator.getMainPhone(), customer_NonActivator.getCountry(), customer_NonActivator.getEmail(), customer_NonActivator.getClinicTimeZone(), 
					customer_NonActivator.getLegalJurisdiction(), customer_NonActivator.getClinicLanguage(), customer_NonActivator.getNewPassword(), 
					customer_NonActivator.getConfirmNewPassword(), customer_NonActivator.getFirstName(), customer_NonActivator.getLastName(),
					customer_NonActivator.getEmailId(), customer_NonActivator.getElecExport());
			addCustomerPage.addCustomerSave();
			
			extentReport.info("600 V Verify that Customer profile is saved successfully and displayed in SJM Customer list page (Customer is as a non-activator clinic).", new String[] {"ClncAcct6524","ClncAcct6521"});
			addCustomerPage.addCustomerConfirmCancel();
			addCustomerPage.verifyAddCustSuccessPopupAndClickOK();
			customerListPage.searchCustomer(customer_NonActivator.getCustomerName());
			
			extentReport.info("700 S Actor select the same customer from customer list page.");
			customerListPage.clickCustomer(customer_NonActivator.getCustomerName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile Page is displayed");
			
			extentReport.info("800 V Verify that View customer Profile page (AD 005) is displayed with Activator clinic checkbox is unchecked and it is non editable mode.",new String[] {"ClncAcct6523","ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,customerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(false,customerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is non-editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is unchecked and non-editable on on View Customer page");
			
			extentReport.info("900 S Actor click on Change button on View Customer page (AD 005).");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change customer profile Page is displayed");
			
			extentReport.info("1000 V Verify that Change customer page (AD 015) is displayed with Activator Clinic checkbox is unchecked and it is in editable mode.", new String[] {"ClncAcct6525","ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,changeCustomerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is unchecked on Change Customer page and is in editable mode");

			extentReport.info("1100 Verify that Activator clinic checkbox is displayed as unchecked on View customer page (AD 005), same state of Activator clinic which is in unchecked state is displayed on change customer page (AD 015).", new String[] {"ClncAcct6525","ClncAcct6523"});
			//This steps is not required.
			
			extentReport.info("1200 S Actor change the values on Change customer page (AD 015) and click on Save button.");
			changeCustomerProfilePage.changeCustomer(customer_Activator);
			changeCustomerProfilePage.clickSaveButton();
			extentReport.reportScreenShot("User is able to edit the existing customer details successfully");
			
			extentReport.info("1300 S select the same customer from SJM customer list page.");
			customerListPage.searchCustomerAndClick(customer_NonActivator.getCustomerName());
			
			extentReport.info("1400 V Verify that View customer Profile page (AD 005) is displayed with Activator clinic checkbox is unchecked and it is non editable state.", new String[] {"ClncAcct6523","ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,customerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(false,customerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is unchecked on View Customer page and it is non-editable");			

			extentReport.info("1500 S Actor click on Change button on View Customer page (AD 005).");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change customer profile Page is displayed");	

			extentReport.info("1600 V Verify that Change customer page is displayed with Activator Clinic checkbox is unchecked and it is in editable state.", new String[] {"ClncAcct6525","ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,changeCustomerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is unchecked on Change Customer page and is in editable mode");

			extentReport.info("1700 S Actor click on All SJM Customers primary tab. Click on Add a Customer button of Customer list page. Add customer page is displayed.");
			changeCustomerProfilePage.clickOnAllAbbottCustomers();
			customerListPage.clickOnAddCustomerButton();
			
			extentReport.info("1800 V Verify that Activator Clinic Checkbox is non–mandatory field on Add Customer page (AD 010).", new String[] {"ClncAcct6524","ClncAcct6521"});
			assertion.assertEqualsWithReporting(false,addCustomerPage.verifyActivatorClincCheckBoxMandatory(),extentReport,"Activator clinic checkbox is not mandatory");
			extentReport.reportScreenShot("Activator clinic checkbox is a non-mandatory field on AddCustomer Page");
			
			extentReport.info("1900 S Actor check the Activator clinic checkbox and provide other mandatory fields detail on Add Customer page (Ad 010). Click on Save button.");
			addCustomerPage.selectActivatorClinicCheckBox();
			addCustomerPage.EnterValueAllfields(customer_NonActivator.getCustomerName(), userId_Direct,customer_NonActivator.getCustomerType() ,
					customer_NonActivator.getClinicLocation(), customer_NonActivator.getCountryCode(), customer_NonActivator.getAreaCode(), 
					customer_NonActivator.getMainPhone(), customer_NonActivator.getCountry(), customer_NonActivator.getEmail(), customer_NonActivator.getClinicTimeZone(), 
					customer_NonActivator.getLegalJurisdiction(), customer_NonActivator.getClinicLanguage(), customer_NonActivator.getNewPassword(), 
					customer_NonActivator.getConfirmNewPassword(), customer_NonActivator.getFirstName(), customer_NonActivator.getLastName(),
					customer_NonActivator.getEmailId(), customer_NonActivator.getElecExport());
			addCustomerPage.addCustomerSave();
			
			extentReport.info("2000 V Verify that Customer profile is saved successfully and displayed in SJM Customer list page (Customer is as a activator clinic).", new String[] {"ClncAcct6524","ClncAcct6521","ClncAcct6522"});
			addCustomerPage.addCustomerConfirmCancel();
			addCustomerPage.verifyAddCustSuccessPopupAndClickOK();
			customerListPage.searchCustomer(customer_Activator.getCustomerName());
			
			extentReport.info("2100 S Actor select the same customer from customer list page.");
			customerListPage.clickCustomer(customer_Activator.getCustomerName());
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyLandingPage(),extentReport,"Customer Profile Page is displayed");
			
			extentReport.info("2200 V Verify that View customer Profile page (AD 005) is displayed with Activator clinic checkbox is checked and it is non editable mode. ", new String[] {"ClncAcct6524","ClncAcct6521"});
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(false,customerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is non-editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is checked and non-editable on on View Customer page");
			
			extentReport.info("2300 S Actor click on Change button on View Customer page (AD 005).");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change customer profile Page is displayed");
			
			extentReport.info("2400 V Verify that Change customer page is displayed with Activator Clinic checkbox is checked and it is in editable mode.", new String[] {"ClncAcct6525","ClncAcct6521"});
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is checked on Change Customer page and is in editable mode");

			extentReport.info("2500 V Verify that Activator Clinic checkbox mode is same as View Customer page (AD005)as well as Change Customer page (AD 015).", new String[] {"ClncAcct6525","ClncAcct6523"});
			//doubt
			
			extentReport.info("2600 S Actor change the values on Change customer page (AD 015) and click on Save button.");
			changeCustomerProfilePage.changeCustomer(customer_NonActivator);
			changeCustomerProfilePage.clickSaveButton();
			extentReport.reportScreenShot("User is able to edit the existing customer details successfully");
			
			extentReport.info("2700 S Select the same customer from SJM customer list page.");
			customerListPage.searchCustomerAndClick(customer_NonActivator.getCustomerName());
			
			extentReport.info("2800 V Verify that View customer Profile page (AD 005) is displayed with Activator clinic checkbox is checked and it is non editable mode.", new String[] {"ClncAcct6523","ClncAcct6521"});
			assertion.assertEqualsWithReporting(true,customerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(false,customerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is non-editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is checked on View Customer page and it is non-editable");			

			extentReport.info("2900 S Actor click on Change button on View Customer page (AD 005).");
			customerProfilePage.clickChangeButton();
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyLandingPage(),extentReport,"Change customer profile Page is displayed");
			
			extentReport.info("3000 V Verify that Change customer page (AD 015) is displayed with Activator Clinic checkbox is checked and it is in non-editable mode.", new String[] {"ClncAcct6525","ClncAcct6521"});
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.verifyActivatorClinicCheckBox(),extentReport,"Activator clinic checkbox is unchecked.");
			assertion.assertEqualsWithReporting(true,changeCustomerProfilePage.validateEditableFields("ActivatorClinicCheckBox"),extentReport,"Activator clinic checkbox is editable.");
			extentReport.reportScreenShot("Activator clinic checkbox is checked on Change Customer page and is in editable mode");
*/
			extentReport.info("3100 S Actor login to such a clinic whose Activator clinic checkbox (having ICM device added and an implanting physician user) is check through SJM admin. Switch to EP application.");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			clinicianHomeTopNavPage.navigateToClinicAdministrationForActivatorPage();
			assertion.assertEqualsWithReporting(true,clinicAdminLeftNavPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			//clinicAdminLeftNavPage.clinicUserPage();
			//assertion.assertEqualsWithReporting(true,clinicUsersPage.verifyLandingPage(),extentReport,"Clinic Administration Page is displayed");
			clinicUsersPage.createUser("Direct", true, "Physician");
			
			extentReport.info("3200 S Click on Enroll a new patient link. Select Enroll Manually option and click on Enroll button.");
			clinicianHomeTopNavPage.navigateToPatientListForActivatorClinic();
			assertion.assertEqualsWithReporting(true,patientListPage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			patientListPage.clickEnrollAPatientButton();
			assertion.assertEqualsWithReporting(true,patientEnrollment.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			patientEnrollment.clickManualEnrollButton();
			assertion.assertEqualsWithReporting(true,patientDeviceDataPage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
				
			extentReport.info("3300 S Actor provides all mandatory fields and enroll a ICM patient.");
			
			extentReport.info("3400 V Verify that newly enrolled patient is displayed in EP Patient List of Activator clinic.", new String[] {"TransMgt9499"});
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
		appHomeTopNavPage.clickSignOutLink();
		saintResult(result, extentTest);

		}

}

