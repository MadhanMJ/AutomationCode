package com.test.qa.ui.tests.UC013A_UC013B_UC013C;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class Clinic_Account_Management_TC100105 extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Log logger;
	ViewCustomerPage viewpage;
	TestDataProvider testDataProvider;
	private String testName;
	Customer  customer1,customer2;

	@BeforeMethod(alwaysRun=true)
	public void initialize() throws Exception {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		logger =  new Log();
		viewpage = new ViewCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();	
		customer2 = testDataProvider.getCustomerData("WA_AD005_ViewCustomerProfile_PageComponents_03_02");	
	}
	
	/*
	 * Saints ID: 1243996
	 * Saints Definition ID: 2629843
	 * Data sheet used:- JurisdictionAlerts.xlsx, Login.xlsx
	 * Test Data requirement:- SJM administrator account, Pre-enrolled customer having authorized for EP and HF
	 */

	@Test(groups= {"Regression"})
	public void tc_Clinic_Account_Management_TC100105() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		CommonUtils.extentTest = extentTest;
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("SJMAdmin");
		extentTest.assignAuthor("Author-Snehal Mane");
		
		
		try {
			Assertions assertions = new Assertions(extentTest);
			
			extentReport.info("100S The actor logs into the system as SJM Admin and navigates to the View customer profile page.");

			loginPage.login(login,"externaluser");

			//loginPage.login(login);

			assertions.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Logged into the application and navigated to Customer list page");
			customerListPage.searchWithExactCustomerNameAndClick(customer2.getCustomerName());
			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer2.getCustomerName()), extentReport, "Searched customer and verified profile page");
			
			extentReport.info("300V Verify the display of list of special alert groups for patient notification to which the clinic is authorized for the EP application, selected from the display groups available and marked as relevant for the EP application", new String[] {"ClncAcct6106", "ClncAcct5991"});	
			viewpage.jurisdictionAlertValidation("dirAlert_Notif_Allow4Patient_NBLE_S");
			viewpage.clicktoAllAbbottCustTab();
			
			extentReport.info("310V General Device Control - A list of devices the clinic is authorized to use when enrolling patients for EP and HF application, based upon jurisdiction.", new String[] {"ClncAcct6107"});
			customerListPage.searchWithExactCustomerNameAndClick(customer2.getCustomerName());
			assertions.assertEqualsWithReporting(true, viewpage.verifySearchedCustomerProfilePage(customer2.getCustomerName()), extentReport, "Searched customer and verified profile page");
			viewpage.jurisdictionAllowedDeviceValidation();
			viewpage.clicktoAllAbbottCustTab();
			
			
			
		}
		
			catch (AssertionError e) {
				extentReport.reportFail( "WA_AD005_ViewCustomerProfile_PageComponents_03 due to some exception is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
				throw e;
				}
		
		

				catch (Exception e) {
					extentReport.reportFail("WA_AD005_ViewCustomerProfile_PageComponents_03 due to some exception", CommonUtils.convertStackTraceToString(e));
				throw e;
				}
		
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
	
}
