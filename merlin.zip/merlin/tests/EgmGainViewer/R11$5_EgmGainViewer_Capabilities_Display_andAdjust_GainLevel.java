package com.test.qa.ui.tests.EgmGainViewer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.*;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientSummaryPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;


/* Author: Poojitha Gangiri
 * TC Name: R11.5_EgmGainViewer_Capabilities_Display_andAdjust_GainLevel
 */

public class R11$5_EgmGainViewer_Capabilities_Display_andAdjust_GainLevel extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	PL_TopNavPage pl_TopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	DataBaseConnector dataBaseConnector;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	List<String> optionsValues;
	ArrayList<Date> transDateValue;
	PL_PatientSummaryPage pl_PatientSummaryPage;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	int transCount, episodesCount;
	
	@BeforeMethod (alwaysRun=true)
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		pl_PatientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		pl_PatientSummaryPage = new PL_PatientSummaryPage(driver,extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver,extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver,extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();	
		databaseResults = new HashMap<String,String>();
		optionsValues = new ArrayList<String>();
		transDateValue = new ArrayList<Date>();
		
	}

	@Test
	public void TC_R11$5_EgmGainViewer_Capabilities_Display_andAdjust_GainLevel() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("DirectAll");
		
		extentTest.assignAuthor("Author: Poojitha Gangiri");
		
		try {
			assertion =  new Assertions(extentTest);
			
			extentReport.info("100S Login to the clinic as per test setup 1");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			
			extentReport.info("200S Select the patient and navigate to Episode/EGM details page");
			ca_RecentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier1 filter.");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx("0522");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");

			extentReport.info("300S Select each episode and "
					+ "navigate to EGM Gain Viewer and Verify the SEGM viewer is displayed with the 5.00 as the default Gain level", new String[] {"TransMgt18697"});
			pl_Transmission_EpisodeAndEgmPage.egmGainViewerValidation("5.0");
			
			extentReport.info("400S Select the Gain '+' button from the currently displayed EGM viewer");
			pl_Transmission_EpisodeAndEgmPage.gainChangeValidation("Increment","5.0");
			
			extentReport.info("500V Verify from any Gain level clicking on '+' increments the Gain level up to a maximum of 200");
			
			extentReport.info("600S Select the patient as per test setup 2");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			ca_RecentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier1 filter.");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx("0727");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			
			
			extentReport.info("700V Navigate to Episode/EGM details, select the episode and navigate to EGM Gain Viewer");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");

			extentReport.info("800V Gain level is set to predefined value of 200", new String[] {"TransMgt18697"});
			pl_Transmission_EpisodeAndEgmPage.egmGainViewerValidation("200.0");
			
			extentReport.info("900S From the EGM Gain viewer Select the Gain '-' button from the currently displayed EGM viewer");
			
			extentReport.info("1000V Verify Gain level is decremented to predefined values from the currently displayed Gain Level", new String[] {"TransMgt18697"});
			
			extentReport.info("1100V Verify from any Gain level clicking on '-' decrements the Gain level up to a minimum of 5.00");
			pl_Transmission_EpisodeAndEgmPage.gainChangeValidation("Decrement","5.0");
			
			extentReport.info("1200S Select the patient as per test setup 3");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			ca_RecentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier1 filter.");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx("0727");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			
			
			extentReport.info("1300S Navigate to Episode/EGM details, select the episode and navigate to EGM Gain Viewer");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");

			extentReport.info("1400V Gain level is set to predefined value of 100", new String[] {"TransMgt18697"});
			pl_Transmission_EpisodeAndEgmPage.egmGainViewerValidation("100.0");
			
			extentReport.info("1500S From the default Gain, switch to different Gain levels (5.00 ,15.0,25.0.50.0 or 200)");

			
			extentReport.info("1600S From the EGM Gain viewer Select the Gain Refresh button from the currently displayed EGM viewer");
			
			extentReport.info("1700V 'Verify the Gain level resets to the Default Gain (100) that was received in the transmission for the selected episode", new String[] {"TransMgt18697"});
			
			pl_Transmission_EpisodeAndEgmPage.gainChangeValidation("Increment","100.0");
			
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {

		appHomeTopNavPage.clickSignOutLink();
		saintResult(result, extentTest);

		}

}
