package com.test.qa.ui.tests.EgmGainViewer;

import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.*;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientSummaryPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.utilities.CommonUtils;


/* Author: Meenakshi Yagati
 * TC Name: R11.5_EgmGainViewer_Capabilities_SweepSpeed
 */

public class R11$5_EgmGainViewer_Capabilities_SweepSpeed extends CommonUtils {
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	PL_TopNavPage pl_TopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	PL_PatientSummaryPage pl_PatientSummaryPage;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	int transCount, episodesCount;
	Patient patient;
	
	@BeforeMethod (alwaysRun=true)
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		pl_PatientProfilePage = new PL_PatientProfilePage(driver,extentReport);
		pl_PatientSummaryPage = new PL_PatientSummaryPage(driver,extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver,extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver,extentReport);
		login = new Login();
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
				
	}

	@Test
	public void TC_R11$5_EgmGainViewer_Capabilities_SweepSpeed() throws Exception { 
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;	
		login = testDataProvider.getLoginData("clinic_user");
		patient = testDataProvider.getSearchPatientData("TC_R11$5_EgmGainViewer_Capabilities_SweepSpeed");
		extentTest.assignAuthor("Author: Meenakshi Yagati");
		
		try {
			assertion =  new Assertions(extentTest);
			
			extentReport.info("100S Login to the clinic as per test setup 1");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			extentReport.info("200S Select the patient and navigate to Episode/EGM details page");
			ca_RecentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier1 filter.");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			extentReport.info("300S Select each episode and navigate to EGM Gain Viewer.");
			extentReport.info("300S Verify SEGM sweep speed is displayed on the SEGM Gain Viewer and The SEGM sweep speed is displayed as 25mm/second ",new String[] {"TransMgt18924"});
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.episodesValidation(),extentReport,"Episodes details are displayed in Episode and EGM Page.");
			extentReport.info("400S Login to the clinic as per Test Setup 2");
			extentReport.info("500S Select the patient and navigate to Episode/EGM details page");
			extentReport.info("600S Select each episode and navigate to EGM Gain Viewer");
			extentReport.info("700V Verify SEGM sweep speed is displayed on the SEGM Gain Viewer as The sweep speed is 25mm/second",new String[] {"TransMgt18927"});
			extentReport.info("800S Login to the clinic as per Test Setup 3");
			extentReport.info("900S Select the patient and navigate to Episode/EGM details page");
			extentReport.info("1000S Select each episode and navigate to EGM Gain Viewer");
			extentReport.info("1100V Verify SEGM sweep speed is displayed on the SEGM Gain Viewer as The sweep speed is 25mm/second", new String[] {"TransMgt18927"});
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.episodeTypeValidation(),extentReport,"Sweep Spped is displayed with Gains");

			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
