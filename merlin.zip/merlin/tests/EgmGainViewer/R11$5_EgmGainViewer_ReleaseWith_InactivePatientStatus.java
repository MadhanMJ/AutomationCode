package com.test.qa.ui.tests.EgmGainViewer;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Shafiya Sunkesala
 * Date: 23/02/2022
 * Test Case: R11.5_EgmGainViewer_ReleaseWith_InactivePatientStatus
 * Test case Id: 1238298
 */

public class R11$5_EgmGainViewer_ReleaseWith_InactivePatientStatus extends CommonUtils {
	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	AppHomeTopNavPage appHomeTopNavPage;
	PatientListPage patientListPage;
	PL_PatientProfilePage pl_PatientProfilePage;
	PL_TopNavPage pl_TopNavPage;
	PL_AllTransmissionsPage pl_AllTransmissionsPage;
	
	LoginPageWithPOJO loginPage;
	Login login_Direct_Clnc_ICM_Patients;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	Patient patient1;
	Patient patient2;
	Patient patient3;

	@BeforeMethod(alwaysRun = true)
	public void initialize() {

		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver, extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_PatientProfilePage= new PL_PatientProfilePage(driver,extentReport);
		pl_TopNavPage= new PL_TopNavPage(driver,extentReport);
		pl_AllTransmissionsPage= new PL_AllTransmissionsPage(driver,extentReport);

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login_Direct_Clnc_ICM_Patients = new Login();
		testDataProvider = new TestDataProvider();
		patient1 = new Patient();
		patient2 = new Patient();
		patient3 = new Patient();
	}

	@Test(groups= {"Regression"})
	public void TC_R11$5_EgmGainViewer_ReleaseWith_InactivePatientStatus()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		login_Direct_Clnc_ICM_Patients = testDataProvider.getLoginData("SJMClinic_1238298");
		patient1 = testDataProvider.getPatientData(testName+"_Option1");
		patient2 = testDataProvider.getPatientData(testName+"_Option2");
		patient3 = testDataProvider.getPatientData(testName+"_Option3");

		extentTest.assignAuthor("Author: Shafiya Sunkesala");
		try {
			assertions = new Assertions(extentTest);
			extentReport.info("100 S Login to the clinic as per test setup 1");
			loginPage.login(login_Direct_Clnc_ICM_Patients, "externaluser");
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			
			extentReport.info("200 S Release the patient with Explanted option");
			clinicianHomeTopNavPage.clickPatientListLink();
		    patientListPage.selectTierOneFilterOption("Active Clinic Patients");
		    assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Active Clinic patients");
		   
		    patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
		    assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with ICM Active Clinic patients");
		    
		    patientListPage.searchPatients(patient1.getLastName()+" "+patient1.getFirstName());
		    //patient name: Test Test		   
		    patientListPage.clickOnPatientCheckBox(patient1.getLastName()+" "+patient1.getFirstName());
		    patientListPage.clickMoreActionsButton();
		    patientListPage.clickReleasePatientLink();
		    		    
		    patientListPage.selectValueInReasonForReleaseDropDown(patient1.getReleaseReason());			
			patientListPage.clickReleaseButton();
			
			extentReport.info("300 S Select the patient and navigate to Episode/EGM details page");
			patientListPage.selectTierOneFilterOption("Inactive Patients");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Inactive Clinic patients");
			   
			patientListPage.selectTierTwoFilterOption("All");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with All Inactive Clinic patients");
			patientListPage.searchPatients(patient1.getLastName()+" "+patient1.getFirstName());
			
			//patientListPage.clickOnPatientName();
			//patient name: Test Test
			patientListPage.clickonAllTransmissionFrmList(patient1.getLastName()+" "+patient1.getFirstName());
			assertions.assertEqualsWithReporting(true, pl_AllTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is Displayed");
			
			pl_TopNavPage.navigateToTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertions.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			
			extentReport.info("400 S Select an episode and navigate to EGM Gain Viewer");			
			extentReport.info("500 V The SEGM Gain Viewer is displayed in a modal window with SEGM waveform data associated with the selected episode",
					new String[] {"TransMgt18879"});
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.validateEpisodeData(),true,"SEGM waveform data associated with the selected episode is displayed");
			
			//Rajesh has to confirm on the below step with praveen
			extentReport.info("600 S A new Transmission is received for the patient with episode associated with SEGM Waveform data");
			extentReport.info("700 S Select the patient and navigate to Episode/EGM details page, select an episode and navigate to EGM Gain Viewer");
			extentReport.info("800 V The SEGM Gain Viewer is displayed in a modal window with SEGM waveform data associated with the selected episode",new String[] {"TransMgt18879"});
			
			extentReport.info("900 S Login to the clinic as per test setup 2");			
			extentReport.info("1000 S Release the patient with Expired option");
			clinicianHomeTopNavPage.clickPatientListLink();
		    patientListPage.selectTierOneFilterOption("Active Clinic Patients");
		    assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Active Clinic patients");
		   
		    patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
		    assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with ICM Active Clinic patients");
		   
		    patientListPage.searchPatients(patient2.getLastName()+" "+patient2.getFirstName());
		    //Above 2021 Beyond 2021: patient name
		    patientListPage.clickOnPatientCheckBox(patient2.getLastName()+" "+patient2.getFirstName());
		    patientListPage.clickMoreActionsButton();
		    patientListPage.clickReleasePatientLink();
		    
		    //Value is expired
		    patientListPage.selectValueInReasonForReleaseDropDown(patient2.getReleaseReason());			
			patientListPage.clickReleaseButton();
			
			extentReport.info("1100 S Select the patient and navigate to Episode/EGM details page");
			patientListPage.selectTierOneFilterOption("Inactive Patients");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Inactive Clinic patients");
			   
			patientListPage.selectTierTwoFilterOption("All");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with ICM Inactive Clinic patients");
			patientListPage.searchPatients(patient2.getLastName()+" "+patient2.getFirstName());
			
			patientListPage.clickonAllTransmissionFrmList(patient1.getLastName()+" "+patient1.getFirstName());
			assertions.assertEqualsWithReporting(true, pl_AllTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is Displayed");
			
			pl_TopNavPage.navigateToTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertions.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			
			extentReport.info("1200 S Select an episode and navigate to EGM Gain Viewer");		
			extentReport.info("1300 V The SEGM Gain Viewer is displayed in a modal window with SEGM waveform data associated with the selected episode", new String[] {"TransMgt18879"});
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.validateEpisodeData(),true,"SEGM waveform data associated with the selected episode is displayed");
			
			extentReport.info("1400 S A new Transmission is received for the patient with episode associated with SEGM Waveform data");
			extentReport.info("1500 S Select the patient and navigate to Episode/EGM details page, select an episode and navigate to EGM Gain Viewer");
			extentReport.info("1600 V The SEGM Gain Viewer is displayed in a modal window with SEGM waveform data associated with the selected episode", new String[] {"TransMgt18879"});
			
			extentReport.info("1700S S Login to the clinic as per test setup 3");			
			extentReport.info("1800 S Release the patient with removed from Merlin.net option");
			clinicianHomeTopNavPage.clickPatientListLink();
		    patientListPage.selectTierOneFilterOption("Active Clinic Patients");
		    assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Active Clinic patients");
		   
		    patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
		    assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with ICM Active Clinic patients");
		    //Flipping Flipper: patient name
		    patientListPage.searchPatients(patient3.getLastName()+" "+patient3.getFirstName());
		    
		    patientListPage.clickOnPatientCheckBox(patient3.getLastName()+" "+patient3.getFirstName());
		    patientListPage.clickMoreActionsButton();
		    patientListPage.clickReleasePatientLink();
		    
		    //value is Removed from merlin.net
		    patientListPage.selectValueInReasonForReleaseDropDown(patient3.getReleaseReason());			
			patientListPage.clickReleaseButton();
			
			extentReport.info("1900 S Select the patient and navigate to Episode/EGM details page");
			patientListPage.selectTierOneFilterOption("Inactive Patients");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with Inactive Clinic patients");
			   
			patientListPage.selectTierTwoFilterOption("All");
			assertions.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Page loaded with ICM Inactive Clinic patients");
			patientListPage.searchPatients(patient3.getLastName()+" "+patient3.getFirstName());
			
			patientListPage.clickonAllTransmissionFrmList(patient1.getLastName()+" "+patient1.getFirstName());
			assertions.assertEqualsWithReporting(true, pl_AllTransmissionsPage.verifyLandingPage(), extentReport, "All Transmissions Page is Displayed");
			
			pl_TopNavPage.navigateToTransmissionPage();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertions.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			
			extentReport.info("2000 S Select an episode and navigate to EGM Gain Viewer");		
			extentReport.info("2100 V The SEGM Gain Viewer is displayed in a modal window with SEGM waveform data associated with the selected episode", new String[] {"TransMgt18879"});
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.validateEpisodeData(),true,"SEGM waveform data associated with the selected episode is displayed");
			
			extentReport.info("2200 S A new Transmission is received for the patient with episode associated with SEGM Waveform data");
			extentReport.info("2300 S Select the patient and navigate to Episode/EGM details page, select an episode and navigate to EGM Gain Viewer");
			extentReport.info("2400 V The SEGM Gain Viewer is displayed in a modal window with SEGM waveform data associated with the selected episode",new String[] {"TransMgt18879"});
			
			//This is used to reactivate patient in order to execute script next time patient should be active
			patientListPage.reactivatePatient(patient1.getLastName()+" "+patient1.getFirstName(), patient2.getLastName()+" "+patient2.getFirstName(), patient3.getLastName()+" "+patient3.getFirstName());
			
			assertions.assertAll();

		} catch (AssertionError e) {
			extentReport.reportFail( "R11.5_EgmGainViewer_ReleaseWith_InactivePatientStatus is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "R11.5_EgmGainViewer_ReleaseWith_InactivePatientStatus is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {   	
	    appHomeTopNavPage.clickSignOutLink();
	    saintResult(result, extentTest);

	}
}
