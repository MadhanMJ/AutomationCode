package com.test.qa.ui.tests.UC013D;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class R7_UC013D_B01_02 extends CommonUtils {
	Login login;
	Customer customer;
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	CustomerListPage customerListPage;
	TestDataProvider testDataProvider;
	AddSecondarylocationPage addSecondarylocationPage;
	CustomerProfilePage customerProfilePage;
	private String testName;
	public DataBaseConnector dataBase;
	DataBaseConnector dataBaseConnector;
	private Assertions softAssert;
	String first_name, last_name, temp_pwd, location, area_code, main_phone, language, legal_jurisdiction, time_zone, customer_type, country;

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);		
		customer = new Customer();// New Pojo classes
		login = new Login();
		testDataProvider = new TestDataProvider();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		addSecondarylocationPage = new AddSecondarylocationPage(driver, extentReport);	
		dataBaseConnector = new DataBaseConnector();
	}

	@Test(groups= {"Regression"})
	public void r7_UC013D_B01_02() throws Exception {		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData(testName);
		extentTest.assignAuthor("Author: ChandraMohan Singaram");
		try {		
			String userId = CommonUtils.randomUserId();
			customer.setUserid(userId);
			softAssert = new Assertions(extentTest);
			extentReport.info("100 S The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page");
			loginPage.login(login,"internaluser");
			
			extentReport.info("200-S-The actor clicks the 'Add a customer' link");
			//Temp comment due to Add customer issue
			addCustomerPage.addCustomerClick();
			
			extentReport.info("300-V-The system displays Add Customer page");
			//Temp comment due to Add customer issue
			assertion.assertEqualsWithReporting(true, addCustomerPage.addCustomerPageLanding(),extentReport,"displays Add New Customer location Page ");
			
			extentReport.info("400-S-The actor enters valid and required information in the Customer headquarters, Clinic location and Clinic main contact sections, and clicks the Save button");
			//Temp comment due to Add customer issue
			addCustomerPage.addCustomerfieldupdate(customer, "Text");		
			addCustomerPage.addCustomerSave();
			
			extentReport.info("500-V-1. System displays AD806 dialog ",new String[] { "ClncAcct5974" });
			extentReport.reportScreenShot("System displays AD806 dialog ");
			//Temp comment due to Add customer issue
			//addCustomerPage.addCustomerConfirmMsg() ;
			
			extentReport.info("600-S- The actor clicks the OK button on AD806 dialog.",new String[] {"ClncAcct2345"});
			//Temp comment due to Add customer issue
			//addCustomerPage.addCustomerConfirmOk();
			Thread.sleep(5000);
			extentReport.info("500-V-2. System creates the Customer and Customer_Account, and stores details in the database (Table: CUSTOMER, ADDRESS, LOCATION, CUSTOMER_ACCOUNT, USER_RECORD) and passwords in LDAP;");
			/*Database Validation for Add Customer			
			dataBaseConnector.getConnection();
			ResultSet customerRecord = dataBaseConnector.executeQuery("select ur.first_name, ur.last_name, ur.temp_pwd, cl.name as location, cp.area_code as area_code,cp.phone_num as main_phone,"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.spoken_language_cd and cd.code_qualifier ='Language_Cd') as language, "
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.legal_jurisdiction_cd and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction, "
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.time_zone_cd and cd.code_qualifier ='Time_Zone_Cd') as time_zone, "
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.customer_type_cd and cd.code_qualifier ='Customer_Type_Cd') as customer_type, "
					+ "(SELECT code_desc FROM lookup.code cd where cad.customer_address_id =c.customer_address_id and cd.code_id=cad.country_cd and cd.code_qualifier ='Country_Cd') as country "
					+ "from customers.customer c, users.user_record ur, users.customer_account ca, customers.customer_phone cp , customers.customer_address cad, customers.customer_location cl    "
					+ "where cl.customer_id = c.customer_id and cl.name='"+customer.getSecondaryLocation() +"'  and c.main_phone_id = cp.customer_phone_id    and c.customer_address_id = cad.customer_address_id      "
					+ "and c.customer_id = ca.customer_id  and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='" + userId + "'");
			while (customerRecord.next()) {
				first_name = customerRecord.getString("first_name");
				last_name = customerRecord.getString("last_name");
				temp_pwd = customerRecord.getString("temp_pwd");
				location = customerRecord.getString("location");
				area_code = customerRecord.getString("area_code");
				main_phone = customerRecord.getString("main_phone");
				language = customerRecord.getString("language");
				legal_jurisdiction = customerRecord.getString("legal_jurisdiction");
				time_zone = customerRecord.getString("time_zone");
				customer_type = customerRecord.getString("customer_type");
				country = customerRecord.getString("country");
			}
		*/	
			extentReport.info("700-V-Verify that the system closes dialog box AD 806 & Add customer location page is displayed <ClncAcct2345>");
			assertion.assertEqualsWithReporting(true, addSecondarylocationPage.verifyLandingPage(),extentReport,"displays Add New Customer location Page ");
			
			extentReport.info("800-S-The actor enters Clinic location data in the �Clinic Location� field and then clicks the �Save� button");		
			addSecondarylocationPage.addSecondaryLocationValue(customer.getSecondaryLocation(), false);
			
			extentReport.info("900-V-2. System displays dialog AD811. <ClncAcct5974>");
			addSecondarylocationPage.clickSaveButton();
			extentReport.reportScreenShot("System displays dialog AD811");
			assertion.assertEqualsWithReporting(true, addSecondarylocationPage.aD811DialogExists(),extentReport,"displays dialog AD811");
			
			extentReport.info("1000-S-The actor The actor clicks 'Ok' button on AD 811 dialog.");			
			addSecondarylocationPage.clickPopUpOkButton();
			
			extentReport.info("1100-V-Verify that the AD 811 dialog box is closed & page Add Customer Location page is displayed. ",new String[] {"ClncAcct2345"});
			assertion.assertEqualsWithReporting(true, addSecondarylocationPage.verifyLandingPage(),extentReport,"displays Add New Customer location Page ");
			
			extentReport.info("900-V-1. System stores the location details in database (LOCATION table)");
			/*Database Validation for Adding Secondary location			
			dataBaseConnector.getConnection();
			ResultSet customerRecordd = dataBaseConnector.executeQuery("select ur.first_name, ur.last_name, ur.temp_pwd, cl.name as location, cp.area_code as area_code,cp.phone_num as main_phone,"
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.spoken_language_cd and cd.code_qualifier ='Language_Cd') as language, "
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.legal_jurisdiction_cd and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction, "
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.time_zone_cd and cd.code_qualifier ='Time_Zone_Cd') as time_zone, "
					+ "(SELECT code_desc FROM lookup.code cd where cd.code_id=c.customer_type_cd and cd.code_qualifier ='Customer_Type_Cd') as customer_type, "
					+ "(SELECT code_desc FROM lookup.code cd where cad.customer_address_id =c.customer_address_id and cd.code_id=cad.country_cd and cd.code_qualifier ='Country_Cd') as country "
					+ "from customers.customer c, users.user_record ur, users.customer_account ca, customers.customer_phone cp , customers.customer_address cad, customers.customer_location cl    "
					+ "where cl.customer_id = c.customer_id and cl.name='"+customer.getSecondaryLocation() +"'  and c.main_phone_id = cp.customer_phone_id    and c.customer_address_id = cad.customer_address_id      "
					+ "and c.customer_id = ca.customer_id  and ca.user_record_id = ur.user_record_id and ur.logon_user_name ='" + userId + "'");
			while (customerRecordd.next()) {
				first_name = customerRecordd.getString("first_name");
				last_name = customerRecordd.getString("last_name");
				temp_pwd = customerRecordd.getString("temp_pwd");
				location = customerRecordd.getString("location");
				area_code = customerRecordd.getString("area_code");
				main_phone = customerRecordd.getString("main_phone");
				language = customerRecordd.getString("language");
				legal_jurisdiction = customerRecordd.getString("legal_jurisdiction");
				time_zone = customerRecordd.getString("time_zone");
				customer_type = customerRecordd.getString("customer_type");
				country = customerRecordd.getString("country");
			}
			extentTest = extentReport.info("1000 V Verify in Database that changes made by actor are reflected in database&lt;ClncAcct221&gt;");
			Assertions softAssert = new Assertions(extentTest);
			softAssert.assertEquals(customer.getFirstName(), first_name,"First Name field is verified");
			softAssert.assertEquals(customer.getLastName(), last_name,"Last Name field is verified");
			softAssert.assertEquals(customer.getNewPassword(), temp_pwd, "Temp pwd is verified");
			softAssert.assertEquals(customer.getSecondaryLocation(), location, "Location field is verified");
			softAssert.assertEquals(customer.getAreaCode(), area_code, "Area Code field is verified");
			softAssert.assertEquals(customer.getMainPhone(), main_phone, "Main phone field is verified");
			softAssert.assertEquals(customer.getClinicLanguage(), language, "Clinic Language field is verified");
			softAssert.assertEquals(customer.getCustomerType(), customer_type, "Customer Type field is verified");
			softAssert.assertEquals(customer.getCountry(), country, "Country Code field is verified");
*/
			extentReport.info("1200-S- Repeat steps # 800-900");
			addSecondarylocationPage.addSecondaryLocationValue("SecondLocationToCancel", false);			
			
			extentReport.info("1300-S- The actor clicks Cancel button on AD811 dialog.");
			addSecondarylocationPage.clickCancelButton();
			
			extentReport.info("1400-V-The system displays AD804 dialog box <ClncAcct5974>, <ClncAcct5973>");
			
			extentReport.info("1500-S-The actor clicks the 'Ok' button on AD 804 dialog.");
			addSecondarylocationPage.clickpopUpOkButtonn();
			
			extentReport.info("1600-V-The system displays Customer List page. <ClncAcct5978>, <ClncAcct5979>");
			softAssert.assertEqualsWithReporting(true, customerListPage.verifyLandingPage(), extentReport, "Verified if the system displays Customer List page. <ClncAcct5978>, <ClncAcct5979>");
			
			softAssert.assertAll();
		} catch (Exception e) {
			extentReport.reportFail("Add Secondary Location functionality is not completed successfully");
			e.printStackTrace();
			throw e;
		}
	}
	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerListPage.verifyLogout();
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}	
}
