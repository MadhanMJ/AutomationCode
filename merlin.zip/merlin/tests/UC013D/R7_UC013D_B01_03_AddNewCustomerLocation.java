package com.test.qa.ui.tests.UC013D;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class R7_UC013D_B01_03_AddNewCustomerLocation extends CommonUtils {
	Login login;
	Customer customer;
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	CustomerListPage customerListPage;
	TestDataProvider testDataProvider;
	AddSecondarylocationPage addSecondarylocationPage;
	CustomerProfilePage customerProfilePage;
	private String testName;
	private String customerName;
	public DataBaseConnector dataBase;
	DataBaseConnector dataBaseConnector;
	Assertions assertion ;
	Assertions softAssert;
	String first_name, last_name, temp_pwd, location, area_code, main_phone, language, legal_jurisdiction, time_zone,
	customer_type, country,secondLocValueInList,enteredSecLocVal,newCustomer,updatedUserId;

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		customer = new Customer();// New Pojo classes
		login = new Login();
		testDataProvider = new TestDataProvider();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		addSecondarylocationPage = new AddSecondarylocationPage(driver, extentReport);
		dataBaseConnector = new DataBaseConnector();
	}

	@Test
	public void r7_UC013D_B01_03_AddNewCustomerLocation() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		softAssert = new Assertions(extentTest);
		assertion =  new Assertions(extentTest);
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData(testName);// key value getting the data
		extentTest.assignAuthor("ChandraMohan Singaram");
		try {
			extentReport.info("100 S The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page");
			loginPage.login(login);
			customerListPage.verifyLandingPage();

			extentReport.info("200-S-The actor clicks the 'customerNameInList' link");

			extentReport.reportScreenShot("The actor clicks the 'customerNameInList' link");
			//Temp comment due to "Click customer" issue.
			//customerName=customerListPage.getAndclickOnFirstCustomerLink();

			extentReport.info("300-S- Click on the Add Secondary location  button.");
			customerProfilePage.goToAddSecondaryLocationPage();

			extentTest=	extentReport.info("400-V- Verify that Add New Customer location page is populated ");
			assertion.assertEqualsWithReporting(true, addSecondarylocationPage.verifyLandingPage(),extentReport,"displays Add New Customer location Page ");

			extentReport.info("500-V-Enter the New Customer location and click on save button.");
			enteredSecLocVal=addSecondarylocationPage.enterRandomSecondaryLocationValue(true);


			extentReport.info("600-V-Verify the location is getting saved and gets displayed on customer list page.");
			addSecondarylocationPage.goToCustomerListPage();
			//Temp comment due to "Click customer" issue.
			//customerListPage.searchCustomer(customerName);
			//String SecLocValueInList=customerListPage.getSecLocationText();
			String SecLocValueInList=customerListPage.matchedSecLocation(enteredSecLocVal);
			System.out.println("Enterd Value --->"+enteredSecLocVal);
			System.out.println("Reflected Value --->"+SecLocValueInList);
			assertion.assertEqualsWithReporting(SecLocValueInList.toLowerCase(), enteredSecLocVal.toLowerCase(), extentReport, "600-V-Verified if the location is getting saved and gets displayed on customer list page.");

			extentReport.info("700-V- Log out and Login as a SJM admin.");
			customerListPage.verifyLogout();

			extentReport.info("Signing Again  in to the application");
			loginPage.login(login);

			extentReport.info("800-S- The actor is on Customer list page and click on Add New Customer button.");
			addCustomerPage.addCustomerClick();

			extentReport.info("900-S- The Add New Customer location page is populated .");
			addCustomerPage.addCustomerPageLanding();

			//extentReport.reportPass("300-V-The system The system displays Add Customer page");
			extentReport.info("1000-S- Fill all the data and click on Save button.");

			//Input Parameter Text to decide insert data for Drop down fields or NOT, while creating Customer.
			newCustomer =addCustomerPage.addCustomerfieldupdate(customer, "Text");
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmOk();

			//customerProfilePage.goToAddSecondaryLocationPage();

			//Temp comment due to "Add customer" issue.
			/*addCustomerPage.addCustomerfieldupdate(customer, "Text");
			String updatedUserId=addCustomerPage.updateUserId() ;
			customerName=addCustomerPage.customerNameValue;
			System.out.println("Added Customer Name is =-->"+customerName);			
			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmOk();
			*/

			extentReport.info("1100-V- Verify that Add New Customer location page is populated");
			//customerProfilePage.goToAddSecondaryLocationPage();

			extentReport.info("1200-V- Fill the secondary location and click on save button.");
			String enteredSecondaryLocationValue=addSecondarylocationPage.enterRandomSecondaryLocationValue();
			addSecondarylocationPage.clickSaveButton();
			addSecondarylocationPage.clickPopUpOkButton();
			addSecondarylocationPage.closeConfirmMsg();

			extentReport.info("1300-V- Verify the location is getting saved and gets displayed on customer list page.");
			addSecondarylocationPage.goToCustomerListPage();
			customerListPage.searchCustomer(customerName);
			secondLocValueInList=customerListPage.matchedSecLocation(enteredSecLocVal);
			assertion.assertEqualsWithReporting(secondLocValueInList.toLowerCase(), enteredSecLocVal.toLowerCase(), extentReport, "600-V-Verified if the location is getting saved and gets displayed on customer list page.");

			extentReport.info("Repeat step 100 to 500.");

			extentReport.info("100 S The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page");
			loginPage.login(login);
			customerListPage.verifyLandingPage();

			extentReport.info("200-S-The actor clicks the 'customerNameInList' link");
			extentReport.reportScreenShot("The actor clicks the 'customerNameInList' link");
			customerName=customerListPage.getAndclickOnFirstCustomerLink();
			Thread.sleep(5000);
			extentReport.info("300-S- Click on the Add Secondary location  button.");
			customerProfilePage.goToAddSecondaryLocationPage();

			extentReport.info("400-V- Verify that Add New Customer location page is populated ");
			addSecondarylocationPage.verifyLandingPage();
			assertion.assertEqualsWithReporting(true, addSecondarylocationPage.verifyWarningMsg(),extentReport,"displays Secondary location alert MIssing message **********CS 818 ");
			enteredSecLocVal=addSecondarylocationPage.enterRandomSecondaryLocationValue(true);

			addSecondarylocationPage.clickSaveButton();
			addSecondarylocationPage.clickPopUpOkButton();
			addSecondarylocationPage.closeConfirmMsg();


			extentReport.info("Repeat step 700 to 1200.");

			extentReport.info("700-V- Log out and Login as a SJM admin.");
			customerListPage.verifyLogout();	
			extentReport.info("Signing Again  in to the application");
			loginPage.login(login);


			extentReport.info("800-S- The actor is on Customer list page and click on Add New Customer button.");
			addCustomerPage.addCustomerClick();
			extentReport.info("900-S- The Add New Customer location page is populated.");
			addCustomerPage.addCustomerPageLanding();


			extentReport.info("1000-S- Fill all the data and click on Save button.");
			newCustomer =addCustomerPage.addCustomerfieldupdate(customer, "Text");
			updatedUserId=addCustomerPage.updateUserId() ;
			customerName=addCustomerPage.customerNameValue;
			System.out.println("Added Customer Name is =-->"+customerName);			

			addCustomerPage.addCustomerSave();
			addCustomerPage.addCustomerConfirmOk();

			extentReport.info("1100-V- Verify that Add New Customer location page is populated");

			extentReport.info("1200-V- Fill the secondary location and click on save button.");
			enteredSecondaryLocationValue=addSecondarylocationPage.enterRandomSecondaryLocationValue(true);


			extentReport.info("1400-S-The actor clicks the Delete button .");
			addSecondarylocationPage.goToCustomerListPage();
			customerListPage.searchCustomer(customerName);
			customerListPage.matchedSecLocation(enteredSecondaryLocationValue);	
			customerListPage.getAndclickOnFirstCustomerLink();


			customerProfilePage.deleteCustomer();
			customerProfilePage.ConfirmDeleteCustomer() ;

			extentReport.info("1500-V- Verify that  secondary location is not getting added.");
			customerListPage.searchCustomer(customerName);
			System.out.println("Matched Location is   "+customerListPage.matchedSecLocation(enteredSecondaryLocationValue));

			assertion.assertEqualsWithReporting(customerListPage.matchedSecLocation(enteredSecondaryLocationValue), "", extentReport, "secondary location is not getting added.");			
			extentReport.info("Signing out from the application");

		} catch (Exception e) {
			extentReport.reportFail("Add Secondary Location functionality is not completed successfully");
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
