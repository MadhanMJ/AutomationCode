package com.test.qa.ui.tests.UC013D;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
/*
import com.test.qa.ui.pageObjects.CustomerListPage;
import com.test.qa.ui.pageObjects.CustomerProfilePage;
import com.test.qa.ui.pageObjects.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ViewCustomerPage;
 */
import com.test.qa.utilities.CommonUtils;

public class WA_AddCustomerLocation_PageComponents extends CommonUtils {
	CommonUtils utils;
	LoginPageWithPOJO loginPage;
	AddSecondarylocationPage addSecondarylocationPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName,fieldValue;
	String customerName;
	Assertions assertion ;
	Assertions softAssert;
	DataBaseConnector dataBaseConnector;
	ViewCustomerPage viewCustomerPage;	

	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		addSecondarylocationPage= new AddSecondarylocationPage (driver, extentReport);		
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		utils= new CommonUtils();
		dataBaseConnector = new DataBaseConnector();

	}

	@Test(groups= {"Regression"})
	public void wA_AddCustomerLocation_PageComponents() throws Exception { 
		testName = CommonUtils.getTestName();
		softAssert = new Assertions(extentTest);
		assertion =  new Assertions(extentTest);
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		customer = testDataProvider.getCustomerData(testName);
		extentTest.assignAuthor("Author: ChandraMohanSingaram");

		try {
			extentReport.info("100 S The actor is logged into the system and selects Customer A (Customer with US address) and navigates to Customer Profile page.");
			loginPage.login(login,"internaluser");
			/****Customer with US address*****/
			customerName=customer.getCustomerName();
			System.out.println("Searched CUstomerName"+customerName);
			customerListPage.searchCustomerAndClick(customerName);
			customerProfilePage.goToChangeCustomerProfilePage();
			Thread.sleep(3000);
			changeCustomerProfilePage.changeCountry("USA", "");

			Thread.sleep(3000);
			customerListPage.searchCustomerAndClick(customerName);
			Thread.sleep(3000);

			extentReport.info("200 V Verify that the system displays Customer Profile page with the customer's details pre-populated.",new String[] {"ClncAcct6521"});
			customerProfilePage.verifyCustomerProfileMandateData();
			/*
			customerProfilePage.verifyCustomerProfileMandateData();
			extentReport.reportScreenShot("Customer Profile Page prepopulated with data:Lower half Page");

			fieldValue= "CustomerName";
			String cNameProfile= customerProfilePage.VerifyCustomerDataInViewMode(fieldValue);
			softAssert.assertEquals(cNameProfile, "stoakhillhospitalav",fieldValue+" detail is Prepopulated");
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+" detail is Prepopulated");

			fieldValue= "MainPhone";
			softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "CountryCode";
			softAssert.assertEquals(customerProfilePage.VerifyMandateCustomerDataInViewMode(fieldValue,"Check if pre-populated: "), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "Country";
			softAssert.assertEquals(customerProfilePage.VerifyMandateCustomerDataInViewMode(fieldValue,"Check if pre-populated: "), true, fieldValue+"detail is pre-populated. ");

			fieldValue= "Email";
			 softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			 fieldValue= "ClinicTimeZone";
			 softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			 fieldValue= "UserID";
			 softAssert.assertEquals( customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true, fieldValue+"detail is pre-populated. ");

			 fieldValue= "FirstName";
			 softAssert.assertEquals(customerProfilePage.verifyMandateCustomerDataInViewMode(fieldValue), true,fieldValue+"detail is pre-populated. ");

			 fieldValue= "LastName";


			 fieldValue= "MainContactEmail";

			 softAssert.assertEquals(customerProfilePage.VerifyMandateCustomerDataInViewMode(fieldValue,"Check if pre-populated: "), true, fieldValue+"detail is pre-populated. ");
			 */

			String Address1CPValue=customerProfilePage.getCustomerDataInViewMode("Address1");
			String Address2CPValue=customerProfilePage.getCustomerDataInViewMode("Address2");
			String Address3CPValue=customerProfilePage.getCustomerDataInViewMode("Address3");
			String SecondaryPhoneCPValue=customerProfilePage.getCustomerDataInViewMode("SecondaryPhone");
			String faxCPValue=customerProfilePage.getCustomerDataInViewMode("fax");

			extentReport.info("300 S The actor clicks the 'Add a Secondary location' button");
			customerProfilePage.goToAddSecondaryLocationPage();

			extentReport.info("400 V Verify that the system displays page Add customer location page.",new String[] {"ClncAcct2345"});
			hardAssert(addSecondarylocationPage.verifyLandingPage(),true, "Add Secondary Location page displayed");

			extentReport.info("500 V Verify that the following fields are displayed on the Add Customer location page. ",new String[] {"ClncAcct2349"});
			fieldValue= "CustomerName";
			softAssert(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true, fieldValue+" is Prepopulated");

			fieldValue= "CustomerType";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "Email";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "ClinicTimeZone";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "LegalJurisdiction";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "MainPhone";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			/***NON-Mandatory Fields*****/
			fieldValue= "Address1";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),Address1CPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "Address2";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),Address2CPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "Address3";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),Address3CPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "SecondaryPhone";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),SecondaryPhoneCPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "Fax";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),faxCPValue,fieldValue+" is matched with customer profile page value ?");

			extentReport.info("600 V Verify that the Clinic Location field is displayed for the user to enter the new clinic location name. <ClncAcct5970>");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("ClinicLocation") ;
			extentReport.reportScreenShot("Clinic Location field is displayed ");
			
			extentReport.info("700 S Click on Cancel button.");
			addSecondarylocationPage.clickCancelButton();
			addSecondarylocationPage.clickpopUpOkButtonn();

			/***************Customer B (Customer with OUS Address)**********************/ 
			extentReport.info("700 S Select Customer B (Customer with OUS Address) from the Customer List.");
			customer = testDataProvider.getCustomerData("wA_AddCustomerLocation_PageComponents_OUS");

			customerName=customerListPage.searchCustomer(customer.getCustomerName());
			customerListPage.clickCustomer(customerName);

			customerProfilePage.verifyLandingPage();		

			customerProfilePage.goToChangeCustomerProfilePage();
			changeCustomerProfilePage.changeCountry("India", "Canada");
			//Merge the steps.
			customerListPage.searchCustomer(customerName);
			customerListPage.clickCustomer(customerName);

			extentReport.info("800 S Click on 'Add a secondary location' button.");
			customerProfilePage.goToAddSecondaryLocationPage();

			extentReport.info("900 V Verify that the system displays page Add customer location page. <ClncAcct2345>");
			hardAssert(addSecondarylocationPage.verifyLandingPage(),true, "Add customer Location page displayed");
			extentReport.info("1000 S Repeat steps 500-600.");
		/*	addSecondarylocationPage.verifyDataInAddCustomerlocationpage("CustomerName");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("CustomerType");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("Address1");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("Address2");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("Address3");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("Email");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("ClinicTimeZone");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("LegalJurisdiction");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("MainPhone");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("SecondaryPhone");
			addSecondarylocationPage.verifyDataInAddCustomerlocationpage("Fax");
*/
			fieldValue= "CustomerName";
			softAssert(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true, fieldValue+" is Prepopulated");

			fieldValue= "CustomerType";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "Email";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "ClinicTimeZone";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "LegalJurisdiction";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			fieldValue= "MainPhone";
			softAssert.assertEquals(addSecondarylocationPage.verifyDataInAddCustomerlocationpage(fieldValue),true,fieldValue+" is Prepopulated");

			/***NON-Mandatory Fields*****/
			fieldValue= "Address1";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),Address1CPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "Address2";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),Address2CPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "Address3";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),Address3CPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "SecondaryPhone";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),SecondaryPhoneCPValue,fieldValue+" is matched with customer profile page value ?");

			fieldValue= "Fax";
			softAssert.assertEquals(addSecondarylocationPage.getDataFromAddCustomerlocationpage(fieldValue),faxCPValue,fieldValue+" is matched with customer profile page value ?");

			
			extentReport.info("1100 S Click on Cancel button.");

			//Merge Steps.
			addSecondarylocationPage.clickCancelButton();
			addSecondarylocationPage.clickpopUpOkButtonn();

			// extentReport.info("Signing out from the application");
			// customerListPage.verifyLogout();

		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			e.printStackTrace();
			throw e;
		}
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		//customerListPage.verifyLogout();
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}