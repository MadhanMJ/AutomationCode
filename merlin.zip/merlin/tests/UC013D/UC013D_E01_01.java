package com.test.qa.ui.tests.UC013D;

import java.lang.reflect.Method;
import java.sql.SQLException;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
//import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddSecondarylocationPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class UC013D_E01_01 extends CommonUtils {
	CommonUtils utils;
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	AddSecondarylocationPage addSecondarylocationPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ViewCustomerPage viewCustomerPage;	
	ExtentTest extentTest;
	ExtentReport extentReportTest;

	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	String testName,customerName,fieldValue, first_name, last_name, temp_pwd, location, area_code, main_phone, language, legal_jurisdiction, time_zone, customer_type, country,existingLocation,fieldMsgMissing,sql ;

	Assertions assertions ;
	Assertions softAssert;
	DataBaseConnector dataBaseConnector;

	@BeforeMethod(alwaysRun=true)
	public void initialize() throws SQLException, InterruptedException {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		addCustomerPage= new AddCustomerPage (driver, extentReport);
		addSecondarylocationPage= new AddSecondarylocationPage (driver, extentReport);		
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		viewCustomerPage = new ViewCustomerPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		dataBaseConnector= new DataBaseConnector();
		customer = new Customer();
		utils= new CommonUtils();
		dataBaseConnector.getConnection(); 
	}

	/*
	 * AUTHOR: ChandraMohan.Singaram 
	 * TC ID : 1243615
	 */

	@Test(groups= {"Regression"})
	public void uC013D_E01_01() throws Exception { 
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		softAssert = new Assertions(extentTest);
		assertions =  new Assertions(extentTest);
		//customer = testDataProvider.getCustomerData(testName);

		extentTest.assignAuthor("Author: ChandraMohanSingaram");		

		try {
			String userId = CommonUtils.randomUserId();
			//customer.setUserid(userId);
			extentReport.info("100-S-The actor (SJM Enrollment Administrator) logs into the system and navigates to Customer List page.");
			loginPage.login(login,"internaluser");
			//customerName=customerListPage.searchCustomerAndClick(customer.getCustomerName());
			customerName=customerListPage.searchCustomerAndClick("stoak");

			extentTest=	extentReport.info("200-V-Verify that the system displays page AD005 (Customer Profile) with the customer's details pre-populated.");
			customerProfilePage.verifyCustomerProfileMandateData();
			extentReport.reportScreenShot("Customer Profile Page prepopulated with data:Lower half Page");
			
			existingLocation= customerProfilePage.readCustomerDataInViewMode("ClinicLocation");
			String userID= customerProfilePage.readCustomerDataInViewMode("UserID");

			extentReport.info("300-S-The actor clicks 'Add a secondary location' button");
			customerProfilePage.goToAddSecondaryLocationPage();

			extentReport.info("400-V-Verify that the system displays page Add Secondary location ",new String[] {"ClncAcct2345"});
			addSecondarylocationPage.verifyLandingPage();
			assertions.assertEqualsWithReporting(addSecondarylocationPage.verifyLandingPage(),true, extentTest,"System Landed in Add Secondary Location Page");
			extentReport.reportScreenShot("System displays Add Secondary location Page");

			/*--------------- Missing Clinic location name /NO Location -------------------------**/
			extentTest=	extentReport.info("500-S-The actor leaves the Clinic location name field blank or enters a couple of space, then clicks the 'Save' button.");
			addSecondarylocationPage.clickSaveButton();

			extentTest=	extentReport.info("600-V-Verify that the system displays alert message CS 818 and verify that the blank Clinic location is not stored in DB location table",new String[] {"ClncAcct310"},new String[] {"ClncAcct5973"},new String[] {"ClncAcct5974"},new String[] {"ClncAcct5977"});
			Boolean fieldMsgMissing =addSecondarylocationPage.verifyWarningMsg();
			assertions.assertEquals( fieldMsgMissing,true,"Displays Secondary location alert MIssing message **********CS 818 ");
			extentReport.reportScreenShot("Secondary location alert Missing message");
			
			/*---------------Database Validation for Adding Secondary location_NO Location-----	*/	
			sql ="select count(*) cnt from customers.customer_location cl inner join users.customer_account ca on cl.customer_id = ca.customer_id inner join users.user_record ur on ur.user_record_id = ca.user_record_id where ur.logon_user_name ='"+userID+"' and cl.name = ''"; 
			softAssert.assertEquals(dataBaseConnector.getCountFromDB(sql),0,"Blank Clinic location is not stored in DB location table. <br> SQL script executed <br> "+sql);

			/*----------------- Clinic location name more than 30 characters-----------------------*/
			extentTest=	extentReport.info("900 S The actor tries to enter a location name greater than 30 characters");
			addSecondarylocationPage.addSecondaryLocationValue("clinicSecondaryLocationValueMorethan30Characters", false);
			String enterdSecLocVal=addSecondarylocationPage.readEnteredSecondaryLocationValue() ;

			extentReport.info("1000 V - Verify that the System allows to enter only 30 characters.",new String[] {"CommUI4622"});
			softAssert.assertEquals(enterdSecLocVal.length(), 30,"Verify that the System allows to enter only 30 characters");
			extentReport.reportScreenShot("System allows to enter only 30 characters");
			/*-------------------- Existing Clinic location name -------------*/
			extentTest=	extentReport.info("1100 S The actor enters an valid Clinic Location name which already exists as a Clinic location for this clinic , then clicks the 'Save' button");
			addSecondarylocationPage.addSecondaryLocationValue(existingLocation, false);
			addSecondarylocationPage.clickSaveButton();

			extentTest=	extentReport.info("1200 V - Verify that the System shall validate Customer Location data entered by the Actor and displays message CM 806  and verify that the duplicate Clinic location is not stored in DB(location table) again.",new String[] {"ClncAcct310"},new String[] {"ClncAcct299"},new String[] {"CommFn722"},new String[] {"ClncAcct5973"},new String[] {"ClncAcct5974"});
			boolean errorMsg=addSecondarylocationPage.existingsecLocErrorMsg();
			softAssert.assertEquals(errorMsg,true,"verify system  displays message CM 806 and the duplicate Clinic location is not stored.");
			extentReport.reportScreenShot("Existing SecLocation Error Message");
			/*----Database Validation for Existing Clinic location name-----*/
			sql ="select count(*) cnt from customers.customer_location cl inner join users.customer_account ca on cl.customer_id = ca.customer_id inner join users.user_record ur on ur.user_record_id = ca.user_record_id where ur.logon_user_name ='"+userID+"' and cl.name = '"+existingLocation+"'"; 
			int existingSecLocCount =dataBaseConnector.getCountFromDB(sql);
			softAssert.assertEquals(existingSecLocCount,1,"Existing Clinic location is not stored in DB location table again.");

			extentTest=	extentReport.info("1300-V- Verify that all dialogs displayed on these pages are in launguage English (US)",new String[] {"CommUI2683"});
			softAssert.assertEquals(errorMsg,true,"Duplicate Clinic location message is in English ");
			softAssert.assertEquals(fieldMsgMissing,true,"Secondary location alert MIssing message is in English ");
			extentReport.info("1500-S-End Test Case.");
		} 
		catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		//customerListPage.verifyLogout();
		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
