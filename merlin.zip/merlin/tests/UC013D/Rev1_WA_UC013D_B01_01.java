package com.test.qa.ui.tests.UC013D;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ViewCustomerPage;
import com.test.qa.utilities.CommonUtils;

public class Rev1_WA_UC013D_B01_01 extends CommonUtils{
	LoginPageWithPOJO loginPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerlistPage;
	ViewCustomerPage viewpage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	Assertions assertion ;
	DataBaseConnector dataBaseConnector;
	String show_export_session_flg,order_transmitter_flg, exportToEHR;
	List<String> expectedxportTOEHROptions = new ArrayList<String>();
	Log logger;
	
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		viewpage = new ViewCustomerPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		customerlistPage = new CustomerListPage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		logger = new Log();
	}
	
	@Test(groups= {"Regression"})
	public void clinicAccountAdmin() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
	
		login = testDataProvider.getLoginData("SJMAdmin");
		extentTest.assignAuthor("Author-Mohan Sekar");
		
		try {
			//User login to application and clicks add customer and clicks cancel without filling form
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			assertion =  new Assertions(extentTest);
            extentReport.info("100-S-The actor The actor (SJM Enrollment Administrator) is logged into the system and navigates to Customer Profile page");
			
            loginPage.login(login,"internaluser");
            viewpage.pageload();
            
            customerlistPage.listclick();
            viewpage.pageload();
           Thread.sleep(3000);
			extentTest = extentReport.info("200-V-The system displays Customer Profile page with the customer's details pre-populated.");
			 assertion.assertEquals(true,customerlistPage.verifyLandingPage());
			extentTest = extentReport.info("300-S-The actor clicks the 'Add a secondary location' button at the bottom of the page.");
			viewpage.clickElement(viewpage.addSecondaryLocation,"text");
			viewpage.pageload();
			 viewpage.pageload();
			extentReport.info("400 V Verify that the system detects that the Actor has initiated an Add a New Customer Location action",new String[] {"ClncAcct6102"});
			assertion.assertEquals(true, viewpage.isElementPresent(viewpage.addSeclocationtextbox), "Add Secondary Location Test Box is Displayed");
			extentReport.info("500-V-The system displays Add customer location page ",new String[] {"ClncAcct2345"});
			 assertion.assertEquals(true,viewpage.verifyLandingPage()); 
			extentReport.info("600 V Verify that the system provides the capacity to add a new Customer Location. ",new String[] {"ClncAcct296","ClncAcct5998"});
			assertion.assertEquals(true, viewpage.isElementPresent(viewpage.addSeclocationtextbox), "Add Secondary Location Test Box is Displayed");
			extentReport.info("700-S-The actor enters Clinic location data in the Clinic Location field and then clicks the Cancel button",new String[] {"ClncAcct6102"});
			viewpage.sendKeys(viewpage.addSeclocationtextbox,CommonUtils.randomSecLoc());
			viewpage.clickElement(viewpage.addSecLocCalcel);
			 viewpage.pageload();
			extentReport.info("720 V Verify that dialog AD 820 is displayed. ",new String[] {"ClncAcct5975"});
            assertion.assertEquals(true, viewpage.isDisplayed(viewpage.addSecLocCalcelok), "AD 820 Pop up is displayed");
    		extentReport.info(" 730 S Click on OK on the dialog. ");
            viewpage.clickElement(viewpage.addSecLocCalcelok);
            viewpage.pageload();
            Thread.sleep(3500);
            extentReport.info("  750 V Verify that the operation is cancelled and Customer list page is displayed ",new String[] {"ClncAcct5971"});
            assertion.assertEquals(true,customerlistPage.verifyLandingPage());
        	extentReport.info(" 760 S Again select the same customer and navigate to Add Secondary location page.");
        	customerlistPage.listclick();
        	 viewpage.pageload();
        	 viewpage.clickElement(viewpage.addSecondaryLocation);
        	extentReport.info("770-S-The actor enters Clinic location data in the Clinic Location field and then clicks the Save button");
        	viewpage.sendKeys(viewpage.addSeclocationtextbox,CommonUtils.randomSecLoc());
        	viewpage.clickElement(viewpage.addSecLocsave);
        	extentReport.info("800 V Verify: 1.System stores the location details in the database correctly (Table: LOCATION); - Name column (entered value) - customer_id column (the selected clinic id) - HQ_flg ( the location is non-HQ , so the flag should be 0) - Create_userid (the logon user id) ",new String[] {"ClncAcct300"});
        	extentReport.info("2.System displays AD 811 dialog box  ",new String[] {"ClncAcct301","ClncAcct5974"});
        	viewpage.waitForPageLoad();
        	extentReport.info(" 900 S The actor clicks 'OK' button on AD 811 dialog box.");
         	viewpage.clickElement(viewpage.addSecLocsaveok);
         	 viewpage.pageload();
         	extentReport.info("1000 V Verify that the AD 811 dialog box is closed & page AD 013 is displayed.  ",new String[] {"ClncAcct5974"});
         	 assertion.assertEquals(true,viewpage.verifyLandingPage()); 
         	extentReport.info(" 1100 S Repeat step #700-800");
         	extentReport.info("700-S-The actor enters Clinic location data in the Clinic Location field and then clicks the Cancel button",new String[] {"ClncAcct6102"});
			viewpage.sendKeys(viewpage.addSeclocationtextbox,CommonUtils.randomSecLoc());
			viewpage.clickElement(viewpage.addSecLocCalcel);
			 viewpage.pageload();
			extentReport.info("720 V Verify that dialog AD 820 is displayed. ",new String[] {"ClncAcct5975"});
            assertion.assertEquals(true, viewpage.isDisplayed(viewpage.addSecLocCalcelok), "AD 820 Pop up is displayed");
    		extentReport.info(" 730 S Click on OK on the dialog. ");
            viewpage.clickElement(viewpage.addSecLocCalcelok);
            viewpage.pageload();
            extentReport.info("  750 V Verify that the operation is cancelled and Customer list page is displayed ",new String[] {"ClncAcct5971"});
            assertion.assertEquals(true,customerlistPage.verifyLandingPage());
        	extentReport.info(" 760 S Again select the same customer and navigate to Add Secondary location page.");
        	customerlistPage.listclick();
        	 viewpage.pageload();
        	 viewpage.clickElement(viewpage.addSecondaryLocation);
        	extentReport.info("770-S-The actor enters Clinic location data in the Clinic Location field and then clicks the Save button");
        	viewpage.sendKeys(viewpage.addSeclocationtextbox,CommonUtils.randomSecLoc());
        	viewpage.clickElement(viewpage.addSecLocsave);
        	 viewpage.pageload();
        	extentReport.info("800 V Verify: 1.System stores the location details in the database correctly (Table: LOCATION); - Name column (entered value) - customer_id column (the selected clinic id) - HQ_flg ( the location is non-HQ , so the flag should be 0) - Create_userid (the logon user id) ",new String[] {"ClncAcct300"});
        	extentReport.info("2.System displays AD 811 dialog box  ",new String[] {"ClncAcct301","ClncAcct5974"});
        	viewpage.waitForLoading();
        	extentReport.info(" 1200 S The actor clicks on 'Cancel' button on AD 811 dialog box.");
        	assertion.assertEquals(true,viewpage.isDisplayed(viewpage.addSecLocsavecancel));

        	
         	 viewpage.pageload();
         	extentReport.info("1300 V Verify: - Alert box AD 804 is displayed ",new String[] {"ClncAcct5974"});
         	extentReport.info("  1400 S The actor click 'Cancel' button.");
         	viewpage.clickElement(viewpage.addSecLocsavecancel);
        	 viewpage.pageload();
        	extentReport.info("1500 V: The system displays customer list page. ",new String[] {"ClncAcct1777","ClncAcct5978","ClncAcct5979"});
        	  assertion.assertEquals(true,customerlistPage.verifyLandingPage()); 
        	 	extentReport.info("1600-S-The actor (User account manager) logged onto the system and navigates to page Clinic locations list.");  
        	 	customerlistPage.listclick();
           	 viewpage.pageload();
           	
           	extentReport.info("1700-S-The actor clicks Add location button.");
            viewpage.clickElement(viewpage.addSecondaryLocation);
            
            extentReport.info("1800-V- Verify that the system displays page Add location." ,new String[] {"ClncMgt25562"});
            assertion.assertEquals(true, viewpage.isDisplayed(viewpage.addSeclocationtextbox), "Add Location page is displayed");
            extentReport.info("1900-V-Verify that the system detects that the actor has initiated an Add a New Customer Location action.",new String[] {"ClncAcct6102"}) ;
            assertion.assertEquals(true, viewpage.isDisplayed(viewpage.addSeclocationtextbox), "Add Location page is displayed");
            
            extentReport.info(" 2000-V-Verify that the system provides the capability to add a new Clinic Location" ,new String[] {"ClncAcct296"});
            assertion.assertEquals(true, viewpage.isDisplayed(viewpage.addSeclocationtextbox), "Add Location page is displayed");
            extentReport.info("2100-S-The actor enters Clinic location data in the Clinic Location field and clicks the Save button");
           	
            String loc=CommonUtils.randomSecLoc();
            viewpage.sendKeys(viewpage.addSeclocationtextbox,loc);
        	viewpage.clickElement(viewpage.addSecLocsave);
        	viewpage.pageload();
        	viewpage.clickElement(viewpage.addSecLocsaveok);
        	viewpage.pageload();
        	extentReport.info("2400-V-Verify that the new location is saved and Clinic Location page is displayed .",new String[] {"ClncMgt25562"}); 
        	extentReport.info("2500S Test Case Ends");
        	assertion.assertAll();
		} catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_UC013D_B01_01  are not verified successfully");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_UC013D_B01_01  are not verified successfully ");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		//customerlistPage.verifyLogout();
		saintResult(result,extentTest);
	
	}
}

