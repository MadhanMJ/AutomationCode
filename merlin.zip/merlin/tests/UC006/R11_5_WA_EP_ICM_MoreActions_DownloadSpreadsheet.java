package com.test.qa.ui.tests.UC006;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.utilities.CommonUtils;

public class R11_5_WA_EP_ICM_MoreActions_DownloadSpreadsheet extends CommonUtils{
	
	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_LeftNavPage clinicAdminLeftNavPage;
	
	private Assertions assertion;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	private String testName;
	PatientListPage patientListPage;
	PL_TopNavPage topPatientNavPage;
	PL_PatientProfilePage patientProfilePage;
	PL_TransmissionPage patientTransmissionPage;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicAdminLeftNavPage = new CA_LeftNavPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		patientListPage = new PatientListPage(driver, extentReport);
		topPatientNavPage = new PL_TopNavPage(driver,extentReport);
		patientProfilePage = new PL_PatientProfilePage(driver, extentReport);
		patientTransmissionPage = new PL_TransmissionPage(driver, extentReport);
		
	}

	@Test
	public void TC_R11_5_WA_EP_ICM_MoreActions_DownloadSpreadsheet() throws Exception {
		
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("physicianUser");
		extentTest.assignAuthor("Author - Salin Gambhir");

		try {
			Assertions assertion = new Assertions(extentTest);
			
			extentTest = extentReport.info("100 S Login to clinic A as physician user. Navigate to Patient list page and select Patient1. Navigate to All Transmissions page, Click on Episodes link of one of the transmissions and navigate to Episodes and EGMs page.");
			loginPage.login(login);
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport, "Patient List Page");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			patientListPage.enterTier3FilterInputBx("EnrollbackICM_FVR");
			patientListPage.clickonAllTransmissionFrmList("EnrollbackICM_FVR");
			topPatientNavPage.navigateToTransmissionPage();
			patientTransmissionPage.clickOnEpisodeEGMsLink();
			//assertion.assertEqualsWithReporting(true, patientTransmissionPage.verifyEpisodePage(), extentReport, testName);
			
			extentTest = extentReport.reportInfo("200 S Click on More Actions -> Download spreadsheet.");
			patientTransmissionPage.clickOnMoreActions();
			patientTransmissionPage.downloadSpreadsheet();
			
			extentTest = extentReport.info("300 V Verify a Save dialog box is displayed to save the downloaded spreadsheet", new String[] {"CommUI10903"});
			// code to be taken from Rajesh for saving the file in specific folder
			
			extentTest = extentReport.info("400 V Verify when the actor specifies a location and saves the file, the contents of the list is saved in .csv format on the actors PC location",new String[] {"CommUI10903"});
			// common code to be taken in from framework
			
			extentTest = extentReport.info("500 V Verify the downloaded spreadsheet displays the table with the list of rows and columns in the order displayed to the user.", new String[] {"CommUI10903"});
			//
			
			
			
		} catch (AssertionError e) {
			extentReport.fail( "WA_CA_200_SchedulingAndMessaging_DynamicComponents_01 is failed due to assertion failure");
			//logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "WA_CA_200_SchedulingAndMessaging_DynamicComponents_01 is failed due to some exception");
			//logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.FAILURE || extentTest.getStatus().toString() == "fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS || extentTest.getStatus().toString() == "pass") {
			status = "Success";
		}
		writeInTextFile(testMethodName, status);
	}
}