package com.test.qa.ui.tests.UC006;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.utilities.CommonUtils;

/*
 * Author: Shafiya Sunkesala
 * Date: 17/02/2022
 * Test Case: ICM_WA_Transmissions_Episodes_and_EGMs_01
 * Test case Id: 1234190
 */

public class ICM_WA_Transmissions_Episodes_and_EGMs_01 extends CommonUtils {
	private Assertions assertions;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	AppHomeTopNavPage appHomeTopNavPage;
	
	LoginPageWithPOJO loginPage;
	Login login_Direct_Clnc_ICM_Patients;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeMethod(alwaysRun = true)
	public void initialize() {

		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver, extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver, extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);

		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login_Direct_Clnc_ICM_Patients = new Login();
		testDataProvider = new TestDataProvider();
	}

	@Test(groups= {"Regression"})
	public void TC_ICM_WA_Transmissions_Episodes_and_EGMs_01()  throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		extentTest = extentReport.initiateTest(testName);
		
		login_Direct_Clnc_ICM_Patients = testDataProvider.getLoginData("SJMClinic_ICMPatients");

		extentTest.assignAuthor("Author: Shafiya Sunkesala");
		try {
			assertions = new Assertions(extentTest);
			extentReport.info("100 S Login to a clinic Clinic_1, select ICM patient PAT1 (patient with transmission of multiple episodes) and navigate to All Transmissions tab.");
			loginPage.login(login_Direct_Clnc_ICM_Patients, "externaluser");
			assertions.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport, "Clinician Home Page is Displayed.");
			
			extentReport.info("200 S Select the transmission which have multiple episodes, On Transmission details page from left hand side navigation menu "
					+ "under ‘Alerts and Episodes’ select ‘Episodes and EGMs’ and observe episodes");
			//after test data is given need to change this
			ca_RecentTransmissionsPage.selectTireOneFilterOption("clinic patients");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier1 filter.");
			//after test data is given need to change this
			ca_RecentTransmissionsPage.enterTier3FilterInputBx("0522");
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			//Need to write the code once test dat is given
			extentReport.info("300 V Verify that the episode directory displays episodes and the EGMs correctly. "
					+ "Episodes include all types of episode and real time EGMs", new String[] {"TransMgt16925", "TransMgt16936","TransMgt17579"});
			
			extentReport.info("400 V Verify that episode information is represented in the following columns for "
					+ "each episode: Date/Time, Zone/Type, Duration, EGM icon (if available)",new String[] {"TransMgt17561"});
			//Need to see if the data has to be validated with vinay
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.isEpisodeColumnsPresent("Date/Time"),true, "Date/Time column is displayed");
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.isEpisodeColumnsPresent("Zone/Type"),true, "Zone/Type column is displayed");
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.isEpisodeColumnsPresent("Duration"),true, "Duration column is displayed");
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.isEpisodeColumnsPresent("EGM"),true, "EGM column is displayed");
			
			extentReport.info("500 S On ‘Episode Directory’, expand the search filter dropdown. (By default it is set to ‘only EGMs’)");
			//in T4 also default is not set to Only EGMS
			pl_Transmission_EpisodeAndEgmPage.expandSearchFilterDrpdwn();
			
			extentReport.info("600 V Verify that the search filters are available and they are as follows: "
					+ "Zone/Type (applicable to ICM patients), Duration, Only EGMs, All episodes.", new String[] {"TransMgt17559", "TransMgt16935", "TransMgt16932", "CommUI8244"});
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.verifySearchFilterDrpdwnValues("Zone/Type"),true, "Zone/Type value is displayed in primary search filter drop down");
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.verifySearchFilterDrpdwnValues("Duration"),true, "Duration value is displayed in primary search filter drop down");
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.verifySearchFilterDrpdwnValues("Only EGMs"),true, "Only EGMs value is displayed in primary search filter drop down");
			assertions.assertEquals(pl_Transmission_EpisodeAndEgmPage.verifySearchFilterDrpdwnValues("All Episodes"),true, "All Episodes value is displayed in primary search filter drop down");
			
			
			extentReport.info("700 S Select primary filter as Zone/Type in filter dropdown and secondary filter as any one Zone/Type.");
			pl_Transmission_EpisodeAndEgmPage.selectValue_PrimaryFilter_Drpdwn("Zone/Type");
			//The value needs to be changed based on test data provided
			String zoneVal = "Real-time EGM Freeze";
			pl_Transmission_EpisodeAndEgmPage.selectValue_SecondaryFilter_Drpdwn(zoneVal);
			
			extentReport.info("800 V Verify that all episodes of the selected zone/type are displayed.", new String[] {"TransMgt17559"});
			pl_Transmission_EpisodeAndEgmPage.validateRecords_EpisodesTable("Zone/Type", zoneVal);
			
			extentReport.info("900 S Select primary filter as ‘Duration’, in the adjacent textbox enter valid duration.");
			pl_Transmission_EpisodeAndEgmPage.selectValue_PrimaryFilter_Drpdwn("Duration");
			//Need to change the value based on test data
			String durationVal = "1";
			pl_Transmission_EpisodeAndEgmPage.enterValue_SearchBox(durationVal);
			
			extentReport.info("1000 V Verify that all the episodes of the mentioned duration are displayed.", new String[] {"TransMgt17559", "TransMgt16932", "CommUI8491"});
			pl_Transmission_EpisodeAndEgmPage.validateRecords_EpisodesTable("Duration", durationVal);
			
			extentReport.info("1100 S Select primary filter as ‘Only EGMs’");
			pl_Transmission_EpisodeAndEgmPage.selectValue_PrimaryFilter_Drpdwn("Only EGMs");
			
			extentReport.info("1200 V Verify that the only episodes which have EGMs associated are displayed.", new String[] {"TransMgt16935"});
			pl_Transmission_EpisodeAndEgmPage.validateRecords_EpisodesTable("Only EGMs", "");
			
			extentReport.info("1300 S Select an episode and open it.");
			
			extentReport.info("1400 V Verify that the episode details are correctly displayed in a new modal dialog.", new String[] {"TransMgt16934", "TransMgt11683"});
			
			extentReport.info("1500 S Verify that the Episode window consists of Previous and Next buttons.", new String[] {"TransMgt18529"});
			
			extentReport.info("1600 S Click on the Next and Previous buttons.");
			
			extentReport.info("1700 V Verify that the reports for subsequent episodes are displayed upon click on Next button "
					+ "and reports of previous episodes upon click on Previous arrow button.", new String[] {"TransMgt18529"});
			
			extentReport.info("1800 S On Modal dialog window click on Print button. Select appropriate printe");
			
			extentReport.info("1900 V Verify that episode details are printed correctly.", new String[] {"TransMgt16669"});
			
			extentReport.info("2000 S Close the Modal dialog.");
			
			extentReport.info("2100 V Verify that user is redirected to Episode directory page.", new String[] {"TransMgt16670"});
			
			
			
			
			
			
			assertions.assertAll();

		} catch (AssertionError e) {
			extentReport.reportFail( "ICM_WA_Transmissions_Episodes_and_EGMs_01 is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "ICM_WA_Transmissions_Episodes_and_EGMs_01 is failed due to exception failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
	appHomeTopNavPage.clickSignOutLink();
	saintResult(result, extentTest);

	}
}
