package com.test.qa.ui.tests.UC006;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_ICD_CRTD_MerlinAtHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_DirectAlert_Pacemaker_CRTP_Page;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class Rev5_WA_ICM_EpisodeDirectory_Tier2Filter_01 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	ExtentTest extentTest, child1;
	Login login;
	Customer customer;
	TestDataProvider testDataProvider;
	private String testName;
	String clinicalTrailSectionTitle;
	CA_DirectAlert_ICD_CRTD_MerlinAtHomePage directAlert_MerlinAtHomePage;
	CA_DirectAlert_Pacemaker_CRTP_Page pacemaker;	
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CommonUtils commonUtils;
	CA_LeftNavPage clncAdnLftNav;
	AppHomeTopNavPage appHomeTopNavPage;
	CustomerListPage customerListPage;
	PatientListPage patientListPg;
	PL_Transmission_EpisodeAndEgmPage episodesAndEGMPage;


	@BeforeClass
	public void initialize() {
		driver.close();
		driver = CommonUtils.initializeDriver();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		directAlert_MerlinAtHomePage =new CA_DirectAlert_ICD_CRTD_MerlinAtHomePage(driver, extentReport);
		pacemaker=new CA_DirectAlert_Pacemaker_CRTP_Page(driver, extentReport);
		commonUtils=new CommonUtils();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		clncAdnLftNav=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage = new AppHomeTopNavPage(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		patientListPg = new  PatientListPage(driver, extentReport); 
		episodesAndEGMPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
	}


	//Author: Alok
	//Test case : 11.0Rev5_WA_ICM_EpisodeDirectory_Tier2Filter_01
	@Test
	public void WA_80Rev2_PA001_PatientList_01() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		extentTest = extentReport.initiateTest(testName);

		login = testDataProvider.getLoginData("Clinic_User");
		extentTest.assignAuthor("ALOK");

		

		try {
			
			Assertions assertion =  new Assertions(extentTest);
			extentReport.info("Scenario1: Select the latest transmission from the All Transmission Page.");		
			
			extentReport.info("100S Login to Clinic and Navigate to Patient List Page.");	
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.clickPatientListLink();
			assertion.assertEqualsWithReporting(true, patientListPg.verifyLandingPage(), extentReport,
					"Patient List page is displayed");
			extentReport.reportScreenShot("Navigated to Patient List.");

			extentReport.info("200S Select Patient1 from patient List and Navigate to All Transmission tab->Select the latest transmission and Navigate to Transmission Tab -> Episodes and EGM's Page");
			patientListPg.selectTierOneFilterOption("Active Clinic Patients");
			patientListPg.selectTier2FilterInDropdown();
			patientListPg.selectTierTwoFilterOption("All");
			patientListPg.enterTier3FilterInputBx("0509");
			patientListPg.clickOnPatient();
			patientListPg.navigateToAllTransmissionTab();
			patientListPg.clickOnPatientInAllTrasmissionPage();
			patientListPg.clickOnEpisodesAndEGMs();
			episodesAndEGMPage.verifyEpisodeTypeInTable();
			episodesAndEGMPage.selectEpisodeTypeOption("All");
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.verifyLandingPage(), extentReport,
					"Episodes and EGM page is displayed");
			extentReport.reportScreenShot("Navigated to Episodes and EGM's Page.");
			
			extentReport.info("300S Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'AT/AF'");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			episodesAndEGMPage.selectEpisodeTypeOption("AT/AF");
			extentReport.reportScreenShot("Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'AT/AF'");
			
			extentReport.info("400V Verify that the page displays AT/AF episodes matching the tier 1 filter that is selected",new String[] {"TransMgt18678"});
			
			extentReport.info("500S Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Brady'");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			episodesAndEGMPage.selectEpisodeTypeOption("Brady");
			extentReport.reportScreenShot("Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Brady'");
			
			extentReport.info("600V Verify that the page displays Brady episodes matching the tier 1 filter that is selected",new String[] {"TransMgt18679"});
			
			extentReport.info("700S Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Pause'");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			episodesAndEGMPage.selectEpisodeTypeOption("Pause");
			extentReport.reportScreenShot("Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Pause'");
			
			extentReport.info("800V Verify that the page displays Pause episodes matching the tier 1 filter that is selected",new String[] {"TransMgt18680"});
			
			extentReport.info("900S Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Symptom'");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			episodesAndEGMPage.selectEpisodeTypeOption("Symptom");
			extentReport.reportScreenShot("Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Symptom'");
			
			extentReport.info("1000V Verify that the page displays Symptom episodes matching the tier 1 filter that is selected",new String[] {"TransMgt18681"});
			
			extentReport.info("1100S Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Tachy'");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			episodesAndEGMPage.selectEpisodeTypeOption("Tachy");
			extentReport.reportScreenShot("Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'Symptom'");
			
			extentReport.info("1200V Verify that the page displays Tachy episodes matching the tier 1 filter that is selected",new String[] {"TransMgt18682"});
			
			extentReport.info("1300S Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier 2 Filter -> Select all the checkboxes");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			episodesAndEGMPage.selectEpisodeTypeOption("All");
			extentReport.reportScreenShot("Select Tier 1 Filter (Show Current/1 week/2week/30 days/60 days/ 90 days/120 days) and Tier2 Filter i.e. checkbox as -> 'All'");
			
			extentReport.info("1400V Verify that all the episodes i.e AT/AF, Tachy, Brady, Pause, Symptom are displayed in the list",new String[] {"TransMgt18678","TransMgt18679","TransMgt186780","TransMgt18681","TransMgt18682"});
			
			
		} 
		catch (AssertionError e) {
			extentTest = extentReport.fail( "11.0Rev5_WA_ICM_EpisodeDirectory_Tier2Filter_01 is failed due to assertion failure");
			extentTest.fail("11.0Rev5_WA_ICM_EpisodeDirectory_Tier2Filter_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;
		}

		catch (Exception e) {
			extentTest = extentReport.fail("11.0Rev5_WA_ICM_EpisodeDirectory_Tier2Filter_01 is failed due to some exception");
			extentTest.fail("11.0Rev5_WA_ICM_EpisodeDirectory_Tier2Filter_01 is failed"+"<br>"+e.getMessage());
			e.printStackTrace();
			throw e;

		}
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			status = "Failure";
		} else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
			status = "Success";
		} 

		writeInTextFile(testMethodName, status);
	}

}

