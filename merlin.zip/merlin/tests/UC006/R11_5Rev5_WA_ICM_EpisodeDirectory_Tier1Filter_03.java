package com.test.qa.ui.tests.UC006;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_EpisodesAndEGMPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class R11_5Rev5_WA_ICM_EpisodeDirectory_Tier1Filter_03 extends CommonUtils{

	Assertions assetions;
	Login loginClinicUser_withAllDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	Login loginAP;
	Login loginPhy;
	Login loginLimited;
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PL_AllTransmissionsPage allTransmissionPage;
	PL_TransmissionPage transmissionPage;
	PL_Transmission_EpisodeAndEgmPage episodesAndEGMPage;
	PatientListPage patientListPage;
	List<Date> latestTransDate;
	List<Date> comparedDate;
	SimpleDateFormat df;
	private String DATE_FORMAT;
	String timestamp;

	@BeforeClass
	public void initialize() {
		testDataProvider = new TestDataProvider();
		loginAP = new Login();
		loginPhy = new Login();
		loginLimited = new Login();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		allTransmissionPage = new PL_AllTransmissionsPage(driver, extentReport);
		transmissionPage = new PL_TransmissionPage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		episodesAndEGMPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		latestTransDate = new ArrayList<Date>();
		comparedDate = new ArrayList<Date>();
		DATE_FORMAT = "MM/dd/yyyy";
		df = new SimpleDateFormat(DATE_FORMAT);
		timestamp = "";
	}

	@Test
	public void WA_ICM_EpisodeDirectory_Tier1Filter_03() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);

		loginAP = testDataProvider.getLoginData("WA_ICM_EpisodeDirectory_Tier1Filter_03_DAL");
		// loginPhy = testDataProvider.getLoginData("");
		// loginLimited = testDataProvider.getLoginData("");

		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			assertion = new Assertions(extentTest);

			extentReport.info("100S Login to Clinic and Navigate to Patient List Page");
			loginPage.login(loginAP, "externaluser");
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport,
					"Clinician Home Landing page is displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport,
					"Patient List page is displayed");

			extentReport.info("200S Select Patient1 from patient List and Navigate to All Transmission tab->Select the transmission "
					+ "and Navigate to Transmission Tab -> Episodes and EGM's Page");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.clickOnPatientNameFrmList("Patient1");
			patientListPage.clickAllTransmissionTab();
			assertion.assertEqualsWithReporting(true, allTransmissionPage.verifyLandingPage(), extentReport,
					"All transmission page is displayed");
			timestamp = allTransmissionPage.clickOnNthTransRecordAndGetTimestamp("8");
			assertion.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport,
					"Transmission page is displayed");
			transmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.verifyLandingPage(), extentReport,
					"Episodes and EGM page is displayed");
			
			
			extentReport.info("300S Select Tier1 Filter as Show-> Current");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			
			extentReport.info("400V Verify the page now displays new episodes and EGMs from selected transmission date "
					+ "and does not display episodes and Egm’s from another transmission with similar date", new String[] {"TransMgt18669"});
			
			
			
			extentReport.info("500S Select Tier1 Filter as Show-> 1 week");
			episodesAndEGMPage.selectTierOneFilterOption("1 Week");
			
			extentReport.info("600V Verify the page now displays new episodes and EGMs from selected transmission date up to 1 week ago which includes the episodes "
					+ "and egm’s from the 2nd transmission with similar date", new String[] {"TransMgt18670"});
			
			extentReport.info("700S Select Patient 2 from patient List and Navigate to All Transmission tab->Select the latest transmission "
					+ "and Navigate to Transmission Tab -> Episodes and EGM's Page");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport,
					"Patient List page is displayed");
			patientListPage.selectTierTwoFilterOption("All");
			patientListPage.clickOnPatientNameFrmList("Patient2");
			patientListPage.clickAllTransmissionTab();
			assertion.assertEqualsWithReporting(true, allTransmissionPage.verifyLandingPage(), extentReport,
					"All transmission page is displayed");
			timestamp = allTransmissionPage.clickOnNthTransRecordAndGetTimestamp("1");
			assertion.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport,
					"Transmission page is displayed");
			transmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.verifyLandingPage(), extentReport,
					"Episodes and EGM page is displayed");
			
			extentReport.info("800S Select Tier1 Filter as Show-> Current");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			
			extentReport.info("900V Verify the page now displays new episodes and EGMs from selected transmission date "
					+ "and does not display episodes and Egm’s from another transmission with similar date", new String[] {"TransMgt18670"});
			
			extentReport.info("1000S Select Tier1 Filter as Show-> 1 week");
			episodesAndEGMPage.selectTierOneFilterOption("1 Week");
			
			extentReport.info("1100V Verify the page now displays new episodes and EGMs from selected transmission date up to 1 week ago which includes the episodes"
					+ "and egm’s from the 2nd transmission with similar date", new String[] {"TransMgt18670"});
			
			extentReport.info("1200S Select transmission 2 and Navigate to Transmission Tab -> Episodes and EGM's Page");
			patientListPage.clickAllTransmissionTab();
			assertion.assertEqualsWithReporting(true, allTransmissionPage.verifyLandingPage(), extentReport,
					"All transmission page is displayed");
			assertion.assertAll();
			timestamp = allTransmissionPage.clickOnNthTransRecordAndGetTimestamp("2");
			assertion.assertEqualsWithReporting(true, transmissionPage.verifyLandingPage(), extentReport,
					"Transmission page is displayed");
			transmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.verifyLandingPage(), extentReport,
					"Episodes and EGM page is displayed");
			
			extentReport.info("1300S Select Tier1 Filter as Show-> Current");
			episodesAndEGMPage.selectTierOneFilterOption("Current");
			
			extentReport.info("1400V Verify the page now displays new episodes and EGMs from selected transmission date"
					+ "and does not display episodes and Egm’s from another transmission with similar date", new String[] {"TransMgt18669"});
			
			/*
			 * AP – hcl1336514cl_direct / Merlinnet123!
			 * 
			 * Phy – HCL1336514_D_Phy / Merlinnet123!
			 * 
			 * LU – HCL1336514_D_LU / Merlinnet123!
			 */

		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
}
}
