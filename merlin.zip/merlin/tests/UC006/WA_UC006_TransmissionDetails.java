package com.test.qa.ui.tests.UC006;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Keys;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_UC006_TransmissionDetails extends CommonUtils {

	/*
	 * Test case name: WA_UC006_TransmissionDetails
	 * Author: Rajesh Singaraj 
	 * Test case ID: 1244546
	 * 
	 */
	LoginPageWithPOJO loginPage;
	Login login;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTrnsPg;
	private String testName;
	private Log logger = new Log();
	Customer customer;
	PatientListPage patientListPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	
	@BeforeMethod
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);		
		login = new Login();
		testDataProvider = new TestDataProvider();
		recentTrnsPg = new CA_RecentTransmissionsPage(driver, extentReport);
		customer = new Customer();
		patientListPage=new PatientListPage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
	}

	@Test
	public void WA_UC006_TransmissionDetails() throws Exception {	
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("physicianUser1");
		customer = testDataProvider.getCustomerData("WA_UC006_TransmissionDetails");
		extentTest.assignAuthor("Author: Rajesh Singaraj");
		try {
			Assertions assertions = new Assertions(extentTest);	
			
			extentReport.info("100 S The actor logs to a clinic where no columns have been removed and navigates to Patient List page");			
			loginPage.login(login);
			patientListPage.invisibleOfSpinner();
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");			
			assertions.assertEqualsWithReporting(recentTrnsPg.verifyLandingPage(), true, extentReport,"Recent Transmission tab should be displayed");
						
			extentReport.info("200S Select tier 1 filter as Clinic Patients and tier 2 filter as All");
			recentTrnsPg.selectTier1FilterValueFromDropdown();
			
			extentReport.info("300S Select transmission link of Patient Initiated Transmission (Patient) having reports and episodes to open Transmission Details Page.");
			patientListPage.PatientNamesearch(customer.getPatientNames());
			patientListPage.clickElement("SearchedPatient");
			
			extentReport.info("400V Verify that transmission date and time is displayed correctly (same as selected) <TransMgt10450>");
			patientListPage.verifyTransDateAndTime();
			
			extentReport.info("500V Verify that in left navigation pan, following links are displayed under Summary section <TransMgt16307> -FastPath™ Summary,Episodes Summary,Diagnostics Summary");
			patientListPage.verifyLeftPanelReports("Summary");
			 								
			extentReport.info("600V Verify that in left navigation panel, following reports are displayed under Alerts & episodes section <TransMgt16307> -Alert Summary,Episodes and EGMs,Extended Episodes");
			patientListPage.verifyLeftPanelReports("AlertEpisodes");			
			
			extentReport.info("700V Verify that in left navigation panel, following reports are displayed under Diagnostics section - Extended Diagnostics,ST Monitoring,Corvue™ Report,DirectTrend™ Report");
			patientListPage.verifyLeftPanelReports("Diagnostics");
			
			extentReport.info("800V Verify that in left navigation pan, following reports are displayed under Tests section <TransMgt16307> - Test Results");
			patientListPage.verifyLeftPanelReports("TestResults");
			
			extentReport.info("900V Verify that in left navigation pan, following reports are displayed under Parameters section <TransMgt16307> -Parameters");
			patientListPage.verifyLeftPanelReports("Parameters");
			
			extentReport.info("1000V Verify that in left navigation pan, following reports are displayed under Wrap-Up™ Overview section <TransMgt16307> -Wrap-Up™ Overview");
			patientListPage.verifyLeftPanelReports("Wrapup");
			
			extentReport.info("1100V Verify that in left navigation pan, following reports are displayed under Other section <TransMgt16307> -View Text Summary,View Merged Report");
			patientListPage.verifyLeftPanelReports("OtherReports");
			
			
			extentReport.info("1200S Click on View Text Summary link");
			patientListPage.clickElement("TextSummaryBtn");
			
			extentReport.info("1300V Verify that Text Summary Report dialog is opened");
			patientListPage.clickElement("TextSumamryReportTitle");
			extentReport.info("1400S Close Text Summary Report dialog");
			
			extentReport.info("1500S Click on View Merged Report link");
			patientListPage.clickElement("ViewMergedReportBtn");
			
			extentReport.info("1600V Verify that Merged reports are displayed in new dialog <TransMgt16905>");
			patientListPage.clickElement("ViewMergedReportTitle");
			
			extentReport.info("1700S Close Merged Report dialog");
			patientListPage.clickElement("ViewMergeReportCancelBtn");
			
			extentReport.info("1800V Verify Transmission Details page is displayed");
			patientListPage.clickElement("TransmissionDetailsPage");
			
			extentReport.info("1900S Click on Episodes and EGMs link in Alerts & episodes section");
			patientListPage.clickElement("EpidosdeEGMLink");
			
			extentReport.info("2000V Verify that Episode list table is displayed with columns Date/Time, Zone/Type, CL (ms), Therapy, Duration, EGM, Alerts <TransMgt16916>, <TransMgt16925>");
			patientListPage.clickElement("dateTimeInEpisodeAndEGM");
			patientListPage.clickElement("zoneTypeInEpisodeAndEGM");
			patientListPage.clickElement("clMSInEpisodeAndEGM");
			patientListPage.clickElement("threapyInEpisodeAndEGM");
			patientListPage.clickElement("durationInEpisodeAndEGM");
			patientListPage.clickElement("EGMInEpisodeAndEGM");
			patientListPage.clickElement("alertInEpisodeAndEGM");
			
			extentReport.info("2100S Click on Date and Time link of first episode");
			patientListPage.clickElement("firstEpisodeDateAndTimeValue");
			
			extentReport.info("2200V Verify that Episode report is displayed in new dialog <TransMgt11683>");
			patientListPage.clickElement("ViewMergedReportTitle");
			
			extentReport.info("2300S Close Episode report dialog");
			patientListPage.clickElement("ViewMergeReportCancelBtn");
			
			extentReport.info("2400S Click on Schedule link");
			patientListPage.clickElement("scheduleLink");
			
			extentReport.info("2500V Verify that Schedule dialog is displayed. <TransMgt17241>");
			patientListPage.clickElement("scheduleDialogBox");
			
			extentReport.info("2600S Close the Schedule dialog");
			patientListPage.clickElement("scheduleCancelBtn");
			
			extentReport.info("2700S Click on Print link");
			patientListPage.clickElement("printLink");
			
			extentReport.info("2800V Verify that Print Transmission dialog is displayed. <TransMgt9107>");
			patientListPage.clickElement("printDialogBox");
			
			extentReport.info("2900S Close the Print Transmission dialog");
			patientListPage.clickElement("printCancelBtn");
			
			extentReport.info("3000S Click on More Action link");
			patientListPage.clickElement("MoreAction");
			
			
			
			
			
			
			
						
		} catch (AssertionError e) {
			extentReport.fail("WA_UC006_TransmissionDetails is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail("WA_UC006_TransmissionDetails is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
