package com.test.qa.ui.tests.UC250;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_PatientProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.DriverUtils;


public class NV_IB001_TRN_LST extends CommonUtils{
	LoginPageWithPOJO loginPage;
	DataBaseConnector dataBaseConnector;
	ExtentTest extentTest;
	Login login;
	CA_ClinicLocationsPage ca_ClinicLocationsPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	CA_RecentTransmissionsPage recentTransmissionsPage;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	private String testName;
	CommonUtils commonUtils; 
	DriverUtils driverUtils;
	CA_RecentTransmissionsPage recentTrnsPg;
	PL_PatientProfilePage patientProfilePg;
	PL_TransmissionPage transmissionPg;
	PatientListPage patientListPg;
	PL_AllTransmissionsPage allTransmissionPg;
	Patient patient;
	
	@BeforeClass
	public void initialize() {
		driver = CommonUtils.initializeDriver();
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		ca_ClinicLocationsPage = new CA_ClinicLocationsPage(driver, extentReport);
		recentTrnsPg= new CA_RecentTransmissionsPage(driver, extentReport);
		patientProfilePg = new PL_PatientProfilePage(driver, extentReport);
		 transmissionPg = new PL_TransmissionPage(driver, extentReport);
		  patientListPg = new PatientListPage(driver, extentReport);
		   allTransmissionPg = new PL_AllTransmissionsPage(driver, extentReport);
		
		login = new Login();
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		commonUtils=new CommonUtils();
		patient = new Patient();
		
	}
	
	
	// Testcase id: 1234491, Testcase name: NV_IB001_TRN_LST, Author- Dhaval
	
	@Test	
	public void NV_IB001_TRN_LST_TC() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		extentTest = extentReport.initiateTest(testName);
		
		login = testDataProvider.getLoginData("Regular_ClinicA");
		patient = testDataProvider.getSearchPatientData(testName);
		extentTest.assignAuthor("Author: Dhaval Kothari");
		try {
			Assertions assertions=new Assertions(extentTest);
			
					
			extentTest= extentReport.info("100 S The actor logs to a clinic and navigates to Recent Transmissions page");
			loginPage.login(login,"externaluser");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
			assertions.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),extentReport, "Record Tranmission Page is displayed");
			
			
			extentReport.info("200 V Verify when the user clicks on the Transmission column data for a website notification the PA400 'Transmission Details' page associated with the website notification is displayed", new String[] {"<TransMgt9112>"});
			//recentTrnsPg.selectTireOneFilterOption("clinic patients");
			recentTrnsPg.enterTier3FilterInputBx(patient.getLastName());
			String transmissionDatTime= recentTrnsPg.verifyFirstTranmissionDtTimeOnRT().substring(0,19);
			recentTrnsPg.clickFirstTranmissionOnRT();
			assertions.assertEqualsWithReporting(true,transmissionPg.verifyPLTranmissionTabIsSelected().contains("active"),extentReport, "Tranmission Tab under Patient List is displayed");
		    assertions.assertEqualsWithReporting(true,transmissionPg.verifyTransmissionDtTime().contains(transmissionDatTime),extentReport, "Tranmission Date Time  is displayed correctly");
		    assertions.assertEqualsWithReporting(true,transmissionPg.verifyPatientName().contains(patient.getFirstName()+" "+patient.getLastName()),extentReport, "Patient Name  is displayed correctly"); 
		    extentReport.reportScreenShot("User is able to successfully navigate to Transmission under Patient List page");
			
			extentReport.info("210 S The actor navigates to Recent Transmissions page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
			assertions.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),extentReport, "Record Tranmission Page is displayed");
			
			
			extentReport.info("220 V Verify when the user clicks on the pencil icon in the Comments Column for a website notification the PA500 'Clinical Comments' page associated with the website notification is displayed", new String[] {"<TransMgt16943>"});
			recentTrnsPg.enterTier3FilterInputBx(patient.getLastName());
			recentTrnsPg.validatePencilIcon();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyClinicCommentPoup(), extentReport, "Verifed that Clinical Comments dialog is displayed");
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyPatientNameCommentPopupMsg().contains(patient.getFirstName()+", "+patient.getLastName()),extentReport, "Patient Name  is displayed correctly");
			recentTrnsPg.validateClinicCommentPoupCloseBtn();
			
			
			extentReport.info("300 S The actor navigates to Recent Transmissions page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
			assertions.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),extentReport, "Record Tranmission Page is displayed");
			
			
			
			extentReport.info("400 V Verify when the user clicks on the Patient field for a website notification the PA100 'Patient Profile' page associated with the website notification is displayed", new String[] {"<TransMgt9115>"});
			recentTrnsPg.enterTier3FilterInputBx(patient.getLastName());
			recentTrnsPg.navigateToPatientProfilePage(patient.getLastName());
			assertions.assertEqualsWithReporting(true,patientProfilePg.verifyLandingPage(),extentReport, "Patient Profile Page is displayed");
			assertions.assertEqualsWithReporting(true,patientProfilePg.verifyPatientName().contains(patient.getFirstName()+" "+patient.getLastName()),extentReport, "Patient Name is displayed correctly");
			extentReport.reportScreenShot("User is able to successfully navigate to Patient Profile page");
			
		    
			extentReport.info("500 S The actor navigates to Recent Transmissions page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
			assertions.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),extentReport, "Record Tranmission Page is displayed");
			
			
			
			extentReport.info("600 V Verify when the user clicks on the Schedule field for a website notification the PA443 Standalone Schedule page associated with the website notification is displayed", new String[] {"<TransMgt9116>"});
			recentTrnsPg.enterTier3FilterInputBx(patient.getLastName());
			recentTrnsPg.clickFirstScheduleOnRT();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyHeaderSchedulePopupMsg().contains("Schedule"),extentReport, "Schedule popup header displayed correctly");
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyPatientNameSchedulePopupMsg().contains(patient.getFirstName()+", "+patient.getLastName()),extentReport, "Patient Name  is displayed correctly");
			recentTrnsPg.clickCancelByOnSchedulePopup();
			
			extentReport.info("700 S The actor navigates to Recent Transmissions page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyLandingPage(),extentReport, "Record Tranmission Page is displayed");
			assertions.assertEqualsWithReporting(true,clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),extentReport, "Record Tranmission Page is displayed");
			
			
			extentReport.info("800 V Verify when the user clicks on the ‘Episodes with Alerts’ link in the Alert List field for a website notification the Transmission Details-Episodes and EGM tab associated with the website notification is displayed ", new String[] {"<TransMgt16737>"});
			recentTrnsPg.enterTier3FilterInputBx(patient.getLastName());
			recentTrnsPg.clickFirstAlertListOnRT();
			assertions.assertEqualsWithReporting(true,transmissionPg.verifyTransmissionDtTime().contains(transmissionDatTime),extentReport, "Tranmission Date Time  is displayed correctly");
		    assertions.assertEqualsWithReporting(true,transmissionPg.verifyPatientName().contains(patient.getFirstName()+" "+patient.getLastName()),extentReport, "Patient Name  is displayed correctly"); 
		    transmissionPg.verifyNavigationToEpisodes();
			
			  		  
		}
		catch (AssertionError e) {
			 extentReport.reportFail( "NV_IB001_TRN_LST_TC is failed due to assertion failure",CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			 extentReport.reportFail( "NV_IB001_TRN_LST_TC is failed due to some exception",CommonUtils.convertStackTraceToString(e));
			throw e;
		}	
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	}


}


