package com.test.qa.ui.tests.UC250;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.ResultSet;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;

import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_IB001_Quicklinks01 extends CommonUtils {
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	DataBaseConnector dataBaseConnector;
	CA_LeftNavPage ca_LeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTrnsPg;
	private String testName;
	PatientListPage ca_patientListPage;
	int countInTable;
	
	private Log logger = new Log();

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		clinicianHomeTopNavPage=new ClinicianHomeTopNavPage(driver, extentReport);
		ca_LeftNavPage=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage=new AppHomeTopNavPage(driver, extentReport);
		recentTrnsPg= new CA_RecentTransmissionsPage(driver, extentReport);
		ca_patientListPage=new PatientListPage(driver, extentReport);

	}

	@Test
	public void rev_WA_IB001_Quicklinks01() throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("DirectAll");
		extentTest.assignAuthor("Author: Abhishek kumar");
		try {
			Assertions assertions=new Assertions(extentTest);
			extentReport.info("100 S Login to a clinic as a physician of Direct Clinic and navigate to IB001 page");
			loginPage.login(login);
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
			assertion.assertEqualsWithReporting(recentTrnsPg.verifyLandingPage(),true,extentReport,"Recent Transmission tab should be displayed");
			//done no step left

			extentReport.info("200 V Verify the Quick Links module is displayed on the page.",new String[] {"Gen2061"});
			extentReport.reportScreenShot("Quick links Module is displayed on the page.");
			recentTrnsPg.verifyQuickLinkModule();
			//done no step left
			
			
			extentReport.info("300 S Set Tier 1 filter to ‘My Patients'");
			extentReport.reportScreenShot("Tier 1 filter is set to ‘My Patients'");
			recentTrnsPg.selectTireOneFilterOption("my patients");
			//done no step left
			
			
			extentReport.info("400 V Verify the system displays ‘Unviewed Transmissions’ link "
					+ "in Quick Links module with count of unviewed website notifications for Tier 1"
					+ " filter (My Patients).",new String[] {"Gen2065"});
			int UnviewedTnsnCountvalue=Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount());
			int unviewedTrnsmissionDipInTable=recentTrnsPg.unviewedTrnsmissionDipInTable();
			assertions.assertEqualsWithReporting(true,(UnviewedTnsnCountvalue==unviewedTrnsmissionDipInTable),extentReport,"Recent Transmission tab should be displayed");
             
			//Database Validation(using db query we need to compare unviewed transmission in ui and db)
			dataBaseConnector.getConnection();
			String query ="select count(*) Unviewed_transmissions from transmissions.rt_cache rc where customer_application_id=146225\r\n"
			  +"and status_cd=68 and patient_id in (SELECT DISTINCT capplp.patient_id AS patientId\r\n"
					 +"FROM patients.customer_application_patient capplp INNER JOIN patients.customer_account_patient cap\r\n"
					  +"ON capplp.customer_appl_patient_id = cap.customer_appl_patient_id WHERE\r\n"
					  +"capplp.customer_application_id = 146225 AND cap.customer_account_id = 176084)";
			ResultSet customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("Unviewed_transmissions");
				
			}
			assertions.assertEqualsWithReporting(true,(UnviewedTnsnCountvalue==countInTable),extentReport,"Recent Transmission tab should be displayed");
			//done no step left
			
			
			extentReport.info("500 S Click on the ‘Unviewed Transmissions’ link");
			recentTrnsPg.navigateToUnviewedTransmissionPage();
			
			//done no step left

			//after 
			extentReport.info("600 V Verify the system displays the unviewed transmissions on Recent Transmission page for patients where physician has been specified as a medical team member.",new String[] {"Gen2063","TransMgt16759","TransMgt8930"});
			UnviewedTnsnCountvalue=Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount());
			unviewedTrnsmissionDipInTable=recentTrnsPg.unviewedTrnsmissionDipInTable();
			assertions.assertEqualsWithReporting(true,(UnviewedTnsnCountvalue==unviewedTrnsmissionDipInTable),extentReport,"Recent Transmission tab should be displayed");
			//done no step left

			extentReport.info("700 S Set Tier 1 filter to ‘Clinic Patients’. ");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
			
			//done no step left

			extentReport.info("800 V Verify the system displays ‘Unviewed Transmissions’ link in Quick Links module with count of unviewed website notifications for Tier 1 filter (Client Patients).",new String[] {"Gen2065"});
			UnviewedTnsnCountvalue=Integer.parseInt(recentTrnsPg.captureUnviewedTnsnCount());
			unviewedTrnsmissionDipInTable=recentTrnsPg.unviewedTrnsmissionDipInTable();
			assertions.assertEqualsWithReporting(true,(UnviewedTnsnCountvalue==unviewedTrnsmissionDipInTable),extentReport,"Recent Transmission tab should be displayed");
  			//Database Validation(using db query we need to compare unviewed transmission in ui and db)
			dataBaseConnector.getConnection();
			query ="select count(*) Unviewed_transmissions from transmissions.rt_cache rc"
					+ " where customer_application_id=146225 and status_cd=68; ";
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("Unviewed_transmissions");
				
			}
			assertions.assertEqualsWithReporting(true,(UnviewedTnsnCountvalue==countInTable),extentReport,"Recent Transmission tab should be displayed");
			//done no step left
			
			
			extentReport.info("900 S Click on the ‘Unviewed Transmissions’ link");
			recentTrnsPg.navigateToUnviewedTransmissionPage();

			//done no step left
			extentReport.info("1000 V Verify the system displays the unviewed transmissions on Recent "
					+ "Transmission page for all active and released patients "
					+ "enrolled in Actor’s clinic.",new String[] {"Gen2063","TransMgt16759","TransMgt16990"});
			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyUnViewedPatientInTable("patientName","1"),extentReport,"active patient is present in the page");
			assertions.assertEqualsWithReporting(false,recentTrnsPg.verifyUnViewedPatientInTable("patientName","1"),extentReport,"Released patient is present in the page");
			appHomeTopNavPage.clickSignOutLink();

			//done no step left


			//***** Quick Link - Transmissions with Alerts **** 

			login = testDataProvider.getLoginData("DirectAll");

			

			loginPage.login(login);
			extentReport.info("1100 S Set Tier 1 filter to ‘Clinic Patients’.");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");
          
			//done no step left
			
        //As mentioned by Praveen we don't need to modify the steps and we need to compare the count b/w db and ui			
			extentReport.info("1200 V Verify the system displays ‘Transmissions with alerts’ link in Quick Links module with"
					+ " count of Transmissions with atleast one associated alert"
					+ " for Tier 1 filter (Client Patients).");
			recentTrnsPg.validateTrnsWithAlertQuickLink();
			int captureTrnswithAlertCount=Integer.parseInt(recentTrnsPg.captureTrnswithAlertCount());
			dataBaseConnector.getConnection();
			query ="select count(*) trans_with_alerts from transmissions.rt_cache rc where customer_application_id=146225 \r\n"
					+ "and (total_episode_alert_count>0 or ep_non_episodal_alert_count>0) and status_cd in(68,69); \r\n"
					+ "\r\n"
					+ "";
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("trans_with_alerts");
				
			}
			assertions.assertEqualsWithReporting(false,captureTrnswithAlertCount==countInTable,extentReport,"Released patient is present in the page");
			
			//done no step left
			
			
			
			extentReport.info("1300 S Click on the ‘Transmissions with alerts’ link");
			recentTrnsPg.navigateTrnsWithAlertQuickLink();
			
			
			
			extentReport.info("1400 V Verify the system displays the"
					+ " Transmissions with atleast one associated alert on"
					+ " Recent Transmission page for all active and released patients enrolled in Actor’s clinic.",new String[] {"Gen2161","TransMgt8934","TransMgt16990"});

			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyActiveAndReleasedPatientInRecentTransmissionPage("patientName", "index"),extentReport,"Patient present is an active patient");
			assertions.assertEqualsWithReporting(false,recentTrnsPg.verifyActiveAndReleasedPatientInRecentTransmissionPage("patientName", "index"),extentReport,"Patient present is a Released patient");
			//based on whether release patient will be present in the page or not will be changing logic
			//done no step left
			
			
			extentReport.info("1500 S Set Tier 1 filter to ‘My Patients’.");
			recentTrnsPg.selectTireOneFilterOption("my patients");
			//done no step left

			extentReport.info("1600 V Verify the system displays"
					+ " ‘Transmissions with alerts’ link in Quick Links module"
					+ " with count of Transmissions with atleast one associated "
					+ "alert for Tier 1 filter (My Patients).",new String[] {"Gen2163"});
			recentTrnsPg.validateTrnsWithAlertQuickLink();
			captureTrnswithAlertCount=Integer.parseInt(recentTrnsPg.captureTrnswithAlertCount());
			int patientInsideRecentTrsmission=recentTrnsPg.totalPatientInsideRecentTransmissionPage();
			dataBaseConnector.getConnection();
			query ="select count(*) trans_with_alerts from transmissions.rt_cache rc where customer_application_id=146225 \r\n"
					+ "and (total_episode_alert_count>0 or ep_non_episodal_alert_count>0) and status_cd in(68,69) \r\n"
					+ "and patient_id in (SELECT\r\n"
					+ "DISTINCT capplp.patient_id AS patientId\r\n"
					+ "FROM\r\n"
					+ "patients.customer_application_patient capplp\r\n"
					+ "INNER JOIN\r\n"
					+ "patients.customer_account_patient cap\r\n"
					+ "ON capplp.customer_appl_patient_id = cap.customer_appl_patient_id\r\n"
					+ "WHERE\r\n"
					+ "capplp.customer_application_id = 146225\r\n"
					+ "AND cap.customer_account_id = 176084);\r\n"
					+ "";
			
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("trans_with_alerts");
				
			}
			
			//assertions.assertEqualsWithReporting(true,(captureTrnswithAlertCount==patientInsideRecentTrsmission),extentReport,"Transmission with alert is equal with patient alert in quick link");
			assertions.assertEqualsWithReporting(true,(captureTrnswithAlertCount==countInTable),extentReport,"Total alert count in quick link and in database is equal");
			//done no step left

			extentReport.info("1700 S Click on the ‘Transmissions with alerts’ link");
			recentTrnsPg.navigateTrnsWithAlertQuickLink();
			//done no step left

			extentReport.info("1800 V Verify the system displays the"
					+ " Transmissions with atleast one associated alert"
					+ " on Recent Transmission page for patients where actor"
					+ " has been specified as a medical team member.", new String[] {"Gen2161","TransMgt8934","TransMgt8930"});

			assertions.assertEqualsWithReporting(true,recentTrnsPg.verifyActiveAndReleasedPatientInRecentTransmissionPage("",""),extentReport,"Transmissions is associated with the alert");
			assertions.assertEqualsWithReporting(true,recentTrnsPg.ValidateMedicalTeamMemberForPatient(testName),extentReport,"Actor is belonging to medical Team");
			
			//done no step left

			appHomeTopNavPage.clickSignOutLink();
			//recentTrnsPg.selectTireOTwoFilterOption("all");
			//done no step left
			//// Quick Link - Patients with no future schedule ////
			//Clarification needed
			
			//3rd data validation

			login = testDataProvider.getLoginData("DirectAll");
			loginPage.login(login);

			extentReport.info("1900 S Ensure that there are patients without next follow-up schedule date with transmissions uploaded.");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			ca_patientListPage.selectTierOneFilterOption("My Active Patients");
			ca_patientListPage.selectTierTwoFilterOption("Patients with no future schedule");
			assertions.assertEqualsWithReporting(true, ca_patientListPage.validateNextTransmissionValue("patientname"), extentReport, "Patient has no follow up schedule date");
			//For this step we need to navigate inside patient list page while we click on patient with no future schedule and check whether next transmission is none			
			
			
			//done  no step left
			
			
		
		   	
			

			extentReport.info("2000 S Navigate to Recent Transmissions (IB001) page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();

			
			
           //done no step left
			
			extentReport.info("2100 S Set Tier 1 filter to ‘My Patients’.");
			recentTrnsPg.selectTireOneFilterOption("my patients");
			
			//done no step left

			extentReport.info("2200 V Verify the system displays"
					+ " ‘Patients with no future schedule’ link in"
					+ " Quick Links module with count of active or"
					+ " released patients not having future follow-up "
					+ "schedule and matching the Tier 1 filter on Recent "
					+ "Transmission page (My Patients) as per user visibility rule.",new String[] {"Gen2164"});

			recentTrnsPg.validateptnWithNoFutureScheduleLink();
			int ptnWithNoFutureSchedulecount=Integer.parseInt(recentTrnsPg.captureptnWithNoFutureScheduleCount());
			dataBaseConnector.getConnection();
			query ="select no_schd_patient_count from transmissions.v_clinic_patients_quick_links_cnt where customer_id=145382 and customer_application_id=146225 and user_record_id=600078";
			//int captureptnWithNoFutureScheduleInTable=recentTrnsPg.totalPatientInsideRecentTransmissionPage();
			//assertions.assertEqualsWithReporting(true,(ptnWithNoFutureSchedulecount==captureptnWithNoFutureScheduleInTable),extentReport,"Transmission with alert is equal with patient alert in quick link");
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("no_schd_patient_count");
				
			} 
			assertions.assertEqualsWithReporting(true,(ptnWithNoFutureSchedulecount==countInTable),extentReport,"Count");
			
			
			//done no step left
			
			
			
			extentReport.info("2300 S Click on the ‘Patients with no future schedule’ link");
			recentTrnsPg.navigateptnWithNoFutureScheduleLink();
			
			//done no step left

			extentReport.info("2400 V Verify the system displays Patient"
					+ " List page with tier 1 filter as “My Active Patients’"
					+ " and tier 2 filter as ‘Patients with no future schedule’."
					+ " Verify that system also lists active or released patients"
					+ " not having future follow-up schedule matching the Tier 1 and"
					+ " Tier 2 filter on Patients List. This also includes patients "
					+ "transferred from R7.0 clinic not having future schedule. ");

			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyLandingPage(),extentReport,"Landed to Patient List page");
			ca_patientListPage.validateActivePatientDropdown();
			ca_patientListPage.validateTier2filterPatientwithfuture("Patients with no future schedule");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName", "index"),extentReport,"Patient present is an active patient");
			assertions.assertEqualsWithReporting(false,ca_patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName", "index"),extentReport,"Patient present is a Released patient");
			//done no step left

		//There is currently no data where we can check active or released patient under patient list page will be utilising same method verifyPatientInTable to find a patient and check status
			//This also includes patients transferred from R7.0 clinic not having future schedule. is yet to be resolved by Rajesh


			extentReport.info("2500 S Navigate to Recent Transmissions (IB001) page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			extentReport.reportScreenShot("Recent Transmissions Link is clicked");


			extentReport.info("2600 S Set Tier 1 filter to ‘Clinic Patients’.");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");

			extentReport.info("2700 V Verify the system displays"
					+ " ‘Patients with no future schedule’ link"
					+ " in Quick Links module with count of active"
					+ " or released patients not having future follow-up "
					+ "schedule and matching the Tier 1 filter on Recent Transmission"
					+ " page (Clinic Patients) as per user visibility rule. ",new String[] {"Gen2164"});
			recentTrnsPg.validateptnWithNoFutureScheduleLink();
			ptnWithNoFutureSchedulecount=Integer.parseInt(recentTrnsPg.captureptnWithNoFutureScheduleCount());
			dataBaseConnector.getConnection();
			query="select no_schd_patient_count from transmissions.v_mypatients_quick_links_cnt "
					+ "where customer_id=145382 and "
					+ "customer_application_id=146225 and user_record_id=600078";
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("no_schd_patient_count");
				
			} 
			assertions.assertEqualsWithReporting(true,ptnWithNoFutureSchedulecount==countInTable,extentReport,"Alert b/w"
					+ "quick link count and transmission in table is equal");
			extentReport.info("2800 S Click on the ‘Patients with no future schedule’ link"); 
			recentTrnsPg.navigateptnWithNoFutureScheduleLink();

			extentReport.info("2900 V Verify the system displays Patient"
					+ " List page with tier 1 filter as “Active Clinic Patients’"
					+ " and tier 2 filter as ‘Patients with no future schedule’. "
					+ "Verify that system also lists active or released patients "
					+ "not having future follow-up schedule matching the Tier 1 "
					+ "and Tier 2 filter on Patients List. This also includes c"
					+ "patients transferred from R7.0 clinic not having future "
					+ "schedule.",new String[] {"Gen2064","Gen2068","TransMgt16775","TransMgt17394"});
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyLandingPage(),extentReport,"Landed to Patient List page");
			recentTrnsPg.validateActivePatientDropdown();
			assertions.assertEqualsWithReporting(true,ca_patientListPage.validateTier2filterPatientwithfuture("Patients with no future schedule"),extentReport,"Landed to Patient List page");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName", "index"),extentReport,"Patient present is an active patient");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyActiveAndReleasedPatientInPatientListPage("patientName", "index"),extentReport,"Patient present is a Released patient");
			
			//done no step left

			/**** Quick Link - Patients with overdue follow-up ***/
			//Data setup should be 1 patient with future schedule,1 without future schedule and 1 with overdue follow up schedule
			extentReport.info("3000 S Ensure that there are patients "
					+ "with overdue follow-up schedule for most recent"
					+ " follow-up schedule. Also ensure that there are "
					+ "few patients with and without future schedule");
          
			clinicianHomeTopNavPage.navigateToPatientListPage();
            ca_patientListPage.selectTierOneFilterOption("Active Clinic Patients");
            ca_patientListPage.selectTierTwoFilterOption("Patients with no future schedule");
            assertions.assertEqualsWithReporting(true,ca_patientListPage.validateNextTransmissionValue(""),extentReport,"Patients are present with overdue follow up");
            assertions.assertEqualsWithReporting(true,ca_patientListPage.validateNextTransmissionValue(""),extentReport,"Patients are present with future follow up");
            assertions.assertEqualsWithReporting(true,ca_patientListPage.validateNextTransmissionValue(""),extentReport,"Patients are present without future follow up");
            
            
			
			
			
			//validation pending
			extentReport.info("3100 S Navigate to Recent transmissions page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();

			extentReport.info("3200 S Set Tier 1 filter to ‘My Patients’.");
			recentTrnsPg.selectTireOneFilterOption("my patients");

			extentReport.info("3300 V Verify the system displays "
					+ "‘Patients with overdue follow-up’ link in Quick"
					+ " Links module with count of active or released "
					+ "patients with overdue follow-up schedule and "
					+ "matching the Tier 1 filter on Recent Transmission "
					+ "page (My Patients) as per user visibility rule. ", new String[] {"Gen2165"} );

			recentTrnsPg.validateptnWithOverdueFollowUp();
			int ptnWithOverduefollowupcount=Integer.parseInt(recentTrnsPg.captureptnWithOverdueFollowUpCount());
			dataBaseConnector.getConnection();
			query="select overdue_trans_count from transmissions.v_clinic_patients_quick_links_cnt "
					+ "where customer_id=145382 and customer_application_id=146225 and user_record_id=600078";
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("overdue_trans_count");
				
			} 
			assertions.assertEqualsWithReporting(true,(ptnWithOverduefollowupcount==countInTable),extentReport,"Count for active or released patient in quick link and patients in table is equal");
			//validation pending

			extentReport.info("3400 S Click on the ‘Patients with overdue follow-up’ link");
			recentTrnsPg.navigateOverDueFollowUp();

			extentReport.info("3500 V Verify the system displays Patient"
					+ " List page with tier 1 filter as “My Active Patients’"
					+ " and tier 2 filter as ‘Patients with overdue follow-up’."
					+ " Verify that system also lists active or released patients"
					+ " with overdue follow-up schedule matching the Tier 1 and Tier 2"
					+ " filter on Patients List. This also includes patients transferred"
					+ " from R7.0 clinic overdue follow-up schedule.");

			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyLandingPage(),extentReport,"Landed to Patient List page");
			//recentTrnsPg.validateActivePatientDropdown();
			assertions.assertEqualsWithReporting(true,ca_patientListPage.captureTier1FilterMyActivePatient()=="My Active Patients",extentReport,"My active filter is selected and displayed");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.captureTier2FilterPatientWithOverdueFollowUp()=="Patients with overdue follow-up",extentReport,"Patients with overdue follow-up is selected and displayed");			
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyPatientInTable("patientName"),extentReport,"Active patient is present in the Recent transmission page");
			
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyPatientStatusInPatientListTable("patientName"),extentReport,"Status of patient should be active or released");
			extentReport.info("3600 S Navigate to Recent transmissions page");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();


			extentReport.info("3700 S Set Tier 1 filter to ‘Clinic Patients’.");
			recentTrnsPg.selectTireOneFilterOption("clinic patients");


			extentReport.info("3800 V Verify the system displays ‘Patients with overdue follow-up’ link in Quick Links module with count of active or released patients with overdue follow-up schedule and matching the Tier 1 filter on Recent Transmission page (Clinic Patients) as per user visibility rule.");
			recentTrnsPg.validateptnWithOverdueFollowUp();
			ptnWithOverduefollowupcount=Integer.parseInt(recentTrnsPg.captureptnWithOverdueFollowUpCount());
			dataBaseConnector.getConnection();
			query="select overdue_trans_count from transmissions.v_mypatients_quick_links_cnt"
					+ " where customer_id=145382 and customer_application_id=146225 and"
					+ " user_record_id=600078";
			customerRecord = dataBaseConnector.executeQuery(query);
			while (customerRecord.next()) {
				countInTable = customerRecord.getInt("overdue_trans_count");
				
			} 
			assertions.assertEqualsWithReporting(true,(ptnWithOverduefollowupcount==countInTable),extentReport,"Count for active or released patient"
					+ " inside quick link is equal to recent transmission page(My Patients) inside table");

			extentReport.info("3900 S Click on the ‘Patients with overdue follow-up’ link");
			recentTrnsPg.navigateOverDueFollowUp();

			extentReport.info("4000 V Verify the system displays"
					+ " Patient List page with tier 1 filter as "
					+ "“Active Clinic Patients’ and tier 2 filter as"
					+ " ‘Patients with overdue follow-up’. Verify that"
					+ " system also lists active or released patients c"
					+ "with overdue follow-up schedule matching the Tier 1 "
					+ "and Tier 2 filter on Patients List. This also includes"
					+ " patients transferred from R7.0 clinic having overdue "
					+ "follow-up schedule.",new String[] {"Gen2162","Gen2068","TransMgt16775","TransMgt17284"});

			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyLandingPage(),extentReport,"Landed to Patient List page");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.captureTier1FilterMyActivePatient()=="My Active Patients",extentReport,"My active filter is selected and displayed");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.captureTier2FilterPatientWithOverdueFollowUp()=="Patients with overdue follow-up",extentReport,"Patients with overdue follow-up is selected and displayed");			
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyPatientStatusInPatientListTable("patientName"),extentReport,"Status of patient should be active status");
			assertions.assertEqualsWithReporting(true,ca_patientListPage.verifyPatientInTable("patientName"),extentReport,"Active patient is present in the Recent transmission page");


		}
		catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}	
	}


	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
