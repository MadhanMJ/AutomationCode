package com.test.qa.ui.tests.UC250;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_IB001_TransList_DynComp_01 extends CommonUtils {

	/*
	 * Test case name: WA-IB001-TransList-DynComp-01 Author: Rajesh Singaraj Test
	 * case ID: 1244058
	 * 
	 */
	LoginPageWithPOJO loginPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	Login login;
	TestDataProvider testDataProvider;
	CA_RecentTransmissionsPage recentTrnsPg;
	private String testName;
	private Log logger = new Log();
	Customer customer;

	@BeforeMethod
	public void initialize() {
		extentReport = new ExtentReport(driver, extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);		
		login = new Login();
		testDataProvider = new TestDataProvider();
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		recentTrnsPg = new CA_RecentTransmissionsPage(driver, extentReport);
		customer = new Customer();
	}

	@Test
	public void WA_IB001_TransList_DynComp_01() throws Exception {	
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		
		login = testDataProvider.getLoginData("physicianUser1");
		customer = testDataProvider.getCustomerData("WA_IB001_TransList_DynComp_01");
		extentTest.assignAuthor("Author: Rajesh Singaraj");
		try {
			Assertions assertions = new Assertions(extentTest);
			
			// Limited User
			extentReport.info("100 S - Login to the database and view the website_notification table for the following fields, "
							+ "‘status_code’ field for the newly arrived 2 transmissions for patient A.");
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(1,false, 68);
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(1,false, 68);
			extentReport.info("200 V – Ensure the status code for the transmissions is ‘New’");
			

			extentReport.info("300 S - Login as Limited user to the EP Application and navigate to IB001.");
			loginPage.login(login);
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");			
			assertions.assertEqualsWithReporting(recentTrnsPg.verifyLandingPage(), true, extentReport,"Recent Transmission tab should be displayed");

			extentReport.info("400 S - Click on the link in the Transmission column for the transmission.");
			recentTrnsPg.selectTier1FilterValueFromDropdown();
			recentTrnsPg.searchPatient(customer.getPatientNames(),1);
			recentTrnsPg.clickOnElement("TransmissionColumn");
			recentTrnsPg.clickOnElement("FirstTransmission");

			extentReport.info("500 V – Verify that the Transmission page is displayed showing applicable transmission reports, merged report (if selected in clinic report setting), text summary report and available episode & EGM reports for the transmission.",new String[] {"TransMgt4040","ClncAcct6089","ClncAcct6089","ClncAcct6089","ClncAcct6089"});
			recentTrnsPg.verifyElement("AllTransmissionReports");
			

			extentReport.info("600 S - Click on any of the links from the left navigation panel");
			recentTrnsPg.clickOnElement("EpisodesAndEGM");
			

			extentReport.info("700 S – Click on Recent Transmission tab and return to IB001.");
			recentTrnsPg.clickOnElement("RecentTrnsTab");
			
			
			extentReport.info("800 V – Verify that the selected transmission is not marked as viewed. This is indicated by the unopened envelop symbol in the beginning of the transmission row",new String[] {"TransMgt4041"});
			recentTrnsPg.verifyElement("MarkUnread");
			

			extentReport.info("900 S – Select another transmission and click on the print button ");
			recentTrnsPg.clickOnElement("SecondTransmission");
			recentTrnsPg.clickOnElement("TransmissonPrint");
			
			extentReport.info("1000 S – Ensure that the print transmission dialog is displayed");
			recentTrnsPg.verifyElement("PrintTransmission");
			
			extentReport.info("1100 S – Close the displayed dialog and return to IB001");
			recentTrnsPg.clickOnElement("TransmissonCancel");
			
			extentReport.info("1200 V – Verify that the selected transmission is not marked as viewed. This is indicated by the unopened envelop symbol in the beginning of the transmission row ",new String[] {"TransMgt4041","<TransMgt3965"});
			recentTrnsPg.clickOnElement("RecentTrnsTab");
			recentTrnsPg.verifyElement("MarkUnread");			

			extentReport.info("1300 S - Login to the db and view the ‘status_code’ field and ‘last_viewed_by’ fields in the website_notification table");
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(1,false, 68);
			extentReport.info("1400 V - Verify the status code is not changed and remains as ‘New’ and the last viewed by field is blank in database.",new String[] {"TransMgt4041","<TransMgt3965"});			
			
			
			recentTrnsPg.clickOnElement("SignOut");
			
			//physician
			extentReport.info("1800 S - Repeat steps 100 and 200");
			extentReport.info("100 S - Login to the database and view the website_notification table for the following fields, "
					+ "‘status_code’ field for the newly arrived 2 transmissions for patient A.");
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(1,false, 68);
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(1,false, 68);
			extentReport.info("200 V – Ensure the status code for the transmissions is ‘New’");
	

			extentReport.info("1900 S - Login as Physician to the EP Application and navigate to IB001.");
			loginPage.login(login);
			clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission");
			extentReport.reportScreenShot("User is able to successfully navigate to Recent Transmission page");
			assertions.assertEqualsWithReporting(recentTrnsPg.verifyLandingPage(), true, extentReport,
					"Recent Transmission tab should be displayed");
					
			extentReport.info("2000 S - Repeat steps 400 to 700");
			extentReport.info("400 S - Click on the link in the Transmission column for the transmission.");
			recentTrnsPg.selectTier1FilterValueFromDropdown();
			recentTrnsPg.searchPatient(customer.getPatientNames(),1);
			recentTrnsPg.clickOnElement("TransmissionColumn");
			recentTrnsPg.clickOnElement("FirstTransmission");

			extentReport.info("500 V – Verify that the Transmission page is displayed showing applicable transmission reports, merged report (if selected in clinic report setting), text summary report and available episode & EGM reports for the transmission.",new String[] {"TransMgt4040","ClncAcct6089","ClncAcct6089","ClncAcct6089","ClncAcct6089"});
			recentTrnsPg.verifyElement("AllTransmissionReports");
			extentReport.reportScreenShot("Transmission page is displayed showing applicable transmission reports");

			extentReport.info("600 S - Click on any of the links from the left navigation panel");
			recentTrnsPg.clickOnElement("EpisodesAndEGM");
			

			extentReport.info("700 S – Click on Recent Transmission tab and return to IB001.");
			recentTrnsPg.clickOnElement("RecentTrnsTab");

			extentReport.info("2100 V – Verify that the selected transmission is marked as viewed. This is indicated by the opened envelop symbol in the beginning of the transmission row (Viewed Field)",new String[] {"TransMgt4041"});			
			recentTrnsPg.verifyElement("MarkUnread");

			extentReport.info("2200 S – Repeat steps 900 to 1100");
			extentReport.info("900 S – Select another transmission and click on the print button ");
			recentTrnsPg.clickOnElement("SecondTransmission");
			recentTrnsPg.clickOnElement("TransmissonPrint");
			
			extentReport.info("1000 S – Ensure that the print transmission dialog is displayed");
			recentTrnsPg.verifyElement("PrintTransmission");
			
			extentReport.info("1100 S – Close the displayed dialog and return to IB001");
			recentTrnsPg.clickOnElement("TransmissonCancel");
			
			extentReport.info("2300 V – Verify that the selected transmission is marked as viewed. This is indicated by the opened envelop symbol in the beginning of the transmission row",new String[] {"TransMgt4041","<TransMgt3965"});
			recentTrnsPg.clickOnElement("RecentTrnsTab");
			recentTrnsPg.verifyElement("MarkUnread");
			
			extentReport.info("2400 S - Login to the db and view the ‘status_code’ field and ‘last_viewed_by’ fields in the website_notification table");
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(2,false, 68);
			extentReport.info("2500 V - Verify the ‘status_code’ is changed to ‘Viewed’ and the user name is added to the ‘last_viewed_by’ field.",new String[] {"TransMgt4041","<TransMgt3965"});
			

			recentTrnsPg.clickOnElement("SecondTransmission");
			
			extentReport.info("2600 S - The actor Select the same transmissions viewed earlier and archive the transmission.");
			recentTrnsPg.clickOnElement("Archive");
			
			extentReport.info("2800 S - Login to the db and view the ‘status_code’ field and ‘last_viewed_by’ fields in the website_notification table");
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(1,false, 68);
			recentTrnsPg.verifyStatusCodeAndLastViewForRecentTransmission(2,false, 68);
			extentReport.info("2900 V - Verify the status code is changed to ‘Completed’ and the last viewed by filed is populated with the user name for both the transmissions",new String[] {"TransMgt4041","<TransMgt3965"});
			
			recentTrnsPg.clickOnElement("SignOut");

		} catch (AssertionError e) {
			extentReport.fail("WA_IB001_TransList_DynComp_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail("WA_IB001_TransList_DynComp_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}
}
