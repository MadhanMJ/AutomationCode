package com.test.qa.ui.tests.UC041B;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.AlliedndPhyscianTopNav;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.My_Account_Page;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class WA_MA100_MyAccount_DynamicComponents02 extends CommonUtils 
{
	ClinicianHomePage clinicianHomePage;
	CA_RecentTransmissionsPage recenttrasmissionpage;
	ClinicianHomeTopNavPage clinicianhometopnavpage;
	PatientListPage patientlistpage;
	
	LoginPageWithPOJO loginPage;
	Login Clinic_User;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	My_Account_Page myaccountpage;
	AlliedndPhyscianTopNav alliedndphysciantopnav;
	
	@BeforeClass
	public void initialize() 
	{
         clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		recenttrasmissionpage=new CA_RecentTransmissionsPage(driver, extentReport);
		clinicianhometopnavpage=new ClinicianHomeTopNavPage(driver, extentReport);
		patientlistpage=new PatientListPage(driver, extentReport);
		myaccountpage=new My_Account_Page(driver, extentReport);
		alliedndphysciantopnav=new AlliedndPhyscianTopNav(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		Clinic_User = new Login();
		testDataProvider = new TestDataProvider();
	}
	
  @Test
  public void TC_WA_MA100_MyAccount_DynamicComponents02() 
  {
	   testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);
		
		Clinic_User = testDataProvider.getLoginData("Allied1");
		
		
		extentTest.assignAuthor("Author: Kundan Kumar");
    try {
			
			extentReport.info("100-S- The Actor navigates to My Account Page.");
			loginPage.login(Clinic_User,"externaluser");
			alliedndphysciantopnav.navigateToManageAccountPage();
			
			extentReport.info("200-V- Verify that the My Account Page is displayed in View mode.",new String[] {"ClncnMgt14767,CommUI8620"});
            myaccountpage.verifyMyAccountPageinDisplayMode();
            
            extentReport.info("300-S- The Actor clicks the Edit button on the page");
            myaccountpage.navigateToEditManageAccount();

            extentReport.info("400 V Verify that following fields are displayed:");
            myaccountpage.verifyRecentTrasmissionPrefrenceColumn();
            
            extentReport.info("1.Sorting preference for the Recent Transmissions column");
            myaccountpage.verifyRecentTrasmissionPrefrenceColumn();
            
            extentReport.info("2.Application Preference - displayed only if the user's clinic has access to both, EP and HF applications.",new String[] {"ClncnMgt12594,ClncnMgt15039"});
            myaccountpage.verifyApplicationPrefrenceColumn();
            //Need to confirm this setting clinic has access to both, EP and HF applications
            
            extentReport.info("450 V Verify that Default values for Recent Transmissions Sort Options is Direct Alerts.",new String[] {"CommFn789,CommUI4587"});
            myaccountpage.navigateToEditManageAccount();
            myaccountpage.verifyDirectAlertCheckBoxIsselctedDefualt();
            
		    extentReport.info("500 S Change the option for sorting the Recent Transmissions column to Patient Name.");
            myaccountpage.selectPatientListCheckBox();
            
		    extentReport.info("600 V Verify that the system saves the value and message CP803 is displayed.",new String[] {"ClncnMgt14765,ClncnMgt15008,ClncnMgt15015"});
            myaccountpage.VerifySuccessMessage();
           
		    extentReport.info("700 V Verify that the changed made are applied on to the Recent Transmissions page.",new String[] {"ClncnMgt14765,ClncnMgt15008"});
		    recenttrasmissionpage.navigateToRecentTransmissionPage();
		    //Need to discuss how to check in recent transmisson tabVerifySuccessMessage()
		    
            extentReport.info("800 S Repeat steps 500-700 for sorting the Recent Transmissions column set to Alerts, Clinic Location and Trasmission time and date");
            alliedndphysciantopnav.navigateToManageAccountPage();
            myaccountpage.navigateToEditManageAccount();
            myaccountpage.selectClinicLocationCheckBox();
            
            alliedndphysciantopnav.navigateToManageAccountPage();
            myaccountpage.navigateToEditManageAccount();
            myaccountpage.selectTransmissionDataCheckBox();
            
            extentReport.info(" 1300 S Navigate back to My  Account Page in Edit mode and set the Application Preference to HF.");
            myaccountpage.navigateToEditManageAccount();
            myaccountpage.selectHeartFailureCheckBox();
            
            extentReport.info(" 1350 V Verify that the message CP 803 is displayed <>",new String[] {"ClncnMgt15015"});
            myaccountpage.VerifySuccessMessage();
         
            extentReport.info(" 1400 S Log out and login to the clinic");
            alliedndphysciantopnav.clickSignoutLink();
            loginPage.login(Clinic_User,"externaluser");
            
            extentReport.info("1500 V Verify that the user is directly navigated to the HF page.",new String[] {"ClncnMgt14765,ClncnMgt15008"});
		    //Need to check what is HF page.No Need to automate HF steps
            
            extentReport.info("1600 S Navigate back to My  Account Page in Edit mode and set the Application Preference to EP.");
            alliedndphysciantopnav.navigateToManageAccountPage();
            myaccountpage.navigateToEditManageAccount();
            myaccountpage.selectElectrophysiologyCheckBox();
            
            extentReport.info("1650 V Verify that the message CP 803 is displayed",new String[] {"ClncnMgt15015"});
            myaccountpage.VerifySuccessMessage();
            
            extentReport.info("1700 S Log out and login to the clinic");
            alliedndphysciantopnav.clickSignoutLink();
            loginPage.login(Clinic_User,"externaluser");
            
            extentReport.info("1800 V Verify that the user is directly navigated to the EP page.",new String[] {"ClncnMgt14765,ClncnMgt15008,CommFn460"});
            //Need to check what needs to verify that will confirm EP page?
            
            extentReport.info("1900 S Navigate back to My  Account Page in Edit mode and click on the change password link.");
            alliedndphysciantopnav.navigateToManageAccountPage();
            myaccountpage.navigateToEditManageAccount();
             myaccountpage.clickOnChangePassword();
            
            extentReport.info("2000 V Verify that the user is direct to Change Password page where the user can provide the new password for the clinic<>",new String[] {"ClncnMgt15014"});
             myaccountpage.verifyChangePassword_Page();
            
		    extentReport.info("2100 S Create new password and login to the clinic.");
		    //Need to discuss with alok from value will be passed
		     myaccountpage.changePassword(testName, testName, testName);
		    alliedndphysciantopnav.clickSignoutLink();
            loginPage.login(Clinic_User,"externaluser");
		    
            extentReport.info("2200 V Verify that the actor is navigated directly to the EP Application page",new String[] {"ClncnMgt14765,ClncnMgt15008,CommFn460"});
            
	 
	 }
	 

catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

/*	@AfterMethod
public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
	String status = null;
	String testMethodName = result.getMethod().getMethodName();
	 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
		 status = "Failure";
	    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
	    	status = "Success";
	    } 
	
	writeInTextFile(testMethodName, status);
}*/

  }
}


