package com.test.qa.ui.tests.UC070AUC070B;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.AddCustomerPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.ChangeCustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerProfilePage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicLocationsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicProfilePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_ClinicUsers;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_LeftNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.topNav.AppHomeTopNavPage;
import com.test.qa.utilities.CommonUtils;

public class WA_96_UC070_Activator_ClinicAdmin_01 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	AddCustomerPage addCustomerPage;
	ChangeCustomerProfilePage changeCustomerProfilePage;
	CustomerProfilePage customerProfilePage;
	CustomerListPage customerListPage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	DataBaseConnector dataBaseConnector;
	CA_LeftNavPage ca_LeftNavPage;
	AppHomeTopNavPage appHomeTopNavPage;
	private Assertions softAssert;
	ExtentTest extentTest;
	Login login;
	Customer customer;
	Boolean customerUpdateCheck;
	TestDataProvider testDataProvider;
	CA_ClinicProfilePage clinicProfilePage;
	CA_ClinicUsers clinicUsers;
	CA_ClinicLocationsPage cliniclocation;
	
	private String testName;
	private Log logger = new Log();
	
	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		customerProfilePage = new CustomerProfilePage(driver, extentReport);
		changeCustomerProfilePage = new ChangeCustomerProfilePage(driver,extentReport);
		login = new Login();
		addCustomerPage = new AddCustomerPage(driver, extentReport);
		testDataProvider = new TestDataProvider();
		customer = new Customer();
		dataBaseConnector = new DataBaseConnector();
		clinicianHomeTopNavPage=new ClinicianHomeTopNavPage(driver, extentReport);
		ca_LeftNavPage=new CA_LeftNavPage(driver, extentReport);
		appHomeTopNavPage=new AppHomeTopNavPage(driver, extentReport);
		clinicProfilePage=new CA_ClinicProfilePage(driver, extentReport);
		clinicUsers=new CA_ClinicUsers(driver, extentReport);
	}
	
	@Test
	public void rev_WA_96_UC070_Activator_ClinicAdmin_01() throws Exception{
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		extentTest = extentReport.initiateTest(testName);
		login = testDataProvider.getLoginData("ActivatorWithAdmin");
		extentTest.assignAuthor("Author - Abhishek kumar");
		try {
			softAssert = new Assertions(extentTest);
			extentReport.info("100 S Login to an Activator clinic with user having admin rights");
			loginPage.login(login, " externaluser");
			
			extentReport.info("200 V Verify that only following primary navigation tabs are displayed. Other tabs are not displayed"
			+"<br/>"+"a. Patient List"+"<br/>"+"b. Clinic Administration" , new String[] {"CommUI10093"});
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyTopNavPageTabForActivaterClc("Patient List"),true,extentReport,"Patient List tab is displayed");
			extentReport.reportScreenShot("Patient List tab is displayed");
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyTopNavPageTabForActivaterClc("Clinic Administration"),true,extentReport,"Clinic Administration tab is displayed");
			extentReport.reportScreenShot("Clinic Administration tab is displayed");
			
			
			
			extentReport.info("300 S Navigate to Clinic Admin tab");
			clinicianHomeTopNavPage.navigateToClinicAdministrationForActivatorPage();
			extentReport.reportScreenShot("Clicked Clinic Administration Link");
			
			extentReport.info("400 V Verify that only following pages are displayed in left navigation panel"+"<br/>"+
			" a. Clinic Profile  displayed as default page"+"<br/>"+"b. Clinic Users"+"<br/>"+"c. Clinic Locations");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("clinicprofilepagelink"),true,extentReport,"Clinic profile tab should be displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("clinicuserlink"),true,extentReport,"Clinic profile tab should be displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("cliniclocationslink"),true,extentReport,"Clinic profile tab should be displayed");
			
			//checkbox is yet not developed in d2
			extentReport.info("500 V On Clinic profile page, verify that 'Include unencrypted patient info in direct alert emails and text messages' checkbox is not displayed (Negative test)", new String[] {"ClncMgt32127"});
			assertion.assertEqualsWithReporting(clinicProfilePage.verifyUnencryptedPatientInformationCheckBoxPresence(),false,extentReport,"'Include unencrypted patient info in direct alert emails and text messages' checkbox is not displayed (Negative test)");
			
			extentReport.info("600 S Click on Clinic User page");
			ca_LeftNavPage.clinicUserPage();
			
			extentReport.info("700 V Verify that Clinic User page is displayed", new String[] {"ClncMgt32051"});
			assertion.assertEqualsWithReporting(clinicUsers.verifyLandingPage(),true, extentReport, "Clinic User page is displayed");
			
			
			
			
			extentReport.info("800 S Click on Clinic Location page");
			ca_LeftNavPage.navigateToClinicLocationsPage();
			
			
			
			extentReport.info("900 V Verify that Clinic Location page is displayed",new String[] {"ClncMgt32051"});
			//assertion.assertEqualsWithReporting(cliniclocation.verifyLandingPage(),true,extentReport,"Clinic Location page is displayed");
			appHomeTopNavPage.clickSignOutLink();
			
			login = testDataProvider.getLoginData("ActivatorWithoutAdmin");
			
			extentReport.info("1000 S Logout from current user and login with user not having admin rights");
			
			loginPage.login(login, " externaluser");
			
			
			extentReport.info("1100 V Verify that only following primary navigation tabs are displayed. Other tabs are not displayed"+"<br/>"+"a. Patient List",new String[] {"CommUI10093"});
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyPatientTabActivatorWithoutAdmin("Patient List"),true,extentReport,"Patient List tab should be displayed");
			extentReport.reportScreenShot("Patient List page is getting displayed");
			
			extentReport.info("1200 S Logout from current user and login with user of regular clinic having admin rights");
			appHomeTopNavPage.clickSignOutLink();
			
			
			extentReport.info("1300 V Verify that only following primary navigation tabs are displayed."+"<br/>"+"a. Recent Transmission"+"<br/>"+
					 "b. Patient List"+"<br/>"+"c. Tools"+"<br/>"+" d. Clinic Administration"+"<br/>"+"e. Communication Center");
			
			login = testDataProvider.getLoginData("RegularClinic");
			loginPage.login(login, " externaluser");
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyTopNavPageTab("Recent Transmission"),true,extentReport,"Recent Transmission tab should be displayed");
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyTopNavPageTab("Patient List"), true, extentReport,"Patient List tab should be displayed");
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyTopNavPageTab("Tools"), true, extentReport,"Tools tab should be displayed");
			assertion.assertEqualsWithReporting(clinicianHomeTopNavPage.verifyTopNavPageTab("Clinic Administration"), true, extentReport,"Clinic Administration tab should be displayed");
			
			
			extentReport.info("1400 S Navigate to Clinic Admin tab");
			clinicianHomeTopNavPage.navigateToClinicAdministrationPage();
			
			
			extentReport.reportScreenShot("Clicked Clinic Administration Link");
			
			
			extentReport.info("1500 V Verify that only following pages are displayed in left navigation pan"+"<br/>"+"a. Clinic Profile displayed as default page"
			+"<br/>"+"b. Scheduling & Messaging page"+"<br/>"+"c. Clinic Hours / Holidays"+"<br/>"+" d. Direct Alert settings"+
					"<br/>"+" e. Clinic Settings"+"<br/>"+" f. Clinic Users"+"<br/>"+"g. Clinic Locations");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("clinicprofilepagelink"),true,extentReport,"Clinic profile link should be displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("SchedulingandMessagingLinkinLeftNav"),true,extentReport,"Scheduling and Messaging link is displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("clinichoursholidays"),true,extentReport,"Clinic hours and holiday link is displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("DirectAlertsSettings"),true,extentReport,"Direct Alert Settings link is displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("clinicsettinglink"),true,extentReport,"Direct Alert Settings link is displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("clinicuserlink"),true,extentReport,"Clinic user link is displayed");
			assertion.assertEqualsWithReporting(ca_LeftNavPage.verifyLeftTabLink("cliniclocationslink"),true,extentReport,"Clinic location link is displayed");
			
			
			extentReport.info("1600 V On Clinic profile page, verify that 'Include unencrypted patient info in direct alert emails and text messages' checkbox is displayed and can be edited",new String[] {"ClncMgt32127"});
			assertion.assertEqualsWithReporting(clinicProfilePage.verifyUnencryptedPatientInformationCheckBoxPresence(),true,extentReport,"Include unencrypted patient info in direct alert emails and text messages' checkbox is displayed and can be edited");
			
			
			
			
	      		
	}
		catch (AssertionError e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to assertion failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			extentReport.fail( "Rev1_WA_UC013B_B01_01 is failed due to some exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			e.printStackTrace();
			throw e;
		}		

}

	
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws Exception {
          customerListPage.verifyLogout();	
          saintResult(result,extentTest);
		
	}
		/*String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}*/
}
