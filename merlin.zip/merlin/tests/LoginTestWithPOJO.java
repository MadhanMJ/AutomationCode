package com.test.qa.ui.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.pojo.Customer;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.CustomerListPage;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.utilities.CommonUtils;

public class LoginTestWithPOJO extends CommonUtils {

	LoginPageWithPOJO loginPage;
	Login login;
	Customer customer;
	CustomerListPage customerListPage;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	@BeforeClass
	public void initialize() {
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		customerListPage = new CustomerListPage(driver, extentReport);
		login = new Login();
		customer  =  new Customer();
		testDataProvider = new TestDataProvider();
	}

	@Test
	public void loginOfPCSAdmin() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;
		
		login = testDataProvider.getLoginData("SJMAdmin");
		customer = testDataProvider.getCustomerData("AddCustomer");
		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;
		extentTest.assignAuthor("Gowshalyadevi Rathinam");

		try {
			Assertions assertion =  new Assertions(extentTest);
			extentReport.info("User is Logging into the application",new String[]{"clncacnt1","clncacnt2"});
			loginPage.login(login);
			extentTest = extentReport.info("Customer List page verification");
			Boolean loginCheck = customerListPage.verifyLandingPage();
			assertion.assertEqualsWithReporting(loginCheck, true,extentReport,"Customer List page is displayed successfully");
			extentTest = extentReport.info("Logging out from the application");
			customerListPage.verifyLogout();
		} catch (AssertionError e) {
			extentReport.reportFail("Login functionality not successfully verified for PCS Admin ");
			throw e;
		} catch (Exception e) {
			extentReport.reportFail( "Login functionality not successfully verified for PCS Admin ");
			throw e;
		}
	}

	@AfterMethod
	public void createEvidenceAndResult(ITestResult result, Method currentMethod) throws IOException {
		String status = null;
		String testMethodName = result.getMethod().getMethodName();

		if (result.getStatus() == ITestResult.SUCCESS) {
			status = "Success";
		} else if (result.getStatus() == ITestResult.FAILURE) {
			status = "Failure";
		}
		writeInTextFile(testMethodName, status);
	}

}
