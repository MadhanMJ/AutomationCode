package com.test.qa.ui.tests.UC006_UC007A_UC007B;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class R11_5_WA_EP_ICM_EpisodeWindow_AssessmentType_01 extends CommonUtils{


	Assertions assetions;
	Login loginClinicUser_withAllDevice;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;

	Login loginAP;
	Login loginPhy;
	Login loginLimited;
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PL_AllTransmissionsPage allTransmissionPage;
	PL_TransmissionPage transmissionPage;
	PL_Transmission_EpisodeAndEgmPage episodesAndEGMPage;
	PatientListPage patientListPage;
	List<Date> latestTransDate;
	List<Date> comparedDate;
	SimpleDateFormat df;
	private String DATE_FORMAT;
	String timestamp;

	@BeforeClass
	public void initialize() {
		testDataProvider = new TestDataProvider();
		loginAP = new Login();
		loginPhy = new Login();
		loginLimited = new Login();
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		clinicianHomePage = new ClinicianHomePage(driver, extentReport);
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver, extentReport);
		allTransmissionPage = new PL_AllTransmissionsPage(driver, extentReport);
		transmissionPage = new PL_TransmissionPage(driver, extentReport);
		patientListPage = new PatientListPage(driver, extentReport);
		episodesAndEGMPage = new PL_Transmission_EpisodeAndEgmPage(driver, extentReport);
		latestTransDate = new ArrayList<Date>();
		comparedDate = new ArrayList<Date>();
		DATE_FORMAT = "MM/dd/yyyy";
		df = new SimpleDateFormat(DATE_FORMAT);
		timestamp = "";
	}

	@Test
	public void ICM_EpisodeWindow_AssessmentType_01() {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;

		extentTest = extentReport.initiateTest(testName);

		loginPhy = testDataProvider.getLoginData("WA_ICM_EpisodeDirectory_Tier1Filter_03_DPhy");
		// loginAP = testDataProvider.getLoginData("");
		// loginLimited = testDataProvider.getLoginData("");

		extentTest.assignAuthor("Author: Vrushali Barhate");
		try {
			assertion = new Assertions(extentTest);

			extentReport.info("100 S Login to clinic A as Physician. Navigate to Patient list. Select Patient1, go to Transmissions tab");
			loginPage.login(loginPhy, "externaluser");
			assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport,
					"Clinician Home Landing page is displayed");
			clinicianHomeTopNavPage.navigateToPatientListPage();
			assertion.assertEqualsWithReporting(true, patientListPage.verifyLandingPage(), extentReport,
					"Patient List page is displayed");
			patientListPage.selectTierOneFilterOption("Active Clinic Patients");
			patientListPage.selectTierTwoFilterOption("Cardiac Monitor");
			patientListPage.clickOnPatientNameFrmList("0509 Transcheck");
			patientListPage.navigateToTranmissionTab();
			
			extentReport.info("200 S Go to Episodes and EGMs tab, select checkbox of one episode with EGM and go to More actions then select ‘View Episode’ option.");
			transmissionPage.clickOnEpisodeEGMsLink();
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.verifyLandingPage(), extentReport,
					"Episodes and EGM page is displayed");
			episodesAndEGMPage.selectEpisodeAndEGMChBx("Timestamp");
			episodesAndEGMPage.selectFromMoreActions("View Episodes");
			
			extentReport.info("300 V On Episode Viewer window, verify that user can assign assessment type to selected Episode."
					, new String[] {"TransMgt18712, TransMgt18607"});
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.assignAssessmentAndNotesAndSave("Test Note", "Not Assessed"), extentReport, "Assessment and Notes saved Successfully");
			
			extentReport.info("400 S Close the episode viewer window and on Episode and EGM page, click on date and time of an episode.");
			episodesAndEGMPage.clickAssessmentDialogCloseBtn();
			episodesAndEGMPage.clickonEpisodeTimestamp("timestamp"); // timestamp needs to be provided
			
			extentReport.info("500 V On Episode Viewer window, verify that user can assign assessment type to selected Episode."
					, new String[] {"TransMgt18712, TransMgt18607"});
			assertion.assertEqualsWithReporting(true, episodesAndEGMPage.assignAssessmentAndNotesAndSave("Test Note2", "Not Sure"), extentReport, "Assessment and Notes saved Successfully");
			//need to add validation for assessment is successfully saved. Open Bug - PCN00031392
			
			extentReport.info("600 S Close the episode viewer window and on Episode and EGM page, click on EGM icon.");
			episodesAndEGMPage.clickAssessmentDialogCloseBtn();
			
		} catch (AssertionError e) {
			e.printStackTrace();
			extentReport.reportFail(e.getMessage());
			throw new AssertionError();
		} catch (Exception e) {
			e.printStackTrace();
			extentReport.reportFail(e.toString().split(System.lineSeparator(), 2)[1]);
			throw new AssertionError(e.toString().split(System.lineSeparator(), 2)[1]);
		}
}
	


}
