package com.test.qa.ui.tests.UC006_UC007A_UC007B;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.pojo.EpisodeAdjudication;
import com.test.qa.pojo.Login;
import com.test.qa.pojo.Patient;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_AllTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_Transmission_EpisodeAndEgmPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;
import com.test.qa.utilities.QueryResults;

public class WA_EP_ICM_EpisodeWindow_AssessmentNote_06 extends CommonUtils {
	
	LoginPageWithPOJO loginPage;
	ClinicianHomePage clinicianHomePage;
	ClinicianHomeTopNavPage clinicianHomeTopNavPage;
	PatientListPage patientListPage;
	PL_TransmissionPage pl_TransmissionPage;
	PL_AllTransmissionsPage pl_AllTransmissionPage;
	CA_RecentTransmissionsPage ca_RecentTransmissionsPage;
	PL_TopNavPage pl_TopNavPage;
	ExtentTest extentTest;
	Login login;
	TestDataProvider testDataProvider;
	Assertions assertion;
	Log logger;
	CommonUtils utils;
	String testName;
	ArrayList<Date> transDateValue;
	Patient patient;
	PL_Transmission_EpisodeAndEgmPage pl_Transmission_EpisodeAndEgmPage;
	String notes, mouseHoverNotes;
	QueryResults queryResults;
	Map<String, String> databaseResults;
	EpisodeAdjudication episodeAdjudication;
	
	@BeforeMethod(alwaysRun=true)
	public void initialize() {
		clinicianHomePage =new ClinicianHomePage(driver,extentReport);	
		clinicianHomeTopNavPage = new ClinicianHomeTopNavPage(driver,extentReport);
		patientListPage = new PatientListPage(driver,extentReport);
		pl_TransmissionPage = new PL_TransmissionPage(driver,extentReport);
		pl_AllTransmissionPage = new PL_AllTransmissionsPage(driver,extentReport);
		pl_TopNavPage = new PL_TopNavPage(driver,extentReport);
		extentReport = new ExtentReport(driver,extentReport);
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		ca_RecentTransmissionsPage = new CA_RecentTransmissionsPage(driver,extentReport);
		pl_Transmission_EpisodeAndEgmPage = new PL_Transmission_EpisodeAndEgmPage(driver,extentReport);
		login = new Login();
		patient = new Patient();
		
		logger = new Log();
		testDataProvider = new TestDataProvider();
		utils= new CommonUtils();
		transDateValue = new ArrayList<Date>();
		episodeAdjudication = new EpisodeAdjudication();
	}
	
	@Test
	public void WA_EP_ICM_EpisodeWindow_AssessmentNote_06() throws Exception {
		testName = CommonUtils.getTestName();
		CommonUtils.currentTestCaseName = testName;		
		extentTest = extentReport.initiateTest(testName);
		CommonUtils.extentTest = extentTest;

		
		login = testDataProvider.getLoginData("TC1238456_SP2Clinic");
		patient = testDataProvider.getSearchPatientData(testName+"_Scenario1");
		extentTest.assignAuthor("Author: Shanmugapriya");
		
		try {
			assertion =  new Assertions(extentTest);

			//Logging in with Allied professional user and navigating to Transmissions tab
			extentReport.info("100 S Login to clinic A as Allied Professional User. Navigate to RT page. "
					+ "Select date time transmission link of Patient1 which navigates to Transmissions tab.");
			loginPage.login(login,"externaluser");
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");	
			
			//Adding assessment notes for 'Not Assessed' episode with less than 120 char
			extentReport.info("200 S Go to Episodes and EGMs tab, select checkbox of Episode with EGM having "
					+ "Assessment type as ‘Not Assessed' and go to More actions then select ‘View Episode’ option. "
					+ "On Episode Viewer window, add assessment note less than 120 characters.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			pl_Transmission_EpisodeAndEgmPage.deselectAssessmentType();
			pl_Transmission_EpisodeAndEgmPage.selectAssessmentType("NotAssessed");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("Checkbox");
			pl_Transmission_EpisodeAndEgmPage.clickOnMoreActions();
			pl_Transmission_EpisodeAndEgmPage.navigateToViewEpisodeOption();
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(119); 
			
			//Validating assessment notes char limit restriction to 120 chars
			extentReport.info("300 V On Episode Viewer window, verify that user can add assessment note up to 120 characters "
					+ "to selected Episode.", new String[] {"TransMgt18693","Config23515"});
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(121);
			notes = pl_Transmission_EpisodeAndEgmPage.validateAssessmentNotes();
			assertion.assertEqualsWithReporting(120,notes.length(),extentReport,"User is able to add assessment notes till 120 char");
			
			//Clicking save button
			extentReport.info("400 S Select save button.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeViewerSaveButton();
			
			//Validating the episode viewer window to be in read only mode
			extentReport.info("500 V Verify Episode Viewer window is display in view mode.", new String[] {"CommUI7681"});
			//Need to check
			
			//Closing the window and mouse hover on Assessment type icon
			extentReport.info("600 S Close the episode viewer window and on Episode and EGM page, hover on Assessment icon.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeAndEgmPdfCloseButton();
			mouseHoverNotes = pl_Transmission_EpisodeAndEgmPage.mouseHoverAssessmentType();
			

			//Validating whether mouse hover is disabled for Not assesses episode
			extentReport.info("700 V Verify that hover is disabled for Not Assessed episode.", new String[] {"TransMgt18693","TransMgt18846"});
			//defect
			assertion.assertEquals(mouseHoverNotes, "", "Added notes is matching with the notes present on mousehover");
			
			//Downloading the spreadsheet
			extentReport.info("800 S On Episode and EGM page, go to More Action then select Download Spreadsheet.");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("Checkbox");
			pl_Transmission_EpisodeAndEgmPage.clickOnMoreActions();
			pl_Transmission_EpisodeAndEgmPage.clickOnDownloadSpreadSheet();
			
			//Validation of downloaded spreadsheet
			extentReport.info("900 V Verify that in download spreadsheet, Added Note with User ID and Date time is display under Note column.",new String[] {"TransMgt18693"});
			String path=System.getProperty("user.dir")+"\\Downloads\\"+patientListPage.getLatestDownloadedFile(System.getProperty("user.dir")+"\\Downloads\\");
			episodeAdjudication = testDataProvider.getEpisodeAdjudicationData(path);
			assertion.assertEquals(episodeAdjudication.getLastAccessedBy(),login.getUserName(),"Adjudication type cd is matching with expected value."); 
			assertion.assertEquals(episodeAdjudication.getLastAccessedOn(),CommonUtils.currentDate(),"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getNotes(),mouseHoverNotes,"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getAssessment(),"Not Assessed","Adjudication type cd is matching with expected value.");
			
			//DB validations for the same updated episode
			extentReport.info("1000 V Verify for the above episode,\n"
					+ "• the Adjudication_Type_Cd='2613' or Null\n"
					+ "• UserID of the clinician in the Adjudication_by_userid column\n"
					+ "• Date and time of Adjudication in the Adjudication_DTM and\n"
					+ "• Assessment Note in the Episode_Note column in the Episode_Adjudication table. ", new String[] {"TransMgt18693"});
			
			String query = "select top 1 ea.adjudication_type_cd,ea.adjudication_by_userid,ea.adjudication_dtm,ea.episode_note,ur.user_record_id from patients.patient p\n"
					+ "inner join transmissions.episode_and_egm eae on p.patient_id = eae.Patient_id\n"
					+ "inner join transmissions.episode_adjudication ea on eae.episode_and_egm_id = ea.episode_and_egm_id\n"
					+ "inner join users.user_record ur on ur.user_record_id = ea.adjudication_by_userid \n"
					+ "where p.first_name='"+patient.getFirstName()+"' and ur.logon_user_name = '"+ login.getUserName() +"'\n"
					+ "order by last_updt_dtm desc;";
			databaseResults = queryResults.patientTable_TC1238457(query);
			assertion.assertEquals(databaseResults.get("adjudication_type_cd"),"2613","Adjudication type cd is matching with expected value.");
			assertion.assertEquals(databaseResults.get("adjudication_by_userid"),databaseResults.get("user_record_id"),"User Id is matching b/w Patient and User record table");
			assertion.assertEquals(databaseResults.get("adjudication_dtm"),"value","Patient Id field is matching b/w database and UI"); //need to be updated
			assertion.assertEquals(databaseResults.get("episode_note"),notes,"Assessment notes is matching b/w database and UI");
			
			extentReport.info("1100 S Navigate to RT page. Select Patient1 name which navigates to Patient and Device data page and go to Transmissions tab then select Episode and EGM page.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");	
			
			
			extentReport.info("1200 S On Episode and EGM page, click on date and time of an Episode with pdf without EGM with Assessment type ‘Appropriate’. On Episode Viewer window, add assessment note less than 120 characters.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			pl_Transmission_EpisodeAndEgmPage.deselectAssessmentType();
			pl_Transmission_EpisodeAndEgmPage.selectAssessmentType("Appropriate");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("TransmissionDate");
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(119); 
			
			
			extentReport.info("1300 V On Episode Viewer window, verify that user can add assessment note up to 120 characters to selected Episode.", new String[] {"TransMgt18693","Config23515"});
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(121);
			notes = pl_Transmission_EpisodeAndEgmPage.validateAssessmentNotes();
			assertion.assertEqualsWithReporting(120,notes.length(),extentReport,"User is able to add assessment notes till 120 char");
			
			extentReport.info("1400 S Select save button.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeViewerSaveButton();
			
			extentReport.info("1500 V Verify Episode Viewer window is display in view mode.",new String[] {"CommUI7681"});
			
			extentReport.info("1600 S Close the episode viewer window and on Episode and EGM page, hover on assessment icon.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeAndEgmPdfCloseButton();
			mouseHoverNotes = pl_Transmission_EpisodeAndEgmPage.mouseHoverAssessmentType();
			
			extentReport.info("1700 V Verify added note is display on hover.", new String[] {"TransMgt18693"});
			assertion.assertEquals(mouseHoverNotes, notes, "Added notes is matching with the notes present on mousehover");
			
			extentReport.info("1800 V Verify for the above episode,\n"
					+ "• the Adjudication_Type_Cd='2600'\n"
					+ "• UserID of the clinician in the Adjudication_by_userid column\n"
					+ "• Date and time of Adjudication in the Adjudication_DTM and\n"
					+ "• Assessment Note in the Episode_Note column in the Episode_Adjudication table.", new String[] {"TransMgt18693"});
			databaseResults = queryResults.patientTable_TC1238457(query);
			assertion.assertEquals(databaseResults.get("adjudication_type_cd"),"2600","Adjudication type cd is matching with expected value.");
			assertion.assertEquals(databaseResults.get("adjudication_by_userid"),databaseResults.get("user_record_id"),"User Id is matching b/w Patient and User record table");
			assertion.assertEquals(databaseResults.get("adjudication_dtm"),"value","Patient Id field is matching b/w database and UI"); //need to be updated
			assertion.assertEquals(databaseResults.get("episode_note"),notes,"Assessment notes is matching b/w database and UI");
			
			extentReport.info("1900 S Go to More Action then select Download Spreadsheet.");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("Checkbox");
			pl_Transmission_EpisodeAndEgmPage.clickOnMoreActions();
			pl_Transmission_EpisodeAndEgmPage.clickOnDownloadSpreadSheet();
			
			extentReport.info("2000 V Verify that in download spreadsheet, Added Note is display under Note column.", new String[] {"TransMgt18693"});
			path=System.getProperty("user.dir")+"\\Downloads\\"+patientListPage.getLatestDownloadedFile(System.getProperty("user.dir")+"\\Downloads\\");
			episodeAdjudication = testDataProvider.getEpisodeAdjudicationData(path);
			assertion.assertEquals(episodeAdjudication.getLastAccessedBy(),login.getUserName(),"Adjudication type cd is matching with expected value."); 
			assertion.assertEquals(episodeAdjudication.getLastAccessedOn(),CommonUtils.currentDate(),"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getNotes(),mouseHoverNotes,"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getAssessment(),"Not Assessed","Adjudication type cd is matching with expected value.");
			
			extentReport.info("2100 S On Episode and EGM page, click on EGM icon of Ongoing Episode with Inappropriate assessment type. On Episode Viewer window, add assessment note less than 120 characters.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");	
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			pl_Transmission_EpisodeAndEgmPage.deselectAssessmentType();
			pl_Transmission_EpisodeAndEgmPage.selectAssessmentType("Inappropriate");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("Checkbox");
			pl_Transmission_EpisodeAndEgmPage.clickOnMoreActions();
			pl_Transmission_EpisodeAndEgmPage.navigateToViewEpisodeOption();
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(119); 
			
			extentReport.info("2200 V On Episode Viewer window, verify that user can add assessment note up to 120 characters to selected Episode.", new String[] {"TransMgt18693","Config23515"});
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(121);
			notes = pl_Transmission_EpisodeAndEgmPage.validateAssessmentNotes();
			assertion.assertEqualsWithReporting(120,notes.length(),extentReport,"User is able to add assessment notes till 120 char");
			
			extentReport.info("2300 S Select save button.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeViewerSaveButton();
			

			extentReport.info("2400 V Verify Episode Viewer window is display in view mode.", new String[] {"CommUI7681"});
			assertion.assertEquals(pl_Transmission_EpisodeAndEgmPage.ValidateEpisodeViewerWindowInViewMode(), true, "Episode viewer window is in view mode");
			
			extentReport.info("2500 S Close the episode viewer window and on Episode and EGM page, hover on assessment icon.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeAndEgmPdfCloseButton();
			mouseHoverNotes = pl_Transmission_EpisodeAndEgmPage.mouseHoverAssessmentType();
			
			extentReport.info("2600 V Verify added note is display on hover.",new String[] {"TransMgt18693","TransMgt18846"});
			assertion.assertEquals(mouseHoverNotes, notes, "Added notes is matching with the notes present on mousehover");
			
			extentReport.info("2700 V Verify for the above episode,\n"
					+ "• the Adjudication_Type_Cd='2601'\n"
					+ "• UserID of the clinician in the Adjudication_by_userid column\n"
					+ "• Date and time of Adjudication in the Adjudication_DTM and\n"
					+ "• Assessment Note in the Episode_Note column in the Episode_Adjudication table.",new String[] {"TransMgt18693"});
			databaseResults = queryResults.patientTable_TC1238457(query);
			assertion.assertEquals(databaseResults.get("adjudication_type_cd"),"2601","Adjudication type cd is matching with expected value.");
			assertion.assertEquals(databaseResults.get("adjudication_by_userid"),databaseResults.get("user_record_id"),"User Id is matching b/w Patient and User record table");
			assertion.assertEquals(databaseResults.get("adjudication_dtm"),"value","Patient Id field is matching b/w database and UI"); //need to be updated
			assertion.assertEquals(databaseResults.get("episode_note"),notes,"Assessment notes is matching b/w database and UI");
			
			
			extentReport.info("2800 S Go to More Action then select Download Spreadsheet.");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("Checkbox");
			pl_Transmission_EpisodeAndEgmPage.clickOnMoreActions();
			pl_Transmission_EpisodeAndEgmPage.clickOnDownloadSpreadSheet();
			
			extentReport.info("2900 V Verify that in download spreadsheet, Added Note is display under Note column. ",new String[] {"TransMgt18693"});
			path=System.getProperty("user.dir")+"\\Downloads\\"+patientListPage.getLatestDownloadedFile(System.getProperty("user.dir")+"\\Downloads\\");
			episodeAdjudication = testDataProvider.getEpisodeAdjudicationData(path);
			assertion.assertEquals(episodeAdjudication.getLastAccessedBy(),login.getUserName(),"Adjudication type cd is matching with expected value."); 
			assertion.assertEquals(episodeAdjudication.getLastAccessedOn(),CommonUtils.currentDate(),"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getNotes(),mouseHoverNotes,"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getAssessment(),"Not Assessed","Adjudication type cd is matching with expected value.");
			
			extentReport.info("3000 S Navigate to RT page. Select date time transmission link of Patient1 which navigates to Transmissions tab.");
			clinicianHomeTopNavPage.navigateToRecentTransmissionLink();
			assertion.assertEqualsWithReporting(true,clinicianHomePage.verifyLandingPage(),extentReport,"Clinician Home Page is displayed");
			ca_RecentTransmissionsPage.enterTier3FilterInputBx(patient.getFirstName());
			assertion.assertEqualsWithReporting(true,ca_RecentTransmissionsPage.verifyLandingPage(),extentReport,"Recent transmissions Page is loaded after selecting Tier3 text.");
			ca_RecentTransmissionsPage.clickOnTransmissionFromTrnmsnList();
			assertion.assertEqualsWithReporting(true,pl_TransmissionPage.verifyLandingPage(),extentReport,"Transmissions Page is loaded.");	
			
			
			extentReport.info("3100 S Go to Episodes and EGMs tab, select checkbox of Episode with EGM having Assessment type as ‘Not Sure’ and go to More actions then select ‘View Episode’ option. On Episode Viewer window, add assessment note less than 120 characters.");
			pl_TransmissionPage.navigateToEpisodesAndEGMs();
			assertion.assertEqualsWithReporting(true,pl_Transmission_EpisodeAndEgmPage.verifyLandingPage(),extentReport,"Episodes and EGM Page is loaded.");
			pl_Transmission_EpisodeAndEgmPage.deselectAssessmentType();
			pl_Transmission_EpisodeAndEgmPage.selectAssessmentType("NotSure");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("EGM");
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(119); 
			
			extentReport.info("3200 V On Episode Viewer window, verify that user can add assessment note up to 120 characters to selected Episode.",new String[] {"TransMgt18693","Config23515"});
			pl_Transmission_EpisodeAndEgmPage.addAssessmentNotes(121);
			notes = pl_Transmission_EpisodeAndEgmPage.validateAssessmentNotes();
			assertion.assertEqualsWithReporting(120,notes.length(),extentReport,"User is able to add assessment notes till 120 char");
			
			extentReport.info("3300 S Select save button.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeViewerSaveButton();
			
			extentReport.info("3400 V Verify Episode Viewer window is display in view mode.", new String[] {"CommUI7681"});
			assertion.assertEquals(pl_Transmission_EpisodeAndEgmPage.ValidateEpisodeViewerWindowInViewMode(), true, "Episode viewer window is in view mode");
			
			extentReport.info("3500 S Close the episode viewer window and on Episode and EGM page, hover on Assessment icon.");
			pl_Transmission_EpisodeAndEgmPage.clickEpisodeAndEgmPdfCloseButton();
			mouseHoverNotes = pl_Transmission_EpisodeAndEgmPage.mouseHoverAssessmentType();
			
			extentReport.info("3600 V Verify added note is display on hover. ", new String[] {"TransMgt18693","TransMgt18846"});
			assertion.assertEquals(mouseHoverNotes, notes, "Added notes is matching with the notes present on mousehover");
			
			extentReport.info("3700 S On Episode and EGM page, go to More Action then select Download Spreadsheet.");
			pl_Transmission_EpisodeAndEgmPage.selectEgmEpisodeCheckBox("Checkbox");
			pl_Transmission_EpisodeAndEgmPage.clickOnMoreActions();
			pl_Transmission_EpisodeAndEgmPage.clickOnDownloadSpreadSheet();
			
			extentReport.info("3800 V Verify that in download spreadsheet, Added Note with User ID and Date time is display under Note column.", new String[] {"TransMgt18693"});
			path=System.getProperty("user.dir")+"\\Downloads\\"+patientListPage.getLatestDownloadedFile(System.getProperty("user.dir")+"\\Downloads\\");
			episodeAdjudication = testDataProvider.getEpisodeAdjudicationData(path);
			assertion.assertEquals(episodeAdjudication.getLastAccessedBy(),login.getUserName(),"Adjudication type cd is matching with expected value."); 
			assertion.assertEquals(episodeAdjudication.getLastAccessedOn(),CommonUtils.currentDate(),"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getNotes(),mouseHoverNotes,"Adjudication type cd is matching with expected value.");
			assertion.assertEquals(episodeAdjudication.getAssessment(),"Not Assessed","Adjudication type cd is matching with expected value.");
			
			extentReport.info("3900 V Verify for the above episode,\n"
					+ "• the Adjudication_Type_Cd='2602'\n"
					+ "• UserID of the clinician in the Adjudication_by_userid column\n"
					+ "• Date and time of Adjudication in the Adjudication_DTM and\n"
					+ "• Assessment Note in the Episode_Note column in the Episode_Adjudication table. ", new String[] {"TransMgt18693"});
			databaseResults = queryResults.patientTable_TC1238457(query);
			assertion.assertEquals(databaseResults.get("adjudication_type_cd"),"2602","Adjudication type cd is matching with expected value.");
			assertion.assertEquals(databaseResults.get("adjudication_by_userid"),databaseResults.get("user_record_id"),"User Id is matching b/w Patient and User record table");
			assertion.assertEquals(databaseResults.get("adjudication_dtm"),"value","Patient Id field is matching b/w database and UI"); //need to be updated
			assertion.assertEquals(databaseResults.get("episode_note"),notes,"Assessment notes is matching b/w database and UI");
			extentReport.info("Test case ends");
			assertion.assertAll();
			
		} catch (AssertionError e) {
			extentReport.fail(testName+"Failed due to Assertion Failure");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (Exception e) {
			extentReport.fail( testName+" Failed due to some Exception");
			logger.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	@AfterMethod
	public void createEvidenceAndResult(ITestResult result) throws Exception {
		clinicianHomeTopNavPage.clickSignOutLink();
		saintResult(result, extentTest);
		}
}
