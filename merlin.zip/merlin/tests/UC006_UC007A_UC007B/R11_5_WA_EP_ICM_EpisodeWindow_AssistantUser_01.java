package com.test.qa.ui.tests.UC006_UC007A_UC007B;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.dataProvider.TestDataProvider;
import com.test.qa.pojo.Login;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.AlliedndPhyscianTopNav;
import com.test.qa.ui.pageObjects.AlliedndPhyscianLogin.My_Account_Page;
import com.test.qa.ui.pageObjects.ClinicAdminLogin.LoginPageWithPOJO;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_EpisodesAndEGMPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.CA_RecentTransmissionsPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomePage;
import com.test.qa.ui.pageObjects.ClinicianLogin.ClinicianHomeTopNavPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PL_TransmissionPage;
import com.test.qa.ui.pageObjects.ClinicianLogin.PatientListPage;
import com.test.qa.utilities.CommonUtils;

public class R11_5_WA_EP_ICM_EpisodeWindow_AssistantUser_01 extends CommonUtils {
  
	
	ClinicianHomePage clinicianHomePage;
	CA_RecentTransmissionsPage recenttrasmissionpage;
	ClinicianHomeTopNavPage clinicianhometopnavpage;
	PatientListPage patientlistpage;
	PL_TransmissionPage pltransmissionpage;
	CA_EpisodesAndEGMPage episodeandegmpage;
	
	LoginPageWithPOJO loginPage;
	Login Clinic_User;
	ExtentTest extentTest;
	private String testName;
	TestDataProvider testDataProvider;
	
	@BeforeClass
	public void initialize() 
	{
         clinicianHomePage =new ClinicianHomePage(driver,extentReport);
		
		recenttrasmissionpage=new CA_RecentTransmissionsPage(driver, extentReport);
		clinicianhometopnavpage=new ClinicianHomeTopNavPage(driver, extentReport);
		patientlistpage=new PatientListPage(driver, extentReport);
		pltransmissionpage=new PL_TransmissionPage(driver, extentReport);
		episodeandegmpage=new CA_EpisodesAndEGMPage(driver, extentReport);
		
		loginPage = new LoginPageWithPOJO(driver, extentReport);
		Clinic_User = new Login();
		testDataProvider = new TestDataProvider();
	}
	
	
	@Test
  public void WA_EP_ICM_EpisodeWindow_AssistantUser_01() throws Exception {

		   testName = CommonUtils.getTestName();
			CommonUtils.currentTestCaseName = testName;

			extentTest = extentReport.initiateTest(testName);
			
			Clinic_User = testDataProvider.getLoginData("DirectAssistant");
			
			
			extentTest.assignAuthor("Author: Kundan Kumar");
			try {
				//assertion = new Assertions(extentTest);
	             //********* RT page -> Transmission tab ***********
				extentReport.info("100 S Login to clinic A as Assistant User. Navigate to RT page. Select Patient1 name which navigates to Patient profile and go to Transmissions tab");
				loginPage.login(Clinic_User, "externaluser");
				assertion.assertEqualsWithReporting(true, clinicianHomePage.verifyLandingPage(), extentReport,
						"Clinician Home Landing page is displayed");
				clinicianhometopnavpage.navigateToRecentTransmissionLink();
				recenttrasmissionpage.clickOnPatientNameFromTrnmsnList();
				pltransmissionpage.navigateToTransmissionTab();
				
	            extentReport.info("200S Go to Episodes and EGMs tab, select checkbox of one episode and go to More actions then select ‘View Episode’ option.");
	            pltransmissionpage.navigateToEpisodesAndEGMs();
	            episodeandegmpage.selectEpisodeCbxEpisodeEGMPage();
	            episodeandegmpage.clickOnMoreActions();
	            episodeandegmpage.navigateToViewEpisodeOption();
	            
			    extentReport.info("300 S On Episodes Viewer window, select Assessment type 'Appropriate' from dropdown.");
	            episodeandegmpage.verifyEpisodeandEgmWindow();
	            episodeandegmpage.selectAppropiateOption();
	            
			    extentReport.info("400 V Verify user not able to save changes (Save button is not display).",new String[] {"TransMgt18712,TransMgt18607"});
	            episodeandegmpage.verifySaveButtonisDisabled();
	            //As per discussion with Abirami save button will be there but as disabled.need to change TC.
	            
			    extentReport.info("500 S On Episodes Viewer window, select Assessment type 'Inappropriate' from dropdown.");
			    episodeandegmpage.selectInappropiateOption();
			    
			   extentReport.info("600 V Verify user not able to save changes (Save button is not display).  <TransMgt18712>, <TransMgt18607>",new String[] {"TransMgt18712,TransMgt18607"});
			   episodeandegmpage.verifySaveButtonisDisabled();
	            //As per discussion with Abirami save button will be there but as disabled.need to change TC.
			   
			   extentReport.info("700 S On Episodes Viewer window, select Assessment type ‘Not Sure’ from dropdown.");
			   episodeandegmpage.selectNotsureOption();
			   
			   extentReport.info("800 V Verify user not able to save changes (Save button is not display). ",new String[] {"TransMgt18712,TransMgt18607"});
			   episodeandegmpage.verifySaveButtonisDisabled();
	            //As per discussion with Abirami save button will be there but as disabled.need to change TC.
			   
			   extentReport.info("900 S Close Episodes Viewer window. Select date time of an Episode with assessment type Appropriate/Inappropriate/Not sure.");
	           episodeandegmpage.clickCancelButton();
	           episodeandegmpage.clickEpisodeDateandTimeLink();
	           
			   extentReport.info("1000 S On Episodes Viewer window, select Assessment type ‘Not Assessed’ from dropdown.");
			   episodeandegmpage.selectNotassessedOption();
	         
			   extentReport.info("1100 V Verify user not able to save changes (Save button is not display). ",new String[] {"TransMgt18712,TransMgt18607"});
	            episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
	            
			   extentReport.info("1200 S On Episodes Viewer window, select add or edit Assessment note.");
	          episodeandegmpage.verifyNoteTextboxisDisabled();
	          //As per discussion with Abirami this step needs to change for verification as not section is disabled.
	          
	          extentReport.info("1300 V Verify user not able to save changes (Save button is not display).",new String[] {"TransMgt18693"});
	          episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
	          
		      extentReport.info("1400 S On Episodes Viewer window, select checkbox of Mark for print.");
	          episodeandegmpage.selectPrintCheckbox();
	         
			  extentReport.info("1500 V Verify user not able to save changes (Save button is not display). ",new String[] {"TransMgt18664"});
			  episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
			  
	     //********* RT Page -> Select date time of transmission ->Transmission tab ***********
	       
		     extentReport.info("1600 S Close Episode Viewer window and navigate to RT page. Select Patient1 and click on date time of transmission which navigates to Transmissions tab.");
		     episodeandegmpage.clickCancelButton();
		     clinicianhometopnavpage.navigateToRecentTransmissionLink();
		     episodeandegmpage.navigateToTransmissionLinkColumn();
		     pltransmissionpage.navigateToTransmissionTab();
		     
		     extentReport.info("1700S Go to Episodes and EGMs tab, select checkbox of one episode and go to More actions then select ‘View Episode’ option.");
		        pltransmissionpage.navigateToEpisodesAndEGMs();
	            episodeandegmpage.selectEpisodeCbxEpisodeEGMPage();
	            episodeandegmpage.clickOnMoreActions();
	            episodeandegmpage.navigateToViewEpisodeOption();
	            
	         extentReport.info("1800 S On Episodes Viewer window, select Assessment type 'Appropriate' from dropdown.");
	         episodeandegmpage.verifyEpisodeandEgmWindow();
	            episodeandegmpage.selectAppropiateOption();
	            
	         extentReport.info("1900 V Verify user not able to save changes (Save button is not display)."  ,new String[] {"TransMgt18712,TransMgt18607"});
	         episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
	 
	         extentReport.info("2000 S On Episodes Viewer window, select Assessment type 'Inappropriate' from dropdown.");
	         episodeandegmpage.selectInappropiateOption();
	         
		     extentReport.info("2100 V Verify user not able to save changes (Save button is not display). " ,new String[] {"TransMgt18712,TransMgt18607"});
		     episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
		     
	         extentReport.info("2200 S On Episodes Viewer window, select Assessment type ‘Not Sure’ from dropdown.");
	         episodeandegmpage.selectNotsureOption();
	         
		     extentReport.info("2300 V Verify user not able to save changes (Save button is not display). ",new String[] {"TransMgt18712,TransMgt18607"});
		     episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
		     
	         extentReport.info("2400 S Close Episodes Viewer window. Select date time of an Episode with assessment type Appropriate/Inappropriate/Not sure.");
	         episodeandegmpage.clickCancelButton();
	         episodeandegmpage.clickEpisodeDateandTimeLink();
	           
		     extentReport.info("2500 S On Episodes Viewer window, select Assessment type ‘Not Assessed’ from dropdown.");
		     episodeandegmpage.selectNotassessedOption();
		     
	         extentReport.info("2600 V Verify user not able to save changes (Save button is not display).",new String[] {"TransMgt18712,TransMgt18607"});
	         episodeandegmpage.verifySaveButtonisDisabled();
	          //As per discussion with Abirami save button will be there but as disabled.need to change TC.
	         
	         extentReport.info("2700 S On Episodes Viewer window, select add or edit Assessment note.");
	         episodeandegmpage.verifyNoteTextboxisDisabled();
	          //As per discussion with Abirami this step needs to change for verification as not section is disabled.
	         
		     extentReport.info("2800 V Verify user not able to save changes (Save button is not display). ",new String[] {"TransMgt18693"});
		     episodeandegmpage.verifySaveButtonisDisabled();
	         //As per discussion with Abirami save button will be there but as disabled.need to change TC.
		     
	         extentReport.info("2900 S On Episodes Viewer window, select checkbox of Mark for print.");
	         episodeandegmpage.selectPrintCheckbox();
	         
	         extentReport.info("3000 V Verify user not able to save changes (Save button is not display). ",new String[] {"TransMgt18664"});
	         episodeandegmpage.verifyNoteTextboxisDisabled();
	          //As per discussion with Abirami this step needs to change for verification as not section is disabled.
	         
		     extentReport.info("3100 S On Episodes Viewer window, select EGM Gain Viewer button.");
             episodeandegmpage.selectEgmViewerButton();
             
	         extentReport.info("3200 V Verify EGM Gain Viewer window is display. <TransMgt18882>");
	         episodeandegmpage.verifyEgmViewerWindow();
				
			}
			 catch (AssertionError e) {
				e.printStackTrace();
				extentReport.reportFail(e.getMessage());
				throw new AssertionError();
			}
	
	}
}
