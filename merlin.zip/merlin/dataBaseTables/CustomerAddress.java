package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class CustomerAddress {
	private String countryCode;


	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public DataBaseConnector dataBase = new DataBaseConnector();
	public void readAddressTable(String addressId) throws SQLException, InterruptedException {
		dataBase.getConnection();
		ResultSet customerAddress = dataBase.executeQuery("SELECT * FROM customers.customer_address where customer_address_id='" + addressId + "'");
		while (customerAddress.next()) {
			setCountryCode(customerAddress.getString("country_cd"));
		}
	}
	
}
