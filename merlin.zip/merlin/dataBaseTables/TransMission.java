package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class TransMission {

	private String transmission_id;
	private String patient_id;
	private String session_date_and_time;
	private String device_model_num;
	private String device_serial_num;
	private String create_dtm;
	
	public String getCreatedDateTime() {
		return create_dtm;
	}

	public void setCreatedDateTime(String string) {
		this.create_dtm = string;
	}
	public String getDeviceSericalNumber() {
		return device_serial_num;
	}

	public void setDeviceSericalNumber(String string) {
		this.device_serial_num = string;
	}
	public String getDeviceModelNumber() {
		return device_model_num;
	}

	public void setDeviceModelNumber(String string) {
		this.device_model_num = string;
	}

	public String getSessionDateTime() {
		return session_date_and_time;
	}

	public void setSessionDateTime(String string) {
		this.session_date_and_time = string;
	}

	public String getPatientId() {
		return patient_id;
	}

	public void setPatientId(String string) {
		this.patient_id = string;
	}
	public String getTransmissionId() {
		return transmission_id;
	}

	public void setTransmissionId(String string) {
		
		this.transmission_id = string;
	}
	public DataBaseConnector dataBase = new DataBaseConnector();

	

	public void readTransMissionTable(String trasmissionid) throws SQLException, InterruptedException {
		dataBase.getConnection();
		
		ResultSet transmissioninfo = dataBase.executeQuery("select * from transmission.transmission t2 where transmission_id ='"+trasmissionid+"'");
		while (transmissioninfo.next()) {
			setTransmissionId(transmissioninfo.getString("transmission_id"));
			setPatientId(transmissioninfo.getString("patient_id"));
			setSessionDateTime(transmissioninfo.getString("session_date_and_time"));
			setDeviceSericalNumber(transmissioninfo.getString("device_serial_num"));
			setCreatedDateTime(transmissioninfo.getString("create_dtm"));
		}
		
		


	

	}
}
