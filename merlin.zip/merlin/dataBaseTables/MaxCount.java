package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class MaxCount {

	private String count;
	private String max;

	public String getCount() {
		return count;
	}

	public void setCount(String string) {
		this.count = string;
	}

	public String getmax() {
		return max;
	}

	public void setMax(String string) {
		this.max = string;
	}

	public DataBaseConnector dataBase = new DataBaseConnector();

	

	public void readTransMissionTable(String tableName) throws SQLException, InterruptedException {
		
		dataBase.getConnection();
		Thread.sleep(6000);
		if(tableName.equals("transmission"))
		{
		ResultSet transmissioninfo = dataBase.executeQuery("select 'transmission' as table,count(*),max(transmission_id) from transmission.transmission");
		while (transmissioninfo.next()) {
			setMax(transmissioninfo.getString("max"));
			setCount(transmissioninfo.getString("count"));
		}
		}
		else if(tableName.equals("alerts"))
		{
		ResultSet transmissioninfo = dataBase.executeQuery("select 'alerts' as table,count(*),max(alert_id) from alert_notification.alert");
		while (transmissioninfo.next()) {
			setMax(transmissioninfo.getString("max"));
			setCount(transmissioninfo.getString("count"));
		}
		}
		else if(tableName.equals("episode"))
		{
		ResultSet transmissioninfo = dataBase.executeQuery("select 'episode' as table,count(*),max(episode_and_egm_id) from transmission.episode_and_egm ");
		while (transmissioninfo.next()) {
			setMax(transmissioninfo.getString("max"));
			setCount(transmissioninfo.getString("count"));
		}
		}
		else if(tableName.equals("battery"))
		{
		ResultSet transmissioninfo = dataBase.executeQuery("select 'battery' as table,count(*),max(battery_longevity_id) from device_product.battery_longevity ");
		while (transmissioninfo.next()) {
			setMax(transmissioninfo.getString("max"));
			setCount(transmissioninfo.getString("count"));
		}
		}
		else if(tableName.equals("leads"))
		{
		ResultSet transmissioninfo = dataBase.executeQuery("select 'leads' as  table,count(*),max(lead_id) from transmission.lead ");
		while (transmissioninfo.next()) {
			setMax(transmissioninfo.getString("max"));
			setCount(transmissioninfo.getString("count"));
		}
		}
		else if(tableName.equals("congestionmonitoring"))
		{
		ResultSet transmissioninfo = dataBase.executeQuery("select 'congestionmonitoring' as table,count(*),max(congestion_period_id) from transmission.congestion_period");
		while (transmissioninfo.next()) {
			setMax(transmissioninfo.getString("max"));
			setCount(transmissioninfo.getString("count"));
		}
		}
		
			
		}

	

	}

