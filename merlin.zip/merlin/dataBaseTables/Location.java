package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class Location {
	private String locationName;

	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public DataBaseConnector dataBase = new DataBaseConnector();
	public void readLocationTable(String customerId) throws SQLException, InterruptedException {
	dataBase.getConnection();
	ResultSet customerLocation = dataBase.executeQuery("SELECT * FROM customers.customer_location where customer_id='" + customerId + "'");
	while (customerLocation.next()) {
		setLocationName(customerLocation.getString("name"));
	}
	}
	
}
