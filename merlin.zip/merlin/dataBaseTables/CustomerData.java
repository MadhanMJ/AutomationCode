package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class CustomerData {
	private String iteration;
	private String flag;
	private String referenceTestCase;
	private String customerName;
	private String userid;
	private String customerType;
	private String clinicLocation;
	private String countryCode;
	private String areaCode;
	private String mainPhone;
	private String SecPhone;
	private String country;
	private String email;
	private String zip;
	private String clinicTimeZone;
	private String legalJurisdiction;
	private String clinicLanguage;
	private String newPassword;
	private String confirmNewPassword;
	private String firstName;
	private String lastName;
	private String emailId;
	private String elecExport;
	private String city;
	private String stateProvince;
	private String secondaryLocation;
	private String middleName;
	private String address1;
	private String address2;
	private String address3;
	private String exportTransmissionData;
	private String orderTransmitter;
	private String recordPatientDataCollection;
	private String allowMobileDirectAlert;
	private String allowVoiceMessage;
	private String allowTextMessage;
	
	public String getRecordPatientDataCollection() {
		return recordPatientDataCollection;
	}
	public void setRecordPatientDataCollection(String recordPatientDataCollection) {
		this.recordPatientDataCollection = recordPatientDataCollection;
	}
	public String getAllowMobileDirectAlert() {
		return allowMobileDirectAlert;
	}
	public void setAllowMobileDirectAlert(String allowMobileDirectAlert) {
		this.allowMobileDirectAlert = allowMobileDirectAlert;
	}
	public String getAllowVoiceMessage() {
		return allowVoiceMessage;
	}
	public void setAllowVoiceMessage(String allowVoiceMessage) {
		this.allowVoiceMessage = allowVoiceMessage;
	}
	public String getAllowTextMessage() {
		return allowTextMessage;
	}
	public void setAllowTextMessage(String allowTextMessage) {
		this.allowTextMessage = allowTextMessage;
	}
	public String getExportTransmissionData() {
		return exportTransmissionData;
	}
	public void setExportTransmissionData(String exportTransmissionData) {
		this.exportTransmissionData = exportTransmissionData;
	}
	public String getOrderTransmitter() {
		return orderTransmitter;
	}
	public void setOrderTransmitter(String orderTransmitter) {
		this.orderTransmitter = orderTransmitter;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getSecondaryLocation() {
		return secondaryLocation;
	}
	public void setSecondaryLocation(String secondaryLocation) {
		this.secondaryLocation = secondaryLocation;
	}
	public String getStateProvince() {
		return stateProvince;
	}
	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getIteration() {
		return iteration;
	}
	public void setIteration(String iteration) {
		this.iteration = iteration;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getClinicLocation() {
		return clinicLocation;
	}
	public void setClinicLocation(String clinicLocation) {
		this.clinicLocation = clinicLocation;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getMainPhone() {
		return mainPhone;
	}
	public void setMainPhone(String mainPhone) {
		this.mainPhone = mainPhone;
	}
	public String getSecPhone() {
		return SecPhone;
	}
	public void setSecPhone(String SecPhone) {
		this.SecPhone = SecPhone;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getClinicTimeZone() {
		return clinicTimeZone;
	}
	public void setClinicTimeZone(String clinicTimeZone) {
		this.clinicTimeZone = clinicTimeZone;
	}
	public String getLegalJurisdiction() {
		return legalJurisdiction;
	}
	public void setLegalJurisdiction(String legalJurisdiction) {
		this.legalJurisdiction = legalJurisdiction;
	}
	public String getClinicLanguage() {
		return clinicLanguage;
	}
	public void setClinicLanguage(String clinicLanguage) {
		this.clinicLanguage = clinicLanguage;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmNewPassword() {
		return confirmNewPassword;
	}
	public void setConfirmNewPassword(String confirmNewPassword) {
		this.confirmNewPassword = confirmNewPassword;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getElecExport() {
		return elecExport;
	}
	public void setElecExport(String elecExport) {
		this.elecExport = elecExport;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getReferenceTestCase() {
		return referenceTestCase;
	}
	public void setReferenceTestCase(String referenceTestCase) {
		this.referenceTestCase = referenceTestCase;
	}


	public DataBaseConnector dataBase = new DataBaseConnector();

	public void readCustomerTable(String userId) throws SQLException, InterruptedException {
		dataBase.getConnection();
		ResultSet customerInfo = dataBase.executeQuery("select c.customer_id,c.name customer_name,(SELECT code_desc FROM lookup.code cd where cd.code_id=c.customer_type_cd and cd.code_qualifier ='Customer_Type_Cd') as customer_type, cl.name as clinic_location,cad.street_address address1,cad.street_address2 address2,cad.street_address3 address3, (SELECT code_desc FROM lookup.code cd where cad.customer_address_id =c.customer_address_id and cd.code_id=cad.country_cd and cd.code_qualifier ='Country_Cd') as country, (SELECT code_desc FROM lookup.code cd where cad.customer_address_id =c.customer_address_id and cd.code_id=cad.state_cd and cd.code_qualifier ='State_Cd') as state, cad.city,cad.zip_code, cmp.country_code main_phone_country_code,cmp.area_code main_phone_area_code,cmp.phone_num main_phone_num, csp.country_code secondary_phone_country_code,csp.area_code secondary_phone_area_code,csp.phone_num secondary_phone_num, cfax.country_code fax_country_code,cfax.area_code fax_area_code,cfax.phone_num fax_num,c.sms text_message,c.email_address, (SELECT code_desc FROM lookup.code cd where cd.code_id=c.time_zone_cd and cd.code_qualifier ='Time_Zone_Cd') as clinic_time_zone, (SELECT code_desc FROM lookup.code cd where cd.code_id=c.legal_jurisdiction_cd and cd.code_qualifier ='Legal_Jurisdiction_Cd') as legal_jurisdiction, (SELECT code_desc FROM lookup.code cd where cd.code_id=c.spoken_language_cd and cd.code_qualifier ='Language_Cd') as clinic_language, ur.logon_user_name ,ur.first_name,ur.middle_name,ur.last_name,ur.temp_pwd,ca.email_address, c.test_clinic_flg from customers.customer c left join customers.customer_phone cmp on c.main_phone_id = cmp.customer_phone_id left join customers.customer_phone csp on c.secondary_phone_id = csp.customer_phone_id left join customers.customer_phone cfax on c.fax_num_id = csp.customer_phone_id left join customers.customer_address cad on c.customer_address_id = cad.customer_address_id left join customers.customer_location cl on cl.customer_id = c.customer_id inner join users.customer_account ca on c.customer_id = ca.customer_id inner join users.user_record ur on ca.user_record_id = ur.user_record_id where ur.logon_user_name ='" + userId + "'");
		while (customerInfo.next()) {
			// Customer Name (Mandatory)
				setCustomerName(customerInfo.getString("customer_name"));
			// Customer Type (Direct, Type 2 Service Provider) (Mandatory)
				setCustomerType(customerInfo.getString("customer_type"));
			//  Clinic Location (Mandatory)
				setClinicLocation(customerInfo.getString("clinic_location"));
			// Clinic Address
				setAddress1(customerInfo.getString("address1"));
				setAddress2(customerInfo.getString("address2"));
				setAddress3(customerInfo.getString("address3"));
			//Clinic City
				setCity(customerInfo.getString("city"));
			// State/Province
				setStateProvince(customerInfo.getString("state"));
			 // Country (Mandatory)
				setCountry(customerInfo.getString("country"));
			// Zip/Postal Code
				setZip(customerInfo.getString("zip_code"));
			 // Main Phone (Mandatory)
              setMainPhone(customerInfo.getString("main_phone_num"));
			//  Secondary Phone
			  setSecPhone(customerInfo.getString("secondary_phone_num"));
			 // Fax Number
			// setFaxNumber(customerInfo.getString("secondary_phone_num"));
			//  Text Message Contact Information

			 // Email Address (Mandatory)
			 setEmail(customerInfo.getString("email_address"));
			//  Clinic Preferred Language (Mandatory)

			//  Clinic Time Zone and Daylight Savings Time Preference (does or does not observe) (Mandatory)

			 // Clinic Legal Jurisdiction (Mandatory)
			 setEmail(customerInfo.getString("email_address"));
			//  Test Clinic (yes/no)

			 // Merlin On Demand Feature Control: Whether the clinic supports a Merlin on Demand Transmitter 

			 // User ID of Clinic's main contact person (Mandatory).

			//  First name of Clinic's main contact person (Mandatory)
//
			 // Middle name of Clinic's main contact person

			//  Last name of Clinic's main contact person (Mandatory)

			//  Credentials of Clinic's main contact person

			 // Email Address of Clinic's main contact person(Mandatory)

			//  Clinic Feature Controls <ClncAcct6525> <ClncAcct6521>
			 


		
			
		}
	}
}
