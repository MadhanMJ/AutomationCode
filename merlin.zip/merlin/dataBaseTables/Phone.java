package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class Phone {
	private String areaCode;
	private String countryCode;
	private String phoneNumber;
	
	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public DataBaseConnector dataBase = new DataBaseConnector();
	
	public void readPhoneTable(String phone_id) throws SQLException, InterruptedException {
		dataBase.getConnection();
		ResultSet phoneInfo = dataBase.executeQuery("SELECT * FROM customers.customer_phone where customer_phone_id='" + phone_id + "'");
		while (phoneInfo.next()) {
		setAreaCode(phoneInfo.getString("area_code"));
		setCountryCode(phoneInfo.getString("country_code"));
		setPhoneNumber(phoneInfo.getString("phone_num"));
		}
	}
}
