package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class LookUp {
	
	public String codeDescription;

	public String getCodeDescription() {
		return codeDescription;
	}

	public void setCodeDescription(String codeDescription) {
		this.codeDescription = codeDescription;
	}
	public DataBaseConnector dataBase = new DataBaseConnector();
	
	public void readLookUpTable(String typeCode, String codeQualifier) throws SQLException, InterruptedException {
	dataBase.getConnection();
	ResultSet lookUpInfo = dataBase.executeQuery("SELECT code_desc FROM lookup.code where code_id='"+ typeCode + "'and code_qualifier ='"+codeQualifier+"'");
	while (lookUpInfo.next()) {
		setCodeDescription(lookUpInfo.getString("code_desc"));
	}
	}
	
}
