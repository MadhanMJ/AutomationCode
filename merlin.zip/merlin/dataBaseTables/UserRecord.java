package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class UserRecord {
	private String userRecordId;
	private String firstName;
	private String lastName;
	private String tempPwd;
	public String getUserRecordId() {
		return userRecordId;
	}

	public void setUserRecordId(String userRecordId) {
		this.userRecordId = userRecordId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTempPwd() {
		return tempPwd;
	}

	public void setTempPwd(String tempPwd) {
		this.tempPwd = tempPwd;
	}

	public DataBaseConnector dataBase = new DataBaseConnector();
	
	public void readUserRecordTable(String userIdValue) throws SQLException, InterruptedException {
		dataBase.getConnection();
		ResultSet userRecord = (dataBase.executeQuery("SELECT * FROM users.user_record where logon_user_name='"+userIdValue+"'"));
		while (userRecord.next()) {
			setUserRecordId(userRecord.getString("user_record_id"));
			setFirstName(userRecord.getString("first_name"));
			setLastName(userRecord.getString("last_name"));
			setTempPwd(userRecord.getString("temp_pwd"));
			
		}
	}
	
}
