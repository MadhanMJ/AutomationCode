package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class CustomerAccount {
	private String customerId;
	
	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public DataBaseConnector dataBase = new DataBaseConnector();

	public void readCustomerAccountTable(String user_record_id) throws SQLException, InterruptedException {
	dataBase.getConnection();	
	ResultSet customerAccount = dataBase.executeQuery("SELECT * FROM users.customer_account where user_record_id='"+ user_record_id + "'");
	while (customerAccount.next()) {
		setCustomerId(customerAccount.getString("customer_id"));
	}
	}
	
}
