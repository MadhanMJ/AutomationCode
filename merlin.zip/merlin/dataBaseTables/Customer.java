package com.test.qa.dataBaseTables;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.qa.dataBase.DataBaseConnector;

public class Customer {
	private String customerName;
	private String emailAddress;
	private String customerTypeCd;
	private String timeZoneCd;
	private String spokenLanguageCd;
	private String phoneId;
	private String legalJurisdictionCd;
	private String addressId;
	private String order_transmitter_flg;
	private String lockout_legacy_device_chck_flg;
	private String show_export_session_flg;

	public String getOrder_transmitter_flg() {
		return order_transmitter_flg;
	}

	public void setOrder_transmitter_flg(String order_transmitter_flg) {
		this.order_transmitter_flg = order_transmitter_flg;
	}

	public String getLockout_legacy_device_chck_flg() {
		return lockout_legacy_device_chck_flg;
	}

	public void setLockout_legacy_device_chck_flg(String lockout_legacy_device_chck_flg) {
		this.lockout_legacy_device_chck_flg = lockout_legacy_device_chck_flg;
	}

	public String getShow_export_session_flg() {
		return show_export_session_flg;
	}

	public void setShow_export_session_flg(String show_export_session_flg) {
		this.show_export_session_flg = show_export_session_flg;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getCustomerTypeCd() {
		return customerTypeCd;
	}

	public void setCustomerTypeCd(String customerTypeCd) {
		this.customerTypeCd = customerTypeCd;
	}

	public String getTimeZoneCd() {
		return timeZoneCd;
	}

	public void setTimeZoneCd(String timeZoneCd) {
		this.timeZoneCd = timeZoneCd;
	}

	public String getSpokenLanguageCd() {
		return spokenLanguageCd;
	}

	public void setSpokenLanguageCd(String spokenLanguageCd) {
		this.spokenLanguageCd = spokenLanguageCd;
	}

	public String getPhoneId() {
		return phoneId;
	}

	public void setPhoneId(String phoneId) {
		this.phoneId = phoneId;
	}

	public String getLegalJurisdictionCd() {
		return legalJurisdictionCd;
	}

	public void setLegalJurisdictionCd(String legalJurisdictionCd) {
		this.legalJurisdictionCd = legalJurisdictionCd;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public DataBaseConnector getDataBase() {
		return dataBase;
	}

	public void setDataBase(DataBaseConnector dataBase) {
		this.dataBase = dataBase;
	}

	public DataBaseConnector dataBase = new DataBaseConnector();

	public void readCustomerTable(String customerId) throws SQLException, InterruptedException {
		dataBase.getConnection();
		ResultSet customerInfo = dataBase.executeQuery("SELECT * FROM customers.customer where customer_id='" + customerId + "'");
		while (customerInfo.next()) {
			setCustomerName(customerInfo.getString("name"));
			setEmailAddress(customerInfo.getString("email_address"));
			setAddressId(customerInfo.getString("customer_address_id"));
			setCustomerTypeCd(customerInfo.getString("customer_type_cd"));
			setTimeZoneCd(customerInfo.getString("time_zone_cd"));
			setSpokenLanguageCd(customerInfo.getString("spoken_language_cd"));
			setPhoneId(customerInfo.getString("main_phone_id"));
			setLegalJurisdictionCd(customerInfo.getString("legal_jurisdiction_cd"));
			setOrder_transmitter_flg(customerInfo.getString("order_transmitter_flg"));
			setShow_export_session_flg(customerInfo.getString("show_export_session_flg"));
			setLockout_legacy_device_chck_flg(customerInfo.getString("lockout_legacy_device_chck_flg"));
		}
	}
}
