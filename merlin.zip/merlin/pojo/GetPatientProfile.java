package com.test.qa.pojo;

public class GetPatientProfile {
	
	private String TransmitterModelNumber;
	private String TransmitterSerialNumber;
	private String TransmitterSWversion;
	private String ProfileVersion;
	public String getTransmitterModelNumber() {
		return TransmitterModelNumber;
	}
	public void setTransmitterModelNumber(String transmitterModelNumber) {
		this.TransmitterModelNumber = transmitterModelNumber;
	}
	public String getTransmitterSerialNumber() {
		return TransmitterSerialNumber;
	}
	public void setTransmitterSerialNumber(String transmitterSerialNumber) {
		this.TransmitterSerialNumber = transmitterSerialNumber;
	}
	public String getTransmitterSWversion() {
		return TransmitterSWversion;
	}
	public void setTransmitterSWversion(String transmitterSWversion) {
		this.TransmitterSWversion = transmitterSWversion;
	}
	public String getProfileVersion() {
		return ProfileVersion;
	}
	public void setProfileVersion(String profileVersion) {
		this.ProfileVersion = profileVersion;
	}
	
	

}
