package com.test.qa.pojo;

public class Customer {
	
	private String iteration;
	private String flag;
	private String referenceTestCase;
	private String customerName;
	private String userid;
	private String customerType;
	private String clinicLocation;
	private String countryCode;
	private String areaCode;
	private String mainPhone;
	private String country;
	private String zipPostalCode;
	private String email;
	private String clinicTimeZone;
	private String legalJurisdiction;
	private String clinicLanguage;
	private String newPassword;
	private String confirmNewPassword;
	private String firstName;
	private String lastName;
	private String emailId;
	private String elecExport;
	private String city;
	private String stateProvince;
	private String secondaryLocation;
	private String middleName;
	private String address1;
	private String address2;
	private String address3;
	private String exportTransmissionData;
	private String orderTransmitter;
	private String recordPatientDataCollection;
	private String allowMobileDirectAlert;
	private String allowVoiceMessage;
	private String allowTextMessage;
	private String SearchLocation1;
	private String SearchLocation2;
	private String SearchLocation3;
	private String SearchLocation4;
	private String SearchLocation5;
	private String patientTransmitterStatus;
	private String patientDeviceCheck;
	private String LengthyClinicLocationName;
	private String LengthyAddressField;
	private String LengthyClinicCity;

	private String FollowupDateID;
	private String CustomerApplicationID;
	private String PatientID;

	
	//shafiya
	private String SecondaryCountryCode;	
	private String SecondaryAreaCode;
	private String SecondaryMainPhone;
	private String faxCountryCode;
	private String faxAreaCode;
	private String faxMainPhone;
	private String textMessage;
	private String credentials;
	
	private String LengthyEmailAddress;
	private String StateProvinceVerification;
	private String CountryVerification;
	private String TimeZoneVerification;
	private String PatientNames;
	
	
	private String stateProvince1;
	private String stateProvince2;
	private String stateProvince3;
	private String stateProvince4;
	private String stateProvince5;
	private String stateProvince6;
	private String stateProvince7;
	private String stateProvince8;
	private String cityValue1;
	private String cityValue2;
	private String cityValue3;
	private String cityValue4;
	private String cityValue5;
	private String cityValue6;
	private String clinicNameValue1;
	private String clinicNameValue2;
	private String clinicNameValue3;
	private String clinicNameValue4;
	private String clinicNameValue5;
	private String clinicNameValue6;
	
	
	public String getCityValue1() {
		return cityValue1;
	}
	public void setCityValue1(String cityValue1) {
		this.cityValue1 = cityValue1;
	}
	public String getCityValue2() {
		return cityValue2;
	}
	public void setCityValue2(String cityValue2) {
		this.cityValue2 = cityValue2;
	}
	public String getCityValue3() {
		return cityValue3;
	}
	public void setCityValue3(String cityValue3) {
		this.cityValue3 = cityValue3;
	}
	public String getCityValue4() {
		return cityValue4;
	}
	public void setCityValue4(String cityValue4) {
		this.cityValue4 = cityValue4;
	}
	public String getCityValue5() {
		return cityValue5;
	}
	public void setCityValue5(String cityValue5) {
		this.cityValue5 = cityValue5;
	}
	public String getCityValue6() {
		return cityValue6;
	}
	public void setCityValue6(String cityValue6) {
		this.cityValue6 = cityValue6;
	}
	public String getClinicNameValue1() {
		return clinicNameValue1;
	}
	public void setClinicNameValue1(String clinicNameValue1) {
		this.clinicNameValue1 = clinicNameValue1;
	}
	public String getClinicNameValue2() {
		return clinicNameValue2;
	}
	public void setClinicNameValue2(String clinicNameValue2) {
		this.clinicNameValue2 = clinicNameValue2;
	}
	public String getClinicNameValue3() {
		return clinicNameValue3;
	}
	public void setClinicNameValue3(String clinicNameValue3) {
		this.clinicNameValue3 = clinicNameValue3;
	}
	public String getClinicNameValue4() {
		return clinicNameValue4;
	}
	public void setClinicNameValue4(String clinicNameValue4) {
		this.clinicNameValue4 = clinicNameValue4;
	}
	public String getClinicNameValue5() {
		return clinicNameValue5;
	}
	public void setClinicNameValue5(String clinicNameValue5) {
		this.clinicNameValue5 = clinicNameValue5;
	}
	public String getClinicNameValue6() {
		return clinicNameValue6;
	}
	public void setClinicNameValue6(String clinicNameValue6) {
		this.clinicNameValue6 = clinicNameValue6;
	}
	public String getStateProvince8() {
		return stateProvince8;
	}
	public void setStateProvince8(String stateProvince8) {
		this.stateProvince8 = stateProvince8;
	}
	public String getStateProvince1() {
		return stateProvince1;
	}
	public void setStateProvince1(String stateProvince1) {
		this.stateProvince1 = stateProvince1;
	}
	public String getStateProvince2() {
		return stateProvince2;
	}
	public void setStateProvince2(String stateProvince2) {
		this.stateProvince2 = stateProvince2;
	}
	public String getStateProvince3() {
		return stateProvince3;
	}
	public void setStateProvince3(String stateProvince3) {
		this.stateProvince3 = stateProvince3;
	}
	public String getStateProvince4() {
		return stateProvince4;
	}
	public void setStateProvince4(String stateProvince4) {
		this.stateProvince4 = stateProvince4;
	}
	public String getStateProvince5() {
		return stateProvince5;
	}
	public void setStateProvince5(String stateProvince5) {
		this.stateProvince5 = stateProvince5;
	}
	public String getStateProvince6() {
		return stateProvince6;
	}
	public void setStateProvince6(String stateProvince6) {
		this.stateProvince6 = stateProvince6;
	}
	public String getStateProvince7() {
		return stateProvince7;
	}
	public void setStateProvince7(String stateProvince7) {
		this.stateProvince7 = stateProvince7;
	}
	
	public String getPatientTransmitterStatus() {
		return patientTransmitterStatus;
	}
	public void setPatientTransmitterStatus(String patientTransmitterStatus) {
		this.patientTransmitterStatus = patientTransmitterStatus;
	}
	public String getPatientDeviceCheck() {
		return patientDeviceCheck;
	}
	public void setPatientDeviceCheck(String patientDeviceCheck) {
		this.patientDeviceCheck = patientDeviceCheck;
	}
	
	public String getRecordPatientDataCollection() {
		return recordPatientDataCollection;
	}
	public void setRecordPatientDataCollection(String recordPatientDataCollection) {
		this.recordPatientDataCollection = recordPatientDataCollection;
	}
	public String getAllowMobileDirectAlert() {
		return allowMobileDirectAlert;
	}
	public void setAllowMobileDirectAlert(String allowMobileDirectAlert) {
		this.allowMobileDirectAlert = allowMobileDirectAlert;
	}
	public String getAllowVoiceMessage() {
		return allowVoiceMessage;
	}
	public void setAllowVoiceMessage(String allowVoiceMessage) {
		this.allowVoiceMessage = allowVoiceMessage;
	}
	public String getAllowTextMessage() {
		return allowTextMessage;
	}
	public void setAllowTextMessage(String allowTextMessage) {
		this.allowTextMessage = allowTextMessage;
	}
	public String getExportTransmissionData() {
		return exportTransmissionData;
	}
	public void setExportTransmissionData(String exportTransmissionData) {
		this.exportTransmissionData = exportTransmissionData;
	}
	public String getOrderTransmitter() {
		return orderTransmitter;
	}
	public void setOrderTransmitter(String orderTransmitter) {
		this.orderTransmitter = orderTransmitter;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getSecondaryLocation() {
		return secondaryLocation;
	}
	public void setSecondaryLocation(String secondaryLocation) {
		this.secondaryLocation = secondaryLocation;
	}
	public String getStateProvince() {
		return stateProvince;
	}
	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getIteration() {
		return iteration;
	}
	public void setIteration(String iteration) {
		this.iteration = iteration;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getClinicLocation() {
		return clinicLocation;
	}
	public void setClinicLocation(String clinicLocation) {
		this.clinicLocation = clinicLocation;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getMainPhone() {
		return mainPhone;
	}
	public void setMainPhone(String mainPhone) {
		this.mainPhone = mainPhone;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipPostalCode() {
		return zipPostalCode;
	}
	public void setZipPostalCode(String zipPostalCode) {
		this.zipPostalCode = zipPostalCode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getClinicTimeZone() {
		return clinicTimeZone;
	}
	public void setClinicTimeZone(String clinicTimeZone) {
		this.clinicTimeZone = clinicTimeZone;
	}
	public String getLegalJurisdiction() {
		return legalJurisdiction;
	}
	public void setLegalJurisdiction(String legalJurisdiction) {
		this.legalJurisdiction = legalJurisdiction;
	}
	public String getClinicLanguage() {
		return clinicLanguage;
	}
	public void setClinicLanguage(String clinicLanguage) {
		this.clinicLanguage = clinicLanguage;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmNewPassword() {
		return confirmNewPassword;
	}
	public void setConfirmNewPassword(String confirmNewPassword) {
		this.confirmNewPassword = confirmNewPassword;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getElecExport() {
		return elecExport;
	}
	public void setElecExport(String elecExport) {
		this.elecExport = elecExport;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getReferenceTestCase() {
		return referenceTestCase;
	}
	public void setReferenceTestCase(String referenceTestCase) {
		this.referenceTestCase = referenceTestCase;
	}
	public String getSearchLocation1() {
		return SearchLocation1;
	}
	public void setSearchLocation1(String SearchLocation1) {
		this.SearchLocation1 = SearchLocation1;
	}
	public String getSearchLocatio2() {
		return SearchLocation2;
	}
	public void setSearchLocation2(String SearchLocation2) {
		this.SearchLocation2 = SearchLocation2;
	}
	public String getSearchLocatio3() {
		return SearchLocation3;
	}
	public void setSearchLocation3(String SearchLocation3) {
		this.SearchLocation3 = SearchLocation3;
	}
	public String getSearchLocatio4() {
		return SearchLocation4;
	}
	public void setSearchLocation4(String SearchLocation4) {
		this.SearchLocation4 = SearchLocation4;
	}
	public String getSearchLocatio5() {
		return SearchLocation5;
	}
	public void setSearchLocation5(String SearchLocation5) {
		this.SearchLocation5 = SearchLocation5;
	}
	
	//Rajesh Singaraj 12/01/2022
	public String getLengthyClinicLocationName() {
		return LengthyClinicLocationName;
	}
	public void setLengthyClinicLocationName(String LengthyClinicLocationName) {
		this.LengthyClinicLocationName = LengthyClinicLocationName;
	}
	public String getLengthyAddressField() {
		return LengthyAddressField;
	}
	public void setLengthyAddressField(String LengthyAddressField) {
		this.LengthyAddressField = LengthyAddressField;
	}
	public String getLengthyClinicCity() {
		return LengthyClinicCity;
	}
	public void setLengthyClinicCity(String LengthyClinicCity) {
		this.LengthyClinicCity = LengthyClinicCity;
	}
	public String getStateProvinceVerification() {
		return StateProvinceVerification;
	}
	public void setStateProvinceVerification(String StateProvinceVerification) {
		this.StateProvinceVerification = StateProvinceVerification;
	}
	public String getCountryVerification() {
		return CountryVerification;
	}
	public void setCountryVerification(String CountryVerification) {
		this.CountryVerification = CountryVerification;
	}	
	public String getTimeZoneVerification() {
		return TimeZoneVerification;
	}
	public void setTimeZoneVerification(String TimeZoneVerification) {
		this.TimeZoneVerification = TimeZoneVerification;
	}
	public String getLengthyEmailAddress() {
		return LengthyEmailAddress;
	}
	public void setLengthyEmailAddress(String LengthyEmailAddress) {
		this.LengthyEmailAddress = LengthyEmailAddress;
	}

	//Rajesh Singaraj -01/27/2022
	public String getPatientNames() {
		return PatientNames;
	}
	public void setPatientNames(String PatientNames) {
		this.PatientNames = PatientNames;
	}

	public String getPatientID() {
		return PatientID;
	}
	public void setPatientID(String PatientID) {
		this.PatientID = PatientID;
	}
	public String getFollowupDateID() {
		return FollowupDateID;
	}
	public void setFollowupDateID(String FollowupDateID) {
		this.FollowupDateID = FollowupDateID;
	}
	public String getCustomerApplicationID() {
		return CustomerApplicationID;
	}
	public void setCustomerApplicationID(String CustomerApplicationID) {
		this.CustomerApplicationID = CustomerApplicationID;
	}
	//Shafiya added for test case : 10.0Rev1_WA_UC013A-B01-01
	public String getSecondaryCountryCode() {
		return SecondaryCountryCode;
	}
	public void setSecondaryCountryCode(String secondaryCountryCode) {
		SecondaryCountryCode = secondaryCountryCode;
	}
	public String getSecondaryAreaCode() {
		return SecondaryAreaCode;
	}
	public void setSecondaryAreaCode(String secondaryAreaCode) {
		SecondaryAreaCode = secondaryAreaCode;
	}
	public String getSecondaryMainPhone() {
		return SecondaryMainPhone;
	}
	public void setSecondaryMainPhone(String secondaryMainPhone) {
		SecondaryMainPhone = secondaryMainPhone;
	}
	public String getFaxCountryCode() {
		return faxCountryCode;
	}
	public void setFaxCountryCode(String faxCountryCode) {
		this.faxCountryCode = faxCountryCode;
	}
	public String getFaxAreaCode() {
		return faxAreaCode;
	}
	public void setFaxAreaCode(String faxAreaCode) {
		this.faxAreaCode = faxAreaCode;
	}
	public String getFaxMainPhone() {
		return faxMainPhone;
	}
	public void setFaxMainPhone(String faxMainPhone) {
		this.faxMainPhone = faxMainPhone;
	}
	public String getTextMessage() {
		return textMessage;
	}
	public void setTextMessage(String textMessage) {
		this.textMessage = textMessage;
	}
	public String getCredentials() {
		return credentials;
	}
	public void setCredentials(String credentials) {
		this.credentials = credentials;
	}
}
