package com.test.qa.pojo;

public class AddSecLocation {
	
	private String name;
	private String hqFlg;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHqFlg() {
		return hqFlg;
	}
	public void setHqFlg(String hqFlg) {
		this.hqFlg = hqFlg;
	}
	

}
