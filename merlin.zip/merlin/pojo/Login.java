package com.test.qa.pojo;



public class Login {
	private String iteration;
	private String userName;
	private String password;
	private String customer;
	private String userType;
	private String mfa;

	private String resetPassword;
	private String Test;

	
	public String getResetPassword() {
		return resetPassword;
	}
	public void setResetPassword(String resetPassword) {
		this.resetPassword = resetPassword;

	
	}
	public String getMfa() {
		return mfa;
	}
	public void setMfa(String mfa) {
		this.mfa = mfa;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getIteration() {
		return iteration;
	}
	public void setIteration(String iteration) {
		this.iteration = iteration;
	}
	//Added by jais
		public void setUserType(String type) {
			this.userType = type;
		}
		public String getUserType() {
			return userType;
		}
		//end jais
		
		
		//mohan
		public String getTest() {
			return Test;
		}
		public void setTest(String test) {
			this.Test = test;
		}
}
