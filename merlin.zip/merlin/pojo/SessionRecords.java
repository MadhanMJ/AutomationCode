package com.test.qa.pojo;

public class SessionRecords {
	private Content content;
	private String encodedContent;
	private String signature;
	private String cloudVerificationId;
	private String id;
	private String signaturePartial;
	private String srwithoutpayloadsignature;
	
	public String getSignaturePartial() {
		return signaturePartial;
	}
	public void setSignaturePartial(String signaturePartial) {
		this.signaturePartial = signaturePartial;
	}
	public String getSrwithoutpayloadsignature() {
		return srwithoutpayloadsignature;
	}
	public void setSrwithoutpayloadsignature(String srwithoutpayloadsignature) {
		this.srwithoutpayloadsignature = srwithoutpayloadsignature;
	}
	
	public Content getContent() {
		return content;
	}
	public void setContent(Content content) {
		this.content = content;
	}
	public String getEncodedContent() {
		return encodedContent;
	}
	public void setEncodedContent(String encodedContent) {
		this.encodedContent = encodedContent;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getCloudVerificationId() {
		return cloudVerificationId;
	}
	public void setCloudVerificationId(String cloudVerificationId) {
		this.cloudVerificationId = cloudVerificationId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
