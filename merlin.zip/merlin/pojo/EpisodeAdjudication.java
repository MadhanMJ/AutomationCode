package com.test.qa.pojo;

public class EpisodeAdjudication {
	private String assessment;
	private String lastAccessedBy;
	private String lastAccessedOn;
	private String notes;
	private String episodeDateAndTime;
	private String episodeType;
	private String transmissionDateAndTime;
	
	public String getAssessment() {
		return assessment;
	}
	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}
	public String getLastAccessedBy() {
		return lastAccessedBy;
	}
	public void setLastAccessedBy(String lastAccessedBy) {
		this.lastAccessedBy = lastAccessedBy;
	}
	public String getLastAccessedOn() {
		return lastAccessedOn;
	}
	public void setLastAccessedOn(String lastAccessedOn) {
		this.lastAccessedOn = lastAccessedOn;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getEpisodeDateAndTime() {
		return episodeDateAndTime;
	}
	public void setEpisodeDateAndTime(String episodeDateAndTime) {
		this.episodeDateAndTime = episodeDateAndTime;
	}
	public String getEpisodeType() {
		return episodeType;
	}
	public void setEpisodeType(String episodeType) {
		this.episodeType = episodeType;
	}
	public String getTransmissionDateAndTime() {
		return transmissionDateAndTime;
	}
	public void setTransmissionDateAndTime(String transmissionDateAndTime) {
		this.transmissionDateAndTime = transmissionDateAndTime;
	}
	




}
