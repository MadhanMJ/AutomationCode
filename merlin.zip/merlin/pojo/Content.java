package com.test.qa.pojo;

public class Content {
	private String type;
	private String payload;
	private String fileName;
	private int workflowId;
	private String payloadLabel;
	private String recordId;
	private boolean lastSection;
	private Integer section;
	private String transmissionKey;
	private String randomSeed;
	private String payloadHashValue;
	private String patientAppIdentityRecord;
	private long appTime;
	private String azureId;
	private Integer userRecordId;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(int workflowId) {
		this.workflowId = workflowId;
	}
	public String getPayloadLabel() {
		return payloadLabel;
	}
	public void setPayloadLabel(String payloadLabel) {
		this.payloadLabel = payloadLabel;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public boolean isLastSection() {
		return lastSection;
	}
	public void setLastSection(boolean lastSection) {
		this.lastSection = lastSection;
	}
	public Integer getSection() {
		return section;
	}
	public void setSection(Integer section) {
		this.section = section;
	}
	public String getTransmissionKey() {
		return transmissionKey;
	}
	public void setTransmissionKey(String transmissionKey) {
		this.transmissionKey = transmissionKey;
	}
	public String getRandomSeed() {
		return randomSeed;
	}
	public void setRandomSeed(String randomSeed) {
		this.randomSeed = randomSeed;
	}
	public String getPayloadHashValue() {
		return payloadHashValue;
	}
	public void setPayloadHashValue(String payloadHashValue) {
		this.payloadHashValue = payloadHashValue;
	}
	public String getPatientAppIdentityRecord() {
		return patientAppIdentityRecord;
	}
	public void setPatientAppIdentityRecord(String patientAppIdentityRecord) {
		this.patientAppIdentityRecord = patientAppIdentityRecord;
	}
	public long getAppTime() {
		return appTime;
	}
	public void setAppTime(long appTime) {
		this.appTime = appTime;
	}
	public String getAzureId() {
		return azureId;
	}
	public void setAzureId(String azureId) {
		this.azureId = azureId;
	}
	public Integer getUserRecordId() {
		return userRecordId;
	}
	public void setUserRecordId(Integer userRecordId) {
		this.userRecordId = userRecordId;
	}
	
}

