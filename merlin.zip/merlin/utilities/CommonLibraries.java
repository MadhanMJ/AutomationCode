package com.test.qa.utilities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.azure.cosmos.implementation.apachecommons.lang.StringUtils;
import com.test.qa.extentReport.ExtentReport;

public class CommonLibraries extends DriverUtils{

	ExtentReport extentReport;
	public CommonLibraries(WebDriver driver, ExtentReport extentReport) {
		super(driver, extentReport);
		this.extentReport = extentReport;
		this.driver = driver;
	}

	String uiListItems = StringUtils.EMPTY;
	public final By LoadingIcon_OR = By.xpath("//*[@class='spinnerWrapper show']");
	public final String LoadingIcon_S = "Loading icon";
	
	
	
	//carmel
	public void VerifyTextinWebElementListAndClick (By element, String strElement, String strExpValue) throws Exception
	{
		uiListItems = StringUtils.EMPTY;
		boolean bFound = false;
		try {
			loading();
			scrollToViewWithoutReport(element, strElement);
			List<WebElement> options = driver.findElements(element);
			int iListSize =  options.size();
			if(iListSize>0) {
				for (int i = 0; i< iListSize; i++) {

					uiListItems = options.get(i).getAttribute("value").toString().trim();
					
					//extentReport.logger.info("Value retrieved from Web element list : " +uiListItems);
					if (uiListItems.contains(strExpValue)) 
						bFound = true;
						
					if (bFound = true) {
						options.get(i).click();
						extentReport.pass("Success - \"" + strExpValue + "\" is found in the value \"" +uiListItems + "\" in " + strElement);
						uiListItems = StringUtils.EMPTY;
						break;	
					}
				}
				
			} else {
				throw new AssertionError()	;				
				}
		} catch (AssertionError e) {
				
				extentReport.reportFail("\"" +strExpValue + "\" is not found in "+ strElement, CommonUtils.convertStackTraceToString(e));
				
				throw e;
		} catch (Exception e) {
			extentReport.reportFail("Failure - \"" + strExpValue + "\" is not found in the value \"" +uiListItems + "\" in "+ strElement, CommonUtils.convertStackTraceToString(e));
			throw new Exception(e.getMessage());
		}
	}

	
	//carmel
			public void VerifyTextinWebElementList (By element, String strElement, String strExpValue) throws Exception
			{
				uiListItems = StringUtils.EMPTY;
				boolean bFound = false;
				try {
				//	Thread.sleep(500);
					loading();
					scrollToViewWithoutReport(element, strElement);
					
					List<WebElement> options = driver.findElements(element);
					int iListSize =  options.size();
					if(iListSize>0) {
					//String[] uiListItems = new String [iListSize];
						for (int i = 0; i< iListSize; i++) {
	
							uiListItems = options.get(i).getText().toString().trim();
							
							//extentReport.logger.info("Value retrieved from Web element list : " +uiListItems);
							if (uiListItems.contains(strExpValue)) 
								bFound = true;
								
							if (bFound = true) {
								extentReport.pass("Success - \"" + strExpValue + "\" is found in the value \"" +uiListItems + "\" in " + strElement);
								//break;	
							}else {
								extentReport.reportFail("Failure - \"" + strExpValue + "\" is not found in the value \"" +uiListItems + "\" in "+ strElement);
							}
							uiListItems = StringUtils.EMPTY;
							
						}
						
					} else {
						//extentReport.reportFail("Failure - \"" + strExpValue + "\" is not found in the value \"" +uiListItems + "\" in "+ strElement);
						
						throw new AssertionError()	;				
						}
				} catch (AssertionError e) {
						
						extentReport.reportFail("\"" +strExpValue + "\" is not found in "+ strElement, CommonUtils.convertStackTraceToString(e));
						
						throw e;
				} catch (Exception e) {
					extentReport.reportFail("Failure - \"" + strExpValue + "\" is not found in the value \"" +uiListItems + "\" in "+ strElement, CommonUtils.convertStackTraceToString(e));
					throw new Exception(e.getMessage());
				}
			}
			
			
		//Carmel
		public void VerifyParticularTextinWebElementList (By element, String strElement, String strExpValue)
		{
			boolean bFound = false;
			try {
				Thread.sleep(500);
				loading();
				visibilityOfElementLocatedWithoutReport(element, strElement);
				elementToBeClickable(element, strElement);
				List<WebElement> options = driver.findElements(element);
				int iListSize =  options.size();
				//String[] uiListItems = new String [iListSize];
				for (int i = 0; i< iListSize; i++) {
					uiListItems = options.get(i).getText().toString().trim();
					
					//extentReport.logger.info("Value retrieved from Web element list : " +uiListItems);
					if (uiListItems.contains(strExpValue)) {
						bFound = true;
						break;
					}
					if (bFound == true) 
						extentReport.pass("Success - \"" + strExpValue + "\" is found in the value \"" +uiListItems + "\" in " + strElement);
					
				}
			
			} catch (Exception e) {
				extentReport.reportFail("Failure - \"" + strExpValue + "\" is not found in the value \"" +uiListItems + "\" in "+ strElement, CommonUtils.convertStackTraceToString(e));
				throw new WebDriverException(e.getMessage());
			}
		}
}
