package com.test.qa.utilities;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.test.qa.dataBase.DataBaseConnector;


public class QueryResults {
	
	DataBaseConnector dataBaseConnector = new DataBaseConnector();
	Map<String, String> customer = new HashMap<String,String>();
	Map<String, String> customerApp = new HashMap<String,String>();
	Map<String, String> patient = new HashMap<String,String>();
	Map<String, String> userRecord = new HashMap<String,String>();
	List<String> patientStatus = new ArrayList<String>();
	List<String> clinicUserStatus = new ArrayList<String>();
	ResultSet customerRecord, patientRecord = null;
	
	public Map<String,String> customerTable(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
			customer.put("city",customerRecord.getString("city"));
			customer.put("legal_jurisdiction",customerRecord.getString("legal_jurisdiction"));
			customer.put("language",customerRecord.getString("language"));
			customer.put("area_code",customerRecord.getString("area_code"));
			customer.put("main_phone",customerRecord.getString("main_phone"));
		}
		dataBaseConnector.closeConnection();
		return customer;
	}
	
	public Map<String,String> readStateProvince(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
			customer.put("state_province",customerRecord.getString("state_province"));
		}
		dataBaseConnector.closeConnection();
		return customer;
	}
	
	public Map<String,String> readCustomerId(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
			customer.put("customer_id",customerRecord.getString("customer_id"));
		}
		dataBaseConnector.closeConnection();
		return customer;
	}
	
	public Map<String,String> readCustomerType(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
			customer.put("customer_type",customerRecord.getString("customer_type"));
		}
		dataBaseConnector.closeConnection();
		return customer;
	}
	
	public Map<String,String> readCityName(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
			customer.put("name",customerRecord.getString("name"));
		}
		dataBaseConnector.closeConnection();
		return customer;
	}
	
	public Map<String,String> readCity(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
			customer.put("city",customerRecord.getString("city"));
		}
		dataBaseConnector.closeConnection();
		return customer;
	}

	//Poojitha - Validations of TC1234183
	public Map<String,String> customerTable_TC1234183(String query) throws SQLException, InterruptedException {
	ResultSet customerRecord = dataBaseConnector.executeQuery(query);
	while (customerRecord.next()) {
	customer.put("city",customerRecord.getString("city"));
	customer.put("legal_jurisdiction",customerRecord.getString("legal_jurisdiction"));
	customer.put("language",customerRecord.getString("language"));
	customer.put("area_code",customerRecord.getString("area_code"));
	customer.put("main_phone",customerRecord.getString("main_phone"));
	customer.put("logon_user_name",customerRecord.getString("logon_user_name"));
	customer.put("clinicName",customerRecord.getString("name"));
	customer.put("customerEmailAddress",customerRecord.getString("email_address"));
	customer.put("addressLine1",customerRecord.getString("street_address"));
	customer.put("addressLine2",customerRecord.getString("street_address2"));
	customer.put("stateCode",customerRecord.getString("State_Code"));
	customer.put("zipCode",customerRecord.getString("zip_code"));
	}
	dataBaseConnector.closeConnection();
	return customer;
	}
	//Ends here
	//Jeetendra - Validations of TC1234183
		public Map<String,String> customerTable_TC1238756(String query) throws SQLException, InterruptedException {
		ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		while (customerRecord.next()) {
		customer.put("customer_id",customerRecord.getString("customer_id"));
		customer.put("name",customerRecord.getString("name"));
		customer.put("create_userid",customerRecord.getString("create_userid"));
		customer.put("create_dtm",customerRecord.getString("create_dtm"));		
		}
		dataBaseConnector.closeConnection();
		return customer;
		}
		//Ends here
		//Poojitha - Validations for TC1244068
		public Map<String,String> patientTable_TC1244068_scenario1(String query) throws SQLException, InterruptedException {
			ResultSet patientRecord = dataBaseConnector.executeQuery(query);
			while (patientRecord.next()) {
			patient.put("first_name",patientRecord.getString("first_name"));
			patient.put("middle_name",patientRecord.getString("middle_name"));
			patient.put("last_name",patientRecord.getString("last_name"));
			}
			dataBaseConnector.closeConnection();
			return patient;
			}
		
		public Map<String,String> patientTable_TC1244068_scenario2(String query) throws SQLException, InterruptedException {
			ResultSet patientRecord = dataBaseConnector.executeQuery(query);
			while (patientRecord.next()) {
			patient.put("patient_num",patientRecord.getString("patient_num"));
			}
			dataBaseConnector.closeConnection();
			return patient;
			}
		//TC1238688 Validations
		public Map<String,String> patientTable_TC1238688(String query) throws SQLException, InterruptedException {
			ResultSet patientRecord = dataBaseConnector.executeQuery(query);
			while (patientRecord.next()) {
			patient.put("patient_ba_mist_threshold",patientRecord.getString("patient_ba_mist_threshold"));
			patient.put("patient_ba_nodc_threshold",patientRecord.getString("patient_ba_nodc_threshold"));
			patient.put("clinic_pbd_mist_threshold",patientRecord.getString("clinic_pbd_mist_threshold"));
			patient.put("clinic_pbd_nodc_threshold",patientRecord.getString("clinic_pbd_nodc_threshold"));
			}
			dataBaseConnector.closeConnection();
			return patient;
			}
			//Ends here
		
		//Vrushali - validation of TC1243597 Shafiya:changed method name to be generic
		public Map<String,String> getDDTAndWebAppVersionID(String query) throws SQLException, InterruptedException {
		       ResultSet customerRecord = dataBaseConnector.executeQuery(query);
		       while (customerRecord.next()) {
		              customerApp.put("ddt_version_id",customerRecord.getString("ddt_version_id"));
		              customerApp.put("webapp_version_id",customerRecord.getString("webapp_version_id"));
		       }
		       dataBaseConnector.closeConnection();
		       return customer;
		}
		
		public Map<String,String> deletedUserRecord(String query) throws SQLException, InterruptedException {
		ResultSet deleteUserRecord = dataBaseConnector.executeQuery(query);
		while(deleteUserRecord.next()) {
		userRecord.put("deleted_flg", deleteUserRecord.getString("deleted_flg"));
		}
		dataBaseConnector.closeConnection();
		return userRecord;
		}

		// Poojitha - TC1238456
		public Map<String, String> patientTable_TC1238456(String query) throws SQLException, InterruptedException {
			ResultSet patientRecord = dataBaseConnector.executeQuery(query);
			while (patientRecord.next()) {
				patient.put("adjudication_type_cd", patientRecord.getString("adjudication_type_cd"));
				patient.put("adjudication_by_userid", patientRecord.getString("adjudication_by_userid"));
				patient.put("adjudication_dtm", patientRecord.getString("adjudication_dtm"));
				patient.put("episode_note", patientRecord.getString("episode_note"));
				patient.put("user_record_id", patientRecord.getString("user_record_id"));
			}
			dataBaseConnector.closeConnection();
			return patient;
		}

		// Ends here
		// Shanmugapriya - TC1238457
		public Map<String, String> patientTable_TC1238457(String query) throws SQLException, InterruptedException {
			ResultSet patientRecord = dataBaseConnector.executeQuery(query);
			while (patientRecord.next()) {
				patient.put("adjudication_type_cd", patientRecord.getString("adjudication_type_cd"));
				patient.put("adjudication_by_userid", patientRecord.getString("adjudication_by_userid"));
				patient.put("adjudication_dtm", patientRecord.getString("adjudication_dtm"));
				patient.put("episode_note", patientRecord.getString("episode_note"));
				patient.put("user_record_id", patientRecord.getString("user_record_id"));
			}
			dataBaseConnector.closeConnection();
			return patient;
		}

}
