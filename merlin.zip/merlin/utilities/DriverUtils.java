package com.test.qa.utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;

public class DriverUtils {
	public WebDriver driver;
	public JavascriptExecutor js;
	public ExtentReport extentReport; 
	ExtentTest extentTest;

	static String callerClassName = new Exception().getStackTrace()[1].getClassName();
	public static Log log = new Log();

	public DriverUtils(WebDriver driver, ExtentReport extentReport) {
		this.driver = driver;
		this.extentReport = extentReport;
		js = (JavascriptExecutor) driver;

	}
	//static CommonUtils common=new CommonUtils();

	public  String WAIT1 = CommonUtils.properties.getProperty("WAITTIME");
	public long WAIT=Long.parseLong(WAIT1);

	public final By LoadingIcon_OR = By.xpath("//*[@class='spinnerWrapper show']");
	public final String LoadingIcon_S = "Loading icon";

	/*
	 * Author: Vinay Babu
	 * Date: 07 Dec 2021
	 * Purpose: For test case ICM_WA_CA600_ReportSetting_ICMEpisodes_01
	 * To click on one element from a list of elements.
	 */

	public void clickOnOneElementInSelectList(By Xpath, String elementName, String strSelectName) {
		try {

			Select select = new Select(driver.findElement(Xpath));
			List<WebElement> options = select.getOptions();

			scrollToViewWebElementWithoutReport(driver.findElement(Xpath), strSelectName);



			for (WebElement ele: options) {

				if (ele.getAttribute("value").contains(elementName)) {
					System.out.println(ele.getAttribute("value"));
					ele.click();
				}
			}





		} catch (Exception e) {
			extentReport.reportFail("Unable to select elements in list " + strSelectName ,
					CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public void maximizeWindow() {
		try {
			driver.manage().window().maximize();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void deleteAllCookies() {
		try {
			driver.manage().deleteAllCookies();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void getURL(String url) {
		try {
			driver.get(url);
			maximizeWindow();
		} catch (WebDriverException e) {
			log.error(e.getMessage());
			//throw new WebDriverException(e.getMessage());
		}
	}
	


	public void implicitWait(int waitTime) {
		try {
			driver.manage().timeouts().implicitlyWait(waitTime, TimeUnit.SECONDS);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void pageLoadTimeout(int waitTime) {
		try {
			driver.manage().timeouts().pageLoadTimeout(waitTime, TimeUnit.SECONDS);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void navigateBack() {
		try {
			driver.navigate().back();
			//carmel

		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void navigateForward() {
		try {
			driver.navigate().forward();
			//carmel

		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void refresh() {
		try {
			driver.navigate().refresh();
			//carmel

		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void switchToAlert() {
		try {
			driver.switchTo().alert();
		} catch (WebDriverException e) {
			extentReport.reportFail("Alert not found", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public void switchToDefaultContent() {
		try {
			//carmel
			driver.switchTo().defaultContent();
		} catch (WebDriverException e) {
			extentReport.reportFail("Switch to default content is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public String getTitle() {
		String title = "";
		try {
			title = driver.getTitle();
			//carmel
			if (!title.isEmpty())
				extentReport.pass("Title is \"" + title + "\"");
			//
			return title;

		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Title is empty \"" + title +"\"", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public String getCurrentURL() {
		String url = "";
		try {
			url = driver.getCurrentUrl();
			//carmel
			if (!url.isEmpty())
				extentReport.pass("Test URL \"" + url + "\"");
			return url;
		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Current URL is \"" + url +"\"", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}


	public void invisibilityOfElementLocated(By element) {
		WebDriverWait wait = new WebDriverWait(driver,WAIT);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(element));
	}

	/*
	 * Author: Carmel Vimala
	 * Purpose: This method is to verify if element is invisible and print both pass and fail statements in report
	 */
	public void invisibilityOfElementLocatedWithReport(By element, String strElement) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(element));
			extentReport.pass(strElement + " is not diplayed");
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement + " is diplayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/*
	 * Author: Carmel Vimala
	 * Purpose: This method is to verify if element is invisible and print only fail statements in report
	 */
	public void invisibilityOfElementLocatedWithoutReport(By element, String strElement) {
		try {
			//Thread.sleep(100);
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(element));
			//carmel
			//Thread.sleep(500);
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement + " is diplayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public void scrollToView(By Xpath) {
		try {
			WebElement element = driver.findElement(Xpath);
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			js.executeScript("window.scrollBy(0,-125)");
		}
		catch (Exception e ) {

		}
	}



	//carmel
	public void scrollToViewWithReport(By Xpath, String strElement) {
		try {

			WebElement element = driver.findElement(Xpath);
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			js.executeScript("window.scrollBy(0,-120)");
			extentReport.pass("Scroll to Webelement " +strElement + " is successful");
			//Thread.sleep(500);
		}
		catch (Exception e ) {
			extentReport.reportFail("Scroll to Webelement " +strElement + " is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void scrollToViewWithoutReport(By Xpath, String strElement) {
		try {

			WebElement element = driver.findElement(Xpath);
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			js.executeScript("window.scrollBy(0,-120)");
			//Thread.sleep(500);
		}
		catch (Exception e ) {
			extentReport.reportFail("Scroll to Webelement " +strElement + " is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}


	public void scrollToViewlist(WebElement webelement) {

		WebElement element = webelement;
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		js.executeScript("window.scrollBy(0,-120)");
	}

	//carmel - above method is modified
	public void scrollToViewWebElementWithoutReport(WebElement webelement,String strElement) {
		try {
			WebElement element = webelement;
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			js.executeScript("window.scrollBy(0,-125)");
			//Thread.sleep(500);
		}
		catch (Exception e ) {
			extentReport.reportFail("Scroll to Webelement " +strElement + " is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel - above method is modified
	public void scrollToViewWebElementWithReport(WebElement webelement,String strElement) {
		try {
			WebElement element = webelement;
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			js.executeScript("window.scrollBy(0,-120)");
			//Thread.sleep(500);
			extentReport.pass("Scroll to Webelement " +strElement + " is successful");
		}
		catch (Exception e ) {
			extentReport.reportFail("Scroll to Webelement " +strElement + " is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}



	public List<WebElement> findElementslist(By locator) throws InterruptedException {
		try {
			List<WebElement> element = driver.findElements(locator);
			return element;

		}

		catch (NoSuchElementException e) {
			throw new NoSuchElementException(e.getMessage());
		}
	}

	//carmel - for above method

	public List<WebElement> findElementslist(By locator, String strElement) {
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			elementToBeClickable(locator, strElement);
			List<WebElement> element = driver.findElements(locator);
			return element;

		} catch (NoSuchElementException e) {
			extentReport.reportFail(strElement + " is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new NoSuchElementException(e.getMessage());
		}
	}


	public String getPageSource() {
		String pageSource = "";
		try {
			pageSource = driver.getPageSource();
			return pageSource;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void navigateURL(String url) {
		try {
			driver.navigate().to(url);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void closeDriver() {
		try {
			driver.close();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public void getFullScreen() {
		try {
			driver.manage().window().fullscreen();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * 
	 * @param element
	 * @param value
	 */

	public void sendKeys(By element, String value) {
		try {

			clear(element);
			driver.findElement(element).sendKeys(value);

		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());

		}

	}


	//carmel
	public void sendKeys(By element, String strElement, String testvalue) {
		try {

			visibilityOfElementLocatedWithoutReport(element, strElement);
			elementToBeClickable(element, strElement);
			clear(element, strElement);
			driver.findElement(element).sendKeys(testvalue);
			extentReport.pass("Success - Value \"" +testvalue + "\" has been entered into the textfield : "+strElement +".");
		} catch (WebDriverException e) {
			extentReport.reportFail("Value " +testvalue + " has not been entered into the textfield : "+strElement +".", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}

	}

	public void clear(By element) {
		try {
			driver.findElement(element).click();
			driver.findElement(element).clear();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}

	}

	//carmel
	public void clear(By element, String strElement) {
		try {
			driver.findElement(element).click();
			driver.findElement(element).clear();
		} catch (WebDriverException e) {
			extentReport.reportFail("Clearing data from " + strElement+" webElement is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public void deleteContent(By element) {
		scrollToView(element);
		driver.findElement(element).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
	}

	//carmel
	public void deleteContent(By element, String strElement) {
		try { 
			scrollToViewWithoutReport(element, strElement);
			driver.findElement(element).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		} catch (WebDriverException e) {
			extentReport.reportFail("Control alt delete operation is not successful for webelement "+ strElement , CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}	
	}

	public void elementToBeClickable(By element) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.elementToBeClickable(element));

		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}

	}

	//carmel
	public void elementToBeClickable(By element, String strElement) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.elementToBeClickable(element));

		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not clickable", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}

	}

	public void click(char ctrlType, String clickElement) {
		try {
			String arg = clickElement;
			char type = ctrlType;
			WebElement item = null;
			switch (type) {
			case 'I':
				item = driver.findElement(By.id(arg));
				break;
			case 'L':
				item = driver.findElement(By.linkText(arg));
				break;
			case 'X':
				item = driver.findElement(By.xpath(arg));
				break;
			}
			if (item.isDisplayed()) {
				item.click();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	//Carmel
	public void click(char ctrlType, String clickElement, String StrElement) {
		try {
			String arg = clickElement;
			char type = ctrlType;
			WebElement item = null;
			switch (type) {
			case 'I':
				item = driver.findElement(By.id(arg));
				break;
			case 'L':
				item = driver.findElement(By.linkText(arg));
				break;
			case 'X':
				item = driver.findElement(By.xpath(arg));
				break;
			}
			if (item.isDisplayed()) {
				item.click();
				extentReport.pass("Click on " +StrElement + " is successful");
			}

		} catch (Exception e) {
			extentReport.reportFail("Click on " + StrElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}
//
	public void clickElement(By element) {
		try {

			if (driver.findElement(element).isDisplayed()) {
				scrollToView(element);
				driver.findElement(element).click();
			}
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}


	//carmel
	public void clickElement(By element, String strElement) {
		try {
			//loadingWithoutReport();
			visibilityOfElementLocatedWithoutReport(element, strElement);
			elementToBeClickable(element, strElement);
			driver.findElement(element).click();
			//loadingWithoutReport();
			System.out.println("");
			extentReport.pass("Click on " +strElement + " is successful");
		} catch (WebDriverException e) {
			extentReport.reportFail("Click on " + strElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void clickElementWithoutReport(By element, String strElement) {
		try {
			visibilityOfElementLocatedWithoutReport(element, strElement);
			elementToBeClickable(element, strElement);
			driver.findElement(element).click();
			//loading();
		} catch (WebDriverException e) {
			extentReport.reportFail("Click on " + strElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public Boolean visibilityOfElementLocated(By element) {
		Boolean visible = false;

		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			if (wait.until(ExpectedConditions.visibilityOfElementLocated(element)) != null) {
				visible = true;
				scrollToView(element);
			}
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		} catch (Exception e) {
			throw new FrameworkException(e.getMessage());

		}
		return visible;

	}

	//carmel
	public Boolean visibilityOfElementLocatedWithoutReport(By element, String strElement) {
		Boolean visible = false;
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			if (wait.until(ExpectedConditions.visibilityOfElementLocated(element)) != null) {
				visible = true;
			}
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not visible", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		} catch (Exception e) {
			extentReport.reportFail(strElement+" is not visible", CommonUtils.convertStackTraceToString(e));
			throw new FrameworkException(e.getMessage());

		}
		return visible;

	}

	//carmel
	public Boolean visibilityOfElementLocatedWithReport(By element, String strElement) {
		Boolean visible = false;
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			if (wait.until(ExpectedConditions.visibilityOfElementLocated(element)) != null) {
				visible = true;
				extentReport.pass("\"" +strElement + "\" is visible");
			}
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not visible");
			throw new WebDriverException(e.getMessage());
		} catch (Exception e) {
			extentReport.reportFail(strElement+" is not visible");
			throw new FrameworkException(e.getMessage());

		}
		return visible;

	}

	public Boolean verifyElement(By element) {
		Boolean visible = false;
		try {


			if (ExpectedConditions.visibilityOfElementLocated(element) != null) {
				visible = true;
				scrollToView(element);
			}

		} catch (Exception e) {
			visible = false;
		}
		return visible;

	}

	public Boolean verifyElementWithReport(By element, String strElement) {
		Boolean visible = false;
		try {


			if (ExpectedConditions.visibilityOfElementLocated(element) != null) {
				visible = true;
				scrollToView(element);
				extentReport.pass(strElement + " is visible");
			}

		} catch (Exception e) {
			visible = false;
			extentReport.reportFail(strElement+" is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return visible;

	}

	public Boolean verifyElementWithoutReport(By element, String strElement) {
		Boolean visible = false;
		try {


			if (ExpectedConditions.visibilityOfElementLocated(element) != null) {
				visible = true;
				scrollToView(element);
			}

		} catch (Exception e) {
			visible = false;
			extentReport.reportFail(strElement+" is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return visible;

	}

	/**
	 * method to wait for presence of element located
	 * 
	 * @param element Element to be identified
	 */
	public void presenceOfElementLocated(By element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.presenceOfElementLocated(element));

		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());

		}
	}
	public void presenceOfElementLocatedWithReport(By element, String strElement) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			extentReport.pass(strElement + " is displayed");
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());

		}
	}
	
	

	public void presenceOfElementLocatedWithoutReport(By element, String strElement) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.presenceOfElementLocated(element));

		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());

		}
	}



	/**
	 * method to wait for pageLoad
	 */
	public void waitForPageLoad() {
		String pageLoadStatus;
		JavascriptExecutor js;
		try {
			do {
				js = (JavascriptExecutor) driver;
				pageLoadStatus = (String) js.executeScript("return document.readyState");
			} while (!pageLoadStatus.equals("complete"));
		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Page load is not completed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public void loading()
	{

		invisibilityOfElementLocated(LoadingIcon_OR);
	}

	public void loadingWithoutReport()
	{
		invisibilityOfElementLocated(LoadingIcon_OR);
	}

	//carmel
	public void waitForPageLoadingWithReport()
	{
		invisibilityOfElementLocatedWithoutReport(LoadingIcon_OR, LoadingIcon_S);
	}



	/**
	 * method to quit driver
	 * 
	 * @param driver to be quit
	 */
	public void quitDriver(WebDriver driver) {
		try {
			driver.quit();
		} catch (WebDriverException e) {
			extentReport.reportFail("Quitting the driver is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method for finding element
	 * 
	 * @param locator element to be identified
	 * @return WebElement if it is available
	 */

	//commented by carmel
	/*public WebElement findElement(String locator) {
		try {
			WebElement element = driver.findElement(By.xpath(locator));
			return element;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}*/


	/*
	 * Author: Vinay Babu 
	 * Date: 06 Dec 2021. 
	 * Added the below method "sendspecialKeysOnPage" to send special keys like escape on the web page when required.
	 * Was needed in one test cases.
	 */


	public void sendspecialKeysOnPage(String keys) {
		Actions action = new Actions(driver);
		if (keys.equalsIgnoreCase("escape")) {
			action.sendKeys(Keys.ESCAPE).perform();
		}
		// Added by Jitendra
		if (keys.equalsIgnoreCase("Tab")) {
			action.sendKeys(Keys.TAB).perform();
		}
		if(keys.equalsIgnoreCase("Enter")) {
			action.sendKeys(Keys.ENTER).perform();
		}
		
	}


	/**
	 * method to get the text of element
	 * 
	 * @param element to be identified
	 * @return text value of the element
	 */
	public String getText(By element) {
		try {
			visibilityOfElementLocated(element);
			String text = driver.findElement(element).getText();
			return text;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public String getText(By element, String strElement) {
		try {
			visibilityOfElementLocated(element);
			String text = driver.findElement(element).getText();
			extentReport.pass("Getting the text is successful from webelement " +strElement+ " and the retrieved text is \""+text+"\"");
			return text;
		} catch (WebDriverException e) {

			extentReport.reportFail("Getting the text is not successful from webelement " +strElement, CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to get the size of Elements
	 * 
	 * @param element to be identified
	 * @return size of the element
	 */
	public int getSizeOfElements(By element) {
		try {
			int size = driver.findElements(element).size();
			return size;
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException(e.getMessage());
		}
	}

	//carmel
	public int getSizeOfElements(By element, String strElement) {
		try {
			int size = driver.findElements(element).size();
			return size;
		} catch (NoSuchElementException e) {
			extentReport.reportFail("Getting the element size is not successful for webelement " +strElement, CommonUtils.convertStackTraceToString(e));
			throw new NoSuchElementException(e.getMessage());
		}
	}

	/**
	 * method to navigate to specified page
	 * 
	 * @param url navigation url
	 */
	//Carmel
	public void navigate(String url) {
		try {
			driver.navigate().to(url);
			extentReport.pass("Navigation to Web URL is successful - " + url);
		} catch (WebDriverException e) {
			extentReport.reportFail("Navigation to web URL is not successful - " +url, CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to click on an element with action class
	 * 
	 * @param element to be clicked
	 */
	public void clickOnElementUsingActions(By element) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(element));
			actions.click().perform();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//Carmel
	public void clickOnElementUsingActions(By element, String strElement) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(element));
			actions.click().perform();
			extentReport.pass("Click on " +strElement + " is successful");
		} catch (WebDriverException e) {
			extentReport.reportFail("Click on " + strElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}


	/**
	 * method to click on an element using javascript
	 * 
	 * @param element to be clicked
	 * @throws InterruptedException 
	 */
	public void clickOnElementUsingJs(By element) throws InterruptedException {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement webElement = driver.findElement(element);
			waitForLoading();
			js.executeScript("arguments[0].click();", webElement);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}
//ChandraMohan.S
	public void clickOnElementUsingActionClass(By element) throws InterruptedException {
		try {
			Actions builder = new Actions(driver);
			WebElement webElement = driver.findElement(element);
			Action seriesOfActions = builder.moveToElement(webElement).click().build();
			seriesOfActions.perform() ;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}
	//carmel
	public void clickOnElementUsingJs(By element, String strElement) {
		try {
			loadingWithoutReport();
			visibilityOfElementLocatedWithoutReport(element, strElement);
			elementToBeClickable(element, strElement);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement webElement = driver.findElement(element);
			js.executeScript("arguments[0].click();", webElement);
			extentReport.pass("Click on " +strElement + " is successful");
		} catch (WebDriverException e) {
			extentReport.reportFail("Click on " + strElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method verify whether element is present on screen
	 * 
	 * @param targetElement element to be present
	 * @return true if element is present else throws exception
	 * @throws InterruptedException Thrown when a thread is waiting, sleeping, or
	 *                              otherwise occupied, and the thread is
	 *                              interrupted, either before or during the
	 *                              activity.
	 */
	public Boolean isElementPresent(By targetElement) throws InterruptedException {
		try {

			Boolean isPresent = driver.findElements(targetElement).size() > 0;
			if(isPresent)
				scrollToView(targetElement);
			return isPresent;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	public Boolean isElementPresent(By targetElement, String strElement) {
		try {
			//scrollToViewWithoutReport(targetElement, strElement);
			Boolean isPresent = driver.findElements(targetElement).size() > 0;
			if(isPresent)
				scrollToViewWithoutReport(targetElement, strElement);
			return isPresent;
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement + " webElement is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}
	public Boolean isElementPresentwithoutException(By targetElement, String strElement) {
		Boolean isPresent = driver.findElements(targetElement).size() > 0;
		if(isPresent)
			scrollToViewWithoutReport(targetElement, strElement);
		return isPresent;

	}
	/**
	 * method verify whether element is not present on screen
	 * 
	 * @param targetElement element not to be present
	 * @return true if element is not present else throws exception
	 * @throws InterruptedException Thrown when a thread is waiting, sleeping, or
	 *                              otherwise occupied, and the thread is
	 *                              interrupted, either before or during the
	 *                              activity.
	 */
	public Boolean isElementNotPresent(By targetElement) throws InterruptedException {
		try {
			Boolean isPresent = (driver.findElements(targetElement).size() == 0);
			System.out.println(isPresent);
			return isPresent;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public Boolean isElementNotPresentWithoutReport(By targetElement, String strElement) {
		try {
			Boolean isPresent = (driver.findElements(targetElement).size() == 0);
			return isPresent;
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement + " webElement is displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	public Boolean isElementNotPresentWithoutexception(By targetElement, String strElement) {

		Boolean isPresent = (driver.findElements(targetElement).size() == 0);
		return isPresent;

	}
	//carmel
	public Boolean isElementNotPresentWithReport(By targetElement, String strElement) {
		try {
			Boolean isPresent = (driver.findElements(targetElement).size() == 0);
			extentReport.pass(strElement + " is not displayed");
			return isPresent;
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement + " webElement is displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to wait for an element to be clickable
	 * 
	 * @param targetElement element to be clickable
	 * @return true if element is clickable else throws TimeoutException
	 */
	public boolean waitForElementToBeClickable(By targetElement) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.elementToBeClickable(targetElement));
			return true;
		} catch (TimeoutException e) {
			System.out.println("Element is not clickable: " + targetElement);
			System.out.println();
			System.out.println(e.getMessage());
			throw new TimeoutException();

		}
	}

	// CARMEL
	public boolean waitForElementToBeClickable(By targetElement, String strElement) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.elementToBeClickable(targetElement));
			return true;
		} catch (TimeoutException e) {
			extentReport.reportFail(strElement+" is not clickable", CommonUtils.convertStackTraceToString(e));
			throw new TimeoutException();

		}
	}

	/**
	 * method to wait for an element until it is invisible
	 * 
	 * @param targetElement element to be invisible
	 * @return true if element gets invisible else throws TimeoutException
	 */
	public boolean waitForInvisibility(By targetElement) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(targetElement));
			return true;
		} catch (TimeoutException e) {
			System.out.println("Element is still visible: " + targetElement);
			System.out.println();
			System.out.println(e.getMessage());
			throw new TimeoutException();
		}
	}

	//carmel
	public boolean waitForInvisibilityWithoutreport(By targetElement, String strElement) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(targetElement));
			return true;
		} catch (TimeoutException e) {
			extentReport.reportFail(strElement+" is Still visible", CommonUtils.convertStackTraceToString(e));
			throw new TimeoutException();

		}
	}

	//carmel
	public boolean waitForInvisibilityWithreport(By targetElement, String strElement) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(targetElement));
			extentReport.pass(strElement + " is not visible");
			return true;
		} catch (TimeoutException e) {
			extentReport.reportFail(strElement+" is Still visible", CommonUtils.convertStackTraceToString(e));
			throw new TimeoutException();

		}
	}

	/**
	 * method to find an element
	 * 
	 * @param locator element to be found
	 * @return WebElement if found else throws NoSuchElementException
	 */
	public WebElement findElement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			return element;
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException(e.getMessage());
		}
	}

	//carmel
	public WebElement findElement(By locator, String strElement) {
		try {
			WebElement element = driver.findElement(locator);
			return element;
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement + " is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to find all the elements of specific locator
	 * 
	 * @param locator element to be found
	 * @return return the list of elements if found else throws
	 *         NoSuchElementException
	 * @throws InterruptedException
	 */
	public List<WebElement> findElements(By locator, String arg1) throws InterruptedException {
		try {
			List<WebElement> element = driver.findElements(locator);
			for (WebElement iter : element) {
				if (iter.getText().equalsIgnoreCase(arg1)) {
					iter.click();
					break;
				}
			}
			return element;
		}

		catch (NoSuchElementException e) {
			throw new NoSuchElementException(e.getMessage());
		}
	}



	/**
	 * method to match value with list elements and click on it
	 * 
	 * @param fetchedListElements List of fetched value
	 * @param valueToBeMatched    value to be matched with list elements
	 */
	public void clickOnMatchingValue(List<WebElement> fetchedListElements, String valueToBeMatched) {

		try {
			for (WebElement element : fetchedListElements) {
				if (element.getText().trim().equalsIgnoreCase(valueToBeMatched.trim())) {
					element.click();
					return;
				}
			}
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void clickOnMatchingValue(List<WebElement> fetchedListElements, String valueToBeMatched, String strElement) {

		try {
			for (WebElement element : fetchedListElements) {
				if (element.getText().equalsIgnoreCase(valueToBeMatched)) {
					element.click();
					extentReport.pass("Click on " +strElement + " is successful");
					return;
				}
			}
		} catch (WebDriverException e) {
			extentReport.reportFail("Click on " + strElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to check value contained in list elements and click on it
	 * 
	 * @param fetchedListElements List of fetched value
	 * @param valueToBeContained  value to be contained in list elements
	 */
	public void clickOnContainingValue(List<WebElement> fetchedListElements, String valueToBeContained) {
		try {
			for (WebElement element : fetchedListElements) {
				if (element.getText().toLowerCase().contains(valueToBeContained.toLowerCase())) {
					element.click();
					return;
				}
			}
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void clickOnContainingValue(List<WebElement> fetchedListElements, String valueToBeContained, String strElement) {
		try {
			for (WebElement element : fetchedListElements) {
				if (element.getText().toLowerCase().contains(valueToBeContained.toLowerCase())) {
					element.click();
					extentReport.pass("Click on " +strElement + " is successful");
					return;
				}
			}
		} catch (WebDriverException e) {
			extentReport.reportFail("Click on " + strElement+" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to accept alert, exception is thrown if no alert is present
	 */
	//carmel
	public void acceptAlert() {
		try {

			Alert alert = driver.switchTo().alert();
			alert.accept();
			//extentReport.pass("Accepting alert is successful");
		} catch (NoAlertPresentException e) {
			//extentReport.reportFail("Accepting alert is not successful", CommonUtils.convertStackTraceToString(e));
			throw new NoAlertPresentException();
		}
	}

	/**
	 * method to dismiss alert, exception is thrown if no alert is present
	 */
	public void dismissAlert() {
		try {

			Alert alert = driver.switchTo().alert();
			alert.dismiss();
			extentReport.pass("Alert dismiss is successful");
		} catch (NoAlertPresentException e) {
			extentReport.reportFail("Alert dismiss is not successful", CommonUtils.convertStackTraceToString(e));
			throw new NoAlertPresentException();
		}
	}

	/**
	 * method to send value to the alert
	 * 
	 * @param value to be passed in to the alert
	 */
	//carmel - need to check with team
	public void sendKeysAcceptAlert(String value) {
		try {
			Alert alert = driver.switchTo().alert();
			alert.sendKeys(value);
			alert.accept();

		} catch (NoAlertPresentException e) {
			throw new NoAlertPresentException();
		}
	}

	/**
	 * method to get message text of alert
	 * 
	 * @return message text which is displayed
	 */
	public String getAlertText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			extentReport.pass("Getting text from alert is successful");
			return alertText;
		} catch (NoAlertPresentException e) {
			extentReport.reportFail("Getting text from alert is not successful", CommonUtils.convertStackTraceToString(e));
			throw new NoAlertPresentException();
		}
	}

	/**
	 * method to verify if alert is present
	 * 
	 * @return returns true if alert is present else false
	 */
	//carmel commented
	/*public boolean isAlertPresent() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			throw new NoAlertPresentException();
		}
	}*/

	//carmel
	public boolean isAlertPresent() {
		boolean foundAlert = false;
		try {

			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert();
			foundAlert = true;
			extentReport.pass("Alert is present");
		} catch (NoAlertPresentException e) {
			foundAlert = false;
			extentReport.reportFail("Alert is not present",CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return foundAlert;
	}

	/**
	 * method to select a value from dropdown with index
	 * 
	 * @param selectLocator          element with select tag
	 * @param valueToBeSelectedindex index to be selected
	 */
	public void selectValuefromDropdownviaIndex(By selectLocator, int valueToBeSelectedindex) {
		try {
			Select selectFromDropdown = new Select(findElement(selectLocator));
			selectFromDropdown.selectByIndex(valueToBeSelectedindex);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}

	}

	//carmel
	public void selectValuefromDropdownviaIndex(By selectLocator, int valueToBeSelectedindex, String strElement) {
		try {

			visibilityOfElementLocatedWithoutReport(selectLocator, strElement);
			Select selectFromDropdown = new Select(findElement(selectLocator,strElement));
			selectFromDropdown.selectByIndex(valueToBeSelectedindex);
			extentReport.pass("Selecting value with index \"" +valueToBeSelectedindex+ "\" from dropdown \""+strElement + "\" is successful");
		} catch (WebDriverException e) {
			extentReport.reportFail("Selecting value with index \"" +valueToBeSelectedindex+ "\" from dropdown \""+strElement + "\" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}

	}

	/**
	 * method to select the drop down via visible Text
	 * 
	 * @param selectLocator element to be identified
	 * @param value         to be passed as reference to select drop down
	 */
	public void selectValuefromDropdownviaVisibleText(By selectLocator, String value) {
		try {
			Select ValuefromDropdown = new Select(driver.findElement(selectLocator));
			ValuefromDropdown.selectByVisibleText(value);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void selectValuefromDropdownviaVisibleText(By selectLocator, String value, String strElement) {
		try {

			visibilityOfElementLocatedWithoutReport(selectLocator, strElement);
			Select ValuefromDropdown = new Select(driver.findElement(selectLocator));
			ValuefromDropdown.selectByVisibleText(value);
			extentReport.pass("Selecting value \"" +value+ "\" from dropdown \""+strElement + "\" is successful");
		} catch (WebDriverException e) {
			extentReport.reportFail("Selecting value \"" +value+ "\" from dropdown \""+strElement + "\" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to select the drop down via value
	 * 
	 * @param selectLocator element to be identified
	 * @param value         to be passed as reference to select drop down
	 */
	public void selectValuefromDropdownviaValue(By selectLocator, String value) {
		try {
			Select ValuefromDropdown = new Select(driver.findElement(selectLocator));
			ValuefromDropdown.selectByValue(value);
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public void selectValuefromDropdownviaValue(By selectLocator, String value, String strElement) {
		try {

			visibilityOfElementLocatedWithoutReport(selectLocator, strElement);
			Select ValuefromDropdown = new Select(driver.findElement(selectLocator));
			ValuefromDropdown.selectByValue(value);
			extentReport.pass("Selecting value \"" +value+ "\" from dropdown \""+strElement + "\" is successful");
		} catch (WebDriverException e) {
			extentReport.reportFail("Selecting value \"" +value+ "\" from dropdown \""+strElement + "\" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to switch to frame via Index
	 * 
	 * @param index frame index
	 */
	public void switchToFrameViaIndex(int index) {
		try {
			driver.switchTo().frame(index);

		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Switching to frame via index\"" +index + "\" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to switch to frame via Name or Id
	 * 
	 * @param value frame name or Id
	 */
	public void switchToFrameViaNameOrId(String value) {
		try {

			driver.switchTo().frame(value);
		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Switching to frame via value \"" +value + "\" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to switch to frame via web element
	 * 
	 * @param element to be identified
	 */
	public void switchToFrameViaWebElement(WebElement element) {
		try {

			driver.switchTo().frame(element);
		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Switching to frame with value \"" +element + "\" is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method for switching to parent frame
	 */
	public void switchToParentFrame() {
		try {

			driver.switchTo().parentFrame();
		} catch (WebDriverException e) {
			//carmel
			extentReport.reportFail("Switching to parent frame is not successful", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to check the element is enabled
	 * 
	 * @param locator element to be identified
	 * @return true if element is enabled else false
	 */
	public Boolean isEnabled(By locator) {
		try {
			return driver.findElement(locator).isEnabled();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public Boolean isEnabledWithReport(By locator, String strElement) {
		boolean enabledStatus = false;
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			enabledStatus = driver.findElement(locator).isEnabled();
			if (enabledStatus==true)
				extentReport.pass(strElement + " is enabled");
			else
				extentReport.reportFail(strElement +" is not enabled");
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not enabled", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return enabledStatus;
	}

	//carmel
	public Boolean isEnabledWithoutReport(By locator, String strElement) {
		boolean enabledStatus = false;
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			enabledStatus = driver.findElement(locator).isEnabled();
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not enabled", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return enabledStatus;
	}

	public Boolean isDisplayed(By locator) {
		try {
			return driver.findElement(locator).isDisplayed();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	/*
	 * Author: Vinay Babu
	 * Date: 06 Dec 2021
	 * 
	 * Added the below function "isDisplayedWithReportScreenshot" to have sreenshot taken when checked whether element is displayed or not.
	 * Needed it in few test cases.
	 */

	public Boolean isDisplayedWithReportScreenshot(By locator, String elementName) {
		try {
			if(driver.findElement(locator).isDisplayed() ) {
				extentReport.reportPass("Element \"" + elementName + "\" is displayed");
				return driver.findElement(locator).isDisplayed();
			} else {
				extentReport.reportFail("Element \"" + elementName + "\" is NOT displayed");
				return driver.findElement(locator).isDisplayed();
			}
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}


	//carmel
	public Boolean isDisplayedWithReport(By locator, String strElement) {
		boolean enabledStatus = false;
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			enabledStatus = driver.findElement(locator).isDisplayed();
			if (enabledStatus==true)
				extentReport.pass(strElement + " is enabled");
			else
				extentReport.reportFail(strElement +" is not enabled");
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return enabledStatus;
	}

	//carmel
	public Boolean isDisplayedWithoutReport(By locator, String strElement) {
		boolean enabledStatus = false;
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			enabledStatus = driver.findElement(locator).isDisplayed();
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not displayed", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return enabledStatus;
	}

	public Boolean isSelected(By locator) {
		try {
			return driver.findElement(locator).isSelected();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel
	public Boolean isSelectedWithReport(By locator, String strElement) {
		boolean enabledStatus = false;
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			enabledStatus = driver.findElement(locator).isSelected();
			if (enabledStatus==true)
				extentReport.pass(strElement + " is selected");
			else
				extentReport.reportFail(strElement +" is not selected");
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not selected", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return enabledStatus;
	}

	//carmel
	public Boolean isSelectedWithoutReport(By locator, String strElement) {
		boolean enabledStatus = false;
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			enabledStatus = driver.findElement(locator).isSelected();
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not selected", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return enabledStatus;
	}
	/**
	 * method to submit the form
	 * 
	 * @param locator element to be identified for submit
	 */
	public void submit(By locator) {
		try {
			driver.findElement(locator).submit();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//carmel

	public void submit(By locator, String strElement) {
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			driver.findElement(locator).submit();
			extentReport.pass(strElement + " is submitted");
		} catch (WebDriverException e) {
			extentReport.reportFail(strElement+" is not submitted", CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method for getting attribute value
	 * 
	 * @param locator   element to be identified
	 * @param attribute value for fetching attribute details
	 * @return attribute value string
	 * @throws InterruptedException 
	 */
	public String getAttribute(By locator, String attribute) throws InterruptedException {
		String attributeValue = "";
		try {
			if (isElementPresent(locator))
			{
				attributeValue = driver.findElement(locator).getAttribute(attribute);
			}
			return attributeValue;
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	//Carmel
	public String getAttributeWithoutReport(By locator, String attribute,String strElement) throws InterruptedException {
		String attributeValue = "";
		try {

			visibilityOfElementLocatedWithoutReport(locator, strElement);
			attributeValue = driver.findElement(locator).getAttribute(attribute);
			
		} catch (WebDriverException e) {
			extentReport.reportFail("Getting attribute for  " +strElement + " is not successful and attributes are: "+attributeValue, CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return attributeValue;
	}

	//Carmel
	public String getAttributeWithReport(By locator, String attribute,String strElement) throws InterruptedException {
		String attributeValue = "";
		try {
			visibilityOfElementLocatedWithoutReport(locator, strElement);
			attributeValue = driver.findElement(locator).getAttribute(attribute);
			extentReport.pass("Getting attribute for  " +strElement + " is successful and attributes are: "+attributeValue);
		} catch (WebDriverException e) {
			extentReport.reportFail("Getting attribute for  " +strElement + " is not successful and attributes are: "+attributeValue, CommonUtils.convertStackTraceToString(e));
			throw new WebDriverException(e.getMessage());
		}
		return attributeValue;
	}

	/**
	 * method for waiting for alert
	 * 
	 * @return true if alert present else false
	 */
	public boolean waitForAlertPresent() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT);
			wait.until(ExpectedConditions.alertIsPresent());
			return true;
		} catch (TimeoutException e) {
			System.out.println("Alert not present");
			System.out.println();
			System.out.println(e.getMessage());
			throw new TimeoutException();

		}
	}

	/**
	 * method for house over
	 * 
	 * @param locator element to be located
	 */
	public void mouseHover(By locator) {
		try {
			Actions actions = new Actions(driver);
			WebElement mouseHover = driver.findElement(locator);
			actions.moveToElement(mouseHover);
			actions.perform();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method for drag and drop
	 * 
	 * @param sourceLocator source element from drag
	 * @param targetLocator target element to drop
	 */
	public void dragAndDrop(By sourceLocator, By targetLocator) {
		try {
			WebElement source = driver.findElement(sourceLocator);
			WebElement destination = driver.findElement(targetLocator);
			Actions actions = new Actions(driver);
			actions.dragAndDrop(source, destination).build().perform();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method for right click on element
	 * 
	 * @param locator element to be found
	 */
	public void rightClick(By locator) {
		try {
			Actions actions = new Actions(driver);
			WebElement rightClick = driver.findElement(locator);
			actions.contextClick(rightClick);
			actions.perform();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method for double click on element
	 * 
	 * @param locator element to be found
	 */
	public void doubleClick(By locator) {
		try {
			Actions actions = new Actions(driver);
			WebElement doubleClick = driver.findElement(locator);
			actions.doubleClick(doubleClick);
			actions.perform();
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}

	/**
	 * method to switch to window
	 * 
	 * @param title for switching based on the title value
	 */
	public void switchToWindow(String title) {
		try {
			Set<String> allWindows = driver.getWindowHandles();
			for (String eachWindow : allWindows) {
				driver.switchTo().window(eachWindow);
				if (driver.getTitle().equals(title)) {

					break;
				}
			}
		} catch (NoSuchWindowException e) {
			throw new NoSuchWindowException(e.getMessage());
		} catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}

	}

	/**
	 * method to verify url
	 * 
	 * @param url for verification
	 * @return boolean true if url matches else false
	 */
	public boolean verifyUrl(String url) {
		if (driver.getCurrentUrl().equals(url)) {
			return true;
		}
		return false;
	}

	/**
	 * method to get list of options available in dropdown
	 * @param locator element to be identified 
	 * @return options available in the drop down
	 */
	public List<WebElement> getOptions(By locator) {
		scrollToView(locator);
		Select dropdown = new Select(findElement(locator));
		List<WebElement> options = dropdown.getOptions();
		return options;
	}
	public ArrayList DropdowngetOptions(By locator,By options) {
		scrollToView(locator);
		driver.findElement(locator).click();
		ArrayList arr = new ArrayList(); 
		int size=driver.findElements(options).size();
		for(int i=0;i<size;i++)
		{
			String value=driver.findElements(options).get(i).getText().trim();
			arr.add(value);
		}

		return arr;
	}

	public void waitForLoading() throws InterruptedException {
		Thread.sleep(4000);
	}

	public void scrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
	}

	public void scrollUp() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-50)");
	}

	public List<WebElement> findElements(By locator) throws InterruptedException {
		try {
			List<WebElement> element = driver.findElements(locator);
			return element;
		}

		catch (NoSuchElementException e) {
			throw new NoSuchElementException(e.getMessage());
		}
	}

	public Boolean isDisplayedFlag(By locator) {
		boolean isDisp=false;

		getSizeOfElements(locator);
		if(getSizeOfElements(locator)>0) {
			if(driver.findElement(locator).isDisplayed()) {
				isDisp= true;	
			}			
		}

		/*
		 * try { isDisp=driver.findElement(locator).isDisplayed(); } catch
		 * (WebDriverException e) { throw new WebDriverException(e.getMessage());

		} */
		return isDisp;
	}

	public Boolean isAttributeAvailable(By locator, String attribute) throws InterruptedException {
		Boolean attributeCheck = null;
		try {
			if (isElementPresent(locator)) {
				String value = driver.findElement(locator).getAttribute(attribute);
				if (value != null)
					attributeCheck = true;
				else
					attributeCheck=false;
			}

		} catch (Exception e) {
			attributeCheck = false;
		}
		return attributeCheck;
	}

}
