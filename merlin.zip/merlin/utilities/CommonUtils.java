package com.test.qa.utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.test.qa.assertions.Assertions;
import com.test.qa.dataBase.DataBaseConnector;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.RestAssured;
import io.restassured.response.Response;


public class CommonUtils{

	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
		System.setProperty("timestamp", dateFormat.format(new Date()));
	}

	public static WebDriver driver;
	public DriverUtils driverScript;
	//public ExtentReport extentReport;
	public static ExtentReport extentReport;
	public static Assertions assertion ;
	public static Assertions softAssert;
	public static Properties properties = loadFromPropertyFile();
	private final By userNameTextBox = By.xpath("//*[@id='signInName']");
	private final By passwordTextBox = By.xpath("//*[@id='password']");
	private final static By navigationButton =By.xpath("//*[@data-icon-name='GlobalNavButton']");
	private final static By emailTextBox = By.xpath("//input[@type='email']");
	private final static By submitButton = By.xpath("//input[@type='submit']");
	private final static By passwordBox = By.xpath("//input[@name='passwd']");
	private final static By allAbbottCustomers_OR= By.xpath("//span[text()='All Abbott Customers']");
	private final static String allAbbottCustomers_S= "All Abbott Customers link";
	private final static By addCustomer_OR= By.xpath("//button[@id=\"btn_pcs-home_add-customer\"]/span");
	private final static String addCustomer_S= "Add Customer Button";
	

	private final static By OTP_FOLDER = By.xpath("//div[@title='OTP']//span[text()='OTP']");
	private final static By readOTP = By.xpath("//span[contains(text(),'Your code is:') and @id=\"x_BodyPlaceholder_UserVerificationEmailBodySentence2\"]");
	public final static String browserType = properties.getProperty("BROWSER");	
	public final static String chromeDriverPath = properties.getProperty("CHROME_DRIVER_PATH");
	public final static String ieDriverPath = properties.getProperty("IE_DRIVER_PATH");
	public final static String firefoxDriverPath = properties.getProperty("FIREFOX_DRIVER_PATH");
	public final static String msEdgeDriverPath = properties.getProperty("MSEDGE_DRIVER_PATH");
	public final static String iterationMode = properties.getProperty("ITERATION_MODE");
	public final static String url =properties.getProperty("URL");
	public final static String adminUrl =properties.getProperty("ADMINURL");
	public final static String BEARER_TOKEN = properties.getProperty("BEARER_TOKEN");
	public final static String OUTLOOK_URL = properties.getProperty("OUTLOOK_URL");
	public final static String OTP_LOGIN = properties.getProperty("OTP_LOGIN");
	public final static String dataPath = properties.getProperty("DATA_PATH");
	public final static String SAINTS_EVIDENCE = properties.getProperty("SAINTS_EVIDENCE");
	public final static String SCREENSHOT_PATH = properties.getProperty("SCREENSHOT_PATH");
	public final static String LOG_PATH = properties.getProperty("LOG_PATH");
	public final static String EXTENTREPORT_PATH = properties.getProperty("EXTENTREPORT_PATH");

	public final static int HTTP_OK = 200;
	public final static int HTTP_BADREQUEST = 400;
	public static String accessToken="";
	public static String currentTestCaseName;
	public static String currentTimeStamp = System.getProperty("timestamp");
	public static String iteration;
	public static ExtentTest extentTest;

	/****************API Information**********************/
	public final static String baseEndPoint =properties.getProperty("BASE_ENDPOINT");
	public final static  String APIversion = properties.getProperty("x-api-version");
	public final static  String SubscriptionKey = properties.getProperty("Subscription-Key");
	public final static String UserAuthorization=properties.getProperty("UserAuthorization");
	public final static String reportPath = properties.getProperty("REPORT_PATH");
	public static String appFailedPath = reportPath+File.separator+ "ApplicationIssue.jpg";
	public DataBaseConnector db = new DataBaseConnector();
	private static Log log = new Log();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		ExtentReport.startReport();
		writeInTextFile("", "");
		extentReport = new ExtentReport(driver,extentReport);
		log = new Log();
		ExtentTest test = ExtentReport.extent.createTest("Prerequisite Verification");
		assertion =  new Assertions(extentTest);
		/*
		 * try { if(!db.getConnection().isClosed()) {test.
		 * pass("Iteration Prerequisite Verified and Passed - DB Connection Established"
		 * ); log.
		 * info("Iteration Prerequisite Verified and Passed - DB Connection Established"
		 * ); } }catch (Exception e) { writeInTextFile("BeforeSuite-DB Connection",
		 * "Failure"); log.
		 * error("Iteration Prerequisite Verified but Failed - DB Connection NOT Established"
		 * +System.lineSeparator()+e.getMessage()); test.
		 * fail("Iteration Prerequisite Verified but Failed - DB Connection NOT Established"
		 * ); extentReport.generateTestReport(); throw e; }
		 */
		
		try {
			driver = initializeDriver();
			driverScript = new DriverUtils(driver,extentReport);
			driverScript.getURL(url);
			
			driverScript.waitForPageLoad();
			//driverScript.acceptAlert();
			if (driverScript.visibilityOfElementLocated(userNameTextBox)
					&& driverScript.visibilityOfElementLocated(passwordTextBox)) {
				test.pass("Iteration Prerequisite Verified and Passed ,Application is available for execution..");
				log.info("Iteration Prerequisite Verified and Passed , Application is available for execution..");
			}
			//driver.quit();
		} catch (Exception e) {
			writeInTextFile("BeforeSuite-Application availability", "Failure");
			CommonUtils.takeSnapShot(driver, appFailedPath);
			test.fail("Iteration Prerequisite Verified but Failed ,Application is not available for execution...", MediaEntityBuilder.createScreenCaptureFromPath(appFailedPath).build());
			log.error("Iteration Prerequisite Verified but Failed ,Application is not available for execution... "
					+ e.getMessage());
			extentReport.generateTestReport();
			driver.quit();
			throw e;
		}
	}
	
	/*
	 * @BeforeClass(alwaysRun=true) public void initialize() { driver =
	 * initializeDriver(); }
	 */

	public static void takeSnapShot(WebDriver webdriver, String filePath) throws Exception {
		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(filePath);
		FileUtils.copyFile(srcFile, destFile);
	}
	
	public static  void adminLogin() throws InterruptedException 
	{
		DriverUtils driverUtils = new DriverUtils(driver,extentReport);
		driver.get(adminUrl);
		driverUtils.clickElement( allAbbottCustomers_OR,allAbbottCustomers_S);
		driverUtils.isElementPresent(allAbbottCustomers_OR);
		
		driverUtils.loading();
		if(driverUtils.isDisplayedWithoutReport(addCustomer_OR, addCustomer_S));
		{
			extentReport.reportInfo("Add Customer Button is Displayed ");
		}
		
		
		driverUtils.loading();
	}
	public static String timestamp() 
	{
		try {
			return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String timestampss() 
	{
		try {
			return new SimpleDateFormat("HHmmss").format(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void saintResult(ITestResult result,ExtentTest extentTest) 
	{
		String status = null;
		String testMethodName = result.getMethod().getMethodName();
		 if (result.getStatus()== ITestResult.FAILURE ||extentTest.getStatus().toString()=="fail") {
			 status = "Failure";
		    } else if (result.getStatus() == ITestResult.SUCCESS||extentTest.getStatus().toString()=="pass") {
		    	status = "Success";
		    } 
		
		writeInTextFile(testMethodName, status);
	
	}

	public static Properties loadFromPropertyFile() {
		//String env =System.getProperty("Env");
		String env=null;
		try 
		{
			Properties envproperties = new Properties();
			String envfile=System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" 
					+ File.separator + "resources" + File.separator + "properties" + File.separator 
					+ "environment.properties";
			envproperties.load(new FileInputStream(envfile));
			env =envproperties.getProperty("Env");
			env=env.toLowerCase();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new FrameworkException("IOException while loading the Env Settings file");
		}
		String filePath = null;

		filePath = System.getProperty("user.dir")
				+ File.separator + "src" + File.separator + "test" + File.separator +
				"resources" + File.separator + "properties" + File.separator + env+".properties"; 

		/*
		 * if (env.equalsIgnoreCase("dev")) { filePath = System.getProperty("user.dir")
		 * + File.separator + "src" + File.separator + "test" + File.separator +
		 * "resources" + File.separator + "properties" + File.separator +
		 * "dev_settings.properties"; } else if (env.equalsIgnoreCase("qa")) { filePath
		 * = System.getProperty("user.dir") + File.separator + "src" + File.separator +
		 * "test" + File.separator + "resources" + File.separator + "properties" +
		 * File.separator + "qa_settings.properties"; } else if
		 * (env.equalsIgnoreCase("d2")) { filePath = System.getProperty("user.dir") +
		 * File.separator + "src" + File.separator + "test" + File.separator +
		 * "resources" + File.separator + "properties" + File.separator +
		 * "d2_settings.properties"; } else { filePath = System.getProperty("user.dir")
		 * + File.separator + "src" + File.separator + "test" + File.separator +
		 * "resources" + File.separator + "properties" + File.separator +
		 * "demo_settings.properties"; }
		 */

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new FrameworkException("FileNotFoundException while loading the Settings file");
		} catch (IOException e) {
			e.printStackTrace();
			throw new FrameworkException("IOException while loading the Settings file");
		}
		return properties;
	}

	public static String convertStackTraceToString(Throwable throwable) 
	{
		try (StringWriter sw = new StringWriter(); 
				PrintWriter pw = new PrintWriter(sw)) 
		{
			throwable.printStackTrace(pw);
			return sw.toString();
		} 
		catch (IOException ioe) 
		{
			throw new IllegalStateException(ioe);
		}
	} 


	public static WebDriver initializeDriver() {
		String workingDir = System.getProperty("user.dir");
		if (browserType.equals("Chrome")) {
			//System.setProperty("webdriver.chrome.driver", workingDir + File.separator + chromeDriverPath);
			/*
			 * Author: Vinay Babu
			 * Date: 09 Dec 2021
			 * Commented the above line and added below line for WebDriverManager implementation
			 */
			WebDriverManager.chromedriver().setup();
			Map<String, Object> prefs = new HashMap<String, Object>();
		    prefs.put("credentials_enable_service", false);
		    prefs.put("profile.password_manager_enabled", false);
		    
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"}); 
			options.addArguments("start-maximized");
			options.addArguments("−−incognito");
			prefs.put("download.default_directory", System.getProperty("user.dir")+"\\Downloads\\");
			
			options.setExperimentalOption("prefs", prefs);
			driver = new ChromeDriver(options);
			return driver;
		} else if (browserType.equals("iedriver")) {
			//System.setProperty("webdriver.ie.driver", workingDir + File.separator + ieDriverPath);
			/*
			 * Author: Vinay Babu
			 * Date: 09 Dec 2021
			 * Commented the above line and added below line for WebDriverManager implementation
			 */
			// driver = new InternetExplorerDriver(caps);
			WebDriverManager.iedriver().setup();
			return driver;
		} else if (browserType.equals("firefox")) {
			//System.setProperty("webdriver.gecko.driver", workingDir + File.separator + firefoxDriverPath);
			/*
			 * Author: Vinay Babu
			 * Date: 09 Dec 2021
			 * Commented the above line and added below line for WebDriverManager implementation
			 */
			// driver = new FirefoxDriver(cap);
			WebDriverManager.firefoxdriver().setup();
			return driver;
		} else if (browserType.equals("msedge")) {
			//System.setProperty("webdriver.edge.driver", workingDir + File.separator + msEdgeDriverPath);
			/*
			 * Author: Vinay Babu
			 * Date: 09 Dec 2021
			 * Commented the above line and added below line for WebDriverManager implementation
			 */
			WebDriverManager.edgedriver().setup();

			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			//prefs.put("download.default_directory", "C:\\TestReports\\");
			prefs.put("profile.default_content_setting_values.notifications", 1);
			prefs.put("download.default_directory",System.getProperty("user.dir")+"\\Downloads\\");
			prefs.put("profile.default_content_settings.popups", 0);
			prefs.put("profile.default_content_setting_values.notifications", 2);
			prefs.put("profile.default_content_setting_values.automatic_downloads" , 1);
			prefs.put("profile.content_settings.pattern_pairs.*,*.multiple-automatic-downloads",1);
			EdgeOptions edgeOptions = new EdgeOptions();
			//System.getProperty("user.home") +
			// String userdatadir = "c:\\Users\\Selenium\\AppData\\Local\\Microsoft\\Edge\\User Data1";
			// edgeOptions.addArguments("user-data-dir="+userdatadir);
			//edgeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
			//edgeOptions.addArguments("user-data-dir=C:\\Users\\porinjx\\AppData\\Local\\Microsoft\\Edge\\User Data");
			//edgeOptions.addArguments();
			//edgeOptions.addArguments("profile-directory=Profile 1");
			//edgeOptions.addArguments("disable-infobars");
			edgeOptions.setExperimentalOption("prefs", prefs);
			//edgeOptions.addArguments("-inprivate");
			driver = new EdgeDriver(edgeOptions);

			return driver;
		} else {
			return driver;
		}
	}

	/*
	 * public static String randomCustomerName() { String characters =
	 * "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
	 * String customerName = "TestClinic_"+RandomStringUtils.random( 5, characters
	 * ); return customerName; }
	 */

	public static String randomUserId() {
		String userId = "TestUser_"+RandomStringUtils.randomAlphanumeric(5);
		return userId.toLowerCase();
	}
	public static String randomCustomerNameWithDate() {
		// String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String pattern = "yyMMdd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		String customerName = "CusName_"+date;
		return customerName;
	}

	public static String randomCustomerName() {
		//String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String customerName = "CustomerName_"+RandomStringUtils.random( 5, characters );
		return customerName;
	}
	public static String randomText(int length) {
		//String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String customerName = RandomStringUtils.random( length, characters );
		return customerName;
	}
	public static String randomCustomerName(int length) {
		//String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String customerName = "CustomerName_"+RandomStringUtils.random( length, characters );
		return customerName;
	}
	public static String randomSecLocation() {
		// String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String customerName = "SecLocation_"+RandomStringUtils.random( 10, characters );
		return customerName;
	}
	
	public static String randomSecLoc() {
		 String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		//String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String customerName = "SecLocation_"+RandomStringUtils.random( 8, characters );
		return customerName;
	}

	public static String randomDataGenerator(String Testdata) {
		// String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String randomData = Testdata+"_"+RandomStringUtils.random( 5, characters );
		return randomData;
	}
//Poojitha - Added new methods to create the dynamic Patient data and clinic users
	
	public static int createRandomIntBetween(int start, int end) {
        return start + (int) Math.round(Math.random() * (end - start));
    }
	
	public static String randomDateOfBirthGenerator()
	{
		
		int day = createRandomIntBetween(1,28);
        int month = createRandomIntBetween(1,12);
        int year = createRandomIntBetween(1960, 2020);
        LocalDate date = LocalDate.of(year,month,day);
        String dateOfBirth = date.toString();
        return dateOfBirth;    
	}
	
	public static String currentDate()
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-yyyy");
		String implantDate = simpleDateFormat.format(new Date());

		return implantDate;
		
	}
	
	public static String randomPhoneNumber()
	{
		 String numbers = "123456789";
		String phoneNumber = RandomStringUtils.random(3,numbers)+"-"+RandomStringUtils.random(7,numbers);
		return phoneNumber;
	}
	
	public static String deviceSerialNumber()
	{ 
		String numbers = "123456789";
		String serialNumber = RandomStringUtils.random(6,numbers);
		return serialNumber;
	}
	
	public static String randomUserNameWithDate() {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		String pattern = "yyMMdd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		String name = "ClncUsr"+RandomStringUtils.random(3, characters)+date;
		return name;
	}
	
	public static String randomareaCode() {
		String number = "0123456789";
		String areaCode = RandomStringUtils.random(3, number);
		return areaCode;
	}
	public static String randomMainPhone() {
		String number = "0123456789";
		String mainPhone = RandomStringUtils.random(7, number);
		return mainPhone;
	}
// Ends here

	public static void writeRequest(String fileContent) {
		try {
			String reportFolder = System.getProperty("user.dir") + File.separator + reportPath+ File.separator+"API_Evidences";
			File reportFile = new File(reportFolder);
			reportFile.mkdir();
			String fileNameReq = CommonUtils.currentTestCaseName+"_RequestPayload";
			File file = new File(reportFile.getAbsolutePath()+File.separator + currentTestCaseName+"_"+currentTimeStamp);
			file.mkdir();
			File file1 = new File(file.getAbsolutePath()+File.separator+"Iteration"+iteration);
			file1.mkdir();
			FileWriter fw = new FileWriter(file1.getAbsolutePath()+File.separator + fileNameReq);
			fw.write(fileContent);
			fw.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void writeResponse(Response fileContent) {
		try {
			String reportFolder = System.getProperty("user.dir") + File.separator + reportPath+ File.separator+"API_Evidences";
			File reportFile = new File(reportFolder);
			reportFile.mkdir();
			String fileNameRes = CommonUtils.currentTestCaseName+"_ResponsePayload";
			File file = new File(reportFile.getAbsolutePath()+File.separator + currentTestCaseName+"_"+currentTimeStamp);
			file.mkdir();
			File file1 = new File(file.getAbsolutePath()+File.separator+"Iteration"+iteration);
			file1.mkdir();
			FileWriter fw = new FileWriter(file1.getAbsolutePath()+File.separator + fileNameRes);
			String finalContent = "Header details:"+System.lineSeparator()+fileContent.getHeaders()+System.lineSeparator()+"Time taken: "+fileContent.getTimeIn(TimeUnit.MILLISECONDS)+"ms"+System.lineSeparator()+fileContent.asPrettyString();
			fw.write(finalContent);
			fw.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static Map<String, String> createTransmissionHeaders(){
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "Bearer " + BEARER_TOKEN);
		return headers;
	}

	public static String getTestName() {

		StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
		StackTraceElement e = stacktrace[2];
		String methodName = e.getMethodName();
		String output = methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
		return output;
	}

	public static String randomGenerator() {	
		Random rand = new Random();
		String random = rand.nextInt(1000)+RandomStringUtils.randomAlphanumeric(3).toLowerCase();
		return random;
	}

	public String formatString(String value) {
		String message = value.replace("\"", "");
		return message;
	}

	public static String createAccessToken() {
		try {
			//log = new Log();
			Map<String, String> headers = new HashMap<String, String>();
			headers.put("Authorization", "Basic " + UserAuthorization);
			headers.put("x-api-version", APIversion);
			headers.put("Ocp-Apim-Subscription-Key", SubscriptionKey);
			log.info("Access token header request body created...");
			Response response = RestAssured.given().headers(headers).post(baseEndPoint+ "oauth/token?grant_type=password&username=pcs_admin&password=merlin-demo1-Apple@123").then().extract().response();
			Assert.assertEquals(response.statusCode(), HTTP_OK);
			accessToken = response.jsonPath().getString("access_token");
			System.out.println("AccessToken Value is --> " + accessToken);
			return accessToken;
		} catch (AssertionError e) {
			log.error("Error in access token creation..."+e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
			throw e;
		}

	}

	public static String convertStringToBaseEncodeString(String value) {
		String encodedString = Base64.getEncoder().encodeToString(value.getBytes());
		return encodedString;
	}

	public static String decodeString(String encodedString) {
		Base64.Decoder decoder = Base64.getDecoder();  
		// Decoding string  
		String decodedString = new String(decoder.decode(encodedString));  
		System.out.println("Decoded string: "+decodedString);
		return decodedString;

	}

	public static File convertZipFileToBaseEncodeString(String path) {
		File originalFile = new File(path);
		String encodedBase64 = null;
		File file1=null;
		try {
			FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
			byte[] bytes = new byte[(int) originalFile.length()];
			fileInputStreamReader.read(bytes);
			//encodedBase64 = new String(Base64.getEncoder().encodeToString(bytes));
			file1 = new File(Paths.get("").toAbsolutePath().toString() + File.separator+dataPath+ File.separator+"Output");
			file1.mkdir();
			FileWriter fw = new FileWriter(file1.getAbsolutePath()+File.separator + "Text");
			fw.write(Base64.getEncoder().encodeToString(bytes));
			fw.close();
			return file1;

		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file1;

	}

	public static Map<String, String> createHeaders() {
		log = new Log();
		log.info("Creating Headers for execution...");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "Bearer " + createAccessToken());
		headers.put("x-api-version", APIversion);
		headers.put("Ocp-Apim-Subscription-Key", SubscriptionKey);
		return headers;

	}

	public JsonObject loadJsonFromResponse(Response response) {
		String responseBodyString = response.getBody().asString();
		JsonObject jsonObject = new JsonParser().parse(responseBodyString).getAsJsonObject();
		return jsonObject;
	}

	public String loadJsonStringFromRequest(Object object) throws JsonProcessingException {
		ObjectMapper mapperObj = new ObjectMapper();
		String jsonStr = mapperObj.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		return jsonStr;
	}

	public String loadStringFromResponse(Response response, String value) {
		return response.jsonPath().getString(value);
	}

	public static String getURL()
	{
		String env =System.getProperty("Env");
		String Url=null;
		if(env.equalsIgnoreCase("QA"))
			Url =loadFromPropertyFile().getProperty("QA_URL");


		else  if(env.equalsIgnoreCase("Dev"))
			Url =loadFromPropertyFile().getProperty("DEV_URL");    

		else
			Url=loadFromPropertyFile().getProperty("URL");
		return Url;
	}

	public static void writeTestData(String fileContent) {
		try {
			String reportFolder = System.getProperty("user.dir") + File.separator + dataPath+ File.separator+"TransmissionData";
			File reportFile = new File(reportFolder);
			reportFile.mkdir();
			String fileNameReq = CommonUtils.currentTestCaseName+"_InputData_"+currentTimeStamp;
			FileWriter fw = new FileWriter(reportFile.getAbsolutePath()+File.separator + fileNameReq);
			fw.write(fileContent);
			fw.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	static { 

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
		System.setProperty("timestamp", dateFormat.format(new Date()));
	}

	public static String getRandomNumberString() {
		Random rnd = new Random();
		int number = rnd.nextInt(999999999);

		// this will convert any number sequence into 6 character.
		return String.format("%06d", number);
	}

	public void copyFolder(Path dir, String folder) throws IOException {
		Optional<Path> lastFilePath = Files.list(dir).filter(f -> Files.isDirectory(f)).max(Comparator.comparingLong(f -> f.toFile().lastModified())); 

		File dest = new File(SAINTS_EVIDENCE+File.separator + folder);
		FileUtils.copyDirectory(lastFilePath.get().toFile(), dest);
	}

	public void copyFile(Path dir, String folder) throws IOException {
		Optional<Path> lastFilePath = Files.list(dir)
				.filter(p -> !Files.isDirectory(p))
				.sorted((p1, p2)-> Long.valueOf(p2.toFile().lastModified())
						.compareTo(p1.toFile().lastModified()))
				.findFirst();

		File dest = new File(SAINTS_EVIDENCE+File.separator + folder+File.separator+lastFilePath.get().toFile().getName());
		FileUtils.copyFile(lastFilePath.get().toFile(), dest);
	}

	public void copyTestData(String dir, String folder,Method currentMethod) throws IOException {
		String currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		File dest = new File(SAINTS_EVIDENCE+File.separator + folder+File.separator+currentScenario+".xlsx");
		File source = new File(dir);
		FileUtils.copyFile(source, dest);
	}

	public static void copyTestData(String dir, Method currentMethod) throws IOException {
		String currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		File dest = new File(SAINTS_EVIDENCE+File.separator + currentScenario+".xlsx");
		File source = new File(dir);
		FileUtils.copyFile(source, dest);
	}

	public String getLatestFolder(Path dir) throws IOException {
		String folder = null;
		Optional<Path> lastFilePath = Files.list(dir).filter(f -> Files.isDirectory(f)).max(Comparator.comparingLong(f -> f.toFile().lastModified())); 

		folder = new File(lastFilePath.toString()).getName().replace("]", "");
		return folder;
	}

	public static void copySaintsEvidences(Method currentMethod) throws IOException {
		String currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		//Path screenshotDirectory = Paths.get(LOG_PATH).toAbsolutePath();
		//String folder = getLatestFolder(screenshotDirectory);
		//Path logDirectory = Paths.get(LOG_PATH).toAbsolutePath();
		//Path reportDirectory = Paths.get(EXTENTREPORT_PATH).toAbsolutePath();
		String testDataFile = Paths.get(dataPath).toAbsolutePath()+File.separator+currentScenario+".xlsx";
		//copyFolder(screenshotDirectory, folder);
		//copyFile(logDirectory, folder);
		//copyFile(reportDirectory, folder);
		copyTestData(testDataFile, currentMethod);
	}

	public static void writeInTextFile(String testMethodName, String status) {
		try {
			String path = Paths.get("").toAbsolutePath().toString()+"\\TcStatus.txt";
			File f = new File(path);

			if (!f.exists()) {
				f.createNewFile();
			}
          
			String fileWrite = testMethodName + "," + status;

			FileWriter writer = new FileWriter(f);
			writer.write(fileWrite);
			writer.flush();
			writer.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public static List<String> extractOTP(WebDriver driver,String MFALogin) throws InterruptedException, AWTException {
		
		List<String> otpList = new ArrayList<String>();
		DriverUtils driverUtils = new DriverUtils(driver,extentReport);
		String otpLogin = decodeString(MFALogin);
		String[] splitLoginDetail = otpLogin.split("~"); 
		String userName = splitLoginDetail[0];
		String password = splitLoginDetail[1];

		By userNameCheck = By.xpath("//div[contains(text(),'" + userName + "')]");
		String currentTime="";

		// Get current time
		DateFormat dateFormat = new SimpleDateFormat("h:mm aa");
		Date date1 = new Date();
		Date date2 = new Date();
		date2.setMinutes(date2.getMinutes() - 1);
		driverUtils.waitForLoading();
		openWindow(OUTLOOK_URL);

		driverUtils.maximizeWindow();
		driverUtils.waitForLoading();

		//Entering email id into email text box
		if (driverUtils.isElementPresent(emailTextBox)) {
			driverUtils.sendKeys(emailTextBox, userName);
			driverUtils.clickElement(submitButton);
		}

		driverUtils.waitForLoading();
		driverUtils.waitForLoading();

		////Entering password into password text box
		if (driverUtils.isElementPresent(userNameCheck)) {
			driverUtils.sendKeys(passwordBox, password);
			driverUtils.clickElement(submitButton);
		}

		if(driverUtils.isElementPresent(OTP_FOLDER))
		{
			driverUtils.waitForLoading();
		}
		else
		{
			driverUtils.waitForPageLoad();
			driverUtils.waitForElementToBeClickable(navigationButton);
			driverUtils.waitForElementToBeClickable(navigationButton);
			driverUtils.clickOnElementUsingJs(navigationButton);
			driverUtils.waitForPageLoad();
			driverUtils.waitForLoading();
		}

		driverUtils.waitForPageLoad();
		driverUtils.waitForLoading();
		driverUtils.waitForLoading();

		driverUtils.clickOnElementUsingJs(OTP_FOLDER);
		driverUtils.clickOnElementUsingJs(OTP_FOLDER);

		driverUtils.waitForPageLoad();
		driverUtils.clickOnElementUsingJs(navigationButton);
		driverUtils.waitForLoading();
		driverUtils.waitForLoading();

		for (int i = 0; i <= 2; i++) {
			date2.setMinutes(date2.getMinutes() + i);
			currentTime = dateFormat.format(date2).toString();
			List<WebElement> mails = driver.findElements(By.xpath("//span[contains(text(),'" + currentTime + "')]"));

			for (WebElement element : mails) {
				element.click();
				driverUtils.waitForPageLoad();
				driverUtils.waitForLoading();
				String otpText = driverUtils.getText(readOTP);

				String[] splitOTP = otpText.split(":");
				String otp = splitOTP[1].trim();
				otpList.add(otp);
			}
			date2.setMinutes(date1.getMinutes() - 1);
		}

		driverUtils.waitForLoading();
		return otpList;
	}

	public static void openNewWindow(String url) throws AWTException {

		// Initialize the robot class object
		Robot robot = new Robot();

		// Press and hold Control and N keys
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_N);

		// Release Control and N keys
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_N); 


		// Set focus to the newly opened browser window
		ArrayList <String> tabs = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs.get(tabs.size()-1));
		for (String windowHandle : driver.getWindowHandles()) {
			driver.switchTo().window(windowHandle);
		}
		// Continue your actions in the new browser window
		driver.get(url);
	}

	public static void openWindow(String url) {
		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		driver.get(url);	
	
	}

	public static String readFileContent(String path) throws IOException {
		String content = Files.lines(Paths.get(path)).collect(Collectors.joining(System.lineSeparator()));
		return content;
	}

	public static void extractResponseXMLFromContent(String responseContent, String destPath) throws IOException {
		final String startDelim = "resp = [";
		final String endDelim = "resp_len";

		int xmlStart = responseContent.indexOf(startDelim) + startDelim.length();
		int xmlEnd = responseContent.lastIndexOf(endDelim);

		String xmlSubContent = responseContent.substring(xmlStart, xmlEnd);
		String xmlContent = xmlSubContent.substring(0, xmlSubContent.lastIndexOf("]"));

		Files.write(Paths.get(destPath), xmlContent.getBytes(), StandardOpenOption.CREATE);
	}

	public static String createRequestXML(Object className, String deviceSerialNum) throws ParserConfigurationException, NoSuchFieldException, IllegalAccessException, TransformerException {
		String path = reportPath + File.separator + "RequestXML_" + deviceSerialNum + "_" + CommonUtils.currentTimeStamp + ".xml";

		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder;
			documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();
			document.setXmlStandalone(true); // ADDED

			// root element
			Element root = document.createElement(className.getClass().getSimpleName());
			document.appendChild(root);

			//Appending elements from POJO
			Field[] allFields = className.getClass().getDeclaredFields();
			for (Field each : allFields) {
				Field field = className.getClass().getDeclaredField(each.getName());
				field.setAccessible(true);
				String value = (String) field.get(className);
				if (value != null) {
					Element element = document.createElement(each.getName());
					element.appendChild(document.createTextNode(value));
					root.appendChild(element);
				}
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, ""); // ADDED
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(new File(path));
			transformer.transform(domSource, streamResult);
		} catch (Exception e) {
			e.printStackTrace();
		} 

		return path;
	}

	public String readXMLElement(String element, String path){
		String value = "";
		try {
			File inputFile = new File(path);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			List<String> tagNames = new ArrayList<String>();
			tagNames.add("Switch");
			tagNames.add("iSwitch");
			tagNames.add("tSwitch");
			tagNames.add("rSwitch");
			for (int k = 0; k < tagNames.size(); k++) {
				NodeList nList = doc.getElementsByTagName(tagNames.get(k));
				for (int i = 0, len = nList.getLength(); i < len; i++) {
					Element elm = (Element) nList.item(i);
					if (elm.getAttribute("name").contains(element)) {
						value = elm.getAttribute("value");
						System.out.println("@@" + value);
					}
					if (!value.isEmpty())
						break;
				}
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}

	// Element should be given in this format - ParentNode.childnode.attribute
	public static String readXML(String element, String path) {

		String value = "";

		try {

			if(element.contains("Controls")) {
				String requestElement = element.replace(".", ",");
				String[] splitElement = requestElement.split(",");
				String attribute=splitElement[splitElement.length-1];
				File inputFile = new File(path);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder;
				dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(inputFile);
				doc.getDocumentElement().normalize();
				List<String> tagNames = new ArrayList<String>();
				tagNames.add("Switch");
				tagNames.add("iSwitch");
				tagNames.add("tSwitch");
				tagNames.add("rSwitch");
				for (int k = 0; k < tagNames.size(); k++) {
					NodeList nList = doc.getElementsByTagName(tagNames.get(k));
					for (int i = 0, len = nList.getLength(); i < len; i++) {
						Element elm = (Element) nList.item(i);
						if (elm.getAttribute("name").equals(attribute)) {
							value = elm.getAttribute("value");
							System.out.println(attribute+" :" + value);
						}
						if (!value.isEmpty())
							break;
					}
				}
			}else if(element.contains("PayloadProfile")){
				String requestElement = element.replace(".", ",");
				String[] splitElement = requestElement.split(",");
				String node = splitElement[0];
				String type=splitElement[1];
				String childNode=splitElement[2];	
				String attribute=splitElement[3];	

				File inputFile = new File(path);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(inputFile);
				doc.getDocumentElement().normalize();
				NodeList nList = doc.getElementsByTagName(node);
				for (int i = 0, len = nList.getLength(); i < len; i++) {
					Node nNode = nList.item(i);
					Element eElement = (Element) nNode;
					if(eElement.getAttribute("Type").equalsIgnoreCase(type)) {
						Element cElement =  (Element) eElement.getElementsByTagName(childNode).item(0);
						value = cElement.getAttribute(attribute);
						System.out.println(attribute+" :" + value);
						if (!value.isEmpty())
							break;
					}
				}
			} 
			else {
				String requestElement = element.replace(".", ",");
				String[] splitElement = requestElement.split(",");
				String node = splitElement[0];
				String childNode=splitElement[1];
				String attribute=splitElement[2];		

				File inputFile = new File(path);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(inputFile);
				doc.getDocumentElement().normalize();
				NodeList nList = doc.getElementsByTagName(node);
				for (int i = 0, len = nList.getLength(); i < len; i++) {
					Node nNode = nList.item(i);
					Element eElement = (Element) nNode;
					Element cElement =  (Element) eElement.getElementsByTagName(childNode).item(0);
					value = cElement.getAttribute(attribute);
					System.out.println(attribute+" :" + value);
					if (!value.isEmpty())
						break;
				}
			} 
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}

	public void softAssertO(Object expected, Object actual, String reportMsg) {
		assertion.assertEquals(expected,actual,"Assertion to verify if "+reportMsg);
		extentReport.reportScreenShot("Assertion Screenshot to verify if "+reportMsg);
		}
	
	public void hardAssert(String expected, String actual, String reportMsg) {
		assertion.assertEquals(expected,actual,"Assertion : "+reportMsg);
		extentReport.reportScreenShot("Screenshot : "+reportMsg);
		//reportMsg.substring(0, 25);
		//assertion.assertEqualsWithReporting(Expected,  Actual, extentTest, "Assertion : "+reportMsg);
		extentReport.reportScreenShot("Assertion Screenshot ");
		boolean hardAssertflag =false;
		System.out.println("Expected Value is "+expected);
		if(expected.equalsIgnoreCase(actual)) {
			hardAssertflag =true;
		}
		Assert.assertTrue(hardAssertflag,"Assertion : "+reportMsg);
	}
	public void hardAssert(Object expected, Object actual, ExtentTest extent, String reportMsg) {
		assertion.assertEqualsWithReporting(expected,actual,extent,"Assertion : "+reportMsg);
		extentReport.reportScreenShot("Assertion Screenshot to verify if  "+reportMsg);
		//Assert.assertTrue(expected.equals(actual), reportMsg);
	}
	public void hardAssert(boolean expected, boolean actual, String reportMsg) {
		//extentTest = extentReport.info(reportMsg);
		//extentReport.reportScreenShot("Screenshot : "+reportMsg);
		//assertion.assertEqualsWithReporting(Expected,  Actual, extentTest, "Assertion : "+reportMsg);
		//assertion.assertEquals(Expected,Actual,"Assertion : "+reportMsg);
		assertion.assertEquals(expected,actual,"Assertion : "+reportMsg);
		extentReport.reportScreenShot("Assertion Screenshot ");
		boolean hardAssertflag =false;
		System.out.println("Expected Value is "+expected);
		if(expected==actual) {
			hardAssertflag =true;
		}
		Assert.assertTrue(hardAssertflag,"Assertion : "+reportMsg);
	}

	public void softAssert(String Expected, String Actual, String reportMsg) {
		extentReport.reportScreenShot("Screenshot : "+reportMsg);
		assertion.assertEquals(Expected,Actual,"Assertion : "+reportMsg);
	}

	public  void softAssert(boolean Expected, boolean Actual, String reportMsg) {
		if(Expected==Actual) {
			extentReport.reportScreenShot("Screenshot for : "+reportMsg);
			assertion.assertEquals(Expected,Actual,"Assertion  "+"   "+"  Passed For "+reportMsg);
//			Customers sorted based on telephoneNo
		}else {
			//extentReport.reportScreenShot("Screenshot : "+reportMsg+"Fail");
			extentReport.reportScreenShot(reportMsg  +"   is Failed , "+"Screenshot : ");
			assertion.assertEquals(Expected,Actual,"Assertion   "+"   "+"  Failed For "+reportMsg);
		}
		//extentReport.reportScreenShot("Screenshot : "+reportMsg);
		//assertion.assertEquals(Expected,Actual,"Assertion : "+reportMsg);
		//assertion.assertEqualsWithReporting(Expected,  Actual, extentTest, "Assertion : "+reportMsg);
	}
	
	/**
	 * Method to fetch integer from given String 
	 */
	public static String extractInt(String inputString)
	{      
		String integerVal = inputString.replaceAll("[^\\d]", "").replaceAll(" +", "");  
		return integerVal;
	}

	/**
	 * Method to fetch integer along with desired character from given String 
	 */
	public static String extractIntAndChar(String inputString, char chr)
	{      
		String extVal = inputString.replaceAll("[^"+chr +"| ^\\d]", "").trim().replaceAll(" +", "");  
		return extVal;
	}

	@AfterClass(alwaysRun=true)
	public void quit() throws IOException {
		driver.quit();
		//Runtime.getRuntime().exec("taskkill /im chromedriver.exe /f");
	}

	@AfterSuite(alwaysRun=true)
	public void tearDown() throws Exception {

		extentReport.generateTestReport();
	}

}
