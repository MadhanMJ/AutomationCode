package com.test.qa.assertions;

import org.apache.log4j.Logger;
import org.testng.asserts.IAssert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.test.qa.extentReport.ExtentReport;

import junit.framework.Assert;

public class Assertions extends SoftAssert{
	static String callerClassName = new Exception().getStackTrace()[1].getClassName();
	private static final Logger log = Logger.getLogger(callerClassName+".class");
	ExtentTest extentTest;
    public Assertions(ExtentTest extentTest) {
		this.extentTest = extentTest;
	}
    
	@Override
    public void onAssertFailure(IAssert<?> a, AssertionError ex) {
		String message="<Font Color=red><b>"+a.getMessage()+"</b></Font>"+"<br>"+"<b>"+"Expected: "+"</b>"+a.getExpected()+"<br>"+"<b>"+"Actual: "+"</b>"+a.getActual() ;
		//Markup m = MarkupHelper.createLabel(message, ExtentColor.RED);
	    extentTest.log(Status.FAIL,message);
    	log.error(ex);
    	super.onAssertFailure(a, ex);
    }

    @Override
    public void onAssertSuccess(IAssert<?> a) {
		String message="<Font Color=#228B22><b>"+a.getMessage()+"</b></Font>"+"<br>"+"<b>"+"Expected: "+"</b>"+a.getExpected()+"<br>"+"<b>"+"Actual: "+"</b>"+a.getActual() ;
		//Markup m = MarkupHelper.createLabel(message , ExtentColor.GREEN);
		extentTest.log(Status.PASS, message);
		log.info(message);
		super.onAssertSuccess(a);
    }
	
	@Override
	public void onBeforeAssert(IAssert<?> assertCommand) {
		this.extentTest = ExtentReport.node;
		
	}
	
	@Override
	public void assertEquals(boolean actual,boolean expectd,String msg) {
	super.assertEquals(actual, expectd, msg);
	}
	
	
	
	public void assertEqualsWithReporting(Object expected, Object actual, ExtentReport test, String message) {
		try{
			Assert.assertEquals(message,expected, actual);
			test.pass("<Font Color=#228B22><b>"+message+"</b></Font>"+"<br>"+"<b>"+"Expected: "+"</b>"+expected+"<br>"+"<b>"+"Actual: "+"</b>"+actual);
			log.info(message);
		}
		catch(AssertionError e) {
			test.fail("<Font Color=red><b>"+message+"-Assertion Failure."+"</b></Font>"+"<br>"+"<b>"+"Expected: "+"</b>"+expected+"<br>"+"<b>"+"Actual: "+"</b>"+actual);
			log.info(message);
			throw e;
		}
		catch(Exception e) {
			test.fail("<Font Color=red>"+"Please check"+"<b>"+" Test Ended Position "+"</b>"+"for step failure."+"</Font>");
			log.info(message);
			throw e;
		}
		
	}
	
	public void assertEqualsWithReporting(Object expected, Object actual, ExtentTest test, String message) {
		try{
			Assert.assertEquals(message,expected, actual);
			test.pass("<Font Color=#228B22><b>"+message+"</b></Font>"+"<br>"+"<b>"+"Expected: "+"</b>"+expected+"<br>"+"<b>"+"Actual: "+"</b>"+actual);
			log.info(message);
		}
		catch(AssertionError e) {
			test.fail("<Font Color=red><b>"+message+"-Assertion Failure."+"</b></Font>"+"<br>"+"<b>"+"Expected: "+"</b>"+expected+"<br>"+"<b>"+"Actual: "+"</b>"+actual);
			log.info(message);
			throw e;
		}
		catch(Exception e) {
			test.fail("<Font Color=red>"+"Please check"+"<b>"+" Test Ended Position "+"</b>"+"for step failure."+"</Font>");
			log.info(message);
			throw e;
		}
		
	}


}
	
