package com.test.qa.dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.aventstack.extentreports.ExtentTest;
import com.test.qa.extentReport.ExtentReport;
import com.test.qa.logger.Log;
import com.test.qa.utilities.CommonUtils;

public class DataBaseConnector {

	public final static String dataBaseURL = CommonUtils.loadFromPropertyFile().getProperty("DATABASE_URL");
	public final static String dataBaseUserName = CommonUtils.loadFromPropertyFile().getProperty("DATABASE_USERNAME");
	public final static String dataBasePassword = CommonUtils.loadFromPropertyFile().getProperty("DATABASE_PASSWORD");
	private static final Log log = new Log();
	private Connection connection = null;
	private ResultSet rs = null;
	private ResultSetMetaData rsmd = null;
	private Statement st = null;
	private ExtentTest extentTest; 
	
	
	public Connection getConnection() {
		try {
			log.info("DB Connection Validation is started... ");
			Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection(dataBaseURL, dataBaseUserName, dataBasePassword);
			log.info("DB Connection Established ");
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
		} catch (ClassNotFoundException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
		}
		return connection;
	}

	public ResultSet executeQuery(String query) throws SQLException, InterruptedException {
		this.extentTest = ExtentReport.node;
		connection=getConnection();
		try {
			extentTest.info(query);
			log.info(query);
			if(connection!=null) {
			st = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			synchronized(st)
			{
			    st.wait(4000);
			}
			rs = st.executeQuery(query);
			rsmd = rs.getMetaData();
			}
			
			return rs;
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (InterruptedException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	

	public void executeNonQuery(String query) throws SQLException, InterruptedException {
		this.extentTest = ExtentReport.node;
		connection=getConnection();
		try {
			//extentTest.info(query);
			log.info(query);
			if(connection!=null) {
			//st = connection.createStatement();
			PreparedStatement ps= connection.prepareStatement(query);			
			ps.executeUpdate();
			}
		}catch (SQLException e) {
				log.error(e.getMessage());
				log.error(CommonUtils.convertStackTraceToString(e));
				throw e;
			}
		}
	public ResultSet executeQueryTemp(String query) throws SQLException, InterruptedException {
		this.extentTest = ExtentReport.node;
		connection=getConnection();
		try {
			extentTest.info(query);
			log.info(query);
			if(connection!=null) {
			st = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			synchronized(st)
			{
			    st.wait(3000);
			}
			rs = st.executeQuery(query);
			rsmd = rs.getMetaData();
			}
			
			return rs;
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		} catch (InterruptedException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	public int getCountFromDB(String sql) throws SQLException, InterruptedException {
		getConnection();
		System.out.println("Parameterized Sql is  "+sql);
		int count = executeScalar(sql);
		System.out.println("Count Value is "+count);
		return count;
	}
	
	
	/***Method to fetch count***/
	public int executeScalar(String query) throws SQLException, InterruptedException {
        this.extentTest = ExtentReport.node;
        connection=getConnection();
        try {
                     //extentTest.info(query);
                     log.info(query);
                     if(connection!=null) {
                     st = connection.createStatement();                   
                     rs = st.executeQuery(query);
                     rs.next();                 
               }                    
               return rs.getInt(1);
        } catch (SQLException e) {
               log.error(e.getMessage());
               log.error(CommonUtils.convertStackTraceToString(e));
               throw e;
        }
 }

	public int updateInsertQuery(String query) throws SQLException, InterruptedException {
		connection=getConnection();
		int  count =0;
		try {
			//extentTest.info(query);
			log.info(query);
			if(connection!=null) {
			st = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			synchronized(st)
			{
			    st.wait(3000);
			}
			 count = st.executeUpdate(query);			
			}
			return count;

		} catch (SQLException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
			throw e;


		} catch (InterruptedException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
			throw e;
		}
	}
	
	
	public ResultSet datatable(String query) {
		try {
			st = connection.createStatement();
			rs = st.executeQuery(query);
			while (rs.next()) 
			return rs;
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
		}
		return rs;
	}
	
	public ArrayList<String> datatable(String query,String columnName) {
		ArrayList<String> data = new ArrayList<String>();
		try {
			st = connection.createStatement();
			rs = st.executeQuery(query);
		    while (rs.next()) {
		         String columnValue = rs.getString(columnName).toString();
		         data.add(columnValue);
		    }
	    return data;
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.error(CommonUtils.convertStackTraceToString(e));
		}
		return data;
	}
	
	public int getRowCount() {
        int rowCount = 0;
        
        if(rs == null) {
        	return rowCount;
        }
        
        try {
            rs.last();
            rowCount = rs.getRow();
            rs.beforeFirst();
        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }
        
        return rowCount ;
    }
	
	public int getColumnCount() {
		int columnCount = 0 ;

		if (rsmd == null) {
			return columnCount;
		}
		
        try {
            columnCount = rsmd.getColumnCount();
        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return columnCount;
	}
	
	public List<String> getAllColumnNamesAsList(){

        List<String> columnNameList = new ArrayList<>();
        
        if (rsmd == null) {
        	return columnNameList;
        }

        try {
            for (int colIndex = 1; colIndex <= getColumnCount() ; colIndex++) {
                String columnName =  rsmd.getColumnName(colIndex) ;
                columnNameList.add(columnName) ;
            }
        } catch (SQLException e){
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return columnNameList ;
    }
	
	public List<String> getRowDataAsList(int rowNum){

        List<String> rowDataAsList = new ArrayList<>();
        int colCount = getColumnCount();
        
        if (rs == null) {
        	return rowDataAsList;
        }

        try {
            rs.absolute( rowNum );

            for (int colIndex = 1; colIndex <= colCount ; colIndex++) {

                String cellValue =  rs.getString( colIndex ) ;
                rowDataAsList.add(cellValue) ;
            }
            rs.beforeFirst();

        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return rowDataAsList ;
    }
	
	 public String getCellValueByColIndex(int rowNum, int columnIndex) {
	        String cellValue = "" ;
	        
	        if (rs == null) {
	        	return cellValue;
	        }

	        try {
	            rs.absolute(rowNum) ;
	            cellValue = rs.getString(columnIndex) ;
	            rs.beforeFirst();
	        } catch (SQLException e) {
	        	log.error(e.getMessage());
				e.printStackTrace();
	        }
	        
	        return cellValue ;
	    }
	 
	 public String getCellValueByColName(int rowNum, String columnName) {
		 String cellValue = "" ;
		 
		 if (rs == null) {
			 return cellValue;
		 }

        try {
            rs.absolute(rowNum) ;
            cellValue = rs.getString(columnName) ;
            rs.beforeFirst();
        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }
        
        return cellValue ;
	 }
	 
	 public String getFirstCellValue(){
	        return getCellValueByColIndex(1,1) ;
	 }
	 
	 public List<String> getColumnDataByColIndex(int columnIndex){
        List<String> columnDataList = new ArrayList<>();
        
        if (rs == null) {
        	return columnDataList;
        }

        try {
            rs.beforeFirst(); // make sure the cursor is at before first location
            while(rs.next()){
                String cellValue = rs.getString(columnIndex) ;
                columnDataList.add(cellValue) ;
            }
            rs.beforeFirst();

        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return columnDataList;
	 }
	 
	 public List<String> getColumnDataByColName(int columnName){
        List<String> columnDataList = new ArrayList<>();
        
        if (rs == null) {
        	return columnDataList;
        }

        try {
            rs.beforeFirst(); // make sure the cursor is at before first location
            while(rs.next()){
                String cellValue = rs.getString(columnName);
                columnDataList.add(cellValue) ;
            }
            rs.beforeFirst();

        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return columnDataList;
	 }
	
	 public Map<String,String> getRow(int rowNum){
        Map<String,String> rowMap = new LinkedHashMap<>();
        
        if (rs == null) {
        	return rowMap;
        }
        
        int columnCount = getColumnCount();
        
        try{
            rs.absolute(rowNum) ;
            for (int colIndex = 1; colIndex <= columnCount ; colIndex++) {
                String columnName = rsmd.getColumnName(colIndex) ;
                String cellValue  = rs.getString(colIndex) ;
                rowMap.put(columnName, cellValue) ;
            }
            rs.beforeFirst();
        } catch(SQLException e){
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return rowMap ;
	 }
	 
	 public List<Map<String,String>> getAllRows(){
        List<Map<String,String>> allRows = new ArrayList<>();
        
        if (rs == null) {
        	return allRows;
        }
        
        int rowCount = getRowCount() ;

        for (int rowIndex = 1; rowIndex <= rowCount ; rowIndex++) {

            Map<String,String> rowMap = getRow(rowIndex);
            allRows.add(rowMap) ;

        }
        
        try {
        	rs.beforeFirst();
        } catch (SQLException e) {
        	log.error(e.getMessage());
			e.printStackTrace();
        }

        return allRows ;
	
	    }
	 
	 public void closeConnection() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			connection.close();
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
	}
}
