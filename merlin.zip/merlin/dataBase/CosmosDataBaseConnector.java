package com.test.qa.dataBase;

import com.azure.cosmos.ConsistencyLevel;
import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.CosmosContainer;
import com.azure.cosmos.CosmosDatabase;
import com.azure.cosmos.models.CosmosDatabaseResponse;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.azure.cosmos.util.CosmosPagedIterable;
import com.test.qa.logger.Log;
import com.test.qa.pojo.SessionRecords;
import com.test.qa.utilities.CommonUtils;

public class CosmosDataBaseConnector {
	private final static String HOST = CommonUtils.loadFromPropertyFile().getProperty("COSMOS_HOST");
	private final static String MASTER_KEY = CommonUtils.loadFromPropertyFile().getProperty("COSMOS_MASTER_KEY");
	private CosmosClient cosmosClient=null;
	public static Log logger = new Log();
	
	public CosmosClient getConnection() {
		try {
		cosmosClient = new CosmosClientBuilder().endpoint(HOST).key(MASTER_KEY)
				.consistencyLevel(ConsistencyLevel.EVENTUAL).buildClient();
		return cosmosClient;
		} catch (Exception e) {
			logger.error("Error occured while connecting to Cosmos DB. " + e.getMessage());
		}
		return cosmosClient;
	}
	
	
	public <T> CosmosPagedIterable<T> executeQuery(String databaseName, Class<T> typeParameterClass, String query) {
		CosmosPagedIterable<T> data=null;
		try {
		CosmosDatabaseResponse cosmosDatabaseResponse = cosmosClient.createDatabaseIfNotExists(databaseName);
		CosmosDatabase database = cosmosClient.getDatabase(cosmosDatabaseResponse.getProperties().getId());
		CosmosContainer container = database.getContainer(typeParameterClass.getSimpleName());
		CosmosQueryRequestOptions queryOptions = new CosmosQueryRequestOptions();
		data = container.queryItems(query, queryOptions, typeParameterClass);
		return data;
		} catch (Exception e) {
			logger.error("Error occured while connecting to Cosmos DB. " + e.getMessage());
		}
		return data;
	}
}
